import React from 'react';
import ReactDOM from 'react-dom';

import MyTrip from './pages/mytrip';

const App = () => {
	return <MyTrip />;
};

class WebComponent extends HTMLElement {
	connectedCallback() {
		ReactDOM.render(
			<App />,
			this
		);
	}
}

const ELEMENT_ID = 'remote-app-mytrip';

if (!customElements.get(ELEMENT_ID)) {
	customElements.define(ELEMENT_ID, WebComponent);
}
