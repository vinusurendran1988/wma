# Configuration

imgUrl=https://cdxwmadoc.ibsplc.org/ra/login/images/flightStatus-logo.png
apiUrl=http://10.246.28.133:8080/web/wma-stg
redirectUrl=http://10.246.28.133:8080/web/wma-stg

# Build path
https://cdxwmadoc.ibsplc.org/ra/login/js/main.a0eeb5ba.js