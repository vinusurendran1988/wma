import React from 'react';
import ReactDOM from 'react-dom';

import Login from './pages/login';
import * as aws_amplify_react from "aws-amplify-react";
import amplifyCustomUi from "aws-amplify-react-custom-ui";
amplifyCustomUi.configure(aws_amplify_react);
const App = (props) => {
	//const flightStatus = properties;
	return <Login {...props}/>;
};

class WebComponent extends HTMLElement {
	connectedCallback() {

		// const properties = {
		// 	imgUrl: "https://cdxwmadoc.ibsplc.org/ra/login/images/flightStatus-logo.png",
		// 	apiUrl: "http://10.246.28.133:8080/web/wma-stg",
		// 	redirectUrl: "http://10.246.28.133:8080/web/wma-stg",
		// 	signUpPage: ""
		// };

		const properties = {
			imgUrl: this.getAttribute('imgUrl'),
			apiUrl: this.getAttribute('apiUrl'),
			redirectUrl: this.getAttribute('redirectUrl'),
		 signUpPage: ""
		};

		console.log(">>>>>"+JSON.stringify(properties))

		ReactDOM.render(
			<App {...properties}/>,
			this
		);
	}
}

const ELEMENT_ID = 'remote-app-login';

if (!customElements.get(ELEMENT_ID)) {
	customElements.define(ELEMENT_ID, WebComponent);
}
