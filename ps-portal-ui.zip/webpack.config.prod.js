const path = require('path');
const webpack = require('webpack');
const config = require('config');
const fs = require('fs');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CopyPlugin = require('copy-webpack-plugin');
const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin

const isProd = process.env.NODE_ENV === 'production';

// Loading Config JSON using NODE_CONFIG_ENV parameter from Package.json
fs.writeFileSync(path.resolve(__dirname, './env.json'), JSON.stringify(config));

function getArgumentValue(key, defaultVal) {
    for(var i=0; i< process.argv.length; i++) {
        const argv = process.argv[i]
        if(argv.includes(key+"=")) return argv.split("=")[1]
    }
    return defaultVal
}

const appName = getArgumentValue("app", "/")
const buildName = getArgumentValue("build", "airpoints-account")

// Directories
const APP_DIR = path.resolve(__dirname, './src/');
const BUILD_DIR = path.resolve(__dirname, './' + buildName);

// Functions to return environment specfic values
function getPublicPath() {
    //console.log(">>>>>>>>>>>>>>>>>>>>>>>>>"+appName.endsWith("/")?appName:"/".concat(appName).concat("/"));
    return "/airpoints-account/";
    //return appName.endsWith("/")?appName:"/".concat(appName).concat("/");
}

function getBuildMode() {
    if(["production", "development"].includes(process.env.NODE_ENV)) {
        return process.env.NODE_ENV
    }
    return "production"
}

module.exports = {
    entry: APP_DIR + '/index.js',
    mode: getBuildMode(),
    devtool: 'source-map',
    module: {
        rules: [
            {
                test: /\.(js|jsx)$/,
                exclude: /(node_modules|bower_components)/,
                loader: 'babel-loader',
                options: {
                    presets: ['@babel/env', '@babel/react'],
                    plugins: [
                        '@babel/plugin-transform-runtime',
                        '@babel/plugin-transform-regenerator',
                        '@babel/plugin-proposal-class-properties'
                    ],
                },
            },
            {
                test: /\.(s*)css$/,
                use: [
                    'style-loader',
                    'css-loader',
                    'sass-loader'
                ]
            },
            {
                test: /\.(svg|eot|gif|otf|png|ttf|woff|woff2|jpe?g)(\?v=[0-9]\.[0-9]\.[0-9])?$/,
                use: [
                    {
                        loader: 'file-loader',
                    },
                ],
            },
            // {
            // test: /\.(png|gif|woff|woff2|eot|ttf|svg)$/,
            // loader: "url-loader?limit=100000"
            // },
        ]
    },
    resolve: {
        extensions: ["*", ".js", ".jsx"],
        alias: {
            config: path.resolve(__dirname, './env.json')
        }
    },
    output: {
        filename: '[name].[hash].js',
        chunkFilename: '[name].[hash].bundle.js',
        path: BUILD_DIR,
        publicPath: getPublicPath()
    },
    plugins: [
        new webpack.HotModuleReplacementPlugin(),
        new HtmlWebpackPlugin({
            template: './public/index.html',
            favicon: './public/favicon.ico',
            chunks: ['index']
        }),
        new CopyPlugin({
            patterns: [{
                from: 'public',
                globOptions: {
                    dot: true,
                    ignore: ['**/index.html']
                }
            }]
        }),
        new BundleAnalyzerPlugin({
            analyzerMode: 'static',
            openAnalyzer: isProd,
            reportFilename: '../report/report.html',
            statsFilename: '../report/stats.json',
            generateStatsFile: true
        })
    ],
    devServer: {
        host:'0.0.0.0',
        contentBase: path.join(__dirname, "public/"),
        port: 8080,
        watchContentBase: true
    },
    entry: {
        index: './src/index.js'
    },
    optimization: {
        runtimeChunk: 'single',
        splitChunks: {
            chunks: 'all',
            maxInitialRequests: Infinity,
            minSize: 0,
            cacheGroups: {
                vendor: {
                    test: /[\\/]node_modules[\\/]/,
                    name(module) {
                        // get the name. E.g. node_modules/packageName/not/this/part.js
                        // or node_modules/packageName
                        const packageName = module.context.match(/[\\/]node_modules[\\/](.*?)([\\/]|$)/)[1];

                        // npm package names are URL-safe, but some servers don't like @ symbols
                        return `npm.${packageName.replace('@', '')}`;
                    },
                },
            },
        },
    },
};
