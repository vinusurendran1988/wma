# iLoyalty Member Portal Application

This project is based on React with Redux (Build tool is webpack)

## Available Scripts

In the project directory, you can run:

### `npm run dev-server`

Runs the app in the development mode.<br />
Open [http://localhost:8080](http://localhost:8080) to view it in the browser.

The page will reload if you make edits.<br />
You will also see any lint errors in the console.

### `npm test`

Execute all the test cases using Jest

### `npm run build`

Command to builds the member portal for deploying in nginx server. You can build 'production' or 'development' build using this script. You can slo specify the application name and build folder name here.<br />
```
Eg: npm run build -- --app=lmp --build=build
app = base context(default value is / - ROOT)
build = build folder or final output folder(default value is lmp)
```
It correctly bundles React in production mode and optimizes the build for the best performance. 
It also split the bundle into multiple file for better performance.

The build is minified and the filenames include the hashes.<br />

### `npm run build-dev`

Command to build the application in development mode. All the feature mentioned in the above build command is applicable here. The difference here is it will be a development build

## Routing Configuration

-- Comments here --

## Page Configuration

-- Comments here --