import React, { Component } from 'react'
import MemberPortalHeader from '../../components/ui/header/CmsHeader';
import MemberPortalFooter from '../../components/ui/cmsfooter'
import './style.scss'
import _500 from '../../components/ui/errors/500';

export default class _505Page extends Component {
    componentDidMount(){
        const props = {
            includeHeader : false
        }
        this.props.setErrorPageInfo(props)
    }
    render() {
        return (
            <>
                <a className="sr-only sr-only-focusable" href="#content">Skip to main content</a>
                {/* <MemberPortalHeader /> */}
                <_500 />
                {/* <MemberPortalFooter /> */}
            </>
        )
    }
}