import React, { Component } from 'react'
import MemberPortalFooter from '../../components/ui/cmsfooter'
import MemberPortalHeader from '../../components/ui/header/CmsHeader';
import PortalBreadcrumb from '../../components/ui/header/PortalBreadcrumb';
import { connect } from 'react-redux';
import { 
    fetchConfiguration
} from '../../components/common/middleware/redux/commonAction'
import './style.scss'
import { withSuspense } from '../../components/common/utils';
import { withTranslation } from 'react-i18next';
import _403 from '../../components/ui/errors/403';

class _403Page extends Component {

    render() {
        return (
            <>
                <a className="sr-only sr-only-focusable" href="#content">Skip to main content</a>
                <MemberPortalHeader />
                <PortalBreadcrumb breadcrumbs={[]} />
                <_403 />
                <MemberPortalFooter />
            </>
        )
    }
}

const mapStateToProps = (state) =>{
    return{
        currentUserData: state.currentLoginUserDataReducer.currentUserData,
    }
}

const mapDispatchToProps = { fetchConfiguration }

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(_403Page)));_403Page