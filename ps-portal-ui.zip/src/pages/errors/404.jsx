import React, { Component } from 'react'
import MemberPortalHeader from '../../components/ui/header/CmsHeader';
import MemberPortalFooter from '../../components/ui/cmsfooter'
import './style.scss'
import _404 from '../../components/ui/errors/404';

export default class _404Page extends Component {
    render() {
        return (
            <>
                <a className="sr-only sr-only-focusable" href="#content">Skip to main content</a>
                <_404 />
            </>
        )
    }
}