import React, { Component } from 'react'
import { getUserBySocialMedia } from '../../components/common/utils/common.utils'
import { 
    _URL_SOCIAL_LOGGED_USER 
} from '../../components/common/config/config';
import { 
    NAVIGATE_MEMBER_DASHBOARD, 
    NAVIGATE_MEMBER_LOGIN, 
    NAVIGATE_404, 
    NAVIGATE_CORPORATE_OVERVIEW, 
    NAVIGATE_CLUB_OVERVIEW,
    NAVIGATE_500
} from '../../components/common/utils/urlConstants';
import { 
    setItemToBrowserStorage, 
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
    BROWSER_STORAGE_KEY_TOKEN,
    BROWSER_STORAGE_KEY_REFRESH_TOKEN,
    BROWSER_STORAGE_KEY_DEFAULT_PROGRAM_CODE,
    getItemFromBrowserStorage,
    BROWSER_STORAGE_KEY_PROGRAM_TYPE,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    BROWSER_STORAGE_KEY_CUSTOMER_NO,
    BROWSER_STORAGE_KEY_REDIRECT_URL,
    removeItemFromBrowserStorage
} from '../../components/common/utils/storage.utils';
import { PROGRAM_TYPE_CORPORATE, PROGRAM_TYPE_INDIVIDUAL } from '../../components/common/utils/Constants';
import {
    isEmptyOrSpaces,
    getLandingPageURL
} from '../../components/common/utils'

class CallbackPage extends Component {

    constructor(props) {
        super(props);
    }

    querParams() {
        return new URLSearchParams(window.location.search);
    }

    componentDidMount() {
        const token = this.querParams().get('ps-token')
        const refresh_token = this.querParams().get('ps-refreshToken')
        getUserBySocialMedia(token, _URL_SOCIAL_LOGGED_USER).then((response) => { 
            if(response && response.status==200){
                setItemToBrowserStorage(BROWSER_STORAGE_KEY_TOKEN, token)
                setItemToBrowserStorage(BROWSER_STORAGE_KEY_REFRESH_TOKEN, refresh_token) 

                const programType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE)
                const programCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE)

                const { userDetails } = response.data

                let loginProgram = userDetails.programs[programType+"Info"];
                if (loginProgram.length == 1) {
                    loginProgram = loginProgram[0];
                    setItemToBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE, loginProgram.programCode)
                } else {
                    loginProgram = loginProgram.find(lp=> lp.programCode == programCode)
                }
                if(loginProgram) {
                    setItemToBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO, loginProgram.membershipNumber)
                    setItemToBrowserStorage("membershipNumber", loginProgram.membershipNumber)
                    setItemToBrowserStorage(BROWSER_STORAGE_KEY_CUSTOMER_NO, loginProgram.nominee?loginProgram.nominee.customerNumber:loginProgram.customerNumber?loginProgram.customerNumber:"")
                } 
                let redirectURL = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_REDIRECT_URL);
                if (!isEmptyOrSpaces(redirectURL)) {
                    removeItemFromBrowserStorage(BROWSER_STORAGE_KEY_REDIRECT_URL)
                    window.location.href =  `${window.location.origin}${window.location.pathname}#${redirectURL}`
                } else if (getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE) === PROGRAM_TYPE_CORPORATE) {
                    window.location.href = `${window.location.origin}${window.location.pathname}#${NAVIGATE_CORPORATE_OVERVIEW}`
                } else if (getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE) === PROGRAM_TYPE_INDIVIDUAL) {
                    let landingURL = getLandingPageURL(userDetails);
                    if (landingURL) {
                        window.location.href =  landingURL;
                        // setTimeout(() => {window.location.reload()}, 1000);
                    } else {
                        window.location.href =  `${window.location.origin}${window.location.pathname}#${NAVIGATE_500}`
                    }
                } else {
                    window.location.href = `${window.location.origin}${window.location.pathname}#${NAVIGATE_404}`
                }

            }
        })
        .catch((error) => {
            location.href = location.origin + location.pathname + `#${NAVIGATE_MEMBER_LOGIN}?error=failed`;
        });
    }

    render() {
        return (
            <>Loading....</>
        )
    }
}

CallbackPage.propTypes = {
};

export default CallbackPage;