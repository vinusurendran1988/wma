import React from 'react';
import { connect } from 'react-redux';
import parse from 'html-react-parser';
import {
    clearSearchMember,
    hideTransferMilesMessage
} from './actions';
import {
    ID_TRANSFER_MILES,
    ID_CANCEL_TRANSFER_MILES,
    ID_SHOW_SECOND_STEP_BUTTION,
    TRANSACTION_TYPE_CHARITY
} from './Constants';
import {
    numberWithCommas,
    toTitleCase,
    getTransactionFee,
    withSuspense,
    getPointsArray,
    getPrecision,
    getTransferPointsList,
    defaultSearchDropDownTemplate
} from '../../common/utils';
import { withTranslation } from 'react-i18next';
import {
    resetError,
    fetchMasterData
} from '../../common/middleware/redux/commonAction'

import { NAVIGATE_TRANSFER } from '../../common/utils/urlConstants';
import { 
    getItemFromBrowserStorage, 
    BROWSER_STORAGE_KEY_PROGRAM_CODE, 
    BROWSER_STORAGE_KEY_CURRENCY_CODE } from '../../common/utils/storage.utils';
import Button from '../../common/components/fieldbank/Button';
import MfaContext from '../../../context/MfaContext';
import SearchDropdown from '../../common/components/fieldbank/SearchDropdown';
import { CHARITY } from '../../common/utils/Constants';
import FilterDropDown from '../../common/components/fieldbank/FilterDropDown';

const initialData = {
    acceptTerms: false,
    pin: '',
    loyaltyMembershipNumberOfRecipient: ''
}

/**
 * @author Somdas M
 * @description Component to render the TransferToCharity component.
 * The component collects the required information for transfering points to charity
 */
class TransferToCharity extends React.Component {

    constructor(props) {
        super(props);
        const data = JSON.parse(JSON.stringify(initialData))
        this.state = {
            data,
            selectedMember: {},
            step: 1
        }
        this.cancel = this.cancel.bind(this)
        this.handleChange = this.handleChange.bind(this)
        this.showStepTwo = this.showStepTwo.bind(this)
    }

    componentDidMount() {
        this.props.resetError()
        if (!this.props.charityOrganisations || this.props.charityOrganisations.length == 0) {
            this.props.fetchMasterData(TRANSACTION_TYPE_CHARITY, this.props.masterEntityLookup, this.props.masterEntityLookupFilters)
        }
        const params = new URLSearchParams(window.location.hash.split('?')[1]);
        const loyaltyMembershipNumberOfRecipient = params.get('membershipNumber') || '';
        this.handleChange('loyaltyMembershipNumberOfRecipient', loyaltyMembershipNumberOfRecipient);
    }

    handleChange(key, value) {
        this.props.updateState("messageContent", { messages: [], type: ""})
        const { data } = this.state;
        this.props.resetError()
        window.history.pushState({}, null, `#${NAVIGATE_TRANSFER}`)
        data[key] = value;
        this.setState({
            data
        })
        const { message, hideMessage } = this.props;
        if (message.showMessage) {
            hideMessage();
        }
    }

    showStepTwo() {
        const { charityOrganisations } = this.props;
        const { data } = this.state;
        const selectedMember = charityOrganisations.find(member => member.FieldValue === data.loyaltyMembershipNumberOfRecipient);
        this.setState({
            selectedMember,
            step: 2
        }, ()=>{
            this.props.hideMessage();
        })
    }

    cancel() {
        const data = JSON.parse(JSON.stringify(initialData));
        this.props.resetError()
        this.props.clearSearchMember();
        this.setState({
            data,
            step: 1
        })
    }

    render() {
        const { t, pointDetails, charityOrganisations, getAvailablePoints, isProtectedApi, config, specialMessageStatus } = this.props;
        const { data, selectedMember, step } = this.state;
        const disableContinue = !(data.pointsToTransfer && data.loyaltyMembershipNumberOfRecipient);
        const disablePay = isProtectedApi ? !(data.acceptTerms && data.pin) : !(data.acceptTerms);
        const pointsAvailable = getAvailablePoints()
        const selectedPointDetails = pointDetails[0];
        const withPayment = selectedPointDetails.isPaymentRequired;

        let transferPointsList = [];
        let pointsList = [];
        pointsList = getPointsArray(this.props.pointDetails[0]).filter(point => point <= pointsAvailable);
        transferPointsList = getTransferPointsList(pointsList);


        return (
            <div className="toggle1">
                {step === 1 &&
                    <div className="step1">
                        <div className="form-row">
                            <div className="col-lg-6 col-md-6">
                                <div className="form-group">
                                <div className="select-wrap">
                                    <label htmlFor="choose_recipient">{t("transfer.charity.choose_recipient")}
                                    <span className="text-warning">*</span>
                                    </label>
                                    <select 
                                        id="choose_recipient"
                                        onChange={(event) => {
                                            this.handleChange('loyaltyMembershipNumberOfRecipient', event.target.value)
                                        }}
                                        value={data.loyaltyMembershipNumberOfRecipient}
                                        data-test="charityList"
                                    >
                                        <option value="" key="r0">{t("transfer.charity.choose_recipient_placeholder")}</option>
                                        {
                                            charityOrganisations && charityOrganisations.map(member => {
                                                return <option key={member.FieldValue} value={member.FieldValue} key={member.FieldValue}>{member.FieldDescription}</option>
                                            })
                                        }
                                    </select>
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-6 col-md-6">
                                <div className="form-group">
                                {
                                    config && config.isPacket ?
                                        <FilterDropDown
                                            label={t("transfer.charity.points_transfer")}
                                            labelDesc={<strong className="float-right">{t("transfer.charity.available")} : {numberWithCommas(pointsAvailable)}</strong>}
                                            placeholder={t("transfer.charity.points_transfer")}
                                            options={transferPointsList}
                                            isRequired={true}
                                            id="points_transfer"
                                            value={data.pointsToTransfer}
                                            onChange={(e) =>
                                                this.handleChange('pointsToTransfer', e)
                                            }
                                            testIdentifier="pointsToTransferFilter"
                                            info=""
                                            enabled={true}
                                        />
                                        : 
                                        <SearchDropdown
                                            label={t("transfer.charity.points_transfer")}
                                            labelDesc={<strong className="float-right">{t("transfer.charity.available")} : {numberWithCommas(pointsAvailable)}</strong>}
                                            placeholder={t("transfer.charity.points_transfer")}
                                            options={transferPointsList}
                                            isRequired={true}
                                            id="points_transfer"
                                            value={data.pointsToTransfer}
                                            itemTemplate={(e) => defaultSearchDropDownTemplate(e)}
                                            onChange={(e) =>
                                                this.handleChange('pointsToTransfer', e)
                                            }
                                            testIdentifier="pointsToTransferFreeForm"
                                            // error=""
                                            info=""
                                            enabled={true}
                                        />
                                    }
                                </div>
                            </div>
                            {
                                specialMessageStatus && 
                                <div className="col-lg-12 col-md-12">
                                    <div className="form-group">
                                        <label htmlFor="special_message">{t("transfer.charity.special_message")}</label>
                                        <textarea 
                                            id="special_message"
                                            placeholder={t("transfer.charity.specialMessage_placeHolder")}
                                            rows="3" cols="60" 
                                            value={data.specialMessageValue}
                                            onChange={(event) => this.handleChange('specialMessageValue', event.target.value)}
                                            data-test="specialMessage"
                                        >
                                        </textarea>
                                    </div>
                                </div>
                            }
                        </div>
                        <div className="form-row">
                            <div className="col-12 buttonWrap d-flex justify-content-between">
                                <div className="buttonLeftTxt"></div>
                                <div>
                                    <Button
                                        className="btn btn-primary"
                                        handleOnClick={() => this.showStepTwo()}
                                        id={ID_SHOW_SECOND_STEP_BUTTION}
                                        data-test="ButtonContinue"
                                        enabled={!disableContinue}
                                        testIdentifier="continueBtn"
                                        label={t("transfer.charity.continue_btn")} />
                                </div>
                            </div>
                        </div>
                    </div>
                }
                {step === 2 &&
                    <div className="step2">
                        <div className="form-row">
                            <div className="col-12 customeTxt">
                                <p>
                                    {parse(t("transfer.charity.message_while_transfer_one").replace("{SELECTED_POINTS}", numberWithCommas(data.pointsToTransfer)).replace("{RECIPIENT}", toTitleCase(selectedMember.FieldDescription)))}
                                    {/* Transferring <strong>{data.pointsToTransfer}</strong> miles to <strong>{toTitleCase(selectedMember.displayName)}</strong> */}
                                    {
                                        withPayment &&
                                        <>
                                            {parse(t("transfer.charity.message_while_transfer_two").replace("{PAYABLE_AMOUNT}", numberWithCommas(getTransactionFee(selectedPointDetails.transactionFee, data.pointsToTransfer).toFixed(getPrecision(this.props.defaultConfig)))).replace("{CURRENCY_CODE}", getItemFromBrowserStorage(BROWSER_STORAGE_KEY_CURRENCY_CODE)))}
                                            {/* &nbsp;Transaction fee <strong>{getTransactionFee(data.pointsToTransfer, settings)}</strong>  */}

                                        </>
                                    }</p>
                            </div>
                        </div>
                        <div className="form-row">
                            {
                                isProtectedApi &&
                                <div className="col-lg-4 col-md-6">
                                    <div className="form-group">
                                        <label htmlFor="charityMemberPin">{t("transfer.charity.enter_pin")}</label>
                                        <input className="" type="password" placeholder={t("transfer.charity.enter_pin_placeholder")} id="charityMemberPin"
                                            onChange={(event) => {
                                                this.handleChange('pin', event.target.value);
                                            }}
                                            value={data.pin}
                                            data-test="memberPin"
                                        />
                                    </div>
                                </div>}
                            <div className="col-lg-8 col-md-6">
                            </div>
                        </div>
                        {/* <div className="form-row">
                            <div className="col-12">
                                <h3>{(t("transfer.charity.terms_and_condition.title")!="transfer.charity.terms_and_condition.title")?t("transfer.charity.terms_and_condition.title"):""}</h3>
                                <ul className="" type="square">
                                    <li>{(t("transfer.charity.terms_and_condition.first_line")!="transfer.charity.terms_and_condition.first_line")?t("transfer.charity.terms_and_condition.first_line").replace("{PACKAGE_OF}", selectedPointDetails.packetSize):""}</li>
                                    <li>{(t("transfer.charity.terms_and_condition.second_line")!="transfer.charity.terms_and_condition.second_line")?t("transfer.charity.terms_and_condition.second_line").replace("{PERIOD}", `${selectedPointDetails.transferPeriod} ${selectedPointDetails.transferPeriodUnit}`).replace("{MAX_POINTS}", selectedPointDetails.transferPeriodMaxPoints):""}</li>
                                    <li>{(t("transfer.charity.terms_and_condition.third_line")!="transfer.charity.terms_and_condition.third_line")?t("transfer.charity.terms_and_condition.third_line").replace("{MIN_PACKAGE}", selectedPointDetails.minimumPacket * selectedPointDetails.packetSize).replace("{MAX_PACKAGE}", selectedPointDetails.maximumPacket * selectedPointDetails.packetSize):""}</li>
                                    {
                                        selectedPointDetails.isPaymentRequired && selectedPointDetails.transactionFee &&
                                        <li>{
                                            t(selectedPointDetails.transactionFee.perUnit ? "transfer.charity.terms_and_condition.fourth_line_1" : "transfer.charity.terms_and_condition.fourth_line_2").replace("{PAYABLE_AMOUNT}", selectedPointDetails.transactionFee.amount.toString()).replace("{CURRENCY_CODE}", getItemFromBrowserStorage(BROWSER_STORAGE_KEY_CURRENCY_CODE))
                                        }</li>
                                    }
                                </ul>
                            </div>
                        </div> */}
                        <div className="form-row">
                            <div className="col-12 buttonWrap">
                                <div className="form-row">
                                    <div className="col-lg-6 col-md-12 buttonLeftTxt">
                                        <div className="form-check form-check-inline">
                                            <input className="form-check-input" 
                                                type="checkbox" 
                                                id="inlineCheckbox1"
                                                checked={data.acceptTerms}
                                                onChange={(event) => {
                                                    this.handleChange('acceptTerms', event.target.checked);
                                                }}
                                                data-test="acceptTermsCheckbox"
                                            />
                                            <label className="form-check-label" htmlFor="inlineCheckbox1">
                                                {parse(t("transfer.charity.accept_text_one"))}
                                                {/* <a role="button">{t("transfer.charity.accept_text_two")}</a> */}
                                                {t("transfer.charity.accept_text_two")}
                                                {t("transfer.charity.accept_text_three")}
                                            </label>
                                        </div>
                                    </div>
                                    <div className="col-lg-6 col-md-12 text-lg-right btn-wrap btn-wrap--grp">
                                        <Button
                                            className="btn btn-secondary"
                                            handleOnClick={() => this.cancel()}
                                            id={ID_CANCEL_TRANSFER_MILES}
                                            testIdentifier="transferCancelBtn"
                                            label={t("transfer.charity.cancel_btn")} />
                                        <Button
                                            className="btn btn-primary"
                                            handleOnClick={() => this.props.makePayment(data.loyaltyMembershipNumberOfRecipient, data.pointsToTransfer, this.cancel, data.pin, data.specialMessageValue)}
                                            id={ID_TRANSFER_MILES}
                                            testIdentifier="proceedToTransferBtn"
                                            enabled={!disablePay}
                                            label={t("transfer.charity.transfer_btn")} />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                }
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
        message: state.transferMilesMessage,
        defaultConfig: state.configurationReducer.default,
        masterEntityLookup: state.masterEntityDataReducer.masterEntityLookup,
        masterEntityLookupFilters: state.masterEntityDataReducer.masterEntityLookupFilters,
        charityOrganisations: state.masterData[CHARITY]
    }
}

const mapDispatchToProps = dispatch => {
    return {
        hideMessage: () => dispatch(hideTransferMilesMessage()),
        clearSearchMember: () => dispatch(clearSearchMember),
        resetError: () => dispatch(resetError()),
        fetchMasterData: (params, lookup, filter) => dispatch(fetchMasterData(params, lookup, filter))
    }
}
TransferToCharity.contextType = MfaContext
export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(TransferToCharity)));