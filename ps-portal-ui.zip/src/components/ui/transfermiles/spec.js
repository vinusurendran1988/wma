import React from 'react';
import TransferMiles from './index'
import {
    findByTestAttr,
    findComponent,
    mockServiceResponse
} from '../../common/testUtils';
import { testStore } from '../../common/utils';
import moxios from 'moxios';
import { mount } from 'enzyme';
import ReactTestUtils from 'react-dom/test-utils';
import {
    fetchConfiguration, fetchAccountSummary, getFamilyMembers, fetchMasterData
} from '../../common/middleware/redux/commonAction'
import { Provider } from 'react-redux'
import { CONFIG_SECTION_TRANSFERPOINT, CONFIG_SECTION_DEFAULT, CHARITY } from '../../common/utils/Constants';
import { BROWSER_STORAGE_KEY_MEMBERSHIP_NO, BROWSER_STORAGE_KEY_COMPANY_CODE, BROWSER_STORAGE_KEY_PROGRAM_CODE } from '../../common/utils/storage.utils';
import { axiosInstance } from '../../common/utils/api';
import { searchMember, makePayment, transferPoints, acceptPayment, logout, postLogout, setTransferMilesMessage, SET_TRANSFER_MILES_MESSAGE } from './actions';
import { _URL_TRANSFER_POINT, _URL_ACCEPT_PAYMENT, _URL_ACCOUNT_SUMMARY, _URL_TRANSACTION_AUTHENTICATE, _URL_TRANSACTION_LOGOUT, _URL_SEARCH_MEMBER } from '../../common/config/config';
import { NAVIGATE_TRANSFER } from '../../common/utils/urlConstants';

var store = testStore({})
let rootComponent;
let component;

const setUpTransferMiles = (props = {}, isDefaultConfig = false) => {
    props.setMenuReference = jest.fn();
    props.resetError = jest.fn();
    props.setStep = jest.fn();
    props.hideMessage = jest.fn();
    props.message = {}
    props.setPageInfo = jest.fn();
    if (isDefaultConfig) {
        props["config"] = JSON.parse(JSON.stringify(CONFIG_RESPONSE)).object
    }
    rootComponent = mount(<Provider store={store}>
        <TransferMiles {...props} store={store} />
    </Provider>);
    component = findComponent(rootComponent, 'TransferMiles');
};

const updateComponents = () => {
    rootComponent = rootComponent.update()
    component = findComponent(rootComponent, 'TransferMiles');

}

const loadInitialApi = () => {
    mockServiceResponse(DEFAULT_RESPONSE, 200, {})
    return ReactTestUtils.act(() => {
        return store.dispatch(fetchConfiguration(CONFIG_SECTION_DEFAULT))
            .then(() => {
                let newState = store.getState();
                expect(newState.configurationReducer[CONFIG_SECTION_DEFAULT]).toBe(DEFAULT_RESPONSE.object);
                mockServiceResponse(CONFIG_RESPONSE, 200, {})
                return ReactTestUtils.act(() => {
                    return store.dispatch(fetchConfiguration(CONFIG_SECTION_TRANSFERPOINT))
                        .then(() => {
                            newState = store.getState();
                            expect(newState.configurationReducer[CONFIG_SECTION_TRANSFERPOINT]).toBe(CONFIG_RESPONSE.object);
                            mockServiceResponse(ACCOUNT_SUMMARY_RESPONSE, 200, {})
                            return ReactTestUtils.act(() => {
                                return store.dispatch(fetchAccountSummary())
                                    .then(() => {
                                        newState = store.getState();
                                        expect(newState.accountSummaryReducer.accountSummary).toBe(ACCOUNT_SUMMARY_RESPONSE.object);
                                        setUpTransferMiles({}, true);
                                    })
                            })
                        })
                })
            })
    })
}



describe('Should load the TransferMiles component successfully', () => {
    beforeEach(() => {
        localStorage.setItem(BROWSER_STORAGE_KEY_COMPANY_CODE, 'IBS')
        localStorage.setItem(BROWSER_STORAGE_KEY_PROGRAM_CODE, 'PRG14')
        localStorage.setItem(BROWSER_STORAGE_KEY_MEMBERSHIP_NO, 'IM0008010415')
        store = undefined
        store = testStore({})
        moxios.install(axiosInstance);
        return loadInitialApi()
    });

    afterEach(() => {
        moxios.uninstall(axiosInstance);
    });

    it('Should render the TransferToCharity tab component', () => {

        let newState = store.getState();
        const  { masterEntityLookup, masterEntityLookupFilters}  = newState.masterEntityDataReducer
        mockServiceResponse(MASTER_DATA_CHARITY_RESPONSE)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchMasterData(CHARITY, masterEntityLookup, masterEntityLookupFilters))
                .then(() => {
                    
                    // updateComponents()
                    newState = store.getState();
                    expect(newState.masterData[CHARITY]).toStrictEqual(MASTER_DATA_CHARITY_RESPONSE.object.masterRecordList);

                    const transferMilesComponent = findByTestAttr(component, 'transferMilesComponent');
                    expect(transferMilesComponent.length).toBe(1);

                    let general_mob_a = findByTestAttr(component, 'family_mob_a');
                    expect(general_mob_a.length).toBe(1);
                    general_mob_a.simulate('click')

                    let general_tabmob = findByTestAttr(component, 'general_tabmob');
                    expect(general_tabmob.length).toBe(1);
                    general_tabmob.simulate('click')

                    let li_family = findByTestAttr(component, 'li_charity');
                    expect(li_family.length).toBe(1);
                    li_family.simulate('click')

                    updateComponents()

                    const charityList = findByTestAttr(component, 'charityList');
                    expect(charityList.length).toBe(1);
                    charityList.simulate('change', { target: { value: "IM0008011007" } })

                    const pointsToTransferFreeForm = findByTestAttr(component, 'pointsToTransferFreeForm');
                    expect(pointsToTransferFreeForm.length).toBe(1);
                    pointsToTransferFreeForm.props().onChange({ target: { value: { label: "1500", value: "1500" } } })

                    const specialMessage = findByTestAttr(component, 'specialMessage');
                    expect(specialMessage.length).toBe(1);
                    specialMessage.props().onChange({ target: { value: "Custom Message" } })

                    const continueBtn = findByTestAttr(component, 'continueBtn');
                    expect(continueBtn.length).toBe(1);
                    continueBtn.props().onClick()
                    
                    updateComponents()

                    const memberPin = findByTestAttr(component, 'memberPin');
                    expect(memberPin.length).toBe(1);
                    memberPin.simulate('change', { target: { value: "1234" } })

                    const acceptTermsCheckbox = findByTestAttr(component, 'acceptTermsCheckbox');
                    expect(acceptTermsCheckbox.length).toBe(1);
                    acceptTermsCheckbox.simulate('change', { target: { checked: true } })
                    
                    updateComponents()

                    const proceedToTransferBtn = findByTestAttr(component, 'proceedToTransferBtn');
                    expect(proceedToTransferBtn.length).toBe(1);

                    
                    moxios.stubRequest(_URL_TRANSFER_POINT, {
                        status: 200,
                        responseText: MAKE_PAYMENT_RESPONSE
                    })
                    moxios.stubRequest(_URL_ACCEPT_PAYMENT, {
                        status: 200,
                        responseText: PAYMENT_RESPONSE
                    })
                    moxios.stubRequest(_URL_ACCOUNT_SUMMARY, {
                        status: 200,
                        responseText: ACCOUNT_SUMMARY_RESPONSE
                    })

                    const newUrl = 'transaction?payment=success&&tid=1234';
                    Object.defineProperty(window, 'location', {
                        writable: true,
                        value: {
                            href: `#${NAVIGATE_TRANSFER}?payment=success&&tid=1234`,
                            hash: newUrl
                        }
                    });
                    proceedToTransferBtn.props().onClick()
                    updateComponents()
                    const transferCancelBtn = findByTestAttr(component, 'transferCancelBtn');
                    expect(transferCancelBtn.length).toBe(1);
                    transferCancelBtn.props().onClick()
                })
        })
    })

    it('Should render the Cancelled Transaction scenario', () => {

        let newState = store.getState();
        const  { masterEntityLookup, masterEntityLookupFilters}  = newState.masterEntityDataReducer
        mockServiceResponse(MASTER_DATA_CHARITY_RESPONSE)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchMasterData(CHARITY, masterEntityLookup, masterEntityLookupFilters))
                .then(() => {
                    
                    // updateComponents()
                    newState = store.getState();
                    expect(newState.masterData[CHARITY]).toStrictEqual(MASTER_DATA_CHARITY_RESPONSE.object.masterRecordList);

                    const transferMilesComponent = findByTestAttr(component, 'transferMilesComponent');
                    expect(transferMilesComponent.length).toBe(1);

                    let general_mob_a = findByTestAttr(component, 'family_mob_a');
                    expect(general_mob_a.length).toBe(1);
                    general_mob_a.simulate('click')

                    let general_tabmob = findByTestAttr(component, 'general_tabmob');
                    expect(general_tabmob.length).toBe(1);
                    general_tabmob.simulate('click')

                    let li_family = findByTestAttr(component, 'li_charity');
                    expect(li_family.length).toBe(1);
                    li_family.simulate('click')

                    updateComponents()

                    const charityList = findByTestAttr(component, 'charityList');
                    expect(charityList.length).toBe(1);
                    charityList.simulate('change', { target: { value: "IM0008011007" } })

                    const pointsToTransferFreeForm = findByTestAttr(component, 'pointsToTransferFreeForm');
                    expect(pointsToTransferFreeForm.length).toBe(1);
                    pointsToTransferFreeForm.props().onChange({ target: { value: { label: "1500", value: "1500" } } })

                    const specialMessage = findByTestAttr(component, 'specialMessage');
                    expect(specialMessage.length).toBe(1);
                    specialMessage.props().onChange({ target: { value: "Custom Message" } })

                    const continueBtn = findByTestAttr(component, 'continueBtn');
                    expect(continueBtn.length).toBe(1);
                    continueBtn.props().onClick()
                    
                    updateComponents()

                    const memberPin = findByTestAttr(component, 'memberPin');
                    expect(memberPin.length).toBe(1);
                    memberPin.simulate('change', { target: { value: "1234" } })

                    const acceptTermsCheckbox = findByTestAttr(component, 'acceptTermsCheckbox');
                    expect(acceptTermsCheckbox.length).toBe(1);
                    acceptTermsCheckbox.simulate('change', { target: { checked: true } })
                    
                    updateComponents()

                    const proceedToTransferBtn = findByTestAttr(component, 'proceedToTransferBtn');
                    expect(proceedToTransferBtn.length).toBe(1);

                    
                    moxios.stubRequest(_URL_TRANSFER_POINT, {
                        status: 200,
                        responseText: MAKE_PAYMENT_RESPONSE
                    })
                    moxios.stubRequest(_URL_ACCEPT_PAYMENT, {
                        status: 200,
                        responseText: PAYMENT_RESPONSE
                    })
                    moxios.stubRequest(_URL_ACCOUNT_SUMMARY, {
                        status: 200,
                        responseText: ACCOUNT_SUMMARY_RESPONSE
                    })

                    const newUrl = 'transaction?payment=cancelled&&tid=1234';
                    Object.defineProperty(window, 'location', {
                        writable: true,
                        value: {
                            href: `#${NAVIGATE_TRANSFER}?payment=cancelled&&tid=1234`,
                            hash: newUrl
                        }
                    });
                    proceedToTransferBtn.props().onClick()
                    updateComponents()
                    const transferCancelBtn = findByTestAttr(component, 'transferCancelBtn');
                    expect(transferCancelBtn.length).toBe(1);
                    transferCancelBtn.props().onClick()
                })
        })
    })

    it('Should render the Failed Transaction scenario', () => {

        let newState = store.getState();
        const  { masterEntityLookup, masterEntityLookupFilters}  = newState.masterEntityDataReducer
        mockServiceResponse(MASTER_DATA_CHARITY_RESPONSE)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchMasterData(CHARITY, masterEntityLookup, masterEntityLookupFilters))
                .then(() => {
                    
                    // updateComponents()
                    newState = store.getState();
                    expect(newState.masterData[CHARITY]).toStrictEqual(MASTER_DATA_CHARITY_RESPONSE.object.masterRecordList);

                    const transferMilesComponent = findByTestAttr(component, 'transferMilesComponent');
                    expect(transferMilesComponent.length).toBe(1);

                    let general_mob_a = findByTestAttr(component, 'family_mob_a');
                    expect(general_mob_a.length).toBe(1);
                    general_mob_a.simulate('click')

                    let general_tabmob = findByTestAttr(component, 'general_tabmob');
                    expect(general_tabmob.length).toBe(1);
                    general_tabmob.simulate('click')

                    let li_family = findByTestAttr(component, 'li_charity');
                    expect(li_family.length).toBe(1);
                    li_family.simulate('click')

                    updateComponents()

                    const charityList = findByTestAttr(component, 'charityList');
                    expect(charityList.length).toBe(1);
                    charityList.simulate('change', { target: { value: "IM0008011007" } })

                    const pointsToTransferFreeForm = findByTestAttr(component, 'pointsToTransferFreeForm');
                    expect(pointsToTransferFreeForm.length).toBe(1);
                    pointsToTransferFreeForm.props().onChange({ target: { value: { label: "1500", value: "1500" } } })

                    const specialMessage = findByTestAttr(component, 'specialMessage');
                    expect(specialMessage.length).toBe(1);
                    specialMessage.props().onChange({ target: { value: "Custom Message" } })

                    const continueBtn = findByTestAttr(component, 'continueBtn');
                    expect(continueBtn.length).toBe(1);
                    continueBtn.props().onClick()
                    
                    updateComponents()

                    const memberPin = findByTestAttr(component, 'memberPin');
                    expect(memberPin.length).toBe(1);
                    memberPin.simulate('change', { target: { value: "1234" } })

                    const acceptTermsCheckbox = findByTestAttr(component, 'acceptTermsCheckbox');
                    expect(acceptTermsCheckbox.length).toBe(1);
                    acceptTermsCheckbox.simulate('change', { target: { checked: true } })
                    
                    updateComponents()

                    const proceedToTransferBtn = findByTestAttr(component, 'proceedToTransferBtn');
                    expect(proceedToTransferBtn.length).toBe(1);

                    
                    moxios.stubRequest(_URL_TRANSFER_POINT, {
                        status: 200,
                        responseText: MAKE_PAYMENT_RESPONSE
                    })
                    moxios.stubRequest(_URL_ACCEPT_PAYMENT, {
                        status: 200,
                        responseText: PAYMENT_RESPONSE
                    })
                    moxios.stubRequest(_URL_ACCOUNT_SUMMARY, {
                        status: 200,
                        responseText: ACCOUNT_SUMMARY_RESPONSE
                    })

                    const newUrl = 'transaction?payment=failed&&tid=1234';
                    Object.defineProperty(window, 'location', {
                        writable: true,
                        value: {
                            href: `#${NAVIGATE_TRANSFER}?payment=failed&&tid=1234`,
                            hash: newUrl
                        }
                    });
                    proceedToTransferBtn.props().onClick()
                    updateComponents()
                    const transferCancelBtn = findByTestAttr(component, 'transferCancelBtn');
                    expect(transferCancelBtn.length).toBe(1);
                    transferCancelBtn.props().onClick()
                })
        })
    })

    it('Should render the TransferToFamilyMember tab component', () => {

        mockServiceResponse(FAMILY_MEMBERS_RESPONSE)
        return ReactTestUtils.act(() => {
            return store.dispatch(getFamilyMembers({ companyCode: "", programCode: "", membershipNumber: "" }))
                .then(() => {
                    
                    updateComponents()
                    let newState = store.getState();
                    expect(newState.familyListReducer.members).toStrictEqual(FAMILY_MEMBERS_RESPONSE.object);

                    const transferMilesComponent = findByTestAttr(component, 'transferMilesComponent');
                    expect(transferMilesComponent.length).toBe(1);

                    let li_family = findByTestAttr(component, 'li_family');
                    expect(li_family.length).toBe(1);
                    li_family.simulate('click')

                    updateComponents()

                    const familyMemberDropdown = findByTestAttr(component, 'familyMemberDropdown');
                    expect(familyMemberDropdown.length).toBe(1);
                    familyMemberDropdown.simulate('change', { target: { value: "IM0008010484" } })

                    const pointsToTransferFilter = findByTestAttr(component, 'pointsToTransferFilter');
                    expect(pointsToTransferFilter.length).toBe(1);
                    pointsToTransferFilter.props().onChange({ target: { value: { label: "1500", value: "1500" } } })

                    const specialMessage = findByTestAttr(component, 'specialMessage');
                    expect(specialMessage.length).toBe(1);
                    specialMessage.props().onChange({ target: { value: "" } })

                    const continueBtn = findByTestAttr(component, 'continueBtn');
                    expect(continueBtn.length).toBe(1);
                    continueBtn.props().onClick()
                    
                    updateComponents()

                    const memberPin = findByTestAttr(component, 'memberPin');
                    expect(memberPin.length).toBe(1);
                    memberPin.simulate('change', { target: { value: "1234" } })

                    const acceptTermsCheckbox = findByTestAttr(component, 'acceptTermsCheckbox');
                    expect(acceptTermsCheckbox.length).toBe(1);
                    acceptTermsCheckbox.simulate('change', { target: { checked: true } })

                    updateComponents()

                    const proceedToTransferBtn = findByTestAttr(component, 'proceedToTransferBtn');
                    expect(proceedToTransferBtn.length).toBe(1);
                    proceedToTransferBtn.props().onClick()

                    const transferCancelBtn = findByTestAttr(component, 'transferCancelBtn');
                    expect(transferCancelBtn.length).toBe(1);
                    transferCancelBtn.props().onClick()
                })
        })
    })

    it('Should render the TransferToNewRecipient tab component', () => {

        const transferMilesComponent = findByTestAttr(component, 'transferMilesComponent');
        expect(transferMilesComponent.length).toBe(1);

        let li_general = findByTestAttr(component, 'li_general');
        expect(li_general.length).toBe(1);
        li_general.simulate('click')

        updateComponents()

        let searchMemberBtn = findByTestAttr(component, 'searchMemberBtn');
        expect(searchMemberBtn.length).toBe(1);
        searchMemberBtn.simulate('click')

        const searchDropDownType = findByTestAttr(component, 'searchDropDownType');
        expect(searchDropDownType.length).toBe(1);
        searchDropDownType.simulate('change', { target: { value: "Membership Number" } })

        const searchMembershipNumber = findByTestAttr(component, 'searchMembershipNumber');
        expect(searchMembershipNumber.length).toBe(1);
        searchMembershipNumber.simulate('change', { target: { value: "testMembershipNumber" } })
        
        searchMemberBtn = findByTestAttr(component, 'searchMemberBtn');
        expect(searchMemberBtn.length).toBe(1);

        moxios.stubRequest(_URL_SEARCH_MEMBER, {
            status: 200,
            responseText: SEARCH_MEMBER_RESPONSE
        })
        searchMemberBtn.simulate('click')
        updateComponents()
        const pointsToTransferFilter = findByTestAttr(component, 'pointsToTransferFilter');
        expect(pointsToTransferFilter.length).toBe(1);
        pointsToTransferFilter.props().onChange({ target: { value: { label: "1500", value: "1500" } } })

        const specialMessage = findByTestAttr(component, 'specialMessage');
        expect(specialMessage.length).toBe(1);
        specialMessage.props().onChange({ target: { value: "Custom Message" } })

        updateComponents()

        const continueBtn = findByTestAttr(component, 'continueBtn');
        expect(continueBtn.length).toBe(1);
        continueBtn.props().onClick()

        updateComponents()

        const otherAcceptTermsCheckbox = findByTestAttr(component, 'otherAcceptTermsCheckbox');
        expect(otherAcceptTermsCheckbox.length).toBe(1);
        otherAcceptTermsCheckbox.simulate('change', { target: { checked: true } })

        const memberPin = findByTestAttr(component, 'memberPin');
        expect(memberPin.length).toBe(1);
        memberPin.simulate('change', { target: { value: "1234" } })

        const proceedToTransferBtn = findByTestAttr(component, 'proceedToTransferBtn');
        expect(proceedToTransferBtn.length).toBe(1);
        proceedToTransferBtn.props().onClick()

        const transferCancelBtn = findByTestAttr(component, 'transferCancelBtn');
        expect(transferCancelBtn.length).toBe(1);
        transferCancelBtn.props().onClick()
    })
})


describe('Should invoke the actions and respective reducers', () => {
    beforeEach(()=>{
        store = undefined
        store = testStore({})
        moxios.install(axiosInstance);
    })

    afterEach(()=>{
        moxios.uninstall(axiosInstance)
    })
    
    it('Should invoke searchMember with success response', () => {
        mockServiceResponse(SEARCH_MEMBER_RESPONSE)
        return ReactTestUtils.act(() => {
            return store.dispatch(searchMember("", ""))
                .then(() => {
                    const newState = store.getState()
                    expect(newState.searchMember.memberDetails).toBe(SEARCH_MEMBER_RESPONSE.object)
                })
        })
    })

    it('Should invoke searchMember with error response', () => {
        mockServiceResponse(SEARCH_MEMBER_ERROR_RESPONSE, 500)
        return ReactTestUtils.act(() => {
            return store.dispatch(searchMember("", ""))
                .then(() => {
                    const newState = store.getState()
                    expect(newState.commonErrorReducer.error).toStrictEqual([SEARCH_MEMBER_ERROR_RESPONSE.error.errorDetails[0].message])
                })
        })
    })

    it('Should invoke the makePayment with success response', ()=>{
        moxios.stubRequest(_URL_TRANSFER_POINT, {
            status: 200,
            responseText: MAKE_PAYMENT_RESPONSE
        })
        moxios.stubRequest(_URL_ACCEPT_PAYMENT, {
            status: 200,
            responseText: PAYMENT_RESPONSE
        })

        moxios.stubRequest(_URL_ACCOUNT_SUMMARY, {
            status: 200,
            responseText: ACCOUNT_SUMMARY_RESPONSE
        })
        
        return ReactTestUtils.act(() => {
            return store.dispatch(makePayment(PAYMENT_REQUEST_WITHOUTAPI, ""))
        })
    })

    it('Should invoke the makePayment with error response', () => {
        mockServiceResponse(MAKE_PAYMENT_ERROR_RESPONSE, 500)
        return ReactTestUtils.act(() => {
            return store.dispatch(makePayment(PAYMENT_REQUEST_WITHAPI, ""))
                .then(() => {
                    const newState = store.getState()
                    expect(newState.commonErrorReducer.error).toStrictEqual([MAKE_PAYMENT_ERROR_RESPONSE.error.errorDetails[0].message])

                })
        })
    })

    it('Should invoke the authenticate method', ()=>{
        moxios.stubRequest(_URL_TRANSACTION_AUTHENTICATE, {
            status: 200,
            responseText: AUTHENTICATE__RESPONSE
        })
        return ReactTestUtils.act(() => {
            return store.dispatch(makePayment(PAYMENT_REQUEST_WITHAPI, ""))
                .then(() => {
                    const newState = store.getState()
                    // expect(newState.commonErrorReducer.error).toStrictEqual([MAKE_PAYMENT_ERROR_RESPONSE.error.errorDetails[0].message])

                })
        })
    })

    it('Should invoke the transfer action', ()=>{
        moxios.stubRequest(_URL_TRANSFER_POINT, {
            status: 200,
            responseText: MAKE_PAYMENT_RESPONSE
        })
        return ReactTestUtils.act(() => {
            return store.dispatch(transferPoints(PAYMENT_REQUEST_WITHAPI_PAYMENT, ""))
        })
    })

    it('Should invoke the transfer action but api responds with 400', ()=>{
        moxios.stubRequest(_URL_TRANSFER_POINT, {
            status: 400,
            responseText: MAKE_PAYMENT_ERROR_RESPONSE
        })
        return ReactTestUtils.act(() => {
            return store.dispatch(transferPoints(PAYMENT_REQUEST_WITHAPI_PAYMENT, ""))
        })
    })

    // it('Should invoke the transfer action but api responds with 500 MFA_REQUIRED', ()=>{
    //     moxios.stubRequest(_URL_TRANSFER_POINT, {
    //         status: 500,
    //         responseText: MAKE_PAYMENT_MFA_ERROR_RESPONSE
    //     })
    //     return ReactTestUtils.act(() => {
    //         const openMfaTab = () => {}
    //         const setMfaMethod  = () => {}
    //         return store.dispatch(transferPoints(PAYMENT_REQUEST_WITHAPI_PAYMENT, "", {openMfaTab, setMfaMethod }))
    //     })
    // })

    it('Should invoke the acceptPayment method but api fails', ()=>{
        moxios.stubRequest(_URL_ACCEPT_PAYMENT, {
            status: 500,
            responseText: ACCEPT_PAYMENT_ERROR_RESPONSE
        })
        return ReactTestUtils.act(() => {
            const resetStates= ()=> {}
            const params = {companyCode : "text", programCode : "text",transactionId : "text", membershipNumber : "text", activityCode : "text", activityName : "text", activityNumber : "text", activityType : "text", paymentGateWayRefNumber : "text", order_amount : "text", order_currency : "text", pointType : "text", transactionType : "text", resetStates} 
            return store.dispatch(acceptPayment(params, "id"))
        })
    })


    it('Should invoke the logout method but api fails', ()=>{
        moxios.stubRequest(_URL_TRANSACTION_LOGOUT, {
            status: 500,
            responseText: LOGOUT_PAYMENT_ERROR_RESPONSE
        })
        return ReactTestUtils.act(() => {
            const resetStates= ()=> {}
            const params = {companyCode : "text", programCode : "text",transactionId : "text", membershipNumber : "text",  activityNumber : "text", transactionId: "1234", isProtectedApi : true, resetStates} 
            return store.dispatch(logout(params, "id"))
        })
    })

    it('Should invoke the logout method with success response', ()=>{
        moxios.stubRequest(_URL_TRANSACTION_LOGOUT, {
            status: 200,
            responseText: LOGOUT_PAYMENT_RESPONSE
        })
        return ReactTestUtils.act(() => {
            const resetStates= ()=> {}
            const params = {companyCode : "text", programCode : "text",transactionId : "text", membershipNumber : "text",  activityNumber : "text", transactionId: "1234", isProtectedApi : true, resetStates} 
            return store.dispatch(logout(params, "id"))
        })
    })

    it('Should match the response messgae', () => {
        setTransferMilesMessage('Error occured! ', "danger")
    })

})


describe('Should load the Transfermiles component successfully without prefetching the configurations', () => {
    beforeEach(() => {
        localStorage.setItem(BROWSER_STORAGE_KEY_COMPANY_CODE, 'IBS')
        localStorage.setItem(BROWSER_STORAGE_KEY_PROGRAM_CODE, 'PRG14')
        localStorage.setItem(BROWSER_STORAGE_KEY_MEMBERSHIP_NO, 'IM0008010415')
        store = undefined
        store = testStore({})
        moxios.install(axiosInstance);
    });

    afterEach(() => {
        moxios.uninstall(axiosInstance);
    });

    it('Should render the index.jsx', () => {
        const newUrl = 'transaction?payment=success&&tid=1234';
        Object.defineProperty(window, 'location', {
            writable: true,
            value: {
                hash: newUrl
            }
        });
        setUpTransferMiles({}, false)
        updateComponents()
        mockServiceResponse(DEFAULT_RESPONSE, 200, {})
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_DEFAULT))
                .then(() => {
                    updateComponents()
                    let newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_DEFAULT]).toBe(DEFAULT_RESPONSE.object);
                    mockServiceResponse(CONFIG_RESPONSE, 200, {})
                    return ReactTestUtils.act(() => {
                        return store.dispatch(fetchConfiguration(CONFIG_SECTION_TRANSFERPOINT))
                            .then(() => {
                                newState = store.getState();
                                expect(newState.configurationReducer[CONFIG_SECTION_TRANSFERPOINT]).toBe(CONFIG_RESPONSE.object);

                                updateComponents()
                                const transferMilesComponent = findByTestAttr(component, 'transferMilesComponent');
                                expect(transferMilesComponent.length).toBe(1);

                                let li_charity = findByTestAttr(component, 'li_charity');
                                expect(li_charity.length).toBe(1);
                                li_charity.simulate('click')

                                li_charity = findByTestAttr(component, 'li_general');
                                expect(li_charity.length).toBe(1);
                                li_charity.simulate('click')
                                updateComponents()
                                const searchDropDownType = findByTestAttr(component, 'searchDropDownType');
                                expect(searchDropDownType.length).toBe(1);
                                searchDropDownType.simulate('change', { target: { value: "Email" } })

                                const searchMembershipNumber = findByTestAttr(component, 'searchMembershipNumber');
                                expect(searchMembershipNumber.length).toBe(1);
                                searchMembershipNumber.simulate('change', { target: { value: "test@email.com" } })

                                const searchMemberBtn = findByTestAttr(component, 'searchMemberBtn');
                                expect(searchMemberBtn.length).toBe(1);

                                moxios.stubRequest(_URL_SEARCH_MEMBER, {
                                    status: 500,
                                    responseText: SEARCH_MEMBER_ERROR_RESPONSE
                                })
                                searchMemberBtn.simulate('click')

                                li_charity = findByTestAttr(component, 'li_family');
                                expect(li_charity.length).toBe(1);
                                li_charity.simulate('click')
                            })
                    })
                })
        })
    })

})

const resetStates = ()=>{}
const MASTER_DATA_CHARITY_RESPONSE = {"statuscode":"200","statusMessage":"SUCCESS","object":{"companyCode":"IBS","entityCode":"ONETIM","masterRecordList":[{"FieldCode":"gulfair.charity.members","SequenceNumber":"0","FieldValue":"IM0008011007","FieldDescription":"Charity Organisation1"}]}}
const FAMILY_MEMBERS_RESPONSE = {"statuscode":"200","statusMessage":"SUCCESS","object":[{"membershipNumber":"IM0008010484","title":"MR","givenName":"Abin","secondName":null,"familyName":"William","displayName":"Mr William Abin","relationship":"O","dateOfBirth":"15-Sep-1972","emailAddress":"abinwilliam_1@hotmail.com","nomineeStatus":"Active","tierCode":"ELT","tierName":"Elite","expiryDetails":[{"pointType":"TIER","points":900.0,"expiryDate":"14-Dec-2021"},{"pointType":"LP","points":6000.0,"expiryDate":"15-Jan-2023"},{"pointType":"LP","points":1000.0,"expiryDate":"15-Mar-2023"},{"pointType":"LP","points":1000.0,"expiryDate":"16-Mar-2023"},{"pointType":"LP","points":1000.0,"expiryDate":"22-Mar-2023"},{"pointType":"LP","points":1000.0,"expiryDate":"25-Mar-2023"},{"pointType":"LP","points":2000.0,"expiryDate":"15-Apr-2023"},{"pointType":"LP","points":1000.0,"expiryDate":"23-Apr-2023"},{"pointType":"BASE","points":1000.0,"expiryDate":"25-Apr-2023"},{"pointType":"LP","points":3000.0,"expiryDate":"28-Apr-2023"},{"pointType":"LP","points":1000.0,"expiryDate":"29-Apr-2023"},{"pointType":"LP","points":3000.0,"expiryDate":"04-May-2023"},{"pointType":"LP","points":2002.0,"expiryDate":"10-Dec-2023"},{"pointType":"BONUS","points":50.0,"expiryDate":"11-Dec-2023"},{"pointType":"LP","points":1000.0,"expiryDate":"11-Dec-2023"},{"pointType":"LP","points":3000.0,"expiryDate":"15-Jan-2024"},{"pointType":"LP","points":1000.0,"expiryDate":"27-Jan-2024"},{"pointType":"LP","points":14000.0,"expiryDate":"24-Feb-2024"},{"pointType":"LP","points":12000.0,"expiryDate":"14-Mar-2024"},{"pointType":"LP","points":1000.0,"expiryDate":"25-Mar-2024"},{"pointType":"LP","points":1000.0,"expiryDate":"21-Apr-2024"},{"pointType":"BASE","points":370.0,"expiryDate":"11-Dec-2024"},{"pointType":"BASE","points":3000.0,"expiryDate":"14-Dec-2024"},{"pointType":"BASE","points":1500.0,"expiryDate":"05-Apr-2025"}],"pointDetails":[{"pointType":"BASE","pointTypeGroup":"Airpoints Dollars","totalAccuredpoints":6000.0,"totalRedeemedpoints":130.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":5870.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"BONUSAPD","pointTypeGroup":"Airpoints Dollars","totalAccuredpoints":100.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":100.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"LP","pointTypeGroup":"Loyalty Points","totalAccuredpoints":76000.0,"totalRedeemedpoints":20998.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":55002.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"BONUS","pointTypeGroup":"Loyalty Points","totalAccuredpoints":50.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":50.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"DPTPNT","pointTypeGroup":"Loyalty Points","totalAccuredpoints":3500.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"SECLSTYER","pointTypeGroup":"Loyalty Points","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"THRLSTYER","pointTypeGroup":"Loyalty Points","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"TIER","pointTypeGroup":"Status Points","totalAccuredpoints":22300.0,"totalRedeemedpoints":21400.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":900.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"TIERCC","pointTypeGroup":"Status Points","totalAccuredpoints":500.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":500.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"FS","pointTypeGroup":"Total Flights","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"FC","pointTypeGroup":"Total Flights","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"REVENUE","pointTypeGroup":"Revenue (NZD)","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"BC","pointTypeGroup":"Benefits","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"KC","pointTypeGroup":"Benefits","totalAccuredpoints":2.0,"totalRedeemedpoints":2.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"WIFI","pointTypeGroup":"Benefits","totalAccuredpoints":10.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":10.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"CV","pointTypeGroup":"Benefits","totalAccuredpoints":2.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":2.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"DF","pointTypeGroup":"Benefits","totalAccuredpoints":5.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":5.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"MV","pointTypeGroup":"Benefits","totalAccuredpoints":12.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":12.0,"bonusDetails":[],"creditLimit":0.0}],"activeNominee":true}]}
const FAMILY_MEMBERS_EMPTY_RESPONSE = {"statuscode":"200","statusMessage":"SUCCESS","object":[]}
const SEARCH_MEMBER_RESPONSE = {"statuscode":"200","object":{"firstName":"Abin","surname":"William","secondName":"","membershipStatus":"Active","accountStatus":"Active","tierCode":"ELT","tierName":"Elite","mobileISDCode":"","mobileAreaCode":"","mobileNumber":"","dateOfBirth":"15-Sep-1972","emailAddress":"abinwilliam_1@hotmail.com","membershipNumber":"IM0008010484"}}
const SEARCH_MEMBER_ERROR_RESPONSE = {"statuscode":"500","statusMessage":"FAILURE","error":{"code":"500","type":"INTERNAL_SERVER_ERROR","message":"Search member failed","errorDetails":[{"message":"Member does not exist"}]}}
const ACCOUNT_SUMMARY_RESPONSE = {"statuscode":"200","statusMessage":"SUCCESS","object":{"title":"Mr","givenName":"David","familyName":"Beckham","membershipType":"Individual","membershipStatus":"Active","membershipStatusCode":"A","accountStatus":"Active","accountStatusCode":"A","suspended":false,"tierCode":"STD","tierName":"Standard","tierFromDate":"29-Apr-2021","tierToDate":"","prospectTier":"","companyName":"","expiryDate":null,"lastActivityDate":"29-Apr-2021","activityType":"Member Enrolment Activity","expiryDetails":[],"pointDetails":[{"pointType":"BASE","pointTypeGroup":"Airpoints Dollars","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"BONUSAPD","pointTypeGroup":"Airpoints Dollars","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"LP","pointTypeGroup":"Loyalty Points","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"BONUS","pointTypeGroup":"Loyalty Points","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"DPTPNT","pointTypeGroup":"Loyalty Points","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"SECLSTYER","pointTypeGroup":"Loyalty Points","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"THRLSTYER","pointTypeGroup":"Loyalty Points","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"TIER","pointTypeGroup":"Status Points","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"TIERCC","pointTypeGroup":"Status Points","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"FS","pointTypeGroup":"Total Flights","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"FC","pointTypeGroup":"Total Flights","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"REVENUE","pointTypeGroup":"Revenue (NZD)","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"BC","pointTypeGroup":"Benefits","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"KC","pointTypeGroup":"Benefits","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"WIFI","pointTypeGroup":"Benefits","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"CV","pointTypeGroup":"Benefits","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"DF","pointTypeGroup":"Benefits","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"MV","pointTypeGroup":"Benefits","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0}],"tierOptions":[{"tierName":"Silver","tierCode":"SIL","type":"upgrade","options":[{"operator":"and","optionDetails":[{"current":"0","next":"450","diff":"450","types":["TIER","TIERCC"],"name":"Total Status Points","uiType":"point","result":false,"preferred":true},{"current":"0","next":"225","diff":"225","types":["TIER"],"name":"Status Points","uiType":"point","result":false,"preferred":true}],"result":false}],"message":"You are 450 Total Status Points and 225 Status Points away from the next tier"}]}}
const CONFIG_RESPONSE = {"statuscode":"200","statusMessage":"SUCCESS","object":{"section":"transferpoint","companyCode":"IBS","programCode":"PRG14","isProtectedApi":true,"ui":{"adhocAttributes":[{"attributeCode":"MSD","attributeValue":""}],"message":{"family":true,"general":true,"charity":true}},"transactionTypes":[{"type":"family","status":"enable","description":"Transfer to any family member","isPacket":true,"pointDetails":[{"pointType":"LP","status":"enable","pointTypeName":"Loyalty Points","isBonus":false,"isPaymentRequired":true,"packetSize":500,"minimumPacket":1,"maximumPacket":10,"transactionFee":{"amount":0.01,"perUnit":true,"vat":0,"serviceCharge":10},"transferPeriod":"12","transferPeriodUnit":"month","transferPeriodMaxPoints":20000}]},{"type":"general","status":"enable","description":"Transfer to any loyalty member","isPacket":true,"pointDetails":[{"pointType":"LP","status":"enable","pointTypeName":"Loyalty Points","isBonus":false,"isPaymentRequired":true,"packetSize":500,"minimumPacket":1,"maximumPacket":10,"transactionFee":{"amount":0.01,"perUnit":true,"vat":0,"serviceCharge":10},"transferPeriod":"12","transferPeriodUnit":"month","transferPeriodMaxPoints":20000}]},{"type":"charity","status":"enable","description":"Transfer to any charity member","isPacket":false,"pointDetails":[{"pointType":"LP","status":"enable","pointTypeName":"Loyalty Points","isBonus":false,"isPaymentRequired":true,"packetSize":500,"minimumPacket":1,"maximumPacket":10,"transactionFee":{"amount":0,"perUnit":true,"vat":0,"serviceCharge":0},"transferPeriod":"12","transferPeriodUnit":"month","transferPeriodMaxPoints":20000}]}]}}
const DEFAULT_RESPONSE = {"statuscode":"200","statusMessage":"SUCCESS","object":{"section":"default","companyCode":"IBS","requestTimedOutInMs":20000,"data":{"membershipTypes":[{"key":"I","value":"Individual"},{"key":"C","value":"Corporate"}],"nomineePermissionFullAccess":[{"key":"fullAccessPrivilege","value":"Full Access"}],"nomineePermissionLimitedAccess":[{"key":"limitedAccessPrivilege","value":"Limited Access"}],"accountStatusCodes":[{"key":"U","value":"Unregistered"},{"key":"A","value":"Active"},{"key":"I","value":"Inactive"},{"key":"S","value":"Suspended"},{"key":"D","value":"Deleted"},{"key":"C","value":"Closed"},{"key":"E","value":"Expired"},{"key":"M","value":"Merged"},{"key":"P","value":"Provisional"},{"key":"R","value":"Payment Due"},{"key":"V","value":"Inactive-Unregistered"},{"key":"H","value":"On Hold"},{"key":"N","value":"Pending Activation"},{"key":"B","value":"Blocked"}],"addressTypes":[{"key":"H","value":"Home"},{"key":"B","value":"Business"}],"emailTypes":[{"key":"H","value":"Home"},{"key":"B","value":"Business"}],"phoneTypes":[{"key":"HP","value":"Home"},{"key":"BP","value":"Business"}],"gender":[{"key":"U","value":"Unknown"},{"key":"M","value":"Male"},{"key":"F","value":"Female"}],"maritalStatus":[{"key":"D","value":"Divorced"},{"key":"M","value":"Married"},{"key":"S","value":"Single"},{"key":"W","value":"Widow"}],"industryType":[{"key":"A","value":"Airline Industry"},{"key":"B","value":"Business Administration"},{"key":"C","value":"Cooperate Communication"},{"key":"D","value":"Service Delivery"},{"key":"E","value":"Self Employment"},{"key":"F","value":"Forces"},{"key":"H","value":"Hospitality Industry"},{"key":"I","value":"Information technology"},{"key":"L","value":"Film Industry"},{"key":"M","value":"Medical professional"},{"key":"N","value":"Banking"},{"key":"P","value":"Apparel Industry"},{"key":"R","value":"Marketing"},{"key":"S","value":"Advisory Services"},{"key":"T","value":"Travel And Tourism"},{"key":"U","value":"Education, Academic Services"},{"key":"X","value":"Not Specified"}],"incomeBand":[{"key":"1","value":"Less than 1000 USD"},{"key":"2","value":"1000-2000 USD"},{"key":"3","value":"2001-5000 USD"},{"key":"4","value":"5001-10,000 USD"},{"key":"5","value":"Greater than 10,000 USD"}],"operationFlags":[{"key":"I","value":"Insert"},{"key":"U","value":"Update"},{"key":"D","value":"Delete"}],"membershipStatusCodes":[{"key":"A","value":"Active"},{"key":"B","value":"BlackListed"},{"key":"C","value":"Closed"},{"key":"D","value":"Deceased"},{"key":"S","value":"Suspended"},{"key":"I","value":"Inactive"},{"key":"P","value":"Protected"}],"noOfEmployees":[{"key":"1","value":"Less than 100","upperLimit":"99","lowerLimit":"1"},{"key":"2","value":"100 - 500","upperLimit":"499","lowerLimit":"101"},{"key":"3","value":"500 - 1000","upperLimit":"999","lowerLimit":"501"},{"key":"4","value":"Greater Than 1000","upperLimit":"2000","lowerLimit":"1000"},{"key":"X","value":"Not Specified","upperLimit":"0","lowerLimit":"0"}],"masterEntityData":[{"key":"airport","value":"ARPMST"},{"key":"country","value":"CNTMST"},{"key":"airlines","value":"ARLMST"},{"key":"airline_booking_class","value":"ARLBKGCLSMST"},{"key":"title","value":"TLEMST"},{"key":"mileage","value":"MILMST"},{"key":"language","value":"LNGMST"},{"key":"state","value":"STTMST"},{"key":"city","value":"CTYMST"},{"key":"charity","value":"ONETIM","filterFieldDetail":[{"attributeCode":"fieldCode","attributeValue":"gulfair.charity.members"}]},{"key":"partners","value":"ONETIM","filterFieldDetail":[{"attributeCode":"fieldCode","attributeValue":"gulfair.preaffiliated.partners"}]}],"iTravelIntegration":{"x_auth_channel":"B2CChannel@ATVL","x_auth_token":"03e83cb1028f3281f8cef470b420f33f4f6916f5","customerProfileId":"3000"},"mfa":{"resendTimeout":"30000","maxAttempts":"3"}},"defaults":{"passwordPattern":"((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&.,{}()?-_=+<>*!^/]).{8,20})","emailPattern":"\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$"},"config":{"login":{"dynamicAttributes":{"permissionDetails":{"attributeGroupName":"Nominee Permission","attributeCode":"","attributeName":""},"programLinkedTo":{"attributeGroupName":"Program Linked Details","attributeCode":"91","attributeName":"Programs linked to"},"programEntitledTo":{"attributeGroupName":"Program Details","attributeCode":"73","attributeName":"Program entitled to"}}},"resetPwd":{"programEntitledToCode":"73","split":"|","corporateProgramCodeIndex":1,"corporateMembershipNumberIndex":2,"previousNomineeStatus":"P","updateNomineeStatus":"A"}},"programs":[{"plugins":{"isActive":true,"cookie":{"domain":"localhost","listenerKeys":[{"key":"ps-token","type":"login"}]},"storage":{"domain":"localhost"},"urls":{"apiUrl":{"login":"http://localhost:8080/#/member/login","logout":"http://192.168.45.200:8084/api/authservice/users/logout","userDetails":"http://192.168.45.200:8084/api/authservice/social-login/user/me","partners":"http://192.168.45.200:8444/api/shopping-service/anz/partners"},"cssUrl":{"default":""},"iconUrl":{"searchPage":"","searchPage1":"http://192.168.45.200:8443/images/icon_notification.svg"}},"i18":{"en":{"logout":"Logout","login":"LOG IN TO EARN","start_shopping":"Start Shopping","started_shopping":"Started Shopping","featured":"Featured Partners","hi":"Hi, ","faq":"FAQ","shopping_site":"Shopping Mall","google_message":"Earn {POINT1} points per {SPENT} {CURRENCY} spent via Shopping Mall","partner_website_message":"Earn <strong>{POINT1} points</strong> for every <strong>{SPENT} {CURRENCY}</strong> you spend via {NAME}","default_message":"We will let you know of your next points earning opportunity"},"ko":{"logout":"로그 아웃","login":"적립하려면 로그인","start_shopping":"쇼핑 시작","started_shopping":"쇼핑 시작","featured":"특집","hi":"안녕하세요,","faq":"자주하는 질문","shopping_site":"에어 포인트 몰","google_message":"Airpoints Mall을 통해 지출 한 {SPENT} {CURRENCY} 당 {POINT1} 에어 포인트 달러 적립","partner_website_message":"{NAME}을 (를) 통해 지출하는 모든 <strong> {CURRENCY} {SPENT} </strong>에 대해 <strong> {POINT1} Airpoints Dollar ™ </strong>를 적립하세요.","default_message":"다음 Airpoint 적립 기회를 알려 드리겠습니다."}}},"programCode":"PRG14","programName":"Airpoints","programType":"individual","isDefault":true,"isActive":true,"privileges":[{"name":"Default","value":"ALL","api":[{"url":"/**/*","method":"*"}],"ui":[{"page":"/**/*","tab":"*","permission":["*"]}]}],"defaults":{"currency":"NZD","posCity":"AUK","posCountry":"NZ","pinRegex":"^\\d{4}$","passwordRegex":"^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$","dateFormat":"yyyy-MM-dd","dateTimeFormat":"yyyy-MM-dd HH:mm","image":{"maleAvatar":"","femaleAvatar":"","otherAvatar":""},"roundCurrencyToDecimalPrecision":2,"skipPinChangeReminder":true},"apiConfigLoader":{"master":true,"preference":true,"buypoint":true,"transferpoint":true,"mileagecalculator":true,"claimmiles":true,"customquery":true,"activitydetails":true,"enrol":true,"family":true,"profile":true,"servicerequest":true,"security":true,"nominee":false,"traveller":false,"accountsummary":true},"data":{"pointTypes":[{"pointType":"TIER","pointName":"Status Point Air","className":"fa fa-bars"},{"pointType":"TIERCC","pointName":"Status Point Credit Card","className":"fa fa-credit-card"},{"pointType":"LP","pointName":"Loyalty Points","className":"fa fa-database","redeemed":true},{"pointType":"BASE","pointName":"Airpoints Dollar","className":"fa fa-usd","redeemed":true},{"pointType":"FLTCNT","pointName":"Status Booster Count","className":""},{"pointType":"FS","pointName":"NZ Flight","className":"fa fa-plane"},{"pointType":"FC","pointName":"Partner Flight","className":"fa fa-plane"},{"pointType":"KC","pointName":"Lounge Coupon","className":"fa fa-ticket"},{"pointType":"CV","pointName":"Recognition Upgrade","className":"fa fa-trophy"},{"pointType":"REVENUE","pointName":"Revenue","className":""},{"pointType":"BONUS","pointName":"Bonus","className":"fa fa-star","redeemed":true},{"pointType":"BC","pointName":"Banked Year","className":"fa fa-level-up"},{"pointType":"DF","pointName":"Duty Free Discount","className":"fa fa-shopping-bag"},{"pointType":"MV","pointName":"Meal Vouchers","className":"fa fa-cutlery"},{"pointType":"WIFI","pointName":"WIFI VIP","className":"fa fa-wifi"}],"partners":[{"value":"NZ","name":"Air New Zealand"},{"value":"KE","name":"Korean Air"},{"value":"EY","name":"Etihad Airways"},{"value":"EK","name":"Emirates"},{"value":"QF","name":"Qantas"},{"value":"CX","name":"Cathay Pacific"}],"cabinClasses":{"NZ":[{"cabinClassCode":"E","cabinClassName":"Economy"},{"cabinClassCode":"P","cabinClassName":"Premium Economy"},{"cabinClassCode":"B","cabinClassName":"Business"}]},"cabinClassBookingClassMapping":{"NZ":[{"cabinClass":"E","bookingClass":"G"},{"cabinClass":"B","bookingClass":"B"},{"cabinClass":"P","bookingClass":"Q"}]},"relationshipCodes":[{"key":"F","value":"Father"},{"key":"M","value":"Mother"},{"key":"S","value":"Spouse"},{"key":"B","value":"Brother"},{"key":"C","value":"Children"},{"key":"E","value":"Step children"},{"key":"G","value":"Grandfather"},{"key":"N","value":"Grandmother"},{"key":"P","value":"Step parents"},{"key":"I","value":"Parents in law"},{"key":"T","value":"Sister"},{"key":"O","value":"Others"}],"nomineeAccountGroupTypes":[{"key":"F","value":"Family"}],"cmsDetails":{"header":{"filter":{"query":"ibs_prg14_header"},"metaData":{"type":"json"}},"footer":{"filter":{"query":"ibs_prg14_footer"},"metaData":{"type":"json"}},"partners":{"filter":{"partner_status":"Active"},"resource":{"tier":"ibs_prg14_retailers"}},"offers":{"filter":{"offer_status":"Active"},"resource":{"tier":"ibs_prg14_offers"}},"viewDetailPartner":{"filter":{"id":""},"metaData":{"type":"html"}},"viewDetailOffer":{"filter":{"id":""},"metaData":{"type":"html"}}}}},{"programCode":"PRG15","programName":"CORPORATE PROGRAM","programType":"corporate","isDefault":false,"isActive":true,"privileges":[{"name":"Manage Profile","attrCode":"85","value":"R","api":[{"url":"/v*/member/profile/retrieve","method":"POST"},{"url":"/v*/member/qr-code/retrieve","method":"POST"}],"ui":[{"url":"/corporate/profile","tab":[{"name":"update-customer-profile","permission":["R","F"]},{"name":"update-company-profile","permission":["R"]}],"permission":["R"]}]},{"name":"Manage Profile","attrCode":"85","value":"F","api":[{"url":"/v*/member/profile/retrieve","method":"POST"},{"url":"/v*/member/profile/update","method":"POST"},{"url":"/v*/member/qr-code/retrieve","method":"POST"}],"ui":[{"url":"/corporate/profile","tab":[{"name":"update-customer-profile","permission":["R","F"]},{"name":"update-company-profile","permission":["R","F"]}],"permission":["F","R"]}]},{"name":"View Summary","attrCode":"86","value":"F","api":[{"url":"/v*/member/account-summary","method":"POST"},{"url":"/v*/summary-service/notification","method":"POST"}],"ui":[]},{"name":"Manage Account User","attrCode":"87","value":"R","api":[{"url":"/v*/member/nominee/retrieve","method":"POST"},{"url":"/v*/member/nominee/retrieve-user","method":"POST"},{"url":"/v*/member/nominee/update/self","method":"POST"}],"ui":[{"url":"/corporate/manageusers","tab":[{"name":"traveller","permission":["R"]},{"name":"nominee","permission":["R"]}],"permission":["R"]}]},{"name":"Manage Account User","attrCode":"87","value":"F","api":[{"url":"/v*/member/nominee/retrieve","method":"POST"},{"url":"/v*/member/nominee/add-reset-pwd","method":"POST"},{"url":"/v*/member/nominee/privilege","method":"POST"},{"url":"/v*/member/nominee/update","method":"POST"},{"url":"/v*/member/nominee/retrieve-user","method":"POST"},{"url":"/v*/member/nominee/delete","method":"POST"},{"url":"/v*/member/nominee/update/self","method":"POST"}],"ui":[{"url":"/corporate/manageusers","tab":[{"name":"traveller","permission":["R","F"]},{"name":"nominee","permission":["R","F"]}],"permission":["R","F"]}]},{"name":"Manage Traveler","attrCode":"88","value":"R","api":[{"url":"/v*/member/traveller/retrieve","method":"POST"}],"ui":[]},{"name":"Manage Traveler","attrCode":"88","value":"F","api":[{"url":"/v*/member/traveller/retrieve","method":"POST"},{"url":"/v*/member/traveller/add","method":"POST"},{"url":"/v*/member/traveller/update","method":"POST"},{"url":"/v*/member/traveller/delete","method":"POST"}],"ui":[]},{"name":"Manage Claims","attrCode":"89","value":"R","api":[{"url":"/v*/point/retro-claim/retrieve","method":"POST"}],"ui":[{"url":"/corporate/claimsummary","tab":[],"permission":["R"]},{"url":"/corporate/claimsubmit","tab":[],"permission":["X"]}]},{"name":"Manage Claims","attrCode":"89","value":"F","api":[{"url":"/v*/point/retro-claim/retrieve","method":"POST"},{"url":"/v*/point/retro-claim","method":"POST"}],"ui":[{"url":"/corporate/claimsummary","tab":[],"permission":["R","F"]},{"url":"/corporate/claimsubmit","tab":[],"permission":["R","F"]}]},{"name":"View Activities","attrCode":"90","value":"F","api":[{"url":"/v*/activity-detail/retrieve","method":"POST"}],"ui":[{"url":"/corporate/myactivity","tab":[],"permission":["F"]}]},{"name":"View Activities","attrCode":"90","value":"R","api":[{"url":"/v*/activity-detail/retrieve","method":"POST"}],"ui":[{"url":"/corporate/myactivity","tab":[],"permission":["X"]}]},{"name":"Default","value":"ALL","api":[{"url":"/v*/member/nominee/account-link","method":"POST"}]}],"defaults":{"currency":"NZD","posCity":"AUK","posCountry":"NZ","pinRegex":"^\\d{4}$","passwordRegex":"^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$","dateFormat":"yyyy-MM-dd","dateTimeFormat":"yyyy-MM-dd HH:mm","roundCurrencyToDecimalPrecision":2,"skipPinChangeReminder":true},"apiConfigLoader":{"master":true,"preference":true,"buypoint":false,"transferpoint":false,"mileagecalculator":false,"claimmiles":false,"customquery":false,"activitydetails":true,"enrol":true,"family":false,"profile":true,"servicerequest":false,"security":true,"nominee":true,"traveller":true,"accountsummary":true},"data":{"pointTypes":[{"pointType":"BASE","pointName":"Airpoints Dollars","className":"fa fa-usd","redeemed":true},{"pointType":"TP","pointName":"Tier Points","className":"fa fa-database","redeemed":true},{"pointType":"REVENUE","pointName":"Ticket Spend","className":"fa fa-usd"},{"pointType":"FC","pointName":"Flight Count","className":"fa fa-plane"},{"pointType":"BUSCLSUPG","pointName":"OW Business Class Upgrade","className":""},{"pointType":"EXBAG","pointName":"Excess Baggage","className":""},{"pointType":"ROBCUP","pointName":"RT Business Class Upgrade","className":""},{"pointType":"ROCT","pointName":"RT Complimentary Flight","className":""}],"partners":[{"value":"NZ","name":"Air New Zealand"},{"value":"KE","name":"Korean Air"},{"value":"EK","name":"Emirates"},{"value":"CX","name":"Cathay Pacific"}],"cabinClasses":{"NZ":[{"cabinClassCode":"E","cabinClassName":"Economy"},{"cabinClassCode":"B","cabinClassName":"Business"},{"cabinClassCode":"P","cabinClassName":"Premium Economy"}]},"cabinClassBookingClassMapping":{"NZ":[{"cabinClass":"E","bookingClass":"B"},{"cabinClass":"B","bookingClass":"A"},{"cabinClass":"P","bookingClass":"U"}]},"relationshipCodes":[{"key":"A","value":"Administrator"},{"key":"O","value":"Others"},{"key":"M","value":"Manager"},{"key":"B","value":"Accountant"},{"key":"C","value":"Customer Support"},{"key":"D","value":"Marketing Manager"}],"nomineeAccountGroupTypes":[{"key":"U","value":"Account User"},{"key":"H","value":"Account Holder"},{"key":"T","value":"Traveller"}],"cmsDetails":{"header":{"filter":{"query":"ibs_prg15_header"},"metaData":{"type":"json"}},"footer":{"filter":{"query":"ibs_prg15_footer"},"metaData":{"type":"json"}},"partners":{"filter":{"partner_status":"Active"},"resource":{"tier":"ibs_prg15_retailers"}},"offers":{"filter":{"offer_status":"Active"},"resource":{"tier":"ibs_prg15_offers"}},"viewDetailPartner":{"filter":{"id":""},"metaData":{"type":"html"}},"viewDetailOffer":{"filter":{"id":""},"metaData":{"type":"html"}}}}}]}}
const MAKE_PAYMENT_RESPONSE = {"statuscode":"200","statusMessage":"SUCCESS","object":{"companyCode":"IBS","programCode":"PRG14","membershipNumber":"IM0008010804","transactionId":"","tierCode":null,"memberActivityStatus":{"accountStatus":null,"activityNumber":"ACT8070","activityType":"TP","activityName":"TRANSFER_POINTS_SOURCE","activityStatus":"D","activityCode":"TP"},"pointDetails":[],"redirectURL":"sessionKey=testSessionKey"}}
const MAKE_PAYMENT_ERROR_RESPONSE = {"statuscode":"400","statusMessage":"FAILURE","error":{"code":"400","type":"BAD_REQUEST","message":"Point transfer failed","errorDetails":[{"message":"Number of points 1,234 is not a multiple of packet size 500"}]}}
const ACCEPT_PAYMENT_ERROR_RESPONSE = {"statuscode":"400","statusMessage":"FAILURE","error":{"code":"400","type":"BAD_REQUEST","message":"Point transfer failed","errorDetails":[{"message":"ACCEPT_PAYMENT_ERROR_RESPONSE"}]}}
const LOGOUT_PAYMENT_ERROR_RESPONSE = {"statuscode":"400","statusMessage":"FAILURE","error":{"code":"400","type":"BAD_REQUEST","message":"Point transfer failed","errorDetails":[{"message":"LOGOUT_PAYMENT_ERROR_RESPONSE"}]}}
const LOGOUT_PAYMENT_RESPONSE =  {"statuscode":"200","statusMessage":"SUCCESS","object":[]}
const POSTLOGOUT_PAYMENT__ERROR_RESPONSE = {"statuscode":"500","statusMessage":"FAILURE","error":{"code":"400","type":"MFA_REQUIRED","message":"Point transfer failed","errorDetails":[{"message":"POSTLOGOUT_PAYMENT__ERROR_RESPONSE"}]}}
const MAKE_PAYMENT_MFA_ERROR_RESPONSE = {"statuscode":"500","statusMessage":"FAILURE","error":{"code":"400","type":"MFA_REQUIRED","message":"Point transfer failed","errorDetails":[{"message":"MFA_REQUIRED"}]}}
const PAYMENT_RESPONSE = {"statuscode":"200","statusMessage":"SUCCESS","object":{"companyCode":"IBS","programCode":"PRG14","membershipNumber":"IM0008010804","transactionId":"","acceptPaymentStatus":true,"activityNumber":"ACT8070"}}
const PAYMENT_REQUEST_WITHAPI = { companyCode: "", programCode: "", membershipNumber: "", pin: "", isProtectedApi: true, resetStates }
const PAYMENT_REQUEST_WITHAPI_PAYMENT = { companyCode: "", programCode: "", membershipNumber: "", pin: "", isProtectedApi: true, resetStates, isPaymentRequired: true }
const PAYMENT_REQUEST_WITHOUTAPI = { companyCode: "", programCode: "", membershipNumber: "", pin: "", isProtectedApi: false, resetStates }
const AUTHENTICATE__RESPONSE = {"statuscode":"200","statusMessage":"SUCCESS","object":{"transactionId": "testId"}}