import React from 'react';
import { connect } from 'react-redux';
import { hideTransferMilesMessage,
     clearSearchMember,
     searchMember 
} from './actions';
import { withTranslation } from 'react-i18next';
import parse from 'html-react-parser';
import {
    numberWithCommas,
    toTitleCase,
    getTransactionFee,
    withSuspense,
    getPointsArray,
    getPrecision,
    getTransferPointsList,
    defaultSearchDropDownTemplate
} from '../../common/utils';
import {
    ID_SEARCH_TRANSFER,
    ID_TRANSFER_MILES,
    ID_SHOW_SECOND_STEP_BUTTION,
    ID_CANCEL_TRANSFER_MILES,
    EMAIL
} from './Constants'
import {
    resetError,
    setError
} from '../../common/middleware/redux/commonAction'
import { NAVIGATE_TRANSFER } from '../../common/utils/urlConstants';
import {
    getItemFromBrowserStorage,
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_CURRENCY_CODE
} from '../../common/utils/storage.utils';
import SearchDropdown from '../../common/components/fieldbank/SearchDropdown';
import Button from '../../common/components/fieldbank/Button';
import MfaContext from '../../../context/MfaContext';
import FilterDropDown from '../../common/components/fieldbank/FilterDropDown';

const initialData = {
    type: EMAIL,
    pointsToTransfer: undefined,
    acceptTerms: false,
    companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
    programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
    membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)
}

class TransferToNewRecipient extends React.Component {

    constructor(props) {
        super(props);
        const data = JSON.parse(JSON.stringify(initialData))
        this.state = {
            data,
            step: 1
        }
        this.cancel = this.cancel.bind(this)
        this.handleChange = this.handleChange.bind(this)
        this.showStepTwo = this.showStepTwo.bind(this)
        this.getName = this.getName.bind(this)
        this.checkUser = this.checkUser.bind(this)
    }

    /**
     * This function is to update data in state
     * 
     * @author Alan Kuriakose
     * @param {string} key - key  of element
     * @param {any} value - value of element
     */
    handleChange(key, value) {
        this.props.updateState("messageContent", { messages: [], type: ""})
        this.props.resetError()
        window.history.pushState({}, null, `#${NAVIGATE_TRANSFER}`)
        const { data } = this.state;
        data[key] = value;
        this.setState({
            data
        })
        const { message, hideMessage } = this.props;
        if (message.showMessage) {
            hideMessage();
        }
    }

    getName() {
        const { member } = this.props;
        const memberDetils = member.memberDetails;
        if (!memberDetils) return '';
        return `${memberDetils.firstName} ${memberDetils.surname}`;
    }

    checkUser() {
        this.props.resetError()
        const { data } = this.state;
        const { currentUserData, t } = this.props;
        const { userId, type, membershipNumber } = data;
        if (!userId) {
            return;
        }
        if(currentUserData && 
            currentUserData.email &&
            currentUserData.email == userId || 
            userId == membershipNumber ){
            //Error - Sender and Recipient cannot have the same membership number
            this.props.setError ([t("transfer.general.sameMemberError")]) 
            return
        }
        const requestBody = {
            object: {
                companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                absoluteIndex: '1',
                pageSize: '1'
            }
        }
        if (type == EMAIL) {
            requestBody.object.emailAddress = userId
        } else {
            requestBody.object.membershipNumber = userId;
        }
        this.props.searchMember(requestBody, ID_SEARCH_TRANSFER)
    }

    showStepTwo() {
        this.setState({
            step: 2
        }, ()=>{
            this.props.hideMessage();
        })
    }

    cancel() {
        const data = JSON.parse(JSON.stringify(initialData));
        this.props.clearSearchMember();
        this.props.resetError()
        this.setState({
            data,
            step: 1
        })
    }

    render() {
        const { data, step} = this.state;
        const { member, t, pointDetails, getAvailablePoints, isProtectedApi, config, specialMessageStatus } = this.props;
        const pointsAvailable = getAvailablePoints()
        const paymentDisabled = isProtectedApi ? !(data.pin && data.acceptTerms) : !(data.acceptTerms);
        const continueDisabled = !parseInt(data.pointsToTransfer) || !member.memberDetails.firstName;
        const selectedPointDetails = pointDetails[0];
        const withPayment = selectedPointDetails.isPaymentRequired;

        let transferPointsList = [];
        let pointsList = [];
        pointsList = getPointsArray(this.props.pointDetails[0]).filter(point => point <= pointsAvailable);
        transferPointsList = getTransferPointsList(pointsList);

        return (
            <div className="toggle2" data-test="newRecipientTransferComponent">
                {
                    step === 1 &&
                    <div className="step1">
                        <div className="form-row">
                            <div className="col-lg-6 col-md-6">
                                <div className="form-group">
                                    <label htmlFor="SearchByDropDown">{t("transfer.general.search_by")}
                                    <span className="text-warning">*</span>
                                    </label>
                                    <select id="SearchByDropDown" value={data.type} onChange={(e) => {
                                        this.handleChange('type', e.target.value);
                                    }}
                                        data-test="searchDropDownType"
                                    >
                                        <option value={t("transfer.general.email")}>{t("transfer.general.email")}</option>
                                        <option value={t("transfer.general.membership_number")}>{t("transfer.general.membership_number")}</option>
                                    </select>
                                </div>
                            </div>
                            <div className="col-lg-6 col-md-6 d-flex align-items-end">
                                <div className="form-group flex-grow-1">
                                    <label htmlFor="MemberNumberTextBox" className="d-block">{data.type} 
                                    <span className="text-warning">*</span>
                                    </label>
                                    <input
                                        type="text"
                                        placeholder={data.type}
                                        id="MemberNumberTextBox"
                                        value={data.userId || ''}
                                        onChange={(event) => this.handleChange('userId', event.target.value)}
                                        data-test="searchMembershipNumber"
                                    />
                                </div>
                                <div className="ml-2 mb-3">
                                    <button
                                        type="button"
                                        onClick={() => this.checkUser()}
                                        data-test="SearchUserBtn"
                                        className="btn btn-secondary"
                                        data-test="searchMemberBtn"
                                    >{t('transfer.general.check')}</button>
                                </div>
                            </div>

                        </div>
                        <div className="form-row">
                            <div className="col-lg-6 col-md-6">
                                <div className="form-group">
                                    <label htmlFor="recipient_name">{t("transfer.general.recipient_name")}
                                    <span className="text-warning">*</span>
                                    </label>
                                    <input type="text" id="recipient_name" placeholder={t("transfer.general.recipient_name_placeholder")} disabled value={`${member.memberDetails.firstName} ${member.memberDetails.surname}`} />
                                </div>
                            </div>
                            <div className="col-lg-6 col-md-6">
                                <div className="form-group">
                                    {
                                        config && config.isPacket ?
                                        <FilterDropDown
                                            label={t("transfer.general.miles_to_transfer")}
                                            labelDesc={<strong className="float-right">{t("transfer.general.available")} : {numberWithCommas(pointsAvailable)}</strong>}
                                            placeholder={t("transfer.general.miles_to_transfer_placeholder")}
                                            options={transferPointsList}
                                            isRequired={true}
                                            id="OtherPointsToTransferDropdown"
                                            value={data.pointsToTransfer}
                                            onChange={(e) =>
                                                this.handleChange('pointsToTransfer', e)
                                            }
                                            testIdentifier="pointsToTransferFilter"
                                            info=""
                                            enabled={true}
                                        /> :
                                        <SearchDropdown
                                            label={t("transfer.general.miles_to_transfer")}
                                            labelDesc={<strong className="float-right">{t("transfer.general.available")} : {numberWithCommas(pointsAvailable)}</strong>}
                                            placeholder={t("transfer.general.miles_to_transfer_placeholder")}
                                            options={transferPointsList}
                                            isRequired={true}
                                            id="pointsToTransferFreeForm"
                                            value={data.pointsToTransfer}
                                            itemTemplate={(e) => defaultSearchDropDownTemplate(e)}
                                            onChange={(e) =>
                                                this.handleChange('pointsToTransfer', e)
                                            }
                                            testIdentifier="otherPointsToTransferDropdown"
                                            enabled={true}
                                        />
                                    }
                                </div>
                            </div>
                        </div>
                        {
                            specialMessageStatus &&
                            <div className="form-row">
                                <div className="col-lg-12 col-md-12">
                                    <div className="form-group">
                                        <label htmlFor="special_message">{t("transfer.general.special_message")}</label>
                                        <textarea
                                            id="special_message"
                                            placeholder={t("transfer.general.specialMessage_placeHolder")}
                                            rows="3" cols="60"
                                            value={data.specialMessageValue}
                                            onChange={(event) => this.handleChange('specialMessageValue', event.target.value)}
                                            data-test="specialMessage"
                                        >
                                        </textarea>
                                    </div>
                                </div>
                            </div>
                        }
                        <div className="form-row">
                            <div className="col-12 buttonWrap d-flex justify-content-between">
                                {/* <div className="buttonLeftTxt">
                                    <div className="form-check form-check-inline">
                                        <input className="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1" />
                                        <label className="form-check-label" for="inlineCheckbox1">{t("transfer.general.save_recipient")}</label>
                                    </div>
                                </div> */}
                                <div className="buttonLeftTxt">
                                    <div className="form-check form-check-inline">
                                        {/* <input className="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1" />
                                <label className="form-check-label" htmlFor="inlineCheckbox1">Save this Recipient</label> */}
                                    </div>
                                </div>
                                <div>
                                    <Button
                                        className="btn btn-primary"
                                        handleOnClick={() => this.showStepTwo()}
                                        id={ID_SHOW_SECOND_STEP_BUTTION}
                                        enabled={!continueDisabled}
                                        label={t("transfer.general.continue_btn")} 
                                        testIdentifier="continueBtn"/>
                                </div>
                            </div>
                        </div>
                    </div>
                }
                {
                    step === 2 &&
                    <div className="step2">
                        <div className="form-row">
                            <div className="col-10 customeTxt">
                                <p>{parse(t("transfer.general.message_while_transfer_one").replace("{SELECTED_POINTS}", numberWithCommas(data.pointsToTransfer)).replace("{RECIPIENT}", toTitleCase(this.getName())))}
                                    {withPayment &&
                                        <>
                                            {parse(t("transfer.general.message_while_transfer_two").replace("{PAYABLE_AMOUNT}", numberWithCommas(getTransactionFee(selectedPointDetails.transactionFee, data.pointsToTransfer).toFixed(getPrecision(this.props.defaultConfig)))).replace("{CURRENCY_CODE}", getItemFromBrowserStorage(BROWSER_STORAGE_KEY_CURRENCY_CODE)))}
                                        </>
                                    }
                                </p>
                            </div>
                        </div>
                        {
                            isProtectedApi &&
                            <div className="form-row">
                                <div className="col-lg-4 col-md-6">
                                    <div className="form-group">
                                        <label htmlFor="generalMemberPin">{t("transfer.general.enter_pin")}</label>
                                        <input className="" type="password" placeholder={t("transfer.general.enter_pin_placeholder")} id="generalMemberPin"
                                            value={data.pin || ''}
                                            onChange={(event) => {
                                                this.handleChange('pin', event.target.value);
                                            }}
                                            data-test="memberPin"
                                        />
                                    </div>
                                </div>
                                <div className="col-lg-8 col-md-6">
                                </div>
                            </div>}
                        {/* <div className="form-row">
                            <div className="col-12">
                                <h3>{(t("transfer.general.terms_and_condition.title") != "transfer.general.terms_and_condition.title") ? t("transfer.general.terms_and_condition.title") : ""}</h3>
                                <ul className="" type="square">
                                    <li>{(t("transfer.general.terms_and_condition.first_line") != "transfer.general.terms_and_condition.first_line") ? t("transfer.general.terms_and_condition.first_line").replace("{PACKAGE_OF}", selectedPointDetails.packetSize) : ""}</li>
                                    <li>{(t("transfer.general.terms_and_condition.second_line") != "transfer.general.terms_and_condition.second_line") ? t("transfer.general.terms_and_condition.second_line").replace("{PERIOD}", `${selectedPointDetails.transferPeriod} ${selectedPointDetails.transferPeriodUnit}`).replace("{MAX_POINTS}", selectedPointDetails.transferPeriodMaxPoints) : ""}</li>
                                    <li>{(t("transfer.general.terms_and_condition.third_line") != "transfer.general.terms_and_condition.third_line") ? t("transfer.general.terms_and_condition.third_line").replace("{MIN_PACKAGE}", selectedPointDetails.minimumPacket * selectedPointDetails.packetSize).replace("{MAX_PACKAGE}", selectedPointDetails.maximumPacket * selectedPointDetails.packetSize) : ""}</li>
                                    {
                                        selectedPointDetails.isPaymentRequired && selectedPointDetails.transactionFee && selectedPointDetails.transactionFee.amount &&
                                        <li>{
                                            t(selectedPointDetails.transactionFee.perUnit ? "transfer.toFamily.terms_and_condition.fourth_line_1" : "transfer.toFamily.terms_and_condition.fourth_line_2").replace("{PAYABLE_AMOUNT}", selectedPointDetails.transactionFee.amount.toString()).replace("{CURRENCY_CODE}", getItemFromBrowserStorage(BROWSER_STORAGE_KEY_CURRENCY_CODE))
                                        }</li>
                                    }
                                </ul>
                            </div>
                        </div> */}
                        <div className="form-row">
                            <div className="col-12 buttonWrap">
                                <div className="form-row">
                                    <div className="col-lg-6 col-md-12 buttonLeftTxt">
                                        <div className="form-check form-check-inline">
                                            <input className="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1"
                                                checked={data.acceptTerms}
                                                onChange={(event) => {
                                                    this.handleChange('acceptTerms', event.target.checked);
                                                }}
                                                data-test="otherAcceptTermsCheckbox"
                                            />
                                            <label className="form-check-label" htmlFor="inlineCheckbox1">
                                                {parse(t("transfer.general.accept_text_one"))}
                                                {/* <a>{t("transfer.general.accept_text_two")}</a> */}
                                                {t("transfer.general.accept_text_two")}
                                                {t("transfer.general.accept_text_three")}
                                            </label>
                                        </div>
                                    </div>
                                    <div className="col-lg-6 col-md-12 text-lg-right btn-wrap btn-wrap--grp">
                                        <Button
                                            className="btn btn-secondary"
                                            handleOnClick={() => this.cancel()}
                                            id={ID_CANCEL_TRANSFER_MILES}
                                            testIdentifier="transferCancelBtn"
                                            label={t("transfer.general.cancel_btn")} />
                                        <Button
                                            className="btn btn-primary"
                                            handleOnClick={() => this.props.makePayment(member.memberDetails.membershipNumber, data.pointsToTransfer, this.cancel(), data.pin, data.specialMessageValue)}
                                            id={ID_TRANSFER_MILES}
                                            testIdentifier="proceedToTransferBtn"
                                            enabled={!paymentDisabled}
                                            label={t("transfer.general.transfer_btn")} />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                }
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return ({
        member: state.searchMember,
        message: state.transferMilesMessage,
        defaultConfig: state.configurationReducer.default,
        currentUserData: state.currentLoginUserDataReducer.currentUserData,
    })
}

const mapDispatchToProps = dispatch => {
    return ({
        searchMember: (requestBody, loading) => dispatch(searchMember(requestBody, loading)),
        hideMessage: () => dispatch(hideTransferMilesMessage()),
        clearSearchMember: () => dispatch(clearSearchMember),
        resetError: () => dispatch(resetError()),
        setError: (message) =>  dispatch(setError(message))

    })
}
TransferToNewRecipient.contextType = MfaContext
export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(TransferToNewRecipient)));