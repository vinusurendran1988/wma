import React from 'react';
import TransferToFamilyMember from './TransferToFamilyMember';
import TransferToNewRecipient from './TransferToNewRecipient';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { withSuspense, getTransactionFee, getPrecision, numberWithCommas } from '../../common/utils';
import { acceptPayment, makePayment, logout } from './actions';
import { CONFIG_SECTION_TRANSFERPOINT, CONFIG_SECTION_DEFAULT } from '../../common/utils/Constants';
import { fetchAccountSummary } from '../../common/middleware/redux/commonAction';
import CustomMessage from '../../common/components/custommessage';
import parse from 'html-react-parser';
import { NAVIGATE_TRANSFER } from '../../common/utils/urlConstants';
import {
    getItemFromBrowserStorage,
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
    BROWSER_STORAGE_KEY_PARAMS,
    BROWSER_STORAGE_TYPE_SESSION,
    BROWSER_STORAGE_KEY_CURRENCY_CODE
} from '../../common/utils/storage.utils';
import { ID_TRANSFER_MILES, TRANSACTION_TYPE_GENERAL, TRANSACTION_TYPE_FAMILY, ENABLE, TRANSACTION_TYPE_CHARITY, SUCCESS, WARNING, CANCELLED, DANGER, FAILED } from './Constants';
import MfaContext from '../../../context/MfaContext';
import TransferToCharity from './TransferToCharity';
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';

/**
 * @author Alan Kuriakose, Somdas M
 * @description Component to render the TransferMiles component.
 * The component renders the tabs based on the transactionType and their respective tab details.
 */
class TransferMiles extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            currentTab: TRANSACTION_TYPE_GENERAL,
            noFamilyMembers: false,
            messageContent: {
                messages: [],
                type: ""
            },
            configurationByType : {},
            disabledTabs: [],
            dropdownDisplay: 'none',
            paymentGateWayRefNumber: undefined
        }

        this.getAvailablePoints = this.getAvailablePoints.bind(this)
        this.makePayment = this.makePayment.bind(this)
    }

    componentDidMount() {
        this.props.setPageInfo(this.props, {config: this.props.config, confSection: CONFIG_SECTION_TRANSFERPOINT})
        if (this.props.config) {
            this.setConfigurationByType()
        } 
        if (!this.props.accountSummary) {
            this.props.fetchAccountSummary();
        }
        const params = new URLSearchParams(window.location.hash.split('?')[1]);
        const paymentStatus = params.get('payment') || '';
        const paymentGateWayRefNumber = (params.get('tid') || '');
        if (paymentStatus !== '') {
            if (paymentStatus === SUCCESS) {
                const parameters = JSON.parse(getItemFromBrowserStorage(
                    BROWSER_STORAGE_KEY_PARAMS,
                    BROWSER_STORAGE_TYPE_SESSION
                ));
                this.setState({
                    paymentGateWayRefNumber
                }, () => {
                    if(parameters && parameters.acceptPaymentRequired){
                        this.props.acceptPayment({ ...parameters, paymentGateWayRefNumber }, ID_TRANSFER_MILES);
                    }else if(parameters){
                        this.props.logout({ ...parameters, paymentGateWayRefNumber }, ID_TRANSFER_MILES)
                    }
                })
            } else if (paymentStatus === CANCELLED) {
                this.showMessage(CANCELLED)
            } else if (paymentStatus === FAILED) {
                this.showMessage(FAILED)
            }
        }
    }

    componentDidUpdate(prevProps) {

        if(prevProps.config != this.props.config){
            this.setConfigurationByType()
        }

        if (prevProps.errors != this.props.errors) {
            let { messageContent } = this.state
            messageContent.messages = this.props.errors
            messageContent.type = DANGER
            this.setState({
                messageContent
            })
        }
        if (prevProps.message != this.props.message || (this.props.message && JSON.stringify(prevProps.language) != JSON.stringify(this.props.language))) {
            if (this.props.message.type == SUCCESS) {
                this.showMessage(SUCCESS)
            } else if (this.props.message.showMessage != prevProps.message.showMessage && !this.props.message.showMessage) {
                let { messageContent } = this.state
                messageContent.messages = []
                messageContent.type = ""
                this.setState({
                    messageContent
                })
            }
        }
    }

    /**
     * 
     * @param {*} messageType 
     * @description This Method is to show the Message after the Transfer Miles is completed.
     */
    showMessage(messageType) {
        let { messageContent, paymentGateWayRefNumber } = this.state
        let transferResponse
        try{
            transferResponse = JSON.parse(getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PARAMS, BROWSER_STORAGE_TYPE_SESSION))
        }catch{
            transferResponse = {}
        }
        switch (messageType) {
            case SUCCESS:
                messageContent.messages = transferResponse && transferResponse.isPaymentRequired ?
                    [parse(this.props.t('transfer.transfer_success_message_withPayment').replace('{POINTS_TO_TRANSFER}', numberWithCommas(transferResponse.pointsToTransfer)).replace('{TRANSACTION_ID}', paymentGateWayRefNumber))] :
                    [parse(this.props.t('transfer.transfer_success_message_withoutPayment').replace('{POINTS_TO_TRANSFER}', numberWithCommas(transferResponse.pointsToTransfer)))]
                messageContent.type = SUCCESS
                break;
            case CANCELLED:
                messageContent.messages = transferResponse && transferResponse.isPaymentRequired ?
                    [parse(this.props.t('transfer.family.purchase_cancelled_withPayment').replace('{TRANSACTION_ID}', window.location.href.split("tid=")[1]))] :
                    [parse(this.props.t('transfer.family.purchase_cancelled_withoutPayment'))]
                messageContent.type = WARNING
                break;
            case FAILED:
                messageContent.messages = transferResponse && transferResponse.isPaymentRequired ?
                    [parse(this.props.t('transfer.family.purchase_failed_withPayment').replace('{TRANSACTION_ID}', window.location.href.split("tid=")[1]))] :
                    [parse(this.props.t('transfer.family.purchase_failed_withoutPayment'))]
                messageContent.type = DANGER
                break;
        }
        this.setState({
            messageContent
        }, () => {
            window.history.pushState({}, null, `#${NAVIGATE_TRANSFER}`)
        })
    }

    /**
     * @author Somdas M
     * @description Method to retrieve the 'enabled' transactions.
     * From the configuration of the transfermiles page, we need to handle only the enabled ones.
     * This method iterates over the configuration and store the enabled types to state variable 'configurationByType'.
     * configurationByType will be an object where the transactionType will be the key and the respective transaction object as value.
     */
    setConfigurationByType = () => {
        const { config } = this.props
        const configurationByType = {}
        let specialMessage = {}
        if (config && config.transactionTypes) {
            config.transactionTypes.map(transactionType => {
                if (transactionType.status === ENABLE)
                    configurationByType[transactionType.type] = transactionType
            })
        }
        const configurationByTypeKeys = Object.keys(configurationByType)
        const currentTab = configurationByTypeKeys.length>0?configurationByTypeKeys[0]:''
        this.setState({ configurationByType, currentTab })
    }

    updateState = (field, index) => {
        this.setState({
            [field]: index
        })
    }

    /**
     * @author Somdas M
     * @param {String} tab The transactionType that is to be displayed as disabled.
     * @description Method to disable the tabs and prevent the click event.
     * The state variable 'disabledTabs' contains the list of tabs that is to be displayed as disabled.
     * Though the tab is enabled in the page configuration, but due to requirement if the tab should be displayed as disabled, 
     * include that in the disabledTabs list in state.
     */
    // disableTab = (tab) => {
    //     const { disabledTabs } = this.state
    //     disabledTabs.push(tab)
    //     this.setState({ disabledTabs })
    // }

    /**
     * @author Somdas M
     * @description Method to render the tabs from the configurationByType (which contains only the enabled tabs)
     */
    renderTabHeader = () => {
        const { configurationByType, messageContent, currentTab, disabledTabs } = this.state;
        const { t } = this.props
        if (configurationByType && Object.keys(configurationByType).length > 0) {
            return Object.keys(configurationByType).map((type, index) => {
                const currentType = configurationByType[type]
                return <li key={currentType.type} onClick={() => {
                    messageContent.messages = []
                    messageContent.type = ""
                    this.setState({
                        currentTab: currentType.type,
                        messageContent,
                    })
                }} disabled={disabledTabs.includes(currentType.type)}>
                    <input type="radio" name="options" id={`option${index}`} checked={currentTab == currentType.type}
                        data-test={`li_${currentType.type}`} readOnly
                    />
                    <label htmlFor={`option${index}`}>{t(`transfer.${currentType.type}.title`)}</label>
                </li>
            })
        }
    }

    /**
     * @author Somdas M
     * @description Method to render the tab details section
     */
    renderTabDetails = () => {
        const { currentTab, configurationByType } = this.state
        if (configurationByType && Object.keys(configurationByType).length) {
            const config = configurationByType[currentTab]
            if (config && config.pointDetails && config.pointDetails.length) {
                const pointDetails = this.getEnabledPointDetails(config.pointDetails)
                const { isProtectedApi, ui } = this.props.config
                const specialMessageStatus = ui.message[currentTab]
                return {
                    [TRANSACTION_TYPE_GENERAL]: <TransferToNewRecipient
                        config={config}
                        isProtectedApi={isProtectedApi}
                        pointDetails={pointDetails}
                        specialMessageStatus={specialMessageStatus}
                        getAvailablePoints = {this.getAvailablePoints}
                        makePayment={ this.makePayment }
                        updateState={ this.updateState}
                    />,

                    [TRANSACTION_TYPE_FAMILY]: <TransferToFamilyMember
                        // disableFamilyTab={() => this.disableTab(TRANSACTION_TYPE_FAMILY) }
                        config={config}
                        isProtectedApi={isProtectedApi}
                        pointDetails={pointDetails}
                        specialMessageStatus={specialMessageStatus}
                        getAvailablePoints = {this.getAvailablePoints}
                        makePayment={ this.makePayment }
                        updateState={ this.updateState}
                    />,
                    
                    [TRANSACTION_TYPE_CHARITY]: <TransferToCharity
                        config={config}
                        pointDetails={pointDetails}
                        isProtectedApi={isProtectedApi}
                        specialMessageStatus={specialMessageStatus}
                        getAvailablePoints = {this.getAvailablePoints}
                        makePayment={ this.makePayment }
                        updateState={ this.updateState}
                    />

                }[currentTab]
            }
        }
    }

     /**
     * @author Somdas M
     * @param {Array} pointDetails The entire list of points
     * @returns {Array} The list of points with status 'enable'
     * @description Retrieve the list of enabled points
     */
    getEnabledPointDetails = (pointDetails) => {
        return pointDetails.filter(e=>e.status == ENABLE)
    }
    
    /**
     * @author Somdas M
     * @description Method to invoke the transfer points api.
     * This method creates the requestbody, the userInputs are provided as arguements to this method.
     * This method will be used by all the tabs to invoke the transfer api
     * @param {string} toMembershipNumber Recipient Membership Number
     * @param {string} pointsToTransfer Total points to be transferred
     * @param {Function} cancelMethod The method which resets the respective component's state
     * @param {string} pin The pin number, is the payment api is protected
     * @param {number} selectedPointDetailsIndex The selected point's index in the array
     */
    makePayment(toMembershipNumber, pointsToTransfer, cancelMethod, pin="",specialMessageValue, selectedPointDetailsIndex=0) {
        const { configurationByType, currentTab } = this.state
        const { defaultConfig, config } = this.props
        const selectedConfig = configurationByType[currentTab]
        const { pointDetails } = selectedConfig
        const selectedPointDetails = pointDetails[selectedPointDetailsIndex];
        if (!selectedPointDetails) {
            return;
        }
        const total_price = parseFloat((getTransactionFee(selectedPointDetails.transactionFee, pointsToTransfer)).toFixed(getPrecision(defaultConfig)));
        const order_currency = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_CURRENCY_CODE);
        const order_amount = total_price;
        let pos_city = "", pos_country = "", show_miles_only= ""
        if(selectedPointDetails.transactionType == "C"){
            show_miles_only = "N"
        }else if(selectedPointDetails.transactionType == "P"){
            show_miles_only = "Y"
        }
        if (defaultConfig) {
            const currentDefaultConfig = getCurrentProgramFromDefaultConfig(defaultConfig)
            pos_city = currentDefaultConfig.defaults.posCity
            pos_country = currentDefaultConfig.defaults.posCountry

        }
        let adhocAttributes = [];
        if(config && config.ui && config.ui.adhocAttributes && specialMessageValue){
            adhocAttributes = config.ui.adhocAttributes
            adhocAttributes[0].attributeValue = specialMessageValue
        }

        const requestBody = {
            companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
            programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
            membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
            isProtectedApi: config.isProtectedApi,
            quoteReferenceNumber:"",
            pointsToTransfer,
            adhocAttributes,
            loyaltyMembershipNumberOfRecipient: toMembershipNumber,
            pin,
            order_currency,
            total_price,
            order_amount,
            ...selectedPointDetails,
            transactionType: currentTab,
            pos_city,
            pos_country,
            show_miles_only,
            resetStates: () => { cancelMethod() }
        }
        this.props.makePayment(requestBody, ID_TRANSFER_MILES, selectedConfig, this.context);
    }

    /**
     * @author Somdas M
     * @description Method to retrieve the total points that are available to transfer
     * @param {number} selectedPointDetailsIndex The index of the point type
     */
   
    getAvailablePoints(selectedPointDetailsIndex = 0) {
        const { accountSummary } = this.props
        const { currentTab, configurationByType } = this.state
        const config = configurationByType[currentTab]
        const { pointDetails } = config
        if (accountSummary && pointDetails && pointDetails.length && pointDetails[selectedPointDetailsIndex]) {
            const pointType = accountSummary.pointDetails.find(p => p.pointType === pointDetails[selectedPointDetailsIndex].pointType)
            if(pointType)
            return pointType.points
        }
        return 0
    }

    onFilterTypeChange = (tabName) => {
        this.setState({
            currentTab: tabName,
            dropdownDisplay: "none"
        })
    }

    renderRadioButtonView(dropdownDisplay, configurationByType, currentTab) {
        return <div className="btn-group btn-group-toggle" data-toggle="buttons">
            {
                this.renderMobileView(dropdownDisplay, configurationByType, currentTab)
            }
            <ul className="radio-wrap">
                {
                    this.renderTabHeader()
                }
            </ul>
        </div>
    }

    renderMobileView(dropdownDisplay, configurationByType, currentTab) {
        const { t } = this.props
        return <div id='countries' className="tab__mob">
            <i className="fa fa-caret-down" aria-hidden="true"></i>
            <dl>
                <dt>
                    <a onClick={() => this.setState({ dropdownDisplay: "block" })} data-test={`${currentTab}_mob_a`}><span>
                        {t(`transfer.${currentTab}.title`)}</span></a>
                </dt>
                <dd>
                    <ul style={{ display: dropdownDisplay }}>
                        {
                            configurationByType && Object.keys(configurationByType).length &&
                            Object.keys(configurationByType).map((type, index) => {
                                const currentType = configurationByType[type]
                                return (<li key={`${currentType.type}_tabmob`} onClick={() => this.onFilterTypeChange(type)} aria-controls={type} aria-selected="true"
                                    data-test={`${type}_tabmob`}>
                                    {t(`transfer.${type}.title`)}</li>)
                            })
                        }
                    </ul>
                </dd>
            </dl>
        </div>
    }

    renderTabView(dropdownDisplay, configurationByType, currentTab) {
        return <nav className="tab">
            {
                this.renderMobileView(dropdownDisplay, configurationByType, currentTab)
            }
            <div className="nav nav-tabs nav-tabs--booking" id="nav-tab" role="tablist">
                {
                    this.renderTabViewHeader()
                }
            </div>
        </nav>
    }

    renderTabViewHeader() {
        const { configurationByType, messageContent, currentTab, disabledTabs } = this.state;
        const { t } = this.props
        if (configurationByType && Object.keys(configurationByType).length > 0) {
            return Object.keys(configurationByType).map((type, index) => {
                const currentType = configurationByType[type]
                return <a key={currentType.type} className={`nav-item nav-link ${currentType.type == currentTab ? 'active' : ''}`}
                    id={`${currentType.type}`}
                    data-toggle="tab"
                    href={`#${currentType.type}`}
                    role="tab"
                    onClick={() => {
                        messageContent.messages = []
                        messageContent.type = ""
                        this.setState({
                            currentTab: currentType.type,
                            messageContent,
                        })
                    }}
                    data-test={`li_${currentType.type}`}
                    aria-controls={currentType.type} aria-selected={currentType.type == currentTab ? 'true' : 'false'}>
                    <span>{t(`transfer.${currentType.type}.title`)}</span>
                </a>
            })
        }

    }

    render() {
        const { messageContent, dropdownDisplay, configurationByType, currentTab } = this.state;
        const { config, t } = this.props;
        return (
            <div className="col-lg-12" data-test="transferMilesComponent">
                <div className="title title--page">
                    <h2>{t("transfer.title")}</h2>
                </div>
                <p className="mb-5">{parse(t("transfer.description"))} </p>
                <CustomMessage message={messageContent.messages} type={messageContent.type} />
                <div className="form form--family">
                    {/* <p className="mb-5">description : TBD</p> */}
                    <div className="form-row">
                        <div className="col-auto">
                            <div className="form-group">
                                {   
                                    config && config.ui && config.ui.showRadioButtonView ?
                                    this.renderRadioButtonView(dropdownDisplay, configurationByType, currentTab) :
                                    this.renderTabView(dropdownDisplay, configurationByType, currentTab)
                                }
                            </div>
                        </div>
                    </div>
                    <div className="form-row">
                        <div className="col-xl-8 col-lg-10 col-md-12">
                            {
                                this.renderTabDetails()
                            }
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

TransferMiles.contextType = MfaContext

const mapStateToProps = state => {
    return ({
        message: state.transferMilesMessage,
        config : state.configurationReducer[CONFIG_SECTION_TRANSFERPOINT],
        errors: state.commonErrorReducer.error,
        accountSummary: state.accountSummaryReducer.accountSummary,
        language: state.language,
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT]
    })
}

const mapDispatchToProps = {
    acceptPayment, 
    fetchAccountSummary, 
    makePayment,
    logout 
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(TransferMiles)));