export const DATA_EXPORT_BTN = "user-data-export-button"
export const ACCOUNT_DEACTIVATE_BTN = "user-account-deactivate-button"