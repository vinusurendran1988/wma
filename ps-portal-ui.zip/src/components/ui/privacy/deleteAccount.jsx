import React, { Component } from 'react';
import {feedbackDetails} from '../feedback/actions'
import { connect } from 'react-redux';
import { withSuspense, getApiErrorMessage } from '../../common/utils';
import { withTranslation } from 'react-i18next';
import { fetchConfiguration } from '../../common/middleware/redux/commonAction';
import { getItemFromBrowserStorage, BROWSER_STORAGE_KEY_COMPANY_CODE, BROWSER_STORAGE_KEY_PROGRAM_CODE, BROWSER_STORAGE_KEY_MEMBERSHIP_NO } from '../../common/utils/storage.utils';
import Button from '../../common/components/fieldbank/Button';
import { ACCOUNT_DEACTIVATE_BTN } from './Constant'
/**
 * DeleteAccount class.
 * @description DeleteAccount section under the Privacy Tab in Profile page.
 * @author Somdas M
 */

class DeleteAccount extends Component {
    constructor (props) {
        super(props)
        this.state = {
            data : this.initialData()
        }
    }

    handleChange(value, fieldName) {
        let {data} = this.state
        data[fieldName]= value
        this.setState({
            data
        })
    }

    pauseAccount(){
        let type = ""
        let messages = []
        this.props.setCustomMessages({ type, messages }, false)

        if(this.state.data.serviceDescription.length>0){
            const {configuration} = this.props
            let payload = {
                "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                "membershipNumber": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                "srType": configuration.deleteAccount.serviceRequestCode,
                "srCategory": configuration.deleteAccount.serviceRequestCategory,
                "descriptionRequest": this.state.serviceDescription,
                "channel": configuration.deleteAccount.serviceRequestChannel
            }
            let form_data = new FormData();
            for (var key in payload) {
                form_data.append(key, payload[key]);
            }
            this.props.feedbackDetails(form_data, ACCOUNT_DEACTIVATE_BTN)
        } else {
            type = "danger"
            messages = [this.props.t('privacy.deleteAccount.provideDescription')]
            this.props.setCustomMessages({type, messages}, false)
        }
    }

    resetBtn(){
        this.setState({
            data: this.initialData()
        })
    }

    initialData(){
        return {
            serviceDescription:""
        }
    }
    componentDidUpdate(prevProps, prevState){
        if (JSON.stringify(prevProps.feedback) !== JSON.stringify(this.props.feedback)) {
            let responseData = this.props.feedback;
            let type="", messages=[]
            if (responseData.statusMessage == "SUCCESS") {
                let { object } = this.props.feedback;
                this.resetBtn()
                type = "success"
                messages = [this.props.t('privacy.userDataExport.successMsg').replace('${REQUEST_ID}', object.serviceRequestId)]
            }
            else {
                type = "danger"
                messages = [getApiErrorMessage(responseData.error)]
            }
            this.props.setCustomMessages({type, messages}, false)
        }
    }

    render() {
        const { t } = this.props
        return (
            <div className="pageClassChangeSecurity rightSidePanel">
                <div className="form-row">
                <div className="col-lg-12">
                        <p>Please use the comment box to fill if any specific details on deleting the account. Please note the service request number after the submission to track the status.</p>
                    </div>
                    <div className="col-lg-6">
                        <div>
                            <ol className="list-group list-group-flush">
                                <li className="list-group-item">1. Submit your delete account request</li>
                                <li className="list-group-item">
                                2. One of our service agents will respond to your request, or request additional information from you within 5 days. We may extend this process for up to XX days, in which case we will notify of the extension.</li>
                                <li className="list-group-item">3. After the deletion, we will notify the status in your registered email address.
                                </li>
                            </ol>
                        </div>
                    </div>
                    <div className="col-lg-6">
                        <div className="form-group">
                            <label
                                htmlFor="accountDescription"
                            >
                                {t('privacy.deleteAccount.description')}
                            </label>
                            <span className="text-warning">*</span>
                            <textarea
                                id="dataExportDescription"
                                className="reftextarea"
                                placeholder=""
                                rows={6}
                                onChange={(e) => this.handleChange(e.target.value, "serviceDescription")}
                                value={this.state.data.serviceDescription}
                                //data-test={testIdentifier}
                            />
                        </div>
                    </div>

                    <div className="col-lg-12">
                        <div className="form-group">
                            <div className="text-right buttonWrap">
                                <Button
                                    className="btn btn-primary" 
                                    handleOnClick={() => this.pauseAccount()} 
                                    id={ACCOUNT_DEACTIVATE_BTN} 
                                    data-test={ACCOUNT_DEACTIVATE_BTN}
                                    label={t("privacy.userDataExport.submitBtn")} />
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        feedback: state.feedback.feedBackDetails,
    }
}

const mapDispatchToProps = {
    feedbackDetails,
    fetchConfiguration
}
export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(DeleteAccount)));