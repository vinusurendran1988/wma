import React, { Component } from 'react'
import { connect } from 'react-redux';
import { withSuspense } from '../../../components/common/utils';
import { withTranslation } from 'react-i18next';
import {
    resetError,
    fetchConfiguration
} from '../../common/middleware/redux/commonAction'
import { CONFIG_SECTION_PRIVACY } from '../../common/utils/Constants';
import CustomMessage from '../../common/components/custommessage';
import UserDataExport from './userDataExport';
import DeleteAccount from './deleteAccount'

/**
 * PrivacyComponent class.
 * @description Privacy Tab in Profile page.
 * @author Somdas M
 */

class PrivacyComponent extends Component {

    constructor(props){
        super(props)
        this.state={
            customeMessage:{
                type:"",
                messages:[]
            },
            canTranslate: true
        }
        this.setCustomMessages = this.setCustomMessages.bind(this)
    }

    componentDidMount(){
        this.props.resetError()
        if (!this.props.config) {
            this.props.fetchConfiguration(CONFIG_SECTION_PRIVACY)
        }
    }

    /**
     * Function to set the success/error message to be displayed
     * @author Somdas M
     * @param {object} customeMessage - Object {type: "success/danger", errorMessages:[]}
     * @param {string} canTranslate - If i18n translation is required or not.
     */
    setCustomMessages(customeMessage, canTranslate=true){
        this.setState({
            customeMessage,
            canTranslate
        })
    }

    render() {
        const { config, t } = this.props;
        const type = config && config.ui && config.ui.type;
        const filterType = config && config.ui && config.ui.filterType;
        return (
            <>
                <CustomMessage type={this.state.customeMessage.type} message={this.state.customeMessage.messages} canTranslate={this.state.canTranslate}/>
                <div className="accordion" id="accordionExample">
                    {
                        config && config.ui && config.ui.layout &&
                        config.ui.layout.order.map((layout, idx) => {
                            const uiConfig = config.ui.layout.elements[layout]
                            // const dynamicAttributes = config.dynamicAttributes[layout]
                            const componentConfig = config[layout]
                            return < div className="card" key={idx}>
                                <div className="card-header" id="headingOne">
                                    <h2 className="mb-0">
                                        <button className="btn btn-link btn-block text-left" type="button" data-toggle="collapse"
                                            data-target={`#collapse${idx}`} aria-expanded="true" aria-controls={`collapse${idx}`} onClick={()=>{
                                                this.setCustomMessages([]);
                                            }}>
                                            {t(`privacy.${layout}.title`)}
                                        </button>
                                    </h2>
                                </div>

                                <div id={`collapse${idx}`} className={`collapse ${idx==0?"show":""}`} aria-labelledby="headingOne"
                                    data-parent="#accordionExample">
                                    <div className="card-body">
                                        {
                                            {
                                                "userDataExport": <UserDataExport
                                                    config={componentConfig}
                                                    uiConfig={uiConfig}
                                                    setCustomMessages={this.setCustomMessages}
                                                    type={type}
                                                    filterType={filterType}
                                                    t={this.props.t}
                                                    configuration={this.props.config}
                                                />,
                                                "deleteAccount": <DeleteAccount
                                                    t={this.props.t}
                                                    setCustomMessages={this.setCustomMessages}
                                                    configuration={this.props.config}
                                                />
                                            }[layout]
                                        }
                                    </div>
                                </div>
                            </div>
                            
                        })
                    }
                    </div>
            </>

        )
    }
}

const mapStateToProps = (state) => {
    return {
        config: state.configurationReducer[CONFIG_SECTION_PRIVACY]
    }
}

const mapDispatchToProps = {
    resetError,
    fetchConfiguration
}
export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(PrivacyComponent)));