import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { withSuspense } from '../../common/utils';
import { connect } from 'react-redux';
import {
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    getItemFromBrowserStorage
} from '../../common/utils/storage.utils';
import { getFooterDetails } from './actions';
import parse from 'html-react-parser';
import { REQTYPE_JSON } from './Constants';
import {
    fetchConfiguration
} from '../../common/middleware/redux/commonAction';
import {
    CONFIG_SECTION_DEFAULT
} from '../../common/utils/Constants';
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';

class MemberPortalFooter extends Component {

    constructor(props) {
        super(props)
        this.state = {
            request: {},
            requestType: ''
        }
    }

    componentDidMount() {
        this.getFooterInfo();
    }

    /**
     * Handling of updations when props or state are updated.
     * @param {*} prevProps 
     * @param {*} prevState 
     * 
     */
    componentDidUpdate(prevProp, prevState) {
        //When language is changed
        if ( Object.keys(this.state.request).length == 0 ||
            (prevProp.language &&
            prevProp.language.code &&
            prevProp.language.code != this.props.language.code)) {
            this.getFooterInfo();
        }
    }

    /**
     * When the component is loaded or when the language is changed
     * do the API call to fetch the footer information
     * 
     */
    getFooterInfo() {

        const { defaultConfig } = this.props;
        if (defaultConfig) {
            const currentProgram = getCurrentProgramFromDefaultConfig(defaultConfig)
            let queryData = {};
            let requestType = '';
            if (currentProgram &&
                currentProgram.data &&
                currentProgram.data.cmsDetails &&
                currentProgram.data.cmsDetails.footer &&
                currentProgram.data.cmsDetails.footer.metaData) {
                queryData = currentProgram.data.cmsDetails.footer
                requestType = queryData.metaData.type
            }
            const request = {
                object: {
                    companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                    programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                    membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO) ?
                        getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO) : "",
                    ...queryData
                }
            }
            this.setState({
                request,
                requestType
            })
            this.props.getFooterDetails(request)
        }
    }

    getFooterContent(footerReponse) {
        let footerInfo = []
        if (footerReponse &&
            footerReponse.object &&
            footerReponse.object.data &&
            footerReponse.object.data.length > 0 &&
            footerReponse.object.data[0].content) {
                const  { content } = footerReponse.object.data[0]
                let dataContent
                try{
                    dataContent = JSON.parse(content.value)
                    footerInfo['footercontent'] = dataContent.layout.footer_content
                    footerInfo['copyright'] = dataContent.layout.copyright[0]
                    footerInfo['socialmedialink'] = dataContent.layout.social_media_link
                } catch {
                    dataContent = {}
                    console.error("An error occured while parsing the footer response!")
                }
        }
        return footerInfo
    }

    /**
     * When the request type is HTML, this method is been invoked to set
     * the footer html content
     * @param {*} footerReponse 
     */
    getFooterHtmlContent(footerReponse) {
        let footerhtml = "";
        if (footerReponse &&
            footerReponse.object &&
            footerReponse.object.data &&
            footerReponse.object.data.length > 0 &&
            footerReponse.object.data[0].content) {
            footerhtml = footerReponse.object.data[0].content.value
        }
        return footerhtml
    }

    render() {
        const { footerresponse } = this.props

        let copyright = {}
        let footerInfo = {}
        let htmlcontent = {}
        //Check if the request type is JSON or not
        if (this.state.requestType == REQTYPE_JSON) {
            footerInfo = this.getFooterContent(footerresponse)
        } else {
            htmlcontent = this.getFooterHtmlContent(footerresponse)
        }

        return (
            this.state.requestType == REQTYPE_JSON ?
                <footer>
                    <div className="container footer1 d-none d-lg-block d-xl-block">
                        <div className="row">
                            {
                                footerInfo &&
                                footerInfo.footercontent && 
                                footerInfo.footercontent.map((footerres, index) => {
                                    if (footerres.header.visibility == true) {
                                        return <div className="col-lg-3 col-md-4 col-sm-6" key={index}>
                                            <h6>{footerres.header.title}</h6>
                                            {
                                                footerres.body.map((footresbody, index) => {
                                                    if (footresbody.visibility == true) {
                                                        return <div className="footerLinks" key={index}>
                                                            <a href={footresbody.link} target="_blank" className="d-block">{footresbody.title}</a>
                                                        </div>
                                                    }
                                                })
                                            }
                                        </div>
                                    }
                                })
                            }
                        </div>
                    </div>

                    <div className="container footer2">
                        <div className="row">
                            {
                                footerInfo &&
                                footerInfo.copyright && 
                                footerInfo.copyright.visibility == true ? <>
                                    <div className="col-lg-6 d-none d-sm-none d-md-none d-lg-block d-xl-block">{copyright.title}</div></> : <> </>
                            }
                            <div className="col-lg-6 text-right">
                                {
                                    footerInfo &&
                                    footerInfo.socialmedialink && 
                                    footerInfo.socialmedialink.map((socailmedia, index) => {
                                        return <a key={index} href={socailmedia.link} target="_blank" aria-label={socailmedia.id}>
                                            <i className={socailmedia.className} aria-hidden="true"></i></a>
                                    })
                                }
                            </div>
                        </div>
                    </div>
                </footer> : <>
                    {
                        htmlcontent && parse(htmlcontent)
                    }
                </>
        );
    }
}

const mapStateToProps = state => {
    return {
        language: state.language,
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        footerresponse: state.getFooterDetailsReducer.footerdetails
    }
}

const mapDispatchToProps = {
    fetchConfiguration,
    getFooterDetails
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(MemberPortalFooter)));
