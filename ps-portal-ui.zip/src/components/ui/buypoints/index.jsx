import React, { Component } from 'react'
import { withTranslation } from 'react-i18next';
import parse from 'html-react-parser';
import { withSuspense, getPrecision, getTransactionFee } from '../../common/utils';
import { connect } from 'react-redux';
import {
    getApiErrorMessage,
    numberWithCommas
} from '../../common/utils'

import {
    fetchAccountSummary,
    resetError
} from '../../common/middleware/redux/commonAction'
import CustomMessage from '../../common/components/custommessage';
import {
    ENABLE,
    ID_SPINNER_PROCEED_TO_PAY,
    CURRENT_MILES,
    DANGER, SUCCESS, WARNING,
    TOTAL_MILES,
    PAYMENT_EQ_SUCCESS, PAYMENT_EQ_FAILED, PAYMENT_EQ_CANCELLED,
    SESSION_KEY_EQ,
    ONE_ITEM,
    TRANSACTION_TYPE_GENERAL,
    TRANSACTION_TYPE_TIERUPGRADE,
    EMPTY_STRING,
    TRANSACTION_TYPE_GIFTMILES
} from './Constants'
import BuyMiles from './BuyMiles';
import {
    CONFIG_SECTION_BUYPOINT,
    CONFIG_SECTION_DEFAULT
} from '../../common/utils/Constants'
import {
    getItemFromBrowserStorage,
    setItemToBrowserStorage,
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
    BROWSER_STORAGE_KEY_CURRENCY_CODE,
    BROWSER_STORAGE_KEY_TRANSACTION_ID,
    BROWSER_STORAGE_TYPE_SESSION,
    BROWSER_STORAGE_KEY_ACTIVITY_NUMBER,
    BROWSER_STORAGE_KEY_ACTIVITY_TYPE,
    BROWSER_STORAGE_KEY_ACTIVITY_CODE,
    BROWSER_STORAGE_KEY_ACTIVITY_NAME,
    BROWSER_STORAGE_KEY_AMOUNT_COLLECTED,
    BROWSER_STORAGE_KEY_PURCHASE_POINTS,
    BROWSER_STORAGE_KEY_TOTAL_MILES,
    removeItemFromBrowserStorage,
    BROWSER_STORAGE_KEY_POINT_DETAILS,
    BROWSER_STORAGE_KEY_SELECTED_TAB,
    BROWSER_STORAGE_KEY_UPGRADED_TIER
} from '../../common/utils/storage.utils';
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';
import {
    authenticateTransaction,
    buyPointAction,
    buyPointAcceptPayment,
    transactionLogout
} from './action'
import { _URL_BUY_PAYMENT_CANCELLED, _URL_BUY_PAYMENT_FAILED, _URL_BUY_PAYMENT_REDIRECT, _URL_BUY_PAYMENT_SUCCESS } from '../../common/config/config';
import { NAVIGATE_BUY } from '../../common/utils/urlConstants';
import UpgradeTier from './UpgradeTier';
import GiftMiles from './GiftMiles';

/**
 * @name BuyPoints component.
 * @description Component to render Buy miles/points components.
 * 
 */
class BuyPoints extends Component {

    constructor(props) {
        super(props)
        this.state = {
            selectedTab: TRANSACTION_TYPE_GENERAL,
            paymentResponse: false,
            paymentStatus: EMPTY_STRING,
            paymentMessage: [],
            currentConfig: {},
            configurationByType: {},
            disabledTabs: [],
            selectedBonusPoint: 0,
            pointDetails: [],
            totalMiles: 0
        }
    }

    /**
     * This method is to set the paymentResponse, paymentStatus to populate in CustomMessage
     * @param {*} Payment response 
     */
    paymentResponse(response) {
        const { paymentResponse, paymentStatus, paymentMessage } = response
        this.setState({
            paymentResponse,
            paymentStatus,
            paymentMessage
        })
    }

   /**
     * Handling of updations when props or state are updated.
     * @param {*} prevProp 
     */
    componentDidUpdate(prevProps) {
        let newState = {}
        if (this.props.error) {
            if (this.props.error.message && this.props.error != prevProps.error) {
                this.setState({
                    paymentResponse: true,
                    paymentStatus: DANGER,
                    paymentMessage: getApiErrorMessage(this.props.error)
                })
            }
        }
        if (prevProps.config != this.props.config) {
            this.setConfigurationByType()
        }

        if (JSON.stringify(prevProps.authTransaction) != JSON.stringify(this.props.authTransaction) &&
            this.props.authTransaction.transactionID) {

            const transactionId = this.props.authTransaction.transactionID
            setItemToBrowserStorage(
                BROWSER_STORAGE_KEY_TRANSACTION_ID,
                transactionId,
                BROWSER_STORAGE_TYPE_SESSION
            )
            this._buyPoint()
        }
        if (this.props.buyPointData &&
            JSON.stringify(prevProps.buyPointData) != JSON.stringify(this.props.buyPointData) &&
            this.props.buyPointData.memberActivityStatus &&
            this.props.buyPointData.memberActivityStatus.activityNumber) {
            const activityNumber = this.props.buyPointData.memberActivityStatus.activityNumber

            setItemToBrowserStorage(
                BROWSER_STORAGE_KEY_ACTIVITY_NUMBER,
                activityNumber,
                BROWSER_STORAGE_TYPE_SESSION
            )
            setItemToBrowserStorage(
                BROWSER_STORAGE_KEY_ACTIVITY_TYPE,
                this.props.buyPointData.memberActivityStatus.activityType,
                BROWSER_STORAGE_TYPE_SESSION
            )
            setItemToBrowserStorage(
                BROWSER_STORAGE_KEY_ACTIVITY_CODE,
                this.props.buyPointData.memberActivityStatus.activityCode,
                BROWSER_STORAGE_TYPE_SESSION
            )
            setItemToBrowserStorage(
                BROWSER_STORAGE_KEY_ACTIVITY_NAME,
                this.props.buyPointData.memberActivityStatus.activityName,
                BROWSER_STORAGE_TYPE_SESSION
            )
            setItemToBrowserStorage(
                BROWSER_STORAGE_KEY_AMOUNT_COLLECTED,
                this.state.pointDetails[0].isPaymentRequired ? parseFloat(getTransactionFee(this.state.pointDetails[0].transactionFee, this.state.selectedBonusPoint).toFixed(this.props.precision)) : 0,
                BROWSER_STORAGE_TYPE_SESSION
            )
            this._redirectPayment(this.props.buyPointData.redirectURL);
        }
        if (this.props.acceptPayment &&
            JSON.stringify(prevProps.acceptPayment) != JSON.stringify(this.props.acceptPayment) &&
            this.props.acceptPayment.acceptPaymentStatus) {
            newState["acceptPaymentInvoked"] = false
            if (this.props.config.isProtectedApi)
                this._logoutTransaction()
            else
                this.showMessage()
        }

        if (this.props.logoutTransaction &&
            JSON.stringify(prevProps.logoutTransaction) != JSON.stringify(this.props.logoutTransaction)) {
            this.showMessage()
        }

        if(window.location.href && ( window.location.href.includes(PAYMENT_EQ_FAILED) ||  window.location.href.includes(PAYMENT_EQ_CANCELLED) )){
            this.showMessage()
        }

        if (window.location.href.includes(PAYMENT_EQ_SUCCESS) && !this.state.acceptPaymentInvoked
            && getItemFromBrowserStorage(BROWSER_STORAGE_KEY_ACTIVITY_CODE, BROWSER_STORAGE_TYPE_SESSION)) {
            newState["acceptPaymentInvoked"] = true
            let pointDetails = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_POINT_DETAILS)
            try{
                pointDetails = JSON.parse(pointDetails)
            }catch{
                pointDetails = undefined
            }
            if(pointDetails && pointDetails[0] && pointDetails[0].acceptPaymentRequired){
                this._acceptPayment()
            }else{
                this.showMessage()
            }
        }

        if (
            this.props.accountSummary &&
            this.state.currentMiles == -1
        ) {
            let selectedBonusPoint = getPointsArray(this.state.pointDetails)[0]
            const currentMiles = this.getCurrentMiles()
            if (this.state[CURRENT_MILES] != currentMiles) {
                newState[CURRENT_MILES] = currentMiles
            }
            const totalPoints = this.calculateTotalMiles(currentMiles, selectedBonusPoint)
            if (this.state[TOTAL_MILES] != totalPoints) newState[TOTAL_MILES] = totalPoints
        }
        if (Object.keys(newState).length > 0) this.setState(newState)

    }

    /**
     * Method is initialized whenever the component is loaded
     */
    componentDidMount() {
        this.props.setPageInfo(this.props, {config: this.props.config, confSection: CONFIG_SECTION_BUYPOINT})
        if (this.props.config) {
            this.setConfigurationByType()
        }
    }

    /**
     * This method is to perform logout transaction for Protect API
     */
    _logoutTransaction() {
        const transactionId = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_TRANSACTION_ID, BROWSER_STORAGE_TYPE_SESSION)
        const activityNumber = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_ACTIVITY_NUMBER, BROWSER_STORAGE_TYPE_SESSION)

        if (transactionId && activityNumber) {
            let logoutTransactionPayload = {
                object: {
                    companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                    programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                    membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                    transactionID: transactionId,
                    activityNumber
                }
            }
            this.props.transactionLogout(logoutTransactionPayload, ID_SPINNER_PROCEED_TO_PAY)
        }
    }

    /**
     * Method is invoked once the buyPointData props is updated 
     * @param {*} redirectURL 
     */
    _redirectPayment(redirectURL) {
        if (redirectURL && this.state.pointDetails[0].isPaymentRequired) {
            var res = redirectURL.split(SESSION_KEY_EQ);
            window.location.href = res[0] + SESSION_KEY_EQ + encodeURIComponent(res[1]);
        } else if (!this.state.pointDetails[0].isPaymentRequired && this.state.pointDetails[0].acceptPaymentRequired) {
            this._acceptPayment();
        } else if (this.props.config.isProtectedApi) {
            this._logoutTransaction()
        } else {
            this.showMessage()
        }
    }

    /**
     * This method is used to do accept payment, only when the Payment is not required
     * i.e when isPaymentRequired is false
     */
    _acceptPayment() {

        const transactionId = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_TRANSACTION_ID, BROWSER_STORAGE_TYPE_SESSION)
        const activityNumber = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_ACTIVITY_NUMBER, BROWSER_STORAGE_TYPE_SESSION)
        const activityType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_ACTIVITY_TYPE, BROWSER_STORAGE_TYPE_SESSION)
        const activityCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_ACTIVITY_CODE, BROWSER_STORAGE_TYPE_SESSION)
        const activityName = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_ACTIVITY_NAME, BROWSER_STORAGE_TYPE_SESSION)
        const amountCollected = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_AMOUNT_COLLECTED, BROWSER_STORAGE_TYPE_SESSION)
        if (this.state.pointDetails && (transactionId || !this.props.config.isProtectedApi) && activityNumber && activityType && activityCode) {
            this.props.buyPointAcceptPayment(this.generateAcceptPaymentPayload(transactionId, activityNumber, activityType, activityCode, activityName, amountCollected), ID_SPINNER_PROCEED_TO_PAY)
            removeItemFromBrowserStorage(BROWSER_STORAGE_KEY_ACTIVITY_CODE, BROWSER_STORAGE_TYPE_SESSION)
        }

    }

    /**
     * This method is to generate a payload for buyPointAcceptPayment API call
     * @param {*} transactionId 
     * @param {*} activityNumber 
     * @param {*} activityType 
     * @param {*} activityCode 
     * @param {*} activityName 
     * @param {*} amountCollected 
     */
    generateAcceptPaymentPayload(transactionId, activityNumber, activityType, activityCode, activityName, amountCollected) {
        const { selectedTab } = this.state
        let pointDetails = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_POINT_DETAILS)
        try{
            pointDetails = JSON.parse(pointDetails)
        }catch{
            pointDetails = undefined
        }
        if (pointDetails) {
            const { pointType, isPaymentRequired } = pointDetails[0]
            const object = {
                companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                activityType,
                activityNumber,
                activityCode,
                paymentRemark: activityName,
                transactionType: selectedTab,
                paymentDetail: [{
                    amountCollected,
                    pointType,
                    currencyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_CURRENCY_CODE),
                    paymentSource: EMPTY_STRING,
                    paymentType: EMPTY_STRING,
                    pointsCollected: "0",
                    quoteReferenceNumber: EMPTY_STRING
                }],
                transactionId: transactionId ? transactionId : EMPTY_STRING,
                promotionIdentifier: EMPTY_STRING
            }
            if (isPaymentRequired) {
                const { paymentDetail } = object
                paymentDetail[0]["paymentGateWayRefNumber"] = window.location.href.split("tid=")[1]
            }
    
            return { object }
        }
    }

    /**
     * This method is used to set the configuration based on the Type
     * Also the status of the type is checked
     */
    setConfigurationByType = () => {
        const { config } = this.props
        const configurationByType = {}
        if (config && config.transactionTypes) {
            config.transactionTypes.map(transactionType => {
                if (transactionType.status === ENABLE)
                    configurationByType[transactionType.type] = transactionType
            })
        }
        this.setState({ configurationByType })
    }

    /**
     * Method is to get the enabled points list
     * @param {*} pointDetails 
     */
    getEnabledPointDetails = (pointDetails) => {
        if (pointDetails && pointDetails.length) {
            return pointDetails.filter(e => e.status == ENABLE)
        }
        return []
    }

    /**
     * This method is invoked when the Proceed to Buy button is clicked
     * To perform the payment process
     * @param {*} selectedBonusPoint 
     * @param {*} transactionPin 
     * @param {*} pointDetails 
     * @param {*} totalMiles 
     */
    makePayment = (selectedBonusPoint, transactionPin, pointDetails, totalMiles) => {
        this.setState({
            selectedBonusPoint,
            pointDetails,
            totalMiles
        }, () => {
            this.props.resetError()
            this.resetErrorMessage()
            setItemToBrowserStorage(BROWSER_STORAGE_KEY_POINT_DETAILS, JSON.stringify(pointDetails))
            setItemToBrowserStorage(BROWSER_STORAGE_KEY_PURCHASE_POINTS, selectedBonusPoint, BROWSER_STORAGE_TYPE_SESSION)
            setItemToBrowserStorage(BROWSER_STORAGE_KEY_TOTAL_MILES, totalMiles, BROWSER_STORAGE_TYPE_SESSION)
            if (this.props.config.isProtectedApi) {
                const payload_authenticate = {
                    object: {
                        companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                        programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                        membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                        pin: transactionPin
                    }
                }
                this.props.authenticateTransaction(payload_authenticate, ID_SPINNER_PROCEED_TO_PAY)
            } else {
                this._buyPoint();
            }
        })
    }

    resetErrorMessage = () => {
        this.setState({
            paymentResponse: false,
            paymentStatus: EMPTY_STRING,
            paymentMessage: []
        })
    }

    /**
     * This methos is to call the buyPointAction API
     * If it is Protected API, first authenticateTransaction API is invoked,
     * Later to that _buyPoint method is been invoked
     */
    _buyPoint() {
        const transactionId = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_TRANSACTION_ID, BROWSER_STORAGE_TYPE_SESSION)
        if (transactionId || !this.props.config.isProtectedApi) {
            this.props.buyPointAction(this.generateBuyPointRequest(transactionId), ID_SPINNER_PROCEED_TO_PAY)
        }
    }

    /**
     * Used to generate the payload for buyPointAction API
     * @param {*} transactionId 
     */
    generateBuyPointRequest(transactionId) {

        const { pointDetails, selectedBonusPoint, selectedTab, configurationByType } = this.state
        const { pointType, isPaymentRequired, transactionFee, transactionType, isBonus } = pointDetails[0]
        setItemToBrowserStorage(BROWSER_STORAGE_KEY_SELECTED_TAB, selectedTab)
        const object = {
            companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
            programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
            membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
            quoteReferenceNumber:"",
            points: [{
                isBonus,
                points: selectedBonusPoint,
                pointType
            }],
            transactionType: selectedTab,
            transactionID: transactionId ? transactionId : EMPTY_STRING
        }
        if (isPaymentRequired) {
            const paymentGateway = {}
            paymentGateway["cancel_url"] = _URL_BUY_PAYMENT_CANCELLED
            paymentGateway["success_url"] = _URL_BUY_PAYMENT_SUCCESS
            paymentGateway["failure_url"] = _URL_BUY_PAYMENT_FAILED
            paymentGateway["redirect_url"] = _URL_BUY_PAYMENT_REDIRECT
            paymentGateway["terms_and_conditions"] = configurationByType[selectedTab] &&
                                                                configurationByType[selectedTab].termsAndConditions ?
                                                                configurationByType[selectedTab].termsAndConditions : ""


            if (this.props.defaultConfig) {
                const defaultConfig = getCurrentProgramFromDefaultConfig(this.props.defaultConfig)
                const precision = getPrecision(defaultConfig, getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE))
                let show_miles_only
                if(transactionType == "C"){
                    show_miles_only = "N"
                }
                if(show_miles_only == "N"){
                    paymentGateway["purchase_totals"] = {
                        show_miles_only,
                        order_amount: parseFloat(getTransactionFee(transactionFee, selectedBonusPoint).toFixed(precision ? precision : 0)),
                        order_currency: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_CURRENCY_CODE)
                    }
                }else if(show_miles_only == "Y"){
                    paymentGateway["purchase_totals"] = {
                        show_miles_only,
                        order_amount: parseFloat(getTransactionFee(transactionFee, selectedBonusPoint).toFixed(precision ? precision : 0)),
                        order_currency: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_CURRENCY_CODE),
                        miles: {
                            redeemed_miles: 0
                        }
                    }
                }
                paymentGateway["point_of_sale"] = {
                    booking_channel: configurationByType[selectedTab] &&
                                     configurationByType[selectedTab].bookingChannel &&
                                     configurationByType[selectedTab].bookingChannel.web ?
                                     configurationByType[selectedTab].bookingChannel.web : "",
                    pos_city: defaultConfig.defaults.posCity,
                    pos_country: defaultConfig.defaults.posCountry
                }
            }
            paymentGateway["order_details"] = {
                order_info: configurationByType[selectedTab] ? configurationByType[selectedTab].description : "",
                order_type: "",
                items: [{
                    airline_data: {
                        origin_destination: [{
                                segments: [{}]
                            }]
                    },
                    quantity: ONE_ITEM,
                    total_price: getTransactionFee(transactionFee, selectedBonusPoint)
                }]
            }
            object["paymentGateway"] = paymentGateway
        }

        return { object }
    }

    /**
     * showMessage Method is to show the payment status in a CustomMessage Component
     * 
     */
    showMessage() {
        let paymentResponse, paymentStatus, paymentMessage;
        let pointDetails = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_POINT_DETAILS)
        let currentTransactionType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_SELECTED_TAB)
        let upgradedTier = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_UPGRADED_TIER)
        if (pointDetails) {
            pointDetails = JSON.parse(pointDetails)
            removeItemFromBrowserStorage(BROWSER_STORAGE_KEY_POINT_DETAILS)
            paymentMessage = []
            if (!pointDetails[0].isPaymentRequired || (window.location.href && window.location.href.includes(PAYMENT_EQ_SUCCESS))) {
                paymentResponse = true
                paymentStatus = SUCCESS
                if (currentTransactionType === TRANSACTION_TYPE_GENERAL) {
                    paymentMessage.push(parse(this.props.t("buy.buy_bonus_points.purchase_success_message").replace(
                        "{SELECTED_POINT}",
                        numberWithCommas(parseInt(getItemFromBrowserStorage(
                            BROWSER_STORAGE_KEY_PURCHASE_POINTS,
                            BROWSER_STORAGE_TYPE_SESSION
                        )))
                    ).replace(
                        "{TRANSACTION_ID}", window.location.href.split("tid=")[1]
                    )))
                } else if (currentTransactionType === TRANSACTION_TYPE_TIERUPGRADE) {
                    paymentMessage.push(parse(this.props.t("buy.tierUpgrade.upgrade_success_message").replace(
                        "{TRANSACTION_ID}", window.location.href.split("tid=")[1]).replace("{UPGRADEDTIER}", upgradedTier)
                    ))
                }
                else if (currentTransactionType === TRANSACTION_TYPE_GIFTMILES) {
                    paymentMessage.push(parse(this.props.t("buy.giftMiles.giftmiles_success_message").replace(
                        "{TRANSACTION_ID}",window.location.href.split("tid=")[1])
                    ))
                }
                window.history.pushState({}, null, `#${NAVIGATE_BUY}`)
            } else if (window.location.href && window.location.href.includes(PAYMENT_EQ_FAILED)) {
                paymentResponse = true
                paymentStatus = DANGER
                if (currentTransactionType === TRANSACTION_TYPE_GENERAL) {
                    paymentMessage.push(parse(this.props.t("buy.buy_bonus_points.purchase_failed").replace(
                        "{TRANSACTION_ID}", window.location.href.split("tid=")[1]
                    )))
                } else if (currentTransactionType === TRANSACTION_TYPE_TIERUPGRADE) {
                    paymentMessage.push(parse(this.props.t("buy.tierUpgrade.upgrade_failed_message").replace(
                        "{TRANSACTION_ID}", window.location.href.split("tid=")[1]
                    )))
                }
                else if (currentTransactionType === TRANSACTION_TYPE_GIFTMILES) {
                    paymentMessage.push(parse(this.props.t("buy.giftMiles.giftmiles_failed_message").replace(
                        "{TRANSACTION_ID}",window.location.href.split("tid=")[1])
                    ))
                }
                window.history.pushState({}, null, `#${NAVIGATE_BUY}`)
            } else if (window.location.href && window.location.href.includes(PAYMENT_EQ_CANCELLED)) {
                paymentResponse = true
                paymentStatus = WARNING
                if (currentTransactionType === TRANSACTION_TYPE_GENERAL) {
                    paymentMessage.push(parse(this.props.t("buy.buy_bonus_points.purchase_cancelled").replace(
                        "{TRANSACTION_ID}", window.location.href.split("tid=")[1]
                    )))
                } else if (currentTransactionType === TRANSACTION_TYPE_TIERUPGRADE) {
                    paymentMessage.push(parse(this.props.t("buy.tierUpgrade.upgrade_cancelled_message").replace(
                        "{TRANSACTION_ID}", window.location.href.split("tid=")[1]
                    )))
                }
                else if (currentTransactionType === TRANSACTION_TYPE_GIFTMILES) {
                    paymentMessage.push(parse(this.props.t("buy.giftMiles.giftmiles_cancelled_message").replace(
                        "{TRANSACTION_ID}",window.location.href.split("tid=")[1])
                    ))
                }
                window.history.pushState({}, null, `#${NAVIGATE_BUY}`)
            } else {
                paymentResponse = false
            }

            const response = {
                paymentResponse,
                paymentStatus,
                paymentMessage,
            }
            this.paymentResponse(response);
            removeItemFromBrowserStorage(
                BROWSER_STORAGE_KEY_PURCHASE_POINTS,
                BROWSER_STORAGE_TYPE_SESSION
            )
            removeItemFromBrowserStorage(
                BROWSER_STORAGE_KEY_TOTAL_MILES,
                BROWSER_STORAGE_TYPE_SESSION
            )
            removeItemFromBrowserStorage(
                BROWSER_STORAGE_KEY_TRANSACTION_ID,
                BROWSER_STORAGE_TYPE_SESSION
            )
            removeItemFromBrowserStorage(
                BROWSER_STORAGE_KEY_ACTIVITY_NUMBER,
                BROWSER_STORAGE_TYPE_SESSION
            )
            removeItemFromBrowserStorage(BROWSER_STORAGE_KEY_SELECTED_TAB)
            removeItemFromBrowserStorage(BROWSER_STORAGE_KEY_UPGRADED_TIER)
            this.props.fetchAccountSummary()
        }

    }

    /**
     * This method is used to render the Tab Header 
     */
    renderRadioButtonView =  () => {
        const { configurationByType, selectedTab, disabledTabs } = this.state;
        const { t } = this.props
        if (configurationByType && Object.keys(configurationByType).length > 0) {
            return Object.keys(configurationByType).map((type, index) => {
                const currentType = configurationByType[type]
                return <li key={currentType.type} onClick={() => {
                    this.setState({
                        selectedTab: currentType.type,
                        paymentMessage: [],
                        paymentStatus: EMPTY_STRING
                    })
                }} disabled={disabledTabs.includes(currentType.type)}>
                    <input type="radio" name="options" id={`option${index}`} checked={selectedTab == currentType.type}
                        data-test={`li_${currentType.type}`}
                        onChange={() => {
                            this.setState({
                                selectedTab: currentType.type,
                                paymentMessage: [],
                                paymentStatus: EMPTY_STRING
                            })
                        }}
                    />
                    <label htmlFor={`option${index}`}>{t(`buy.${currentType.type}.title`)}</label>
                </li>
            })
        }
    }

    renderTabViewHeader = () => {
        const { configurationByType, selectedTab } = this.state;
        const { t } = this.props
        if (configurationByType && Object.keys(configurationByType).length > 0) {
            return Object.keys(configurationByType).map((type, index) => {
                const currentType = configurationByType[type]
                return <a key={currentType.type} className={`nav-item nav-link ${currentType.type == selectedTab ? 'active' : ''}`}
                    id={`${currentType.type}`}
                    data-toggle="tab"
                    href={`#${currentType.type}`}
                    role="tab"
                    onClick={() => {
                        this.setState({
                            selectedTab: currentType.type,
                            paymentMessage: [],
                            paymentStatus: EMPTY_STRING
                        })
                    }}
                    data-test={`li_${currentType.type}`}
                    aria-controls={currentType.type} aria-selected={currentType.type == selectedTab ? 'true' : 'false'}>
                    <span>{t(`buy.${currentType.type}.title`)}</span>
                </a>
            })
        }

    }

    /**
     * This method is to render the tab details 
     */
    renderTabDetails = () => {
        const { selectedTab, configurationByType } = this.state
        if (configurationByType && Object.keys(configurationByType).length) {
            const config = configurationByType[selectedTab]
            if (config) {
                const pointDetails = this.getEnabledPointDetails(config.pointDetails)
                const { isProtectedApi } = this.props.config
                return {
                    [TRANSACTION_TYPE_GENERAL]: <BuyMiles
                        paymentResponse={(response) => this.paymentResponse(response)}
                        configDetails={config}
                        isProtectedApi={isProtectedApi}
                        pointDetails={pointDetails}
                        precision={getPrecision(this.props.defaultConfig)}
                        resetErrorMessage={this.resetErrorMessage}
                        makePayment={(selectedBonusPoint, transactionPin, totalMiles) =>
                            this.makePayment(selectedBonusPoint, transactionPin, pointDetails, totalMiles)}
                    />,
                    [TRANSACTION_TYPE_TIERUPGRADE]: <UpgradeTier
                        paymentResponse={(response) => this.paymentResponse(response)}
                        configDetails={config}
                        isProtectedApi={isProtectedApi}
                        pointDetails={pointDetails}
                        precision={getPrecision(this.props.defaultConfig)}
                    />,
                    [TRANSACTION_TYPE_GIFTMILES]: <GiftMiles
                        paymentResponse={(response) => this.paymentResponse(response)}
                        configDetails={config}
                        isProtectedApi={isProtectedApi}
                        pointDetails={pointDetails}
                        precision={getPrecision(this.props.defaultConfig)}
                    />
                }[selectedTab]
            }
        }
    }

    render() {
        const { config, t } = this.props
        return (
            <div className="col-lg-12" data-test="buyMilesComponent">
                <h1>{t("buy.title")}</h1>
                <p className="mb-5">{parse(t("buy.description"))} </p>
                {
                    this.state.paymentResponse &&
                    <CustomMessage message={this.state.paymentMessage} type={this.state.paymentStatus} />
                }
                <div className="form-row">
                    <div className="col-auto d-flex align-items-center">
                        <div className="form-group">
                            <div className="btn-group btn-group-toggle" data-toggle="buttons">
                                {
                                    config && config.ui && config.ui.showRadioButtonView ?
                                    <ul className="radio-wrap">
                                        {
                                            this.renderRadioButtonView()
                                        }
                                    </ul> :
                                    <nav className="tab">
                                        <div className="nav nav-tabs nav-tabs--booking" id="nav-tab" role="tablist">
                                            {
                                                this.renderTabViewHeader()
                                            }
                                        </div>
                                    </nav>
                                }
                            </div>
                        </div>
                    </div>
                </div>
                {
                    this.renderTabDetails()
                }
            </div>

        );
    }

}

BuyPoints.propTypes = {

};

BuyPoints.defaultProps = {

}

function mapStateToProps(state) {
    return {
        error: state.commonErrorReducer.error,
        config: state.configurationReducer[CONFIG_SECTION_BUYPOINT],
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        authTransaction: state.authenticateTransactionReducer.authenticateTransaction,
        buyPointData: state.buyPointReducer.buyPointData,
        acceptPayment: state.buyPointAcceptReducer.acceptPayment,
        logoutTransaction: state.logoutTransactionReducer.logoutTransaction
    }
}

const mapDispatchToProps = {
    resetError,
    authenticateTransaction,
    buyPointAction,
    transactionLogout,
    buyPointAcceptPayment,
    fetchAccountSummary
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(BuyPoints)));