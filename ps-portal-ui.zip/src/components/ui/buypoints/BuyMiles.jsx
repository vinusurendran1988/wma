import React, { Component } from 'react'
import parse from 'html-react-parser';
import { withTranslation } from 'react-i18next';
import { withSuspense,
     getTransactionFee,
     getPointsArray,
     defaultSearchDropDownTemplate,
     numberWithCommas,
     isEmptyOrSpaces
} from '../../common/utils';
import { connect } from 'react-redux';
import {
    PAYMENT_MESSAGE,
    PAYMENT_STATUS,
    PAYMENT_RESPONSE
} from './Constants'

import {
    ID_SPINNER_PROCEED_TO_PAY,
    CURRENT_MILES,
    TOTAL_MILES
} from './Constants'

import {
    _URL_BUY_PAYMENT_CANCELLED,
    _URL_BUY_PAYMENT_FAILED,
    _URL_BUY_PAYMENT_SUCCESS,
    _URL_BUY_PAYMENT_REDIRECT
} from '../../common/config/config'

import {
    authenticateTransaction,
    buyPointAction,
    buyPointAcceptPayment,
    transactionLogout
} from './action'

import {
    fetchAccountSummary
} from '../../common/middleware/redux/commonAction'
import { NAVIGATE_BUY } from '../../common/utils/urlConstants';
import {
    getItemFromBrowserStorage,
    BROWSER_STORAGE_KEY_CURRENCY_CODE,
    BROWSER_STORAGE_TYPE_SESSION,
    removeItemFromBrowserStorage,
    BROWSER_STORAGE_KEY_MISSING_POINTS
} from '../../common/utils/storage.utils';
import Button from '../../common/components/fieldbank/Button';
import SearchDropdown from '../../common/components/fieldbank/SearchDropdown';
import FilterDropDown from '../../common/components/fieldbank/FilterDropDown';

/**
 * @name BuyMiles component.
 * @description Component to Buy miles/points.
 *
 */
class BuyMiles extends Component {
    constructor(props) {
        super(props);
        this.state = {
            currencyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_CURRENCY_CODE),
            agreeTerms: false,
            selectedBonusPoint: 0,
            totalMiles: 0,
            transactionPin: "",
            currentMiles: -1,
            buypointSucces: false,
            btnProceedToPay: false,
            paymentResponse: false,
            paymentStatus: "",
            paymentMessage: []
        }
        this.handleAgreeTermsChanged = this.handleAgreeTermsChanged.bind(this)
        this.handleBonusPointChange = this.handleBonusPointChange.bind(this)
        this.handleInputChange = this.handleInputChange.bind(this)
    }

    /**
     * The componentDidMount() method is called after the component is rendered
     */
    componentDidMount() {
        if (this.props.pointDetails && this.props.pointDetails.length) {
            let newState = {}
            // this.setMissingMiles(newState);
            newState['selectedBonusPoint'] = getPointsArray(this.props.pointDetails[0])[0].toString()
            this.setState(newState)
        }
    }

    /**
     * Handling of updations when props or state are updated.
     * @param {*} prevProp
     */
    componentDidUpdate(prevProps) {
        let newState = {}
        if (prevProps.configDetails != this.props.configDetails) {
            //this.setMissingMiles(newState);
        }

        if (this.props.acceptPayment &&
            JSON.stringify(prevProps.acceptPayment) != JSON.stringify(this.props.acceptPayment) &&
            this.props.acceptPayment.acceptPaymentStatus) {
            if (!this.props.isProtectedApi)
                this.resetBuyForm(false)
        }

        if (this.props.logoutTransaction &&
            JSON.stringify(prevProps.logoutTransaction) != JSON.stringify(this.props.logoutTransaction)) {
            this.resetBuyForm(false)
        }

        if (
            this.props.accountSummary &&
            this.state.currentMiles == -1
        ) {
            let selectedBonusPoint = getPointsArray(this.props.pointDetails[0])[0]
            const currentMiles = this.getCurrentMiles()
            if (this.state[CURRENT_MILES] != currentMiles) {
                newState[CURRENT_MILES] = currentMiles
            }

            const totalPoints = this.calculateTotalMiles(currentMiles, selectedBonusPoint)
            if (this.state[TOTAL_MILES] != totalPoints) newState[TOTAL_MILES] = totalPoints
        }
        if (Object.keys(newState).length > 0) this.setState(newState)

    }

    setMissingMiles = (newState) => {
        const missingPoints = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MISSING_POINTS, BROWSER_STORAGE_TYPE_SESSION);
        const pointsArray = getPointsArray(this.props.configDetails.pointDetails[0]);
        newState["selectedBonusPoint"] = pointsArray[0];
        if (missingPoints && missingPoints > 0) {
            const closest = this.getNextHighestIndex(pointsArray, missingPoints);
            newState["selectedBonusPoint"] = pointsArray[closest];
            removeItemFromBrowserStorage(BROWSER_STORAGE_KEY_MISSING_POINTS, BROWSER_STORAGE_TYPE_SESSION);
        }
    }

    /**
     * Method to get the current miles
     */
    getCurrentMiles() {
        const { accountSummary, configDetails } = this.props
        if(accountSummary && configDetails) {            
            const pointType = accountSummary.pointDetails.find(p=> p.pointType === configDetails.pointDetails[0].pointType)
            return pointType.points
        }
        return this.state[CURRENT_MILES]!=undefined?this.state[CURRENT_MILES]:0
    }
    /**
     * This method is used to handle the input change from the Pin Text box
     * @param {*} field
     * @param {*} event
     */
    handleInputChange(field, event) {
        if (!isNaN(event.target.value)) {
            this.setState({
                [field]: event.target.value,
                btnProceedToPay: (field === "transactionPin" && this.state.agreeTerms && event.target.value.length >= 4),
                paymentResponse: false,
                paymentStatus: "",
                paymentMessage: []
            })
        }
    }

    /**
     * Method to handle the bonus point change in the Search DropDown Field
     * @param {*} e
     */
    handleBonusPointChange(e) {
        const selectedBonusPoint = e;
        const totalMiles = this.calculateTotalMiles(this.state.currentMiles, selectedBonusPoint)
        window.history.pushState({}, null, `#${NAVIGATE_BUY}`)
        this.props.resetErrorMessage()
        this.setState({
            selectedBonusPoint,
            totalMiles,
            paymentResponse: false,
            paymentStatus: "",
            paymentMessage: [],
            agreeTerms: !isEmptyOrSpaces(selectedBonusPoint+"") && 
                        parseFloat(selectedBonusPoint) > 0 && this.state.agreeTerms 
        })
    }

    /**
     * This method is used to calculate the current total miles
     * @param {*} currentMiles
     * @param {*} selectedBonusPoint
     */
    calculateTotalMiles(currentMiles, selectedBonusPoint) {
        if(selectedBonusPoint == "" || selectedBonusPoint == undefined){
            return parseFloat(currentMiles)
        }
        return parseFloat(currentMiles) + parseFloat(selectedBonusPoint)
    }

    /**
     * Method to reset the payment response in the parent class[BuyPoints]
     */
    resetPaymentResponse() {
        return {
            paymentResponse: false,
            paymentStatus: "",
            paymentMessage: []
        }
    }

    /**
     * Method to handle the AgreeTerms change from the Terms and condition checkbox
     * @param {*} e
     */
    handleAgreeTermsChanged(e) {
        let currentMiles = this.getCurrentMiles()
        window.history.pushState({}, null, `#${NAVIGATE_BUY}`)
        this.setState({
            agreeTerms: !this.state.agreeTerms,
            btnProceedToPay: !this.props.isProtectedApi && !this.state.agreeTerms,
            totalMiles: this.calculateTotalMiles(currentMiles, this.state.selectedBonusPoint)
        })
        this.props.paymentResponse(this.resetPaymentResponse())

    }

    /**
     * This method is invoked when the cancel button is been clicked
     * and when the payment is over to reset the buy miles form
     * @param {*} clearMessage
     */
    resetBuyForm = (clearMessage = true) => {
        let newState = {
            selectedBonusPoint: getPointsArray(this.props.pointDetails[0])[0].toString(),
            transactionPin: "",
            agreeTerms: false,
            btnProceedToPay: false
        }
        if (clearMessage) {
            newState[PAYMENT_RESPONSE] = false
            newState[PAYMENT_STATUS] = ""
            newState[PAYMENT_MESSAGE] = []
        }
        this.setState(newState)
        this.props.resetErrorMessage()
    }

    /**
     * This method is used to get the Transfer points list
     * @param {*} pointsList
     */
    getTransferPointsList(pointsList) {
        let transferPointsList = [];
        pointsList.map(points => {
            transferPointsList.push({
                label: points.toString(),
                value: points.toString()
            });
        })
        return transferPointsList
    }

    render() {
        const { configDetails, t } = this.props
        let transferPointsList = [];
        transferPointsList = this.getTransferPointsList(getPointsArray(this.props.pointDetails[0]));
        return (
            configDetails && configDetails.pointDetails && Object.keys(configDetails.pointDetails[0]).length > 0 &&
            <div className="form-row" data-test="generalBuyComponent">
                <div className="col-lg-8 col-md-12">
                    <div className="toggle1">
                        <div className="step1">
                            <div className="form-row">
                                <div className="col-lg-6 col-md-6">
                                    <div className="form-group" >
                                        {
                                            configDetails && configDetails.isPacket ?
                                            <FilterDropDown
                                                label={t("buy.buy_bonus_points.number_of_points")}
                                                placeholder={t("buy.buy_bonus_points.number_of_points")}
                                                options={transferPointsList}
                                                isRequired={true}
                                                id="selectedBonusPoint"
                                                value={this.state.selectedBonusPoint}
                                                onChange={(e) =>
                                                    this.handleBonusPointChange(e)
                                                }
                                                testIdentifier="selectedPoints"
                                                info=""
                                                enabled={true}
                                            /> :
                                            <SearchDropdown
                                                label={t("buy.buy_bonus_points.number_of_points")}
                                                placeholder={t("buy.buy_bonus_points.number_of_points")}
                                                options={transferPointsList}
                                                isRequired={true}
                                                id="selectedBonusPoint"
                                                value={this.state.selectedBonusPoint}
                                                itemTemplate={(e) => defaultSearchDropDownTemplate(e)}
                                                onChange={(e) =>
                                                    this.handleBonusPointChange(e)
                                                }
                                                testIdentifier="selectedPoints"
                                                enabled={true}
                                            />
                                        }
                                    </div>
                                </div>
                                {
                                    <div className="col-lg-6 col-md-6">
                                        <div className="form-group">
                                            <label htmlFor="f2" className="d-block">{t("buy.buy_bonus_points.total_payable")}</label>
                                            <input className="" type="text" readOnly
                                                value={
                                                    this.state.currencyCode + " " + parseFloat(getTransactionFee(this.props.pointDetails[0].transactionFee, this.state.selectedBonusPoint, configDetails.pointDetails[0].isPaymentRequired).toFixed(this.props.precision))
                                                }
                                                id="f2"
                                                disabled
                                                data-test="payableAmount" />
                                        </div>
                                    </div>
                                }
                            </div>
                            {
                                this.state.agreeTerms == 1 &&
                                <div className="form-row">
                                    <div className="col-12">
                                        <div className="balance-text alert-info p-3 text-center mb-3" role="alert">
                                            {
                                                parse(t("buy.buy_bonus_points.after_purchase_message").replace("{TOTAL_AMOUNT_AFTER}", numberWithCommas(this.state.totalMiles)))
                                            }
                                        </div>
                                    </div>
                                </div>
                            }
                            {
                                this.state.agreeTerms == 1 && !this.state.buypointSucces && this.props.isProtectedApi &&
                                <div className="form-row">
                                    <div className="col-lg-4 col-md-6">
                                        <div className="form-group">
                                            <label htmlFor="pinTextBox">{t("buy.buy_bonus_points.enter_pin")}</label>
                                            <input className="" type="password" placeholder={t("buy.buy_bonus_points.enter_pin")} id="pinTextBox" maxLength={4} value={this.state.transactionPin} onChange={(e) => this.handleInputChange("transactionPin", e)} data-test="PinTextBox" />
                                        </div>
                                    </div>
                                </div>
                            }
                            {
                                !this.state.buypointSucces &&
                                <div className="form-row">
                                    <div className="col-lg-7 col-md-12 d-flex align-items-center">
                                        <div className="form-check form-check-inline">
                                            <input className="form-check-input" type="checkbox" id="inlineCheckbox1" value={this.state.agreeTerms} checked={this.state.agreeTerms} onChange={(e) => this.handleAgreeTermsChanged(e)} data-test="AcceptTermsCheckbox" disabled={isEmptyOrSpaces(this.state.selectedBonusPoint+"" ) || parseFloat(this.state.selectedBonusPoint) <= 0}/>
                                            <label className="form-check-label" htmlFor="inlineCheckbox1">
                                                {parse(t("buy.buy_bonus_points.accept_text_one"))}
                                                {parse(t("buy.buy_bonus_points.accept_text_two"))}
                                            </label>
                                        </div>
                                    </div>
                                    <div className="col-lg-5 col-md-12 text-lg-right btn-wrap btn-wrap--grp">
                                        <Button
                                            className="btn btn-secondary"
                                            handleOnClick={() => this.resetBuyForm()}
                                            id="buy_cancle_btn"
                                            testIdentifier="btnCancel"
                                            label={t("buy.buy_bonus_points.cancel")} />
                                        <Button
                                            className="btn btn-primary"
                                            handleOnClick={() => this.props.makePayment(
                                                this.state.selectedBonusPoint,
                                                this.state.transactionPin,
                                                this.state.totalMiles)}
                                            id={ID_SPINNER_PROCEED_TO_PAY}
                                            testIdentifier="btnProceedTobuy"
                                            enabled={this.state.btnProceedToPay}
                                            label={t("buy.buy_bonus_points.proceed_to_pay")} />
                                    </div>
                                </div>
                            }
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

BuyMiles.propTypes = {
};

function mapStateToProps(state) {
    return {
        accountSummary: state.accountSummaryReducer.accountSummary,
        acceptPayment: state.buyPointAcceptReducer.acceptPayment,
        logoutTransaction: state.logoutTransactionReducer.logoutTransaction,
    }
}
const mapDispatchToProps = {
    authenticateTransaction,
    buyPointAction,
    transactionLogout,
    buyPointAcceptPayment,
    fetchAccountSummary
}
export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(BuyMiles)));