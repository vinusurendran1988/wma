import React, { Component } from 'react'
import parse from 'html-react-parser';
import { withTranslation } from 'react-i18next';
import {
    withSuspense,
    numberWithCommas
} from '../../common/utils';
import { connect } from 'react-redux';
import {
    PAYMENT_MESSAGE,
    PAYMENT_STATUS,
    PAYMENT_RESPONSE,
    WARNING,
    SESSION_KEY_EQ,
    EMPTY_STRING,
    ONE_ITEM,
    PURCHASE_TIER_KEY
} from './Constants'

import {
    ID_SPINNER_PROCEED_TO_PAY,
    CURRENT_MILES
} from './Constants'

import {
    _URL_TIERUPGRADE_PAYMENT_CANCELLED,
    _URL_TIERUPGRADE_PAYMENT_FAILED,
    _URL_TIERUPGRADE_PAYMENT_SUCCESS,
    _URL_TIERUPGRADE_PAYMENT_REDIRECT
} from '../../common/config/config'

import {
    simulateRuleService,
    tierUpgrade
} from './action'

import {
    fetchAccountSummary,
    fetchConfiguration
} from '../../common/middleware/redux/commonAction'
import { NAVIGATE_BUY } from '../../common/utils/urlConstants';
import Button from '../../common/components/fieldbank/Button';
import {
    getItemFromBrowserStorage,
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
    BROWSER_STORAGE_KEY_CURRENCY_CODE,
    BROWSER_STORAGE_TYPE_SESSION,
    setItemToBrowserStorage,
    BROWSER_STORAGE_KEY_SELECTED_TAB,
    BROWSER_STORAGE_KEY_ACTIVITY_CODE,
    BROWSER_STORAGE_KEY_POINT_DETAILS,
    BROWSER_STORAGE_KEY_UPGRADED_TIER
} from '../../common/utils/storage.utils';
import { CONFIG_SECTION_SUMMARY, CONFIG_SECTION_DEFAULT, CONFIG_SECTION_SIMULATE_RULE } from '../../common/utils/Constants';
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';

/**
 * @name UpgradeTier component.
 * @description Component to Upgrade Tier.
 * @author Gowthaman A
 * 
 */
class UpgradeTier extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedUpgradeTier: "",
            agreeTerms: false,
            buypointSucces: false,
            btnProceedToPay: false,
            upgradeableTiers: [],
            paymentResponse: false,
            paymentStatus: "",
            paymentMessage: [],
            error: []
        }
    }

    /**
     * The componentDidMount() method is called after the component is rendered
     */
    componentDidMount() {
        if (!this.props.simulateRuleConfig) {
            this.props.fetchConfiguration(CONFIG_SECTION_SIMULATE_RULE)
        }
        if (!this.props.accountSummary) {
            this.props.fetchAccountSummary()
        } else {
            this.setUpgradeableTiers()
        }

    }

    /**
     * Handling of updations when props or state are updated.
     * @param {*} prevProp
     */
    componentDidUpdate(prevProps, prevState) {

        if(prevProps.accountSummary != this.props.accountSummary){
            this.setUpgradeableTiers()
        }

        if (prevState.upgradeableTiers != this.state.upgradeableTiers || this.props.simulateRuleConfig != prevProps.simulateRuleConfig) {
            const { accountSummary, summaryConfig, t } = this.props
            const loyaltyPoint = this.getLoyaltyPoints(accountSummary, summaryConfig);
            let error = []
            if (this.state.upgradeableTiers.length == 0) {
                error.push(t("buy.tierUpgrade.higher_Tier_Member"))
            } else {
                let result = ""
                this.state.upgradeableTiers.map(tier => {
                    if (tier.validations) {
                        tier.validations.map(validation => {
                            if (validation.condition.includes("{MILES}")) {
                                result = validation.condition.replace("{MILES}", loyaltyPoint)
                                if (!eval(result)) {
                                    error.push(t(validation.errorMessage))
                                }
                            }
                        })
                    }
                })
            }
            if(error.length > 0){
                this.showMessage(error)
            }else if(this.props.simulateRuleConfig){
                this.invokeSimulateRule()
            }
        }

        if (prevProps.simulateRule != this.props.simulateRule) {
            const { t } = this.props
            let error = []
            let result = ""
            this.state.upgradeableTiers.map(tier => {
                if (tier.validations) {
                    tier.validations.map(validation => {
                        if (validation.condition.includes("{CURRENT_MILES}") && validation.condition.includes("{POINTS_TO_PURCHASE}")) {
                            const currentMiles = this.getCurrentMiles()
                            const pointsToPurchase = this.getPointsToPurchase(this.props.simulateRule)
                            result = validation.condition.replace("{CURRENT_MILES}", currentMiles).replace("{POINTS_TO_PURCHASE}", pointsToPurchase)
                            if (!eval(result)) {
                                let res = pointsToPurchase - currentMiles
                                error.push(t(validation.errorMessage).replace("{REQUIRED_MILES}", pointsToPurchase)
                                    .replace("{UPGRADEABLETIER}", this.state.selectedUpgradeTier ))
                            }
                        }
                    })
                }
            })
            this.showMessage(error)
        }

        if (prevProps.tierUpgradeResponse != this.props.tierUpgradeResponse) {
            this.redirectPayment(this.props.tierUpgradeResponse)
        }
    }

    showMessage(error){
        this.setState({
            error
        }, () =>{
            this.props.paymentResponse({
                paymentResponse: true,
                paymentStatus: WARNING,
                paymentMessage: error
            })
        })
    }

    /**
     * @description Method to set the UpgradeableTiers once the component is loaded
     */
    setUpgradeableTiers() {
        const { accountSummary, configDetails, t } = this.props
        if (configDetails) {
            const upgradeableTiers = this.getUpgradeableTier(configDetails, accountSummary)
            if(upgradeableTiers && upgradeableTiers.length > 0){
                this.setState({
                    upgradeableTiers,
                    selectedUpgradeTier: upgradeableTiers[0].tierName
                })
            }else if(this.state.error.length == 0){
                this.showMessage([t("buy.tierUpgrade.higher_Tier_Member")])
            }
        }
    }

    /**
     * @description Method to get the upgradeableTiers based on the current config
     * @param {*} config 
     * @param {*} accountSummary 
     */
    getUpgradeableTier(config, accountSummary) {
        let upgradeableTier = []
        if (config && 
            config.purchaseTier && 
            accountSummary && 
            accountSummary.tierName && 
            config.purchaseTier[accountSummary.tierName] &&
            config.upgradableTierCodes &&
            (config.upgradableTierCodes.length == 0 || config.upgradableTierCodes.includes(accountSummary.tierCode))){
            upgradeableTier = config.purchaseTier[accountSummary.tierName]
        }
        return upgradeableTier
    }

    /**
     * @description Method to get the current Loyalty Points
     * @param {*} accountSummary 
     * @param {*} summaryConfig 
     */
    getLoyaltyPoints = (accountSummary, summaryConfig) => {
        let loyaltyPoint = 0
        let pointTypeList
        summaryConfig && summaryConfig.ui.layout.elements.pointDropdown.fields.map((field) => {
            if (field.name == summaryConfig.ui.defaultPointType) {
                pointTypeList = field.data.pointTypes
            }
        })
        accountSummary.pointDetails.map((pointData) => {
            if (pointTypeList.includes(pointData.pointType)) loyaltyPoint += pointData.points
        })
        return loyaltyPoint;
    }

    /**
     * @description Redirect to the Payment Site after the Purchase Tier API Call
     * @param {*} tierUpgrade 
     */
    redirectPayment(tierUpgrade) {
        if (tierUpgrade && tierUpgrade.redirectURL && this.props.pointDetails[0].isPaymentRequired) {
            var res = tierUpgrade.redirectURL.split(SESSION_KEY_EQ);
            window.location.href = res[0] + SESSION_KEY_EQ + encodeURIComponent(res[1]);
        } else if (!this.props.pointDetails[0].isPaymentRequired) {
            this.props.showMessage()
        }
    }

    /**
     * Method to get the current miles
     */
    getCurrentMiles() {
        const { accountSummary, configDetails } = this.props
        if (accountSummary && configDetails) {
            const pointType = accountSummary.pointDetails.find(p => p.pointType === configDetails.pointDetails[0].pointType)
            return pointType.points
        }
        return this.state[CURRENT_MILES] != undefined ? this.state[CURRENT_MILES] : 0
    }

    /**
     * Method to reset the payment response in the parent class[BuyPoints]
     */
    resetPaymentResponse() {
        return {
            paymentResponse: false,
            paymentStatus: "",
            paymentMessage: []
        }
    }

    /**
     * Method to handle the AgreeTerms change from the Terms and condition checkbox
     * @param {*} e
     */
    handleAgreeTermsChanged(e) {
        window.history.pushState({}, null, `#${NAVIGATE_BUY}`)
        this.setState({
            agreeTerms: !this.state.agreeTerms,
            btnProceedToPay: !this.props.isProtectedApi && !this.state.agreeTerms
        })
        this.props.paymentResponse(this.resetPaymentResponse())

    }

    handleChange(e) {
        const selectedUpgradeTier = e
        this.setState({
            selectedUpgradeTier
        }, () => {
            this.invokeSimulateRule()
        })
    }

    /**
     * This method is invoked when the cancel button is been clicked
     * and when the payment is over to reset the buy miles form
     * @param {*} clearMessage
     */
    resetBuyForm = (clearMessage = true) => {
        const { accountSummary, configDetails } = this.props
        const upgradeableTier = this.getUpgradeableTier(configDetails, accountSummary)
        let newState = {
            selectedUpgradeTier: upgradeableTier.length > 0 ? upgradeableTier : "",
            agreeTerms: false,
            btnProceedToPay: false
        }
        if (clearMessage) {
            newState[PAYMENT_RESPONSE] = false
            newState[PAYMENT_STATUS] = ""
            newState[PAYMENT_MESSAGE] = []
        }
        this.setState(newState)
    }

    /**
     * @description This Method is to invoke the Simulate Rule API to get the required
     * points /Miles to upgrade to the next tier
     */
    invokeSimulateRule(tierCode = this.props.accountSummary.tierCode){

        const { summaryConfig, accountSummary, simulateRuleConfig } = this.props
        const loyaltyPoint = this.getLoyaltyPoints(accountSummary, summaryConfig);
        const currentRuleType = this.getCurrentRuleType(simulateRuleConfig)
        const executionItems = this.setExecutionItems(currentRuleType, loyaltyPoint, tierCode)
        const request = {
            object: {
                companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                ruleType: currentRuleType.ruleType,
                partnerCode: "",
                rewardCode: "",
                activityCode: currentRuleType.activityCode,
                excludeOptimizationRule: true,
                executionItems
            }
        }
        this.props.simulateRuleService(request)
    }

    /**
     * @description This method is to get the current Rule Type from the Simulate Rule Config
     * @param {*} simulateRuleConfig 
     */
    getCurrentRuleType = (simulateRuleConfig) => {
        let currentRuleType = []
        simulateRuleConfig && simulateRuleConfig.ruleTypes &&
            simulateRuleConfig.ruleTypes.map(ruleType => {
                if (ruleType.key == PURCHASE_TIER_KEY) {
                    currentRuleType = ruleType
                }
            })
        return currentRuleType
    }

    setExecutionItems = (currentRuleType, loyaltyPoint, tierCode) => {
        if (currentRuleType && currentRuleType.executionItems) {
            const executionItems = [ ...currentRuleType.executionItems ]
            executionItems.map(executionItem => {
                executionItem.variables.map(variable => {
                    if (variable.code == "LTYPNT") {
                        variable["value"] = loyaltyPoint
                    } else if (variable.code == "TIR") {
                        variable["value"] = tierCode
                    }
                })

            })
            return executionItems
        }
        return []
    }

    /**
     * @description This method is to call Purchase Tier API, On clicking the Proceed Button
     */
    proceedToPurchaseTier() {

        const { configDetails, summaryConfig, simulateRule, defaultConfig, accountSummary } = this.props
        const { activityCode, activityType, type, pointDetails, terms_and_conditions, description, bookingChannel } = configDetails
        const { isPaymentRequired, pointType, transactionType } = pointDetails[0]
        const loyaltyPoint = this.getLoyaltyPoints(accountSummary, summaryConfig);
        const pointsToPurchase = this.getPointsToPurchase(simulateRule)
        setItemToBrowserStorage(BROWSER_STORAGE_KEY_SELECTED_TAB, type)
        setItemToBrowserStorage(BROWSER_STORAGE_KEY_UPGRADED_TIER, this.state.selectedUpgradeTier)
        setItemToBrowserStorage(BROWSER_STORAGE_KEY_ACTIVITY_CODE, activityCode, BROWSER_STORAGE_TYPE_SESSION)
        setItemToBrowserStorage(BROWSER_STORAGE_KEY_POINT_DETAILS, JSON.stringify(pointDetails))
        const object = {
            companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
            programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
            membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
            activityCode,
            activityType,
            transactionType: type,
            quoteReferenceNumber: EMPTY_STRING,
            tierCode: accountSummary.tierCode,
            balance: loyaltyPoint,
            points: [{
                points: pointsToPurchase,
                pointType,
                balance: this.getCurrentMiles()
            }],
            adhocAttributes: [
                {
                    attributeCode: "",
                    attributeValue: ""
                }
            ],
        }
        if (isPaymentRequired) {
            const paymentGateway = {}
            paymentGateway["cancel_url"] = _URL_TIERUPGRADE_PAYMENT_CANCELLED
            paymentGateway["success_url"] = _URL_TIERUPGRADE_PAYMENT_SUCCESS
            paymentGateway["failure_url"] = _URL_TIERUPGRADE_PAYMENT_FAILED
            paymentGateway["redirect_url"] = _URL_TIERUPGRADE_PAYMENT_REDIRECT
            paymentGateway["terms_and_conditions"] = terms_and_conditions

            if (defaultConfig) {
                const defaultConfig = getCurrentProgramFromDefaultConfig(this.props.defaultConfig)
                if (transactionType == "P") {
                    paymentGateway["purchase_totals"] = {
                        show_miles_only: "Y",
                        order_amount: 0,
                        order_currency: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_CURRENCY_CODE),
                        miles: {
                            redeemed_miles: pointsToPurchase
                        },
                    }
                } else if (transactionType == "C") {
                    paymentGateway["purchase_totals"] = {
                        show_miles_only: "N",
                        order_amount: 0,
                        order_currency: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_CURRENCY_CODE),
                    }
                }
                paymentGateway["point_of_sale"] = {
                    booking_channel: bookingChannel.web,
                    pos_city: defaultConfig.defaults.posCity,
                    pos_country: defaultConfig.defaults.posCountry
                }
            }
            paymentGateway["order_details"] = {
                order_info: description,
                order_type: "",
                items: [{
                    airline_data: {
                        origin_destination: [{
                            segments: [{}]
                        }]
                    },
                    quantity: ONE_ITEM,
                    total_price: 0
                }]
            }
            object["paymentGateway"] = paymentGateway
        }

        this.props.tierUpgrade({object})

    }

    /**
     * @description This method is to get the points required to upgrade the tier
     * @param {*} simulateRule 
     */
    getPointsToPurchase(simulateRule) {
        let pointsToPurchase = undefined
        if (simulateRule) {
            simulateRule && simulateRule.executionItems && simulateRule.executionItems.map((item) => {
                item.variables.map((pointDetail) => {
                    pointsToPurchase = parseFloat(pointDetail.value)
                })
            })
        }
        return pointsToPurchase
    }

    render() {
        const { t, configDetails, accountSummary, simulateRule } = this.props
        const { upgradeableTiers, error } = this.state
        const pointsToPurchase = this.getPointsToPurchase(simulateRule)
        return (
            configDetails && accountSummary &&
            <div className="form-row" data-test="tierUpgradeComponent">
                <div className="col-lg-8 col-md-12">
                    <div className="toggle1">
                        <div className="step1">
                            <div className="form-row">
                                <div className="col-lg-6 col-md-6">
                                    <div className="form-group" >
                                        <label htmlFor="f2" className="d-block">{t("buy.tierUpgrade.currentTier")}</label>
                                        <input className="" type="text" readOnly
                                            value={accountSummary.tierName}
                                            id="f2"
                                            disabled
                                            data-test="currentTier" />
                                    </div>
                                </div>
                                <div className="col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label htmlFor="select_upgradeTier" className="d-block">{t("buy.tierUpgrade.upgradeTier")}
                                            <span className="text-warning">*</span></label>
                                        <select
                                            id="select_upgradeTier"
                                            data-test="upgradeTier"
                                            value={this.state.selectedUpgradeTier}
                                            onChange={(e) => {
                                                this.handleChange(e.target.value);
                                            }}
                                            disabled={upgradeableTiers.length == 0 || ( upgradeableTiers.length == 1 && error.length > 0 )}>
                                            {
                                                upgradeableTiers &&
                                                upgradeableTiers.map(tiers => {
                                                    return <option key={tiers.tierCode} value={tiers.tierCode}>
                                                        {tiers.tierName}</option>
                                                })
                                            }
                                        </select>
                                    </div>
                                </div>
                            </div>
                            {
                                this.state.agreeTerms == 1 &&
                                <div className="form-row">
                                    <div className="col-12">
                                        <div className="balance-text alert-info p-3 text-center mb-3" role="alert">
                                            {
                                                parse(t("buy.tierUpgrade.points_need_to_buy").replace("{POINTS_NEEDED_TOBUY}", numberWithCommas(pointsToPurchase)))
                                            }
                                        </div>
                                    </div>
                                </div>
                            }
                            {
                                !this.state.buypointSucces &&
                                <div className="form-row">
                                    <div className="col-lg-7 col-md-12 d-flex align-items-center">
                                        <div className="form-check form-check-inline">
                                            <input className="form-check-input" type="checkbox" id="inlineCheckbox1"
                                                value={this.state.agreeTerms}
                                                disabled={error.length > 0}
                                                checked={this.state.agreeTerms}
                                                onChange={(e) => this.handleAgreeTermsChanged(e)}
                                                data-test="AcceptTermsCheckbox" />
                                            <label className="form-check-label" htmlFor="inlineCheckbox1">
                                                {parse(t("buy.buy_bonus_points.accept_text_one"))}
                                                {parse(t("buy.buy_bonus_points.accept_text_two"))}
                                            </label>
                                        </div>
                                    </div>
                                    <div className="col-lg-5 col-md-12 text-lg-right btn-wrap btn-wrap--grp">
                                        <Button
                                            className="btn btn-secondary"
                                            handleOnClick={() => this.resetBuyForm()}
                                            id="buy_cancle_btn"
                                            testIdentifier="btnCancel"
                                            enabled={error.length == 0}
                                            label={t("buy.buy_bonus_points.cancel")} />
                                        <Button
                                            className="btn btn-primary"
                                            handleOnClick={() => this.proceedToPurchaseTier()}
                                            id={ID_SPINNER_PROCEED_TO_PAY}
                                            testIdentifier="btnProceedTobuy"
                                            enabled={this.state.btnProceedToPay && error.length == 0}
                                            label={t("buy.tierUpgrade.proceed")} />
                                    </div>
                                </div>
                            }
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

UpgradeTier.propTypes = {
};

function mapStateToProps(state) {
    return {
        accountSummary: state.accountSummaryReducer.accountSummary,
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        summaryConfig: state.configurationReducer[CONFIG_SECTION_SUMMARY],
        simulateRuleConfig: state.configurationReducer[CONFIG_SECTION_SIMULATE_RULE],
        simulateRule: state.simulateRuleReducer.simulateRule,
        tierUpgradeResponse: state.tierUpgradeReducer.tierUpgrade
    }
}
const mapDispatchToProps = {
    fetchConfiguration,
    fetchAccountSummary,
    simulateRuleService,
    tierUpgrade,
}
export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(UpgradeTier)));