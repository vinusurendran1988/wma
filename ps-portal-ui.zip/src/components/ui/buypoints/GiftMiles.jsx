import parse from 'html-react-parser';
import React from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import Button from '../../common/components/fieldbank/Button';
import FilterDropDown from '../../common/components/fieldbank/FilterDropDown';
import SearchDropdown from '../../common/components/fieldbank/SearchDropdown';
import { _URL_GIFTPOINT_PAYMENT_CANCELLED, _URL_GIFTPOINT_PAYMENT_FAILED, _URL_GIFTPOINT_PAYMENT_REDIRECT, _URL_GIFTPOINT_PAYMENT_SUCCESS } from '../../common/config/config';
import {
    fetchConfiguration, fetchCurrentLoginUserData, resetError, validateMemberDetails
} from '../../common/middleware/redux/commonAction';
import {
    defaultSearchDropDownTemplate, getPointsArray,
    getPrecision, withSuspense
} from '../../common/utils';
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';
import { CONFIG_SECTION_RETRIEVE_QUOTE } from '../../common/utils/Constants';
import {
    BROWSER_STORAGE_KEY_ACTIVITY_CODE, BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_CURRENCY_CODE, BROWSER_STORAGE_KEY_MEMBERSHIP_NO, BROWSER_STORAGE_KEY_POINT_DETAILS, BROWSER_STORAGE_KEY_PROGRAM_CODE, BROWSER_STORAGE_KEY_SELECTED_TAB,
    BROWSER_STORAGE_KEY_UPGRADED_TIER, BROWSER_STORAGE_TYPE_SESSION, getItemFromBrowserStorage, setItemToBrowserStorage
} from '../../common/utils/storage.utils';
import { NAVIGATE_BUY } from '../../common/utils/urlConstants';
import { fetchRetrieveQuote } from '../extendexpiry/actions';
import { EMPTY_STRING } from '../extendexpiry/Constants';
import { giftPoints } from './action';
import {
    ID_SPINNER_PROCEED_TO_PAY, MILES_TO_GIFT,
    ONE_ITEM,
    SESSION_KEY_EQ, WARNING
} from './Constants';

const initialData = {
    membershipNumber: "",
    lastName: "",
    firstName: "",
    recipientName: "",
    milesToGift: undefined,
    totalPayableAmount: 0,
    specialMessage: "",
    agreeTerms: false,
    btnProceedToGift: false,
    specialMessageValue: "",
    currencyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_CURRENCY_CODE)
}

class GiftMiles extends React.Component {

    constructor(props) {
        super(props);
        const data = JSON.parse(JSON.stringify(initialData))
        this.state = {
            data
        }
    }

    componentDidMount = () => {
        if (!this.props.currentUserData) {
            this.props.fetchCurrentLoginUserData();
        }
        if(!this.props.retrieveQuoteConfig){
            this.props.fetchConfiguration(CONFIG_SECTION_RETRIEVE_QUOTE)
        }
    }

    componentDidUpdate = (prevProps, prevState) => {
        if(prevProps.validateMember != this.props.validateMember){
            const { validateMember } = this.props
            const { data } = this.state
            if(validateMember && validateMember.displayName){
                data.recipientName = validateMember.displayName
                this.setState({
                    data
                })
            }
        }
        if(prevProps.retrieveQuote != this.props.retrieveQuote){
            const { retrieveQuote } = this.props
            const { data } = this.state
            if(retrieveQuote && retrieveQuote.amount){
                data.totalPayableAmount = retrieveQuote.amount
                this.setState({
                    data
                })
            }
        }

        if (prevProps.giftPointData != this.props.giftPointData) {
            this.redirectPayment(this.props.giftPointData)
        }
    }

    handleChange(key, value) {
        this.resetErrors()
        if(key == MILES_TO_GIFT){
            this.getTotalPayableAmount(value)
        }
        const { data } = this.state;
        data[key] = value;
        data.agreeTerms = false
        this.setState({
            data
        })
    }

    resetErrors = () => {
        this.props.resetError()
        this.props.paymentResponse({
            paymentResponse: false,
            paymentStatus: "",
            paymentMessage: []
        })
    }

    
    /**
     * @description Redirect to the Payment Site after the Purchase Tier API Call
     * @param {*} giftPointData
     */
     redirectPayment(giftPointData) {
        if (giftPointData && giftPointData.redirectURL && this.props.pointDetails[0].isPaymentRequired) {
            var res = giftPointData.redirectURL.split(SESSION_KEY_EQ);
            window.location.href = res[0] + SESSION_KEY_EQ + encodeURIComponent(res[1]);
        } else if (!this.props.pointDetails[0].isPaymentRequired) {
            this.props.showMessage()
        }
    }

    getCurrentRetrieveQuoteConfig = (retrieveQuoteConfig) => {
        let currentRetrieveQuoteConfig = []
        if(retrieveQuoteConfig && 
            retrieveQuoteConfig.quotes.length > 0) {
                retrieveQuoteConfig.quotes.map(quote => {
                    if(quote.key == "gift_miles"){
                        currentRetrieveQuoteConfig = quote
                    }
                })
        }
        return currentRetrieveQuoteConfig
    }

    setDynamicAttributes = (currentRetrieveQuoteConfig, milesToGift) => {
       const { data } = this.state
       if(currentRetrieveQuoteConfig && currentRetrieveQuoteConfig.dynamicAttributes.length > 0 ){
            const dynamicAttributes = [...currentRetrieveQuoteConfig.dynamicAttributes]
            dynamicAttributes.map(dynamicAttribute => {
                if(dynamicAttribute.attributeCode == "PNTS"){
                    dynamicAttribute["attributeValue"] = milesToGift
                }else if(dynamicAttribute.attributeCode == "SRCMEMNUM"){
                    dynamicAttribute["attributeValue"] = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)
                }else if(dynamicAttribute.attributeCode == "TARMEMNUM"){
                    dynamicAttribute["attributeValue"] = data.membershipNumber
                }
            })
            return dynamicAttributes
       }
       return []
    }

    getTotalPayableAmount = (milesToGift) => {

        const { data } = this.state
        if(!milesToGift || milesToGift ==undefined){
            data.totalPayableAmount = 0;
            this.setState({data})
            return
        }
        
        const currentRetrieveQuoteConfig = this.getCurrentRetrieveQuoteConfig(this.props.retrieveQuoteConfig)
        const dynamicAttributes = this.setDynamicAttributes(currentRetrieveQuoteConfig, milesToGift)

        const request = {
            object: {
                companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                partyType: currentRetrieveQuoteConfig.partyType,
                activityCode: currentRetrieveQuoteConfig.activityCode,
                dynamicAttributes
            }
        }
        this.props.fetchRetrieveQuote(request)
    }

    getName() {
        const { member } = this.props;
        const memberDetils = member.memberDetails;
        if (!memberDetils) return '';
        return `${memberDetils.firstName} ${memberDetils.surname}`;
    }

    checkUser() {
        this.props.resetError()
        let error = []
        const { currentUserData, t } = this.props;
        const { data } = this.state;
        const { membershipNumber, firstName, lastName } = data;
        if (!membershipNumber) {
            error.push("Enter the Recipient Membership Number")
        } else if (!firstName) {
            error.push("Enter the Recipient First Name")
        }
        if (!error &&
            currentUserData &&
            currentUserData.userId &&
            currentUserData.userId == membershipNumber) {
            error.push("Same user Error")
        }
        if (error && error.length > 0) {
            this.showMessage(error)
            return
        }
        const requestBody = {
            object: {
                companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                membershipNumber
            }
        }
        if (firstName != "") {
            requestBody["object"].givenName = firstName
        } else if (lastName != "") {
            requestBody["object"].familyName = lastName
        }
        this.props.validateMemberDetails(requestBody)
    }

    showMessage(error) {
        this.setState({
            error
        }, () => {
            this.props.paymentResponse({
                paymentResponse: true,
                paymentStatus: WARNING,
                paymentMessage: error
            })
        })
    }

    cancel() {
        const data = JSON.parse(JSON.stringify(initialData));
        this.props.clearSearchMember();
        this.props.resetError()
        this.setState({
            data
        })
    }

    handleAgreeTermsChanged(e) {
        console.log("123456", e)
        window.history.pushState({}, null, `#${NAVIGATE_BUY}`)
        const { data } = this.state
        data.agreeTerms = !data.agreeTerms,
        data.btnProceedToGift = data.agreeTerms ? true : false
        this.setState({
            data
        })
        this.resetErrors()
    }

    resetGiftMiles = () => {
        this.resetErrors
        const data = JSON.parse(JSON.stringify(initialData))
        this.setState({data})
    }

    generateGiftMilesPayload = ()=>{
        const { configDetails, summaryConfig, simulateRule, defaultConfig, accountSummary } = this.props
        const {data}=this.state
        const {milesToGift,membershipNumber} = data
        const { activityCode, activityType, type, pointDetails, terms_and_conditions, description, bookingChannel } = configDetails
        const { pointType, isPaymentRequired, transactionFee, transactionType, isBonus } = pointDetails[0]
        // const pointsToPurchase = this.getPointsToPurchase(simulateRule)
        setItemToBrowserStorage(BROWSER_STORAGE_KEY_SELECTED_TAB, type)
        setItemToBrowserStorage(BROWSER_STORAGE_KEY_UPGRADED_TIER, this.state.selectedUpgradeTier)
        setItemToBrowserStorage(BROWSER_STORAGE_KEY_ACTIVITY_CODE, activityCode, BROWSER_STORAGE_TYPE_SESSION)
        setItemToBrowserStorage(BROWSER_STORAGE_KEY_POINT_DETAILS, JSON.stringify(pointDetails))
        const object = {
            companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
            programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
            membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
            targetMembershipNumber : membershipNumber,
            activityCode,
            activityType,
            transactionType: type,
            quoteReferenceNumber: EMPTY_STRING,
            points: [{
                points: milesToGift,
                pointType,
                isBonus
            }],
        }
        if (isPaymentRequired) {
            const paymentGateway = {}
            paymentGateway["cancel_url"] = _URL_GIFTPOINT_PAYMENT_CANCELLED
            paymentGateway["success_url"] = _URL_GIFTPOINT_PAYMENT_SUCCESS
            paymentGateway["failure_url"] = _URL_GIFTPOINT_PAYMENT_FAILED
            paymentGateway["redirect_url"] = _URL_GIFTPOINT_PAYMENT_REDIRECT
            paymentGateway["terms_and_conditions"] = terms_and_conditions

          if (this.props.defaultConfig) {
                const defaultConfig = getCurrentProgramFromDefaultConfig(this.props.defaultConfig)
                const precision = getPrecision(defaultConfig, getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE))
                let show_miles_only
                if(transactionType == "C"){
                    show_miles_only = "N"
                }
                else if(transactionType == "P"){
                    show_miles_only = "Y"
                }
                if(show_miles_only == "N"){
                    paymentGateway["purchase_totals"] = {
                        show_miles_only,
                        order_amount: data.totalPayableAmount,
                        order_currency: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_CURRENCY_CODE)
                    }
                }else if(show_miles_only == "Y"){
                    paymentGateway["purchase_totals"] = {
                        show_miles_only,
                        order_amount: data.totalPayableAmount,

                        order_currency: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_CURRENCY_CODEE),
                        miles: {
                            redeemed_miles: 0
                        }
                    }
                }
                paymentGateway["point_of_sale"] = {
                    pos_city: defaultConfig.defaults.posCity,
                    pos_country: defaultConfig.defaults.posCountry
                }
            }
            paymentGateway["order_details"] = {
                order_info: description,
                order_type: "",
                items: [{
                    airline_data: {
                        origin_destination: [{
                            segments: [{}]
                        }]
                    },
                    quantity: ONE_ITEM,
                    total_price:  data.totalPayableAmount
                }]
            }
            object["paymentGateway"] = paymentGateway
            return {"object": object}
        }
    }

    proceedToPay = () => {
        this.props.resetError()
        let error = []
        const { currentUserData, t } = this.props;
        const { data } = this.state;
        const { membershipNumber, firstName, lastName } = data;
        if (!membershipNumber) {
            error.push("Enter the Recipient Membership Number")
        } else if (!firstName) {
            error.push("Enter the Recipient First Name")
        }
        if (!error &&
            currentUserData &&
            currentUserData.userId &&
            currentUserData.userId == membershipNumber) {
            error.push("Same user Error")
        }
        if (error && error.length > 0) {
            this.showMessage(error)
            return
        }
        const request = this.generateGiftMilesPayload()
        this.props.giftPoints(request)
    }

    getTransferPointsList(pointsList) {
        let transferPointsList = [];
        pointsList.map(points => {
            transferPointsList.push({
                label: points.toString(),
                value: points.toString()
            });
        })
        return transferPointsList
    }

    render() {

        const lastName = false
        const { data } = this.state;
        const { member, configDetails, t, specialMessageStatus } = this.props
        let transferPointsList = [];
        transferPointsList = this.getTransferPointsList(getPointsArray(this.props.pointDetails[0]));
        const selectedPointDetails = configDetails.pointDetails[0];
        const withPayment = selectedPointDetails.isPaymentRequired;

        return (
            <div className="form-row" data-test="tierUpgradeComponent">
                <div className="col-lg-8 col-md-12">
                    <div className="toggle1">
                        <div className="step1">
                            <div className="form-row">
                                <div className="col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label htmlFor="MemberNumberTextBox" className="d-block">
                                            {t("buy.giftMiles.membershipNumber")}
                                            <span className="text-warning">*</span>
                                        </label>
                                        <input
                                            type="text"
                                            placeholder={t("buy.giftMiles.membershipNumber_placeholder")}
                                            id="MemberNumberTextBox"
                                            value={data.membershipNumber}
                                            onChange={(event) => this.handleChange('membershipNumber', event.target.value)}
                                            data-test="searchMembershipNumber"
                                        />
                                    </div>
                                </div>
                                <div className="col-lg-6 col-md-6 d-flex align-items-end">
                                    {
                                        lastName ?
                                            <div className="form-group flex-grow-1">
                                                <label htmlFor="LastNameTextBox" className="d-block">
                                                    {t("buy.giftMiles.lastName")}
                                                    <span className="text-warning">*</span>
                                                </label>
                                                <input
                                                    type="text"
                                                    placeholder={t("buy.giftMiles.lastName_placeholder")}
                                                    id="LastNameTextBox"
                                                    value={data.lastName}
                                                    onChange={(event) => this.handleChange('lastName', event.target.value)}
                                                    data-test="lastNameTest"
                                                />
                                            </div> :
                                            <div className="form-group flex-grow-1">
                                                <label htmlFor="FirstNameTextBox" className="d-block">
                                                    {t("buy.giftMiles.firstName")}
                                                    <span className="text-warning">*</span>
                                                </label>
                                                <input
                                                    type="text"
                                                    placeholder={t("buy.giftMiles.firstName_placeholder")}
                                                    id="FirstNameTextBox"
                                                    value={data.firstName}
                                                    onChange={(event) => this.handleChange('firstName', event.target.value)}
                                                    data-test="firstNameTest"
                                                />
                                            </div>
                                    }
                                    <div className="ml-2 mb-3">
                                        <button
                                            type="button"
                                            onClick={() => this.checkUser()}
                                            data-test="SearchUserBtn"
                                            className="btn btn-secondary"
                                            data-test="searchMemberBtn"
                                        >{t("buy.giftMiles.checkUser")}</button>
                                    </div>
                                </div>
                            </div>
                            <div className="form-row">
                                <div className="col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label htmlFor="recipient_name">{t("buy.giftMiles.recipient_name")}
                                            <span className="text-warning">*</span>
                                        </label>
                                        <input
                                            type="text" id="recipient_name"
                                            placeholder={t("buy.giftMiles.recipient_name_placeholder")}
                                            value={data.recipientName}
                                            disabled
                                        />
                                    </div>
                                </div>
                                <div className="col-lg-6 col-md-6">
                                    <div className="form-group">
                                        {
                                            configDetails && configDetails.isPacket ?
                                                <FilterDropDown
                                                    label={t("buy.giftMiles.no_of_miles_to_gift")}
                                                    placeholder={t("buy.giftMiles.no_of_miles_to_gift")}
                                                    options={transferPointsList}
                                                    isRequired={true}
                                                    id="milesToGift"
                                                    value={data.milesToGift}
                                                    onChange={(e) =>
                                                        this.handleChange('milesToGift', e)
                                                    }
                                                    testIdentifier="milesToGift"
                                                    info=""
                                                    enabled={true}
                                                /> :
                                                <SearchDropdown
                                                    label={t("buy.giftMiles.no_of_miles_to_gift")}
                                                    placeholder={t("buy.giftMiles.no_of_miles_to_gift")}
                                                    options={transferPointsList}
                                                    isRequired={true}
                                                    id="milesToGift"
                                                    value={data.milesToGift}
                                                    itemTemplate={(e) => defaultSearchDropDownTemplate(e)}
                                                    onChange={(e) =>
                                                        this.handleChange('milesToGift', e)
                                                    }
                                                    testIdentifier="milesToGift"
                                                    enabled={true}
                                                />
                                        }
                                    </div>
                                </div>
                            </div>
                            <div className="form-row">
                                <div className="col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label htmlFor="f2" className="d-block">{t("buy.giftMiles.total_payable")}</label>
                                        <input className="" type="text" readOnly
                                            value={data.totalPayableAmount}
                                            id="f2"
                                            disabled
                                            data-test="payableAmount" />
                                    </div>
                                </div>
                            </div>
                            {
                                !specialMessageStatus &&
                                <div className="form-row">
                                    <div className="col-lg-12 col-md-12">
                                        <div className="form-group">
                                            <label htmlFor="special_message">{t("buy.giftMiles.special_message")}</label>
                                            <textarea
                                                id="special_message"
                                                placeholder={t("buy.giftMiles.specialMessage_placeHolder")}
                                                rows="3" cols="60"
                                                value={data.specialMessageValue}
                                                onChange={(event) => this.handleChange('specialMessageValue', event.target.value)}
                                                data-test="specialMessage"
                                            >
                                            </textarea>
                                        </div>
                                    </div>
                                </div>
                            }
                            <div className="form-row">
                                <div className="col-lg-7 col-md-12 d-flex align-items-center">
                                    <div className="form-check form-check-inline">
                                        <input 
                                            className="form-check-input" 
                                            type="checkbox" 
                                            id="inlineCheckbox1" 
                                            value={data.agreeTerms} 
                                            checked={data.agreeTerms} 
                                            onChange={(e) => this.handleAgreeTermsChanged(e)} 
                                            data-test="AcceptTermsCheckbox" 
                                            disabled={!data.recipientName}
                                        />
                                        <label className="form-check-label" htmlFor="inlineCheckbox1">
                                            {parse(t("buy.giftMiles.accept_text_one"))}
                                            {parse(t("buy.giftMiles.accept_text_two"))}
                                        </label>
                                    </div>
                                </div>
                                <div className="col-lg-5 col-md-12 text-lg-right btn-wrap btn-wrap--grp">
                                    <Button
                                        className="btn btn-secondary"
                                        handleOnClick={() => this.resetGiftMiles()}
                                        id="buy_cancle_btn"
                                        testIdentifier="btnCancel"
                                        label={t("buy.giftMiles.cancel")} />
                                    <Button
                                        className="btn btn-primary"
                                        id={ID_SPINNER_PROCEED_TO_PAY}
                                        testIdentifier="btnProceedTobuy"
                                        handleOnClick={() => this.proceedToPay()}
                                        enabled={data.btnProceedToGift && data.agreeTerms}
                                        label={t("buy.giftMiles.proceed_to_pay")} />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        member: state.searchMember,
        message: state.transferMilesMessage,
        defaultConfig: state.configurationReducer.default,
        // retrieveQuoteConfig: state.configurationReducer[CONFIG_SECTION_RETRIEVE_QUOTE],
        retrieveQuoteConfig: {"section":"retrievequote","companyCode":"GF","programCode":"FF","quotes":[{"key":"renew_miles","partyType":"M","activityCode":"RP","dynamicAttributes":[{"attributeCode":"MEMSHPNUM","attributeValue":""},{"attributeCode":"PNTTYP","attributeValue":"MILES"},{"attributeCode":"PNTS","attributeValue":"","attributeType":"MILES"}]},{"key":"gift_miles","partyType":"M","activityCode":"GP","dynamicAttributes":[{"attributeCode":"ACTCOD","attributeValue":"GP","attributeType":"A"},{"attributeCode":"PNTS","attributeValue":"","attributeType":"MILES"},{"attributeCode":"SRCMEMNUM","attributeValue":""},{"attributeCode":"TARMEMNUM","attributeValue":""},{"attributeCode":"PNTTYP","attributeValue":"MILES"}]}]},
        currentUserData: state.currentLoginUserDataReducer.currentUserData,
        validateMember: state.validateMemberDetailReducer.validateMemberData,
        retrieveQuote: state.retrieveQuoteReducer.retrieveQuoteResponse,
        giftPointData: state.giftPointsReducer.giftPointData
    }
}

const mapDispatchToProps = {
    resetError,
    fetchCurrentLoginUserData,
    validateMemberDetails,
    fetchRetrieveQuote,
    fetchConfiguration,
    giftPoints
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(GiftMiles)));