import React from 'react';
import BuyPoints from './index';
import {
    findByTestAttr,
    findComponent,
    mockServiceResponse
} from '../../common/testUtils';
import { testStore } from '../../common/utils';
import moxios from 'moxios';
import { mount } from 'enzyme';
import { Provider } from 'react-redux'
import ReactTestUtils from 'react-dom/test-utils';
import {
    fetchConfiguration
} from '../../common/middleware/redux/commonAction'
import {
    CONFIG_SECTION_BUYPOINT, CONFIG_SECTION_DEFAULT, CONFIG_SECTION_SIMULATERULE, CONFIG_SECTION_SUMMARY
} from '../../common/utils/Constants'
import {
    authenticateTransaction,
    buyPointAction,
    buyPointAcceptPayment,
    transactionLogout,
    tierUpgrade
} from './action'
import {
    fetchAccountSummary
} from '../../common/middleware/redux/commonAction'
import {
    ID_SPINNER_PROCEED_TO_PAY
} from './Constants'
import { axiosInstance } from '../../common/utils/api';
import { _URL_ACCOUNT_SUMMARY, _URL_SIMULATE_RULE } from '../../common/config/config';
import { BROWSER_STORAGE_KEY_COMPANY_CODE, BROWSER_STORAGE_KEY_PROGRAM_CODE } from '../../common/utils/storage.utils';

var store = testStore({})
let rootComponent;
let component;

const setUpBuyMiles = (props = {}, isDefaultConfig = false) => {
    props.paymentResponse = (response = {}) => {
    }
    props.resetError = jest.fn();
    props.setPageInfo = jest.fn();
    if(isDefaultConfig){
        props["config"] = JSON.parse(JSON.stringify(CONFIG_RESPONSE)).object
    }
    rootComponent = mount(<Provider store={store}>
        <BuyPoints {...props} store={store} />
    </Provider>);
    component = findComponent(rootComponent, 'BuyPoints');
};

describe('Should render the Buy Points Page Successfully',()=>{

    beforeEach(() => {
        store = undefined
        store = testStore({})
        moxios.install(axiosInstance);
        moxios.stubRequest(_URL_ACCOUNT_SUMMARY, {
            status: 200,
            responseText: ACCOUNT_SUMMARY_SUCCESS
        })
        localStorage.setItem(BROWSER_STORAGE_KEY_COMPANY_CODE, "GF")
        localStorage.setItem(BROWSER_STORAGE_KEY_PROGRAM_CODE, "FF")
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchAccountSummary())
            .then(() => {
                setUpBuyMiles({}, true);
             })
        })
    });

    afterEach(() => {
        moxios.uninstall(axiosInstance);
    });

    it('should pass the config to BuyPoints',()=>{
        mockServiceResponse(CONFIG_RESPONSE)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_BUYPOINT))
                .then(() => {
                    const newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_BUYPOINT]).toBe(CONFIG_RESPONSE.object);
                    updateComponents();
                    mockServiceResponse(DEFAULT_CONFIG_RESPONSE)
                    return store.dispatch(fetchConfiguration([CONFIG_SECTION_DEFAULT]))
                        .then(() => {
                        updateComponents();
                        const newState = store.getState();
                        expect(newState.configurationReducer[CONFIG_SECTION_DEFAULT]).toBe(DEFAULT_CONFIG_RESPONSE.object);
                        updateComponents();
                    const generalBuyComponent = findByTestAttr(component, 'generalBuyComponent')
                    expect(generalBuyComponent.length).toBe(1)
                    const selectedTab = findByTestAttr(component, 'li_general')
                    expect(selectedTab.length).toBe(1);
                    selectedTab.simulate("click")
                    updateComponents();
                    const selectedPoints = findByTestAttr(component, 'selectedPoints')
                    expect(selectedPoints.length).toBe(1);
                    selectedPoints.props().onChange({ target: { value: 2000 } })
                    const acceptTermsCheckbox = findByTestAttr(component, 'AcceptTermsCheckbox')
                    expect(acceptTermsCheckbox.length).toBe(1);
                    acceptTermsCheckbox.simulate('change');
                    updateComponents();
                    const pinTextBox = findByTestAttr(component, 'PinTextBox')
                    expect(pinTextBox.length).toBe(1);
                    pinTextBox.simulate('change', { target: { value: '1234' } })
                    const btnProceedTobuy = findByTestAttr(component, 'btnProceedTobuy')
                    expect(btnProceedTobuy.length).toBe(1);
                    btnProceedTobuy.props().onClick();
                    mockServiceResponse(AUTH_RESPONSE)
                    return ReactTestUtils.act(() => {
                        return store.dispatch(authenticateTransaction({ "test": "test" }, ID_SPINNER_PROCEED_TO_PAY))
                        .then(() => {
                            let newState = store.getState();
                            expect(newState.authenticateTransactionReducer.authenticateTransaction).toBe(AUTH_RESPONSE.object);
                            updateComponents();
                            let data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "redirectURL": window.location.href + "payment=success&&", "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010415", "transactionID": "1B8BCAE337FF4CD0219E38EA937C478C", "tiercode": null, "memberActivityStatus": { "accountStatus": null, "activityNumber": "ACT4116", "activityType": "BP", "activityName": "BUY_POINTS", "activityStatus": "D", "activityCode": "BP", "pointDetails": [{ "pointType": "BASE", "points": 1000.0, "isBonus": true, "expiryDate": "15-Feb-2024" }] } } }
                            mockServiceResponse(data)
                            return ReactTestUtils.act(() => {
                                return store.dispatch(buyPointAction({ "test": "test" }))
                                .then(() => {
                                    newState = store.getState();
                                    expect(newState.buyPointReducer.buyPointData).toBe(data.object);
                                    data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010415", "transactionId": "434D7C7518FB20E075D63707A882A5EF", "acceptPaymentStatus": true, "activityNumber": "ACT4117" } };
                                    mockServiceResponse(data);
                                    window.sessionStorage.setItem('transactionId', '434D7C7518FB20E075D63707A882A5EF')
                                    window.sessionStorage.setItem('activityNumber', 'ACT4117')
                                    window.sessionStorage.setItem('missingPoints', '1000')
                                    return ReactTestUtils.act(() => {
                                        return store.dispatch(buyPointAcceptPayment({ "test": "test" }))
                                        .then(() => {
                                            newState = store.getState();
                                            expect(newState.buyPointAcceptReducer.acceptPayment).toBe(data.object);
                                            data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "status": true, "membershipNumber": "IM0008010415", "transactionID": "434D7C7518FB20E075D63707A882A5EF", "activityNumber": "ACT4117" } }
                                            mockServiceResponse(data);
                                            component.setState({
                                            paymentResponse: true,
                                            paymentStatus: "success",
                                            paymentMessage: ["You have purchased 2000 Skypass miles successfully. Your balance: 10000 miles."]
                                            })
                                            return ReactTestUtils.act(() => {
                                                return store.dispatch(transactionLogout({ "test": "test" }))
                                                .then(() => {
                                                newState = store.getState();
                                                expect(newState.logoutTransactionReducer.logoutTransaction).toBe(data.object);
                                                })
                                            });
                                        })
                                    })
                                })
                            })
                        })
                    })
                })})
        });
    })



    it('should pass the config to BuyPoints With Radio Button',()=>{
        mockServiceResponse(CONFIG_RESPONSE_RADIOBUTTON)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_BUYPOINT))
                .then(() => {
                    const newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_BUYPOINT]).toBe(CONFIG_RESPONSE_RADIOBUTTON.object);
                    updateComponents();
                    const generalBuyComponent = findByTestAttr(component, 'generalBuyComponent')
                    expect(generalBuyComponent.length).toBe(1)
                   
                    const selectedTab = findByTestAttr(component, 'li_general')
                    expect(selectedTab.length).toBe(1);
                    selectedTab.simulate("click")
                    const selectedPoints = findByTestAttr(component, 'selectedPoints')
                    expect(selectedPoints.length).toBe(1);
                    selectedPoints.props().onChange({ target: { value: 2000 } })
                    const acceptTermsCheckbox = findByTestAttr(component, 'AcceptTermsCheckbox')
                    expect(acceptTermsCheckbox.length).toBe(1);
                    acceptTermsCheckbox.simulate('change');
                    updateComponents();
                    const pinTextBox = findByTestAttr(component, 'PinTextBox')
                    expect(pinTextBox.length).toBe(1);
                    pinTextBox.simulate('change', { target: { value: '1234' } })
                    const btnProceedTobuy = findByTestAttr(component, 'btnProceedTobuy')
                    expect(btnProceedTobuy.length).toBe(1);
                    btnProceedTobuy.props().onClick();
                    mockServiceResponse(AUTH_RESPONSE)
                    return ReactTestUtils.act(() => {
                        return store.dispatch(authenticateTransaction({ "test": "test" }, ID_SPINNER_PROCEED_TO_PAY))
                        .then(() => {
                            let newState = store.getState();
                            expect(newState.authenticateTransactionReducer.authenticateTransaction).toBe(AUTH_RESPONSE.object);
                            updateComponents();
                            let data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "redirectURL": window.location.href + "payment=success&&", "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010415", "transactionID": "1B8BCAE337FF4CD0219E38EA937C478C", "tiercode": null, "memberActivityStatus": { "accountStatus": null, "activityNumber": "ACT4116", "activityType": "BP", "activityName": "BUY_POINTS", "activityStatus": "D", "activityCode": "BP", "pointDetails": [{ "pointType": "BASE", "points": 1000.0, "isBonus": true, "expiryDate": "15-Feb-2024" }] } } }
                            mockServiceResponse(data)
                            return ReactTestUtils.act(() => {
                                return store.dispatch(buyPointAction({ "test": "test" }))
                                .then(() => {
                                    newState = store.getState();
                                    expect(newState.buyPointReducer.buyPointData).toBe(data.object);
                                    data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010415", "transactionId": "434D7C7518FB20E075D63707A882A5EF", "acceptPaymentStatus": true, "activityNumber": "ACT4117" } };
                                    mockServiceResponse(data);
                                    window.sessionStorage.setItem('transactionId', '434D7C7518FB20E075D63707A882A5EF')
                                    window.sessionStorage.setItem('activityNumber', 'ACT4117')
                                    window.sessionStorage.setItem('missingPoints', '1000')
                                    return ReactTestUtils.act(() => {
                                        return store.dispatch(buyPointAcceptPayment({ "test": "test" }))
                                        .then(() => {
                                            newState = store.getState();
                                            expect(newState.buyPointAcceptReducer.acceptPayment).toBe(data.object);
                                            data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "status": true, "membershipNumber": "IM0008010415", "transactionID": "434D7C7518FB20E075D63707A882A5EF", "activityNumber": "ACT4117" } }
                                            mockServiceResponse(data);
                                            component.setState({
                                            paymentResponse: true,
                                            paymentStatus: "success",
                                            paymentMessage: ["You have purchased 2000 Skypass miles successfully. Your balance: 10000 miles."]
                                            })
                                            return ReactTestUtils.act(() => {
                                                return store.dispatch(transactionLogout({ "test": "test" }))
                                                .then(() => {
                                                newState = store.getState();
                                                expect(newState.logoutTransactionReducer.logoutTransaction).toBe(data.object);
                                                })
                                            });
                                        })
                                    })
                                })
                            })
                        })
                    })
                })
        });
    })

    it('Buy points: Fetch configuration for buy point and render without errors and clear form', () => {
        mockServiceResponse(CONFIG_RESPONSE)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_BUYPOINT))
                .then(() => {
                    const newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_BUYPOINT]).toBe(CONFIG_RESPONSE.object);
                    updateComponents();
                    const generalBuyComponent = findByTestAttr(component, 'generalBuyComponent')
                    expect(generalBuyComponent.length).toBe(1)
                    const selectedTab = findByTestAttr(component, 'li_general')
                    expect(selectedTab.length).toBe(1);
                    selectedTab.simulate("click")
                    const selectedPoints = findByTestAttr(component, 'selectedPoints')
                    expect(selectedPoints.length).toBe(1);
                    selectedPoints.props().onChange({ target: { value: 2000 } })
                    const acceptTermsCheckbox = findByTestAttr(component, 'AcceptTermsCheckbox')
                    expect(acceptTermsCheckbox.length).toBe(1);
                    acceptTermsCheckbox.simulate('change');
                    updateComponents();
                    const pinTextBox = findByTestAttr(component, 'PinTextBox')
                    expect(pinTextBox.length).toBe(1);
                    pinTextBox.simulate('change', { target: { value: '1234' } })
                    const btnCancel = findByTestAttr(component, 'btnCancel')
                    expect(btnCancel.length).toBe(1);
                    btnCancel.props().onClick();
                })
        });
    })

    it('should pass with unprotected api without payment',()=>{
        mockServiceResponse(CONFIG_RESPONSE_UNPROTECTED_API_WO_PAYMENT)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_BUYPOINT))
                .then(() => {
                    const newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_BUYPOINT]).toBe(CONFIG_RESPONSE_UNPROTECTED_API_WO_PAYMENT.object);
                    updateComponents();
                    const generalBuyComponent = findByTestAttr(component, 'generalBuyComponent')
                    expect(generalBuyComponent.length).toBe(1)
                    const selectedTab = findByTestAttr(component, 'li_general')
                    expect(selectedTab.length).toBe(1);
                    selectedTab.simulate("click")
                    const selectedPoints = findByTestAttr(component, 'selectedPoints')
                    expect(selectedPoints.length).toBe(1);
                    selectedPoints.props().onChange({ target: { value: 2000 } })
                    const acceptTermsCheckbox = findByTestAttr(component, 'AcceptTermsCheckbox')
                    expect(acceptTermsCheckbox.length).toBe(1);
                    acceptTermsCheckbox.simulate('change');
                    updateComponents();
                    const btnProceedTobuy = findByTestAttr(component, 'btnProceedTobuy')
                    expect(btnProceedTobuy.length).toBe(1);
                    btnProceedTobuy.props().onClick();
                    mockServiceResponse(AUTH_RESPONSE)
                    return ReactTestUtils.act(() => {
                        return store.dispatch(authenticateTransaction({ "test": "test" }, ID_SPINNER_PROCEED_TO_PAY))
                        .then(() => {
                            let newState = store.getState();
                            expect(newState.authenticateTransactionReducer.authenticateTransaction).toBe(AUTH_RESPONSE.object);
                            updateComponents();
                            let data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "redirectURL": window.location.href + "payment=success&&", "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010415", "transactionID": "1B8BCAE337FF4CD0219E38EA937C478C", "tiercode": null, "memberActivityStatus": { "accountStatus": null, "activityNumber": "ACT4116", "activityType": "BP", "activityName": "BUY_POINTS", "activityStatus": "D", "activityCode": "BP", "pointDetails": [{ "pointType": "BASE", "points": 1000.0, "isBonus": true, "expiryDate": "15-Feb-2024" }] } } }
                            mockServiceResponse(data)
                            return ReactTestUtils.act(() => {
                                return store.dispatch(buyPointAction({ "test": "test" }))
                                .then(() => {
                                    newState = store.getState();
                                    expect(newState.buyPointReducer.buyPointData).toBe(data.object);
                                    data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010415", "transactionId": "434D7C7518FB20E075D63707A882A5EF", "acceptPaymentStatus": true, "activityNumber": "ACT4117" } };
                                    mockServiceResponse(data);
                                    window.sessionStorage.setItem('transactionId', '434D7C7518FB20E075D63707A882A5EF')
                                    window.sessionStorage.setItem('activityNumber', 'ACT4117')
                                    return ReactTestUtils.act(() => {
                                        return store.dispatch(buyPointAcceptPayment({ "test": "test" }))
                                        .then(() => {
                                            newState = store.getState();
                                            expect(newState.buyPointAcceptReducer.acceptPayment).toBe(data.object);
                                            data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "status": true, "membershipNumber": "IM0008010415", "transactionID": "434D7C7518FB20E075D63707A882A5EF", "activityNumber": "ACT4117" } }
                                            mockServiceResponse(data);
                                            component.setState({
                                            paymentResponse: true,
                                            paymentStatus: "success",
                                            paymentMessage: ["You have purchased 2000 Skypass miles successfully. Your balance: 10000 miles."]
                                            })
                                            return ReactTestUtils.act(() => {
                                                return store.dispatch(transactionLogout({ "test": "test" }))
                                                .then(() => {
                                                newState = store.getState();
                                                expect(newState.logoutTransactionReducer.logoutTransaction).toBe(data.object);
                                                })
                                            });
                                        })
                                    })
                                })
                            })
                        })
                    })
                })
        });

    })

    it('should pass with unprotected api with payment',()=>{
        mockServiceResponse(CONFIG_RESPONSE_UNPROTECTED_API)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_BUYPOINT))
                .then(() => {
                    const newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_BUYPOINT]).toBe(CONFIG_RESPONSE_UNPROTECTED_API.object);
                    updateComponents();
                    const generalBuyComponent = findByTestAttr(component, 'generalBuyComponent')
                    expect(generalBuyComponent.length).toBe(1)
                    const selectedTab = findByTestAttr(component, 'li_general')
                    expect(selectedTab.length).toBe(1);
                    selectedTab.simulate("click")
                    const selectedPoints = findByTestAttr(component, 'selectedPoints')
                    expect(selectedPoints.length).toBe(1);
                    selectedPoints.props().onChange({ target: { value: 2000 } })
                    const acceptTermsCheckbox = findByTestAttr(component, 'AcceptTermsCheckbox')
                    expect(acceptTermsCheckbox.length).toBe(1);
                    acceptTermsCheckbox.simulate('change');
                    updateComponents();
                    const btnProceedTobuy = findByTestAttr(component, 'btnProceedTobuy')
                    expect(btnProceedTobuy.length).toBe(1);
                    btnProceedTobuy.props().onClick();
                    mockServiceResponse(AUTH_RESPONSE)
                    return ReactTestUtils.act(() => {
                        return store.dispatch(authenticateTransaction({ "test": "test" }, ID_SPINNER_PROCEED_TO_PAY))
                        .then(() => {
                            let newState = store.getState();
                            expect(newState.authenticateTransactionReducer.authenticateTransaction).toBe(AUTH_RESPONSE.object);
                            updateComponents();
                            let data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "redirectURL": window.location.href + "payment=success&&", "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010415", "transactionID": "1B8BCAE337FF4CD0219E38EA937C478C", "tiercode": null, "memberActivityStatus": { "accountStatus": null, "activityNumber": "ACT4116", "activityType": "BP", "activityName": "BUY_POINTS", "activityStatus": "D", "activityCode": "BP", "pointDetails": [{ "pointType": "BASE", "points": 1000.0, "isBonus": true, "expiryDate": "15-Feb-2024" }] } } }
                            mockServiceResponse(data)
                            return ReactTestUtils.act(() => {
                                return store.dispatch(buyPointAction({ "test": "test" }))
                                .then(() => {
                                    newState = store.getState();
                                    expect(newState.buyPointReducer.buyPointData).toBe(data.object);
                                    data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010415", "transactionId": "434D7C7518FB20E075D63707A882A5EF", "acceptPaymentStatus": true, "activityNumber": "ACT4117" } };
                                    mockServiceResponse(data);
                                    window.sessionStorage.setItem('transactionId', '434D7C7518FB20E075D63707A882A5EF')
                                    window.sessionStorage.setItem('activityNumber', 'ACT4117')
                                    return ReactTestUtils.act(() => {
                                        return store.dispatch(buyPointAcceptPayment({ "test": "test" }))
                                        .then(() => {
                                            newState = store.getState();
                                            expect(newState.buyPointAcceptReducer.acceptPayment).toBe(data.object);
                                            data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "status": true, "membershipNumber": "IM0008010415", "transactionID": "434D7C7518FB20E075D63707A882A5EF", "activityNumber": "ACT4117" } }
                                            mockServiceResponse(data);
                                            component.setState({
                                            paymentResponse: true,
                                            paymentStatus: "success",
                                            paymentMessage: ["You have purchased 2000 Skypass miles successfully. Your balance: 10000 miles."]
                                            })
                                            return ReactTestUtils.act(() => {
                                                return store.dispatch(transactionLogout({ "test": "test" }))
                                                .then(() => {
                                                newState = store.getState();
                                                expect(newState.logoutTransactionReducer.logoutTransaction).toBe(data.object);
                                                })
                                            });
                                        })
                                    })
                                })
                            })
                        })
                    })
                })
        });

    })

    it('should pass the config with payment Cancelled',()=>{
        mockServiceResponse(CONFIG_RESPONSE_UNPROTECTED_API)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_BUYPOINT))
                .then(() => {
                    const newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_BUYPOINT]).toBe(CONFIG_RESPONSE_UNPROTECTED_API.object);
                    updateComponents();
                    const generalBuyComponent = findByTestAttr(component, 'generalBuyComponent')
                    expect(generalBuyComponent.length).toBe(1)
                   
                    const selectedTab = findByTestAttr(component, 'li_general')
                    expect(selectedTab.length).toBe(1);
                    selectedTab.simulate("click")
                    const selectedPoints = findByTestAttr(component, 'selectedPoints')
                    expect(selectedPoints.length).toBe(1);
                    selectedPoints.props().onChange({ target: { value: 2000 } })
                    const acceptTermsCheckbox = findByTestAttr(component, 'AcceptTermsCheckbox')
                    expect(acceptTermsCheckbox.length).toBe(1);
                    acceptTermsCheckbox.simulate('change');
                    updateComponents();
                    const btnProceedTobuy = findByTestAttr(component, 'btnProceedTobuy')
                    expect(btnProceedTobuy.length).toBe(1);
                    btnProceedTobuy.props().onClick();
                    mockServiceResponse(AUTH_RESPONSE)
                    return ReactTestUtils.act(() => {
                        return store.dispatch(authenticateTransaction({ "test": "test" }, ID_SPINNER_PROCEED_TO_PAY))
                        .then(() => {
                            let newState = store.getState();
                            expect(newState.authenticateTransactionReducer.authenticateTransaction).toBe(AUTH_RESPONSE.object);
                            updateComponents();
                            let data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "redirectURL": window.location.href + "payment=cancelled &&", "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010415", "transactionID": "1B8BCAE337FF4CD0219E38EA937C478C", "tiercode": null, "memberActivityStatus": { "accountStatus": null, "activityNumber": "ACT4116", "activityType": "BP", "activityName": "BUY_POINTS", "activityStatus": "D", "activityCode": "BP", "pointDetails": [{ "pointType": "BASE", "points": 1000.0, "isBonus": true, "expiryDate": "15-Feb-2024" }] } } }
                            mockServiceResponse(data)
                            return ReactTestUtils.act(() => {
                                return store.dispatch(buyPointAction({ "test": "test" }))
                                .then(() => {
                                    newState = store.getState();
                                    expect(newState.buyPointReducer.buyPointData).toBe(data.object);
                                    data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010415", "transactionId": "434D7C7518FB20E075D63707A882A5EF", "acceptPaymentStatus": true, "activityNumber": "ACT4117" } };
                                    mockServiceResponse(data);
                                    window.sessionStorage.setItem('transactionId', '434D7C7518FB20E075D63707A882A5EF')
                                    window.sessionStorage.setItem('missingPoints', '1000')
                                    return ReactTestUtils.act(() => {
                                        return store.dispatch(buyPointAcceptPayment({ "test": "test" }))
                                        .then(() => {
                                            newState = store.getState();
                                            expect(newState.buyPointAcceptReducer.acceptPayment).toBe(data.object);
                                            data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "status": true, "membershipNumber": "IM0008010415", "transactionID": "434D7C7518FB20E075D63707A882A5EF", "activityNumber": "ACT4117" } }
                                            mockServiceResponse(data);
                                            component.setState({
                                            paymentResponse: true,
                                            paymentStatus: "warning",
                                            paymentMessage: ["Your transaction has been cancelled"]
                                            })
                                            return ReactTestUtils.act(() => {
                                                return store.dispatch(transactionLogout({ "test": "test" }))
                                                .then(() => {
                                                newState = store.getState();
                                                expect(newState.logoutTransactionReducer.logoutTransaction).toBe(data.object);
                                                })
                                            });
                                        })
                                    })
                                })
                            })
                        })
                    })
                })
        });
    })

    it('should pass the config with payment failed',()=>{
        mockServiceResponse(CONFIG_RESPONSE_UNPROTECTED_API)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_BUYPOINT))
                .then(() => {
                    const newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_BUYPOINT]).toBe(CONFIG_RESPONSE_UNPROTECTED_API.object);
                    updateComponents();
                    const generalBuyComponent = findByTestAttr(component, 'generalBuyComponent')
                    expect(generalBuyComponent.length).toBe(1)
                   
                    const selectedTab = findByTestAttr(component, 'li_general')
                    expect(selectedTab.length).toBe(1);
                    selectedTab.simulate("click")
                    const selectedPoints = findByTestAttr(component, 'selectedPoints')
                    expect(selectedPoints.length).toBe(1);
                    selectedPoints.props().onChange({ target: { value: 2000 } })
                    const acceptTermsCheckbox = findByTestAttr(component, 'AcceptTermsCheckbox')
                    expect(acceptTermsCheckbox.length).toBe(1);
                    acceptTermsCheckbox.simulate('change');
                    updateComponents();
                    const btnProceedTobuy = findByTestAttr(component, 'btnProceedTobuy')
                    expect(btnProceedTobuy.length).toBe(1);
                    btnProceedTobuy.props().onClick();
                    mockServiceResponse(AUTH_RESPONSE)
                    return ReactTestUtils.act(() => {
                        return store.dispatch(authenticateTransaction({ "test": "test" }, ID_SPINNER_PROCEED_TO_PAY))
                        .then(() => {
                            let newState = store.getState();
                            expect(newState.authenticateTransactionReducer.authenticateTransaction).toBe(AUTH_RESPONSE.object);
                            updateComponents();
                            let data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "redirectURL": window.location.href + "payment=failed &&", "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010415", "transactionID": "1B8BCAE337FF4CD0219E38EA937C478C", "tiercode": null, "memberActivityStatus": { "accountStatus": null, "activityNumber": "ACT4116", "activityType": "BP", "activityName": "BUY_POINTS", "activityStatus": "D", "activityCode": "BP", "pointDetails": [{ "pointType": "BASE", "points": 1000.0, "isBonus": true, "expiryDate": "15-Feb-2024" }] } } }
                            mockServiceResponse(data)
                            return ReactTestUtils.act(() => {
                                return store.dispatch(buyPointAction({ "test": "test" }))
                                .then(() => {
                                    newState = store.getState();
                                    expect(newState.buyPointReducer.buyPointData).toBe(data.object);
                                    data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010415", "transactionId": "434D7C7518FB20E075D63707A882A5EF", "acceptPaymentStatus": true, "activityNumber": "ACT4117" } };
                                    mockServiceResponse(data);
                                    window.sessionStorage.setItem('transactionId', '434D7C7518FB20E075D63707A882A5EF')
                                    window.sessionStorage.setItem('missingPoints', '1000')
                                    return ReactTestUtils.act(() => {
                                        return store.dispatch(buyPointAcceptPayment({ "test": "test" }))
                                        .then(() => {
                                            newState = store.getState();
                                            expect(newState.buyPointAcceptReducer.acceptPayment).toBe(data.object);
                                            data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "status": true, "membershipNumber": "IM0008010415", "transactionID": "434D7C7518FB20E075D63707A882A5EF", "activityNumber": "ACT4117" } }
                                            mockServiceResponse(data);
                                            component.setState({
                                            paymentResponse: true,
                                            paymentStatus: "warning",
                                            paymentMessage: ["Your transaction has been cancelled"]
                                            })
                                            return ReactTestUtils.act(() => {
                                                return store.dispatch(transactionLogout({ "test": "test" }))
                                                .then(() => {
                                                newState = store.getState();
                                                expect(newState.logoutTransactionReducer.logoutTransaction).toBe(data.object);
                                                })
                                            });
                                        })
                                    })
                                })
                            })
                        })
                    })
                })
        });
    })

    it('Buy points: Payment Failure on Authentication', () => {
        mockServiceResponse(CONFIG_RESPONSE)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_BUYPOINT))
                .then(() => {

                    mockServiceResponse(AUTH_RESPONSE_FAIL, 500)
                    return ReactTestUtils.act(() => {
                        return store.dispatch(authenticateTransaction({ "test": "test" }, ID_SPINNER_PROCEED_TO_PAY ))
                        .then(() => {
                            component.setState({
                                acceptPaymentInvoked: false
                            })
                            rootComponent = rootComponent.update()
                            component = findComponent(rootComponent, 'BuyMiles')
                            let newState = store.getState();
                            expect(newState.commonErrorReducer.error.message).toBe(AUTH_RESPONSE_FAIL_MSG);
                        });
                    });


                })
        });

    });

    it('Buy points: Payment Failure on BuyPoint', () => {
        mockServiceResponse(CONFIG_RESPONSE)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_BUYPOINT))
                .then(() => {
                    
                                mockServiceResponse(BUYPOINT_RESPONSE_FAIL, 500)
                                return ReactTestUtils.act(() => {
                                    return store.dispatch(buyPointAction({ "test": "test" }, { loading: true, divId: ID_SPINNER_PROCEED_TO_PAY })).then(() => {
                                        rootComponent = rootComponent.update()
                                        component = findComponent(rootComponent, 'BuyMiles')
                                        let newState = store.getState();
                                        expect(newState.commonErrorReducer.error.message).toBe(BUYPOINT_RESPONSE_FAIL_MSG);
                                    });
                                });


                })
        });

    });

    it('Buy points: Payment Failure on Accept Payment', () => {
        mockServiceResponse(CONFIG_RESPONSE)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_BUYPOINT))
                .then(() => {
                    
                                mockServiceResponse(ACCEPTPAYMENT_RESPONSE_FAIL, 500)
                                return ReactTestUtils.act(() => {
                                    return store.dispatch(buyPointAcceptPayment({ "test": "test" }, { loading: true, divId: ID_SPINNER_PROCEED_TO_PAY })).then(() => {
                                        rootComponent = rootComponent.update()
                                        component = findComponent(rootComponent, 'BuyMiles')
                                        let newState = store.getState();
                                        expect(newState.commonErrorReducer.error.message).toBe(ACCEPTPAYMENT_RESPONSE_FAIL_MSG);
                                    });
                                });


                })
        });

    });

    it('Buy points: Payment Failure on Transaction logout', () => {
        mockServiceResponse(CONFIG_RESPONSE)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_BUYPOINT))
                .then(() => {
                   
                                mockServiceResponse(TRANSACTION_LOGOUT_RESPONSE_FAIL, 500)
                                return ReactTestUtils.act(() => {
                                    return store.dispatch(transactionLogout({ "test": "test" })).then(() => {
                                        rootComponent = rootComponent.update()
                                        component = findComponent(rootComponent, 'BuyMiles')
                                        let newState = store.getState();
                                        expect(newState.commonErrorReducer.error.message).toBe(TRANSACTION_LOGOUT_RESPONSE_FAIL_MSG);
                                    });
                                });


                })
        });

    });

    it('should pass the config to TierUpgrade with higher tier warning', () => {
        moxios.stubRequest(_URL_SIMULATE_RULE, {
            status: 200,
            responseText: SIMULATE_RULE_SUCCESS
        })
        moxios.stubRequest(_URL_ACCOUNT_SUMMARY, {
            status: 200,
            responseText: ACCOUNT_SUMMARY_SUCCESS_1
        })
        mockServiceResponse(CONFIG_RESPONSE_UNPROTECTED_API)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_BUYPOINT))
                .then(() => {
                    const newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_BUYPOINT]).toBe(CONFIG_RESPONSE_UNPROTECTED_API.object);
                    updateComponents();
                    mockServiceResponse(SUMMARY_CONFIG)
                    return store.dispatch(fetchConfiguration(CONFIG_SECTION_SUMMARY))
                        .then(() => {
                            updateComponents();
                            const newState = store.getState();
                            expect(newState.configurationReducer[CONFIG_SECTION_SUMMARY]).toStrictEqual(SUMMARY_CONFIG.object);
                            updateComponents();
                            let li_tierUpgrade = findByTestAttr(component, 'li_tierUpgrade');
                            expect(li_tierUpgrade.length).toBe(1);
                            li_tierUpgrade.simulate('click')

                            updateComponents();
                            let tierUpgradeComponent = findByTestAttr(component, 'tierUpgradeComponent')
                            expect(tierUpgradeComponent.length).toBe(1);

                            const currentTier = findByTestAttr(component, 'currentTier')
                            expect(currentTier.length).toBe(1);

                            const upgradeTier = findByTestAttr(component, 'upgradeTier')
                            expect(upgradeTier.length).toBe(1);

                            const acceptTermsCheckbox = findByTestAttr(component, 'AcceptTermsCheckbox')
                            expect(acceptTermsCheckbox.length).toBe(1);
                        })
                })
        });
    })

    it('should pass the config to TierUpgrade', () => {
        moxios.stubRequest(_URL_SIMULATE_RULE, {
            status: 200,
            responseText: SIMULATE_RULE_SUCCESS
        })

        moxios.stubRequest(_URL_ACCOUNT_SUMMARY, {
            status: 200,
            responseText: ACCOUNT_SUMMARY_SUCCESS_WITH_LOYALTY_POINT
        })
        mockServiceResponse(CONFIG_RESPONSE_UNPROTECTED_API)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_BUYPOINT))
                .then(() => {
                    const newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_BUYPOINT]).toStrictEqual(CONFIG_RESPONSE_UNPROTECTED_API.object);
                    updateComponents();
                    mockServiceResponse(SIMULATE_RULE_CONFIG)
                    return store.dispatch(fetchConfiguration(CONFIG_SECTION_SIMULATERULE))
                        .then(() => {
                            updateComponents();
                            const newState = store.getState();
                            expect(newState.configurationReducer[CONFIG_SECTION_SIMULATERULE]).toStrictEqual(SIMULATE_RULE_CONFIG.object);
                            updateComponents();
                            mockServiceResponse(SUMMARY_CONFIG)
                            return store.dispatch(fetchConfiguration(CONFIG_SECTION_SUMMARY))
                                .then(() => {
                                    updateComponents();
                                    const newState = store.getState();
                                    expect(newState.configurationReducer[CONFIG_SECTION_SUMMARY]).toStrictEqual(SUMMARY_CONFIG.object);
                                    mockServiceResponse(DEFAULT_CONFIG_RESPONSE)
                                    return store.dispatch(fetchConfiguration([CONFIG_SECTION_DEFAULT]))
                                        .then(() => {
                                            updateComponents();
                                            const newState = store.getState();
                                            expect(newState.configurationReducer[CONFIG_SECTION_DEFAULT]).toBe(DEFAULT_CONFIG_RESPONSE.object);
                                            updateComponents();

                                            let li_tierUpgrade = findByTestAttr(component, 'li_tierUpgrade');
                                            expect(li_tierUpgrade.length).toBe(1);
                                            li_tierUpgrade.simulate('click')
                                            updateComponents();
                                            let tierUpgradeComponent = findByTestAttr(component, 'tierUpgradeComponent')
                                            expect(tierUpgradeComponent.length).toBe(1);

                                            const currentTier = findByTestAttr(component, 'currentTier')
                                            expect(currentTier.length).toBe(1);

                                            const upgradeTier = findByTestAttr(component, 'upgradeTier')
                                            expect(upgradeTier.length).toBe(1);

                                            const acceptTermsCheckbox = findByTestAttr(component, 'AcceptTermsCheckbox')
                                            expect(acceptTermsCheckbox.length).toBe(1);
                                            acceptTermsCheckbox.simulate('change');
                                            updateComponents();

                                            const btnProceedTobuy = findByTestAttr(component, 'btnProceedTobuy')
                                            expect(btnProceedTobuy.length).toBe(1);
                                            btnProceedTobuy.props().onClick();

                                            mockServiceResponse(PURCHASE_TIER_RESPONSE)
                                            return store.dispatch(tierUpgrade("test", ""))
                                                .then(() => {
                                                    updateComponents();
                                                    const newState = store.getState();
                                                    expect(newState.tierUpgradeReducer.tierUpgrade).toStrictEqual(PURCHASE_TIER_RESPONSE.object);
                                                })
                                        })
                                })
                        })
                })
        });
    })

})


const updateComponents = () => {
    rootComponent = rootComponent.update()
    component = findComponent(rootComponent, 'BuyPoints');
}


// describe('BuyPoints Component', () => {
//     describe('Bonus Point', () => {
//         beforeEach(() => {
//             store = undefined
//             store = testStore({})
//             setUpBuyMiles({});
//             // component.setState({
//             //     companyCode: 'IBS',
//             //     programCode: "PRG14",
//             //     membershipNumber: "IMI123456",
//             //     selectedTab: "general",
//             // });
//             moxios.install(axiosInstance);
//             localStorage.setItem(BROWSER_STORAGE_KEY_COMPANY_CODE, 'IBS')
//             localStorage.setItem(BROWSER_STORAGE_KEY_PROGRAM_CODE, 'PRG14')
//             localStorage.setItem(BROWSER_STORAGE_KEY_MEMBERSHIP_NO, 'IM0008010415')
//             // window.sessionStorage.setItem('programCode', 'PRG14')
//             // localStorage.setItem(SESSION_STORAGE_MEMBERSHIP_NO, 'IM0008010415')
//         });

//         afterEach(() => {
//             moxios.uninstall(axiosInstance);
//         });

//         // describe('Success scenarios',()=>{
//         //     it('Buy points: Fetch configuration for buy point and render without errors and submit', () => {
//         //         mockServiceResponse(CONFIG_RESPONSE)
//         //         return ReactTestUtils.act(() => {
//         //             return store.dispatch(fetchConfiguration(CONFIG_SECTION_BUYPOINT))
//         //                 .then(() => {
//         //                     expect(newState.configurationReducer[CONFIG_SECTION_BUYPOINT]).toBe(CONFIG_RESPONSE.object);
//         //                     let data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "title": "Mr", "givenName": "Prithviraj", "familyName": "Sukumaran", "membershipType": "Individual", "membershipStatus": "Active", "membershipStatusCode": "A", "accountStatus": "Active", "accountStatusCode": "A", "suspended": false, "tierCode": "BLU", "tierName": "Blue", "tierFromDate": "01-Jul-2020", "tierToDate": "", "prospectTier": "", "companyName": "", "expiryDate": null, "lastActivityDate": "15-Jul-2020", "activityType": "Buy Points", "expiryDetails": [{ "pointType": "BONUS", "points": 500.0, "expiryDate": "31-Jul-2023" }, { "pointType": "BASE", "points": 10000.0, "expiryDate": "31-Jul-2023" }], "pointDetails": [{ "pointType": "BASE", "pointTypeGroup": "Total Miles", "totalAccuredpoints": 11000.0, "totalRedeemedpoints": 1000.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 10000.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "BONUS", "pointTypeGroup": "Total Miles", "totalAccuredpoints": 500.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 500.0, "bonusDetails": [{ "bonusCode": "ENB", "bonusName": "Enrolment Partner Bonus", "points": 500.0 }], "creditLimit": 0.0 }, { "pointType": "TIER", "pointTypeGroup": "Qualifying Miles", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "TIERKE", "pointTypeGroup": "Qualifying Miles", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "FS", "pointTypeGroup": "Qualifying Segments", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "FC", "pointTypeGroup": "Qualifying Segments", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }] } }
//         //                     mockServiceResponse(data)
//         //                     return ReactTestUtils.act(() => {
//         //                         return store.dispatch(fetchAccountSummary({ "test": "test" }))
//         //                             .then(() => {
//         //                                 updateComponents();
//         //                                 const newState = store.getState();
//         //                                 expect(newState.accountSummaryReducer.accountSummary).toBe(data.object);
    
//         //                                // rootComponent = rootComponent.update()
//         //                                 //component = findComponent(rootComponent, 'BuyPoints');
    
//         //                                 // const buyPointsComponent = findByTestAttr(component, 'buyPointsComponent');
//         //                                 // expect(buyPointsComponent.length).toBe(1);
    
//         //                                 // const buyPointTab = findByTestAttr(component, 'buyPointTab')
//         //                                 // expect(buyPointTab.length).toBe(1);
//         //                                 // buyPointTab.simulate('click', { target: { value: 0 } })
    
                                        
//         //                                 updateComponents();
                                       
//         //                                 console.log("+++++++++",component.debug() )
//         //                                 const buyMilesComponent = findByTestAttr(component, 'buyMilesComponent')
//         //                                 expect(buyMilesComponent.length).toBe(1)
//         //                                 console.log("===========",buyMilesComponent.debug() )
//         //                                 // const generalBuyComponent = findByTestAttr(component, 'generalBuyComponent')
//         //                                 // expect(generalBuyComponent.length).toBe(1)
//         //                                 // const selectedPoints = findByTestAttr(component, 'selectedPoints')
//         //                                 // expect(selectedPoints.length).toBe(1);
//         //                                 // selectedPoints.simulate('change', { target: { value: 2000 } })

//         //                                 // rootComponent = rootComponent.update()
//         //                                 // const acceptTermsCheckbox = findByTestAttr(component, 'AcceptTermsCheckbox')
//         //                                 // expect(acceptTermsCheckbox.length).toBe(1);
//         //                                 // acceptTermsCheckbox.simulate('change')
    
//         //                                 // rootComponent = rootComponent.update()
//         //                                 // component = findComponent(rootComponent, 'BuyMiles');
    
//         //                                 // const pinTextBox = findByTestAttr(component, 'PinTextBox')
//         //                                 // expect(pinTextBox.length).toBe(1);
//         //                                 // pinTextBox.simulate('change', { target: { value: '1234' } })
    
//         //                                 // rootComponent = rootComponent.update()
//         //                                 // component = findComponent(rootComponent, 'BuyMiles');
    
//         //                                 // const btnProceedTobuy = findByTestAttr(component, 'btnProceedTobuy')
//         //                                 // expect(btnProceedTobuy.length).toBe(1);
//         //                                 // btnProceedTobuy.simulate('click')
//         //                                 // mockServiceResponse(AUTH_RESPONSE)
//         //                                 // return ReactTestUtils.act(() => {
//         //                                 //     return store.dispatch(authenticateTransaction({ "test": "test" },  {loading: true, divId: ID_SPINNER_PROCEED_TO_PAY})).then(() => {
//         //                                 //         component.setState({
//         //                                 //             acceptPaymentInvoked: false
//         //                                 //         })
//         //                                 //         rootComponent = rootComponent.update()
//         //                                 //         component = findComponent(rootComponent, 'BuyMiles')
//         //                                 //         let newState = store.getState();
//         //                                 //         expect(newState.authenticateTransactionReducer.authenticateTransaction).toBe(AUTH_RESPONSE.object);
//         //                                 //         let data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "redirectURL": window.location.href + "payment=success&&", "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010415", "transactionID": "1B8BCAE337FF4CD0219E38EA937C478C", "tiercode": null, "memberActivityStatus": { "accountStatus": null, "activityNumber": "ACT4116", "activityType": "BP", "activityName": "BUY_POINTS", "activityStatus": "D", "activityCode": "BP", "pointDetails": [{ "pointType": "BASE", "points": 1000.0, "isBonus": true, "expiryDate": "15-Feb-2024" }] } } }
//         //                                 //         mockServiceResponse(data)
//         //                                 //         return ReactTestUtils.act(() => {
//         //                                 //             return store.dispatch(buyPointAction({ "test": "test" }))
//         //                                 //                 .then(() => {
//         //                                 //                     newState = store.getState();
//         //                                 //                     expect(newState.buyPointReducer.buyPointData).toBe(data.object);
//         //                                 //                     data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010415", "transactionId": "434D7C7518FB20E075D63707A882A5EF", "acceptPaymentStatus": true, "activityNumber": "ACT4117" } };
//         //                                 //                     mockServiceResponse(data);
//         //                                 //                     window.sessionStorage.setItem('transactionId', '434D7C7518FB20E075D63707A882A5EF')
//         //                                 //                     window.sessionStorage.setItem('activityNumber', 'ACT4117')
//         //                                 //                     return ReactTestUtils.act(() => {
//         //                                 //                         return store.dispatch(buyPointAcceptPayment({ "test": "test" }))
//         //                                 //                             .then(() => {
//         //                                 //                                 newState = store.getState();
//         //                                 //                                 expect(newState.buyPointAcceptReducer.acceptPayment).toBe(data.object);
//         //                                 //                                 data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "status": true, "membershipNumber": "IM0008010415", "transactionID": "434D7C7518FB20E075D63707A882A5EF", "activityNumber": "ACT4117" } }
//         //                                 //                                 mockServiceResponse(data);
//         //                                 //                                 component.setState({
//         //                                 //                                     paymentResponse: true,
//         //                                 //                                     paymentStatus: "success",
//         //                                 //                                     paymentMessage: ["You have purchased 2000 Skypass miles successfully. Your balance: 10000 miles."]
//         //                                 //                                 })
//         //                                 //                                 rootComponent.update();
//         //                                 //                                 component = findComponent(rootComponent, 'BuyMiles')
//         //                                 //                                 return ReactTestUtils.act(() => {
//         //                                 //                                     return store.dispatch(transactionLogout({ "test": "test" }))
//         //                                 //                                         .then(() => {
//         //                                 //                                             newState = store.getState();
//         //                                 //                                             expect(newState.logoutTransactionReducer.logoutTransaction).toBe(data.object);
//         //                                 //                                         })
//         //                                 //                                 });
//         //                                 //                             });
//         //                                 //                     });
//         //                                 //                 })
//         //                                 //         });
//         //                                 //     });
//         //                                 // });
//         //                             })
//         //                     });
    
    
//         //                 })
//         //         });
    
//         //     });
    
//         //     // it('Buy points: Fetch configuration for buy point and render without errors and clear form', () => {
//         //     //     mockServiceResponse(CONFIG_RESPONSE)
//         //     //     return ReactTestUtils.act(() => {
//         //     //         return store.dispatch(fetchConfiguration(CONFIG_SECTION_BUYPOINT))
//         //     //             .then(() => {
//         //     //                 let data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "title": "Mr", "givenName": "Prithviraj", "familyName": "Sukumaran", "membershipType": "Individual", "membershipStatus": "Active", "membershipStatusCode": "A", "accountStatus": "Active", "accountStatusCode": "A", "suspended": false, "tierCode": "BLU", "tierName": "Blue", "tierFromDate": "01-Jul-2020", "tierToDate": "", "prospectTier": "", "companyName": "", "expiryDate": null, "lastActivityDate": "15-Jul-2020", "activityType": "Buy Points", "expiryDetails": [{ "pointType": "BONUS", "points": 500.0, "expiryDate": "31-Jul-2023" }, { "pointType": "BASE", "points": 10000.0, "expiryDate": "31-Jul-2023" }], "pointDetails": [{ "pointType": "BASE", "pointTypeGroup": "Total Miles", "totalAccuredpoints": 11000.0, "totalRedeemedpoints": 1000.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 10000.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "BONUS", "pointTypeGroup": "Total Miles", "totalAccuredpoints": 500.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 500.0, "bonusDetails": [{ "bonusCode": "ENB", "bonusName": "Enrolment Partner Bonus", "points": 500.0 }], "creditLimit": 0.0 }, { "pointType": "TIER", "pointTypeGroup": "Qualifying Miles", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "TIERKE", "pointTypeGroup": "Qualifying Miles", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "FS", "pointTypeGroup": "Qualifying Segments", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "FC", "pointTypeGroup": "Qualifying Segments", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }] } }
//         //     //                 mockServiceResponse(data)
//         //     //                 return ReactTestUtils.act(() => {
//         //     //                     return store.dispatch(fetchAccountSummary({ "test": "test" }))
//         //     //                         .then(() => {
//         //     //                             const newState = store.getState();
//         //     //                             expect(newState.accountSummaryReducer.accountSummary).toBe(data.object);
//         //     //                             expect(newState.configurationReducer[CONFIG_SECTION_BUYPOINT]).toBe(CONFIG_RESPONSE.object);
    
//         //     //                             rootComponent = rootComponent.update()
//         //     //                             component = findComponent(rootComponent, 'BuyPoints');
    
//         //     //                             // const buyPointsComponent = findByTestAttr(component, 'buyPointsComponent');
//         //     //                             // expect(buyPointsComponent.length).toBe(1);
    
//         //     //                             // const buyPointTab = findByTestAttr(component, 'buyPointTab')
//         //     //                             // expect(buyPointTab.length).toBe(1);
//         //     //                             // buyPointTab.simulate('click', { target: { value: 0 } })

    
//         //     //                             rootComponent = rootComponent.update()
//         //     //                             component = findComponent(rootComponent, 'BuyMiles');
//         //     //                             const selectedPoints = findByTestAttr(component, 'selectedPoints')
//         //     //                             expect(selectedPoints.length).toBe(1);
//         //     //                             selectedPoints.simulate('change', { target: { value: 2000 } })

//         //     //                             rootComponent = rootComponent.update()
//         //     //                             const acceptTermsCheckbox = findByTestAttr(component, 'AcceptTermsCheckbox')
//         //     //                             expect(acceptTermsCheckbox.length).toBe(1);
//         //     //                             acceptTermsCheckbox.simulate('change')
    
//         //     //                             rootComponent = rootComponent.update()
//         //     //                             component = findComponent(rootComponent, 'BuyMiles');
    
//         //     //                             const pinTextBox = findByTestAttr(component, 'PinTextBox')
//         //     //                             expect(pinTextBox.length).toBe(1);
//         //     //                             pinTextBox.simulate('change', { target: { value: '1234' } })
    
//         //     //                             rootComponent = rootComponent.update()
//         //     //                             component = findComponent(rootComponent, 'BuyMiles');
    
//         //     //                             const btnCancel = findByTestAttr(component, 'btnCancel')
//         //     //                             expect(btnCancel.length).toBe(1);
//         //     //                             btnCancel.simulate('click')
//         //     //                         })
//         //     //                 });
    
    
//         //     //             })
//         //     //     });
    
//         //     // });
        
//         // })


//         // describe('Failure scenarios',()=>{
//         //     it('Buy Points: Payment Failure', () => {
//         //         mockServiceResponse(CONFIG_RESPONSE_UNPROTECTED_API)
//         //         return ReactTestUtils.act(() => {
//         //             return store.dispatch(fetchConfiguration(CONFIG_SECTION_BUYPOINT))
//         //                 .then(() => {
//         //                     let data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "title": "Mr", "givenName": "Prithviraj", "familyName": "Sukumaran", "membershipType": "Individual", "membershipStatus": "Active", "membershipStatusCode": "A", "accountStatus": "Active", "accountStatusCode": "A", "suspended": false, "tierCode": "BLU", "tierName": "Blue", "tierFromDate": "01-Jul-2020", "tierToDate": "", "prospectTier": "", "companyName": "", "expiryDate": null, "lastActivityDate": "15-Jul-2020", "activityType": "Buy Points", "expiryDetails": [{ "pointType": "BONUS", "points": 500.0, "expiryDate": "31-Jul-2023" }, { "pointType": "BASE", "points": 10000.0, "expiryDate": "31-Jul-2023" }], "pointDetails": [{ "pointType": "BASE", "pointTypeGroup": "Total Miles", "totalAccuredpoints": 11000.0, "totalRedeemedpoints": 1000.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 10000.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "BONUS", "pointTypeGroup": "Total Miles", "totalAccuredpoints": 500.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 500.0, "bonusDetails": [{ "bonusCode": "ENB", "bonusName": "Enrolment Partner Bonus", "points": 500.0 }], "creditLimit": 0.0 }, { "pointType": "TIER", "pointTypeGroup": "Qualifying Miles", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "TIERKE", "pointTypeGroup": "Qualifying Miles", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "FS", "pointTypeGroup": "Qualifying Segments", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "FC", "pointTypeGroup": "Qualifying Segments", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }] } }
//         //                     mockServiceResponse(data)
//         //                     return ReactTestUtils.act(() => {
//         //                         return store.dispatch(fetchAccountSummary({ "test": "test" }))
//         //                             .then(() => {
//         //                                 const newState = store.getState();
//         //                                 expect(newState.accountSummaryReducer.accountSummary).toBe(data.object);
//         //                                 expect(newState.configurationReducer[CONFIG_SECTION_BUYPOINT]).toBe(CONFIG_RESPONSE_UNPROTECTED_API.object);
    
//         //                                 rootComponent = rootComponent.update()
//         //                                 component = findComponent(rootComponent, 'BuyPoints');
    
//         //                                 // const buyPointsComponent = findByTestAttr(component, 'buyPointsComponent');
//         //                                 // expect(buyPointsComponent.length).toBe(1);
    
//         //                                 // const buyPointTab = findByTestAttr(component, 'buyPointTab')
//         //                                 // expect(buyPointTab.length).toBe(1);
//         //                                 // buyPointTab.simulate('click', { target: { value: 0 } })
    
                                        
    
//         //                                 rootComponent = rootComponent.update()
//         //                                 component = findComponent(rootComponent, 'BuyMiles');

//         //                                 const selectedPoints = findByTestAttr(component, 'selectedPoints')
//         //                                 expect(selectedPoints.length).toBe(1);
//         //                                 selectedPoints.simulate('change', { target: { value: 2000 } })

//         //                                 rootComponent = rootComponent.update()
//         //                                 const acceptTermsCheckbox = findByTestAttr(component, 'AcceptTermsCheckbox')
//         //                                 expect(acceptTermsCheckbox.length).toBe(1);
//         //                                 acceptTermsCheckbox.simulate('change')
    
//         //                                 rootComponent = rootComponent.update()
//         //                                 component = findComponent(rootComponent, 'BuyMiles');
    
//         //                                 const btnProceedTobuy = findByTestAttr(component, 'btnProceedTobuy')
//         //                                 expect(btnProceedTobuy.length).toBe(1);
//         //                                 btnProceedTobuy.simulate('click')
//         //                                 mockServiceResponse(AUTH_RESPONSE)
//         //                                 return ReactTestUtils.act(() => {
//         //                                     return store.dispatch(authenticateTransaction({ "test": "test" }, {loading: true, divId: ID_SPINNER_PROCEED_TO_PAY})).then(() => {
//         //                                         component.setState({
//         //                                             acceptPaymentInvoked: false
//         //                                         })
//         //                                         rootComponent = rootComponent.update()
//         //                                         component = findComponent(rootComponent, 'BuyMiles')
//         //                                         let newState = store.getState();
//         //                                         expect(newState.authenticateTransactionReducer.authenticateTransaction).toBe(AUTH_RESPONSE.object);
//         //                                         let data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "redirectURL": window.location.href + "payment=failed&&", "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010415", "transactionID": "1B8BCAE337FF4CD0219E38EA937C478C", "tiercode": null, "memberActivityStatus": { "accountStatus": null, "activityNumber": "ACT4116", "activityType": "BP", "activityName": "BUY_POINTS", "activityStatus": "D", "activityCode": "BP", "pointDetails": [{ "pointType": "BASE", "points": 1000.0, "isBonus": true, "expiryDate": "15-Feb-2024" }] } } }
//         //                                         mockServiceResponse(data)
//         //                                         return ReactTestUtils.act(() => {
//         //                                             return store.dispatch(buyPointAction({ "test": "test" }))
//         //                                                 .then(() => {
//         //                                                     newState = store.getState();
//         //                                                     expect(newState.buyPointReducer.buyPointData).toBe(data.object);
//         //                                                     data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010415", "transactionId": "434D7C7518FB20E075D63707A882A5EF", "acceptPaymentStatus": true, "activityNumber": "ACT4117" } };
//         //                                                     mockServiceResponse(data);
//         //                                                     window.sessionStorage.setItem('transactionId', '434D7C7518FB20E075D63707A882A5EF')
//         //                                                     window.sessionStorage.setItem('activityNumber', 'ACT4117')
//         //                                                     return ReactTestUtils.act(() => {
//         //                                                         return store.dispatch(buyPointAcceptPayment({ "test": "test" }))
//         //                                                             .then(() => {
//         //                                                                 newState = store.getState();
//         //                                                                 expect(newState.buyPointAcceptReducer.acceptPayment).toBe(data.object);
//         //                                                                 data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "status": true, "membershipNumber": "IM0008010415", "transactionID": "434D7C7518FB20E075D63707A882A5EF", "activityNumber": "ACT4117" } }
//         //                                                                 mockServiceResponse(data);
//         //                                                                 component.setState({
//         //                                                                     paymentResponse: true,
//         //                                                                     paymentStatus: "failed",
//         //                                                                     paymentMessage: ["Payment failed."]
//         //                                                                 })
//         //                                                                 rootComponent.update();
//         //                                                                 component = findComponent(rootComponent, 'BuyMiles')
//         //                                                                 return ReactTestUtils.act(() => {
//         //                                                                     return store.dispatch(transactionLogout({ "test": "test" }))
//         //                                                                         .then(() => {
//         //                                                                             newState = store.getState();
//         //                                                                             expect(newState.logoutTransactionReducer.logoutTransaction).toBe(data.object);
//         //                                                                         })
//         //                                                                 });
//         //                                                             });
//         //                                                     });
//         //                                                 })
//         //                                         });
//         //                                     });
//         //                                 });
//         //                             })
//         //                     });
    
    
//         //                 })
//         //         });
    
//         //     })

//         //     it('Buy Points: Payment Failure with payment required', () => {
//         //         mockServiceResponse(CONFIG_RESPONSE_UNPROTECTED_API_WO_PAYMENT)
//         //         return ReactTestUtils.act(() => {
//         //             return store.dispatch(fetchConfiguration(CONFIG_SECTION_BUYPOINT))
//         //                 .then(() => {
//         //                     let data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "title": "Mr", "givenName": "Prithviraj", "familyName": "Sukumaran", "membershipType": "Individual", "membershipStatus": "Active", "membershipStatusCode": "A", "accountStatus": "Active", "accountStatusCode": "A", "suspended": false, "tierCode": "BLU", "tierName": "Blue", "tierFromDate": "01-Jul-2020", "tierToDate": "", "prospectTier": "", "companyName": "", "expiryDate": null, "lastActivityDate": "15-Jul-2020", "activityType": "Buy Points", "expiryDetails": [{ "pointType": "BONUS", "points": 500.0, "expiryDate": "31-Jul-2023" }, { "pointType": "BASE", "points": 10000.0, "expiryDate": "31-Jul-2023" }], "pointDetails": [{ "pointType": "BASE", "pointTypeGroup": "Total Miles", "totalAccuredpoints": 11000.0, "totalRedeemedpoints": 1000.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 10000.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "BONUS", "pointTypeGroup": "Total Miles", "totalAccuredpoints": 500.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 500.0, "bonusDetails": [{ "bonusCode": "ENB", "bonusName": "Enrolment Partner Bonus", "points": 500.0 }], "creditLimit": 0.0 }, { "pointType": "TIER", "pointTypeGroup": "Qualifying Miles", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "TIERKE", "pointTypeGroup": "Qualifying Miles", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "FS", "pointTypeGroup": "Qualifying Segments", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "FC", "pointTypeGroup": "Qualifying Segments", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }] } }
//         //                     mockServiceResponse(data)
//         //                     return ReactTestUtils.act(() => {
//         //                         return store.dispatch(fetchAccountSummary({ "test": "test" }))
//         //                             .then(() => {
//         //                                 const newState = store.getState();
//         //                                 expect(newState.accountSummaryReducer.accountSummary).toBe(data.object);
//         //                                 expect(newState.configurationReducer[CONFIG_SECTION_BUYPOINT]).toBe(CONFIG_RESPONSE_UNPROTECTED_API_WO_PAYMENT.object);
    
//         //                                 rootComponent = rootComponent.update()
//         //                                 component = findComponent(rootComponent, 'BuyPoints');
    
//         //                                 // const buyPointsComponent = findByTestAttr(component, 'buyPointsComponent');
//         //                                 // expect(buyPointsComponent.length).toBe(1);
    
//         //                                 // const buyPointTab = findByTestAttr(component, 'buyPointTab')
//         //                                 // expect(buyPointTab.length).toBe(1);
//         //                                 // buyPointTab.simulate('click', { target: { value: 0 } })
    
                                        
    
//         //                                 rootComponent = rootComponent.update()
//         //                                 component = findComponent(rootComponent, 'BuyMiles');

//         //                                 const selectedPoints = findByTestAttr(component, 'selectedPoints')
//         //                                 expect(selectedPoints.length).toBe(1);
//         //                                 selectedPoints.simulate('change', { target: { value: 2000 } })

//         //                                 rootComponent = rootComponent.update()
//         //                                 const acceptTermsCheckbox = findByTestAttr(component, 'AcceptTermsCheckbox')
//         //                                 expect(acceptTermsCheckbox.length).toBe(1);
//         //                                 acceptTermsCheckbox.simulate('change')
    
//         //                                 rootComponent = rootComponent.update()
//         //                                 component = findComponent(rootComponent, 'BuyMiles');
    
//         //                                 const btnProceedTobuy = findByTestAttr(component, 'btnProceedTobuy')
//         //                                 expect(btnProceedTobuy.length).toBe(1);
//         //                                 btnProceedTobuy.simulate('click')
//         //                                 mockServiceResponse(AUTH_RESPONSE)
//         //                                 return ReactTestUtils.act(() => {
//         //                                     return store.dispatch(authenticateTransaction({ "test": "test" }, {loading: true, divId: ID_SPINNER_PROCEED_TO_PAY})).then(() => {
//         //                                         component.setState({
//         //                                             acceptPaymentInvoked: false
//         //                                         })
//         //                                         rootComponent = rootComponent.update()
//         //                                         component = findComponent(rootComponent, 'BuyMiles')
//         //                                         let newState = store.getState();
//         //                                         expect(newState.authenticateTransactionReducer.authenticateTransaction).toBe(AUTH_RESPONSE.object);
//         //                                         let data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "redirectURL": window.location.href + "payment=failed&&", "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010415", "transactionID": "1B8BCAE337FF4CD0219E38EA937C478C", "tiercode": null, "memberActivityStatus": { "accountStatus": null, "activityNumber": "ACT4116", "activityType": "BP", "activityName": "BUY_POINTS", "activityStatus": "D", "activityCode": "BP", "pointDetails": [{ "pointType": "BASE", "points": 1000.0, "isBonus": true, "expiryDate": "15-Feb-2024" }] } } }
//         //                                         mockServiceResponse(data)
//         //                                         return ReactTestUtils.act(() => {
//         //                                             return store.dispatch(buyPointAction({ "test": "test" }))
//         //                                                 .then(() => {
//         //                                                     newState = store.getState();
//         //                                                     expect(newState.buyPointReducer.buyPointData).toBe(data.object);
//         //                                                     data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010415", "transactionId": "434D7C7518FB20E075D63707A882A5EF", "acceptPaymentStatus": true, "activityNumber": "ACT4117" } };
//         //                                                     mockServiceResponse(data);
//         //                                                     window.sessionStorage.setItem('transactionId', '434D7C7518FB20E075D63707A882A5EF')
//         //                                                     window.sessionStorage.setItem('activityNumber', 'ACT4117')
//         //                                                     return ReactTestUtils.act(() => {
//         //                                                         return store.dispatch(buyPointAcceptPayment({ "test": "test" }))
//         //                                                             .then(() => {
//         //                                                                 newState = store.getState();
//         //                                                                 expect(newState.buyPointAcceptReducer.acceptPayment).toBe(data.object);
//         //                                                                 data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "status": true, "membershipNumber": "IM0008010415", "transactionID": "434D7C7518FB20E075D63707A882A5EF", "activityNumber": "ACT4117" } }
//         //                                                                 mockServiceResponse(data);
//         //                                                                 component.setState({
//         //                                                                     paymentResponse: true,
//         //                                                                     paymentStatus: "failed",
//         //                                                                     paymentMessage: ["Payment failed."]
//         //                                                                 })
//         //                                                                 rootComponent.update();
//         //                                                                 component = findComponent(rootComponent, 'BuyMiles')
//         //                                                                 return ReactTestUtils.act(() => {
//         //                                                                     return store.dispatch(transactionLogout({ "test": "test" }))
//         //                                                                         .then(() => {
//         //                                                                             newState = store.getState();
//         //                                                                             expect(newState.logoutTransactionReducer.logoutTransaction).toBe(data.object);
//         //                                                                         })
//         //                                                                 });
//         //                                                             });
//         //                                                     });
//         //                                                 })
//         //                                         });
//         //                                     });
//         //                                 });
//         //                             })
//         //                     });
    
    
//         //                 })
//         //         });
    
//         //     })

//         //     it('Buy Points: Payment Cancelled', () => {
//         //         mockServiceResponse(CONFIG_RESPONSE_UNPROTECTED_API)
//         //         return ReactTestUtils.act(() => {
//         //             return store.dispatch(fetchConfiguration(CONFIG_SECTION_BUYPOINT))
//         //                 .then(() => {
//         //                     let data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "title": "Mr", "givenName": "Prithviraj", "familyName": "Sukumaran", "membershipType": "Individual", "membershipStatus": "Active", "membershipStatusCode": "A", "accountStatus": "Active", "accountStatusCode": "A", "suspended": false, "tierCode": "BLU", "tierName": "Blue", "tierFromDate": "01-Jul-2020", "tierToDate": "", "prospectTier": "", "companyName": "", "expiryDate": null, "lastActivityDate": "15-Jul-2020", "activityType": "Buy Points", "expiryDetails": [{ "pointType": "BONUS", "points": 500.0, "expiryDate": "31-Jul-2023" }, { "pointType": "BASE", "points": 10000.0, "expiryDate": "31-Jul-2023" }], "pointDetails": [{ "pointType": "BASE", "pointTypeGroup": "Total Miles", "totalAccuredpoints": 11000.0, "totalRedeemedpoints": 1000.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 10000.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "BONUS", "pointTypeGroup": "Total Miles", "totalAccuredpoints": 500.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 500.0, "bonusDetails": [{ "bonusCode": "ENB", "bonusName": "Enrolment Partner Bonus", "points": 500.0 }], "creditLimit": 0.0 }, { "pointType": "TIER", "pointTypeGroup": "Qualifying Miles", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "TIERKE", "pointTypeGroup": "Qualifying Miles", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "FS", "pointTypeGroup": "Qualifying Segments", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "FC", "pointTypeGroup": "Qualifying Segments", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }] } }
//         //                     mockServiceResponse(data)
//         //                     return ReactTestUtils.act(() => {
//         //                         return store.dispatch(fetchAccountSummary({ "test": "test" }))
//         //                             .then(() => {
//         //                                 const newState = store.getState();
//         //                                 expect(newState.accountSummaryReducer.accountSummary).toBe(data.object);
//         //                                 expect(newState.configurationReducer[CONFIG_SECTION_BUYPOINT]).toBe(CONFIG_RESPONSE_UNPROTECTED_API.object);
    
//         //                                 rootComponent = rootComponent.update()
//         //                                 component = findComponent(rootComponent, 'BuyPoints');
    
//         //                                 // const buyPointsComponent = findByTestAttr(component, 'buyPointsComponent');
//         //                                 // expect(buyPointsComponent.length).toBe(1);
    
//         //                                 // const buyPointTab = findByTestAttr(component, 'buyPointTab')
//         //                                 // expect(buyPointTab.length).toBe(1);
//         //                                 // buyPointTab.simulate('click', { target: { value: 0 } })
    
//         //                                 const selectedPoints = findByTestAttr(component, 'selectedPoints')
//         //                                 expect(selectedPoints.length).toBe(1);
//         //                                 selectedPoints.simulate('change', { target: { value: 2000 } })
    
//         //                                 rootComponent = rootComponent.update()
//         //                                 component = findComponent(rootComponent, 'BuyMiles');
//         //                                 const acceptTermsCheckbox = findByTestAttr(component, 'AcceptTermsCheckbox')
//         //                                 expect(acceptTermsCheckbox.length).toBe(1);
//         //                                 acceptTermsCheckbox.simulate('change')
    
//         //                                 rootComponent = rootComponent.update()
//         //                                 component = findComponent(rootComponent, 'BuyMiles');
    
//         //                                 const btnProceedTobuy = findByTestAttr(component, 'btnProceedTobuy')
//         //                                 expect(btnProceedTobuy.length).toBe(1);
//         //                                 btnProceedTobuy.simulate('click')
//         //                                 mockServiceResponse(AUTH_RESPONSE)
//         //                                 return ReactTestUtils.act(() => {
//         //                                     return store.dispatch(authenticateTransaction({ "test": "test" }, {loading: true, divId: ID_SPINNER_PROCEED_TO_PAY})).then(() => {
//         //                                         component.setState({
//         //                                             acceptPaymentInvoked: false
//         //                                         })
//         //                                         rootComponent = rootComponent.update()
//         //                                         component = findComponent(rootComponent, 'BuyMiles')
//         //                                         let newState = store.getState();
//         //                                         expect(newState.authenticateTransactionReducer.authenticateTransaction).toBe(AUTH_RESPONSE.object);
//         //                                         let data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "redirectURL": window.location.href + "payment=cancelled&&", "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010415", "transactionID": "1B8BCAE337FF4CD0219E38EA937C478C", "tiercode": null, "memberActivityStatus": { "accountStatus": null, "activityNumber": "ACT4116", "activityType": "BP", "activityName": "BUY_POINTS", "activityStatus": "D", "activityCode": "BP", "pointDetails": [{ "pointType": "BASE", "points": 1000.0, "isBonus": true, "expiryDate": "15-Feb-2024" }] } } }
//         //                                         mockServiceResponse(data)
//         //                                         return ReactTestUtils.act(() => {
//         //                                             return store.dispatch(buyPointAction({ "test": "test" }))
//         //                                                 .then(() => {
//         //                                                     newState = store.getState();
//         //                                                     expect(newState.buyPointReducer.buyPointData).toBe(data.object);
//         //                                                     data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010415", "transactionId": "434D7C7518FB20E075D63707A882A5EF", "acceptPaymentStatus": true, "activityNumber": "ACT4117" } };
//         //                                                     mockServiceResponse(data);
//         //                                                     window.sessionStorage.setItem('transactionId', '434D7C7518FB20E075D63707A882A5EF')
//         //                                                     window.sessionStorage.setItem('activityNumber', 'ACT4117')
//         //                                                     return ReactTestUtils.act(() => {
//         //                                                         return store.dispatch(buyPointAcceptPayment({ "test": "test" }))
//         //                                                             .then(() => {
//         //                                                                 newState = store.getState();
//         //                                                                 expect(newState.buyPointAcceptReducer.acceptPayment).toBe(data.object);
//         //                                                                 data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "status": true, "membershipNumber": "IM0008010415", "transactionID": "434D7C7518FB20E075D63707A882A5EF", "activityNumber": "ACT4117" } }
//         //                                                                 mockServiceResponse(data);
//         //                                                                 component.setState({
//         //                                                                     paymentResponse: true,
//         //                                                                     paymentStatus: "failed",
//         //                                                                     paymentMessage: ["Payment failed."]
//         //                                                                 })
//         //                                                                 rootComponent.update();
//         //                                                                 component = findComponent(rootComponent, 'BuyMiles')
//         //                                                                 return ReactTestUtils.act(() => {
//         //                                                                     return store.dispatch(transactionLogout({ "test": "test" }))
//         //                                                                         .then(() => {
//         //                                                                             newState = store.getState();
//         //                                                                             expect(newState.logoutTransactionReducer.logoutTransaction).toBe(data.object);
//         //                                                                         })
//         //                                                                 });
//         //                                                             });
//         //                                                     });
//         //                                                 })
//         //                                         });
//         //                                     });
//         //                                 });
//         //                             })
//         //                     });
    
    
//         //                 })
//         //         });
    
//         //     })

//         //     it('Buy Points: Payment Failed and returned unrecognized URL', () => {
//         //         mockServiceResponse(CONFIG_RESPONSE_UNPROTECTED_API)
//         //         return ReactTestUtils.act(() => {
//         //             return store.dispatch(fetchConfiguration(CONFIG_SECTION_BUYPOINT))
//         //                 .then(() => {
//         //                     let data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "title": "Mr", "givenName": "Prithviraj", "familyName": "Sukumaran", "membershipType": "Individual", "membershipStatus": "Active", "membershipStatusCode": "A", "accountStatus": "Active", "accountStatusCode": "A", "suspended": false, "tierCode": "BLU", "tierName": "Blue", "tierFromDate": "01-Jul-2020", "tierToDate": "", "prospectTier": "", "companyName": "", "expiryDate": null, "lastActivityDate": "15-Jul-2020", "activityType": "Buy Points", "expiryDetails": [{ "pointType": "BONUS", "points": 500.0, "expiryDate": "31-Jul-2023" }, { "pointType": "BASE", "points": 10000.0, "expiryDate": "31-Jul-2023" }], "pointDetails": [{ "pointType": "BASE", "pointTypeGroup": "Total Miles", "totalAccuredpoints": 11000.0, "totalRedeemedpoints": 1000.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 10000.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "BONUS", "pointTypeGroup": "Total Miles", "totalAccuredpoints": 500.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 500.0, "bonusDetails": [{ "bonusCode": "ENB", "bonusName": "Enrolment Partner Bonus", "points": 500.0 }], "creditLimit": 0.0 }, { "pointType": "TIER", "pointTypeGroup": "Qualifying Miles", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "TIERKE", "pointTypeGroup": "Qualifying Miles", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "FS", "pointTypeGroup": "Qualifying Segments", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "FC", "pointTypeGroup": "Qualifying Segments", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }] } }
//         //                     mockServiceResponse(data)
//         //                     return ReactTestUtils.act(() => {
//         //                         return store.dispatch(fetchAccountSummary({ "test": "test" }))
//         //                             .then(() => {
//         //                                 const newState = store.getState();
//         //                                 expect(newState.accountSummaryReducer.accountSummary).toBe(data.object);
//         //                                 expect(newState.configurationReducer[CONFIG_SECTION_BUYPOINT]).toBe(CONFIG_RESPONSE_UNPROTECTED_API.object);
    
//         //                                 rootComponent = rootComponent.update()
//         //                                 component = findComponent(rootComponent, 'BuyPoints');
    
//         //                                 // const buyPointsComponent = findByTestAttr(component, 'buyPointsComponent');
//         //                                 // expect(buyPointsComponent.length).toBe(1);
    
//         //                                 // const buyPointTab = findByTestAttr(component, 'buyPointTab')
//         //                                 // expect(buyPointTab.length).toBe(1);
//         //                                 // buyPointTab.simulate('click', { target: { value: 0 } })
    
//         //                                 const selectedPoints = findByTestAttr(component, 'selectedPoints')
//         //                                 expect(selectedPoints.length).toBe(1);
//         //                                 selectedPoints.simulate('change', { target: { value: 2000 } })
    
//         //                                 rootComponent = rootComponent.update()
//         //                                 component = findComponent(rootComponent, 'BuyMiles');
//         //                                 const acceptTermsCheckbox = findByTestAttr(component, 'AcceptTermsCheckbox')
//         //                                 expect(acceptTermsCheckbox.length).toBe(1);
//         //                                 acceptTermsCheckbox.simulate('change')
    
//         //                                 rootComponent = rootComponent.update()
//         //                                 component = findComponent(rootComponent, 'BuyMiles');
    
//         //                                 const btnProceedTobuy = findByTestAttr(component, 'btnProceedTobuy')
//         //                                 expect(btnProceedTobuy.length).toBe(1);
//         //                                 btnProceedTobuy.simulate('click')
//         //                                 mockServiceResponse(AUTH_RESPONSE)
//         //                                 return ReactTestUtils.act(() => {
//         //                                     return store.dispatch(authenticateTransaction({ "test": "test" }, {loading: true, divId: ID_SPINNER_PROCEED_TO_PAY})).then(() => {
//         //                                         component.setState({
//         //                                             acceptPaymentInvoked: false
//         //                                         })
//         //                                         rootComponent = rootComponent.update()
//         //                                         component = findComponent(rootComponent, 'BuyMiles')
//         //                                         let newState = store.getState();
//         //                                         expect(newState.authenticateTransactionReducer.authenticateTransaction).toBe(AUTH_RESPONSE.object);
//         //                                         let data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "redirectURL": window.location.href + "payment=notfound&&", "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010415", "transactionID": "1B8BCAE337FF4CD0219E38EA937C478C", "tiercode": null, "memberActivityStatus": { "accountStatus": null, "activityNumber": "ACT4116", "activityType": "BP", "activityName": "BUY_POINTS", "activityStatus": "D", "activityCode": "BP", "pointDetails": [{ "pointType": "BASE", "points": 1000.0, "isBonus": true, "expiryDate": "15-Feb-2024" }] } } }
//         //                                         mockServiceResponse(data)
//         //                                         return ReactTestUtils.act(() => {
//         //                                             return store.dispatch(buyPointAction({ "test": "test" }))
//         //                                                 .then(() => {
//         //                                                     newState = store.getState();
//         //                                                     expect(newState.buyPointReducer.buyPointData).toBe(data.object);
//         //                                                     data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010415", "transactionId": "434D7C7518FB20E075D63707A882A5EF", "acceptPaymentStatus": true, "activityNumber": "ACT4117" } };
//         //                                                     mockServiceResponse(data);
//         //                                                     window.sessionStorage.setItem('transactionId', '434D7C7518FB20E075D63707A882A5EF')
//         //                                                     window.sessionStorage.setItem('activityNumber', 'ACT4117')
//         //                                                     return ReactTestUtils.act(() => {
//         //                                                         return store.dispatch(buyPointAcceptPayment({ "test": "test" }))
//         //                                                             .then(() => {
//         //                                                                 newState = store.getState();
//         //                                                                 expect(newState.buyPointAcceptReducer.acceptPayment).toBe(data.object);
//         //                                                                 data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "status": true, "membershipNumber": "IM0008010415", "transactionID": "434D7C7518FB20E075D63707A882A5EF", "activityNumber": "ACT4117" } }
//         //                                                                 mockServiceResponse(data);
//         //                                                                 component.setState({
//         //                                                                     paymentResponse: true,
//         //                                                                     paymentStatus: "failed",
//         //                                                                     paymentMessage: ["Payment failed."]
//         //                                                                 })
//         //                                                                 rootComponent.update();
//         //                                                                 component = findComponent(rootComponent, 'BuyMiles')
//         //                                                                 return ReactTestUtils.act(() => {
//         //                                                                     return store.dispatch(transactionLogout({ "test": "test" }))
//         //                                                                         .then(() => {
//         //                                                                             newState = store.getState();
//         //                                                                             expect(newState.logoutTransactionReducer.logoutTransaction).toBe(data.object);
//         //                                                                         })
//         //                                                                 });
//         //                                                             });
//         //                                                     });
//         //                                                 })
//         //                                         });
//         //                                     });
//         //                                 });
//         //                             })
//         //                     });
    
    
//         //                 })
//         //         });
    
//         //     })
    
//         //     it('Buy points: Payment Failure on Authentication', () => {
//         //         mockServiceResponse(CONFIG_RESPONSE)
//         //         return ReactTestUtils.act(() => {
//         //             return store.dispatch(fetchConfiguration(CONFIG_SECTION_BUYPOINT))
//         //                 .then(() => {
//         //                     let data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "title": "Mr", "givenName": "Prithviraj", "familyName": "Sukumaran", "membershipType": "Individual", "membershipStatus": "Active", "membershipStatusCode": "A", "accountStatus": "Active", "accountStatusCode": "A", "suspended": false, "tierCode": "BLU", "tierName": "Blue", "tierFromDate": "01-Jul-2020", "tierToDate": "", "prospectTier": "", "companyName": "", "expiryDate": null, "lastActivityDate": "15-Jul-2020", "activityType": "Buy Points", "expiryDetails": [{ "pointType": "BONUS", "points": 500.0, "expiryDate": "31-Jul-2023" }, { "pointType": "BASE", "points": 10000.0, "expiryDate": "31-Jul-2023" }], "pointDetails": [{ "pointType": "BASE", "pointTypeGroup": "Total Miles", "totalAccuredpoints": 11000.0, "totalRedeemedpoints": 1000.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 10000.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "BONUS", "pointTypeGroup": "Total Miles", "totalAccuredpoints": 500.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 500.0, "bonusDetails": [{ "bonusCode": "ENB", "bonusName": "Enrolment Partner Bonus", "points": 500.0 }], "creditLimit": 0.0 }, { "pointType": "TIER", "pointTypeGroup": "Qualifying Miles", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "TIERKE", "pointTypeGroup": "Qualifying Miles", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "FS", "pointTypeGroup": "Qualifying Segments", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "FC", "pointTypeGroup": "Qualifying Segments", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }] } }
//         //                     mockServiceResponse(data)
//         //                     return ReactTestUtils.act(() => {
//         //                         return store.dispatch(fetchAccountSummary({ "test": "test" }))
//         //                             .then(() => {
                                       
//         //                                 mockServiceResponse(AUTH_RESPONSE_FAIL, 500)
//         //                                 return ReactTestUtils.act(() => {
//         //                                     return store.dispatch(authenticateTransaction({ "test": "test" },  {loading: true, divId: ID_SPINNER_PROCEED_TO_PAY})).then(() => {
//         //                                         component.setState({
//         //                                             acceptPaymentInvoked: false
//         //                                         })
//         //                                         rootComponent = rootComponent.update()
//         //                                         component = findComponent(rootComponent, 'BuyMiles')
//         //                                         let newState = store.getState();
//         //                                         expect(newState.commonErrorReducer.error.message).toBe(AUTH_RESPONSE_FAIL_MSG);
//         //                                     });
//         //                                 });
//         //                             })
//         //                     });
    
    
//         //                 })
//         //         });
    
//         //     });
    
//         //     it('Buy points: Payment Failure on BuyPoint', () => {
//         //         mockServiceResponse(CONFIG_RESPONSE)
//         //         return ReactTestUtils.act(() => {
//         //             return store.dispatch(fetchConfiguration(CONFIG_SECTION_BUYPOINT))
//         //                 .then(() => {
//         //                     let data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "title": "Mr", "givenName": "Prithviraj", "familyName": "Sukumaran", "membershipType": "Individual", "membershipStatus": "Active", "membershipStatusCode": "A", "accountStatus": "Active", "accountStatusCode": "A", "suspended": false, "tierCode": "BLU", "tierName": "Blue", "tierFromDate": "01-Jul-2020", "tierToDate": "", "prospectTier": "", "companyName": "", "expiryDate": null, "lastActivityDate": "15-Jul-2020", "activityType": "Buy Points", "expiryDetails": [{ "pointType": "BONUS", "points": 500.0, "expiryDate": "31-Jul-2023" }, { "pointType": "BASE", "points": 10000.0, "expiryDate": "31-Jul-2023" }], "pointDetails": [{ "pointType": "BASE", "pointTypeGroup": "Total Miles", "totalAccuredpoints": 11000.0, "totalRedeemedpoints": 1000.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 10000.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "BONUS", "pointTypeGroup": "Total Miles", "totalAccuredpoints": 500.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 500.0, "bonusDetails": [{ "bonusCode": "ENB", "bonusName": "Enrolment Partner Bonus", "points": 500.0 }], "creditLimit": 0.0 }, { "pointType": "TIER", "pointTypeGroup": "Qualifying Miles", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "TIERKE", "pointTypeGroup": "Qualifying Miles", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "FS", "pointTypeGroup": "Qualifying Segments", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "FC", "pointTypeGroup": "Qualifying Segments", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }] } }
//         //                     mockServiceResponse(data)
//         //                     return ReactTestUtils.act(() => {
//         //                         return store.dispatch(fetchAccountSummary({ "test": "test" }))
//         //                             .then(() => {
//         //                                 mockServiceResponse(BUYPOINT_RESPONSE_FAIL, 500)
//         //                                 return ReactTestUtils.act(() => {
//         //                                     return store.dispatch(buyPointAction({ "test": "test" },  {loading: true, divId: ID_SPINNER_PROCEED_TO_PAY})).then(() => {
//         //                                         rootComponent = rootComponent.update()
//         //                                         component = findComponent(rootComponent, 'BuyMiles')
//         //                                         let newState = store.getState();
//         //                                         expect(newState.commonErrorReducer.error.message).toBe(BUYPOINT_RESPONSE_FAIL_MSG);
//         //                                     });
//         //                                 });
//         //                             })
//         //                     });
    
    
//         //                 })
//         //         });
    
//         //     });
    
//         //     it('Buy points: Payment Failure on Accept Payment', () => {
//         //         mockServiceResponse(CONFIG_RESPONSE)
//         //         return ReactTestUtils.act(() => {
//         //             return store.dispatch(fetchConfiguration(CONFIG_SECTION_BUYPOINT))
//         //                 .then(() => {
//         //                     let data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "title": "Mr", "givenName": "Prithviraj", "familyName": "Sukumaran", "membershipType": "Individual", "membershipStatus": "Active", "membershipStatusCode": "A", "accountStatus": "Active", "accountStatusCode": "A", "suspended": false, "tierCode": "BLU", "tierName": "Blue", "tierFromDate": "01-Jul-2020", "tierToDate": "", "prospectTier": "", "companyName": "", "expiryDate": null, "lastActivityDate": "15-Jul-2020", "activityType": "Buy Points", "expiryDetails": [{ "pointType": "BONUS", "points": 500.0, "expiryDate": "31-Jul-2023" }, { "pointType": "BASE", "points": 10000.0, "expiryDate": "31-Jul-2023" }], "pointDetails": [{ "pointType": "BASE", "pointTypeGroup": "Total Miles", "totalAccuredpoints": 11000.0, "totalRedeemedpoints": 1000.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 10000.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "BONUS", "pointTypeGroup": "Total Miles", "totalAccuredpoints": 500.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 500.0, "bonusDetails": [{ "bonusCode": "ENB", "bonusName": "Enrolment Partner Bonus", "points": 500.0 }], "creditLimit": 0.0 }, { "pointType": "TIER", "pointTypeGroup": "Qualifying Miles", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "TIERKE", "pointTypeGroup": "Qualifying Miles", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "FS", "pointTypeGroup": "Qualifying Segments", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "FC", "pointTypeGroup": "Qualifying Segments", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }] } }
//         //                     mockServiceResponse(data)
//         //                     return ReactTestUtils.act(() => {
//         //                         return store.dispatch(fetchAccountSummary({ "test": "test" }))
//         //                             .then(() => {
//         //                                 mockServiceResponse(ACCEPTPAYMENT_RESPONSE_FAIL, 500)
//         //                                 return ReactTestUtils.act(() => {
//         //                                     return store.dispatch(buyPointAcceptPayment({ "test": "test" },  {loading: true, divId: ID_SPINNER_PROCEED_TO_PAY})).then(() => {
//         //                                         rootComponent = rootComponent.update()
//         //                                         component = findComponent(rootComponent, 'BuyMiles')
//         //                                         let newState = store.getState();
//         //                                         expect(newState.commonErrorReducer.error.message).toBe(ACCEPTPAYMENT_RESPONSE_FAIL_MSG);
//         //                                     });
//         //                                 });
//         //                             })
//         //                     });
    
    
//         //                 })
//         //         });
    
//         //     });
    
//         //     it('Buy points: Payment Failure on Transaction logout', () => {
//         //         mockServiceResponse(CONFIG_RESPONSE)
//         //         return ReactTestUtils.act(() => {
//         //             return store.dispatch(fetchConfiguration(CONFIG_SECTION_BUYPOINT))
//         //                 .then(() => {
//         //                     let data = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "title": "Mr", "givenName": "Prithviraj", "familyName": "Sukumaran", "membershipType": "Individual", "membershipStatus": "Active", "membershipStatusCode": "A", "accountStatus": "Active", "accountStatusCode": "A", "suspended": false, "tierCode": "BLU", "tierName": "Blue", "tierFromDate": "01-Jul-2020", "tierToDate": "", "prospectTier": "", "companyName": "", "expiryDate": null, "lastActivityDate": "15-Jul-2020", "activityType": "Buy Points", "expiryDetails": [{ "pointType": "BONUS", "points": 500.0, "expiryDate": "31-Jul-2023" }, { "pointType": "BASE", "points": 10000.0, "expiryDate": "31-Jul-2023" }], "pointDetails": [{ "pointType": "BASE", "pointTypeGroup": "Total Miles", "totalAccuredpoints": 11000.0, "totalRedeemedpoints": 1000.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 10000.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "BONUS", "pointTypeGroup": "Total Miles", "totalAccuredpoints": 500.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 500.0, "bonusDetails": [{ "bonusCode": "ENB", "bonusName": "Enrolment Partner Bonus", "points": 500.0 }], "creditLimit": 0.0 }, { "pointType": "TIER", "pointTypeGroup": "Qualifying Miles", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "TIERKE", "pointTypeGroup": "Qualifying Miles", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "FS", "pointTypeGroup": "Qualifying Segments", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "FC", "pointTypeGroup": "Qualifying Segments", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }] } }
//         //                     mockServiceResponse(data)
//         //                     return ReactTestUtils.act(() => {
//         //                         return store.dispatch(fetchAccountSummary({ "test": "test" }))
//         //                             .then(() => {
//         //                                 mockServiceResponse(TRANSACTION_LOGOUT_RESPONSE_FAIL, 500)
//         //                                 return ReactTestUtils.act(() => {
//         //                                     return store.dispatch(transactionLogout({ "test": "test" })).then(() => {
//         //                                         rootComponent = rootComponent.update()
//         //                                         component = findComponent(rootComponent, 'BuyMiles')
//         //                                         let newState = store.getState();
//         //                                         expect(newState.commonErrorReducer.error.message).toBe(TRANSACTION_LOGOUT_RESPONSE_FAIL_MSG);
//         //                                     });
//         //                                 });
//         //                             })
//         //                     });
    
    
//         //                 })
//         //         });
    
//         //     });
//         // })
    
//     });
// });


const CONFIG_RESPONSE = {"object":{"companyCode":"IBS","isProtectedApi":true,"programCode":"PRG14","section":"buypoint","transactionTypes":[{"description":"Purchase Falconflyer miles","bookingChannel":{"mobile":"","web":"WEB"}, "isPacket": false,"pointDetails":[{"acceptPaymentRequired":true,"addedPointList":[],"isBonus":false,"isPaymentRequired":true,"maximumPacket":10,"minimumPacket":1,"packetSize":1000,"pointType":"LP","pointTypeName":"Loyalty Points","status":"enable","transactionType":"C","transactionFee":{"amount":0.01,"perUnit":true,"serviceCharge":0,"vat":0}}],"status":"enable","type":"general"},{"activityCode":"PT","activityType":"PT","bookingChannel":{"mobile":"","web":"WEB"},"description":"Tier Upgrade","isProtectedApi":false,"pointDetails":[{"accpetPaymentRequired":false,"isBonus":false,"isPaymentRequired":true,"pointType":"MILES","pointTypeName":"Falconflyer Miles","status":"enable","transactionType":"C"}],"purchaseTier":{"Blue":[{"tierCode":"SLV","tierName":"Silver","validations":[{"condition":"{MILES}>600","errorMessage":"buy.tierUpgrade.invalid_Loyalty_Points"},{"condition":"{CURRENT_MILES}>= {POINTS_TO_PURCHASE}","errorMessage":"buy.tierUpgrade.invalid_Current_Miles"}]}]},"ruleType":"ADHOCPRS","status":"enable","terms_and_conditions":"https://www.gulfair.com/membership/rules-terms?_gl=1%2A1sqwq73%2A_ga%2AMjc3NjUwODU3LjE2MTc3ODc3NTA.%2A_ga_0QVNSNCG0T%2AMTYyMTQwNTQ2OS4xNC4xLjE2MjE0MDYxNzQuMA","type":"tierUpgrade","upgradableTierCodes":[],"upgradeTierUsing":"miles"}],"ui":{"showRadioButtonView":false}},"statuscode":"200","statusMessage":"SUCCESS"}
const CONFIG_RESPONSE_RADIOBUTTON = {"statuscode":"200","statusMessage":"SUCCESS","object":{"section":"buypoint","companyCode":"IBS","programCode":"PRG14","isProtectedApi":true,"transactionTypes":[{"type":"general","status":"enable","description":"Transfer to any loyalty member","pointDetails":[{"pointType":"LP","status":"enable","pointTypeName":"Loyalty Points","isBonus":false,"isPaymentRequired":false,"packetSize":1000,"minimumPacket":1,"maximumPacket":10,"transactionType":"C","transactionFee":{"amount":0.01,"perUnit":true,"vat":0,"serviceCharge":0},"addedPointList":[]}]}],"ui":{"showRadioButtonView":true}}}
const AUTH_RESPONSE = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "status": true, "membershipNumber": "IM0008010794", "transactionID": "3AE4F1611A08CA4679DAE17E6F21BD50" } }
const CONFIG_RESPONSE_UNPROTECTED_API = {"object":{"companyCode":"IBS","isProtectedApi":false,"programCode":"PRG14","section":"buypoint","transactionTypes":[{"description":"Purchase Falconflyer miles","bookingChannel":{"mobile":"","web":"WEB"}, "isPacket": false,"pointDetails":[{"acceptPaymentRequired":true,"addedPointList":[],"isBonus":false,"isPaymentRequired":false,"maximumPacket":10,"minimumPacket":1,"packetSize":1000,"pointType":"LP","pointTypeName":"Loyalty Points","status":"enable","transactionType":"C","transactionFee":{"amount":0.01,"perUnit":true,"serviceCharge":0,"vat":0}}],"status":"enable","type":"general"},{"activityCode":"PT","activityType":"PT","bookingChannel":{"mobile":"","web":"WEB"},"description":"Tier Upgrade","isProtectedApi":false,"pointDetails":[{"accpetPaymentRequired":false,"isBonus":false,"isPaymentRequired":true,"pointType":"MILES","pointTypeName":"Falconflyer Miles","status":"enable","transactionType":"C"}],"purchaseTier":{"Blue":[{"tierCode":"SLV","tierName":"Silver","validations":[{"condition":"{MILES}>600","errorMessage":"buy.tierUpgrade.invalid_Loyalty_Points"},{"condition":"{CURRENT_MILES}>= {POINTS_TO_PURCHASE}","errorMessage":"buy.tierUpgrade.invalid_Current_Miles"}]}]},"ruleType":"ADHOCPRS","status":"enable","terms_and_conditions":"https://www.gulfair.com/membership/rules-terms?_gl=1%2A1sqwq73%2A_ga%2AMjc3NjUwODU3LjE2MTc3ODc3NTA.%2A_ga_0QVNSNCG0T%2AMTYyMTQwNTQ2OS4xNC4xLjE2MjE0MDYxNzQuMA","type":"tierUpgrade","upgradableTierCodes":[],"upgradeTierUsing":"miles"}],"ui":{"showRadioButtonView":false}},"statuscode":"200","statusMessage":"SUCCESS"}
const CONFIG_RESPONSE_UNPROTECTED_API_WO_PAYMENT = {"statuscode":"200","statusMessage":"SUCCESS","object":{"section":"buypoint","companyCode":"IBS","programCode":"PRG14","isProtectedApi":false,"transactionTypes":[{"type":"general","status":"enable","description":"Transfer to any loyalty member","pointDetails":[{"pointType":"LP","status":"enable","pointTypeName":"Loyalty Points","isBonus":false,"isPaymentRequired":false,"acceptPaymentRequired":true,"packetSize":1000,"minimumPacket":1,"maximumPacket":10,"transactionType":"C","transactionFee":{"amount":0.01,"perUnit":true,"vat":0,"serviceCharge":0},"addedPointList":[]}]}]}}
const AUTH_RESPONSE_FAIL = {"statuscode":"500","statusMessage":"FAILURE","error":{"code":"500","type":"INTERNAL_SERVER_ERROR","message":"Authentication failed","errorDetails":[{"message":"Authentication failed"}]}}
const AUTH_RESPONSE_FAIL_MSG = "Authentication failed"
const BUYPOINT_RESPONSE_FAIL = {"statuscode": "500", "statusMessage": "SUCCESS", "error":{"message": "Buypoint failed"} }
const BUYPOINT_RESPONSE_FAIL_MSG = "Buypoint failed"
const ACCEPTPAYMENT_RESPONSE_FAIL = {"statuscode": "500", "statusMessage": "SUCCESS", "error":{"message": "Accept payment failed"} }
const ACCEPTPAYMENT_RESPONSE_FAIL_MSG = "Accept payment failed"
const TRANSACTION_LOGOUT_RESPONSE_FAIL = {"statuscode": "500", "statusMessage": "SUCCESS", "error":{"message": "Transaction logout failed"} }
const TRANSACTION_LOGOUT_RESPONSE_FAIL_MSG = "Transaction logout failed"
const ACCOUNT_SUMMARY_SUCCESS = {"statuscode":"200","statusMessage":"SUCCESS","object":{"title":"Mr","givenName":"David","familyName":"Beckham","membershipType":"Individual","membershipStatus":"Active","membershipStatusCode":"A","accountStatus":"Active","accountStatusCode":"A","suspended":false,"tierCode":"STD","tierName":"Blue","tierFromDate":"29-Apr-2021","tierToDate":"","prospectTier":"","companyName":"","expiryDate":null,"lastActivityDate":"10-May-2021","activityType":"Buy Points","expiryDetails":[{"pointType":"LP","points":13000,"expiryDate":"09-May-2024"},{"pointType":"BASE","points":20000,"expiryDate":"06-May-2025"}],"pointDetails":[{"pointType":"BASE","pointTypeGroup":"Airpoints Dollars","totalAccuredpoints":20000,"totalRedeemedpoints":0,"pointsToNextTier":0,"pointsForTierRetention":0,"points":20000,"bonusDetails":[],"creditLimit":0},{"pointType":"MILES","pointTypeGroup":"Falcon Flyer Miles","totalAccuredpoints":174500,"totalRedeemedpoints":143246,"pointsToNextTier":0,"pointsForTierRetention":0,"points":31254,"bonusDetails":[],"creditLimit":0},{"pointType":"BONUSAPD","pointTypeGroup":"Airpoints Dollars","totalAccuredpoints":0,"totalRedeemedpoints":0,"pointsToNextTier":0,"pointsForTierRetention":0,"points":0,"bonusDetails":[],"creditLimit":0},{"pointType":"LP","pointTypeGroup":"Loyalty Points","totalAccuredpoints":18000,"totalRedeemedpoints":5000,"pointsToNextTier":0,"pointsForTierRetention":0,"points":13000,"bonusDetails":[],"creditLimit":0},{"pointType":"BONUS","pointTypeGroup":"Loyalty Points","totalAccuredpoints":0,"totalRedeemedpoints":0,"pointsToNextTier":0,"pointsForTierRetention":0,"points":0,"bonusDetails":[],"creditLimit":0},{"pointType":"DPTPNT","pointTypeGroup":"Loyalty Points","totalAccuredpoints":0,"totalRedeemedpoints":0,"pointsToNextTier":0,"pointsForTierRetention":0,"points":0,"bonusDetails":[],"creditLimit":0},{"pointType":"SECLSTYER","pointTypeGroup":"Loyalty Points","totalAccuredpoints":0,"totalRedeemedpoints":0,"pointsToNextTier":0,"pointsForTierRetention":0,"points":0,"bonusDetails":[],"creditLimit":0},{"pointType":"THRLSTYER","pointTypeGroup":"Loyalty Points","totalAccuredpoints":0,"totalRedeemedpoints":0,"pointsToNextTier":0,"pointsForTierRetention":0,"points":0,"bonusDetails":[],"creditLimit":0},{"pointType":"TIER","pointTypeGroup":"Status Points","totalAccuredpoints":0,"totalRedeemedpoints":0,"pointsToNextTier":0,"pointsForTierRetention":0,"points":0,"bonusDetails":[],"creditLimit":0},{"pointType":"TIERCC","pointTypeGroup":"Status Points","totalAccuredpoints":0,"totalRedeemedpoints":0,"pointsToNextTier":0,"pointsForTierRetention":0,"points":0,"bonusDetails":[],"creditLimit":0},{"pointType":"FS","pointTypeGroup":"Total Flights","totalAccuredpoints":0,"totalRedeemedpoints":0,"pointsToNextTier":0,"pointsForTierRetention":0,"points":0,"bonusDetails":[],"creditLimit":0},{"pointType":"FC","pointTypeGroup":"Total Flights","totalAccuredpoints":0,"totalRedeemedpoints":0,"pointsToNextTier":0,"pointsForTierRetention":0,"points":0,"bonusDetails":[],"creditLimit":0},{"pointType":"REVENUE","pointTypeGroup":"Revenue (NZD)","totalAccuredpoints":0,"totalRedeemedpoints":0,"pointsToNextTier":0,"pointsForTierRetention":0,"points":0,"bonusDetails":[],"creditLimit":0},{"pointType":"BC","pointTypeGroup":"Benefits","totalAccuredpoints":0,"totalRedeemedpoints":0,"pointsToNextTier":0,"pointsForTierRetention":0,"points":0,"bonusDetails":[],"creditLimit":0},{"pointType":"KC","pointTypeGroup":"Benefits","totalAccuredpoints":0,"totalRedeemedpoints":0,"pointsToNextTier":0,"pointsForTierRetention":0,"points":0,"bonusDetails":[],"creditLimit":0},{"pointType":"WIFI","pointTypeGroup":"Benefits","totalAccuredpoints":0,"totalRedeemedpoints":0,"pointsToNextTier":0,"pointsForTierRetention":0,"points":0,"bonusDetails":[],"creditLimit":0},{"pointType":"CV","pointTypeGroup":"Benefits","totalAccuredpoints":0,"totalRedeemedpoints":0,"pointsToNextTier":0,"pointsForTierRetention":0,"points":0,"bonusDetails":[],"creditLimit":0},{"pointType":"DF","pointTypeGroup":"Benefits","totalAccuredpoints":0,"totalRedeemedpoints":0,"pointsToNextTier":0,"pointsForTierRetention":0,"points":0,"bonusDetails":[],"creditLimit":0},{"pointType":"MV","pointTypeGroup":"Benefits","totalAccuredpoints":0,"totalRedeemedpoints":0,"pointsToNextTier":0,"pointsForTierRetention":0,"points":0,"bonusDetails":[],"creditLimit":0}],"tierOptions":[{"tierName":"Silver","tierCode":"SIL","type":"upgrade","options":[{"operator":"and","optionDetails":[{"current":"0","next":"450","diff":"450","types":["TIER","TIERCC"],"name":"Total Status Points","uiType":"point","result":false,"preferred":true},{"current":"0","next":"225","diff":"225","types":["TIER"],"name":"Status Points","uiType":"point","result":false,"preferred":true}],"result":false}],"message":"You are 450 Total Status Points and 225 Status Points away from the next tier"}]}}
const ACCOUNT_SUMMARY_SUCCESS_1 = {"statuscode":"200","statusMessage":"SUCCESS","object":{"title":"Mr","givenName":"Tom","familyName":"Jerry","membershipType":"Individual","membershipStatus":"Active","membershipStatusCode":"A","accountStatus":"Active","accountStatusCode":"A","suspended":false,"tierCode":"220","tierName":"SILVER","subTierName":null,"baseTierName":"Blue","tierFromDate":"08-Jun-2021","tierToDate":"","prospectTier":"","companyName":"","expiryDate":null,"lastActivityDate":"09-Jul-2021","activityType":null,"expiryDetails":[{"pointType":"MILES","points":5500.0,"expiryDate":"30-Jan-2023"}],"pointDetails":[{"pointType":"MILES","pointTypeGroup":"Falcon Flyer Miles","totalAccuredpoints":5500.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":5500.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"BNSMILES","pointTypeGroup":"Falcon Flyer Miles","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"BNFTIRNOM","pointTypeGroup":"Falcon Flyer Miles","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"LTYPNT","pointTypeGroup":"Loyalty Points","totalAccuredpoints":700.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":700.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"CBUPGVCH","pointTypeGroup":"Upgrade Vouchers","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"PRGLNGVCH","pointTypeGroup":"Lounge Vouchers","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"TORDM","pointTypeGroup":"RuleOutput","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"PNTAMT","pointTypeGroup":"RuleOutput","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"PNTTOPUR","pointTypeGroup":"RuleOutput","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"TIRPURPNT","pointTypeGroup":"RuleOutput","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0}],"tierOptions":[{"tierName":"Silver","tierCode":"220","type":"upgrade","options":[{"operator":"and","optionDetails":[{"current":"700","next":"900","diff":"200","types":["LTYPNT"],"name":"Loyalty Points","uiType":"point","result":false,"preferred":true}],"result":false}],"message":"You are 200 Loyalty Points away from the next tier"}]}}
const ACCOUNT_SUMMARY_SUCCESS_WITH_LOYALTY_POINT = {"statuscode":"200","statusMessage":"SUCCESS","object":{"title":"Mr","givenName":"Tom","familyName":"Jerry","membershipType":"Individual","membershipStatus":"Active","membershipStatusCode":"A","accountStatus":"Active","accountStatusCode":"A","suspended":false,"tierCode":"110","tierName":"Blue","subTierName":null,"baseTierName":"Blue","tierFromDate":"08-Jun-2021","tierToDate":"","prospectTier":"","companyName":"","expiryDate":null,"lastActivityDate":"09-Jul-2021","activityType":null,"expiryDetails":[{"pointType":"MILES","points":5500.0,"expiryDate":"30-Jan-2023"}],"pointDetails":[{"pointType":"MILES","pointTypeGroup":"Falcon Flyer Miles","totalAccuredpoints":5500.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":5500.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"BNSMILES","pointTypeGroup":"Falcon Flyer Miles","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"BNFTIRNOM","pointTypeGroup":"Falcon Flyer Miles","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"LTYPNT","pointTypeGroup":"Loyalty Points","totalAccuredpoints":700.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":700.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"CBUPGVCH","pointTypeGroup":"Upgrade Vouchers","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"PRGLNGVCH","pointTypeGroup":"Lounge Vouchers","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"TORDM","pointTypeGroup":"RuleOutput","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"PNTAMT","pointTypeGroup":"RuleOutput","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"PNTTOPUR","pointTypeGroup":"RuleOutput","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"TIRPURPNT","pointTypeGroup":"RuleOutput","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0}],"tierOptions":[{"tierName":"Silver","tierCode":"220","type":"upgrade","options":[{"operator":"and","optionDetails":[{"current":"700","next":"900","diff":"200","types":["LTYPNT"],"name":"Loyalty Points","uiType":"point","result":false,"preferred":true}],"result":false}],"message":"You are 200 Loyalty Points away from the next tier"}]}}
const DEFAULT_CONFIG_RESPONSE= {"statuscode":"200","statusMessage":"SUCCESS","object":{"section":"default","companyCode":"GF","requestTimedOutInMs":20000,"subscribeKeyId":3,"data":{"membershipTypes":[{"key":"I","value":"Individual"},{"key":"C","value":"Corporate"}],"nomineePermissionFullAccess":[{"key":"fullAccessPrivilege","value":"Full Access"}],"nomineePermissionLimitedAccess":[{"key":"limitedAccessPrivilege","value":"Limited Access"}],"accountStatusCodes":[{"key":"U","value":"Unregistered"},{"key":"A","value":"Active"},{"key":"I","value":"Inactive"},{"key":"S","value":"Suspended"},{"key":"D","value":"Deleted"},{"key":"C","value":"Closed"},{"key":"E","value":"Expired"},{"key":"M","value":"Merged"},{"key":"P","value":"Provisional"},{"key":"R","value":"Payment Due"},{"key":"V","value":"Inactive-Unregistered"},{"key":"H","value":"On Hold"},{"key":"N","value":"Pending Activation"},{"key":"B","value":"Blocked"}],"addressTypes":[{"key":"H","value":"Home"},{"key":"B","value":"Business"}],"emailTypes":[{"key":"H","value":"Home"},{"key":"B","value":"Business"}],"phoneTypes":[{"key":"HP","value":"Home"},{"key":"BP","value":"Business"},{"key":"HM","value":"Mobile"}],"gender":[{"key":"U","value":"Unknown"},{"key":"M","value":"Male"},{"key":"F","value":"Female"}],"maritalStatus":[{"key":"D","value":"Divorced"},{"key":"M","value":"Married"},{"key":"S","value":"Single"},{"key":"W","value":"Widow"}],"industryType":[{"key":"A","value":"Airline Industry"},{"key":"B","value":"Business Administration"},{"key":"C","value":"Cooperate Communication"},{"key":"D","value":"Service Delivery"},{"key":"E","value":"Self Employment"},{"key":"F","value":"Forces"},{"key":"H","value":"Hospitality Industry"},{"key":"I","value":"Information technology"},{"key":"L","value":"Film Industry"},{"key":"M","value":"Medical professional"},{"key":"N","value":"Banking"},{"key":"P","value":"Apparel Industry"},{"key":"R","value":"Marketing"},{"key":"S","value":"Advisory Services"},{"key":"T","value":"Travel And Tourism"},{"key":"U","value":"Education, Academic Services"},{"key":"X","value":"Not Specified"}],"incomeBand":[{"key":"1","value":"Less than 1000 USD"},{"key":"2","value":"1000-2000 USD"},{"key":"3","value":"2001-5000 USD"},{"key":"4","value":"5001-10,000 USD"},{"key":"5","value":"Greater than 10,000 USD"}],"operationFlags":[{"key":"I","value":"Insert"},{"key":"U","value":"Update"},{"key":"D","value":"Delete"}],"membershipStatusCodes":[{"key":"A","value":"Active"},{"key":"B","value":"BlackListed"},{"key":"C","value":"Closed"},{"key":"D","value":"Deceased"},{"key":"S","value":"Suspended"},{"key":"I","value":"Inactive"},{"key":"P","value":"Protected"}],"noOfEmployees":[{"key":"1","value":"Less than 100","upperLimit":"99","lowerLimit":"1"},{"key":"2","value":"100 - 500","upperLimit":"499","lowerLimit":"101"},{"key":"3","value":"500 - 1000","upperLimit":"999","lowerLimit":"501"},{"key":"4","value":"Greater Than 1000","upperLimit":"2000","lowerLimit":"1000"},{"key":"X","value":"Not Specified","upperLimit":"0","lowerLimit":"0"}],"masterEntityData":[{"key":"airport","value":"ARPMST"},{"key":"country","value":"CNTMST"},{"key":"airlines","value":"ARLMST"},{"key":"airline_booking_class","value":"ARLBKGCLSMST"},{"key":"title","value":"TLEMST"},{"key":"mileage","value":"MILMST"},{"key":"language","value":"LNGMST"},{"key":"state","value":"STTMST"},{"key":"city","value":"CTYMST"},{"key":"charity","value":"ONETIM","filterFieldDetail":[{"attributeCode":"fieldCode","attributeValue":"gulfair.charity.members"}]},{"key":"partners","value":"ONETIM","filterFieldDetail":[{"attributeCode":"fieldCode","attributeValue":"gulfair.preaffiliated.partners"}]},{"key":"title_GF","value":"ONETIM","filterFieldDetail":[{"attributeCode":"fieldCode","attributeValue":"gulfair.member.title"}]},{"key":"tierName","value":"ONETIM","filterFieldDetail":[{"attributeCode":"fieldCode","attributeValue":"gulfair.tier.name"}]},{"key":"resetPoint","value":"ONETIM","filterFieldDetail":[{"attributeCode":"fieldCode","attributeValue":"gulfair.resetpoint.period"}]}],"tokenTypes":[{"key":"Enrol","value":"E"}]},"defaults":{"passwordPattern":"((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&.,{}()?-_=+<>*!^/]).{8,20})","emailPattern":"\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$"},"config":{"login":{"memberProgramExclusionList":"PROFILE_DETAILS,PREFERENCES,DYNAMIC_ATTRIBUTES,POINT_DETAILS","dynamicAttributes":{"permissionDetails":{"attributeGroupName":"Nominee Permission","attributeCode":"","attributeName":""},"programLinkedTo":{"attributeGroupName":"Program Linked Details","attributeCode":"91","attributeName":"Programs linked to"},"programEntitledTo":{"attributeGroupName":"Program Details","attributeCode":"73","attributeName":"Program entitled to"}}},"resetPwd":{"programEntitledToCode":"73","split":"|","corporateProgramCodeIndex":1,"corporateMembershipNumberIndex":2,"previousNomineeStatus":"P","updateNomineeStatus":"A"}},"programs":[{"programCode":"FF","programName":"Falconflyer","programType":"individual","isDefault":true,"isActive":true,"privileges":[{"name":"Default","value":"ALL","api":[{"url":"/**/*","method":"*"}],"ui":[{"page":"/**/*","tab":"*","permission":["*"]}]}],"defaults":{"currency":"USD","posCity":"JFK","posCountry":"US","pinRegex":"^\\d{4}$","passwordRegex":"^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$","dateFormat":"yyyy-MM-dd","dateTimeFormat":"yyyy-MM-dd HH:mm","image":{"maleAvatar":"","femaleAvatar":"","otherAvatar":""},"roundCurrencyToDecimalPrecision":2,"skipPinChangeReminder":true},"apiConfigLoader":{"master":true,"preference":true,"buypoint":true,"transferpoint":true,"mileagecalculator":true,"claimmiles":true,"customquery":true,"activitydetails":true,"enrol":true,"family":true,"profile":true,"servicerequest":true,"security":true,"nominee":false,"traveller":false,"accountsummary":true,"activation":true,"simulaterule":true,"renewpoint":true,"retrievequote":true},"data":{"pointTypes":[{"pointType":"MILES","pointName":"Falconflyer Miles","className":"fa fa-usd","redeemed":true},{"pointType":"BNSMILES","pointName":"Bonus","className":"fa fa-star","redeemed":true},{"pointType":"LTYPNT","pointName":"Loyalty Points","className":"fa fa-bars"},{"pointType":"PRGLNGVCH","pointName":"Tier Lounge Vouchers","className":"fa fa-ticket","redeemed":true},{"pointType":"CBUPGVCH","pointName":"Cobrand Upgrade Vouchers","className":"fa fa-trophy","redeemed":true}],"partners":[{"value":"GF","name":"Gulf Air"},{"value":"EY","name":"Etihad Airways"}],"cabinClasses":{"GF":[{"cabinClassCode":"E","cabinClassName":"Economy"},{"cabinClassCode":"B","cabinClassName":"Falcon Gold"}]},"cabinClassBookingClassMapping":{"GF":[{"cabinClass":"E","bookingClass":"Y"},{"cabinClass":"B","bookingClass":"J"}]},"relationshipCodes":[{"key":"O","value":"Others"}],"nomineeAccountGroupTypes":[{"key":"P","value":"Pool"}],"cmsDetails":{"header":{"filter":{"query":"ibs_prg14_header"},"metaData":{"type":"json"}},"footer":{"filter":{"query":"ibs_prg14_footer"},"metaData":{"type":"json"}},"partners":{"filter":{"partner_status":"Active"},"resource":{"tier":"ibs_prg14_retailers"}},"offers":{"filter":{"offer_status":"Active"},"resource":{"tier":"ibs_prg14_offers"}},"viewDetailPartner":{"filter":{"id":""},"metaData":{"type":"html"}},"viewDetailOffer":{"filter":{"id":""},"metaData":{"type":"html"}}}}},{"programCode":"CP","programName":"Corporate Loyalty","programType":"corporate","isDefault":false,"isActive":false,"privileges":[{"name":"Manage Profile","attrCode":"85","value":"R","api":[{"url":"/v*/member/profile/retrieve","method":"POST"},{"url":"/v*/member/qr-code/retrieve","method":"POST"}],"ui":[{"url":"/corporate/profile","tab":[{"name":"update-customer-profile","permission":["R","F"]},{"name":"update-company-profile","permission":["R"]}],"permission":["R"]}]},{"name":"Manage Profile","attrCode":"85","value":"F","api":[{"url":"/v*/member/profile/retrieve","method":"POST"},{"url":"/v*/member/profile/update","method":"POST"},{"url":"/v*/member/qr-code/retrieve","method":"POST"}],"ui":[{"url":"/corporate/profile","tab":[{"name":"update-customer-profile","permission":["R","F"]},{"name":"update-company-profile","permission":["R","F"]}],"permission":["F","R"]}]},{"name":"View Summary","attrCode":"86","value":"F","api":[{"url":"/v*/member/account-summary","method":"POST"},{"url":"/v*/summary-service/notification","method":"POST"}],"ui":[]},{"name":"Manage Account User","attrCode":"87","value":"R","api":[{"url":"/v*/member/nominee/retrieve","method":"POST"},{"url":"/v*/member/nominee/retrieve-user","method":"POST"},{"url":"/v*/member/nominee/update/self","method":"POST"}],"ui":[{"url":"/corporate/manageusers","tab":[{"name":"traveller","permission":["R"]},{"name":"nominee","permission":["R"]}],"permission":["R"]}]},{"name":"Manage Account User","attrCode":"87","value":"F","api":[{"url":"/v*/member/nominee/retrieve","method":"POST"},{"url":"/v*/member/nominee/add-reset-pwd","method":"POST"},{"url":"/v*/member/nominee/privilege","method":"POST"},{"url":"/v*/member/nominee/update","method":"POST"},{"url":"/v*/member/nominee/retrieve-user","method":"POST"},{"url":"/v*/member/nominee/delete","method":"POST"},{"url":"/v*/member/nominee/update/self","method":"POST"}],"ui":[{"url":"/corporate/manageusers","tab":[{"name":"traveller","permission":["R","F"]},{"name":"nominee","permission":["R","F"]}],"permission":["R","F"]}]},{"name":"Manage Traveler","attrCode":"88","value":"R","api":[{"url":"/v*/member/traveller/retrieve","method":"POST"}],"ui":[]},{"name":"Manage Traveler","attrCode":"88","value":"F","api":[{"url":"/v*/member/traveller/retrieve","method":"POST"},{"url":"/v*/member/traveller/add","method":"POST"},{"url":"/v*/member/traveller/update","method":"POST"},{"url":"/v*/member/traveller/delete","method":"POST"}],"ui":[]},{"name":"Manage Claims","attrCode":"89","value":"R","api":[{"url":"/v*/point/retro-claim/retrieve","method":"POST"}],"ui":[{"url":"/corporate/claimsummary","tab":[],"permission":["R"]},{"url":"/corporate/claimsubmit","tab":[],"permission":["X"]}]},{"name":"Manage Claims","attrCode":"89","value":"F","api":[{"url":"/v*/point/retro-claim/retrieve","method":"POST"},{"url":"/v*/point/retro-claim","method":"POST"}],"ui":[{"url":"/corporate/claimsummary","tab":[],"permission":["R","F"]},{"url":"/corporate/claimsubmit","tab":[],"permission":["R","F"]}]},{"name":"View Activities","attrCode":"90","value":"F","api":[{"url":"/v*/activity-detail/retrieve","method":"POST"}],"ui":[{"url":"/corporate/myactivity","tab":[],"permission":["F"]}]},{"name":"View Activities","attrCode":"90","value":"R","api":[{"url":"/v*/activity-detail/retrieve","method":"POST"}],"ui":[{"url":"/corporate/myactivity","tab":[],"permission":["X"]}]},{"name":"Default","value":"ALL","api":[{"url":"/v*/member/nominee/account-link","method":"POST"}]}],"defaults":{"currency":"USD","posCity":"JFK","posCountry":"US","pinRegex":"^\\d{4}$","passwordRegex":"^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$","dateFormat":"yyyy-MM-dd","dateTimeFormat":"yyyy-MM-dd HH:mm","roundCurrencyToDecimalPrecision":2,"skipPinChangeReminder":true},"apiConfigLoader":{"master":true,"preference":true,"buypoint":false,"transferpoint":false,"mileagecalculator":false,"claimmiles":false,"customquery":false,"activitydetails":true,"enrol":true,"family":false,"profile":true,"servicerequest":false,"security":true,"nominee":true,"traveller":true,"accountsummary":true,"activation":false,"simulaterule":false,"renewpoint":false,"retrievequote":false},"data":{"pointTypes":[],"partners":[{"value":"GF","name":"Gulf Air"},{"value":"EY","name":"Etihad Airways"}],"cabinClasses":{"GF":[{"cabinClassCode":"E","cabinClassName":"Economy"},{"cabinClassCode":"B","cabinClassName":"Falcon Gold"}]},"cabinClassBookingClassMapping":{"GF":[{"cabinClass":"E","bookingClass":"Y"},{"cabinClass":"B","bookingClass":"J"}]},"relationshipCodes":[{"key":"A","value":"Administrator"},{"key":"O","value":"Others"},{"key":"M","value":"Manager"},{"key":"B","value":"Accountant"},{"key":"C","value":"Customer Support"},{"key":"D","value":"Marketing Manager"}],"nomineeAccountGroupTypes":[{"key":"U","value":"Account User"},{"key":"H","value":"Account Holder"},{"key":"T","value":"Traveller"}],"cmsDetails":{"header":{"filter":{"query":"ibs_prg15_header"},"metaData":{"type":"json"}},"footer":{"filter":{"query":"ibs_prg15_footer"},"metaData":{"type":"json"}},"partners":{"filter":{"partner_status":"Active"},"resource":{"tier":"ibs_prg15_retailers"}},"offers":{"filter":{"offer_status":"Active"},"resource":{"tier":"ibs_prg15_offers"}},"viewDetailPartner":{"filter":{"id":""},"metaData":{"type":"html"}},"viewDetailOffer":{"filter":{"id":""},"metaData":{"type":"html"}}}}}]}}
const PURCHASE_TIER_RESPONSE= {"statuscode":"200","statusMessage":"SUCCESS","object":{"companyCode":"GF","programCode":"FF","membershipNumber":"0007111727","activityCode":"PT","redirectURL":"http://192.168.45.252:8092/paymentlite-ui/ps/payment?sessionKey=078D1DBE9BBA46519AB9B2453510D89A"}}
const SIMULATE_RULE_CONFIG = {"statuscode":"200","statusMessage":"SUCCESS","object":{"section":"simulaterule","companyCode":"GF","programCode":"FF","ruleTypes":[{"key":"Purchase_tier","ruleType":"ADHOCPRS","activityCode":"PT","filter":{"enable":true,"values":["TIRPURPNT"]},"executionItems":[{"variables":[{"code":"ACN$ACTTYP","name":"Action","value":"S","dataType":"STRING","isOutputVariable":false},{"code":"LTYPNT","name":"Loyalty Point","value":"${accountSummary.user.balance}","dataType":"PNTS","isOutputVariable":false},{"code":"TIR","name":"Tier","value":"${accountSummary.tierCode}","dataType":"STRING","isOutputVariable":false}]}]},{"key":"Profile_completeness","ruleType":"PRFCMPLTE","filter":{"enable":true,"values":["PRFCMPPER"]},"executionItems":[{"variables":[{"code":"FAMNAM","name":"Family Name","value":"object.memberAccount.memberProfile.individualInfo.familyName","uiPath":"object.memberAccount.memberProfile.individualInfo.familyName","dataType":"ALPHANUMERIC","isOutputVariable":false},{"code":"GVNNAM","name":"Given Name","value":"object.memberAccount.memberProfile.individualInfo.givenName","uiPath":"object.memberAccount.memberProfile.individualInfo.givenName","dataType":"ALPHANUMERIC","isOutputVariable":false},{"code":"TITLE","name":"Title","value":"object.memberAccount.memberProfile.individualInfo.title","uiPath":"object.memberAccount.memberProfile.individualInfo.title","dataType":"ALPHANUMERIC","isOutputVariable":false},{"code":"NTNLTY","name":"Nationality","value":"object.memberAccount.memberProfile.individualInfo.memberNationality","uiPath":"object.memberAccount.memberProfile.individualInfo.memberNationality","dataType":"ALPHANUMERIC","isOutputVariable":false},{"code":"CNTRES","name":"Country of Residence","value":"object.memberAccount.memberProfile.individualInfo.countryOfResidence","uiPath":"object.memberAccount.memberProfile.individualInfo.countryOfResidence","dataType":"ALPHANUMERIC","isOutputVariable":false},{"code":"PRFLNG","name":"Preferred Language","value":"object.memberAccount.memberProfile.individualInfo.preferredLanguage","uiPath":"object.memberAccount.memberProfile.individualInfo.preferredLanguage","dataType":"ALPHANUMERIC","isOutputVariable":false},{"code":"DOB","name":"Date of Birth","value":"object.memberAccount.memberProfile.individualInfo.dateOfBirth","uiPath":"object.memberAccount.memberProfile.individualInfo.dateOfBirth","dataType":"ALPHANUMERIC","isOutputVariable":false},{"code":"GNDR","name":"Gender","value":"object.memberAccount.memberProfile.individualInfo.gender","uiPath":"object.memberAccount.memberProfile.individualInfo.gender","dataType":"ALPHANUMERIC","isOutputVariable":false},{"code":"HEMAIL","name":"Home E-mail","value":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[?addressType == 'H'].emailAddress | [0]","uiPath":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[?(@.addressType == 'H')].emailAddress","dataType":"ALPHANUMERIC","isOutputVariable":false},{"code":"HMOBNO","name":"Home Mobile","value":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[?addressType == 'H'].mobileNumber | [0]","uiPath":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[?(@.addressType == 'H')].mobileNumber","dataType":"ALPHANUMERIC","isOutputVariable":false},{"code":"HADDRLN1","name":"Home Address Line One","value":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[?addressType == 'H'].addressLine1 | [0]","uiPath":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[?(@.addressType == 'H')].addressLine1","dataType":"ALPHANUMERIC","isOutputVariable":false},{"code":"HCOUNTRY","name":"Home Country","value":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[?addressType == 'H'].country | [0]","uiPath":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[?(@.addressType == 'H')].country","dataType":"ALPHANUMERIC","isOutputVariable":false},{"code":"HZIPCOD","name":"Home Postal Code","value":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[?addressType == 'H'].zipCode | [0]","uiPath":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[?(@.addressType == 'H')].zipCode","dataType":"ALPHANUMERIC","isOutputVariable":false},{"code":"HPHNNO","name":"Home Phone Number","value":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[?addressType == 'H'].phoneNumber | [0]","uiPath":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[?(@.addressType == 'H')].phoneNumber","dataType":"ALPHANUMERIC","isOutputVariable":false},{"code":"CMPNAM","name":"Company Name","value":"object.memberAccount.memberProfile.individualInfo.companyName","uiPath":"object.memberAccount.memberProfile.individualInfo.companyName","dataType":"ALPHANUMERIC","isOutputVariable":false},{"code":"BADDRLN1","name":"Business Address Line One","value":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[?addressType == 'B'].addressLine1 | [0]","uiPath":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[?(@.addressType == 'B')].addressLine1","dataType":"ALPHANUMERIC","isOutputVariable":false},{"code":"PRFADD","name":"Preferred Address","value":"object.memberAccount.memberProfile.individualInfo.preferredAddress","uiPath":"object.memberAccount.memberProfile.individualInfo.preferredAddress","dataType":"ALPHANUMERIC","isOutputVariable":false}]}]}]}}
const SIMULATE_RULE_SUCCESS = {"statuscode":"200","statusMessage":"SUCCESS","object":{"companyCode":"GF","programCode":"FF","ruleType":"ADHOCPRS","executionItems":[{"reasonCodes":[],"ruleOutputStatus":"success","variables":[{"code":"TIRPURPNT","dataType":"DECIMAL","isOutputVariable":true,"name":"Points to Purchase Tier","value":"45000.0"}]}]}}
const SUMMARY_CONFIG = {"statuscode":"200","statusMessage":"SUCCESS","object":{"section":"summary","companyCode":"GF","programCode":"FF","ui":{"defaultAbsoluteIndex":1,"defaultPageSize":10,"isBonusRequiredForAccoutnSummary":"Y","defaultPointType":"pointType2","tierHeader":{"pointType":{"miles":[],"segments":[]}},"layout":{"order":["memberCard","usefulLinkGroup","familyCard"],"elements":{"breadcrumbMenuItems":{"type":"navigator","visibility":true,"id":"id-breadcrumb","menuItems":[{"id":"dashboard_link","enable":true,"currentTab":true,"key":"dashboard","link":"/member/dashboard","visible":true,"additinalClass":""},{"id":"mileage_overview","enable":true,"currentTab":true,"key":"mileage_overview","link":"/member/overview","visible":true,"additinalClass":""},{"id":"transactions","enable":true,"key":"transactions","link":"","visible":true,"currentTab":true,"additinalClass":"","child":[{"id":"calculator","enable":true,"currentTab":true,"key":"calculator","link":"/mileagecalculator","visible":true,"additinalClass":""},{"id":"my_activity","enable":true,"currentTab":true,"key":"my_activity","link":"/member/myactivity","visible":true,"additinalClass":""},{"id":"buy","enable":true,"currentTab":true,"key":"buy","link":"/buy","visible":true,"additinalClass":""},{"id":"transfer","enable":true,"currentTab":true,"key":"transfer","link":"/transfer","visible":true,"additinalClass":""},{"id":"migratepoints","enable":true,"currentTab":true,"key":"migratepoints","link":"/member/migratepoints","visible":false,"additinalClass":""},{"id":"extend_miles","enable":true,"currentTab":true,"key":"extend_miles","link":"/member/extendexpiry","visible":true,"additinalClass":""}]},{"id":"my_family","enable":true,"currentTab":true,"key":"my_family","link":"","visible":true,"additinalClass":"","child":[{"id":"family_pooling","enable":true,"currentTab":true,"key":"family_pooling","link":"/familypooling","visible":true,"additinalClass":""},{"id":"add_family","enable":true,"currentTab":true,"key":"add_family","link":"/addfamilymember","visible":true,"additinalClass":""}]},{"id":"claim","enable":true,"currentTab":true,"key":"claim","link":"","visible":true,"additinalClass":"","child":[{"id":"claim_list","enable":true,"currentTab":true,"key":"claim_list","link":"/member/claimsummary","visible":true,"additinalClass":""},{"id":"submit_claim","enable":true,"currentTab":true,"key":"submit_claim","link":"/member/claimsubmit","visible":true,"additinalClass":""}]},{"id":"myflight","enable":true,"currentTab":true,"key":"myflight","link":"/member/myflights","visible":true,"additinalClass":""},{"id":"booking","enable":false,"currentTab":true,"key":"booking","link":"/member/booking","visible":false,"additinalClass":""},{"id":"my_profile","enable":true,"currentTab":true,"key":"my_profile","link":"","visible":true,"additinalClass":"","child":[{"id":"my_profile","enable":true,"currentTab":true,"key":"my_profile","link":"/member/profile","visible":true,"additinalClass":""},{"id":"companion_list","enable":true,"currentTab":true,"key":"companion_list","link":"/member/travelcompanion","visible":true,"additinalClass":""},{"id":"add_companion","enable":true,"currentTab":true,"key":"add_companion","link":"/member/travelcompanion","visible":true,"additinalClass":""}]},{"id":"referral","enable":true,"currentTab":true,"key":"referral","link":"/referral","visible":true,"additinalClass":""},{"id":"feedback","enable":true,"currentTab":true,"key":"feedback","link":"https://www.gulfair.com/contact-us","visible":true,"additinalClass":"","target":"_blank"}]},"loginMenuItems":{"type":"navigator","visibility":true,"id":"id-login","menuItems":[{"id":"","enable":true,"key":"corporate_login","currentTab":false,"link":"/corporate/login","visible":false,"additinalClass":""},{"id":"","enable":true,"key":"my_profile","link":"/member/profile","visible":true,"currentTab":true,"additinalClass":""}]},"memberCard":{"fields":[{"name":"totalMiles","id":"totalMiles","category":"points","visibility":true,"grouping":"summary","data":{"pointTypes":["MILES","BNSMILES"]}},{"name":"myFlights","id":"myFlights","visibility":true,"category":"points","grouping":"pointTypesDisplay","data":{"pointTypes":["LP"]}},{"name":"bonusPoints","id":"bonusPoints","visibility":true,"category":"points","grouping":"pointTypesDisplay","data":{"pointTypes":["BONUS"]}},{"name":"partnerPoints","id":"partnerPoints","visibility":true,"category":"points","grouping":"pointTypesDisplay","data":{"pointTypes":["FC","FS"]}},{"name":"notification","id":"notification","visibility":true,"category":"message","grouping":"notification","data":{"pointTypes":["TIER","TIERCC"],"threshold":-5000}},{"name":"includeMileageLink","id":"includeMileageLink","link":"#/member/overview","category":"navigation","grouping":"links","visibility":true}]},"familyCard":{"fields":[{"name":"includeFamilyDetailLink","id":"includeFamilyDetailLink","grouping":"links","visibility":true},{"name":"pooledMiles","id":"pooledMiles","visibility":true,"data":{"pointTypes":["MILES","BNSMILES"]}},{"name":"notification","id":"notification","visibility":true,"category":"message","grouping":"notification","data":{"pointTypes":["MILES","BNSMILES"],"threshold":-5000}}]},"usefulLinkGroup":{"fields":[{"id":"calculator","visibility":true,"className":"fa fa-calculator","link":"/mileagecalculator","enable":true},{"id":"claim","visibility":true,"className":"fa fa-money","link":"/member/claimsummary","enable":true},{"id":"buy","visibility":true,"className":"fa fa-plane","link":"/buy","enable":true},{"id":"transfer","visibility":true,"className":"fa fa-exchange","link":"/transfer","enable":true},{"id":"activity","visibility":true,"className":"fa fa-file-text-o","link":"/member/myactivity","enable":true},{"id":"my_flight","visibility":true,"className":"fa fa-plane","link":"/member/myflights","enable":true},{"id":"destination","visibility":false,"className":"fa fa-map-marker","link":"/member/booking","enable":true},{"id":"migratepoints","visibility":false,"className":"fa fa-plane","link":"/member/migratepoints","enable":true}]},"pointDropdown":{"fields":[{"name":"pointType1","id":"pointType1","category":"points","visibility":true,"iconClass":"","icon":"goldStar","data":{"pointTypes":["MILES","BNSMILES"]}},{"name":"pointType2","id":"pointType2","visibility":true,"category":"points","iconClass":"","icon":"goldStar","grouping":"pointTypesDisplay","data":{"pointTypes":["MILES"]}},{"name":"includeMileageLink","id":"includeMileageLink","link":"#/member/overview","category":"navigation","visibility":true}]},"quickLinks":{"fields":[{"id":"digitalcard","visibility":true,"svgCode":"<?xml version=\"1.0\" encoding=\"utf-8\"?> <svg version=\"1.1\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\"20px\" height=\"20px\" xmlns=\"http://www.w3.org/2000/svg\"> <g transform=\"matrix(1 0 0 1 -599 -143 )\"> <path d=\"M 3.63636363636364 14.5454545454545 L 5.45454545454545 14.5454545454545 L 5.45454545454545 16.3636363636364 L 3.63636363636364 16.3636363636364 L 3.63636363636364 14.5454545454545 Z M 3.63636363636364 3.63636363636364 L 5.45454545454545 3.63636363636364 L 5.45454545454545 5.45454545454545 L 3.63636363636364 5.45454545454545 L 3.63636363636364 3.63636363636364 Z M 14.5454545454545 3.63636363636364 L 16.3636363636364 3.63636363636364 L 16.3636363636364 5.45454545454545 L 14.5454545454545 5.45454545454545 L 14.5454545454545 3.63636363636364 Z M 1.81818181818182 12.7272727272727 L 1.81818181818182 18.1676136363636 L 7.27272727272727 18.1676136363636 L 7.27272727272727 12.7272727272727 L 1.81818181818182 12.7272727272727 Z M 1.81818181818182 1.81818181818182 L 1.81818181818182 7.27272727272727 L 7.27272727272727 7.27272727272727 L 7.27272727272727 1.81818181818182 L 1.81818181818182 1.81818181818182 Z M 12.7272727272727 1.81818181818182 L 12.7272727272727 7.27272727272727 L 18.1818181818182 7.27272727272727 L 18.1818181818182 1.81818181818182 L 12.7272727272727 1.81818181818182 Z M 0 10.9090909090909 L 9.09090909090909 10.9090909090909 L 9.09090909090909 20 L 0 20 L 0 10.9090909090909 Z M 14.5454545454545 18.1818181818182 L 16.3636363636364 18.1818181818182 L 16.3636363636364 20 L 14.5454545454545 20 L 14.5454545454545 18.1818181818182 Z M 18.1818181818182 18.1818181818182 L 20 18.1818181818182 L 20 20 L 18.1818181818182 20 L 18.1818181818182 18.1818181818182 Z M 18.1818181818182 10.9090909090909 L 20 10.9090909090909 L 20 16.3636363636364 L 14.5454545454545 16.3636363636364 L 14.5454545454545 14.5454545454545 L 12.7272727272727 14.5454545454545 L 12.7272727272727 20 L 10.9090909090909 20 L 10.9090909090909 10.9090909090909 L 16.3636363636364 10.9090909090909 L 16.3636363636364 12.7272727272727 L 18.1818181818182 12.7272727272727 L 18.1818181818182 10.9090909090909 Z M 0 0 L 9.09090909090909 0 L 9.09090909090909 9.09090909090909 L 0 9.09090909090909 L 0 0 Z M 10.9090909090909 0 L 20 0 L 20 9.09090909090909 L 10.9090909090909 9.09090909090909 L 10.9090909090909 0 Z \" fill-rule=\"nonzero\" stroke=\"none\" transform=\"matrix(1 0 0 1 599 143 )\" /> </g> </svg>","className":"","link":"","enable":true,"action":"qr"},{"id":"calculator","visibility":true,"svgCode":"<svg version=\"1.1\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\"24px\" height=\"20px\" xmlns=\"http://www.w3.org/2000/svg\"> <g transform=\"matrix(1 0 0 1 -700 -143 )\"> <path d=\"M 22.9254067278288 6.87709503828556 C 23.4670825688073 8.02092075006519 23.7958409785933 9.21991086456629 23.9307889908257 10.470082734751 C 23.9561345565749 10.7048929663609 23.9770275229358 10.9401299101534 23.9999755351682 11.175177204087 C 24 11.5228765142356 24 11.8705521181519 24 12.2182514283005 C 23.9767094801223 12.4535357845578 23.9563058103976 12.6891046156034 23.9296880733945 12.9240333783752 C 23.7369785932722 14.6245051323993 23.1916574923547 16.2094327098594 22.2713639143731 17.6715620036508 C 21.7986055045872 18.422670270014 21.2674250764526 19.1299457127279 20.6212599388379 19.7516653628239 C 20.5726972477064 19.7983903468222 20.5206850152905 19.8417964582889 20.460379204893 19.8956096057654 C 20.3822629969419 19.8263162885523 20.3077920489297 19.7657942773155 20.2398042813455 19.6990612331982 C 19.7643058103976 19.2324751677216 19.2892232415902 18.7655098025271 18.816244648318 18.2965294075813 C 18.6957798165138 18.1770974089088 18.7016758409786 18.1720005689496 18.8199388379205 18.0508143090819 C 20.1482813455658 16.6894365028566 21.0023975535168 15.0932010525567 21.3325504587156 13.243759334329 C 21.3996574923547 12.8677784889648 21.4179571865443 12.483595287201 21.4576880733945 12.1031102576868 C 21.4616758409786 12.0649669298058 21.4582262996942 12.0261124149539 21.4582262996942 11.9732949292369 C 21.3905810397553 11.9732949292369 21.3348990825688 11.9732949292369 21.2791926605505 11.9732949292369 C 20.8347645259939 11.9732949292369 20.3903119266055 11.9706161249793 19.9459571865443 11.9754521963824 C 19.8516452599389 11.9764715643743 19.7812599388379 11.9527890382382 19.723498470948 11.8826660028922 C 19.6982018348624 11.851966431975 19.6661039755352 11.8266007633407 19.6383608562691 11.7976791598511 C 19.4380183486239 11.5887087215229 19.4440122324159 11.4314652822227 19.6331498470948 11.216354929711 C 19.7509480122324 11.0823673043643 19.8785565749236 11.0274873764313 20.0637798165138 11.034291065121 C 20.4382629969419 11.0480169736624 20.8137737003058 11.0358556764573 21.1888685015291 11.0338643529384 C 21.2336636085627 11.0336272906147 21.2784587155963 11.0303084180831 21.32325382263 11.0285304506555 C 21.4308990825688 11.0242396225968 21.4736146788991 10.9762819145153 21.4528929663609 10.8686556195624 C 21.3551314984709 10.3610103596235 21.287119266055 9.84644287983311 21.1600733944954 9.34588578337245 C 20.8319510703364 8.05306640115687 20.2010275229358 6.90284000663775 19.3413577981651 5.86801555128844 C 19.3036330275229 5.82261811630278 19.2616024464832 5.78058696631345 19.2137003058104 5.72838584263803 C 19.1457370030581 5.78658464310267 19.0835718654434 5.83653367470308 19.0251987767584 5.89037052841192 C 18.7800856269113 6.11640945404547 18.5363425076453 6.34384704738876 18.2915963302752 6.57026527274021 C 18.1653333333333 6.68706587961975 18.02074617737 6.73426498826541 17.8439143730887 6.69861081478321 C 17.5408929663609 6.63751985396961 17.3874250764526 6.31845767252211 17.559755351682 6.0682383898727 C 17.6585443425076 5.92481568404334 17.7788379204893 5.7925823198919 17.9046116207951 5.66992627361734 C 18.1195840978593 5.46024464831804 18.346495412844 5.26206054571747 18.5661406727829 5.06107910769742 C 17.3604648318043 3.71980418652064 14.3255535168196 2.45901192423488 12.4745443425076 2.51687883744637 C 12.4745443425076 2.56277410331176 12.4750825688073 2.609238318754 12.4744709480122 2.65567882796387 C 12.4694801223241 3.03476518976839 12.4703363914373 3.41406490766423 12.4565871559633 3.79286679468032 C 12.4495902140673 3.98590664485693 12.28 4.15094943460636 12.0907400611621 4.1795865633075 C 11.9001100917431 4.20843704809995 11.6601345565749 4.08438233411564 11.6001957186544 3.90191546357538 C 11.5563547400612 3.76847308157315 11.5340917431193 3.62464736979352 11.5273394495413 3.48430647417206 C 11.5138593272171 3.20428845743546 11.5175779816514 2.92346442879833 11.514373088685 2.64299599364673 C 11.5138837920489 2.6009648436574 11.5142996941896 2.5589099874357 11.5142996941896 2.51007514875661 C 10.9660183486238 2.53802479671906 10.4427889908257 2.60523196548373 9.92643425076452 2.72305194035512 C 8.32442813455658 3.08860204347723 6.91148623853211 3.80808619586089 5.66842813455657 4.84947727757628 C 5.57443425076452 4.92820567527203 5.5679021406728 4.98180546665718 5.65118042813456 5.06634189128322 C 5.87911926605506 5.29769101296731 6.10267889908257 5.53309390038641 6.32719266055044 5.76757224474314 C 6.40477064220184 5.84860014697864 6.48484403669726 5.92799231918071 6.55552293577981 6.01447265486096 C 6.70666666666667 6.19938126733519 6.68824464831804 6.40062347391129 6.50960244648319 6.59010738923263 C 6.38096636085626 6.72656046274566 6.11571865443426 6.75977289429391 5.94923547400612 6.6495626200128 C 5.85573088685015 6.58766564729867 5.77140061162079 6.5112130479103 5.68939449541283 6.43480786098665 C 5.41915596330275 6.18297655453619 5.15185321100918 5.92815826280729 4.86199388379205 5.65420904155703 C 3.51217125382263 7.21571486143707 2.73839755351681 8.99477277576275 2.5560122324159 11.0388426617358 C 2.61279510703363 11.0388426617358 2.65570642201834 11.0388426617358 2.69861773700305 11.0388426617358 C 3.11043425076453 11.0388426617358 3.52222629969418 11.0387004243416 3.93404281345565 11.0388900742005 C 4.24594495412843 11.0390323115947 4.49044648318043 11.4317023445464 4.33110703363915 11.6933480311974 C 4.22874617737002 11.8614489249224 4.09930275229357 11.9902922978451 3.85644036697248 11.9784628878932 C 3.46194495412843 11.9592371334424 3.0657125382263 11.9732949292369 2.67021406727828 11.9732949292369 C 2.62600611620794 11.9732949292369 2.58179816513762 11.9732949292369 2.54155351681956 11.9732949292369 C 2.59510703363914 13.1443828082403 2.84347400611619 14.2618234833938 3.32956574923548 15.3274660408221 C 3.81394495412844 16.3893630135363 4.46647094801223 17.339935519048 5.33702752293577 18.1687528151151 C 4.72824464831805 18.7502192826494 4.13181651376148 19.3198800464642 3.49658715596331 19.9266173577033 C 3.43033639143729 19.8398051347699 3.38705810397552 19.7720527226608 3.33294189602448 19.713782803499 C 2.13670948012234 18.4258469051514 1.18546788990825 16.9963373870991 0.628746177370022 15.3372567147903 C 0.303388379204898 14.3676955171515 0.0989357798165201 13.376348291966 0.0449418960244657 12.3570277125856 C 0.0424709480122419 12.310539790911 0.0314862385321157 12.2645022876514 0.02446483180428 12.2182514283005 C 0.02446483180428 11.8705521181519 0.02446483180428 11.5228765142356 0.02446483180428 11.175177204087 C 0.0315107033639197 11.1292582319892 0.0395351681957163 11.0834577910533 0.0454311926605442 11.0373965815613 C 0.114470948012231 10.4972737832776 0.149724770642206 9.9507265960221 0.257761467889895 9.41804755470213 C 0.748770642201825 6.99728563639381 1.92555351681957 4.93202237868336 3.77431192660551 3.23797501363109 C 5.61893577981652 1.54772064575777 7.80501529051989 0.523895882227438 10.3218593272171 0.173968186236163 C 10.6399021406728 0.12975606286893 10.9594373088685 0.0957139131877789 11.2782874617737 0.0569542232652972 C 11.5147889908257 0.0569542232652972 11.7512660550459 0.0569542232652972 11.9877675840978 0.0569542232652972 C 12.0725871559633 0.0638053244197918 12.1573333333333 0.071699499798498 12.2422262996942 0.0772941706374628 C 12.7706422018349 0.112094919754405 13.3039021406728 0.113991418343885 13.8265688073394 0.187077732735937 C 15.2475107033639 0.385807078680986 16.586373088685 0.842460232795203 17.833370030581 1.5268591612735 C 20.1179204892967 2.78072920370766 21.8270825688073 4.55781950074675 22.9254067278288 6.87709503828556 Z M 14.5936792950603 14.3919304090004 C 14.8447937829645 14.562310503365 15.1904519035511 14.5037981190707 15.3657283160753 14.2612393408 C 15.4480138820115 14.1473672797774 15.4812950463764 14.0068797932099 15.4585518123271 13.869409910198 L 14.8758815873667 10.2925442919147 L 16.4221050492624 8.7958656795506 C 16.459825603942 8.76095889492629 16.4938895268136 8.72252884841823 16.5238030259586 8.68113262343899 C 16.775275640771 8.33312863739782 16.6870706088987 7.85285159661588 16.326791573168 7.60840382851744 C 16.0048850684353 7.38999165679984 15.5672031301943 7.43104593010522 15.2960972216164 7.70508226988268 L 13.7645187604228 9.18822101750708 L 10.0343506086014 8.61900891205726 C 9.82494204121971 8.58664455567652 9.61514849214037 8.6726133083504 9.49382933392481 8.84050256608795 C 9.31855292140061 9.08306134435868 9.38003182861574 9.41781444178378 9.63114631651995 9.58819453614833 C 9.66413197559523 9.61057516321938 9.69952511772738 9.62942217605427 9.73670076888198 9.64440277307214 L 12.2458252826817 10.6575647936732 L 10.6323705204674 12.2203750871821 L 9.49472982805295 11.9959612460911 C 9.3019483770822 11.959477639514 9.10537514931091 12.0361468861555 8.99300850478042 12.1916470793827 C 8.83583812052269 12.4091495706584 8.89096626544288 12.7093227211472 9.11614066277455 12.8621025762087 C 9.13482606523967 12.874780540996 9.15438595052126 12.8862027581838 9.17468199125791 12.8962884499381 L 10.4289328607928 13.5068935539905 L 11.0602566207967 14.7212350193497 C 11.0973001170976 14.7907746141185 11.1512537886495 14.8505874999677 11.2174551001418 14.8955048035979 C 11.4426294974735 15.0482846586594 11.7525811837958 14.9958165952679 11.9097515680535 14.7783141039922 C 11.9868163447553 14.6716669070574 12.015808595979 14.5391978583419 11.9900996775528 14.4111940225156 L 11.7581813366606 13.3100857680551 L 13.3641537842551 11.7562846170656 L 14.398984119107 14.1571673183659 C 14.4395098228199 14.2517087417316 14.5070580442564 14.3331582648318 14.5936792950603 14.3919304090004 Z \" fill-rule=\"nonzero\" stroke=\"none\" transform=\"matrix(1 0 0 1 700 143 )\" /> </g> </svg>","className":"","link":"/mileagecalculator","enable":true,"action":"link"},{"id":"claim","visibility":true,"svgCode":"<svg version=\"1.1\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\"25px\" height=\"22px\" xmlns=\"http://www.w3.org/2000/svg\"> <g transform=\"matrix(1 0 0 1 -800 -143 )\"> <path d=\"M 22.1153846153846 6.21739130434783 C 22.1153846153846 9.6991304347826 19.3653846153846 12.4347826086957 15.8653846153846 12.4347826086957 C 12.3653846153846 12.4347826086957 9.61538461538462 9.6991304347826 9.61538461538462 6.21739130434783 C 9.61538461538462 2.73565217391306 12.3653846153846 0 15.8653846153846 0 C 19.3653846153846 0 22.1153846153846 2.73565217391306 22.1153846153846 6.21739130434783 Z M 3.23497267770147 12.3261661690495 C 2.76106588244103 12.3261661690495 2.2871590871807 12.3261661690495 1.81325229192026 12.3263057603572 C 0.230526022859032 12.2280334797565 0.215436169960981 12.2419926105236 0.249744231738611 13.7843369689852 C 0.251310159869543 13.8535742575902 0.048878359671151 20.8138760407031 0.532180723717073 21.0898480559694 C 1.82236314650033 21.3062145828602 3.11525035423673 21.2552637555601 4.4087069903845 21.1257230220411 C 4.73826368339379 21.0859394993547 4.79890780919163 20.851286511159 4.79919252339716 20.587877713583 C 4.79976195180843 20.2052579392556 4.78638038414418 19.8226381649282 4.77897781479791 19.4400183906008 C 4.77897781479791 19.0212444675865 4.77897781479791 18.6024705445723 4.77883545769515 18.183696621558 C 4.77883545769515 17.6706985658655 4.77869310059239 17.1575609188653 4.77869310059239 16.6445628631729 C 4.77869310059239 16.3187567510677 4.77869310059239 15.9930902302703 4.77883545769515 15.6672841181651 C 4.77883545769515 15.3416175973677 4.77883545769515 15.0159510765702 4.77883545769515 14.6902845557728 C 4.77883545769515 14.412358262199 4.77883545769515 14.1344319686252 4.77883545769515 13.8563660837437 C 4.77855074348952 13.5306995629463 4.77840838638665 13.2051726334565 4.77812367218112 12.8795061126591 C 4.81058109162219 12.3827006486564 4.43305005496538 12.3755814919652 4.09082357980577 12.3264453516649 C 3.80553994577108 12.3263057603572 3.52025631173627 12.3263057603572 3.23497267770147 12.3261661690495 Z M 8.08152024292825 20.3835160391521 C 8.36481087752361 20.4795548588299 8.64824386922184 20.5757332698156 8.93153450381743 20.6717720894935 C 9.25596634112531 20.7893079705529 9.58039817843341 20.9069834429199 9.9048300157415 21.0245193239793 C 10.1038452454723 21.0918023342769 12.4236965928928 21.879376492159 12.7703361382395 21.9181828756917 C 12.8588822561884 21.9349338326123 12.9475707312401 21.9515451982252 13.0361168491891 21.9682961551457 C 13.0475054174141 22.0075213126015 14.9482574541569 22.0378126263661 15.1037114104273 21.8323342214738 C 15.6089367683063 21.7503941238706 23.6710465718453 17.4646617957424 24.5378589708662 16.9746963058157 C 24.8499057402297 16.7985320755344 24.8460620984537 16.5938912184881 24.6746641466684 16.37557041329 C 23.9758331289653 15.485536235577 22.6345445062728 15.0923075218665 22.6345445062728 15.0923075218665 C 21.9730110495065 14.8411827593657 21.3603060790046 15.0653663994859 20.7466046087831 15.2792202828386 C 20.1220839987479 15.4791150354241 19.4975633887125 15.6790097880096 18.8730427786774 15.8787649492873 C 18.3988512692115 16.0021636652689 17.8346900707684 16.0483683881082 18.0674439338656 16.7796872489988 C 17.9178266188104 17.8277387869958 17.4104659043892 18.5947930226503 16.3274130661973 18.9097110127571 C 15.9023347572014 18.9451672049056 15.4773988053081 18.9804838057465 15.0523204963123 19.0159399978951 C 14.6727964602162 19.0159399978951 14.293130067017 19.0159399978951 13.9136060309209 19.0159399978951 C 13.5339396377218 19.0158004065874 13.1544156016257 19.0155212239721 12.7747492084268 19.0153816326643 C 12.4426300875669 19.0152420413567 12.110510966707 19.015102450049 11.7783918458471 19.0149628587414 C 11.2563683498364 19.0149628587414 10.7343448538256 19.0149628587414 10.2123213578149 19.0149628587414 C 9.95351614490304 18.975179336055 9.70054757320655 18.9211574999861 9.49982405824196 18.7378741130136 C 9.41839579543361 17.939830607056 10.0538779023852 18.1180887069525 10.4967508492328 18.0339151484266 C 10.7818921261647 18.0337755571188 11.0670334030967 18.0336359658112 11.3521746800287 18.0334963745035 C 11.7314140019193 18.0334963745035 12.1106533238098 18.0336359658112 12.4897502885975 18.0336359658112 C 12.8697013960021 18.0336359658112 13.2496525034068 18.0336359658112 13.6296036108114 18.0336359658112 C 14.008842932702 18.0339151484266 14.3880822545925 18.0341943310419 14.7673215764831 18.0344735136572 C 14.8622737640585 18.0343339223496 14.9572259516341 18.0341943310419 15.0523204963123 18.0340547397342 C 16.3420758477869 18.1179491156448 16.7015275323866 17.9165188586749 16.9204727565111 16.9871199321985 C 17.1416956942806 16.5137658078847 16.7001039613585 14.909442908817 15.052462853415 14.9888703628821 C 14.8141570633082 14.9888703628821 14.575993630304 14.9887307715743 14.3376878401972 14.9887307715743 C 13.9590179467178 14.9887307715743 13.5802056961357 14.9885911802667 13.2015358026564 14.9885911802667 C 12.8697013960021 14.9818907974984 12.5378669893479 14.9750508234225 12.2058902255909 14.9683504406543 C 12.0816124748362 14.8675655165155 11.9573347240815 14.7667805923768 11.8330569733269 14.665995668238 C 11.8330569733269 14.665995668238 11.2586460634814 14.2490364322234 11.2586460634814 14.2490364322234 C 11.0061045630933 14.021502600719 9.43818343272435 13.3715654722009 8.42303493257372 13.2258321469919 C 7.55394481990783 13.0729796650916 6.67517442425072 13.1783711023836 5.80238302691181 13.1933073723044 C 5.37673528950463 13.2005661203033 5.23736768585191 13.5179967539482 5.24021482790814 13.9271388767331 C 5.25174575323582 15.5708265245642 5.24235018445023 17.214653763703 5.24320432706713 18.8583414115341 C 5.24334668416989 19.0164983631257 5.21359404968229 19.1870789411002 5.3649196499712 19.307825422236 C 5.50585318175485 19.611157333806 7.8427873815129 20.2969694283957 8.08152024292825 20.3835160391521 Z M 13.8322951505018 10.4516858695652 L 15.8177884615385 9.40540652173907 L 17.77816680602 10.451120923913 C 17.9766653927337 10.5583139378985 18.2189670630803 10.5421736192536 18.4015259197325 10.4095974184783 C 18.5857964046822 10.2768351902174 18.6769439799331 10.0553764945652 18.6394126254181 9.83109307065216 L 18.275668896321 7.59277839673908 L 19.8734322742474 6.02505421195658 C 20.0350182727588 5.86800583291494 20.0925814424352 5.63225472024172 20.0215823578595 5.41830258152174 C 19.9523050419632 5.20372374008054 19.7666553659469 5.04761767841576 19.5435514214047 5.01634374999999 L 17.3173494983279 4.68585054347834 L 16.3367370401337 2.66560489130437 C 16.2386722738096 2.46107126672607 16.0317311040649 2.33132881933799 15.8050898829431 2.33228695652176 C 15.5783469054603 2.33121949908332 15.3712690546886 2.46097876474601 15.2731605351171 2.66560489130437 L 14.2727947324416 4.70082160326085 L 12.0669105351171 5.01634374999999 C 11.8436996286582 5.04751707815129 11.6579188528087 5.20364121389045 11.5885974080268 5.41830258152174 C 11.5177875047823 5.63217380402099 11.5753329270114 5.86774251173057 11.7367474916388 6.0247717391304 L 13.3410012541806 7.61650611413043 L 12.9707671404683 9.83165801630431 C 12.9335179765886 10.0556589673913 13.0243833612041 10.2771176630435 13.2086538461538 10.4098798913043 C 13.3914842402084 10.5419331470513 13.6335071204124 10.558157222009 13.8322951505018 10.4516858695652 Z \" fill-rule=\"nonzero\" stroke=\"none\" transform=\"matrix(1 0 0 1 800 143 )\" /> </g> </svg>","className":"","link":"/member/claimsummary","enable":true,"action":"link"},{"id":"buy","visibility":true,"svgCode":"<svg version=\"1.1\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\"20px\" height=\"24px\" xmlns=\"http://www.w3.org/2000/svg\"> <g transform=\"matrix(1 0 0 1 -894 -141 )\"> <path d=\"M 17.5 5.14285714285714 C 17.5 6.47056738570591 17.032432499551 7.66711583622095 16.254251797261 8.57142857142857 L 19.2307692307692 8.57142857142857 C 19.4391025641026 8.41558441558441 19.6193910256411 8.4926948051948 19.7716346153846 8.64691558441559 C 19.9238782051282 8.80113636363637 20 8.98376623376625 20 9.19480519480521 L 20 15.4285714285714 C 20 15.6233766233766 19.9338942307692 15.7958603896104 19.8016826923077 15.9460227272727 C 19.6694711538461 16.0961850649351 19.5072115384615 16.1834415584416 19.3149038461539 16.2077922077922 L 6.76682692307689 17.6931818181818 C 6.87099358974355 18.1801948051948 6.92307692307689 18.4642857142857 6.92307692307689 18.5454545454545 C 6.92307692307689 18.6753246753247 6.82692307692311 18.9350649350649 6.63461538461538 19 L 17.6923076923077 19 C 17.9006410256411 19.3246753246753 18.0809294871795 19.4017857142857 18.2331730769231 19.5560064935065 C 18.3854166666667 19.7102272727273 18.4615384615385 19.8928571428571 18.4615384615385 20.1038961038961 C 18.4615384615385 20.3149350649351 18.3854166666667 20.4975649350649 18.2331730769231 20.6517857142857 C 18.0809294871795 20.8060064935065 17.9006410256411 20.8831168831169 17.6923076923077 20.5714285714286 L 5.38461538461538 20.5714285714286 C 5.17628205128204 20.8831168831169 4.99599358974355 20.8060064935065 4.84375 20.6517857142857 C 4.69150641025645 20.4975649350649 4.61538461538462 20.3149350649351 4.61538461538462 20.1038961038961 C 4.61538461538462 20.0146103896104 4.64743589743591 19.8867694805195 4.71153846153849 19.7203733766234 C 4.77564102564107 19.5539772727273 4.83974358974355 19.4078733766234 4.90384615384613 19.2820616883117 C 4.96794871794871 19.15625 5.05408653846151 18.9939123376623 5.16225961538462 18.7950487012987 C 5.27043269230774 18.5961850649351 5.33253205128204 18.476461038961 5.34855769230774 18.4358766233766 L 3.22115384615387 8.41558441558441 L 0.769230769230755 8.41558441558441 C 0.560897435897421 8.41558441558441 0.380608974358931 8.33847402597402 0.228365384615377 8.18425324675323 C 0.076121794871824 8.03003246753245 0 7.84740259740257 0 7.63636363636366 C 0 7.4253246753247 0.076121794871824 7.24269480519482 0.228365384615377 7.08847402597404 C 0.380608974358931 6.93425324675325 0.560897435897421 6.85714285714286 0.769230769230755 6.85714285714286 L 3.84615384615387 6.85714285714286 C 3.97435897435893 6.85714285714286 4.08854166666667 6.88352272727272 4.18870192307689 6.93628246753248 C 4.2888621794872 6.9890422077922 4.3669871794872 7.05194805194807 4.42307692307689 7.125 C 4.47916666666667 7.19805194805193 4.53125 7.29748376623377 4.57932692307689 7.42329545454546 C 4.62740384615387 7.54910714285716 4.65945512820516 7.65462662337664 4.67548076923076 7.73985389610391 C 4.69150641025645 7.82508116883118 4.71354166666667 7.94480519480518 4.74158653846151 8.09902597402596 C 4.76963141025645 8.25324675324675 4.78766025641022 8.35876623376623 4.79567307692311 8.57142857142857 L 8.74608300546119 8.57142766191334 C 7.96762625186498 7.66726618128445 7.5 6.47065079869602 7.5 5.14285714285714 C 7.5 2.26285714285713 9.69999999999999 0 12.5 0 C 15.3 0 17.5 2.26285714285713 17.5 5.14285714285714 Z M 5.07211538461538 21.3457792207792 C 5.37660256410258 21.0373376623377 5.73717948717947 20.8831168831169 6.15384615384613 20.8831168831169 C 6.5705128205128 20.8831168831169 6.93108974358978 21.0373376623377 7.23557692307689 21.3457792207792 C 7.54006410256409 21.6542207792208 7.69230769230774 22.0194805194805 7.69230769230774 22.4415584415584 C 7.69230769230774 22.8636363636364 7.54006410256409 23.2288961038961 7.23557692307689 23.5373376623376 C 6.93108974358978 23.8457792207792 6.5705128205128 24 6.15384615384613 24 C 5.73717948717947 24 5.37660256410258 23.8457792207792 5.07211538461538 23.5373376623376 C 4.76762820512818 23.2288961038961 4.61538461538462 22.8636363636364 4.61538461538462 22.4415584415584 C 4.61538461538462 22.0194805194805 4.76762820512818 21.6542207792208 5.07211538461538 21.3457792207792 Z M 15.8413461538461 21.3457792207792 C 16.1458333333333 21.0373376623377 16.5064102564102 20.8831168831169 16.9230769230769 20.8831168831169 C 17.3397435897436 20.8831168831169 17.7003205128205 21.0373376623377 18.0048076923077 21.3457792207792 C 18.3092948717948 21.6542207792208 18.4615384615385 22.0194805194805 18.4615384615385 22.4415584415584 C 18.4615384615385 22.8636363636364 18.3092948717948 23.2288961038961 18.0048076923077 23.5373376623376 C 17.7003205128205 23.8457792207792 17.3397435897436 24 16.9230769230769 24 C 16.5064102564102 24 16.1458333333333 23.8457792207792 15.8413461538461 23.5373376623376 C 15.5368589743589 23.2288961038961 15.3846153846154 22.8636363636364 15.3846153846154 22.4415584415584 C 15.3846153846154 22.0194805194805 15.5368589743589 21.6542207792208 15.8413461538461 21.3457792207792 Z M 10.3281599351467 8.57142857142857 L 11.009191268374 8.57143319711796 L 12.4619230769231 7.77989670329665 L 13.8970522299202 8.57142857142857 L 14.575132199645 8.57142696932794 C 14.6912244059293 8.46009604054479 14.7459206810697 8.29697826602139 14.7192224080268 8.13201304945056 L 14.428227424749 6.28053997252742 L 15.7064381270902 4.98376112637369 C 15.8357069258993 4.85385497467887 15.8817574616404 4.65884806029983 15.8249581939799 4.48187266483517 C 15.7695363412628 4.30437887790876 15.6210166004499 4.17525218554272 15.442533444816 4.14938324175824 L 13.6615719063546 3.87600824175833 L 12.8770819397993 2.20491593406595 C 12.7986301267399 2.03573127757162 12.6330771909442 1.92841185056128 12.4517642140467 1.92920439560443 C 12.2703698320605 1.92832142381719 12.1047075514431 2.03565476244726 12.026220735786 2.20491593406595 L 11.2259280936456 3.88839189560438 L 9.46122073578598 4.14938324175824 C 9.2826520106189 4.17516897173755 9.13402738993928 4.3043106144868 9.07857023411376 4.48187266483517 C 9.02192231151815 4.65878112860077 9.06795864930141 4.85363716255037 9.19709030100336 4.98352747252742 L 10.4804933110368 6.30016689560438 L 10.1843060200669 8.13248035714282 C 10.1578270333703 8.29712248385652 10.2122721933852 8.46010423958647 10.3281599351467 8.57142857142857 Z \" fill-rule=\"nonzero\" stroke=\"none\" transform=\"matrix(1 0 0 1 894 141 )\" /> </g> </svg>","className":"","link":"/buy","enable":true,"action":"link"},{"id":"transfer","visibility":true,"svgCode":"<svg version=\"1.1\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\"23px\" height=\"22px\" xmlns=\"http://www.w3.org/2000/svg\"> <g transform=\"matrix(1 0 0 1 -987 -143 )\"> <path d=\"M 9.87250080996437 0.00868553400416869 C 11.2442672522409 -0.0682998810327802 12.4606627308398 0.372227771678645 13.5708358832211 1.12832982654152 C 13.9666888656899 1.3979103781709 14.3327729579898 1.71183979282157 14.7001223946146 2.01991305196943 C 14.9346106771302 2.21658775756382 14.97396954534 2.45504514567826 14.8406422117427 2.65014066327189 C 14.7036520393103 2.85069753936815 14.4918067605025 2.89076943488738 14.1986464595558 2.77042214932962 C 12.8047697901292 2.19809809805494 11.395842182944 2.06413031599065 9.98531624608518 2.68922556629065 C 9.544110659131 2.88478168038451 9.14059901364341 3.16344256301824 8.71983872709601 3.40407133463373 C 8.71491054393606 3.44815699965489 8.70984916663667 3.49217686517602 8.704854386407 3.53626253019717 C 8.98922387414953 3.79952632982352 9.27119586738184 4.06529051045107 9.5586288203319 4.32519853557581 C 9.77233881709205 4.51845166716856 9.8488588502106 4.74736812777843 9.7383743115303 5.01392190240636 C 9.62888872889594 5.27817269453318 9.40159292991108 5.34561718206555 9.12947730299867 5.34930195406731 C 7.91487994528241 5.36568602957518 6.70041578170561 5.39154523308759 5.48588502105907 5.41214047659747 C 5.03715396522554 5.41977321860114 4.82457611865078 5.21257059300169 4.83183519925124 4.76723957678796 C 4.85174772310018 3.55080421970415 4.87812016271284 2.33443466212037 4.89683393930668 1.11799930503657 C 4.90076316642068 0.863223640914291 4.99046941934556 0.665167145819236 5.2332157385075 0.565217705271267 C 5.48122322617805 0.463096881222255 5.7055221570251 0.520145047749635 5.89578998524065 0.707542023839573 C 6.03131502213904 0.840983409903617 6.17822815796105 0.964949667963112 6.30023398970446 1.10951116953249 C 6.43749055041579 1.27216753361056 6.54531120630692 1.28716981961776 6.73258216638468 1.15774220305564 C 7.67586306202528 0.505866556242784 8.70745167212643 0.0740902370355581 9.87250080996437 0.00868553400416869 Z M 0.0165340725008112 17.4350909218677 C 0.0152021311062375 17.0569411951862 0.0177994168256646 16.6787256690047 0.0161344900824436 16.3005759423232 C 0.0108733215738539 15.1024986457482 0.532394974621123 14.1906491743106 1.6519583138342 13.737290619093 C 3.46393138701897 13.0036261937409 5.30900320385904 12.993427271236 7.09746751142949 13.8271069366361 C 8.05986176608229 14.2757279278514 8.52184563879189 15.1030908412485 8.55121494654236 16.1539088567528 C 8.56313582202383 16.5810792109578 8.55434500881961 17.0088417606631 8.5540786205407 17.4363411123683 C 8.55387882933151 17.7905398210383 8.50912559847367 17.8369284685606 8.15456279923683 17.8371258670606 C 6.85658591021996 17.8381128595611 5.55854242413334 17.8375864635609 4.26049893804673 17.8377180625609 C 2.97910471939235 17.837849661561 1.69771050073797 17.8384418570613 0.416316282083593 17.8374548645608 C 0.0617534828467493 17.8371916665607 0.0177994168256646 17.791921610539 0.0165340725008112 17.4350909218677 Z M 9.40672090428022 20.7890888369774 C 9.03024766910257 20.5352343658556 8.68400950358185 20.2359782397119 8.33450808164442 19.9451444495724 C 8.06871917635625 19.7239265304662 8.01717304438606 19.4882985208531 8.15895820583895 19.2807010982535 C 8.29841246985134 19.0764594501554 8.50892580726448 19.0426385071392 8.82419633536125 19.1708159332007 C 10.220470499298 19.7385998189732 11.6295978976925 19.8634872700332 13.0370603693438 19.23174627023 C 13.4698747255121 19.0374403466367 13.86592749919 18.763056431505 14.2787627344397 18.5253228378909 C 14.2828251556932 18.4828821603706 14.2868209798769 18.4405072823502 14.2908834011303 18.3981982038299 C 14.0076460635732 18.133815812703 13.7266064293171 17.8671304390751 13.4403722236222 17.6059064239497 C 13.228393750675 17.4123900943568 13.1488768494186 17.1843948267474 13.2603603441449 16.9171830571191 C 13.3704453004068 16.6531954629924 13.5973415169733 16.5850929804598 13.8693905468159 16.581474007958 C 15.0755966737464 16.5654189299503 16.2816696065373 16.5400203229381 17.4878757334677 16.5202804729287 C 17.973035386443 16.5123187334248 18.1772885993016 16.7153101910223 18.1684977860974 17.1888691927495 C 18.146254364808 18.3805639378215 18.1202149105439 19.5721928833934 18.1037654343209 20.7639534279653 C 18.1000359984161 21.0328101850944 18.0341714964542 21.256989081702 17.7657187083768 21.365492457254 C 17.4952014111379 21.4748512263065 17.2678390150833 21.3920096557668 17.0657835055258 21.19039998767 C 16.880244069261 21.0051743950811 16.6936390798805 20.7207231564446 16.4794629036323 20.6932189654314 C 16.2824687713741 20.6678861579192 16.0508441628568 20.9312157570456 15.8296752942871 21.0593931831071 C 13.6303070664891 22.3339294987188 11.4874131538212 22.1920657766507 9.40672090428022 20.7890888369774 Z M 18.7090662010872 7.30341550600516 C 17.11879477303 7.30032292950368 15.8426617228842 6.03012938089407 15.8467907412074 4.45449455313787 C 15.8509197595306 2.87918872288182 17.1315148133482 1.62557664828017 18.7313096223766 1.63077480878266 C 20.3099265632312 1.63590716978513 21.5840617012851 2.90156055289256 21.5836621188668 4.46410128014248 C 21.5832625364484 6.03585393739681 20.2968735375644 7.30650808250664 18.7090662010872 7.30341550600516 Z M 21.5238579502502 8.58275518511916 C 22.486252204903 9.03137617633447 22.9482360776126 9.85873908973155 22.977605385363 10.9095571052359 C 22.9895262608445 11.3367274594409 22.9807354476403 11.7644900091462 22.9804690593614 12.1919893608514 C 22.9802692681522 12.5461880695214 22.9355160372944 12.5925767170436 22.5809532380575 12.5927741155437 C 21.2829763490407 12.5937611080442 19.984932862954 12.5932347120439 18.6868893768674 12.593366311044 C 17.405495158213 12.5934979100441 16.1241009395587 12.5940901055443 14.8427067209043 12.5931031130439 C 14.4881439216674 12.5928399150437 14.4441898556463 12.547569859022 14.4429245113215 12.1907391703508 C 14.4415925699269 11.8125894436693 14.4441898556463 11.4343739174877 14.4425249289031 11.0562241908063 C 14.4372637603946 9.85814689423126 14.9587854134418 8.94629742279364 16.0783487526549 8.49293886757606 C 17.8903218258397 7.75927444222394 19.7353936426797 7.74914131921908 21.5238579502502 8.58275518511916 Z M 4.30658411029914 6.88243030480311 C 5.88520105115375 6.88756266580558 7.15933618920767 8.15321604891301 7.1589366067893 9.71575677616293 C 7.15853702437094 11.2875094334173 5.87214802548688 12.5581635785271 4.28434068900968 12.5550710020256 C 2.69406926095251 12.5519784255241 1.41793621080672 11.2817848769145 1.42206522912992 9.70615004915832 C 1.42619424745311 8.13084421890227 2.70678930127075 6.87723214430062 4.30658411029914 6.88243030480311 Z \" fill-rule=\"nonzero\" stroke=\"none\" transform=\"matrix(1 0 0 1 987 143 )\" /> </g> </svg>","className":"","link":"/transfer","enable":true,"action":"link"},{"id":"activity","visibility":true,"svgCode":"<svg version=\"1.1\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\"17px\" height=\"20px\" xmlns=\"http://www.w3.org/2000/svg\"> <g transform=\"matrix(1 0 0 1 -1102 -143 )\"> <path d=\"M 11.7317708333333 0.758928571428572 L 16.2473958333333 5.3125 C 16.3506944444444 5.41666666666667 16.4539930555556 5.55059523809524 16.5572916666667 5.71428571428571 L 11.3333333333333 5.71428571428571 L 11.3333333333333 0.446428571428572 C 11.4956597222222 0.550595238095237 11.6284722222222 0.654761904761902 11.7317708333333 0.758928571428572 Z M 10.2265625 6.83035714285714 C 10.4331597222222 7.03869047619047 10.6840277777778 7.14285714285714 10.9791666666667 7.14285714285714 L 17 7.14285714285714 L 17 18.9285714285714 C 17 19.2261904761905 16.8967013888889 19.4791666666667 16.6901041666667 19.6875 C 16.4835069444444 19.8958333333333 16.2326388888889 20 15.9375 20 L 1.0625 20 C 0.767361111111111 20 0.516493055555556 19.8958333333333 0.309895833333333 19.6875 C 0.103298611111111 19.4791666666667 0 19.2261904761905 0 18.9285714285714 L 0 1.07142857142857 C 0 0.773809523809523 0.103298611111111 0.520833333333333 0.309895833333333 0.3125 C 0.516493055555556 0.104166666666667 0.767361111111111 0 1.0625 0 L 9.91666666666667 0 L 9.91666666666667 6.07142857142857 C 9.91666666666667 6.36904761904762 10.0199652777778 6.62202380952381 10.2265625 6.83035714285714 Z M 12.650390625 15.6138392857143 C 12.716796875 15.546875 12.75 15.4613095238095 12.75 15.3571428571429 L 12.75 14.6428571428571 C 12.75 14.5386904761905 12.716796875 14.453125 12.650390625 14.3861607142857 C 12.583984375 14.3191964285714 12.4991319444444 14.2857142857143 12.3958333333333 14.2857142857143 L 4.60416666666667 14.2857142857143 C 4.50086805555556 14.2857142857143 4.416015625 14.3191964285714 4.349609375 14.3861607142857 C 4.283203125 14.453125 4.25 14.5386904761905 4.25 14.6428571428571 L 4.25 15.3571428571429 C 4.25 15.4613095238095 4.283203125 15.546875 4.349609375 15.6138392857143 C 4.416015625 15.6808035714286 4.50086805555556 15.7142857142857 4.60416666666667 15.7142857142857 L 12.3958333333333 15.7142857142857 C 12.4991319444444 15.7142857142857 12.583984375 15.6808035714286 12.650390625 15.6138392857143 Z M 12.650390625 12.7566964285714 C 12.716796875 12.6897321428571 12.75 12.6041666666667 12.75 12.5 L 12.75 11.7857142857143 C 12.75 11.6815476190476 12.716796875 11.5959821428571 12.650390625 11.5290178571429 C 12.583984375 11.4620535714286 12.4991319444444 11.4285714285714 12.3958333333333 11.4285714285714 L 4.60416666666667 11.4285714285714 C 4.50086805555556 11.4285714285714 4.416015625 11.4620535714286 4.349609375 11.5290178571429 C 4.283203125 11.5959821428571 4.25 11.6815476190476 4.25 11.7857142857143 L 4.25 12.5 C 4.25 12.6041666666667 4.283203125 12.6897321428571 4.349609375 12.7566964285714 C 4.416015625 12.8236607142857 4.50086805555556 12.8571428571429 4.60416666666667 12.8571428571429 L 12.3958333333333 12.8571428571429 C 12.4991319444444 12.8571428571429 12.583984375 12.8236607142857 12.650390625 12.7566964285714 Z M 12.650390625 9.89955357142857 C 12.716796875 9.83258928571429 12.75 9.74702380952381 12.75 9.64285714285714 L 12.75 8.92857142857143 C 12.75 8.82440476190476 12.716796875 8.73883928571429 12.650390625 8.671875 C 12.583984375 8.60491071428571 12.4991319444444 8.57142857142857 12.3958333333333 8.57142857142857 L 4.60416666666667 8.57142857142857 C 4.50086805555556 8.57142857142857 4.416015625 8.60491071428571 4.349609375 8.671875 C 4.283203125 8.73883928571429 4.25 8.82440476190476 4.25 8.92857142857143 L 4.25 9.64285714285714 C 4.25 9.74702380952381 4.283203125 9.83258928571429 4.349609375 9.89955357142857 C 4.416015625 9.96651785714286 4.50086805555556 10 4.60416666666667 10 L 12.3958333333333 10 C 12.4991319444444 10 12.583984375 9.96651785714286 12.650390625 9.89955357142857 Z \" fill-rule=\"nonzero\" stroke=\"none\" transform=\"matrix(1 0 0 1 1102 143 )\" /> </g> </svg>","className":"","link":"/member/myactivity","enable":true,"action":"link"}]}}}}}}