import React, { Component } from 'react';
import { withSuspense } from '../../common/utils';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { TAB_EARN_MILES } from './Constants';
import { BROWSER_STORAGE_KEY_MISSING_POINTS, BROWSER_STORAGE_TYPE_SESSION, setItemToBrowserStorage } from '../../common/utils/storage.utils';
import { NAVIGATE_BUY } from '../../common/utils/urlConstants';

class ChartView extends Component {
    navigateToBuyMiles(missingMiles) {
        setItemToBrowserStorage(BROWSER_STORAGE_KEY_MISSING_POINTS, -missingMiles, BROWSER_STORAGE_TYPE_SESSION)
        window.location.href = `#${NAVIGATE_BUY}`
    }
    render() {
        const { tabName, cabinClass, calculatedMileage, t } = this.props
        const selectedTabData = calculatedMileage[tabName]&& calculatedMileage[tabName].processed_data && calculatedMileage[tabName].processed_data.chart[cabinClass]
        const milesView = tabName == TAB_EARN_MILES?"earnMilesView":"" 
        let currentMilesWidth, calculatedMilesWidth, balanceMilesWidth
        if(selectedTabData){
            if(tabName == TAB_EARN_MILES){
                balanceMilesWidth = "100%"
                calculatedMilesWidth = `${(selectedTabData.calculatedMiles/selectedTabData.balanceMiles)*100}%`;
                currentMilesWidth = `${(selectedTabData.currentMiles/selectedTabData.balanceMiles)*100}%`;
            } else if(selectedTabData.currentMiles>0){
                currentMilesWidth = "100%"
                let usedMilesWidth = (selectedTabData.calculatedMiles / selectedTabData.currentMiles) * 100;
                calculatedMilesWidth = selectedTabData.balanceMiles < 0 ? (100 + usedMilesWidth) + "%" : usedMilesWidth + "%"
                balanceMilesWidth = `${(selectedTabData.balanceMiles / selectedTabData.currentMiles)*100}%`;
            } else { //If currentMiles is zero, balance is less than 0
                currentMilesWidth = "0%"
                calculatedMilesWidth = "100%";
                balanceMilesWidth = "100%";;
            }
        }

        return (
            selectedTabData?
                <div className={`col-lg-5 miles-view ${milesView}`}>
                    <div className="form-row miles-view__row ">
                        <div className="col-3 miles-view__row--label">{t('mileage_calculator.chart.currentMiles')}</div>
                        <div className="col-4 p-0">
                            <div className="miles-view__row--bar currentMiles" style={{ "width": currentMilesWidth }}>
                                <span>{parseInt(selectedTabData.currentMiles)}</span>
                            </div>
                        </div>
                        <div className="col-5"></div>
                    </div>
                    <div className="form-row miles-view__row">
                        <div className="col-3 miles-view__row--label">{tabName == TAB_EARN_MILES ? t('mileage_calculator.chart.earnedMiles') : t('mileage_calculator.chart.usedMiles')}</div>
                        <div className="col-4 p-0">
                            <div className={`miles-view__row--bar useMiles ${tabName == TAB_EARN_MILES && selectedTabData.balanceMiles < 0 ? "overMiles" : ""} ${tabName != TAB_EARN_MILES && selectedTabData.balanceMiles < 0 ? "noBalanceMiles" : ""} `} style={{ "width": calculatedMilesWidth }}>
                                <span>{parseInt(selectedTabData.calculatedMiles)}</span>
                            </div>
                        </div>
                        <div className="col-5"></div>
                    </div>
                    <div className="form-row miles-view__row">
                        <div className="col-3 miles-view__row--label">{t('mileage_calculator.chart.balanceMiles')}</div>
                        <div className="col-4 p-0">
                            <div className={`miles-view__row--bar balanceMiles ${selectedTabData.balanceMiles < 0 ? "noBalanceMiles" : ""}`} style={{ "width": balanceMilesWidth }}>
                                <span>{parseInt(selectedTabData.balanceMiles)}
                                </span>
                            </div>
                        </div>

                        <div className="col-5"></div>
                        {
                            selectedTabData.balanceMiles < 0 &&
                            <span className="miles-view__row--label text">{t('mileage_calculator.chart.insufficientMilesText1')} <a role="button" onClick={() => this.navigateToBuyMiles(selectedTabData.balanceMiles)} data-test="buyMilesBtnChart">{t('mileage_calculator.chart.buyMiles')} {-parseInt(selectedTabData.balanceMiles)}</a>{t('mileage_calculator.chart.insufficientMilesText2')}</span>
                        }
                    </div>
                </div> :
                <div></div>
        );
    }
}

function mapStateToProps(state) {
    return {
        calculatedMileage: state.mileageCalculatorReducer
    }
}

const mapDispatchToProps = {
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(ChartView)));