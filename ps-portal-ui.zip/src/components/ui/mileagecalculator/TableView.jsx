import React, { Component } from 'react';
import { withSuspense } from '../../common/utils';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';
import { setItemToBrowserStorage, BROWSER_STORAGE_KEY_BOOK, BROWSER_STORAGE_TYPE_SESSION, BROWSER_STORAGE_KEY_MISSING_POINTS } from '../../common/utils/storage.utils';
import { NAVIGATE_MEMBER_BOOKING, NAVIGATE_BUY, NAVIGATE_MEMBER_MYFLIGHT } from '../../common/utils/urlConstants';
import { TAB_UPGRADE_MILES, TAB_EARN_MILES, TAB_USE_MILES } from './Constants';

/**
 * TableView class.
 * @description To view the travel class details in a table format in with rows and columns
 * @author Somdas M
 */
class TableView extends Component {

    navigateToFlights(){
        window.location.href = `#${NAVIGATE_MEMBER_MYFLIGHT}`
    }

    navigateToBuyMiles(missingMiles) {
        setItemToBrowserStorage(BROWSER_STORAGE_KEY_MISSING_POINTS, -missingMiles, BROWSER_STORAGE_TYPE_SESSION)
        window.location.href = `#${NAVIGATE_BUY}`
    }

    navigateToBookFlight(result) {
        const { data } = this.props.rootState
        if(data){
            const book = {
                fromAirport: data.fromAirport,
                toAirport: data.toAirport,
                fromDate: data.travelDate,
                toDate: data.returnDate,
                cabinClass: result,
                bookingClass: this.props.getBookingClassByCabinClass(data.cabinClass),
                isRoundTrip: this.props.isRoundTrip
            }
            setItemToBrowserStorage(BROWSER_STORAGE_KEY_BOOK, JSON.stringify(book), BROWSER_STORAGE_TYPE_SESSION)
            window.location.href = `#${NAVIGATE_MEMBER_BOOKING}`
        }
    }

    /**
     * Method returns the cabinClassName from default config based on cabinClassCode provided.
     * @author Somdas M
     * @param {*} cabinClassCode 
     */
    getCabinClassName(cabinClassCode) {
        const { partnerCode, defaultConfig } = this.props
        const currentProgram = getCurrentProgramFromDefaultConfig(defaultConfig)
        if(currentProgram){
            const cabinFound =  currentProgram.data.cabinClasses[partnerCode].find(cabin => { return cabin.cabinClassCode == cabinClassCode })
            if(cabinFound){
                return cabinFound.cabinClassName;
            }
        }
        return ""
    }

    getMissingMiles(response){
        if(response.requiredPoints >= 0){
            const diff = (response.requiredPoints) - response.points
            if(diff<0){
                return parseInt(diff)
            }
        }
        return 0
    }

    render() {
        const { t, calculatedMileage, rootState } = this.props
        const { selectedTab } = rootState
        return (
            <div className="col-lg-7">
                <div className="form-row">
                    <div className="col-3">
                        <label>
                            {selectedTab != TAB_UPGRADE_MILES ?
                                t('mileage_calculator.earnMiles.travel_class') :
                                t('mileage_calculator.upgrade_to')
                            }</label>
                    </div>
                    <div className="col-3">
                        <label>{t(`mileage_calculator.${selectedTab}.table_title`)}</label>
                    </div>
                    <div className="col-6 text-right"></div>
                </div>
                <ul className="list-group" data-test="ResultListGroup">
                    {
                        calculatedMileage[selectedTab] && calculatedMileage[selectedTab].processed_data &&
                        Object.keys(calculatedMileage[selectedTab].processed_data.table).map((result, index) => {
                            const processedTableData = calculatedMileage[selectedTab].processed_data.table[result]
                            let missingMiles = 0
                            if(processedTableData.requiredPoints >= 0){
                                missingMiles = this.getMissingMiles(processedTableData)
                            }
                            return <li className={"list-group-item " + (this.props.cabinClass == result ? "active" : "")} key={index} onClick={() => this.props.onChangeList(result)} data-test="treeView">
                                <div className="form-row">
                                    <div className="col-3" data-test="TravelClassNameInList">
                                        <label className="sr-only">{t('mileage_calculator.earnMiles.travel_class')}</label>
                                        {this.getCabinClassName(result)}</div>
                                    <div className="col-3">
                                        <label className="sr-only">{t('mileage_calculator.earnMiles.miles')}</label>
                                        {
                                            parseInt(processedTableData.points)
                                        }
                                        {
                                            missingMiles!="" &&
                                            <span className="text-danger"> ({missingMiles})</span>
                                        }
                                    </div>
                                    <div className="col-6 text-right btn-wrap btn-wrap--grp">
                                        {(selectedTab == TAB_USE_MILES || selectedTab == TAB_UPGRADE_MILES) && missingMiles != "" &&
                                            <button type="button" className="btn btn-link" onClick={() => this.navigateToBuyMiles(missingMiles)} data-test="buyMilesBtnTable">{t('mileage_calculator.useMiles.buyMiles')}</button>
                                        } &nbsp;
                                        {(selectedTab == TAB_EARN_MILES || selectedTab == TAB_USE_MILES) &&
                                            <button type="button" className="btn btn-link" onClick={() => this.navigateToBookFlight(result)} data-test="bookFlightBtn">{t('mileage_calculator.book_flight')}</button>
                                        }
                                       {/*  {(selectedTab == TAB_UPGRADE_MILES) &&
                                          <button type="button" className="btn btn-link" onClick={() => this.navigateToFlights()} data-test="bookUpgradeBtn">{t('mileage_calculator.upgrade_btn')}</button>
                                        } */}
                                    </div>
                                </div>
                            </li>
                        })
                    }

                </ul>
            </div>

        );
    }
}

function mapStateToProps(state) {
    return {
        defaultConfig: state.configurationReducer.default,
        calculatedMileage: state.mileageCalculatorReducer
    }
}

const mapDispatchToProps = {
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(TableView)));