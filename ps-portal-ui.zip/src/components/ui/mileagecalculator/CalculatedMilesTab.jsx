import React, { Component } from 'react'
import { withTranslation } from 'react-i18next';
import { withSuspense } from '../../common/utils';
import { connect } from 'react-redux';
import { calculateMileage } from './action';
import TableView from './TableView';
import ChartView from './ChartView';
import { CONFIG_SECTION_MILEAGECALCULATOR } from '../../common/utils/Constants';
import { TAB_UPGRADE_MILES } from './Constants';
import Custommessage from '../../common/components/custommessage';

/**
 * CalculatedMilesTab class.
 * @description The component to which renders the contents for EARN, BURN, UPGRADE tabs
 * @author Somdas M
 */
class CalculatedMilesTab extends Component {
    constructor(props) {
        super(props);
        this.state = {
            cabinClass: props.cabinClass
        }
        this.onChangeList = this.onChangeList.bind(this)
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevProps.rootState.selectedTab != this.props.rootState.selectedTab) {
            this.setState({
                cabinClass: this.props.cabinClass
            })
        }

        if (this.props.rootState.selectedTab == TAB_UPGRADE_MILES && this.props.calculatedMileage[TAB_UPGRADE_MILES] && this.props.calculatedMileage[TAB_UPGRADE_MILES].processed_data && prevState.cabinClass != Object.keys(this.props.calculatedMileage[TAB_UPGRADE_MILES].processed_data.table)[0]) {
            if (this.props.calculatedMileage[TAB_UPGRADE_MILES]) {
                this.setState({
                    cabinClass: Object.keys(this.props.calculatedMileage[TAB_UPGRADE_MILES].processed_data.table)[0]
                })
            }

        }
    }

    /**
     * Method to highlight the selected travel class in the table view
     * @param {*} result 
     */
    onChangeList(result) {
        this.setState({
            cabinClass: result,
        })
    }



    render() {
        const { cabinClass } = this.state
        const { rootState, calculatedMileage, t } = this.props
        const { partnerCode } = rootState.data
        const { selectedTab, loading } = rootState


        return (
            <div className="tab-pane fade show active" id="t1" role="tabpanel" aria-labelledby="home-tab" data-test="calculatedMilesTab">
                { loading ?
                    <div className="form-row justify-content-center">
                        <i className="fa fa-circle-o-notch fa-spin fa-3x"></i>
                    </div> :
                    <div className="form-row">
                        {/* {
                        loading && 
                        <i className="fa fa-circle-o-notch fa-spin fa-3x"></i>
                    } */}
                        {
                            (calculatedMileage && calculatedMileage[selectedTab] && calculatedMileage[selectedTab].processed_data && calculatedMileage[selectedTab].processed_data.table && Object.keys(calculatedMileage[selectedTab].processed_data.table).length > 0) ?

                                <TableView
                                    partnerCode={partnerCode}
                                    cabinClass={cabinClass}
                                    onChangeList={this.onChangeList}
                                    rootState={this.props.rootState}
                                    getBookingClassByCabinclassName={this.props.getBookingClassByCabinClass} /> :

                                <div className="col-md-12">

                                    <Custommessage type="warning" message={[t('mileage_calculator.nodata')]} />
                                </div>
                        }{
                            calculatedMileage && calculatedMileage[selectedTab] && calculatedMileage[selectedTab].processed_data && calculatedMileage[selectedTab].processed_data.chart && Object.keys(calculatedMileage[selectedTab].processed_data.chart).length > 0 &&
                            <ChartView
                                cabinClass={cabinClass}
                                tabName={this.props.rootState.selectedTab}
                            />
                        }
                    </div>
                }

            </div>
        )
    }
}


function mapStateToProps(state) {
    return {
        calculatedMileage: state.mileageCalculatorReducer,
        accountSummary: state.accountSummaryReducer.accountSummary,
        defaultConfig: state.configurationReducer.default,
        mileageCalculatorConfig: state.configurationReducer[CONFIG_SECTION_MILEAGECALCULATOR]
    }
}

const mapDispatchToProps = {
    calculateMileage
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(CalculatedMilesTab)));
