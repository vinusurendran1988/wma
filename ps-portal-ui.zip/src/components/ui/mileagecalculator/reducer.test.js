import { MILEAGE_CALCULATOR_SUCCESS } from './action';
import { mileageCalculatorReducer } from './reducer';
import {testReducer} from '../../common/testUtils';

describe('Reducer : MilageCalculator', () => {

    it('Should return default state', () => {
        const newState = testReducer(mileageCalculatorReducer,undefined, {});
        expect(newState).toEqual({});
    });

    it('Should return new state if receiving type', () => {
        const response = {
            statuscode: 200,
            statusMessage: "SUCCESS",
            object: {
                testData: "testData"
            }
        };
        const calculatedMileageList = {
            testData: "testData"
        };
        const newState = testReducer(
            mileageCalculatorReducer,
            undefined,
            {
                type: MILEAGE_CALCULATOR_SUCCESS,
                payload: response
            }
        );
        expect(newState).toEqual({ calculatedMileageList });
    });

});
