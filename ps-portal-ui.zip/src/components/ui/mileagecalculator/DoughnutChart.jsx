import React from 'react';
import { withTranslation } from 'react-i18next';
import MoneyBag from './MoneyBag';
import { numberWithCommas, withSuspense } from '../../common/utils';

/**
 * This is a doughnut chart component which draws the chart based on props received
 * @author Alan Kuriakose
 * 
 */
class DoughnutChart extends React.Component {

    constructor(props) {
        super(props);
        const createRefs = (params = []) => {
            params.forEach(param=>this[param] = React.createRef());
        }
        createRefs([
            'arc1Ref',
            'arc2Ref',
            'circle1Ref',
            'circle2Ref',
            'text1Ref',
            'text2Ref',
            'text3Ref',
            'text4Ref'
        ])
        this.state = {
            remainingMiles: 0,
            nextTier: null
        }
    }

    componentDidMount() {
        this.drawChart();
    }

    componentDidUpdate(prevProps) {
        if(['achieved', 'currentTier', 'newGain'].find(key=>prevProps[key] !== this.props[key])) {
            this.drawChart();
        }
    }

    /**
     * Function to generate path for arc in svg
     * @author Alan Kuriakose
     * @param {integer} x - center x axis
     * @param {integer} y - center y axis
     * @param {integer} radius - radius
     * @param {integer} startAngle - start angle in degrees
     * @param {integer} endAngle - end angle in degrees
     */
    describeArc(x, y, radius, startAngle, endAngle) {

        const start = this.polarToCartesian(x, y, radius, endAngle);
        const end = this.polarToCartesian(x, y, radius, startAngle);

        const largeArcFlag = endAngle - startAngle <= 180 ? "0" : "1";

        const d = [
            "M", start.x, start.y,
            "A", radius, radius, 0, largeArcFlag, 0, end.x, end.y
        ].join(" ");

        return d;
    }

    /**
     * Function to convert polar coordinates to rectangular coordinates
     * @author Alan Kuriakose
     * @param {integer} centerX - center x axis
     * @param {integer} centerY - center y axis
     * @param {integer} radius - radius
     * @param {integer} angleInDegrees - angle in degrees
     */
    polarToCartesian(centerX, centerY, radius, angleInDegrees) {
        const angleInRadians = (angleInDegrees - 90) * Math.PI / 180.0;

        return {
            x: centerX + (radius * Math.cos(angleInRadians)),
            y: centerY + (radius * Math.sin(angleInRadians))
        };
    }

    /**
     * Function to draw the chart
     * @author Alan Kuriakose
     */
    drawChart() {
        const { colors, tierNames, pointLimits } = this.props;
        try {
            const cx = 76;
            const cy = 76;
            const r = 68;
            const { achieved, currentTier, newGain } = this.props;
            const totalGain = achieved+newGain;
            const tierIndex = tierNames.indexOf(currentTier);
            let targetTierIndex = tierIndex + 1;
            let target = pointLimits[targetTierIndex] || totalGain;
            let color = colors[currentTier];
            if(totalGain > target) {
                color = colors[tierNames[targetTierIndex]] || colors.slice(-1)[0];
                targetTierIndex += 1;
                target = pointLimits[targetTierIndex] || totalGain;
            }
            const configureCircles = (cx, cy, r, circle) => {
                circle.setAttribute('cx', cx);
                circle.setAttribute('cy', cy)
                circle.setAttribute('r', r);
            }
            configureCircles(cx, cy, r, this.circle1Ref.current);
            configureCircles(cx, cy, 55, this.circle2Ref.current);
            const configureText = (text, params={}) => {
                Object.keys(params).forEach(key=>{
                    text.setAttribute(key, params[key]);
                })
            }
            configureText(this.text1Ref.current, {
                x:cx,
                y:90
            })
            configureText(this.text2Ref.current, {
                x: cx,
                y: 107
            })
            this.circle1Ref.current.setAttribute('stroke', color);
            this.circle2Ref.current.setAttribute('fill', color);
            const arc1Angle = newGain*360/target;
            const path1 = this.describeArc(cx, cy, r, 0, arc1Angle);
            this.arc1Ref.current.setAttribute('d', path1);
            const needToAchive = target-totalGain
            const arc2Angle = arc1Angle+(needToAchive<0?0:needToAchive)*360/target;
            const path2 = this.describeArc(cx, cy, r, arc1Angle, arc2Angle);
            this.arc2Ref.current.setAttribute('d', path2);
            this.setState({
                remainingMiles: (needToAchive<0?0:needToAchive),
                nextTier: tierNames[targetTierIndex]
            })
        } catch(error) {
            console.log("error: ", error)
        }
    }

    render() {
        const { achieved, newGain, t } = this.props;
        const { remainingMiles, nextTier } = this.state;
        return(
            <div>
                <svg width="221" height="151">
                    <circle strokeWidth="14" fill="none" ref={this.circle1Ref} />
                    <circle ref={this.circle2Ref} />
                    <g transform={`translate(66,47)`}>
                        <MoneyBag data-test="MoneyBagComponent" />
                    </g>
                    <text ref={this.text1Ref} stroke="white" textAnchor="middle" fontSize="12" fontWeight="200">{t('mileage_calculator.earnMiles.your_miles')}</text>
                    <text ref={this.text2Ref} textAnchor="middle" fontSize="12"  stroke="white" fontWeight="200">{numberWithCommas(achieved)}</text>
                    <path ref={this.arc1Ref} fill="none" strokeWidth="14"  stroke="#1fadaf"></path>
                    <path ref={this.arc2Ref} strokeWidth="14" stroke="#08273c" fill="none"></path>
                    <text stroke="#1fadaf" ref={this.text3Ref} x="140" y="10" fontSize="12" fontWeight="200">{t('mileage_calculator.earnMiles.you_earn')}:</text>
                    <text stroke="#1fadaf" x="140" y="24" fontSize="12" fontWeight="200">
                        <tspan fontWeight="bold">{numberWithCommas(achieved+newGain)}</tspan> {t('mileage_calculator.earnMiles.miles')}
                    </text>
                </svg>
                { nextTier &&
                    <div style={{width: '151px'}} className="text-center">
                        <b>{numberWithCommas(remainingMiles)}</b> miles to <b>{nextTier}</b> Tier
                    </div>
                }
            </div>
        )
    }
}

DoughnutChart.defaultProps = {
    currentTier: 'Blue',
    achieved: 0,
    newGain: 0
}


export default withSuspense()(withTranslation()(DoughnutChart));