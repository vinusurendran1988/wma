export const createEarnMilesResponse = (data, pageConfig, currentMiles) =>{
    const payload = {
        rowData: {
            api: data
        },
        processed_data: {
            table: {},
            chart: {}
        }
    }
    data.flightAttributePointDetails.map(flightAttributePointDetail => {
        flightAttributePointDetail.pointCreditDetails.map(pointCreditDetail => {
            const pointsToBeAdded = pageConfig.pointTypesToBeAddedInResult.find(e=>e.flightPointType == pointCreditDetail.pointType)
            if (pageConfig.pointTypesToBeAddedInResult && pointsToBeAdded) {
                // Data population for the list view.
                if (payload.processed_data.table[flightAttributePointDetail.cabinClass]) {
                    payload.processed_data.table[flightAttributePointDetail.cabinClass].points =
                        parseInt(payload.processed_data.table[flightAttributePointDetail.cabinClass].points) + pointCreditDetail.points
                } else {
                    payload.processed_data.table[flightAttributePointDetail.cabinClass] = {
                        "points": pointCreditDetail.points
                    }
                }

                //Data population for the chart view.
                const calculatedMiles = payload.processed_data.table[flightAttributePointDetail.cabinClass].points
                payload.processed_data.chart[flightAttributePointDetail.cabinClass] = {
                    currentMiles,
                    calculatedMiles,
                    balanceMiles: currentMiles+calculatedMiles
                    
                }

            }
        })
    })
    return payload
}

export const createUseMilesResponse = (data, cabinClass, responsePayload, currentMiles) =>{
    if(data.reward){
        responsePayload.rowData.api.push(data.reward[0]) //handleMe: If multiple rewards are returned from burn api
        responsePayload.processed_data.table[cabinClass] = {
            "points": data.reward[0].rewardPricingDetail.rewardPoints, //handleMe: If multiple rewards are returned from burn api
            "requiredPoints": currentMiles
        }
        const calculatedMiles = responsePayload.processed_data.table[cabinClass].points
        responsePayload.processed_data.chart[cabinClass] = {
            currentMiles,
            calculatedMiles,
            balanceMiles: currentMiles-calculatedMiles
        }
    }
    return responsePayload
}

export const createUpgradeUsingMilesResponse = (data, cabinClass, responsePayload, upgradeTo, requiredPoints) => {
    if(data.reward){
        responsePayload.rowData.api.push(data.reward[0]) //handleMe: If multiple rewards are returned from burn api
        responsePayload.unprocessed_data[cabinClass] = {
            "points": data.reward[0].rewardPricingDetail.rewardPoints //handleMe: If multiple rewards are returned from burn api
        }
    }
    if(responsePayload.rowData.api.length == 2){
        const { unprocessed_data } = responsePayload
        const newTable = {}
        let points = unprocessed_data[upgradeTo].points
        Object.keys(unprocessed_data).map((key, idx)=>{
            if(key != upgradeTo){
                points -= unprocessed_data[key].points
            } 
        })
        newTable[upgradeTo] = {
            points,
            requiredPoints
        }
        responsePayload.processed_data.table = newTable
        responsePayload.processed_data.chart[upgradeTo] = {
            currentMiles: requiredPoints,
            calculatedMiles: newTable[upgradeTo].points,
            balanceMiles: requiredPoints-newTable[upgradeTo].points
        }
        
    }
    return responsePayload
}