import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { withSuspense, getDefaultFormattedDate, getCurrentDate, getFormattedDate } from '../../common/utils';
import { connect } from 'react-redux';
import AutoCompleteField from '../../common/components/AutocompleteField';
import {
    fetchMasterData,
    fetchConfiguration,
    fetchAccountSummary
} from '../../common/middleware/redux/commonAction';
import {
    AIRPORT,
    CONFIG_SECTION_DEFAULT,
    CONFIG_SECTION_MILEAGECALCULATOR,
    DD_MMM_YYYY
} from '../../common/utils/Constants';
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';
import { TAB_EARN_MILES, TAB_USE_MILES, TAB_UPGRADE_MILES, CALCULATE_BTN } from './Constants';
import CalculatedMilesTab from './CalculatedMilesTab';
import { calculateMileage, clearExisitingData } from './action'
import { getItemFromBrowserStorage, BROWSER_STORAGE_KEY_COMPANY_CODE, BROWSER_STORAGE_KEY_PROGRAM_CODE, BROWSER_STORAGE_KEY_MEMBERSHIP_NO, BROWSER_STORAGE_KEY_BOOK, BROWSER_STORAGE_TYPE_SESSION, removeItemFromBrowserStorage } from '../../common/utils/storage.utils';
import CustomMessage from '../../common/components/custommessage'

/**
 * MileageCalculator class.
 * @description To calculate the miles for EARN, BURN, UPGRADE
 * @author Somdas M
 */
class MileageCalculator extends Component {
    constructor() {
        super();
        this.state = {
            cabinClasses: [],
            airportsList: [],
            isCalculateBtnClicked: false,
            isRoundTrip: false,
            selectedTab: TAB_EARN_MILES,
            hasInputChanged: false,
            data:{
                partnerCode: "",
                travelDate: getCurrentDate(DD_MMM_YYYY),
                returnDate: null,
                fromAirport: {
                    name: "",
                    value: ""
                },
                toAirport: {
                    name: "",
                    value: ""
                },
                cabinClass: undefined
            },
            isTabDisabled: false,
            errors: [],
            loading: false,
            masterApiCall: false
        }
        this.calculate = this.calculate.bind(this)
        // this.updateState = this.updateState.bind(this)
        this.getBookingClassByCabinClass = this.getBookingClassByCabinClass.bind(this)
        this.changeTab = this.changeTab.bind(this)
    }

    componentDidMount() {
        const { airports, defaultConfig, masterEntityLookup } = this.props
        this.props.setPageInfo(this.props, {config: this.props.mileageCalculatorConfig, confSection: CONFIG_SECTION_MILEAGECALCULATOR})

        // Used to populate the booking screen, if redirect from mileagecalculator screen
        if(getItemFromBrowserStorage(BROWSER_STORAGE_KEY_BOOK, BROWSER_STORAGE_TYPE_SESSION)){
            removeItemFromBrowserStorage(BROWSER_STORAGE_KEY_BOOK, BROWSER_STORAGE_TYPE_SESSION)
        }

        //To populate the origin and destination fields
        if (!airports.length && masterEntityLookup && Object.keys(masterEntityLookup).length) { this.props.fetchMasterData(AIRPORT, masterEntityLookup) }
        const config = getCurrentProgramFromDefaultConfig(defaultConfig)
        if (config) {
            const partnerCode = config.data.partners[0].value
            let  { data } = this.state
            data["partnerCode"] =  partnerCode
            this.setState({
                data,
                cabinClasses: config.data.cabinClasses[config.data.partners[0].value]
            })
        }
        //if (!this.props.accountSummaryConfig) { this.props.fetchConfiguration(CONFIG_SECTION_ACCOUNT_SUMMARY) }
        if (!this.props.accountSummary) {
            this.props.fetchAccountSummary()
        }
    }

    componentDidUpdate(prevProps, prevState) {
        const newDataState = {}
        let cabinClasses = []

        // To select a 'Travel Class' by default
        if ((prevState.cabinClasses !== this.state.cabinClasses) && this.state.cabinClasses.length > 0) {
            newDataState["cabinClass"] = this.state.cabinClasses[0].cabinClassCode
        }
        //Loads the list of cabinClasses and the partnerCode
        if (JSON.stringify(this.props.defaultConfig) != JSON.stringify(prevProps.defaultConfig) &&
            !this.state.data.partnerCode) {
            const config = getCurrentProgramFromDefaultConfig(this.props.defaultConfig)
            if(config) {
                newDataState["partnerCode"] = config.data.partners[0].value
                cabinClasses = config.data.cabinClasses[newDataState.partnerCode]
            }
        }
        if (Object.keys(newDataState).length > 0){
            let { data } = this.state
            Object.keys(newDataState).forEach((dataValue)=>{
                data[dataValue] = newDataState[dataValue]
            })
            this.setState(data)
        }

        const updatedState = {}
        const { airports, masterEntityLookup } = this.props
        if (!this.state.masterApiCall && !airports.length && masterEntityLookup && Object.keys(masterEntityLookup).length) {
            this.props.fetchMasterData(AIRPORT, masterEntityLookup)
            updatedState["masterApiCall"] = true
        }
        if(cabinClasses.length > 0 ) updatedState["cabinClasses"] = cabinClasses
        if(prevProps.airports != this.props.airports || (this.props.airports.length>0 && this.state.airportsList.length ==0)){
            const airportsList = this.props.airports.map(obj => {
                return {
                    name: obj.AirportName,
                    value: obj.AirportCode
                }
            })
            updatedState["airportsList"] = airportsList
        }
        if(prevProps.error != this.props.error){
            updatedState["loading"] = false
            updatedState["errors"] = this.props.error
        }
        if(this.state.loading &&
            ((this.state.selectedTab!=TAB_UPGRADE_MILES &&
                this.props.calculatedMileageList[this.state.selectedTab] &&
                this.props.calculatedMileageList[this.state.selectedTab].rowData) ||
                (this.state.selectedTab==TAB_UPGRADE_MILES &&
                    this.props.calculatedMileageList[this.state.selectedTab] &&
                    this.props.calculatedMileageList[this.state.selectedTab].rowData &&
                    this.props.calculatedMileageList[this.state.selectedTab].rowData.api &&
                    this.props.calculatedMileageList[this.state.selectedTab].rowData.api.length>1))){
            updatedState["loading"] = false
        }
        if(Object.keys(updatedState).length>0){
            this.setState(updatedState)
        }
    }

    // The input fileds are stored inside 'data' in state
    handleInputChange(fieldName, value){
        let { data, isTabDisabled } = this.state
        data[fieldName] = value
        if(fieldName == "cabinClass"){
            isTabDisabled = this.checkIfTabDisabled()
        }
        this.setState({data, isCalculateBtnClicked:false, isTabDisabled, errors:[]})
    }

    /**
     * Method to create the request payload based on the tab chosen.
     * @param {*} tab The selected tab name.
     * @author Somdas M
     */
    createRequestPayload(tab, cabinClass){
        const payload = {
            "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
            "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
            "membershipNumber": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
            "partnerCode": (this.state.data && this.state.data.partnerCode)?this.state.data.partnerCode:""
        }
        switch (tab) {
            case TAB_EARN_MILES:
                payload["businessType"] = this.props.mileageCalculatorConfig.ui[tab].businessType
                payload["flightAttributes"] = this.populateFlightAttributes(payload)
                return payload
            case TAB_USE_MILES:
            case TAB_UPGRADE_MILES:
                const { defaults } = this.props.mileageCalculatorConfig
                const { data } = this.state
                payload["origin"] = data.fromAirport.value
                payload["destination"] = data.toAirport.value
                payload["carrierCode"] = data.partnerCode
                payload["rewardCode"] = defaults.rewardCode
                payload["rewardGroup"] = defaults.rewardGroup
                payload["cabinClass"] = cabinClass
                //payload["activityDate"] = getCurrentDate()
                payload["isRoundTripPermitted"] = false
                payload["isRetrieveregiondetail"] = true
                payload["pageNumber"] = 1
                payload["absoluteIndex"] =  1
                return payload
        }
    }

    /**
     * Method to find the booking class.
     * Retrieves the 'bookingClass' from the default config having the respective cabinClassCode
     * @param {*} cabinClassCode The cabin class code
     */
    getBookingClassByCabinClass(cabinClassCode) {
        const { defaultConfig, mileageCalculatorConfig } = this.props
        const companyCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE)
        const programCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE)
        if(defaultConfig  &&
            defaultConfig.companyCode === companyCode) {
            const partnerCode = defaultConfig.programs
                .find(obj => (obj.programCode == programCode))
                .data.partners[0].value;
            let configuredBookingClass = defaultConfig.programs.find(obj => (obj.programCode == programCode))
                .data.cabinClassBookingClassMapping[partnerCode].find(mapping => { return mapping.cabinClass == cabinClassCode });
            if (configuredBookingClass) {
                return configuredBookingClass.bookingClass;
            }
        }
        return mileageCalculatorConfig.defaults.bookingClass
    }

    /**
     * Method to populate flight attributes to the earnmiles payload.
     */
    populateFlightAttributes() {
        const { defaultConfig } = this.props
        const { partnerCode } = this.state.data
        const companyCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE)
        const programCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE)
        let flightAttributeArray = [];
        if (defaultConfig && defaultConfig.companyCode === companyCode) {
            defaultConfig.programs.find(obj => (obj.programCode == programCode))
                .data.cabinClasses[partnerCode].forEach(cabin => {
                    let oneWayFlightAttribute = {
                        carrierCode: this.state.data.partnerCode,
                        flightDate: getDefaultFormattedDate(this.state.data.travelDate),
                        cabinClass: cabin.cabinClassCode,
                        bookingClass: this.getBookingClassByCabinClass(cabin.cabinClassCode),
                        originAirport: this.state.data.fromAirport.value,
                        destinationAirport: this.state.data.toAirport.value
                    }
                    flightAttributeArray.push(oneWayFlightAttribute);

                    // handleMe: Uncomment below line if roundTrip is enabled
                    // if (this.state.isRoundTrip && this.state.data.returnDate) {
                    //     let returnFlightAttribute = {
                    //         carrierCode: this.state.data.partnerCode,
                    //         flightDate: getDefaultFormattedDate(this.state.data.returnDate),
                    //         cabinClass: cabin.cabinClassCode,
                    //         bookingClass: this.getBookingClassByCabinClass(cabin.cabinClassCode),
                    //         originAirport: this.state.data.toAirport.value,
                    //         destinationAirport: this.state.data.fromAirport.value
                    //     }
                    //     flightAttributeArray.push(returnFlightAttribute)
                    // }
                });
        }
        return flightAttributeArray;
    }

    /**
     * Method to invoke the api to find the calculated mileage.
     * Based on the selected tab, this method creates the respective payload and invokes the action
     * @param {*} tabName The selected tab
     * @author Somdas M
     */
    fetchApiResult(tabName) {
        let payload = {}
        if (tabName && this.canInvokeApi(tabName)) {
            this.setState({
                loading: true
            })
            const { mileageCalculatorConfig } = this.props
            const { cabinClasses } = this.state
            const { accountSummary } = this.props
            const attributeCode = this.props.mileageCalculatorConfig.defaults.attributeCode
            let currentPoints = 0
            if (accountSummary && accountSummary.pointDetails) {
                accountSummary.pointDetails.map(pointDetail => {
                    const pointTypeToBeAdded = mileageCalculatorConfig.ui[tabName].pointTypesToBeAddedInResult.find(e => e.type == pointDetail.pointType)
                    if (pointTypeToBeAdded) {
                        currentPoints += pointDetail.points
                    }
                })
            }
            switch (tabName) {
                case TAB_EARN_MILES:
                    payload = this.createRequestPayload(tabName)
                    return this.props.calculateMileage({ object: payload }, tabName, mileageCalculatorConfig.ui[TAB_EARN_MILES], "", {}, currentPoints, "", CALCULATE_BTN)
                case TAB_USE_MILES:
                    const responsePayload = {
                        rowData: {
                            api: []
                        },
                        processed_data: {
                            table: {},
                            chart: {}
                        }
                    }
                    return cabinClasses.map(cabinClass => {
                        const { cabinClassCode } = cabinClass
                        payload = this.createRequestPayload(tabName, cabinClass.cabinClassCode)
                        payload["dynamicAttributes"] = [{
                            "attributeCode": attributeCode,
                            "attributeValue": cabinClass.cabinClassCode
                        }]
                        return this.props.calculateMileage({ object: payload }, tabName, mileageCalculatorConfig.ui[TAB_USE_MILES], cabinClassCode, responsePayload, currentPoints, "", CALCULATE_BTN)
                    })
                case TAB_UPGRADE_MILES:
                    const { data } = this.state
                    const { cabinClass } = data
                    const upgradePayload = {
                        rowData: {
                            api: []
                        },
                        processed_data: {
                            table: {},
                            chart: {}
                        },
                        unprocessed_data: {}
                    }
                    const currentCabinClass = cabinClasses.find(e => e.cabinClassCode == cabinClass)
                    const currentIndex = cabinClasses.indexOf(currentCabinClass)
                    payload = this.createRequestPayload(tabName, cabinClass.cabinClassCode)
                    if (currentIndex < cabinClasses.length - 1) {
                        payload["dynamicAttributes"] = [{
                            "attributeCode": attributeCode,
                            "attributeValue": cabinClasses[currentIndex].cabinClassCode
                        }]
                        this.props.calculateMileage({ object: payload }, tabName, mileageCalculatorConfig.ui[TAB_UPGRADE_MILES], cabinClasses[currentIndex].cabinClassCode, upgradePayload, currentPoints, cabinClasses[currentIndex + 1].cabinClassCode, CALCULATE_BTN).then(res=>{
                            payload["dynamicAttributes"] = [{
                                "attributeCode": attributeCode,
                                "attributeValue": cabinClasses[currentIndex+1].cabinClassCode
                            }]
                            return this.props.calculateMileage({ object: payload }, tabName, mileageCalculatorConfig.ui[TAB_UPGRADE_MILES], cabinClasses[currentIndex+1].cabinClassCode, upgradePayload, currentPoints, cabinClasses[currentIndex + 1].cabinClassCode, CALCULATE_BTN)
                        })
                    }
            }
        } else {
            const errors = [this.props.t('mileage_calculator.pleaseFillRequiredFields')]
            this.setState({
                errors
            })
        }

    }


    /**
     * Method to check if the required fields for the calculating the earnmiles are present.
     * Based on the output from this method, canInvokeApi decides whether to invoke the earnmiles api.
     * @author Somdas M
     */
    canInvokeApi(tabName) {
        if (tabName) {
            const { data, isRoundTrip } = this.state
            const { fromAirport, toAirport, travelDate, returnDate, partnerCode, cabinClass } = data
            if (travelDate && partnerCode && cabinClass &&
                fromAirport && fromAirport.name &&
                toAirport && toAirport.name) {
                if (!isRoundTrip || (isRoundTrip && returnDate)) {
                    return true
                }
            }
        }
        return false
    }

    /**
     * Method to trigger the api when the user clicks the 'calculate' button
     * @author Somdas M
     */
    calculate(){
        let { selectedTab } = this.state
        this.props.clearExisitingData(selectedTab)
        this.setState({
            isCalculateBtnClicked: true
        })
        this.fetchApiResult(selectedTab)
    }

    changeTab(selectedTab){
        this.setState({
            selectedTab,
            errors: []
        }, ()=>{
            this.calculate()
        })
    }

    checkIfTabDisabled(){
        const { cabinClasses, data, selectedTab } = this.state
        const { cabinClass } = data
        if(cabinClass && cabinClasses.length>1 && cabinClasses[cabinClasses.length-1].cabinClassCode == cabinClass){
            return true
        }
        return false
    }

    render() {

        const { t, mileageCalculatorConfig } = this.props;
        const { cabinClasses, isRoundTrip, data, selectedTab, isCalculateBtnClicked, isTabDisabled, airportsList, errors } = this.state
        const {
            travelDate,
            fromAirport,
            toAirport,
            cabinClass,
            returnDate
        } = data
        let tabs = (mileageCalculatorConfig && mileageCalculatorConfig.ui && mileageCalculatorConfig.ui.tabs) ?
            mileageCalculatorConfig.ui.tabs : []
       
        return (
            <div className="col-lg-12">
                <h1>{t('mileage_calculator.title')}</h1>
                <p>{t('mileage_calculator.description')}</p>
                <div>{errors && <CustomMessage message={errors} type={"danger"} />}</div>
                <div>
                    <div className="form-row">

                        <div className="col-lg-3 col-md-6">
                            <div className="form-group">
                                <label htmlFor="f1">{t('mileage_calculator.from')}<span className="text-warning">*</span></label>
                                <AutoCompleteField
                                    list={airportsList.filter(e => e != toAirport)}
                                    inputId="fromAirport"
                                    placeholder={t('mileage_calculator.from_placeholder')}
                                    handleSelectEvent={(e) => this.handleInputChange("fromAirport", e)}
                                    selected={fromAirport}
                                    dataForTest="fromAirport"
                                    className={"txt"}
                                    disabled={airportsList.length == 0}
                                />
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <div className="form-group">
                                <label htmlFor="f2">{t('mileage_calculator.to')}<span className="text-warning">*</span></label> <div className="txt" id="f2">
                                    <AutoCompleteField
                                        list={airportsList.filter(e => e != fromAirport)}
                                        inputId="toAirport"
                                        placeholder={t('mileage_calculator.to_placeholder')}
                                        handleSelectEvent={(e) => this.handleInputChange("toAirport", e)}
                                        selected={toAirport}
                                        className=""
                                        dataForTest="toAirport"
                                        disabled={airportsList.length == 0}
                                    />
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6">
                            <div className="form-group">
                                <label htmlFor="f3">{selectedTab == TAB_UPGRADE_MILES ? t('mileage_calculator.upgradeUsingMiles.upgradeFrom') : t('mileage_calculator.travel_class')}</label>
                                <select id="f3" value={cabinClass} onChange={(e) => this.handleInputChange("cabinClass", e.target.value)} className="" id="f3" data-test="cabinClass">
                                    {
                                        cabinClasses.map((cabin, idx) => {
                                            if (selectedTab != TAB_UPGRADE_MILES || selectedTab == TAB_UPGRADE_MILES && idx + 1 < cabinClasses.length) {
                                                return <option key={cabin.cabinClassCode} value={cabin.cabinClassCode}>{cabin.cabinClassName}</option>
                                            }
                                        })
                                    }
                                </select>
                            </div>
                        </div>
                        <div className="col-lg-2 col-md-6  layout__buttons--nolabel">
                            <button type="button" className="btn btn-primary" onClick={() => { this.calculate() }} id={CALCULATE_BTN} data-test="btnProcecalculateBtnedTobuy">{t('mileage_calculator.calculate')}</button>
                        </div>

                    </div>
                    {isCalculateBtnClicked && this.canInvokeApi(selectedTab) &&
                        <div className="form-row" data-test="myTabs">
                            <div className="col-12">
                                <ul className="nav nav-tabs" id="myTab" role="tablist">
                                    {
                                        tabs &&
                                        tabs.map((tab) => {
                                            return (tab != TAB_UPGRADE_MILES || (tab == TAB_UPGRADE_MILES && !isTabDisabled)) && <li className="col nav-item" role="presentation" key={`tab_${tab}`}>
                                                <a className={"nav-link " + (selectedTab === tab ? "active" : "")} onClick={() => this.changeTab(tab)} id={tab} data-toggle="tab" href={`${tab}`} role="tab" aria-controls={`${tab}`} aria-selected="true" data-test={`tab_${tab}`}>
                                                    {t(`mileage_calculator.${tab}.title`)}</a> </li>
                                        })
                                    }
                                </ul>
                                <div className="tab-content" id="myTabContent">
                                    <CalculatedMilesTab
                                        rootState={this.state}
                                        getBookingClassByCabinclassName={this.getBookingClassByCabinClass}
                                        cabinClass={cabinClass}
                                    />
                                </div>
                            </div>
                        </div>
                    }
                </div>
            </div>
        )

        

        
    }
}

MileageCalculator.propTypes = {

};

MileageCalculator.defaultProps = {
    airports: []
};

const mapStateToProps = (state) => {
    return {
        calculatedMileageList: state.mileageCalculatorReducer,
        airports: state.masterData[AIRPORT],
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        error: state.commonErrorReducer.error,
        accountSummary: state.accountSummaryReducer.accountSummary,
        mileageCalculatorConfig: state.configurationReducer.mileagecalculator,
        masterEntityLookup: state.masterEntityDataReducer.masterEntityLookup
    }
}

const mapDispatchToProps = {
    fetchMasterData,
    fetchConfiguration,
    calculateMileage,
    fetchAccountSummary,
    clearExisitingData
}


export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(MileageCalculator)));
