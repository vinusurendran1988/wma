import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import { CONFIG_SECTION_PROFILE, PROGRAM_TYPE_CORPORATE } from '../../../components/common/utils/Constants';
import { NAVIGATE_MEMBER_DASHBOARD } from '../../../components/common/utils/urlConstants';
import {
    fetchConfiguration, resetError
} from '../../common/middleware/redux/commonAction';
import { CONTEXT_TAB, havePrivilege } from '../../common/privileges';
import { getCurrentPageUri, withSuspense } from '../../common/utils';
import { BROWSER_STORAGE_KEY_PROGRAM_TYPE, getItemFromBrowserStorage } from '../../common/utils/storage.utils';
import UpdateProfile from "../updateprofile";


/**
 * @name ProfileCompletion component.
 * @description When mandatory fields are not completed during enrollment,
 *  then user is redirected to this component on logging in 
 *
 * @author Amrutha
 */
class ProfileCompletion extends Component {
    constructor(props) {
        super(props)
        this.state = {

        }
    }
    componentDidMount() {
        const { profileData } = this.props
        this.props.setPageInfo(this.props, { config: this.props.config, confSection: CONFIG_SECTION_PROFILE })
        if (profileData) {
            this.redirectPage(profileData.object)
        }
    }

    componentDidUpdate(prevProps) {
        const { error, profileData } = this.props
        if (JSON.stringify(prevProps.profileData) != JSON.stringify(profileData) && profileData.object && 
            profileData.object.areMandatoryFieldsFilled) {
                this.redirectPage(profileData.object)
        }
    }

    redirectPage = (profileData) => {

        if (profileData.areMandatoryFieldsFilled) {
            window.location = `#${NAVIGATE_MEMBER_DASHBOARD}`

        }
    }
    render() {
        const { profileData, accountSummary, userPrivileges, t,corporateNominees } = this.props
        const programType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE)
        const userData = programType === PROGRAM_TYPE_CORPORATE ? corporateNominees : accountSummary
        if (userPrivileges && userData) {
            const privilegeCheckData = havePrivilege(
                { "url": getCurrentPageUri() },
                userData,
                CONTEXT_TAB,
                userPrivileges)
            return (
                <div>
                    <h1>{t('profileCompletion.updateProfile')}</h1>
                    {profileData && Object.keys(profileData).length > 0 &&
                        <UpdateProfile privilegeCheckData={privilegeCheckData} isProfileComplete={false} />}
                </div>
            );
        }else{
            return(<></>)
        }
    }
}

const mapStateToProps = (state) => {
    return {
        profileData: state.profileDataReducer.profileData,
        error: state.commonErrorReducer.error,
        config: state.configurationReducer[CONFIG_SECTION_PROFILE],
        accountSummary: state.accountSummaryReducer.accountSummary,
        userPrivileges: state.privilegesReducer.privileges,
        corporateNominees: state.retriveAccountNomineeReducer.corporateNominees

    }
}
const mapDispatchToProps = dispatch => {
    return {
        fetchConfiguration,
        resetError
    }
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(ProfileCompletion)));