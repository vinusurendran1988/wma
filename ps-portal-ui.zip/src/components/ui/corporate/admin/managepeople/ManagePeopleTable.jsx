import React from 'react';
import { withSuspense, toTitleCase } from '../../../../common/utils';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import {
    COLUMN_TYPE_ACTION,
    COLUMN_TYPE_NAME_WITH_TITLE
} from './Constants';
import { getItemFromBrowserStorage, BROWSER_STORAGE_KEY_EMAIL } from '../../../../common/utils/storage.utils';

class ManagePeopleTable extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
        }
        this.actionBodyTemplate = this.actionBodyTemplate.bind(this)
    }

    componentDidMount() {
        this.setState({
            pageSize: this.props.pageSize
        })
    }

    componentDidUpdate(prevProps) {
    }

    /**
     * Provides template for action buttons
     * @param {*} rowData 
     */
    actionBodyTemplate(rowData, props) {
        const { onClickEdit, onClickDelete } = this.props
        let buttonPanel = <span></span>
        if(getItemFromBrowserStorage(BROWSER_STORAGE_KEY_EMAIL) != rowData.emailAddress) {
            buttonPanel = <span className="travellerTabActionCol">
            <a
                onClick={(e) => {
                    e.preventDefault()
                    onClickEdit(rowData)
                }}
                className="actionBtn"
                role="button"
                data-toggle="modal"
                data-target="#exampleModal-edit">
                <i className="fa fa-pencil"
                    aria-hidden="true"></i>
            </a>
            <a className="actionBtn"
                onClick={(e) => {
                    e.preventDefault()
                    onClickDelete(rowData)
                }}
                role="button">
                <i className="fa fa-trash-o" aria-hidden="true">
                </i>
            </a>
        </span>
        }

        return (
            <React.Fragment>
                <span className="p-column-title">{props.header}</span>
                {buttonPanel}
            </React.Fragment>
        );
    }

    /**
     * Provides template for displaying name in title case:
     *      
     * Format:
     *      Title GivenName FamilyName 
     * @param {*} data 
     */
    customeNameBodyTemplate(data, props) {
        let name = ""
        if(props.customColumns) {
            props.customColumns.forEach(i=> name+=data[i]+" ")
        } else {
            name = `${data.givenName} ${data.familyName}`
        }
        data[props.field] = toTitleCase(name.trim())
        return (
            <React.Fragment>
                <span className="p-column-title">{props.header}</span>
                {data[props.field]}
            </React.Fragment>
        );
    }

    defaultColumnBodyTemplate(data, props) {
        return (
            <React.Fragment>
                <span className="p-column-title">{props.header}</span>
                {data[props.field]}
            </React.Fragment>
        );
    }

    /**
     * Populate contents for each column
     */
    populateColumns() {

        const { t, columnsToDisplay, i18Path, canEdit } = this.props
        return columnsToDisplay.map((column, index) => {
            if (column.type != COLUMN_TYPE_ACTION || (column.type == COLUMN_TYPE_ACTION && canEdit)) {
                let props = {
                    header: t(`${i18Path}.columnHeaders.${column.id}`),
                    sortable: true
                }

                switch (column.type) {
                    case COLUMN_TYPE_ACTION:
                        props.field = column.id
                        props.body = this.actionBodyTemplate
                        props.sortable = false
                        props.style = { width: '200px' }
                        break
                    case COLUMN_TYPE_NAME_WITH_TITLE:
                        props.field = column.id
                        props.body = this.customeNameBodyTemplate
                        props.customColumns = column.data
                        break
                    default:
                        props.field = column.id
                        props.body = this.defaultColumnBodyTemplate
                }

                return <Column
                    key={index}
                    {...props}
                />
            }
        })

    }

    render() {
        const { i18Path, pageSize, inputData, t, availablePageSizes } = this.props;
        return (
            <div className="datatable-responsive-demo">
                <div className="card">
                    <DataTable
                        paginator={true}
                        paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
                        rows={pageSize}
                        rowsPerPageOptions={availablePageSizes}
                        emptyMessage={t(`${i18Path}.emptyMessage`)}
                        value={inputData}
                        removableSort={true}
                        rowHover
                        scrollable={true}
                        className="p-datatable-responsive-demo table table-striped"
                    >
                        {this.populateColumns()}
                    </DataTable>
                </div>
            </div>
        );
    }
}

ManagePeopleTable.defaultProps = {
};

const mapStateToProps = (state) => {
    return {

    }
}

const mapDispatchToProps = {
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(ManagePeopleTable)));