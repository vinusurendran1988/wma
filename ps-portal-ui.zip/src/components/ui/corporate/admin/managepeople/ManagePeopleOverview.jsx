import React from 'react';
import { withSuspense, constructJsonPath, getCurrentPageUri } from '../../../../common/utils';
import { getValueFromPath, isDependentExists } from '../../../../common/utils/object.utils'
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import ManagePeopleTable from './ManagePeopleTable';
import {
    TAB_TRAVELLERS,
    TAB_ACCOUNT_USERS,
    REQUEST_TEMPLATE,
    POPUP_FUNCTION_ADD,
    POPUP_FUNCTION_EDIT,
    POPUP_FUNCTION_DELETE,
    PRIVILEGE_ATTRIBUTES_KEY_FULL_ACCESS,
    PRIVILEGE_ATTRIBUTES_KEY_LIMITED_ACCESS,
    CONFIG_LAYOUT_ELEMENT_TYPE_POPUP,
    PLACEHOLDER_CORPORATE_MEMBERSHIP_NUMBER,
    CONFIG_LAYOUT_ELEMENT_TYPE_TABLE
} from './Constants';
import {
    CONFIG_SECTION_NOMINEE,
    CONFIG_SECTION_TRAVELLER,
    CONFIG_SECTION_DEFAULT
} from '../../../../common/utils/Constants';
import {
    getItemFromBrowserStorage,
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
    BROWSER_STORAGE_KEY_EMAIL
} from '../../../../common/utils/storage.utils';
import {
    retrieveNominees,
    retrieveCustomer,
    addTraveller,
    addNominee,
    updateTraveller,
    updateNominee,
    deleteTraveller,
    deleteNominee
} from './action'
import { fetchConfiguration, setError, resetError } from '../../../../common/middleware/redux/commonAction';
import AddEditPopup from '../../../../common/components/addeditpopup/AddEditPopup';
import { findValueFromObjectByPath, setValueToObjectByPath } from '../../../../common/utils/object.utils';
import { getCurrentProgramFromDefaultConfig } from '../../../../common/utils/configurationFiles.utils';
import Popup from '../../../../common/components/popup/Popup';
import { POPUP_TYPE_CONFIRMATION, ID_SIMPLE_POPUP } from '../../../../common/components/popup/Constants';
import { havePrivilege, CONTEXT_TAB, FULL_ACCESS } from '../../../../common/privileges';
import { ID_CONFIRM_BUTTON } from '../../../../common/components/addeditpopup/Constants';

class ManagePeopleOverview extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            layout: undefined,
            popupLayout: {
                [TAB_TRAVELLERS]: {},
                [TAB_ACCOUNT_USERS]: {}
            },
            accountGroupType: undefined,
            nomineeListToDisplay: {
                [TAB_TRAVELLERS]: [],
                [TAB_ACCOUNT_USERS]: []
            },
            contextBasedConfigs: {
                [TAB_TRAVELLERS]: {},
                [TAB_ACCOUNT_USERS]: {}
            },
            isAddEditPopUpVisible: false,
            isDeletePopupVisible: false,
            popupFunction: undefined,
            requestForPopup: undefined,
            errorCodes: [],
            showWarningAndError: false,
            nomineePrivilegeDynamicAttributes: {
                full: [],
                limited: []
            }
        }
    }

    componentDidMount() {
        this.resetError();
        this.setTabSpecificConfig()
    }

    /**
     * Handling of updations when props or state are updated.
     * 
     * @param {*} prevProps 
     * @param {*} prevState 
     * 
     * @author Ajmal V Aliyar
     */
    componentDidUpdate(prevProps, prevState) {

        const {
            layout
        } = this.state
        let { nomineeListToDisplay } = this.state
        const {
            nomineeConfig,
            travellerConfig,
            tabId,
            nomineesResponse,
            customerResponse,
            addedTraveller,
            addedNominee,
            updatedTraveller,
            updatedNominee,
            deletedTraveller,
            deletedNominee,
            onSuccessMessage,
            i18Path
        } = this.props

        let i18MessagePath = `${i18Path}.messages.`

        //When tab is changed
        if (prevProps.tabId !== tabId) {
            this.setTabSpecificConfig()
        }

        /**
         * layout is changed when tab is changed. Do the following
         *  1.  update the layout of add and edit popups
         *  2.  Update list of people if needed
         */
        if (prevState.layout !== layout) {
            this.setPopupLayout()
            if (!nomineeListToDisplay[tabId].length) {
                this.populateNomineeList()
            }
        }

        //When receiving the configuration of a specific tab via API call
        if (
            prevProps.nomineeConfig !== nomineeConfig ||
            prevProps.travellerConfig !== travellerConfig
        ) {
            this.setTabSpecificConfig()
        }

        // When response is received from retrieveNominee API
        if (prevProps.nomineesResponse !== nomineesResponse) {
            nomineeListToDisplay[tabId] = nomineesResponse.nomineeDetails
            this.setState({
                nomineeListToDisplay
            })
        }

        /**
         * When the details of a selected accountuser or traveller 
         * is receieved when edit is clicked
         * via retrieveCustomer API
         */
        if (prevProps.customerResponse !== customerResponse) {
            this.generateUpdateRequest()
        }

        if (prevProps.addedTraveller !== addedTraveller) {
            this.onAddEditPopupHide()
            this.populateNomineeList()
            onSuccessMessage([i18MessagePath + 'success_added'])
            window.scrollTo(0, 0);
        }

        if (prevProps.addedNominee !== addedNominee) {
            this.onAddEditPopupHide()
            this.populateNomineeList()
            onSuccessMessage([i18MessagePath + 'success_added'])
            window.scrollTo(0, 0);
        }

        if (prevProps.updatedTraveller !== updatedTraveller) {
            this.onAddEditPopupHide()
            this.populateNomineeList()
            onSuccessMessage([i18MessagePath + 'success_updated'])
            window.scrollTo(0, 0);
        }

        if (prevProps.updatedNominee !== updatedNominee) {
            this.onAddEditPopupHide()
            this.populateNomineeList()
            onSuccessMessage([i18MessagePath + 'success_updated'])
            window.scrollTo(0, 0);
        }

        if (prevProps.deletedTraveller !== deletedTraveller) {
            this.populateNomineeList()
            this.onDeletePopupHide()
            onSuccessMessage([i18MessagePath + 'success_deleted'])
            window.scrollTo(0, 0);
        }

        if (prevProps.deletedNominee !== deletedNominee) {
            this.populateNomineeList()
            this.onDeletePopupHide()
            onSuccessMessage([i18MessagePath + 'success_deleted'])
            window.scrollTo(0, 0);
        }
    }

    resetError() {
        this.props.onSuccessMessage([])
        this.props.resetError()
    }

    /**
     * When a tab is selected:
     * 
     *      -   If the corresponding configuration of that page is available:
     *              1.  accountGroupType from that config is set to state
     *              2.  layout from that config is set to state
     *      -   API call is made to fetch the corresponding config
     * 
     * @author Ajmal V Aliyar
     */
    setTabSpecificConfig() {

        const { tabId, travellerConfig, nomineeConfig } = this.props
        let { layout, accountGroupType } = this.state
        let saveToStateObject = {
            layout: layout,
            accountGroupType: accountGroupType
        }
        if (tabId == TAB_TRAVELLERS) {
            if (travellerConfig) {
                saveToStateObject.accountGroupType = travellerConfig.accountGroupTypeNomineeStatusMapping &&
                    travellerConfig.accountGroupTypeNomineeStatusMapping.length &&
                    travellerConfig.accountGroupTypeNomineeStatusMapping[0].accountGroupType
                saveToStateObject.layout = travellerConfig.ui.layout
            } else {
                this.props.fetchConfiguration(CONFIG_SECTION_TRAVELLER)
            }
        } else if (tabId == TAB_ACCOUNT_USERS) {
            if (nomineeConfig) {
                saveToStateObject.accountGroupType = nomineeConfig.accountGroupTypeNomineeStatusMapping &&
                    nomineeConfig.accountGroupTypeNomineeStatusMapping.length &&
                    nomineeConfig.accountGroupTypeNomineeStatusMapping[0].accountGroupType
                saveToStateObject.layout = nomineeConfig.ui.layout
                const fullAccessPrivilegeAttributes = this.convertDynamicAttributesArrayToUsableStructure(nomineeConfig.dynamicAttributes[PRIVILEGE_ATTRIBUTES_KEY_FULL_ACCESS])
                const limitedAccessPrivilegeAttributes = this.convertDynamicAttributesArrayToUsableStructure(nomineeConfig.dynamicAttributes[PRIVILEGE_ATTRIBUTES_KEY_LIMITED_ACCESS])
                saveToStateObject = {
                    ...saveToStateObject,
                    nomineePrivilegeDynamicAttributes: {
                        full: fullAccessPrivilegeAttributes,
                        limited: limitedAccessPrivilegeAttributes
                    }
                }
            } else {
                this.props.fetchConfiguration(CONFIG_SECTION_NOMINEE)
            }
        }
        this.setState({ ...saveToStateObject })
    }

    /**
     * Invokes API call to retrieve nominees so that it can be displayed in table.
     * 
     * @author Ajmal V Aliyar
     */
    populateNomineeList() {
        const { accountGroupType } = this.state
        const { tabId } = this.props
        if (accountGroupType) {
            let requestPayload = JSON.parse(JSON.stringify(REQUEST_TEMPLATE.RETRIEVE_NOMINEES.object))
            requestPayload.companyCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE)
            requestPayload.programCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE)
            requestPayload.membershipNumber = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)


            this.props.retrieveNominees({
                object: requestPayload
            }, tabId)
        }
    }

    setPopupLayout() {
        const { layout } = this.state
        let { popupLayout, contextBasedConfigs } = this.state
        const { tabId } = this.props
        if (layout && layout.elements) {
            if (
                layout.elements.addModalInfo &&
                layout.elements.addModalInfo.type == CONFIG_LAYOUT_ELEMENT_TYPE_POPUP &&
                layout.elements.addModalInfo.ui &&
                layout.elements.addModalInfo.ui.layout
            ) {
                popupLayout[tabId][POPUP_FUNCTION_ADD] = layout.elements.addModalInfo.ui.layout
                contextBasedConfigs[tabId][POPUP_FUNCTION_ADD] = layout.elements.addModalInfo
            }
            if (
                layout.elements.updateModalInfo &&
                layout.elements.updateModalInfo.type == CONFIG_LAYOUT_ELEMENT_TYPE_POPUP &&
                layout.elements.updateModalInfo.ui &&
                layout.elements.updateModalInfo.ui.layout
            ) {
                popupLayout[tabId][POPUP_FUNCTION_EDIT] = layout.elements.updateModalInfo.ui.layout
                contextBasedConfigs[tabId][POPUP_FUNCTION_EDIT] = layout.elements.updateModalInfo
            }
        }

        this.setState({ popupLayout })
    }

    preProcessData(data) {
        const cUser = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_EMAIL)
        let index = -1
        data.some((x, i) => {
            if(x.emailAddress === cUser) {
                index = i
                return true
            }
        });
        if(index > -1) {
            data.unshift(data.splice(index, 1)[0])
        }
        return data
    }

    /**
     * Displays elements according to the received {elementName}.
     * @param {*} elementName element from ui configuration
     * 
     * NB: Only elements with type 'table' is displayed at the moment.
     * 
     * @author Ajmal V Aliyar
     */
    displayElement(elementName, key, canEdit) {
        const { layout, nomineeListToDisplay } = this.state
        const { i18Path, tabId } = this.props
        let elementToDisplay = undefined
        if (
            elementName &&
            layout &&
            layout.elements &&
            layout.elements[elementName]
        ) {
            elementToDisplay = layout.elements[elementName]
            if (elementToDisplay.type == CONFIG_LAYOUT_ELEMENT_TYPE_TABLE) {
                return <ManagePeopleTable
                    key={key}
                    canEdit={canEdit}
                    i18Path={`${i18Path}.table`}
                    inputData={
                        (nomineeListToDisplay[tabId].length)
                            ? this.preProcessData(nomineeListToDisplay[tabId])
                            : []
                    }
                    columnsToDisplay={
                        (
                            elementToDisplay &&
                            elementToDisplay.columns &&
                            elementToDisplay.columns.length
                        )
                            ? elementToDisplay.columns
                            : []
                    }
                    onClickEdit={(input) => this.handleClickEdit(input)}
                    onClickDelete={(input) => this.handleClickDelete(input)}
                    pageSize={elementToDisplay.defaultPageSize ? elementToDisplay.defaultPageSize : 10}
                    availablePageSizes={elementToDisplay.availablePageSizes ? elementToDisplay.availablePageSizes : []}
                />
            }
        }
    }

    /**
     * Handling of click event of Add button.
     * @param {*} input 
     * 
     * @author Ajmal V Aliyar
     */
    handleClickAdd() {
        this.resetError();

        const { tabId } = this.props
        const popupFunction = POPUP_FUNCTION_ADD
        let requestForPopup = JSON.parse(JSON.stringify(REQUEST_TEMPLATE[tabId][popupFunction]))
        this.setAdditionalMappingsToRequest(requestForPopup, popupFunction)

        /**
         * It is expected that the function setAdditionalMappingsToRequest 
         * have set one object(corporate info dynamic attribute) to the 
         * customerDynamicAttribute array.
         * 
         * The attributeValue of that dynamic attribute is of the format:
         *      
         *      Corporate|PRG15|${corporateMembershipNumber}
         * 
         * The following code will 
         *      replace ${corporateMembershipNumber} 
         *      with membership number from local storage
         */
        if (
            requestForPopup &&
            requestForPopup.object &&
            requestForPopup.object.nomineeDetails &&
            requestForPopup.object.nomineeDetails.length &&
            requestForPopup.object.nomineeDetails[0].customerDynamicAttribute &&
            requestForPopup.object.nomineeDetails[0].customerDynamicAttribute.length &&
            requestForPopup.object.nomineeDetails[0].customerDynamicAttribute[0] &&
            requestForPopup.object.nomineeDetails[0].customerDynamicAttribute[0].attributeValue
        ) {
            try {
                requestForPopup.object.nomineeDetails[0].customerDynamicAttribute[0].attributeValue = requestForPopup.object.nomineeDetails[0].customerDynamicAttribute[0].attributeValue.replace(
                    PLACEHOLDER_CORPORATE_MEMBERSHIP_NUMBER,
                    getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)
                )
            } catch (err) {
                console.error("Error ocurred while replacing ${corporateMembershipNumber} : ", err);
            }
        } else {
            console.warn("Could not find the location in request to replace ${corporateMembershipNumber} dynamically")
        }
        this.setState({
            popupFunction,
            requestForPopup,
            isAddEditPopUpVisible: true
        })
    }

    /**
     * Handling of click event of Edit button from table.
     * @param {*} input 
     * 
     * @author Ajmal V Aliyar
     */
    handleClickEdit(input) {
        this.resetError();
        this.setState({ popupFunction: POPUP_FUNCTION_EDIT })
        let requestPayload = JSON.parse(JSON.stringify(REQUEST_TEMPLATE.RETRIEVE_CUSTOMER.object))
        requestPayload.companyCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE)
        requestPayload.customerNumber = input.customerNumber
        if (input && input.customerNumber) {
            this.props.retrieveCustomer({
                object: requestPayload
            })
        } else {
            console.error("Retrieve customer did not initiate because no cusotmerNumber found for editing");
        }
    }

    /**
     * When popup for delete confirmation is closed
     * 
     * @author Ajmal V Aliyar
     */
    onDeletePopupHide() {
        this.setState({
            isDeletePopupVisible: false,
            requestForPopup: undefined,
            popupFunction: undefined
        })
    }

    /**
     * When the user clicks the Delete confirmation.
     * 
     * @author Ajmal V Aliyar
     */
    handleDeleteClickConfirm() {
        const { tabId } = this.props
        const { requestForPopup } = this.state
        if (tabId == TAB_TRAVELLERS) {
            this.props.deleteTraveller(requestForPopup)
        } else if (tabId == TAB_ACCOUNT_USERS) {
            this.props.deleteNominee(requestForPopup)
        }
    }

    /**
     * Handling of click event of Delete button from table.
     * @param {*} input 
     * 
     * @author Ajmal V Aliyar
     */
    handleClickDelete(input) {
        this.resetError();
        const { nomineesResponse, defaultConfig } = this.props
        let nomineeDetail = JSON.parse(JSON.stringify(input))
        const currentProgram = getCurrentProgramFromDefaultConfig(defaultConfig)
        let nomineeAccountGroupType = undefined
        if(currentProgram){
            nomineeAccountGroupType = currentProgram.data.nomineeAccountGroupTypes.find(type => {
                return type.value == input.accountGroupType
            })
        }
        nomineeDetail.accountGroupType = (nomineeAccountGroupType) ? nomineeAccountGroupType.key : ""

        let requestPayload = JSON.parse(JSON.stringify(REQUEST_TEMPLATE.DELETE_NOMINEE.object))
        requestPayload.companyCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE)
        requestPayload.programCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE)
        requestPayload.membershipNumber = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)
        requestPayload.accountStatus = nomineesResponse.accountStatus
        requestPayload.preferredLanguage = nomineesResponse.preferredLanguage
        const membershipType = defaultConfig.data.membershipTypes.find(type => {
            return type.value == nomineesResponse.membershipType
        })
        requestPayload.membershipType = (membershipType) ? membershipType.key : ""
        requestPayload.nomineeDetails.push(nomineeDetail)
        requestPayload = ({
            object: requestPayload
        })
        this.setState({
            requestForPopup: requestPayload,
            isDeletePopupVisible: true,
            popupFunction: POPUP_FUNCTION_DELETE
        })
    }

    /**
     * Popup window is closed, the following states are cleared:
     * 
     *      1.  isAddEditPopUpVisible
     *      2.  popupFunction
     *      3.  requestForPopup
     * 
     * @author Ajmal V Aliyar
     */
    onAddEditPopupHide() {
        this.setState({
            isAddEditPopUpVisible: false,
            popupFunction: undefined,
            requestForPopup: undefined,
            showWarningAndError: false,
            errorCodes: []
        })
        this.resetError();
    }

    handleRequestChange(requestForPopup) {
        this.resetError();
        const { tabId } = this.props
        const { contextBasedConfigs, popupFunction } = this.state
        const dynamicAttributesPath = contextBasedConfigs[tabId][popupFunction].ui.dynamicAttributesPath
        this.applyDynamicAttributeChangesToRequest(requestForPopup, dynamicAttributesPath)
        this.setState({
            requestForPopup,
            showWarningAndError: false
        })
    }

    applyDynamicAttributeChangesToRequest(request, path) {
        const { tabId } = this.props
        const { nomineePrivilegeDynamicAttributes } = this.state
        if (
            tabId == TAB_ACCOUNT_USERS
        ) {

            let dynamicAttributes = findValueFromObjectByPath(request, path, [])
            const selectedPrivilegeType = request.object.nomineeAccessPrivilege
            const fullAccessPrivilegeAttributes = nomineePrivilegeDynamicAttributes.full
            const limitedAccessPrivilegeAttributes = nomineePrivilegeDynamicAttributes.limited
            this.removePrivilegesFromArray(dynamicAttributes, fullAccessPrivilegeAttributes.concat(limitedAccessPrivilegeAttributes))
            if (selectedPrivilegeType == PRIVILEGE_ATTRIBUTES_KEY_FULL_ACCESS) {
                dynamicAttributes = dynamicAttributes.concat(fullAccessPrivilegeAttributes)
            }
            if (selectedPrivilegeType == PRIVILEGE_ATTRIBUTES_KEY_LIMITED_ACCESS) {
                dynamicAttributes = dynamicAttributes.concat(limitedAccessPrivilegeAttributes)
            }
            setValueToObjectByPath(request, path, dynamicAttributes)
        }
    }

    removePrivilegesFromArray(dynamicAttributes, attributesToRemove) {
        attributesToRemove.forEach(objectToRemove => {
            const equalOccuranceIndex = dynamicAttributes.findIndex(attribute =>
                objectToRemove.attributeCode == attribute.attributeCode &&
                objectToRemove.attributeValue == attribute.attributeValue
            )
            if (equalOccuranceIndex !== -1) {
                dynamicAttributes.splice(equalOccuranceIndex, 1)
            }
        })
    }

    convertDynamicAttributesArrayToUsableStructure(array) {
        return array.map(attribute => {
            return {
                attributeCode: attribute.attributeCode,
                attributeValue: attribute.attributeValue
            }
        })
    }

    handleErrorMessagesFromSection(codes) {
        if (!codes.length) { this.resetError() }
        if (JSON.stringify(codes) != JSON.stringify(this.state.errorCodes)) {
            this.setState({ errorCodes: codes })
        }
    }

    generateUpdateRequest() {
        const { tabId, customerResponse } = this.props
        const { popupFunction, contextBasedConfigs } = this.state
        const dynamicAttributesPath = contextBasedConfigs[tabId][popupFunction].ui.dynamicAttributesPath
        let requestForPopup = JSON.parse(JSON.stringify(REQUEST_TEMPLATE[tabId][popupFunction]))

        this.setAdditionalMappingsToRequest(requestForPopup, popupFunction, customerResponse)
        let dynamicAttributes = this.convertDynamicAttributesArrayToUsableStructure(findValueFromObjectByPath(requestForPopup, dynamicAttributesPath, []))
        setValueToObjectByPath(requestForPopup, dynamicAttributesPath, dynamicAttributes)
        this.setAccessPrivilegeTemporaryFlagFromDynamicAttributes(requestForPopup, dynamicAttributes)

        this.setState({
            requestForPopup,
            isAddEditPopUpVisible: true
        })
    }

    setAccessPrivilegeTemporaryFlagFromDynamicAttributes(request, dynamicattributes) {
        const { nomineePrivilegeDynamicAttributes } = this.state
        let nomineeAccessPrivilege = undefined

        if (this.isAllAttributesPresentInArray(dynamicattributes, nomineePrivilegeDynamicAttributes.full)) {
            nomineeAccessPrivilege = PRIVILEGE_ATTRIBUTES_KEY_FULL_ACCESS
        }
        if (this.isAllAttributesPresentInArray(dynamicattributes, nomineePrivilegeDynamicAttributes.limited)) {
            nomineeAccessPrivilege = PRIVILEGE_ATTRIBUTES_KEY_LIMITED_ACCESS
        }
        setValueToObjectByPath(request, "object.nomineeAccessPrivilege", nomineeAccessPrivilege)
    }

    /**
     * Returns 'true' if ALL the elements of 'arrayToSearchFor' is present in 'arrayToSearchIn'.
     * Else return false.
     * 
     * @param {Array} arrayToSearchIn The array in which the search is going to happen
     * @param {Array} arrayToSearchFor The serach will be for the elements of this array
     * 
     * @author Ajmal V Aliyar
     */
    isAllAttributesPresentInArray(arrayToSearchIn, arrayToSearchFor) {
        let isPresent = true
        let index = 0
        do {
            const searchIndex = arrayToSearchIn.findIndex(object =>
                object.attributeCode == arrayToSearchFor[index].attributeCode &&
                object.attributeValue == arrayToSearchFor[index].attributeValue
            )
            if (searchIndex == -1) {
                isPresent = false
            }
            index++
        } while (index < arrayToSearchFor.length && isPresent)

        return isPresent
    }

    /**
     * @todo move to util
     * 
     * @param {*} request 
     * @param {*} responseForReference 
     */
    setAdditionalMappingsToRequest(request, popupFunction, responseForReference) {
        const { tabId, defaultConfig, travellerConfig, nomineeConfig } = this.props
        const { contextBasedConfigs } = this.state
        const config = contextBasedConfigs[tabId][popupFunction]
        const fullConfig = (tabId == TAB_TRAVELLERS)
            ? travellerConfig
            : (tabId == TAB_ACCOUNT_USERS) ? nomineeConfig : undefined
        if (config && config.ui && config.ui.request && config.ui.request.additionalMapping) {
            config.ui.request.additionalMapping.forEach((fields) => {
                let { fromPath, toPath, dependentPath } = fields
                let value = undefined
                fromPath.forEach((path, index) => {
                    let returnValue = getValueFromPath(path, {config: fullConfig, request: responseForReference, defaultConfig})
                    if (returnValue instanceof Object) {
                        if (!value) {
                            value = {}
                        }
                        if (Object.keys(value).length > 0) {
                            value = {
                                ...value,
                                ...returnValue
                            }
                        } else {
                            value = returnValue
                        }
                    } else if (returnValue instanceof Array) {
                        value = returnValue
                    } else if (returnValue && isDependentExists(dependentPath, {config: fullConfig, request: responseForReference, defaultConfig})) {
                        if (!value) {
                            value = ""
                        }
                        value += (index > 0 ? " " : "") + returnValue
                    }
                })
                if (value) {
                    constructJsonPath(toPath, value, request)
                    setValueToObjectByPath(request, toPath, value)
                }
            })
        }
    }

    /**
     * Does the following when confirmation event from the popup is received 
     *  -   If errors exist, it will be updated in the state so that it can be displayed
     *  -   Else, the corresponding API call from below will be fired based on tabId(prop) and popupFunction(state)
     *      -   addTraveller
     *      -   addNominee
     *      -   updateTraveller
     *      -   updateNominee
     * 
     * @author Ajmal V Aliyar
     */
    handleAddEditClickConfirm() {
        const { tabId } = this.props
        const { popupFunction, errorCodes } = this.state
        let { requestForPopup } = this.state
        const operationWithContext = `${tabId}-${popupFunction}`
        if (errorCodes.length) {
            this.props.setError(errorCodes);
        } else {
            switch (operationWithContext) {
                case `${[TAB_TRAVELLERS]}-${[POPUP_FUNCTION_ADD]}`:
                    this.props.addTraveller(requestForPopup, ID_CONFIRM_BUTTON)
                    break;
                case `${[TAB_ACCOUNT_USERS]}-${[POPUP_FUNCTION_ADD]}`:
                    this.props.addNominee(requestForPopup, ID_CONFIRM_BUTTON)
                    break;
                case `${[TAB_TRAVELLERS]}-${[POPUP_FUNCTION_EDIT]}`:
                    this.props.updateTraveller(requestForPopup)
                    break;
                case `${[TAB_ACCOUNT_USERS]}-${[POPUP_FUNCTION_EDIT]}`:
                    this.props.updateNominee(requestForPopup)
                    break;
                default:
                    console.error("Confirm Clicked; Could not decide which operation to do.Operation encountered :", operationWithContext);
            }
        }
        this.setState({ showWarningAndError: true })
    }

    render() {
        const { t, i18Path, tabId, errors, userPrivileges, corporateNominees } = this.props
        const {
            layout,
            isAddEditPopUpVisible,
            isDeletePopupVisible,
            popupLayout,
            popupFunction,
            requestForPopup,
            errorCodes,
            showWarningAndError
        } = this.state
        let canEdit = undefined
        if (userPrivileges && corporateNominees) {
            const privilegeCheckData = havePrivilege(
                { "url": getCurrentPageUri(), "tab": tabId },
                corporateNominees,
                CONTEXT_TAB,
                userPrivileges)
            canEdit = privilegeCheckData ? privilegeCheckData.permission === FULL_ACCESS : true
        }

        return (
            <>
                <h2>{t(`${i18Path}.title`)}</h2>
                <p>{t(`${i18Path}.description`)}</p>
                {
                    canEdit ?
                        <div className="text-right btnWrapper">
                            <button className="btn btn-primary"
                                data-target="#managePeopleModal" //id of the div inside component 'ManagePeopleDialog'
                                onClick={(e) => this.handleClickAdd()}
                            >
                                {t(`${i18Path}.add_button`)}
                            </button>
                        </div> : <></>
                }
                {
                    layout &&
                    layout.order &&
                    layout.order.length &&
                    layout.order.map((element, index) => {
                        return this.displayElement(element, index, canEdit)
                    })
                }



                {/* <----------------------    Displayed only when needed - popup ------------------->*/}
                {
                    isAddEditPopUpVisible &&
                    popupLayout[tabId] &&
                    <AddEditPopup
                        id={"managePeople"}
                        isVisible={isAddEditPopUpVisible}
                        i18Path={`${i18Path}.popups.addedit.${popupFunction}`}
                        operation={popupFunction}
                        onPopupHide={() => this.onAddEditPopupHide()}
                        onClickCancel={() => this.onAddEditPopupHide()}
                        onClickConfirm={() => this.handleAddEditClickConfirm()}
                        layout={popupLayout[tabId][popupFunction]}
                        request={requestForPopup}
                        dynamicAttributesPath={undefined}
                        dynamicAttributes={undefined}
                        findValueFromState={(stateFieldName, fieldType) => console.warn("findValueFromState is invoked")}
                        onRequestChange={(req) => this.handleRequestChange(req)}
                        onErrorCodes={(codes) => this.handleErrorMessagesFromSection(codes)}
                        messages={(errorCodes.length > 0) ? errorCodes : (errors) ? errors : []}
                        isSuccessMessage={false}
                        canTranslateMessage={errorCodes.length > 0}
                        showWarningAndError={showWarningAndError}
                    />
                }

                <Popup
                    isVisible={isDeletePopupVisible}
                    id={"confirm-delete"}
                    i18Path={`${i18Path}.popups.confirm_delete`}
                    popupType={POPUP_TYPE_CONFIRMATION}
                    onPopupHide={() => this.onDeletePopupHide()}
                    onClickCancel={() => this.onDeletePopupHide()}
                    onClickConfirm={() => this.handleDeleteClickConfirm()}
                    errors={errors}
                    isSuccessMessage={false}
                    canTranslateMessage={false}
                />

            </>

        )
    }
}

ManagePeopleOverview.defaultProps = {
};

const mapStateToProps = (state) => {
    return {
        errors: state.commonErrorReducer.error,
        travellerConfig: state.configurationReducer[CONFIG_SECTION_TRAVELLER],
        nomineeConfig: state.configurationReducer[CONFIG_SECTION_NOMINEE],
        nomineesResponse: state.retrieveNomineesReducer.response,
        customerResponse: state.retrieveCustomerReducer.response,
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        addedTraveller: state.addTravellerReducer.response,
        addedNominee: state.addNomineeReducer.response,
        updatedTraveller: state.updateTravellerReducer.response,
        updatedNominee: state.updateNomineeReducer.response,
        deletedTraveller: state.deleteTravellerReducer.response,
        deletedNominee: state.deleteNomineeReducer.response,
        userPrivileges: state.privilegesReducer.privileges,
        corporateNominees: state.retriveAccountNomineeReducer.corporateNominees
    }
}

const mapDispatchToProps = {
    setError,
    resetError,
    retrieveNominees,
    retrieveCustomer,
    fetchConfiguration,
    addTraveller,
    addNominee,
    updateTraveller,
    updateNominee,
    deleteTraveller,
    deleteNominee
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(ManagePeopleOverview)));