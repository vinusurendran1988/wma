import React from 'react';
import { withSuspense, getCurrentPageUri } from '../../../../common/utils';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { fetchConfiguration, resetError } from '../../../../common/middleware/redux/commonAction';
import { CONFIG_SECTION_MANAGEPEOPLE, CONFIG_SECTION_DEFAULT, PROGRAM_TYPE_CORPORATE, CONFIG_SECTION_ACCOUNT_SUMMARY } from '../../../../common/utils/Constants';
import ManagePeopleOverview from './ManagePeopleOverview';
import _403 from '../../../errors/403';
import { havePrivilege, CONTEXT_TAB } from '../../../../common/privileges';
import { getItemFromBrowserStorage, BROWSER_STORAGE_KEY_PROGRAM_TYPE } from '../../../../common/utils/storage.utils';
import CustomMessage from '../../../../common/components/custommessage';

class ManagePeople extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            i18Path: "corporate.admin.manage_people",
            selectedTab: undefined,
            messages: []
        }
        this.setMessage = this.setMessage.bind(this)
    }

    /**
     * Tasks done in componentDidMount:
     *  - Fetch ManagePeople configuration
     * 
     * @author Ajmal V Aliyar
     */
    componentDidMount() {
        this.props.setPageInfo(this.props, {config: this.props.managePeopleConfig, confSection: CONFIG_SECTION_MANAGEPEOPLE})
        if (!this.props.accountSummaryConfig) { this.props.fetchConfiguration(CONFIG_SECTION_ACCOUNT_SUMMARY) }
        if (!this.state.selectedTab) {
            this.setSelectedTab()
        }
    }

    componentDidUpdate(prevProps) {
        const { managePeopleConfig } = this.props

        if (prevProps.managePeopleConfig != managePeopleConfig) {
            this.setSelectedTab()
        }
    }

    /**
     * @description Sets the tab to be selected.
     * 
     * - If a parameter (tab-identifier string) is passed:
     *   It will be set to state.
     * 
     * - Else if no parameter is passed:
     *   The first tab found from managepeople config will be set to config.
     * 
     * @param {string} tabName tab-identifier (optional)
     * 
     * @author Ajmal V Aliyar
     */
    setSelectedTab(tabName) {
        if (!tabName) {
            const { managePeopleConfig } = this.props
            if (
                managePeopleConfig &&
                managePeopleConfig.ui &&
                managePeopleConfig.ui.layout &&
                managePeopleConfig.ui.layout.type == "tab" &&
                managePeopleConfig.ui.layout.order &&
                managePeopleConfig.ui.layout.order.length
            ) {
                tabName = managePeopleConfig.ui.layout.order[0]
            }
        }

        if (tabName) {
            this.setState({
                selectedTab: tabName,
                messages: []
            })
            this.props.resetError()
        }
    }

    doRenderOverview() {
        const { selectedTab } = this.state
        const {
            accountSummary,
            userPrivileges,
            corporateNominees
        } = this.props
        const programType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE)
        const userData = programType === PROGRAM_TYPE_CORPORATE ? corporateNominees : accountSummary
        if (userPrivileges && userData) {
            const privilegeCheckData = havePrivilege(
                { "url": getCurrentPageUri(), "tab": selectedTab },
                userData,
                CONTEXT_TAB,
                userPrivileges)

            return privilegeCheckData.canDisplay
        }
    }

    setMessage(messages) {
        this.setState({ messages })
    }

    render() {
        const { managePeopleConfig, t } = this.props
        const { selectedTab, i18Path, messages } = this.state
        const tabs = (
            managePeopleConfig &&
            managePeopleConfig.ui &&
            managePeopleConfig.ui.layout &&
            managePeopleConfig.ui.layout.type == "tab" &&
            managePeopleConfig.ui.layout.order &&
            managePeopleConfig.ui.layout.order.length
        ) ? managePeopleConfig.ui.layout.order : []

        const doRender = this.doRenderOverview()

        return (
            <>
                <div className="form-row">
                    <div className="col-lg-12">
                        <h1>{t(`${i18Path}.title`)}</h1>
                        <CustomMessage
                            message={messages}
                            canTranslate={true}
                        />
                        <ul className="nav nav-tabs" id="myTab" role="tablist">
                            {tabs.map((tab, index) => {
                                return <li key={index}
                                    className="nav-item"
                                    role="presentation"
                                >
                                    <a className={`nav-link ${tab == selectedTab ? 'active' : ''}`}
                                        id={`${tab}-tab`}
                                        data-toggle="tab"
                                        role="tab"
                                        href={`#${tab}`}
                                        aria-controls={tab}
                                        aria-selected="true"
                                        onClick={() => this.setSelectedTab(tab)}
                                    >{t(`${i18Path}.${tab}.tabName`)}</a>
                                </li>
                            })}
                        </ul>
                        <div className="tab-content" id="myTabContent">
                            {
                                selectedTab &&
                                <div
                                    className="tab-pane fade show active"
                                    id={selectedTab}
                                    role="tabpanel"
                                    aria-labelledby={`${selectedTab}-tab`}
                                >
                                    {
                                        (doRender)
                                            ? <ManagePeopleOverview
                                                i18Path={`${i18Path}.${selectedTab}`}
                                                tabId={selectedTab}
                                                onSuccessMessage={(receivedMessages) => this.setMessage(receivedMessages)}
                                            />
                                            : <_403 />
                                    }
                                </div>
                            }
                        </div>
                    </div>
                </div>
            </>

        )
    }
}

ManagePeople.defaultProps = {
};

const mapStateToProps = (state) => {
    return {
        managePeopleConfig: state.configurationReducer[CONFIG_SECTION_MANAGEPEOPLE],
        accountSummaryConfig: state.configurationReducer[CONFIG_SECTION_ACCOUNT_SUMMARY],
        accountSummary: state.accountSummaryReducer.accountSummary,
        userPrivileges: state.privilegesReducer.privileges,
        corporateNominees: state.retriveAccountNomineeReducer.corporateNominees
    }
}

const mapDispatchToProps = {
    resetError,
    fetchConfiguration
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(ManagePeople)));