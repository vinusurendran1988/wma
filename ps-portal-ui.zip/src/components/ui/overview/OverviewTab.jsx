import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { withSuspense, numberWithCommas } from '../../common/utils';
import { connect } from 'react-redux';
import { CONFIG_SECTION_DEFAULT, PROGRAM_TYPE_CORPORATE } from '../../common/utils/Constants';
import { fetchConfiguration, fetchAccountSummary } from '../../common/middleware/redux/commonAction'
import { NAVIGATE_MEMBER_MYFLIGHT, NAVIGATE_CORPORATE_MYFLIGHT, NAVIGATE_MEMBER_EXTEND_EXPIRY } from '../../common/utils/urlConstants';
import { getItemFromBrowserStorage, BROWSER_STORAGE_KEY_PROGRAM_TYPE } from '../../common/utils/storage.utils';
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';

class OverviewTab extends Component {
    constructor(props) {
        super(props)
    }

    navigateRedeem() {
        const programType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE)
        let location = `#${NAVIGATE_MEMBER_MYFLIGHT}`
        if (programType == PROGRAM_TYPE_CORPORATE) {
            location = `#${NAVIGATE_CORPORATE_MYFLIGHT}`
        }
        return location
    }

    render() {
        const { t, accountSummary, section } = this.props
        let { defaultConfig } = this.props
        const defaultProgram = getCurrentProgramFromDefaultConfig(defaultConfig)
        return (
            defaultConfig && accountSummary && section ?
                section.fields.map((pointDetail) => {
                    if (pointDetail.visibility) {
                        let hasAdditional = false, hasExpiryData = false, defaultPointType = {}, iconClass = " fa fa-plane ", points = 0, totalAccuredpoints = 0, totalRedeemedpoints = 0
                        let pointExpiryDetail = undefined
                        if (Array.isArray(pointDetail.pointType)) {
                            const pointSummaryDetailList = accountSummary.pointDetails.filter(e => pointDetail.pointType.includes(e.pointType))
                            pointExpiryDetail = accountSummary.expiryDetails.find(e => pointDetail.pointType.includes(e.pointType))
                            hasAdditional = (pointSummaryDetailList && pointSummaryDetailList.length && (pointSummaryDetailList.filter(e => e.totalAccuredpoints > 0).length || pointSummaryDetailList.filter(e => e.totalRedeemedpoints > 0).length)) && pointDetail.detail
                            hasExpiryData = (pointExpiryDetail != undefined)
                            if (defaultProgram && defaultProgram.data && defaultProgram.data.pointTypes) {
                                defaultPointType = defaultProgram.data.pointTypes.find(e => pointDetail.pointType.includes(e.pointType))
                            }
                            pointSummaryDetailList.map(pointSummaryDetail => {
                                points += pointSummaryDetail.points
                                totalAccuredpoints += pointSummaryDetail.totalAccuredpoints
                                totalRedeemedpoints += pointSummaryDetail.totalRedeemedpoints
                            })
                        } else if (typeof pointDetail.pointType === 'string') {
                            const pointSummaryDetail = accountSummary.pointDetails.find(e => e.pointType == pointDetail.pointType)
                            pointExpiryDetail = accountSummary.expiryDetails.find(e => e.pointType == pointDetail.pointType)
                            hasExpiryData = (pointExpiryDetail != undefined)
                            hasAdditional = (pointSummaryDetail && (pointSummaryDetail.totalAccuredpoints || pointSummaryDetail.totalRedeemedpoints)) && pointDetail.detail
                            if (defaultProgram && defaultProgram.data && defaultProgram.data.pointTypes) {
                                defaultPointType = defaultProgram.data.pointTypes.find(e => e.pointType == pointDetail.pointType)
                            }
                            points = pointSummaryDetail ? pointSummaryDetail.points : 0
                            totalAccuredpoints = pointSummaryDetail.totalAccuredpoints
                            totalRedeemedpoints = pointSummaryDetail.totalRedeemedpoints
                        }
                        points = numberWithCommas(parseInt(points))
                        totalAccuredpoints = numberWithCommas(parseInt(totalAccuredpoints))
                        totalRedeemedpoints = numberWithCommas(parseInt(totalRedeemedpoints))

                        if (defaultPointType && defaultPointType.className) iconClass = defaultPointType.className
                        return <li className={`dashItem ${hasAdditional && hasExpiryData ? "hasHover" : ""} list-inline-item col`}>
                            <div className=" d-flex justify-content-between">
                                <i className={iconClass} aria-hidden="true"></i>
                                <div className="txt ml-3">{defaultPointType && Object.keys(defaultPointType).length > 0 && defaultPointType.pointName}<strong>{points}</strong></div>
                            </div>
                            {
                                hasAdditional ?
                                    <div className="hasHoverDetails text-center">
                                        <span className="text-info">
                                            {/* {t('overview.tabs.last_one_year')} */}
                                        </span>
                                        <div className=" d-flex justify-content-around">
                                            <div className="txt ml-3">{t('overview.tabs.accrued')}<strong>{totalAccuredpoints}</strong>
                                            </div>
                                            {
                                                defaultPointType.redeemed &&
                                                <div className="txt ml-3">{t('overview.tabs.redeemed')}<strong>{totalRedeemedpoints}</strong>
                                                </div>
                                            }
                                        </div>
                                        <p>
                                            {
                                                hasExpiryData && pointDetail.showExpiryData && pointExpiryDetail ?
                                                    pointDetail.canAddExpiryLink ? <span className="text-danger" onClick={() => window.location.href = `#${NAVIGATE_MEMBER_EXTEND_EXPIRY}`} role="button">{t('overview.tabs.expiry').replace('{EXPIRY_MILES}', pointExpiryDetail.points).replace('{EXPIRY_DATE}', pointExpiryDetail.expiryDate)}</span>
                                                    : <span className="text-danger">{t('overview.tabs.expiry').replace('{EXPIRY_MILES}', pointExpiryDetail.points).replace('{EXPIRY_DATE}', pointExpiryDetail.expiryDate)}</span> : <></>
                                            }
                                            <br />
                                            {
                                                defaultPointType.redeemed && (pointDetail.redeemed == undefined || pointDetail.redeemed) &&
                                                t('overview.tabs.redeem_before_it_expires')
                                            }
                                        </p>
                                        {
                                            defaultPointType.redeemed && (pointDetail.redeemed == undefined || pointDetail.redeemed) &&
                                            <div>
                                                <a href={this.navigateRedeem()} className="btn-sm btn btn-primary">{t('overview.redeem_now')}</a>
                                            </div>
                                        }
                                    </div> : ""
                            }
                        </li>
                    }
                }) : <div></div>
        )
    }
}



function mapStateToProps(state) {
    return {
        accountSummary: state.accountSummaryReducer.accountSummary,
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT]
    }
}

const mapDispatchToProps = { fetchConfiguration, fetchAccountSummary }

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(OverviewTab)));