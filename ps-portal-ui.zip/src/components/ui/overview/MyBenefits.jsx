import React, { Component } from 'react';

class MyBenefits extends Component {
    render() {
        const { pointDetail, section, t } = this.props
        return (
            <div className="col">
                <div className="cardItems">
                    <div className="d-flex justify-content-between">
                        <i className={pointDetail.className} aria-hidden="true"></i>
                        <span>{pointDetail.totalRedeemedpoints + "/" + pointDetail.totalAccuredpoints}</span>
                    </div>
                    <p><strong><center>{pointDetail.pointName}</center> </strong></p>
                    {
                        section && section.enrollButtonEnabled &&
                        <div className="text-center">
                            <span className="btn btn-sm btn-primary disabled" >{t('overview.btn_details')}</span>
                        </div>
                    }
                </div>
            </div>
        );
    }
}

export default MyBenefits;