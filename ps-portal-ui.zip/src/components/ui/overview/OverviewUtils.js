export const getMessage = (tierOption, operation, customMessageId, tierToDate, t) => {
    
    let message = t(customMessageId)
    try {

        if(!customMessageId) {
            customMessageId = `overview.messages.${operation}.default`
            message = t(customMessageId)
        }
        if(message == customMessageId) {
            message = ""
        } else {
    
            let condition = "", flag = false
            tierOption.options.forEach((option, i) => {
                if(i==0) flag = option.optionDetails.length>0
                if(condition != "" && i != 0) condition += ` ${t('overview.or')} `
                option.optionDetails.forEach((detail, j) => {
                    // if(detail.preferred) {
                        flag = flag&&detail.result
                        if(!detail.result) {
                            if(j != 0) condition += " " + option.operator + " "
                            condition += detail.diff + " " + detail.name
                        }
                    // }
                })
            });
            if(condition == "") {
                if(flag) {
                    customMessageId = `overview.messages.${operation}.passed`
                    message = t(customMessageId)
                }
                if(message == customMessageId) message = ""
            } else {
                message = message.replace("{CONDITION}", condition)
            }
            message = message.replace("{TIER}",tierOption.tierName).replace("{EXPIRYDATE}", tierToDate)
            
        }
    } catch(err) {
        message = ""
    }
    return message
}