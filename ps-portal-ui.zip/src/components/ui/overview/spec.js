import React from 'react';
import { testStore } from '../../common/utils';
import moxios from 'moxios';
import { mount } from 'enzyme';
import {
    findComponent,
    mockServiceResponse
} from '../../common/testUtils';
import ReactTestUtils from 'react-dom/test-utils';
import { Provider } from 'react-redux'
import {
    fetchConfiguration, fetchAccountSummary, fetchProfileImage
} from '../../common/middleware/redux/commonAction'
import Overview from './index';
import { CONFIG_SECTION_OVERVIEW, CONFIG_SECTION_DEFAULT, SESSION_STORAGE_COMPANY_CODE, SESSION_STORAGE_PROGRAM_CODE, SESSION_STORAGE_MEMBERSHIP_NO } from '../../common/utils/Constants';

let store;
let rootComponent;
let component;

const setUpOverview = (props = {}) => {
    store = testStore({})
    rootComponent = mount(<Provider store={store}>
        <Overview {...props} store={store} />
    </Provider>);
    component = findComponent(rootComponent, 'Overview');
};

describe('Overview: Render the page', () => {

    beforeEach(() => {
        store = undefined
        setUpOverview({});
        moxios.install();
    });


    afterEach(() => {
        moxios.uninstall();
    });

    it('Overview: render the page without errors', () => {

        rootComponent = rootComponent.update();
        component = findComponent(rootComponent, 'Overview');


        mockServiceResponse(OVERVIEW_CONFIG)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_OVERVIEW))
                .then(() => {
                    let newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_OVERVIEW]).toBe(OVERVIEW_CONFIG.object);

                    mockServiceResponse(ACCOUNT_SUMMARY_RESPONSE)
                    return ReactTestUtils.act(() => {
                        return store.dispatch(fetchAccountSummary(ACCOUNT_SUMMARY_REQUEST))
                            .then(() => {
                                newState = store.getState();
                                expect(newState.accountSummaryReducer.accountSummary).toBe(ACCOUNT_SUMMARY_RESPONSE.object);

                                mockServiceResponse(PROFILE_IMG_RESPONSE)
                                return ReactTestUtils.act(() => {
                                    return store.dispatch(fetchProfileImage(PROFILE_IMG_REQUEST))
                                        .then(() => {
                                            newState = store.getState();
                                            expect(newState.profileImageReducer.profileImage).toBe(PROFILE_IMG_RESPONSE.object);

                                            window.sessionStorage.setItem(SESSION_STORAGE_COMPANY_CODE, "IBS")
                                            window.sessionStorage.setItem(SESSION_STORAGE_PROGRAM_CODE, "PRG14")
                                            localStorage.setItem(SESSION_STORAGE_MEMBERSHIP_NO, "IM0008010133")
                                            mockServiceResponse(DEFAULT_CONFIG)
                                            return ReactTestUtils.act(() => {
                                                return store.dispatch(fetchConfiguration(CONFIG_SECTION_DEFAULT))
                                                    .then(() => {
                                                        newState = store.getState();
                                                        expect(newState.configurationReducer[CONFIG_SECTION_DEFAULT]).toBe(DEFAULT_CONFIG.object);
                                                    })
                                            })

                                        })
                                })
                            })
                    })
                })
        })

    })

})

describe('Overview: Failed to render the page due to errors', () => {

    beforeEach(() => {
        store = undefined
        setUpOverview({});
        moxios.install();
    });


    afterEach(() => {
        moxios.uninstall();
    });

    it('Default config response 500', () => {
        mockServiceResponse(DEFAULT_CONFIG_ERROR, 500)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_DEFAULT));
        })
    })

    it('Profile Image response 500', () => {
        mockServiceResponse(PROFILE_IMG_RESPONSE_ERROR, 500)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchProfileImage(PROFILE_IMG_REQUEST));
        })
    })

    it('Account Summary response 500', () => {
        mockServiceResponse(ACCOUNT_SUMMARY_RESPONSE_ERROR, 500)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchAccountSummary(ACCOUNT_SUMMARY_REQUEST));
        })
    })

    it('Overview config response 500', () => {
        mockServiceResponse(OVERVIEW_CONFIG_ERROR, 500)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_OVERVIEW));
        })
    })
})
const OVERVIEW_CONFIG_ERROR = { "statuscode": "500", "statusMessage": "FAILURE", "error": { "code": "500", "type": "INTERNAL_SERVER_ERROR", "message": "Overview failed", "errorDetails": [{ "message": "Overview failed" }] } }
const ACCOUNT_SUMMARY_RESPONSE_ERROR = { "statuscode": "500", "statusMessage": "FAILURE", "error": { "code": "500", "type": "INTERNAL_SERVER_ERROR", "message": "Account Summary failed", "errorDetails": [{ "message": "Account Summary failed" }] } }
const PROFILE_IMG_RESPONSE_ERROR = { "statuscode": "500", "statusMessage": "FAILURE", "error": { "code": "500", "type": "INTERNAL_SERVER_ERROR", "message": "Profile Image failed", "errorDetails": [{ "message": "Profile Image failed" }] } }
const DEFAULT_CONFIG_ERROR = { "statuscode": "500", "statusMessage": "FAILURE", "error": { "code": "500", "type": "INTERNAL_SERVER_ERROR", "message": "Default config failed", "errorDetails": [{ "message": "Default config failed" }] } }
const PROFILE_IMG_REQUEST = {
    object: {
        companyCode: window.sessionStorage.getItem(SESSION_STORAGE_COMPANY_CODE),
        programCode: window.sessionStorage.getItem(SESSION_STORAGE_PROGRAM_CODE),
        membershipNumber: localStorage.getItem(SESSION_STORAGE_MEMBERSHIP_NO)
    }
}
const PROFILE_IMG_RESPONSE = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "profileImgData": "", "profileImgType": "jpg", "isPrivate": false, "profileImgEncoder": "base64" } }
const ACCOUNT_SUMMARY_REQUEST = {
    object: {
        companyCode: window.sessionStorage.getItem(SESSION_STORAGE_COMPANY_CODE),
        programCode: window.sessionStorage.getItem(SESSION_STORAGE_PROGRAM_CODE),
        membershipNumber: localStorage.getItem(SESSION_STORAGE_MEMBERSHIP_NO)
    }
}

const ACCOUNT_SUMMARY_RESPONSE = {"statuscode":"200","statusMessage":"SUCCESS","object":{"title":"Mrs","givenName":"Beema","familyName":"Shajahan","membershipType":"Individual","membershipStatus":"Active","membershipStatusCode":"A","accountStatus":"Active","accountStatusCode":"A","suspended":false,"tierCode":"SIL","tierName":"Silver","tierFromDate":"08-Oct-2020","tierToDate":"07-Oct-2021","prospectTier":"","companyName":"","expiryDate":null,"lastActivityDate":"08-Oct-2020","activityType":"Tier Change Activity","expiryDetails":[{"pointType":"FLTCNT","points":1.0,"expiryDate":"05-Oct-2021"},{"pointType":"TIER","points":73.0,"expiryDate":"05-Oct-2021"},{"pointType":"CV","points":2.0,"expiryDate":"07-Oct-2021"},{"pointType":"KC","points":4.0,"expiryDate":"07-Oct-2021"},{"pointType":"FLTCNT","points":15.0,"expiryDate":"07-Oct-2021"},{"pointType":"TIER","points":695.0,"expiryDate":"07-Oct-2021"},{"pointType":"LP","points":9500.0,"expiryDate":"05-Oct-2023"},{"pointType":"BASE","points":150.0,"expiryDate":"07-Oct-2024"}],"pointDetails":[{"pointType":"BASE","pointTypeGroup":"Airpoints Dollars","totalAccuredpoints":150.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":150.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"BONUSAPD","pointTypeGroup":"Airpoints Dollars","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"LP","pointTypeGroup":"Loyalty Points","totalAccuredpoints":10400.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":10400.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"BONUS","pointTypeGroup":"Loyalty Points","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"TIER","pointTypeGroup":"Status Points","totalAccuredpoints":768.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":768.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"TIERCC","pointTypeGroup":"Status Points","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"FS","pointTypeGroup":"Total Flights","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"FC","pointTypeGroup":"Total Flights","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"REVENUE","pointTypeGroup":"Revenue (NZD)","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"BC","pointTypeGroup":"Benefits","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"KC","pointTypeGroup":"Benefits","totalAccuredpoints":4.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":4.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"WIFI","pointTypeGroup":"Benefits","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"CV","pointTypeGroup":"Benefits","totalAccuredpoints":2.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":2.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"DF","pointTypeGroup":"Benefits","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0},{"pointType":"MV","pointTypeGroup":"Benefits","totalAccuredpoints":0.0,"totalRedeemedpoints":0.0,"pointsToNextTier":0.0,"pointsForTierRetention":0.0,"points":0.0,"bonusDetails":[],"creditLimit":0.0}],"tierOptions":[{"tierName":"Gold","tierCode":"GOL","type":"upgrade","options":[{"operator":"and","optionDetails":[{"current":"768","next":"900","diff":"132","types":["TIER","TIERCC"],"name":"Total Status Points","uiType":"point","result":false,"preferred":true},{"current":"768","next":"450","diff":"-318","types":["TIER"],"name":"Status Points Air","uiType":"point","result":true,"preferred":true}],"result":false}],"message":"You are 132 Total Status Points away from the next tier"},{"tierName":"Silver","tierCode":"SIL","type":"retain","options":[{"operator":"and","optionDetails":[{"current":"768","next":"404","diff":"-364","types":["TIER","TIERCC"],"name":"Total Status Points","uiType":"point","result":true,"preferred":true},{"current":"768","next":"202","diff":"-566","types":["TIER"],"name":"Status Points Air","uiType":"point","result":true,"preferred":true}],"result":true}],"message":null}]}}

const OVERVIEW_CONFIG = {"statuscode":"200","statusMessage":"SUCCESS","object":{"section":"overview","companyCode":"IBS","programCode":"PRG14","ui":{"order":["header","pointTypeCarousel","graph","cart","promotional","benefits","links"],"layout":{"elements":{"header":{"totalMilePointTypes":["BASE","BONUS","LP"],"className":"col-lg-12","fields":[{"icons":[{"iconName":"qr","url":"#"},{"iconName":"card","url":"#"},{"iconName":"dropPin","url":"#"},{"iconName":"notification","data":"3","url":"#"}]}]},"graph":{"className":"col-lg-9 tabLeft","fields":[{"name":"upgradeHeader","visibility":true,"className":""},{"name":"upgradeComponent","visibility":true},{"name":"dotLine","visibility":true},{"name":"retainHeader","visibility":true,"className":""},{"name":"retainComponent","visibility":true}]},"cart":{"fields":[{"name":"shopAd","visibility":true,"className":"col-lg-3 tabRight knowMoreTab"}]},"pointTypeCarousel":{"className":"col-lg-12","fields":[{"pointType":"BASE","className":"fa fa-plane","detail":true,"visibility":true},{"pointType":"BONUS","className":"fa fa-database","detail":true,"visibility":true},{"pointType":"TIER","className":"fa fa-star","detail":true,"visibility":true},{"pointType":"TIERKE","className":"fa fa-credit-card","detail":true,"visibility":true},{"pointType":"FS","className":"fa fa-star","detail":true,"visibility":true},{"pointType":"FC","className":"fa fa-star","detail":true,"visibility":true}]},"promotional":{"fields":[{"visibility":true,"className":"col-lg-12 banner"}]},"benefits":{"pointTypeGroup":["Total Benefits","Benefits", "Total Miles"],"fields":[{"visibility":true,"className":"col-lg-9 tabLeft myBenafitsSec"}]},"links":{"fields":[{"name":"useMiles","visibility":true,"className":"col-lg-3 tabRight knowMoreTab2"}]}}}}}}

const DEFAULT_CONFIG = { "statuscode": "200", "statusMessage": "SUCCESS", "object": [{ "section": "default", "companyCode": "IBS", "programCode": "PRG14", "programName": "SKYPASS", "skipPinChangeReminder": true, "defaultCurrency": "KRW", "defaultPosCity": "SEO", "defaultPosCountry": "KE", "defaultPinRegex": "^\\d{4}$", "defaultPasswordRegex": "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$", "requestTimedOutInMs": 20000, "tiers": [{ "name": "Blue", "code": "BLU", "order": "1", "minQualifyingMiles": 0, "minQualifyingSegments": 0, "upgradeExpiryInMonths": "12", "downgradeExpiryInMonths": "12", "themeClass": "userClass4", "upgrade": { "type": "upgrade", "tierName": "Silver", "tierCode": "SIL", "message": "You are ${condition} away from the next tier", "criterias": { "criteria1": { "criteriaName": "criteria1", "name": "Total Qualifying Miles", "values": ["TIER", "TIERKE"], "type": "points", "uiType": "point" }, "criteria2": { "criteriaName": "criteria2", "name": "Total Qualifying Segments", "values": ["FS", "FC"], "type": "points", "uiType": "flight" }, "criteria3": { "criteriaName": "criteria3", "name": "Total KE Qualifying miles", "type": "points", "values": ["TIER"], "uiType": "point" } }, "conditions": { "condition1": { "conditionName": "condition1", "lhs": "$criteria1", "operation": "greater-than", "rhs": "10000", "operatorType": "logical", "preferred": true }, "condition2": { "conditionName": "condition2", "lhs": "$criteria2", "operation": "greater-than", "rhs": "10", "operatorType": "logical", "preferred": true }, "condition3": { "conditionName": "condition3", "lhs": "$criteria3", "operation": "greater-than", "rhs": "7000", "operatorType": "logical", "preferred": false } }, "ruleSet": { "rule1": { "ruleName": "rule1", "operator": "or", "operands": ["$condition1"], "ruleType": "simple" }, "rule2": { "ruleName": "rule2", "operator": "and", "operands": ["$condition2", "$condition3"], "ruleType": "simple" } } } }, { "name": "Silver", "code": "SIL", "order": "2", "minQualifyingMiles": 10000, "minQualifyingSegments": 10, "upgradeExpiryInMonths": "12", "downgradeExpiryInMonths": "12", "themeClass": "userClass1", "upgrade": { "type": "upgrade", "tierName": "Gold", "tierCode": "GOL", "message": "You are ${condition} away from the next tier", "criterias": { "criteria1": { "criteriaName": "criteria1", "name": "Total Qualifying Miles", "values": ["TIER", "TIERKE"], "type": "points", "uiType": "point" }, "criteria2": { "criteriaName": "criteria2", "name": "Total Qualifying Segments", "values": ["FS", "FC"], "type": "points", "uiType": "flight" }, "criteria3": { "criteriaName": "criteria3", "name": "Total KE Qualifying miles", "type": "points", "values": ["TIER"], "uiType": "point" } }, "conditions": { "condition1": { "conditionName": "condition1", "lhs": "$criteria1", "operation": "greater-than", "rhs": "40000", "operatorType": "logical", "preferred": true }, "condition2": { "conditionName": "condition2", "lhs": "$criteria2", "operation": "greater-than", "rhs": "40", "operatorType": "logical", "preferred": true }, "condition3": { "conditionName": "condition3", "lhs": "$criteria3", "operation": "greater-than", "rhs": "30000", "operatorType": "logical", "preferred": false } }, "ruleSet": { "rule1": { "ruleName": "rule1", "operator": "or", "operands": ["$condition1"], "ruleType": "simple" }, "rule2": { "ruleName": "rule2", "operator": "and", "operands": ["$condition2", "$condition3"], "ruleType": "simple" } } }, "retain": { "tierName": "Silver", "tierCode": "SIL", "type": "retain", "message": "You need ${condition} to retain ${tier} tier by ${expiryDate}", "criterias": { "criteria1": { "criteriaName": "criteria1", "name": "Total Qualifying Miles", "values": ["TIER", "TIERKE"], "type": "points", "uiType": "point" }, "criteria2": { "criteriaName": "criteria2", "name": "Total Qualifying Segments", "values": ["FS", "FC"], "type": "points", "uiType": "flight" } }, "conditions": { "condition1": { "conditionName": "condition1", "lhs": "$criteria1", "operation": "greater-than", "rhs": "10000", "operatorType": "logical", "preferred": true }, "condition2": { "conditionName": "condition2", "lhs": "$criteria2", "operation": "greater-than", "rhs": "10", "operatorType": "logical", "preferred": true } }, "ruleSet": { "rule1": { "ruleName": "rule1", "operator": "or", "operands": ["$condition1"], "ruleType": "simple" }, "rule2": { "ruleName": "rule2", "operator": "or", "operands": ["$condition2"], "ruleType": "simple" } } } }, { "name": "Gold", "code": "GOL", "order": "3", "minQualifyingMiles": 40000, "minQualifyingSegments": 40, "upgradeExpiryInMonths": "12", "downgradeExpiryInMonths": "12", "themeClass": "userClass2", "upgrade": { "tierName": "Platinum", "tierCode": "PLT", "type": "upgrade", "message": "You are ${condition} away from the next tier", "criterias": { "criteria1": { "criteriaName": "criteria1", "name": "Total Qualifying Miles", "values": ["TIER", "TIERKE"], "type": "points", "uiType": "point" }, "criteria2": { "criteriaName": "criteria2", "name": "Total Qualifying Segments", "values": ["FS", "FC"], "type": "points", "uiType": "flight" }, "criteria3": { "criteriaName": "criteria3", "name": "Total KE Qualifying miles", "type": "points", "values": ["TIER"], "uiType": "point" } }, "conditions": { "condition1": { "conditionName": "condition1", "lhs": "$criteria1", "operation": "greater-than", "rhs": "70000", "operatorType": "logical", "preferred": true }, "condition2": { "conditionName": "condition2", "lhs": "$criteria2", "operation": "greater-than", "rhs": "70", "operatorType": "logical", "preferred": true }, "condition3": { "conditionName": "condition3", "lhs": "$criteria3", "operation": "greater-than", "rhs": "50000", "operatorType": "logical", "preferred": false } }, "ruleSet": { "rule1": { "ruleName": "rule1", "operator": "or", "operands": ["$condition1"], "ruleType": "simple" }, "rule2": { "ruleName": "rule2", "operator": "and", "operands": ["$condition2", "$condition3"], "ruleType": "simple" } } }, "retain": { "tierName": "Gold", "tierCode": "GOL", "type": "retain", "message": "You need ${condition} to retain ${tier} tier by ${expiryDate}", "criterias": { "criteria1": { "criteriaName": "criteria1", "name": "Total Qualifying Miles", "values": ["TIER", "TIERKE"], "type": "points", "uiType": "point" }, "criteria2": { "criteriaName": "criteria2", "name": "Total Qualifying Segments", "values": ["FS", "FC"], "type": "points", "uiType": "flight" } }, "conditions": { "condition1": { "conditionName": "condition1", "lhs": "$criteria1", "operation": "greater-than", "rhs": "40000", "operatorType": "logical", "preferred": true }, "condition2": { "conditionName": "condition2", "lhs": "$criteria2", "operation": "greater-than", "rhs": "40", "operatorType": "logical", "preferred": true } }, "ruleSet": { "rule1": { "ruleName": "rule1", "operator": "or", "operands": ["$condition1"], "ruleType": "simple" }, "rule2": { "ruleName": "rule2", "operator": "or", "operands": ["$condition2"], "ruleType": "simple" } } } }, { "name": "Platinum", "code": "PLT", "order": "4", "minQualifyingMiles": 70000, "minQualifyingSegments": 70, "upgradeExpiryInMonths": "12", "downgradeExpiryInMonths": "12", "themeClass": "userClass3", "upgrade": { "tierName": "Diamond", "tierCode": "DIA", "type": "upgrade", "message": "You are ${condition} away from the next tier", "criterias": { "criteria1": { "criteriaName": "criteria1", "name": "Total Qualifying Miles", "values": ["TIER", "TIERKE"], "type": "points", "uiType": "point" }, "criteria2": { "criteriaName": "criteria2", "name": "Total KE Qualifying miles", "type": "points", "values": ["TIER"], "uiType": "point" } }, "conditions": { "condition1": { "conditionName": "condition1", "lhs": "$criteria1", "operation": "greater-than", "rhs": "100000", "operatorType": "logical", "preferred": true }, "condition2": { "conditionName": "condition2", "lhs": "$criteria2", "operation": "greater-than", "rhs": "70000", "operatorType": "logical", "preferred": true } }, "ruleSet": { "rule1": { "ruleName": "rule1", "operator": "and", "operands": ["$condition1", "$condition2"], "ruleType": "simple" } } }, "retain": { "tierName": "Platinum", "tierCode": "PLT", "type": "retain", "message": "You need ${condition} to retain ${tier} tier by ${expiryDate}", "criterias": { "criteria1": { "criteriaName": "criteria1", "name": "Total Qualifying Miles", "values": ["TIER", "TIERKE"], "type": "points", "uiType": "point" }, "criteria2": { "criteriaName": "criteria2", "name": "Total Qualifying Segments", "values": ["FS", "FC"], "type": "points", "uiType": "flight" } }, "conditions": { "condition1": { "conditionName": "condition1", "lhs": "$criteria1", "operation": "greater-than", "rhs": "70000", "operatorType": "logical", "preferred": true }, "condition2": { "conditionName": "condition2", "lhs": "$criteria2", "operation": "greater-than", "rhs": "70", "operatorType": "logical", "preferred": true } }, "ruleSet": { "rule1": { "ruleName": "rule1", "operator": "or", "operands": ["$condition1"], "ruleType": "simple" }, "rule2": { "ruleName": "rule2", "operator": "or", "operands": ["$condition2"], "ruleType": "simple" } } } }, { "name": "Diamond", "code": "DIA", "order": "5", "minQualifyingMiles": 100000, "minQualifyingSegments": 90, "upgradeExpiryInMonths": "12", "downgradeExpiryInMonths": "12", "themeClass": "userClass5", "retain": { "tierName": "Diamond", "tierCode": "DIA", "type": "retain", "message": "You need ${condition} to retain ${tier} tier by ${expiryDate}", "criterias": { "criteria1": { "criteriaName": "criteria1", "name": "Total Qualifying Miles", "values": ["TIER", "TIERKE"], "type": "points", "uiType": "point" } }, "conditions": { "condition1": { "conditionName": "condition1", "lhs": "$criteria1", "operation": "greater-than", "rhs": "100000", "operatorType": "logical", "preferred": true } }, "ruleSet": { "rule1": { "ruleName": "rule1", "operator": "or", "operands": ["$condition1"], "ruleType": "simple" } } } }], "currencies": [{ "code": "HKD", "name": "Hong Kong Dollar" }, { "code": "TWD", "name": "New Taiwan Dollar" }, { "code": "PHP", "name": "PESO" }, { "code": "KRW", "name": "South Korean Won" }, { "code": "USD", "name": "US Dollar" }, { "code": "VND", "name": "Vietnam Don" }, { "code": "JPY", "name": "Yen" }, { "code": "CNY", "name": "Yuan Renminbi" }], "partners": [{ "value": "KE", "name": "Korean Air" }, { "value": "DL", "name": "Delta Airlines" }, { "value": "EY", "name": "Etihad Airways" }], "cabinClasses": { "KE": [{ "cabinClassCode": "E", "cabinClassName": "Economy" }, { "cabinClassCode": "B", "cabinClassName": "Prestige" }, { "cabinClassCode": "F", "cabinClassName": "First" }] }, "cabinClassBookingClassMapping": { "KE": [{ "cabinClass": "E", "bookingClass": "B" }, { "cabinClass": "B", "bookingClass": "R" }, { "cabinClass": "F", "bookingClass": "F" }] }, "gender": [{ "key": "U", "value": "Unknown" }, { "key": "M", "value": "Male" }, { "key": "F", "value": "Female" }], "maritalStatus": [{ "key": "D", "value": "Divorced" }, { "key": "M", "value": "Married" }, { "key": "S", "value": "Single" }, { "key": "W", "value": "Widow" }], "industryType": [{ "key": "A", "value": "Airline Industry" }, { "key": "B", "value": "Business Administration" }, { "key": "C", "value": "Cooperate Communication" }, { "key": "D", "value": "Service Delivery" }, { "key": "E", "value": "Self Employment" }, { "key": "F", "value": "Forces" }, { "key": "H", "value": "Hospitality Industry" }, { "key": "I", "value": "Information technology" }, { "key": "L", "value": "Film Industry" }, { "key": "M", "value": "Medical professional" }, { "key": "N", "value": "Banking" }, { "key": "P", "value": "Apparel Industry" }, { "key": "R", "value": "Marketing" }, { "key": "S", "value": "Advisory Services" }, { "key": "T", "value": "Travel And Tourism" }, { "key": "U", "value": "Education, Academic Services" }, { "key": "X", "value": "Not Specified" }], "incomeBand": [{ "key": "1", "value": "Less than 1000 USD" }, { "key": "2", "value": "1000-2000 USD" }, { "key": "3", "value": "2001-5000 USD" }, { "key": "4", "value": "5001-10,000 USD" }, { "key": "5", "value": "Greater than 10,000 USD" }], "pointTypes": [{ "pointType": "BASE", "pointName": "Skypass Miles", "pointImage": "star" }, { "pointType": "BONUS", "pointName": "Bonus Miles", "pointImage": "star" }, { "pointType": "TIER", "pointName": "KE Qualifying Miles", "pointImage": "star" }, { "pointType": "TIERKE", "pointName": "Partner Qualifying Miles", "pointImage": "creditCard" }, { "pointType": "FS", "pointName": "KE Flights", "pointImage": "flight" }, { "pointType": "FC", "pointName": "Partner Flights", "pointImage": "flight" }, { "pointType": "CV", "pointName": "Free upgrade benefit", "pointImage": "rest" }, { "pointType": "REVENUE", "pointName": "Revenue", "pointImage": "creditCard" }] }] }