import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { withSuspense, toTitleCase, numberWithCommas } from '../../common/utils';
import { connect } from 'react-redux';
import DonutChart from '../../common/components/donutChart';
import { fetchConfiguration, fetchAccountSummary } from '../../common/middleware/redux/commonAction';
import { CONFIG_SECTION_DEFAULT, CONFIG_SECTION_OVERVIEW, PROGRAM_TYPE_CORPORATE, CONFIG_SECTION_ACCOUNT_SUMMARY } from '../../common/utils/Constants';
import { UPGRADE, RETAIN, SECTION_HEADER, SECTION_POINT_CAROUSEL, SECTION_GRAPH, SECTION_SHOP, SECTION_PROMOTIONAL, SECTION_BENEFITS, SECTION_LINKS, SECTION_FLIGHT_SEARCH } from './Constants';
import OverviewHeader from './OverviewHeader';
import OverviewTab from './OverviewTab';
import { NAVIGATE_MEMBER_MYFLIGHT, NAVIGATE_CORPORATE_MYFLIGHT } from '../../common/utils/urlConstants';
import { getMessage } from './OverviewUtils';
import MyBenefits from './MyBenefits';
import { getItemFromBrowserStorage,BROWSER_STORAGE_KEY_PROGRAM_TYPE } from '../../common/utils/storage.utils';
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';
import { _IMAGE_BASEURL } from '../../common/config/config';
import SearchFlights from '../../common/components/fieldbank/SearchFlights';

/**
 * Overview class.
 * @description The mileage overview class.
 * @author Somdas M
 */
class Overview extends Component {

  constructor(props) {
    super(props)
    this.state = {
      hasDotLine: 0 // Displays a dotted line between the upgrade and the retain tier, only when hasDotLine=2
    }
  }

  componentDidMount() {
    this.props.setPageInfo(this.props, {config: this.props.overviewConfig, confSection: CONFIG_SECTION_OVERVIEW})
    if (!this.props.accountSummaryConfig) { this.props.fetchConfiguration(CONFIG_SECTION_ACCOUNT_SUMMARY) }
    if (!this.props.accountSummary) {
      this.props.fetchAccountSummary()
    }
  }

  /**
   * @description Method to repeat the donut chart with the optionDetails for upgrade
   * @param {Array} options 
   * @param {object} tierOption 
   * @author Somdas M
   */
   renderDounutChart(options, tierOption, colors, memberTierDetails) {
    return options && options.map((option, index) => {
      const { optionDetails } = option
      return optionDetails.map((detail, idx) => {
        if (detail.preferred) {
          return <>
            {
              idx > 0 &&
              <div className="col-md-2 align-self-center">{option.operator.toUpperCase()}</div>
            }
            <div className="graph">
              <DonutChart
                currentTier={memberTierDetails.tierDetails.currentTierName}
                nextTier={memberTierDetails.tierDetails.nextTierName}
                nextTarget={parseInt(detail.next)}
                difference={parseInt(detail.diff)}
                pointsAchieved={parseInt(detail.current)}
                icon={detail.uiType}
                colors={colors}
                name={detail.name}
              />
            </div>
            {
              index < (options.length - 1) &&
              <div className="col-md-2 align-self-center">{this.props.t('overview.or')}</div>
            }
          </>
        }
      })
    })
  }

  /**
   * @description Method to render the chart and respective message for upgrade
   * @param {object} tierOption 
   * @author Somdas M
   */
  renderUpgradeData(tierOption, colors) {
    if (tierOption.type == UPGRADE) {
      if (this.state.hasDotLine == 0) {
        this.setState({
          hasDotLine: 1
        })
      }
      const { options } = tierOption
      const { t, memberTierDetails } = this.props
      return <>
        <h3 className="mb-3">{t('overview.tier_progress')}</h3>
        <div className="form-row">
          <div className="col-lg-8">
            <div className="form-row text-center">
              {
                memberTierDetails && memberTierDetails.tierDetails &&
                this.renderDounutChart(options, tierOption, colors, memberTierDetails)
              }
            </div>
          </div>
          <div className="col-lg-4 align-self-center">{getMessage(tierOption, UPGRADE, "", "", t)}</div>
        </div>
      </>
    }
  }

  /**
   * @description Method to render the Upgrade section.
   * @author Somdas M
   */
  renderUpgrade(colors, accountSummary) {
    return <>
      {
        accountSummary && accountSummary.tierOptions &&
        accountSummary.tierOptions.map((tierOption) => {
          return this.renderUpgradeData(tierOption, colors)
        })
      }
    </>
  }

  /**
   * @description Method to render the progress bar and respective message for retain
   * @param {object} tierOption 
   * @author Somdas M
   */
  renderRetainData(tierOption, accountSummary, section) {
    const { t } = this.props
    const { options } = tierOption
    if (this.state.hasDotLine == 1) {
      this.setState({
        hasDotLine: 2
      })
    }
    return <><h3>{tierOption.tierName && t('overview.to_retain_tier').replace('{RETAIN_TIERNAME}', toTitleCase(tierOption.tierName))}</h3>
      <div className="form-row">
        <div className="col-lg-8">
          <div className="form-row text-center">
            {
              options && options.map((option) => {
                const { optionDetails } = option
                return optionDetails.map((detail) => {
                  if (detail.preferred) {
                    let width = `${(detail.current / detail.next) * 100}%`
                    return <div className="col-lg-6 toRetainItems">
                      <h5>{detail.name}</h5>
                      {
                        detail.result ?
                          <div className="d-flex justify-content-between toRetainItemsNew">
                            <div className="text-left"><div><i className="fa fa-check" aria-hidden="true"></i>{numberWithCommas(parseInt(detail.current))}</div><div><span>Your current points</span></div></div>
                            <div className="text-right"><div><span>You need <strong>{numberWithCommas(parseInt(detail.next))}</strong> points to retain the tier</span></div></div>
                          </div>
                          :
                          <>
                            <div className="d-flex justify-content-between">
                              <div className="text-left">{numberWithCommas(parseInt(detail.current))}{accountSummary.tierFromDate && <span>Earned since {accountSummary.tierFromDate}</span>}</div>
                              <div className="text-right">{numberWithCommas(parseInt(detail.next))}{accountSummary.tierToDate && <span>Need by {accountSummary.tierToDate}</span>}</div>
                            </div>
                            <div>
                              <div className="progress" style={{ height: "20px" }}>
                                <div className="progress-bar" role="progressbar" style={{ width }} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                              </div>
                            </div>
                          </>
                      }
                    </div>
                  }
                })
              })
            }
          </div>
        </div>
        <div className="col-lg-4 align-self-center">{getMessage(tierOption, RETAIN, "", accountSummary.tierToDate, t)} 
        {
          section.moreDetails && 
          <a className="more">{t('overview.more_details')}</a>
        }
        </div>
      </div>
    </>
  }

  /**
   * @description Method to render the Retain section.
   * @author Somdas M
   */
  renderRetain(accountSummary, section) {
    if (accountSummary && accountSummary.tierOptions) {
      const { tierOptions } = accountSummary
      return tierOptions.map((tierOption) => {
        if (tierOption.type && tierOption.type == RETAIN) {
          return this.renderRetainData(tierOption, accountSummary, section)
        }
      })
    }
  }

  renderHeader(section) {
    const { accountSummary } = this.props
    if (accountSummary) {
      return <OverviewHeader
        firstName={accountSummary.givenName}
        lastName={accountSummary.familyName}
        tierName={accountSummary.tierName}
        section={section}
      />
    }
  }

  renderPointCarousel(section, defaultConfig) {
    const { t, memberTierDetails } = this.props
    const mainTierType = memberTierDetails && memberTierDetails.tierDetails && memberTierDetails.tierDetails.main
    const cobrandType = memberTierDetails && memberTierDetails.tierDetails && memberTierDetails.tierDetails.sub ? memberTierDetails.tierDetails.sub : ""
    const className = section.className ? section.className : "col-lg-12"
    const programType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE)
    return <>
      <div className={className}>
      <h1>{t(programType == PROGRAM_TYPE_CORPORATE?'overview.mileage_overview_corporate':'overview.mileage_overview')}
        {defaultConfig.programName}
        <strong class="text-uppercase ml-2">{memberTierDetails && memberTierDetails[mainTierType] && memberTierDetails[mainTierType].name}</strong>
        { 
          cobrandType && memberTierDetails && memberTierDetails[cobrandType] &&
          <span class={`badge-brand badge-brand${memberTierDetails.tierDetails.subThemeClass } ml-3`}>
            {memberTierDetails[cobrandType].type}
            <strong className="text-uppercase ml-1">{memberTierDetails[cobrandType].name}</strong>
          </span>
        }
        </h1>
      </div>
      <div className={className}>
        <ul className=" list-inline dashItems form-row row-cols-1 row-cols-sm-2 row-cols-md-4 row-cols-lg-5">
          <OverviewTab
            section={section}
          />
        </ul>
      </div>
    </>

  }

  renderGraph(section, accountSummary) {
    const { hasDotLine } = this.state
    return <div className={section.className ? section.className : "col-lg-9"}>
      <div className="h-100">
        {this.renderUpgrade(section.colors, accountSummary)}
        {/* <TierProgress  accountSummary={accountSummary}/> */}
        {hasDotLine > 1 && <div className="dotLine"></div>}
        {this.renderRetain(accountSummary, section)}
      </div>
    </div>
  }

  renderCart(section) {
    const { t } = this.props
    return <div className={`${section.className?section.className:"col-lg-3"} tabRight knowMoreTab`}>
      <div className="text-left"> <img src={`${_IMAGE_BASEURL}/cart.svg`} />
        <div>{t('overview.shop_with_loyalty_card_and_get_rewarded')}</div>
          {
            section.moreDetails && 
            <a className="more">{t('overview.more_details')}</a>
          }
        </div>
    </div>
  }

  navigateBooking() {
    const programType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE)
    let location = `#${NAVIGATE_MEMBER_MYFLIGHT}`
    if (programType == PROGRAM_TYPE_CORPORATE) {
      location = `#${NAVIGATE_CORPORATE_MYFLIGHT}`
    }
    return location
  }

  renderPromotional(section) {
    const { t } = this.props
    return section.fields.map((field) => {
      if (field.visibility) {
        const className = field.className ? field.className : "col-lg-12"
        return <div className={className}>
          <p>{t('overview.promotion_message')}
            <strong> {t('overview.upgrade_to_next_tier')}</strong></p>
          <a href={this.navigateBooking()} className="btn btn-primary btn-lg">{t('overview.book_a_flight')}</a>
        </div>
      }
    })
  }

  renderSearchFlight = () =>{

  }

  renderBenefits(section, defaultConfig, accountSummary) {
    const { t } = this.props
    const benefits = accountSummary.pointDetails.filter((pointDetail) => {
      if (section.pointTypeGroup && section.pointTypeGroup.includes(pointDetail.pointTypeGroup)) {
        const defaultPoint = defaultConfig.data.pointTypes.find(e => e.pointType == pointDetail.pointType)
        if (defaultPoint) {
          pointDetail["pointName"] = defaultPoint.pointName
          pointDetail["className"] = defaultPoint.className
        } else {
          pointDetail["pointName"] = pointDetail.pointType
        }
        return pointDetail
      }
    })
    return <div className={`${section.className?section.className:"col-lg-9"} tabLeft myBenafitsSec`} >
      {
        benefits && benefits.length > 0 &&
        <>
          <h2 className="d-flex justify-content-between mb-4">{t('overview.my_benefits')} 
            <div>
              {
                 section.viewAll &&
                <a className="more">{t('overview.view_all')}</a>
              }
            </div>
          </h2>
          <div className="form-row row-cols-2 row-cols-sm-2 row-cols-md-4 row-cols-lg-6">
            {
              benefits.map((pointDetail) => {
                return <MyBenefits pointDetail={pointDetail} t={t} section={section}/>
              })
            }
          </div></>
      }
    </div>
  }

  renderLinks(section) {
    const { t } = this.props
    return <div className={`${section.className?section.className:"col-lg-3"}  tabRight knowMoreTab2`}>
      <h3>{t('overview.use_miles')}</h3>
      <h4>{t('overview.reward_yourself_with_your_points')}</h4>
      <div><a className="more">{t('overview.search_for_flight')}</a></div>
      <div><a className="more">{t('overview.upgrade_with_points')}</a></div>
      <div><a className="more">{t('overview.search_hotels')}</a></div>
    </div>
  }

  render() {
    const { overviewConfig, accountSummary } = this.props
    let { defaultConfig } = this.props
    if (defaultConfig) {
      defaultConfig = getCurrentProgramFromDefaultConfig(defaultConfig)
      return (
        accountSummary && defaultConfig && overviewConfig && overviewConfig.config && overviewConfig.config.ui && overviewConfig.config.ui.layout && overviewConfig.config.ui.layout.order && overviewConfig.config.ui.layout.elements ?
          overviewConfig.config.ui.layout.order.map((order) => {
            const section = overviewConfig.config.ui.layout.elements[order]
            if (section) {
              switch (order) {
                case SECTION_HEADER: return this.renderHeader(section)
                case SECTION_POINT_CAROUSEL: return this.renderPointCarousel(section, defaultConfig)
                case SECTION_GRAPH: return this.renderGraph(section, accountSummary)
                case SECTION_SHOP: return this.renderCart(section)
                case SECTION_PROMOTIONAL: return this.renderPromotional(section)
                case SECTION_FLIGHT_SEARCH: return <SearchFlights className={section.className} />
                case SECTION_BENEFITS: return this.renderBenefits(section, defaultConfig, accountSummary)
                case SECTION_LINKS: return this.renderLinks(section)
                default: return <div></div>
              }
            }
            return <div></div>
          }) : <div></div>
      )
    } else {
      return <div></div>
    }
  }
}


function mapStateToProps(state) {
  return {
    accountSummary: state.accountSummaryReducer.accountSummary,
    defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
    overviewConfig: state.configurationReducer[CONFIG_SECTION_OVERVIEW],
    accountSummaryConfig: state.configurationReducer[CONFIG_SECTION_ACCOUNT_SUMMARY],
    memberTierDetails : state.setTierDetailsReducer.payload
  }
}

const mapDispatchToProps = { fetchAccountSummary, fetchConfiguration }

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(Overview)));