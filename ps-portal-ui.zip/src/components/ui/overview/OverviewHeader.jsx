import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { withSuspense, numberWithCommas } from '../../common/utils';
import { connect } from 'react-redux';
import {
    fetchProfileImage,
    fetchConfiguration
} from '../../common/middleware/redux/commonAction'
import { 
    getItemFromBrowserStorage, 
    BROWSER_STORAGE_KEY_COMPANY_CODE, 
    BROWSER_STORAGE_KEY_PROGRAM_CODE, 
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO 
} from '../../common/utils/storage.utils';
import { _IMAGE_BASEURL } from '../../common/config/config';

class OverviewHeader extends Component {

    componentDidMount() {
        if (!this.props.profileImage) {
            const profileImageRequest = {
                object: {
                    companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                    programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                    membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                }
            }
            this.props.fetchProfileImage(profileImageRequest)
        }
    }

    calculateTotalMiles() {
        const { accountSummary, section } = this.props
        let point = 0
        if(section && accountSummary && accountSummary.pointDetails){
            const { pointType } = section
            accountSummary.pointDetails.map((pointData) => {
                if(pointType.includes(pointData.pointType)) point += pointData.points
            })
        }
        return point;
    }

    render() {
        const { accountSummary, t, profileImage, section } = this.props
        const { givenName, familyName, tierName } = accountSummary
        return (
            accountSummary && section ?
            <div  className={section.className?section.className:"col-12"}>
                <div className="card mb-3 profileSecWrap">
                    <div className="card-body">
                        <div className="row">
                            <div className="col-lg-4 profileSec1">
                                <div className="d-flex justify-content-start">
                                    <div className="proImg"><img src={
                                        profileImage ?
                                            "data:image/" +
                                            profileImage.profileImgType +
                                            ";" +
                                            profileImage.profileImgEncoder +
                                            "," +
                                            profileImage.profileImgData
                                            : `${_IMAGE_BASEURL}/default-profile-picture.png`
                                    } alt="Profile Photo" width="75" className="rounded mx-auto d-block" /></div>
                                    <div className="ml-2">
                                        <div>{givenName} <span>{familyName}</span><em>{tierName}</em></div>
                                            {t('overview.header.ff_no')} {getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)}
                                    </div>
                                </div>
                            </div>
                                <div className="col-lg-8 d-flex justify-content-between profileSec2">
                                    {`${t('overview.header.total_miles')}: ${numberWithCommas(parseInt(this.calculateTotalMiles()))}`}
                                    <div className="profileSec3">
                                        {
                                            section && section.menuItems &&
                                            section.menuItems.map((menuItem) => {
                                                if (menuItem.visibility) {
                                                    const className = `${!menuItem.enable ? "inactive disabled" : ""} ${menuItem.className}`
                                                    return {
                                                        "header-qrcode": <a data-toggle="modal" data-target="#membercardModal" onClick={() => this.getQrCode()} data-test="qrLink"><img src={`${_IMAGE_BASEURL}/icons/digitalcard.svg`} /></a>,
                                                        "header-calculator": <a href={`#${menuItem.link}`} className={className} role="button"><img src={`${_IMAGE_BASEURL}/icons/calculator.svg`} /></a>,
                                                        "header-destination": <a href={`#${menuItem.link}`} className={className} role="button"><img src={`${_IMAGE_BASEURL}/icons/location.svg`} /></a>,
                                                        "header-notification": <a /*href={`#${menuItem.link}`}*/ className={className} role="button"><span>0</span><img src={`${_IMAGE_BASEURL}/icons/bell.svg`} /></a>
                                                    }[menuItem.id] || <div></div>
                                                }

                                            })
                                        }
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>: <div></div>

        );
    }
}

function mapStateToProps(state) {
    return {
        profileImage: state.profileImageReducer.profileImage,
        accountSummary: state.accountSummaryReducer.accountSummary
    }
}

const mapDispatchToProps = { fetchProfileImage, fetchConfiguration }

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(OverviewHeader)));