import React from 'react'; 
import { mount } from 'enzyme';
import UpdateProfile from '../updateprofile/index';
import { testStore } from '../../common/utils';
import { Provider } from 'react-redux';
import moxios from 'moxios';
import * as actions from './actions';
import setProfileData from './reducer'
import configureMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { SESSION_STORAGE_COMPANY_CODE, SESSION_STORAGE_MEMBERSHIP_NO, SESSION_STORAGE_PROGRAM_CODE } from '../../common/utils/Constants';

const middlewares = [thunk];
const mockStore = configureMockStore(middlewares);
const enrolmentDate = String('0'+new Date().toLocaleString('en-GB', {year: 'numeric', month: 'short', day: 'numeric'}).replace(/ /ig, '-')).slice(-11);

const profileConfigActionX = {
  type: 'SET_CONFIG_DATA',
  payload: {
    config: {
      section: 'profile',
      companyCode: 'IBS',
      programCode: 'PRG14',
      accountStatusCodes: {
        Unregistered: 'U',
        Active: 'A',
        Inactive: 'I',
        Suspended: 'S',
        Deleted: 'D'
      },
      operationFlags: {
        Insert: 'I',
        Update: 'U',
        Delete: 'D'
      },
      addressTypes: {
        Home: 'H',
        Business: 'B'
      },
      membershipStatusCodes: {
        Active: 'A',
        BlackListed: 'B',
        Closed: 'C',
        Deceased: 'D',
        Suspended: 'S',
        Inactive: 'I'
      },
      image: {
        maxSizeInMB: 2,
        supportedTypes: [
          'png',
          'jpg',
          'jpeg'
        ]
      },
      password: {
        pattern: '((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&.,{}()?-_=+<>*!^/]).{8,20})'
      },
      changePin: {
        securityQuestionRequired: false
      },
      qrConfig: {
        width: 350,
        height: 350,
        fields: [
          {
            fieldName: 'givenName',
            labelName: 'Member Name'
          },
          {
            fieldName: 'membershipNumber',
            labelName: 'Membership ID'
          },
          {
            fieldName: 'tierName',
            labelName: 'Tier Name'
          },
          {
            fieldName: 'tierToDate',
            labelName: 'Expiry date'
          }
        ]
      },
      dynamicAttributes: {
        updateProfile: [
          {
            attributeCode: '68',
            attributeName: 'User Id',
            attributeValue: '',
            attributeMapping: 'userId',
            type: 'C'
          },
          {
            attributeCode: '23',
            attributeName: 'English Name',
            attributeValue: '',
            attributeMapping: 'koreanName',
            type: 'P'
          },
          {
            attributeCode: '18',
            attributeName: 'Secret Question',
            attributeValue: '',
            type: 'P'
          },
          {
            attributeCode: '19',
            attributeName: 'Answer',
            attributeValue: '',
            type: 'P'
          }
        ],
        changePin: [
          {
            attributeCode: '18',
            attributeName: 'Secret Question',
            attributeValue: '',
            type: 'P'
          }
        ]
      },
      ui: {
        isLayoutSequential: false,
        image: {
          defaultAvatarMale: '',
          defaultAvatarFemale: '',
          defaultAvatarOthers: ''
        },
        layout: {
          order: [
            'basicInfo',
            'contactInfo',
            'companyInfo',
            'pinInfo',
            'securityQnInfo'
          ],
          elements: {
            basicInfo: {
              fields: [
                {
                  name: 'displayName',
                  id: '',
                  visibility: true
                },
                {
                  name: 'koreanName',
                  id: '',
                  visibility: true
                },
                {
                  name: 'givenName',
                  id: '',
                  visibility: true
                },
                {
                  name: 'familyName',
                  id: '',
                  visibility: true
                },
                {
                  name: 'dateOfBirth',
                  id: '',
                  visibility: true
                },
                {
                  name: 'gender',
                  id: '',
                  visibility: true
                }
              ]
            },
            contactInfo: {
              fields: [
                {
                  name: 'address1',
                  id: '',
                  visibility: true
                },
                {
                  name: 'address1Line1',
                  id: '',
                  visibility: true
                },
                {
                  name: 'address1PostCode',
                  id: '',
                  visibility: true
                },
                {
                  name: 'address1Ph',
                  id: '',
                  visibility: true
                },
                {
                  name: 'address1MobileISDCode',
                  id: '',
                  visibility: true
                },
                {
                  name: 'address1Mobile',
                  id: '',
                  visibility: true
                },
                {
                  name: 'address1Fax',
                  id: '',
                  visibility: true
                },
                {
                  name: 'address1Email',
                  id: '',
                  visibility: true
                }
              ]
            },
            companyInfo: {
              fields: [
                {
                  name: 'address2',
                  id: '',
                  visibility: true
                },
                {
                  name: 'address2Line1',
                  id: '',
                  visibility: true
                },
                {
                  name: 'address2PostCode',
                  id: '',
                  visibility: true
                },
                {
                  name: 'address2Ph',
                  id: '',
                  visibility: true
                },
                {
                  name: 'address2MobileISDCode',
                  id: '',
                  visibility: true
                },
                {
                  name: 'address2Mobile',
                  id: '',
                  visibility: true
                },
                {
                  name: 'address2Fax',
                  id: '',
                  visibility: true
                },
                {
                  name: 'address2Email',
                  id: '',
                  visibility: true
                }
              ]
            },
            pinInfo: {
              fields: [
                {
                  name: '',
                  id: '',
                  visibility: true
                }
              ]
            },
            securityQnInfo: {
              fields: [
                {
                  name: '',
                  id: '',
                  visibility: true
                }
              ]
            }
          }
        }
      }
    },
    type: 'profile'
  }
}

const profileConfigAction = {
  type: 'SET_CONFIG_DATA',
  payload: {
    config: {
      "section": "profile",
      "companyCode": "IBS",
      "programCode": "PRG14",
      "accountStatusCodes": {
        "Unregistered": "U",
        "Active": "A",
        "Inactive": "I",
        "Suspended": "S",
        "Deleted": "D"
      },
      "operationFlags": {
        "Insert": "I",
        "Update": "U",
        "Delete": "D"
      },
      "addressTypes": {
        "Home": "H",
        "Business": "B"
      },
      "membershipStatusCodes": {
        "Active": "A",
        "BlackListed": "B",
        "Closed": "C",
        "Deceased": "D",
        "Suspended": "S",
        "Inactive": "I"
      },
      "image": {
        "maxSizeInMB": 2,
        "supportedTypes": ["png", "jpg", "jpeg"]
      },
      "password": {
        "pattern": "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&.,{}()?-_=+<>*!^/]).{8,20})"
      },
      "qrConfig": {
        "width": 350,
        "height": 350,
        "defaultPointType": "BONUS",
        "fields": [{
          "fieldName": "givenName",
          "labelName": "Member Name"
        }, {
          "fieldName": "membershipNumber",
          "labelName": "Membership ID"
        }, {
          "fieldName": "tierName",
          "labelName": "Tier Name"
        }, {
          "fieldName": "tierToDate",
          "labelName": "Expiry date"
        }]
      },
      "dynamicAttributes": {
        "updateProfile": [{
          "attributeCode": "68",
          "attributeName": "User Id",
          "attributeValue": "",
          "attributeMapping": "userId",
          "type": "C"
        }, {
          "attributeCode": "23",
          "attributeName": "English Name",
          "attributeValue": "",
          "attributeMapping": "koreanName",
          "type": "P"
        }, {
          "attributeCode": "18",
          "attributeName": "Secret Question",
          "attributeValue": "",
          "type": "P"
        }, {
          "attributeCode": "19",
          "attributeName": "Answer",
          "attributeValue": "",
          "type": "P"
        }]
      },
      "ui": {
        "dynamicAttributesPath": "object.memberAccount.memberDynamicAttributes",
        "isLayoutSequential": false,
        "image": {
          "defaultAvatarMale": "",
          "defaultAvatarFemale": "",
          "defaultAvatarOthers": ""
        },
        "layout": {
          "order": ["basicInfo", "contactInfo", "companyInfo", "pinInfo", "securityQnInfo"],
          "elements": {
            "basicInfo": {
              "fields": [{
                "name": "displayName",
                "id": "id-displayName",
                "visibility": true,
                "required": true,
                "path": "object.memberAccount.memberProfile.individualInfo.displayName",
                "validation": {
                  "pattern": "^[ a-zA-Z0-9]{1,20}$",
                  "customMessageId": "profile.form.name"
                }
              }, {
                "name": "koreanName",
                "id": "id-koreanName",
                "visibility": true,
                "validation": {
                  "pattern": "^[ a-zA-Z]{1,20}$",
                  "customMessageId": "profile.form.kname"
                }
              }, {
                "name": "givenName",
                "id": "id-givenName",
                "visibility": true,
                "required": true,
                "path": "object.memberAccount.memberProfile.individualInfo.givenName",
                "validation": {
                  "pattern": "^[ a-zA-Z]{1,20}$",
                  "customMessageId": "profile.form.fname"
                },
                "additional": [{
                  "id": "id-title",
                  "name": "title",
                  "type": "lov",
                  "source": "master",
                  "path": "object.memberAccount.memberProfile.individualInfo.title",
                  "values": [{
                    "key": "M",
                    "value": "Male"
                  }, {
                    "key": "F",
                    "value": "Female"
                  }],
                  "sourceKey": "titleMaster",
                  "isRequired": true,
                  "validation": {
                    "pattern": "^[a-zA-Z]{1,20}$",
                    "customMessageId": "enrolment.form.title"
                  }
                }]
              }, {
                "name": "familyName",
                "id": "id-familyName",
                "visibility": true,
                "path": "object.memberAccount.memberProfile.individualInfo.familyName",
                "validation": {
                  "pattern": "^[ a-zA-Z]{1,20}$",
                  "customMessageId": "profile.form.lname"
                }
              }, {
                "name": "dateOfBirth",
                "id": "id-dateOfBirth",
                "path": "object.memberAccount.memberProfile.individualInfo.dateOfBirth",
                "visibility": true,
                "required": true,
                "validation1": {
                  "pattern": "^[0-9]{4}-[a-zA-Z]{3}-[0-9]{2}$",
                  "customMessageId": "profile.form.dob"
                }
              }, {
                "name": "gender",
                "id": "id-gender",
                "path": "object.memberAccount.memberProfile.individualInfo.gender",
                "visibility": true,
                "source": "default",
                "sourceKey": "gender",
                "required": true
              }, {
                "name": "preferredLanguage",
                "id": "id-preferred-language",
                "path": "object.memberAccount.memberProfile.individualInfo.preferredLanguage",
                "type": "lov",
                "source": "master",
                "sourceKey": "languageMaster",
                "visibility": true,
                "isRequired": true,
                "validation": {
                  "pattern": "[A-Z]{2}$",
                  "customMessageId": "enrolment.form.preferredLanguage"
                }
              }]
            },
            "contactInfo": {
              "fields": [{
                "name": "address1",
                "id": "id-address1",
                "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.0.addressLine1",
                "visibility": true
              }, {
                "name": "address1Line1",
                "id": "id-addressLine1",
                "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.0.addressLine2",
                "visibility": true
              }, {
                "name": "address1PostCode",
                "id": "id-address1PostCode",
                "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.0.zipCode",
                "visibility": true,
                "validation": {
                  "pattern": "^[0-9]{4,10}$",
                  "customMessageId": "profile.form.postcode"
                }
              }, {
                "name": "address1Ph",
                "id": "id-address1Ph",
                "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.0.phoneNumber",
                "visibility": true,
                "validation": {
                  "pattern": "^[0-9]{5,15}$",
                  "customMessageId": "form.phone.errorMessage"
                }
              }, {
                "name": "address1MobileISDCode",
                "id": "id-address1MobileISDCode",
                "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.0.mobileISDCode",
                "visibility": true
              }, {
                "name": "address1Mobile",
                "id": "id-address1Mobile",
                "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.0.mobileNumber",
                "visibility": true,
                "validation": {
                  "pattern": "^[0-9]{5,15}$",
                  "customMessageId": "form.mobileNumber.errorMessage"
                }
              }, {
                "name": "address1Fax",
                "id": "id-address1Fax",
                "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.0.faxNumber",
                "visibility": true,
                "validation": {
                  "pattern": "^[0-9]{5,15}$",
                  "customMessageId": "form.mobileNumber.errorMessage"
                }
              }, {
                "name": "memberNationality",
                "id": "id-natinality",
                "path": "object.memberAccount.memberProfile.individualInfo.memberNationality",
                "type": "lov",
                "source": "master",
                "sourceKey": "countryMaster",
                "visibility": true,
                "isRequired": true,
                "validation": {
                  "pattern": "[A-Z]{2}$",
                  "customMessageId": "enrolment.form.nationality"
                }
              }, {
                "name": "address1Email",
                "id": "id-address1Email",
                "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.0.emailAddress",
                "visibility": true,
                "validation": {
                  "pattern": "\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$",
                  "customMessageId": "form.emailAddress.errorMessage"
                }
              }]
            },
            "companyInfo": {
              "fields": [{
                "name": "companyName",
                "id": "id-company-name",
                "path": "object.memberAccount.memberProfile.individualInfo.companyName",
                "visibility": true
              }, {
                "name": "jobTitle",
                "id": "id-jobTitle",
                "path": "object.memberAccount.memberProfile.individualInfo.designation",
                "visibility": true
              }, {
                "name": "address2",
                "id": "id-address2",
                "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.1.addressLine1",
                "visibility": true
              }, {
                "name": "address2Line1",
                "id": "id-address2Line1",
                "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.1.addressLine2",
                "visibility": true
              }, {
                "name": "address2PostCode",
                "id": "id-address2PostCode",
                "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.1.zipCode",
                "visibility": true,
                "validation": {
                  "pattern": "^[0-9]{4,10}$",
                  "customMessageId": "profile.form.postcode"
                }
              }, {
                "name": "address2Ph",
                "id": "id-address2Ph",
                "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.1.phoneNumber",
                "visibility": true,
                "validation": {
                  "pattern": "^[0-9]{5,15}$",
                  "customMessageId": "form.phone.errorMessage"
                }
              }, {
                "name": "address2MobileISDCode",
                "id": "id-address2MobileISDCode",
                "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.1.mobileISDCode",
                "visibility": true
              }, {
                "name": "address2Mobile",
                "id": "id-address2Mobile",
                "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.1.mobileNumber",
                "visibility": true,
                "validation": {
                  "pattern": "^[0-9]{5,15}$",
                  "customMessageId": "form.mobileNumber.errorMessage"
                }
              }, {
                "name": "address2Fax",
                "id": "id-address2Fax",
                "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.1.faxNumber",
                "visibility": true
              }, {
                "name": "address2Email",
                "id": "id-address2Email",
                "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.1.emailAddress",
                "visibility": true,
                "validation": {
                  "pattern": "^(|\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+)$",
                  "customMessageId": "form.emailAddress.errorMessage"
                }
              }]
            },
            "pinInfo": {
              "fields": [{
                "name": "",
                "id": "",
                "visibility": true
              }]
            },
            "securityQnInfo": {
              "fields": [{
                "name": "",
                "id": "",
                "visibility": true
              }]
            }
          }
        }
      }
    }
  ,
    type: 'profile'
  }
}

const profileDataAction = {
  type: 'SET_PROFILE_DATA',
  payload: {
    object: {
      memberAccount: {
        companyCode: 'IBS',
        programCode: 'PRG14',
        membershipNumber: 'IM0008010632',
        accountStatus: 'A',
        enrolmentSource: 'W',
        enrolmentDate,
        extendToDay: '0',
        extendToMonth: '0',
        tier: 'BLU',
        tierFromDate: '17-Jul-2020',
        memberProfile: {
          membershipType: 'I',
          membershipStatus: 'A',
          individualInfo: {
            memberNationality: 'BH',
            preferredLanguage: 'EN',
            preferredAddress: 'H',
            preferredEmailAddress: 'H',
            preferredPhoneNumber: 'HP',
            title: 'MR',
            givenName: 'Paul',
            familyName: 'Gp',
            secondName: 'L',
            displayName: 'Paul GP',
            initials: 'S',
            gender: 'M',
            maritalStatus: 'M',
            dateOfBirth: '23-Oct-1990',
            passportNumber: 'M0992353',
            countryOfResidence: 'BH',
            companyName: 'UnknownCmp',
            designation: '',
            memberContactInfos: [
              {
                addressType: 'H',
                addressLine1: 'House no 70',
                addressLine2: 'Block 319',
                city: 'MA',
                state: 'SF',
                country: 'BH',
                zipCode: '26814',
                addressInvalid: false,
                emailAddress: 'paul1876@gmail.com',
                phoneISDCode: '+973',
                phoneAreaCode: '1731',
                phoneNumber: '161056',
                mobileISDCode: '+242',
                mobileAreaCode: '1731',
                mobileNumber: '4267',
                faxISDCode: '+993',
                faxAreaCode: '1630',
                faxNumber: '5678',
                skypeID: 'paul.ge90e',
                postalAddressStatus: 'V',
                phoneNumberStatus: 'V',
                mobileNumberStatus: 'V'
              },
              {
                addressType: 'B',
                addressLine1: 'House no 20',
                addressLine2: 'Block 309',
                city: 'MA',
                state: 'SF',
                country: 'BH',
                zipCode: '26814',
                addressInvalid: false,
                emailAddress: 'paul996@gmail.com',
                phoneISDCode: '+973',
                phoneAreaCode: '1731',
                phoneNumber: '161056',
                mobileISDCode: '+973',
                mobileAreaCode: '1731',
                mobileNumber: '4267',
                faxISDCode: '+993',
                faxAreaCode: '1630',
                faxNumber: '5678',
                skypeID: 'paul.george',
                postalAddressStatus: 'V',
                phoneNumberStatus: 'V',
                mobileNumberStatus: 'V'
              }
            ]
          },
          corporateInfo: null
        },
        memberDynamicAttributes: [
          {
            attributeGroupName: 'English Name',
            attributeCode: '23',
            groupInstanceID: '1',
            attributeValue: 'PAUL998',
            type: 'P'
          },
          {
            attributeGroupName: 'Security Details',
            attributeCode: '19',
            groupInstanceID: '1',
            attributeValue: 'abcdasd',
            type: 'P'
          },
          {
            attributeGroupName: 'Security Details',
            attributeCode: '18',
            groupInstanceID: '1',
            attributeValue: 'MN',
            type: 'P'
          }
        ],
        periodType: 'O',
        period: 0
      },
      paymentDetail: null
    }
  }
}

const ISDFetchAction = {
    type: 'MASTER_SET_ISD_CODES',
    payload: [
      {
        IsdCode: '+93',
        DefaultLanguage: 'EN',
        CountryName: 'AFGHANISTAN',
        PostalRegionType: 'F',
        CountryCode: 'AF'
      },
      {
        IsdCode: '+355',
        DefaultLanguage: 'EN',
        CountryName: 'ALBANIA',
        PostalRegionType: 'F',
        CountryCode: 'AL'
      },
      {
        IsdCode: '+213',
        DefaultLanguage: 'EN',
        CountryName: 'ALGERIA',
        PostalRegionType: 'F',
        CountryCode: 'DZ'
      },
      {
        IsdCode: '+684',
        DefaultLanguage: 'EN',
        CountryName: 'AMERICAN SAMOA',
        PostalRegionType: 'F',
        CountryCode: 'AS'
      },
      {
        IsdCode: '+376',
        DefaultLanguage: 'EN',
        CountryName: 'ANDORRA',
        PostalRegionType: 'F',
        CountryCode: 'AD'
      },
      {
        IsdCode: '+244',
        DefaultLanguage: 'EN',
        CountryName: 'ANGOLA',
        PostalRegionType: 'F',
        CountryCode: 'AO'
      },
      {
        IsdCode: '+264',
        DefaultLanguage: 'EN',
        CountryName: 'ANGUILLA',
        PostalRegionType: 'F',
        CountryCode: 'AI'
      },
      {
        IsdCode: '+672',
        DefaultLanguage: 'EN',
        CountryName: 'ANTARCTICA',
        PostalRegionType: 'F',
        CountryCode: 'AQ'
      },
      {
        IsdCode: '+268',
        DefaultLanguage: 'EN',
        CountryName: 'ANTIGUA AND BARBUDA',
        PostalRegionType: 'F',
        CountryCode: 'AG'
      },
      {
        IsdCode: '+54',
        DefaultLanguage: 'EN',
        CountryName: 'ARGENTINA',
        PostalRegionType: 'F',
        CountryCode: 'AR'
      },
      {
        IsdCode: '+374',
        DefaultLanguage: 'EN',
        CountryName: 'ARMENIA',
        PostalRegionType: 'F',
        CountryCode: 'AM'
      },
      {
        IsdCode: '+297',
        DefaultLanguage: 'EN',
        CountryName: 'ARUBA',
        PostalRegionType: 'F',
        CountryCode: 'AW'
      },
      {
        IsdCode: '+61',
        DefaultLanguage: 'EN',
        CountryName: 'AUSTRALIA',
        PostalRegionType: 'F',
        CountryCode: 'AU'
      },
      {
        IsdCode: '+43',
        DefaultLanguage: 'EN',
        CountryName: 'AUSTRIA',
        PostalRegionType: 'F',
        CountryCode: 'AT'
      },
      {
        IsdCode: '+994',
        DefaultLanguage: 'EN',
        CountryName: 'AZERBAIDJAN',
        PostalRegionType: 'F',
        CountryCode: 'AZ'
      },
      {
        IsdCode: '+242',
        DefaultLanguage: 'EN',
        CountryName: 'BAHAMAS',
        PostalRegionType: 'F',
        CountryCode: 'BS'
      },
      {
        IsdCode: '+973',
        DefaultLanguage: 'EN',
        CountryName: 'BAHRAIN',
        PostalRegionType: 'F',
        CountryCode: 'BH'
      },
      {
        IsdCode: '+880',
        DefaultLanguage: 'EN',
        CountryName: 'BANGLADESH',
        PostalRegionType: 'F',
        CountryCode: 'BD'
      },
      {
        IsdCode: '+246',
        DefaultLanguage: 'EN',
        CountryName: 'BARBADOS',
        PostalRegionType: 'F',
        CountryCode: 'BB'
      },
      {
        IsdCode: '+375',
        DefaultLanguage: 'EN',
        CountryName: 'BELARUS',
        PostalRegionType: 'F',
        CountryCode: 'BY'
      },
      {
        IsdCode: '+32',
        DefaultLanguage: 'EN',
        CountryName: 'BELGIUM',
        PostalRegionType: 'F',
        CountryCode: 'BE'
      },
      {
        IsdCode: '+501',
        DefaultLanguage: 'EN',
        CountryName: 'BELIZE',
        PostalRegionType: 'F',
        CountryCode: 'BZ'
      },
      {
        IsdCode: '+229',
        DefaultLanguage: 'EN',
        CountryName: 'BENIN',
        PostalRegionType: 'F',
        CountryCode: 'BJ'
      },
      {
        IsdCode: '+441',
        DefaultLanguage: 'EN',
        CountryName: 'BERMUDA',
        PostalRegionType: 'F',
        CountryCode: 'BM'
      },
      {
        IsdCode: '+975',
        DefaultLanguage: 'EN',
        CountryName: 'BHUTAN',
        PostalRegionType: 'F',
        CountryCode: 'BT'
      },
      {
        IsdCode: '+591',
        DefaultLanguage: 'EN',
        CountryName: 'BOLIVIA',
        PostalRegionType: 'F',
        CountryCode: 'BO'
      },
      {
        IsdCode: '+387',
        DefaultLanguage: 'EN',
        CountryName: 'BOSNIA-HERZEGOVINA',
        PostalRegionType: 'F',
        CountryCode: 'BA'
      },
      {
        IsdCode: '+267',
        DefaultLanguage: 'EN',
        CountryName: 'BOTSWANA',
        PostalRegionType: 'F',
        CountryCode: 'BW'
      },
      {
        IsdCode: '+47',
        DefaultLanguage: 'EN',
        CountryName: 'BOUVET ISLAND',
        PostalRegionType: 'F',
        CountryCode: 'BV'
      },
      {
        IsdCode: '+55',
        DefaultLanguage: 'EN',
        CountryName: 'BRAZIL',
        PostalRegionType: 'F',
        CountryCode: 'BR'
      },
      {
        IsdCode: '+246',
        DefaultLanguage: 'EN',
        CountryName: 'BRITISH INDIAN OCEAN TERRITORY',
        PostalRegionType: 'F',
        CountryCode: 'IO'
      },
      {
        IsdCode: '+673',
        DefaultLanguage: 'EN',
        CountryName: 'BRUNEI DARUSSALAM',
        PostalRegionType: 'F',
        CountryCode: 'BN'
      },
      {
        IsdCode: '+359',
        DefaultLanguage: 'EN',
        CountryName: 'BULGARIA',
        PostalRegionType: 'F',
        CountryCode: 'BG'
      },
      {
        IsdCode: '+226',
        DefaultLanguage: 'EN',
        CountryName: 'BURKINA FASO',
        PostalRegionType: 'F',
        CountryCode: 'BF'
      },
      {
        IsdCode: '+257',
        DefaultLanguage: 'EN',
        CountryName: 'BURUNDI',
        PostalRegionType: 'F',
        CountryCode: 'BI'
      },
      {
        IsdCode: '+855',
        DefaultLanguage: 'EN',
        CountryName: 'CAMBODIA, KINGDOM OF',
        PostalRegionType: 'F',
        CountryCode: 'KH'
      },
      {
        IsdCode: '+237',
        DefaultLanguage: 'EN',
        CountryName: 'CAMEROON',
        PostalRegionType: 'F',
        CountryCode: 'CM'
      },
      {
        IsdCode: '+1',
        DefaultLanguage: 'EN',
        CountryName: 'CANADA',
        PostalRegionType: 'F',
        CountryCode: 'CA'
      },
      {
        IsdCode: '+238',
        DefaultLanguage: 'EN',
        CountryName: 'CAPE VERDE',
        PostalRegionType: 'F',
        CountryCode: 'CV'
      },
      {
        IsdCode: '+345',
        DefaultLanguage: 'EN',
        CountryName: 'CAYMAN ISLANDS',
        PostalRegionType: 'F',
        CountryCode: 'KY'
      },
      {
        IsdCode: '+236',
        DefaultLanguage: 'EN',
        CountryName: 'CENTRAL AFRICAN REPUBLIC',
        PostalRegionType: 'F',
        CountryCode: 'CF'
      },
      {
        IsdCode: '+235',
        DefaultLanguage: 'EN',
        CountryName: 'CHAD',
        PostalRegionType: 'F',
        CountryCode: 'TD'
      },
      {
        IsdCode: '+56',
        DefaultLanguage: 'EN',
        CountryName: 'CHILE',
        PostalRegionType: 'F',
        CountryCode: 'CL'
      },
      {
        IsdCode: '+86',
        DefaultLanguage: 'EN',
        CountryName: 'CHINA',
        PostalRegionType: 'F',
        CountryCode: 'CN'
      },
      {
        IsdCode: '+61',
        DefaultLanguage: 'EN',
        CountryName: 'CHRISTMAS ISLAND',
        PostalRegionType: 'F',
        CountryCode: 'CX'
      },
      {
        IsdCode: '+61',
        DefaultLanguage: 'EN',
        CountryName: 'COCOS (KEELING) ISLANDS',
        PostalRegionType: 'F',
        CountryCode: 'CC'
      },
      {
        IsdCode: '+57',
        DefaultLanguage: 'EN',
        CountryName: 'COLOMBIA',
        PostalRegionType: 'F',
        CountryCode: 'CO'
      },
      {
        IsdCode: '+269',
        DefaultLanguage: 'EN',
        CountryName: 'COMOROS',
        PostalRegionType: 'F',
        CountryCode: 'KM'
      },
      {
        IsdCode: '+242',
        DefaultLanguage: 'EN',
        CountryName: 'CONGO',
        PostalRegionType: 'F',
        CountryCode: 'CG'
      },
      {
        IsdCode: '+682',
        DefaultLanguage: 'EN',
        CountryName: 'COOK ISLANDS',
        PostalRegionType: 'F',
        CountryCode: 'CK'
      },
      {
        IsdCode: '+506',
        DefaultLanguage: 'EN',
        CountryName: 'COSTA RICA',
        PostalRegionType: 'F',
        CountryCode: 'CR'
      },
      {
        IsdCode: '+385',
        DefaultLanguage: 'EN',
        CountryName: 'CROATIA',
        PostalRegionType: 'F',
        CountryCode: 'HR'
      },
      {
        IsdCode: '+53',
        DefaultLanguage: 'EN',
        CountryName: 'CUBA',
        PostalRegionType: 'F',
        CountryCode: 'CU'
      },
      {
        IsdCode: '+357',
        DefaultLanguage: 'EN',
        CountryName: 'CYPRUS',
        PostalRegionType: 'F',
        CountryCode: 'CY'
      },
      {
        IsdCode: '+420',
        DefaultLanguage: 'EN',
        CountryName: 'CZECH REPUBLIC',
        PostalRegionType: 'F',
        CountryCode: 'CZ'
      },
      {
        IsdCode: '+243',
        DefaultLanguage: 'EN',
        CountryName: 'DEMOCRATIC REPUBLIC OF THE CONGO',
        PostalRegionType: 'F',
        CountryCode: 'CD'
      },
      {
        IsdCode: '+45',
        DefaultLanguage: 'EN',
        CountryName: 'DENMARK',
        PostalRegionType: 'F',
        CountryCode: 'DK'
      },
      {
        IsdCode: '+253',
        DefaultLanguage: 'EN',
        CountryName: 'DJIBOUTI',
        PostalRegionType: 'F',
        CountryCode: 'DJ'
      },
      {
        IsdCode: '+767',
        DefaultLanguage: 'EN',
        CountryName: 'DOMINICA',
        PostalRegionType: 'F',
        CountryCode: 'DM'
      },
      {
        IsdCode: '+809',
        DefaultLanguage: 'EN',
        CountryName: 'DOMINICAN REPUBLIC',
        PostalRegionType: 'F',
        CountryCode: 'DO'
      },
      {
        IsdCode: '+670',
        DefaultLanguage: 'EN',
        CountryName: 'EAST TIMOR',
        PostalRegionType: 'F',
        CountryCode: 'TP'
      },
      {
        IsdCode: '+593',
        DefaultLanguage: 'EN',
        CountryName: 'ECUADOR',
        PostalRegionType: 'F',
        CountryCode: 'EC'
      },
      {
        IsdCode: '+20',
        DefaultLanguage: 'EN',
        CountryName: 'EGYPT',
        PostalRegionType: 'F',
        CountryCode: 'EG'
      },
      {
        IsdCode: '+503',
        DefaultLanguage: 'EN',
        CountryName: 'EL SALVADOR',
        PostalRegionType: 'F',
        CountryCode: 'SV'
      },
      {
        IsdCode: '+240',
        DefaultLanguage: 'EN',
        CountryName: 'EQUATORIAL GUINEA',
        PostalRegionType: 'F',
        CountryCode: 'GQ'
      },
      {
        IsdCode: '+291',
        DefaultLanguage: 'EN',
        CountryName: 'ERITREA',
        PostalRegionType: 'F',
        CountryCode: 'ER'
      },
      {
        IsdCode: '+372',
        DefaultLanguage: 'EN',
        CountryName: 'ESTONIA',
        PostalRegionType: 'F',
        CountryCode: 'EE'
      },
      {
        IsdCode: '+251',
        DefaultLanguage: 'EN',
        CountryName: 'ETHIOPIA',
        PostalRegionType: 'F',
        CountryCode: 'ET'
      },
      {
        IsdCode: '+500',
        DefaultLanguage: 'EN',
        CountryName: 'FALKLAND ISLANDS',
        PostalRegionType: 'F',
        CountryCode: 'FK'
      },
      {
        IsdCode: '+298',
        DefaultLanguage: 'EN',
        CountryName: 'FAROE ISLANDS',
        PostalRegionType: 'F',
        CountryCode: 'FO'
      },
      {
        IsdCode: '+679',
        DefaultLanguage: 'EN',
        CountryName: 'FIJI',
        PostalRegionType: 'F',
        CountryCode: 'FJ'
      },
      {
        IsdCode: '+358',
        DefaultLanguage: 'EN',
        CountryName: 'FINLAND',
        PostalRegionType: 'F',
        CountryCode: 'FI'
      },
      {
        IsdCode: '+420',
        DefaultLanguage: 'EN',
        CountryName: 'FORMER CZECHOSLOVAKIA',
        PostalRegionType: 'F',
        CountryCode: 'CS'
      },
      {
        IsdCode: '+7 ',
        DefaultLanguage: 'EN',
        CountryName: 'FORMER USSR',
        PostalRegionType: 'F',
        CountryCode: 'SU'
      },
      {
        IsdCode: '+33',
        DefaultLanguage: 'EN',
        CountryName: 'FRANCE',
        PostalRegionType: 'F',
        CountryCode: 'FR'
      },
      {
        IsdCode: '+33',
        DefaultLanguage: 'EN',
        CountryName: 'FRANCE (EUROPEAN TERRITORY)',
        PostalRegionType: 'F',
        CountryCode: 'FX'
      },
      {
        IsdCode: '+594',
        DefaultLanguage: 'EN',
        CountryName: 'FRENCH GUYANA',
        PostalRegionType: 'F',
        CountryCode: 'GF'
      },
      {
        IsdCode: '+33',
        DefaultLanguage: 'EN',
        CountryName: 'FRENCH SOUTHERN TERRITORIES',
        PostalRegionType: 'F',
        CountryCode: 'TF'
      },
      {
        IsdCode: '+241',
        DefaultLanguage: 'EN',
        CountryName: 'GABON',
        PostalRegionType: 'F',
        CountryCode: 'GA'
      },
      {
        IsdCode: '+220',
        DefaultLanguage: 'EN',
        CountryName: 'GAMBIA',
        PostalRegionType: 'F',
        CountryCode: 'GM'
      },
      {
        IsdCode: '+995',
        DefaultLanguage: 'EN',
        CountryName: 'GEORGIA',
        PostalRegionType: 'F',
        CountryCode: 'GE'
      },
      {
        IsdCode: '+49',
        DefaultLanguage: 'EN',
        CountryName: 'GERMANY',
        PostalRegionType: 'F',
        CountryCode: 'DE'
      },
      {
        IsdCode: '+233',
        DefaultLanguage: 'EN',
        CountryName: 'GHANA',
        PostalRegionType: 'F',
        CountryCode: 'GH'
      },
      {
        IsdCode: '+350',
        DefaultLanguage: 'EN',
        CountryName: 'GIBRALTAR',
        PostalRegionType: 'F',
        CountryCode: 'GI'
      },
      {
        IsdCode: '+44',
        DefaultLanguage: 'EN',
        CountryName: 'GREAT BRITAIN',
        PostalRegionType: 'F',
        CountryCode: 'GB'
      },
      {
        IsdCode: '+30',
        DefaultLanguage: 'EN',
        CountryName: 'GREECE',
        PostalRegionType: 'F',
        CountryCode: 'GR'
      },
      {
        IsdCode: '+299',
        DefaultLanguage: 'EN',
        CountryName: 'GREENLAND',
        PostalRegionType: 'F',
        CountryCode: 'GL'
      },
      {
        IsdCode: '+473',
        DefaultLanguage: 'EN',
        CountryName: 'GRENADA',
        PostalRegionType: 'F',
        CountryCode: 'GD'
      },
      {
        IsdCode: '+590',
        DefaultLanguage: 'EN',
        CountryName: 'GUADELOUPE (FRENCH)',
        PostalRegionType: 'F',
        CountryCode: 'GP'
      },
      {
        IsdCode: '+670',
        DefaultLanguage: 'EN',
        CountryName: 'GUAM (USA)',
        PostalRegionType: 'F',
        CountryCode: 'GU'
      },
      {
        IsdCode: '+502',
        DefaultLanguage: 'EN',
        CountryName: 'GUATEMALA',
        PostalRegionType: 'F',
        CountryCode: 'GT'
      },
      {
        IsdCode: '+224',
        DefaultLanguage: 'EN',
        CountryName: 'GUINEA',
        PostalRegionType: 'F',
        CountryCode: 'GN'
      },
      {
        IsdCode: '+245',
        DefaultLanguage: 'EN',
        CountryName: 'GUINEA BISSAU',
        PostalRegionType: 'F',
        CountryCode: 'GW'
      },
      {
        IsdCode: '+592',
        DefaultLanguage: 'EN',
        CountryName: 'GUYANA',
        PostalRegionType: 'F',
        CountryCode: 'GY'
      },
      {
        IsdCode: '+509',
        DefaultLanguage: 'EN',
        CountryName: 'HAITI',
        PostalRegionType: 'F',
        CountryCode: 'HT'
      },
      {
        IsdCode: '+61',
        DefaultLanguage: 'EN',
        CountryName: 'HEARD AND MCDONALD ISLANDS',
        PostalRegionType: 'F',
        CountryCode: 'HM'
      },
      {
        IsdCode: '+39',
        DefaultLanguage: 'EN',
        CountryName: 'HOLY SEE (VATICAN CITY STATE)',
        PostalRegionType: 'F',
        CountryCode: 'VA'
      },
      {
        IsdCode: '+504',
        DefaultLanguage: 'EN',
        CountryName: 'HONDURAS',
        PostalRegionType: 'F',
        CountryCode: 'HN'
      },
      {
        IsdCode: '+852',
        DefaultLanguage: 'EN',
        CountryName: 'HONG KONG',
        PostalRegionType: 'F',
        CountryCode: 'HK'
      },
      {
        IsdCode: '+36',
        DefaultLanguage: 'EN',
        CountryName: 'HUNGARY',
        PostalRegionType: 'F',
        CountryCode: 'HU'
      },
      {
        IsdCode: '+354',
        DefaultLanguage: 'EN',
        CountryName: 'ICELAND',
        PostalRegionType: 'F',
        CountryCode: 'IS'
      },
      {
        IsdCode: '+91',
        DefaultLanguage: 'EN',
        CountryName: 'INDIA',
        PostalRegionType: 'F',
        CountryCode: 'IN'
      },
      {
        IsdCode: '+62',
        DefaultLanguage: 'EN',
        CountryName: 'INDONESIA',
        PostalRegionType: 'F',
        CountryCode: 'ID'
      },
      {
        IsdCode: '+98',
        DefaultLanguage: 'EN',
        CountryName: 'IRAN',
        PostalRegionType: 'F',
        CountryCode: 'IR'
      },
      {
        IsdCode: '+964',
        DefaultLanguage: 'EN',
        CountryName: 'IRAQ',
        PostalRegionType: 'F',
        CountryCode: 'IQ'
      },
      {
        IsdCode: '+353',
        DefaultLanguage: 'EN',
        CountryName: 'IRELAND',
        PostalRegionType: 'F',
        CountryCode: 'IE'
      },
      {
        IsdCode: '+972',
        DefaultLanguage: 'EN',
        CountryName: 'ISRAEL',
        PostalRegionType: 'F',
        CountryCode: 'IL'
      },
      {
        IsdCode: '+39',
        DefaultLanguage: 'EN',
        CountryName: 'ITALY',
        PostalRegionType: 'F',
        CountryCode: 'IT'
      },
      {
        IsdCode: '+225',
        DefaultLanguage: 'EN',
        CountryName: 'IVORY COAST',
        PostalRegionType: 'F',
        CountryCode: 'CI'
      },
      {
        IsdCode: '+876',
        DefaultLanguage: 'EN',
        CountryName: 'JAMAICA',
        PostalRegionType: 'F',
        CountryCode: 'JM'
      },
      {
        IsdCode: '+81',
        DefaultLanguage: 'EN',
        CountryName: 'JAPAN',
        PostalRegionType: 'F',
        CountryCode: 'JP'
      },
      {
        IsdCode: '+962',
        DefaultLanguage: 'EN',
        CountryName: 'JORDAN',
        PostalRegionType: 'F',
        CountryCode: 'JO'
      },
      {
        IsdCode: '+7',
        DefaultLanguage: 'EN',
        CountryName: 'KAZAKHSTAN',
        PostalRegionType: 'F',
        CountryCode: 'KZ'
      },
      {
        IsdCode: '+254',
        DefaultLanguage: 'EN',
        CountryName: 'KENYA',
        PostalRegionType: 'F',
        CountryCode: 'KE'
      },
      {
        IsdCode: '+686',
        DefaultLanguage: 'EN',
        CountryName: 'KIRIBATI',
        PostalRegionType: 'F',
        CountryCode: 'KI'
      },
      {
        IsdCode: '+965',
        DefaultLanguage: 'EN',
        CountryName: 'KUWAIT',
        PostalRegionType: 'F',
        CountryCode: 'KW'
      },
      {
        IsdCode: '+996',
        DefaultLanguage: 'EN',
        CountryName: 'KYRGYZ REPUBLIC (KYRGYZSTAN)',
        PostalRegionType: 'F',
        CountryCode: 'KG'
      },
      {
        IsdCode: '+856',
        DefaultLanguage: 'EN',
        CountryName: 'LAOS',
        PostalRegionType: 'F',
        CountryCode: 'LA'
      },
      {
        IsdCode: '+371',
        DefaultLanguage: 'EN',
        CountryName: 'LATVIA',
        PostalRegionType: 'F',
        CountryCode: 'LV'
      },
      {
        IsdCode: '+961',
        DefaultLanguage: 'EN',
        CountryName: 'LEBANON',
        PostalRegionType: 'F',
        CountryCode: 'LB'
      },
      {
        IsdCode: '+266',
        DefaultLanguage: 'EN',
        CountryName: 'LESOTHO',
        PostalRegionType: 'F',
        CountryCode: 'LS'
      },
      {
        IsdCode: '+231',
        DefaultLanguage: 'EN',
        CountryName: 'LIBERIA',
        PostalRegionType: 'F',
        CountryCode: 'LR'
      },
      {
        IsdCode: '+218',
        DefaultLanguage: 'EN',
        CountryName: 'LIBYA',
        PostalRegionType: 'F',
        CountryCode: 'LY'
      },
      {
        IsdCode: '+41',
        DefaultLanguage: 'EN',
        CountryName: 'LIECHTENSTEIN',
        PostalRegionType: 'F',
        CountryCode: 'LI'
      },
      {
        IsdCode: '+370',
        DefaultLanguage: 'EN',
        CountryName: 'LITHUANIA',
        PostalRegionType: 'F',
        CountryCode: 'LT'
      },
      {
        IsdCode: '+352',
        DefaultLanguage: 'EN',
        CountryName: 'LUXEMBOURG',
        PostalRegionType: 'F',
        CountryCode: 'LU'
      },
      {
        IsdCode: '+853',
        DefaultLanguage: 'EN',
        CountryName: 'MACAU',
        PostalRegionType: 'F',
        CountryCode: 'MO'
      },
      {
        IsdCode: '+389',
        DefaultLanguage: 'EN',
        CountryName: 'MACEDONIA',
        PostalRegionType: 'F',
        CountryCode: 'MK'
      },
      {
        IsdCode: '+261',
        DefaultLanguage: 'EN',
        CountryName: 'MADAGASCAR',
        PostalRegionType: 'F',
        CountryCode: 'MG'
      },
      {
        IsdCode: '+265',
        DefaultLanguage: 'EN',
        CountryName: 'MALAWI',
        PostalRegionType: 'F',
        CountryCode: 'MW'
      },
      {
        IsdCode: '+60',
        DefaultLanguage: 'EN',
        CountryName: 'MALAYSIA',
        PostalRegionType: 'F',
        CountryCode: 'MY'
      },
      {
        IsdCode: '+960',
        DefaultLanguage: 'EN',
        CountryName: 'MALDIVES',
        PostalRegionType: 'F',
        CountryCode: 'MV'
      },
      {
        IsdCode: '+223',
        DefaultLanguage: 'EN',
        CountryName: 'MALI',
        PostalRegionType: 'F',
        CountryCode: 'ML'
      },
      {
        IsdCode: '+356',
        DefaultLanguage: 'EN',
        CountryName: 'MALTA',
        PostalRegionType: 'F',
        CountryCode: 'MT'
      },
      {
        IsdCode: '+692',
        DefaultLanguage: 'EN',
        CountryName: 'MARSHALL ISLANDS',
        PostalRegionType: 'F',
        CountryCode: 'MH'
      },
      {
        IsdCode: '+596',
        DefaultLanguage: 'EN',
        CountryName: 'MARTINIQUE (FRENCH)',
        PostalRegionType: 'F',
        CountryCode: 'MQ'
      },
      {
        IsdCode: '+222',
        DefaultLanguage: 'EN',
        CountryName: 'MAURITANIA',
        PostalRegionType: 'F',
        CountryCode: 'MR'
      },
      {
        IsdCode: '+230',
        DefaultLanguage: 'EN',
        CountryName: 'MAURITIUS',
        PostalRegionType: 'F',
        CountryCode: 'MU'
      },
      {
        IsdCode: '+269',
        DefaultLanguage: 'EN',
        CountryName: 'MAYOTTE',
        PostalRegionType: 'F',
        CountryCode: 'YT'
      },
      {
        IsdCode: '+52',
        DefaultLanguage: 'EN',
        CountryName: 'MEXICO',
        PostalRegionType: 'F',
        CountryCode: 'MX'
      },
      {
        IsdCode: '+691',
        DefaultLanguage: 'EN',
        CountryName: 'MICRONESIA',
        PostalRegionType: 'F',
        CountryCode: 'FM'
      },
      {
        IsdCode: '+373 ',
        DefaultLanguage: 'EN',
        CountryName: 'MOLDAVIA',
        PostalRegionType: 'F',
        CountryCode: 'MD'
      },
      {
        IsdCode: '+377',
        DefaultLanguage: 'EN',
        CountryName: 'MONACO',
        PostalRegionType: 'F',
        CountryCode: 'MC'
      },
      {
        IsdCode: '+976',
        DefaultLanguage: 'EN',
        CountryName: 'MONGOLIA',
        PostalRegionType: 'F',
        CountryCode: 'MN'
      },
      {
        IsdCode: '+382',
        DefaultLanguage: 'EN',
        CountryName: 'MONTENEGRO',
        PostalRegionType: 'F',
        CountryCode: 'ME'
      },
      {
        IsdCode: '+664',
        DefaultLanguage: 'EN',
        CountryName: 'MONTSERRAT',
        PostalRegionType: 'F',
        CountryCode: 'MS'
      },
      {
        IsdCode: '+212',
        DefaultLanguage: 'EN',
        CountryName: 'MOROCCO',
        PostalRegionType: 'F',
        CountryCode: 'MA'
      },
      {
        IsdCode: '+258',
        DefaultLanguage: 'EN',
        CountryName: 'MOZAMBIQUE',
        PostalRegionType: 'F',
        CountryCode: 'MZ'
      },
      {
        IsdCode: '+95',
        DefaultLanguage: 'EN',
        CountryName: 'MYANMAR',
        PostalRegionType: 'F',
        CountryCode: 'MM'
      },
      {
        IsdCode: '+264',
        DefaultLanguage: 'EN',
        CountryName: 'NAMIBIA',
        PostalRegionType: 'F',
        CountryCode: 'NA'
      },
      {
        IsdCode: '+674',
        DefaultLanguage: 'EN',
        CountryName: 'NAURU',
        PostalRegionType: 'F',
        CountryCode: 'NR'
      },
      {
        IsdCode: '+977',
        DefaultLanguage: 'EN',
        CountryName: 'NEPAL',
        PostalRegionType: 'F',
        CountryCode: 'NP'
      },
      {
        IsdCode: '+31',
        DefaultLanguage: 'EN',
        CountryName: 'NETHERLANDS',
        PostalRegionType: 'F',
        CountryCode: 'NL'
      },
      {
        IsdCode: '+599',
        DefaultLanguage: 'EN',
        CountryName: 'NETHERLANDS ANTILLES',
        PostalRegionType: 'F',
        CountryCode: 'AN'
      },
      {
        IsdCode: '+687',
        DefaultLanguage: 'EN',
        CountryName: 'NEW CALEDONIA (FRENCH)',
        PostalRegionType: 'F',
        CountryCode: 'NC'
      },
      {
        IsdCode: '+64',
        DefaultLanguage: 'EN',
        CountryName: 'NEW ZEALAND',
        PostalRegionType: 'F',
        CountryCode: 'NZ'
      },
      {
        IsdCode: '+505',
        DefaultLanguage: 'EN',
        CountryName: 'NICARAGUA',
        PostalRegionType: 'F',
        CountryCode: 'NI'
      },
      {
        IsdCode: '+227',
        DefaultLanguage: 'EN',
        CountryName: 'NIGER',
        PostalRegionType: 'F',
        CountryCode: 'NE'
      },
      {
        IsdCode: '+234',
        DefaultLanguage: 'EN',
        CountryName: 'NIGERIA',
        PostalRegionType: 'F',
        CountryCode: 'NG'
      },
      {
        IsdCode: '+683',
        DefaultLanguage: 'EN',
        CountryName: 'NIUE',
        PostalRegionType: 'F',
        CountryCode: 'NU'
      },
      {
        IsdCode: '+672',
        DefaultLanguage: 'EN',
        CountryName: 'NORFOLK ISLAND',
        PostalRegionType: 'F',
        CountryCode: 'NF'
      },
      {
        IsdCode: '+850',
        DefaultLanguage: 'EN',
        CountryName: 'NORTH KOREA',
        PostalRegionType: 'F',
        CountryCode: 'KP'
      },
      {
        IsdCode: '+670 ',
        DefaultLanguage: 'EN',
        CountryName: 'NORTHERN MARIANA ISLANDS',
        PostalRegionType: 'F',
        CountryCode: 'MP'
      },
      {
        IsdCode: '+47',
        DefaultLanguage: 'EN',
        CountryName: 'NORWAY',
        PostalRegionType: 'F',
        CountryCode: 'NO'
      },
      {
        IsdCode: '+968',
        DefaultLanguage: 'EN',
        CountryName: 'OMAN',
        PostalRegionType: 'F',
        CountryCode: 'WY'
      },
      {
        IsdCode: '+968',
        DefaultLanguage: 'EN',
        CountryName: 'OMAN',
        PostalRegionType: 'F',
        CountryCode: 'OM'
      },
      {
        IsdCode: '+92',
        DefaultLanguage: 'EN',
        CountryName: 'PAKISTAN',
        PostalRegionType: 'F',
        CountryCode: 'PK'
      },
      {
        IsdCode: '+680',
        DefaultLanguage: 'EN',
        CountryName: 'PALAU',
        PostalRegionType: 'F',
        CountryCode: 'PW'
      },
      {
        IsdCode: '+970',
        DefaultLanguage: 'EN',
        CountryName: 'PALESTINIAN TERRITORY',
        PostalRegionType: 'F',
        CountryCode: 'PS'
      },
      {
        IsdCode: '+507',
        DefaultLanguage: 'EN',
        CountryName: 'PANAMA',
        PostalRegionType: 'F',
        CountryCode: 'PA'
      },
      {
        IsdCode: '+675',
        DefaultLanguage: 'EN',
        CountryName: 'PAPUA NEW GUINEA',
        PostalRegionType: 'F',
        CountryCode: 'PG'
      },
      {
        IsdCode: '+595',
        DefaultLanguage: 'EN',
        CountryName: 'PARAGUAY',
        PostalRegionType: 'F',
        CountryCode: 'PY'
      },
      {
        IsdCode: '+51',
        DefaultLanguage: 'EN',
        CountryName: 'PERU',
        PostalRegionType: 'F',
        CountryCode: 'PE'
      },
      {
        IsdCode: '+63',
        DefaultLanguage: 'EN',
        CountryName: 'PHILIPPINES',
        PostalRegionType: 'F',
        CountryCode: 'PH'
      },
      {
        IsdCode: '+649 ',
        DefaultLanguage: 'EN',
        CountryName: 'PITCAIRN ISLAND',
        PostalRegionType: 'F',
        CountryCode: 'PN'
      },
      {
        IsdCode: '+48',
        DefaultLanguage: 'EN',
        CountryName: 'POLAND',
        PostalRegionType: 'F',
        CountryCode: 'PL'
      },
      {
        IsdCode: '+689',
        DefaultLanguage: 'EN',
        CountryName: 'POLYNESIA (FRENCH)',
        PostalRegionType: 'F',
        CountryCode: 'PF'
      },
      {
        IsdCode: '+351 ',
        DefaultLanguage: 'EN',
        CountryName: 'PORTUGAL',
        PostalRegionType: 'F',
        CountryCode: 'PT'
      },
      {
        IsdCode: '+787',
        DefaultLanguage: 'EN',
        CountryName: 'PUERTO RICO',
        PostalRegionType: 'F',
        CountryCode: 'PR'
      },
      {
        IsdCode: '+675 ',
        DefaultLanguage: 'EN',
        CountryName: 'Papaua New Guinea',
        PostalRegionType: 'F',
        CountryCode: 'PNG'
      },
      {
        IsdCode: '+974',
        DefaultLanguage: 'EN',
        CountryName: 'QATAR',
        PostalRegionType: 'F',
        CountryCode: 'QA'
      },
      {
        IsdCode: '+262',
        DefaultLanguage: 'EN',
        CountryName: 'REUNION (FRENCH)',
        PostalRegionType: 'F',
        CountryCode: 'RE'
      },
      {
        IsdCode: '+40',
        DefaultLanguage: 'EN',
        CountryName: 'ROMANIA',
        PostalRegionType: 'F',
        CountryCode: 'RO'
      },
      {
        IsdCode: '+7',
        DefaultLanguage: 'EN',
        CountryName: 'RUSSIAN FEDERATION',
        PostalRegionType: 'F',
        CountryCode: 'XU'
      },
      {
        IsdCode: '+7',
        DefaultLanguage: 'EN',
        CountryName: 'RUSSIAN FEDERATION',
        PostalRegionType: 'F',
        CountryCode: 'RU'
      },
      {
        IsdCode: '+250',
        DefaultLanguage: 'EN',
        CountryName: 'RWANDA',
        PostalRegionType: 'F',
        CountryCode: 'RW'
      },
      {
        IsdCode: '+290',
        DefaultLanguage: 'EN',
        CountryName: 'SAINT HELENA',
        PostalRegionType: 'F',
        CountryCode: 'SH'
      },
      {
        IsdCode: '+758',
        DefaultLanguage: 'EN',
        CountryName: 'SAINT LUCIA',
        PostalRegionType: 'F',
        CountryCode: 'LC'
      },
      {
        IsdCode: '+508',
        DefaultLanguage: 'EN',
        CountryName: 'SAINT PIERRE AND MIQUELON',
        PostalRegionType: 'F',
        CountryCode: 'PM'
      },
      {
        IsdCode: '+809',
        DefaultLanguage: 'EN',
        CountryName: 'SAINT VIN-GREN',
        PostalRegionType: 'F',
        CountryCode: 'VC'
      },
      {
        IsdCode: '+685',
        DefaultLanguage: 'EN',
        CountryName: 'SAMOA',
        PostalRegionType: 'F',
        CountryCode: 'WS'
      },
      {
        IsdCode: '+378',
        DefaultLanguage: 'EN',
        CountryName: 'SAN MARINO',
        PostalRegionType: 'F',
        CountryCode: 'SM'
      },
      {
        IsdCode: '+239',
        DefaultLanguage: 'EN',
        CountryName: 'SAO TOME AND PRINCIPE',
        PostalRegionType: 'F',
        CountryCode: 'ST'
      },
      {
        IsdCode: '+966',
        DefaultLanguage: 'EN',
        CountryName: 'SAUDI ARABIA',
        PostalRegionType: 'F',
        CountryCode: 'SA'
      },
      {
        IsdCode: '+221',
        DefaultLanguage: 'EN',
        CountryName: 'SENEGAL',
        PostalRegionType: 'F',
        CountryCode: 'SN'
      },
      {
        IsdCode: '+381',
        DefaultLanguage: 'EN',
        CountryName: 'SERBIA',
        PostalRegionType: 'F',
        CountryCode: 'RS'
      },
      {
        IsdCode: '+248',
        DefaultLanguage: 'EN',
        CountryName: 'SEYCHELLES',
        PostalRegionType: 'F',
        CountryCode: 'SC'
      },
      {
        IsdCode: '+232',
        DefaultLanguage: 'EN',
        CountryName: 'SIERRA LEONE',
        PostalRegionType: 'F',
        CountryCode: 'SL'
      },
      {
        IsdCode: '+65',
        DefaultLanguage: 'EN',
        CountryName: 'SINGAPORE',
        PostalRegionType: 'F',
        CountryCode: 'SG'
      },
      {
        IsdCode: '+421',
        DefaultLanguage: 'EN',
        CountryName: 'SLOVAK REPUBLIC',
        PostalRegionType: 'F',
        CountryCode: 'SK'
      },
      {
        IsdCode: '+386',
        DefaultLanguage: 'EN',
        CountryName: 'SLOVENIA',
        PostalRegionType: 'F',
        CountryCode: 'SI'
      },
      {
        IsdCode: '+677',
        DefaultLanguage: 'EN',
        CountryName: 'SOLOMON ISLANDS',
        PostalRegionType: 'F',
        CountryCode: 'SB'
      },
      {
        IsdCode: '+252',
        DefaultLanguage: 'EN',
        CountryName: 'SOMALIA',
        PostalRegionType: 'F',
        CountryCode: 'SO'
      },
      {
        IsdCode: '+27',
        DefaultLanguage: 'EN',
        CountryName: 'SOUTH AFRICA',
        PostalRegionType: 'F',
        CountryCode: 'ZA'
      },
      {
        IsdCode: '+82',
        DefaultLanguage: 'EN',
        CountryName: 'SOUTH KOREA',
        PostalRegionType: 'F',
        CountryCode: 'KR'
      },
      {
        IsdCode: '+34',
        DefaultLanguage: 'EN',
        CountryName: 'SPAIN',
        PostalRegionType: 'F',
        CountryCode: 'ES'
      },
      {
        IsdCode: '+94',
        DefaultLanguage: 'EN',
        CountryName: 'SRI LANKA',
        PostalRegionType: 'F',
        CountryCode: 'LK'
      },
      {
        IsdCode: '+869',
        DefaultLanguage: 'EN',
        CountryName: 'ST KITTS-NEVIS',
        PostalRegionType: 'F',
        CountryCode: 'KN'
      },
      {
        IsdCode: '+249',
        DefaultLanguage: 'EN',
        CountryName: 'SUDAN',
        PostalRegionType: 'F',
        CountryCode: 'SD'
      },
      {
        IsdCode: '+597',
        DefaultLanguage: 'EN',
        CountryName: 'SURINAME',
        PostalRegionType: 'F',
        CountryCode: 'SR'
      },
      {
        IsdCode: '+47 ',
        DefaultLanguage: 'EN',
        CountryName: 'SVALBARD AND JAN MAYEN ISLANDS',
        PostalRegionType: 'F',
        CountryCode: 'SJ'
      },
      {
        IsdCode: '+268',
        DefaultLanguage: 'EN',
        CountryName: 'SWAZILAND',
        PostalRegionType: 'F',
        CountryCode: 'SZ'
      },
      {
        IsdCode: '+46',
        DefaultLanguage: 'EN',
        CountryName: 'SWEDEN',
        PostalRegionType: 'F',
        CountryCode: 'SE'
      },
      {
        IsdCode: '+41',
        DefaultLanguage: 'EN',
        CountryName: 'SWITZERLAND',
        PostalRegionType: 'F',
        CountryCode: 'CH'
      },
      {
        IsdCode: '+963',
        DefaultLanguage: 'EN',
        CountryName: 'SYRIA',
        PostalRegionType: 'F',
        CountryCode: 'SY'
      },
      {
        IsdCode: '+7',
        DefaultLanguage: 'EN',
        CountryName: 'TADJIKISTAN',
        PostalRegionType: 'F',
        CountryCode: 'TJ'
      },
      {
        IsdCode: '+886',
        DefaultLanguage: 'EN',
        CountryName: 'TAIWAN',
        PostalRegionType: 'F',
        CountryCode: 'TW'
      },
      {
        IsdCode: '+255',
        DefaultLanguage: 'EN',
        CountryName: 'TANZANIA',
        PostalRegionType: 'F',
        CountryCode: 'TZ'
      },
      {
        IsdCode: '+66',
        DefaultLanguage: 'EN',
        CountryName: 'THAILAND',
        PostalRegionType: 'F',
        CountryCode: 'TH'
      },
      {
        IsdCode: '+228',
        DefaultLanguage: 'EN',
        CountryName: 'TOGO',
        PostalRegionType: 'F',
        CountryCode: 'TG'
      },
      {
        IsdCode: '+690',
        DefaultLanguage: 'EN',
        CountryName: 'TOKELAU',
        PostalRegionType: 'F',
        CountryCode: 'TK'
      },
      {
        IsdCode: '+676',
        DefaultLanguage: 'EN',
        CountryName: 'TONGA',
        PostalRegionType: 'F',
        CountryCode: 'TO'
      },
      {
        IsdCode: '+868',
        DefaultLanguage: 'EN',
        CountryName: 'TRINIDAD AND TOBAGO',
        PostalRegionType: 'F',
        CountryCode: 'TT'
      },
      {
        IsdCode: '+216',
        DefaultLanguage: 'EN',
        CountryName: 'TUNISIA',
        PostalRegionType: 'F',
        CountryCode: 'TN'
      },
      {
        IsdCode: '+90',
        DefaultLanguage: 'EN',
        CountryName: 'TURKEY',
        PostalRegionType: 'F',
        CountryCode: 'TR'
      },
      {
        IsdCode: '+993',
        DefaultLanguage: 'EN',
        CountryName: 'TURKMENISTAN',
        PostalRegionType: 'F',
        CountryCode: 'TM'
      },
      {
        IsdCode: '+649',
        DefaultLanguage: 'EN',
        CountryName: 'TURKS AND CAICOS ISLANDS',
        PostalRegionType: 'F',
        CountryCode: 'TC'
      },
      {
        IsdCode: '+688',
        DefaultLanguage: 'EN',
        CountryName: 'TUVALU',
        PostalRegionType: 'F',
        CountryCode: 'TV'
      },
      {
        IsdCode: '+256',
        DefaultLanguage: 'EN',
        CountryName: 'UGANDA',
        PostalRegionType: 'F',
        CountryCode: 'UG'
      },
      {
        IsdCode: '+380',
        DefaultLanguage: 'EN',
        CountryName: 'UKRAINE',
        PostalRegionType: 'F',
        CountryCode: 'UA'
      },
      {
        IsdCode: '+971',
        DefaultLanguage: 'EN',
        CountryName: 'UNITED ARAB EMIRATES',
        PostalRegionType: 'F',
        CountryCode: 'AE'
      },
      {
        IsdCode: '+44',
        DefaultLanguage: 'EN',
        CountryName: 'UNITED KINGDOM',
        PostalRegionType: 'F',
        CountryCode: 'UK'
      },
      {
        IsdCode: '+1',
        DefaultLanguage: 'EN',
        CountryName: 'UNITED STATES',
        PostalRegionType: 'F',
        CountryCode: 'US'
      },
      {
        IsdCode: '+598',
        DefaultLanguage: 'EN',
        CountryName: 'URUGUAY',
        PostalRegionType: 'F',
        CountryCode: 'UY'
      },
      {
        IsdCode: '+1',
        DefaultLanguage: 'EN',
        CountryName: 'USA MINOR OUTLYING ISLANDS',
        PostalRegionType: 'F',
        CountryCode: 'UM'
      },
      {
        IsdCode: '+998',
        DefaultLanguage: 'EN',
        CountryName: 'UZBEKISTAN',
        PostalRegionType: 'F',
        CountryCode: 'UZ'
      },
      {
        IsdCode: '+999',
        DefaultLanguage: 'EN',
        CountryName: 'Unknown',
        PostalRegionType: 'F',
        CountryCode: 'XX'
      },
      {
        IsdCode: '+678',
        DefaultLanguage: 'EN',
        CountryName: 'VANUATU',
        PostalRegionType: 'F',
        CountryCode: 'VU'
      },
      {
        IsdCode: '+58',
        DefaultLanguage: 'EN',
        CountryName: 'VENEZUELA',
        PostalRegionType: 'F',
        CountryCode: 'VE'
      },
      {
        IsdCode: '+84',
        DefaultLanguage: 'EN',
        CountryName: 'VIETNAM',
        PostalRegionType: 'F',
        CountryCode: 'VN'
      },
      {
        IsdCode: '+284 ',
        DefaultLanguage: 'EN',
        CountryName: 'VIRGIN ISLANDS (BRITISH)',
        PostalRegionType: 'F',
        CountryCode: 'VG'
      },
      {
        IsdCode: '+340 ',
        DefaultLanguage: 'EN',
        CountryName: 'VIRGIN ISLANDS (USA)',
        PostalRegionType: 'F',
        CountryCode: 'VI'
      },
      {
        IsdCode: '+681',
        DefaultLanguage: 'EN',
        CountryName: 'WALLIS AND FUTUNA ISLANDS',
        PostalRegionType: 'F',
        CountryCode: 'WF'
      },
      {
        IsdCode: '+808',
        DefaultLanguage: 'EN',
        CountryName: 'WESTERN SAHARA',
        PostalRegionType: 'F',
        CountryCode: 'EH'
      },
      {
        IsdCode: '+967',
        DefaultLanguage: 'EN',
        CountryName: 'YEMEN',
        PostalRegionType: 'F',
        CountryCode: 'YE'
      },
      {
        IsdCode: '+381',
        DefaultLanguage: 'EN',
        CountryName: 'YUGOSLAVIA',
        PostalRegionType: 'F',
        CountryCode: 'YU'
      },
      {
        IsdCode: '+243',
        DefaultLanguage: 'EN',
        CountryName: 'ZAIRE',
        PostalRegionType: 'F',
        CountryCode: 'ZR'
      },
      {
        IsdCode: '+260',
        DefaultLanguage: 'EN',
        CountryName: 'ZAMBIA',
        PostalRegionType: 'F',
        CountryCode: 'ZM'
      },
      {
        IsdCode: '+263',
        DefaultLanguage: 'EN',
        CountryName: 'ZIMBABWE',
        PostalRegionType: 'F',
        CountryCode: 'ZW'
      }
    ]
  }

const GenderFetchAction = {
    type: 'MASTER_SET_GENDER',
    payload: [
      'B',
      'M',
      'F'
    ]
  }

const memberProfileResponse = {
  "statuscode": "200",
  "statusMessage": "SUCCESS",
  "object": {
      "isAccrualValid": "NA",
      "isRedemptionValid": "NA",
      "memberAccount": {
          "companyCode": "IBS",
          "programCode": "PRG14",
          "membershipNumber": "IM0008010632",
          "accountStatus": "Active",
          "accountStatusCode": "A",
          "enrolmentSource": "W",
          "enrolmentDate": enrolmentDate,
          "accountPeriodType": "O",
          "accountExpiryinMonths": 0,
          "extendToDay": "0",
          "extendToMonth": "0",
          "tier": "BLU",
          "tierFromDate": "17-Jul-2020",
          "memberProfile": {
              "companyCode": "IBS",
              "membershipNumber": "IM0008010632",
              "membershipType": "I",
              "membershipStatus": "Active",
              "membershipStatusCode": "A",
              "enrollmentSource": "W",
              "customerPassword": "4779BB616E3A94C4794A0A90C8E62DA1EE7C9C8E",
              "individualInfo": {
                  "memberNationality": "BH",
                  "preferredLanguage": "EN",
                  "preferredAddress": "H",
                  "preferredEmailAddress": "H",
                  "preferredPhoneNumber": "HP",
                  "title": "MR",
                  "givenName": "Paul",
                  "familyName": "Gp",
                  "secondName": "L",
                  "displayName": "Paul GP",
                  "initials": "S",
                  "gender": "M",
                  "maritalStatus": "M",
                  "dateOfBirth": "23-Oct-1990",
                  "passportNumber": "M0992353",
                  "countryOfResidence": "BH",
                  "companyName": "UnknownCmp",
                  "designation": "",
                  "memberContactInfos": [
                      {
                          "addressType": "H",
                          "addressLine1": "House no 70",
                          "addressLine2": "Block 319",
                          "city": "MA",
                          "state": "SF",
                          "country": "BH",
                          "zipCode": "26814",
                          "addressInvalid": false,
                          "emailAddress": "paul1876@gmail.com",
                          "phoneISDCode": "+973",
                          "phoneAreaCode": "1731",
                          "phoneNumber": "161056",
                          "mobileISDCode": "+242",
                          "mobileAreaCode": "1731",
                          "mobileNumber": "4267",
                          "faxISDCode": "+993",
                          "faxAreaCode": "1630",
                          "faxNumber": "5678",
                          "skypeID": "paul.ge90e",
                          "postalAddressStatus": "V",
                          "phoneNumberStatus": "V",
                          "mobileNumberStatus": "V"
                      },
                      {
                          "addressType": "B",
                          "addressLine1": "House no 20",
                          "addressLine2": "Block 309",
                          "city": "MA",
                          "state": "SF",
                          "country": "BH",
                          "zipCode": "26814",
                          "addressInvalid": false,
                          "emailAddress": "paul996@gmail.com",
                          "phoneISDCode": "+973",
                          "phoneAreaCode": "1731",
                          "phoneNumber": "161056",
                          "mobileISDCode": "+973",
                          "mobileAreaCode": "1731",
                          "mobileNumber": "4267",
                          "faxISDCode": "+993",
                          "faxAreaCode": "1630",
                          "faxNumber": "5678",
                          "skypeID": "paul.george",
                          "postalAddressStatus": "V",
                          "phoneNumberStatus": "V",
                          "mobileNumberStatus": "V"
                      }
                  ]
              }
          },
          "memberPreferences": [],
          "memberDynamicAttributes": [
              {
                  "attributeGroupName": "English Name",
                  "attributeCode": "23",
                  "groupInstanceID": "1",
                  "attributeValue": "PAUL998",
                  "type": "P"
              },
              {
                  "attributeGroupName": "Security Details",
                  "attributeCode": "19",
                  "groupInstanceID": "1",
                  "attributeValue": "abcdasd",
                  "type": "P"
              },
              {
                  "attributeGroupName": "Security Details",
                  "attributeCode": "18",
                  "groupInstanceID": "1",
                  "attributeValue": "MN",
                  "type": "P"
              }
          ],
          "accrualSegment": []
      },
      "memberArtefactDetail": [
          {
              "artefactIdentifier": "1",
              "artefactType": "C",
              "artefactStatus": "P",
              "statusChangeDate": "20-Jul-2020 11:24:08",
              "statusStartDate": "20-Jul-2020 11:24:08",
              "userCode": "SYSTEM"
          }
      ]
  }
}

const securityFetchAction = {
  type: 'SET_MASTER_DATA',
  payload: {
    data: [
      {
        optionCode: 'MN',
        optionName: 'Mother\'s Name',
        sequenceNumber: 1,
        defaultFlag: false
      },
      {
        optionCode: 'WD',
        optionName: 'Anniversary Year',
        sequenceNumber: 2,
        defaultFlag: false
      }
    ],
    type: 'securityQuestions'
  }
}

const defaultConfigAction = {
  type: 'SET_CONFIG_DATA',
  payload: {
    config: [
      {
        section: 'default',
        companyCode: 'IBS',
        programCode: 'PRG14',
        skipPinChangeReminder: true,
        defaultCurrency: 'KRW',
        defaultPosCity: 'SEO',
        defaultPosCountry: 'KE',
        defaultPinRegex: '^\\d{4}$',
        defaultPasswordRegex: '^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$',
        requestTimedOutInMs: 20000,
        tiers: [
          {
            name: 'Blue',
            code: 'BLU',
            order: '1',
            upgradeExpiryInMonths: '12',
            downgradeExpiryInMonths: '12',
            themeClass: 'userClass1'
          },
          {
            name: 'Silver',
            code: 'SIL',
            order: '2',
            upgradeExpiryInMonths: '12',
            downgradeExpiryInMonths: '12',
            themeClass: 'userClass2'
          },
          {
            name: 'Gold',
            code: 'GOL',
            order: '3',
            upgradeExpiryInMonths: '12',
            downgradeExpiryInMonths: '12',
            themeClass: 'userClass3'
          },
          {
            name: 'Platinum',
            code: 'PLT',
            order: '4',
            upgradeExpiryInMonths: '12',
            downgradeExpiryInMonths: '12',
            themeClass: 'userClass4'
          },
          {
            name: 'Diamond',
            code: 'DIA',
            order: '5',
            upgradeExpiryInMonths: '12',
            downgradeExpiryInMonths: '12',
            themeClass: 'userClass5'
          }
        ],
        currencies: [
          {
            code: 'HKD',
            name: 'Hong Kong Dollar'
          },
          {
            code: 'HKD',
            name: 'Hong Kong Dollar'
          },
          {
            code: 'TWD',
            name: 'New Taiwan Dollar'
          },
          {
            code: 'PHP',
            name: 'PESO'
          },
          {
            code: 'KRW',
            name: 'South Korean Won'
          },
          {
            code: 'USD',
            name: 'US Dollar'
          },
          {
            code: 'VND',
            name: 'Vietnam Don'
          },
          {
            code: 'JPY',
            name: 'Yen'
          },
          {
            code: 'CNY',
            name: 'Yuan Renminbi'
          }
        ],
        partners: [
          {
            value: 'KE',
            name: 'Korean Air'
          },
          {
            value: 'DL',
            name: 'Delta Airlines'
          },
          {
            value: 'EY',
            name: 'Etihad Airways'
          }
        ],
        cabinClasses: {
          KE: [
            {
              cabinClassCode: 'E',
              cabinClassName: 'Economy'
            },
            {
              cabinClassCode: 'B',
              cabinClassName: 'Prestige'
            },
            {
              cabinClassCode: 'F',
              cabinClassName: 'First'
            }
          ]
        },
        cabinClassBookingClassMapping: {
          KE: [
            {
              cabinClass: 'E',
              bookingClass: 'B'
            },
            {
              cabinClass: 'B',
              bookingClass: 'R'
            },
            {
              cabinClass: 'F',
              bookingClass: 'F'
            }
          ]
        },
        gender: [
          {
            key: 'U',
            value: 'Unknown'
          },
          {
            key: 'M',
            value: 'Male'
          },
          {
            key: 'F',
            value: 'Female'
          }
        ]
      }
    ],
    type: 'default'
  }
}

const securityConfigAction = {
  type: 'SET_CONFIG_DATA',
  payload: {
    config: {
      section: 'security',
      companyCode: 'IBS',
      programCode: 'PRG14',
      changePassword: {
        additionalSecurityEnabled: true,
        securityType: {
          pin: {
            enabled: false
          },
          securityQuestion: {
            enabled: true,
            count: 1
          }
        }
      },
      changePin: {
        additionalSecurityEnabled: true,
        securityType: {
          password: {
            enabled: false
          },
          securityQuestion: {
            enabled: true,
            count: 1
          }
        }
      },
      changeSecurityQuestion: {
        count: 1,
        additionalSecurityEnabled: true,
        securityType: {
          pin: {
            enabled: false
          },
          password: {
            enabled: true
          }
        }
      },
      dynamicAttributes: {
        changePin: [
          {
            attributeCode: '18',
            attributeName: 'Secret Question',
            attributeValue: '',
            type: 'P',
            attributeKey: 'SQ'
          },
          {
            attributeCode: '19',
            attributeName: 'Secret Answer',
            attributeValue: '',
            type: 'P',
            attributeKey: 'SA'
          }
        ],
        changePassword: [
          {
            attributeCode: '18',
            attributeName: 'Secret Question',
            attributeValue: '',
            type: 'P',
            attributeKey: 'SQ'
          },
          {
            attributeCode: '19',
            attributeName: 'Secret Answer',
            attributeValue: '',
            type: 'P',
            attributeKey: 'SA'
          }
        ],
        changeSecurityQuestion: [
          {
            attributeCode: '18',
            attributeName: 'Secret Question',
            attributeValue: '',
            type: 'P',
            attributeKey: 'SQ'
          },
          {
            attributeCode: '19',
            attributeName: 'Secret Answer',
            attributeValue: '',
            type: 'P',
            attributeKey: 'SA'
          }
        ]
      },
      ui: {
        type: 'memberDynamicAttribute',
        filterType: 'attributeCode',
        layout: {
          order: [
            'changePassword',
            'changePin',
            'changeSecurityQuestion'
          ],
          elements: {
            changePassword: {
              fields: [
                {
                  name: 'oldPassword',
                  id: 'id-security-pwd-old-password',
                  visibility: true,
                  isRequired: true,
                  className: 'col-lg-4 col-md-6',
                  validation: [
                    {
                      pattern: '^([a-zA-Z0-9!@#\\$%\\^\\&*\\)\\(+=._-~])+$',
                      customMessageId: 'security.changePassword.old_password_msg'
                    }
                  ]
                },
                {
                  name: 'newPassword',
                  id: 'id-security-pwd-new-password',
                  visibility: true,
                  isRequired: true,
                  className: 'col-lg-4 col-md-6',
                  validation: [
                    {
                      pattern: '^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$',
                      customMessageId: 'form.newPassword.errorMessage.invalid'
                    },
                    {
                      pattern: '^((?![oldPassword]).)*$',
                      field: [
                        'oldPassword'
                      ],
                      customMessageId: 'security.changePassword.passwords_cannot_be_same'
                    }
                  ]
                },
                {
                  name: 'confirmPassword',
                  id: 'id-security-pwd-confirm-password',
                  visibility: true,
                  isRequired: true,
                  className: 'col-lg-4 col-md-6',
                  validation: [
                    {
                      pattern: '^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$',
                      customMessageId: 'security.changePassword.confirm_password_msg'
                    },
                    {
                      pattern: '^[newPassword]$',
                      field: [
                        'newPassword'
                      ],
                      customMessageId: 'security.changePassword.passwords_need_to_be_same'
                    }
                  ]
                },
                {
                  name: 'additionalSecurityInfo',
                  messageId: 'security.changePassword.additional_security_info',
                  className: 'col-sm-12',
                  visibility: true
                },
                {
                  name: 'memberPin',
                  id: 'id-security-pwd-pin',
                  className: 'col-lg-4 col-md-6',
                  visibility: false,
                  isRequired: true,
                  validation: {
                    pattern: '^[0-9]{4}$',
                    customMessageId: 'enrolment.form.memberPin'
                  }
                },
                {
                  name: 'securityQuestions',
                  id: 'id-security-pwd-security-questions',
                  visibility: true,
                  className: 'col-lg-12',
                  isRequired: true,
                  type: 'security',
                  validation: {
                    pattern: '^(?=.*[a-zA-Z0-9])',
                    customMessageId: 'enrolment.security_question.error.message'
                  }
                }
              ]
            },
            changePin: {
              fields: [
                {
                  name: 'oldPin',
                  id: 'id-security-pin-old-pin',
                  visibility: true,
                  isRequired: true,
                  className: 'col-lg-4 col-md-6',
                  validation: [
                    {
                      pattern: '^[0-9]{4}$',
                      customMessageId: 'enrolment.form.memberPin'
                    }
                  ]
                },
                {
                  name: 'newPin',
                  id: 'id-security-pin-new-pin',
                  visibility: true,
                  isRequired: true,
                  className: 'col-lg-4 col-md-6',
                  validation: [
                    {
                      pattern: '^[0-9]{4}$',
                      customMessageId: 'enrolment.form.memberPin'
                    },
                    {
                      pattern: '^(?![oldPin]$).*$',
                      field: [
                        'oldPin'
                      ],
                      customMessageId: 'security.changePin.change_pin_old_and_new_pins_cannot_be_same_message'
                    }
                  ]
                },
                {
                  name: 'confirmPin',
                  id: 'id-security-pwd-confirm-pin',
                  visibility: true,
                  isRequired: true,
                  className: 'col-lg-4 col-md-6',
                  validation: [
                    {
                      pattern: '^[newPin]$',
                      field: [
                        'newPin'
                      ],
                      customMessageId: 'security.changePin.change_pin_new_and_confirm_pins_need_to_be_same_message'
                    }
                  ]
                },
                {
                  name: 'additionalSecurityInfo',
                  messageId: 'security.changePin.additional_security_info',
                  className: 'col-sm-12',
                  visibility: true
                },
                {
                  name: 'securityQuestions',
                  type: 'security',
                  id: 'id-security-pin-security-questions',
                  visibility: true,
                  isRequired: true,
                  className: 'col-lg-12',
                  validation: {
                    pattern: '^(?=.*[a-zA-Z0-9])',
                    customMessageId: 'enrolment.security_question.error.message'
                  }
                }
              ]
            },
            changeSecurityQuestion: {
              fields: [
                {
                  name: 'securityQuestions',
                  id: 'id-security-questions-security-questions',
                  visibility: true,
                  isRequired: true,
                  validation: {
                    pattern: '^(?=.*[a-zA-Z0-9])',
                    customMessageId: 'security.changeSecurityQuestion.form.invalid_security_answer'
                  }
                },
                {
                  name: 'additionalSecurityInfo',
                  messageId: 'security.changeSecurityQuestion.additional_security_info',
                  className: 'col-sm-12',
                  visibility: true
                },
                {
                  name: 'pin',
                  id: 'id-security-questions-pin',
                  visibility: false,
                  isRequired: true,
                  validation: {
                    pattern: '^[0-9]{4}$',
                    customMessageId: 'security.changeSecurityQuestion.form.invalid_pin'
                  }
                },
                {
                  name: 'password',
                  id: 'id-security-questions-password',
                  visibility: true,
                  isRequired: true,
                  validation: {
                    pattern: '^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$',
                    customMessageId: 'enrolment.form.password'
                  }
                }
              ]
            }
          }
        }
      }
    },
    type: 'security'
  }
}

describe('actions', ()=>{
    beforeEach(()=>{
        moxios.install();
    })
    afterEach(()=>{
        moxios.uninstall();
    })
    test('profile data fetch failed', async done => {
        const store = mockStore({});
        moxios.wait(()=>{
            const request = moxios.requests.mostRecent();
            request.respondWith({ status: 500, response: {
                message: 'error occured',
                error: {
                  errorDetails: ['error occured']
                }
            } })
        })
        await store.dispatch(actions.fetchProfileData());
        done();
    })

    test('should fetch profile data', async (done)=>{
        const store = mockStore({})
        moxios.wait(() => {
            const request = moxios.requests.mostRecent();
            request.respondWith({ status: 200, response: {
                ...memberProfileResponse
            } })
        })
        await store.dispatch(actions.fetchProfileData()).then(response=>{
            const actionsCalled = store.getActions();
            expect(actionsCalled[0]).toEqual(profileDataAction);
        })
        done();
    })

    test('update profile failure', async done => {
        const store = mockStore({});
        moxios.wait(()=>{
            const request = moxios.requests.mostRecent();
            request.respondWith({ status: 500, response: {
                message: 'error occured',
                error: {
                  errorDetails: ['error occured']
                }
            } })
        })
        await store.dispatch(actions.updateProfileDetails({}));
        done();
    })

    test('should update profile data', async (done)=>{
        const store = mockStore({});
        // delete window.location;
        // window.location = {
        //     reload: jest.fn()
        // }
        let t = jest.fn();
        window.sessionStorage.setItem(SESSION_STORAGE_COMPANY_CODE, 'IBS')
        window.sessionStorage.setItem(SESSION_STORAGE_PROGRAM_CODE, 'PRG14')
        window.sessionStorage.setItem(SESSION_STORAGE_MEMBERSHIP_NO, 'IM0008010632');
        moxios.wait(()=>{
            const request = moxios.requests.mostRecent();
            request.respondWith({ status: 200, response: {
                message: 'profile updated'
            } })
        })
        await store.dispatch(actions.updateProfileDetails({data: 'new data'}, t)).then(response=>{
            // expect(response.data).toEqual({message: 'profile updated'})
            // expect(actionsCalled[0]).toEqual(profileDataAction);

            expect(jest.isMockFunction(t)).toBe(true)
            expect(t).toHaveBeenCalled();
        })
        done();
    })

})

describe('reducers', ()=>{
    test('test profile picture setting', ()=>{
        const action = {
            type: actions.SET_PROFILE_PICTURE,
            payload: 'picture'
        }
        const response = setProfileData(undefined, action);
        expect(response).toEqual({
            profilePicture: 'picture'
        })
    })
})

describe('component', ()=>{
    window.sessionStorage.setItem(SESSION_STORAGE_COMPANY_CODE, "IBS");
    window.sessionStorage.setItem(SESSION_STORAGE_PROGRAM_CODE, "PRG14");
    window.sessionStorage.setItem(SESSION_STORAGE_MEMBERSHIP_NO, "IM0008010632");
    delete window.scrollTo;
    window.scrollTo = jest.fn();
    test('render the component', ()=>{
        const store = testStore({})
        let wrapper = mount(
            <Provider store={store}>
                <UpdateProfile />
            </Provider>
        );

        wrapper.prop('store').dispatch(defaultConfigAction);
        wrapper = wrapper.update();


        wrapper.prop('store').dispatch(profileConfigAction);
        wrapper = wrapper.update();

        wrapper.prop('store').dispatch(securityConfigAction);
        wrapper = wrapper.update();
        
        wrapper.prop('store').dispatch(profileDataAction);
        wrapper = wrapper.update();

        wrapper.prop('store').dispatch(ISDFetchAction);
        wrapper = wrapper.update();

        wrapper.prop('store').dispatch(GenderFetchAction);
        wrapper = wrapper.update();

        wrapper.prop('store').dispatch(securityFetchAction);
        wrapper = wrapper.update();

        let text = wrapper.find('input[type="text"]');
        text.forEach(textObj=>{
            textObj.at(0).simulate('change', {value: 'hello world'});
            wrapper = wrapper.update();
        })
        let buttons = wrapper.find('button');
        buttons.forEach(button=>{
            button.simulate('click');
            wrapper = wrapper.update();
        })
        let gender = wrapper.find('Gender');
        gender.find('select').simulate('change', {value: 'B'});
        wrapper = wrapper.update();
        let ISDCodes = wrapper.find('ISDCode');
        ISDCodes.forEach(ISDCode=>{
            ISDCode.find('select').simulate('change', {value: '+355'})
            wrapper = wrapper.update();
        })

        // const newProfileDataAction = JSON.parse(JSON.stringify(profileDataAction));
        // newProfileDataAction.payload.object.memberAccount.memberDynamicAttributes = {}
        // wrapper.prop('store').dispatch(newProfileDataAction);
        // wrapper = wrapper.update()


        // text.at(0).simulate('change', {value: 'hello world'});
        // wrapper = wrapper.update();

        // console.log(text.at(0).debug())

        // let checkbox = wrapper.find('input[type="checkbox"]');
        // checkbox.at(0).simulate('click');
        // wrapper.update();
    })
})
