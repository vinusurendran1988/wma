import React from 'react';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { withSuspense, constructJsonPath } from '../../common/utils';
import { updateProfileDetails } from './actions';
import CustomMessage from '../../common/components/custommessage';
import { CONFIG_SECTION_PROFILE, CONFIG_SECTION_DEFAULT, PROGRAM_TYPE_CORPORATE } from '../../common/utils/Constants';
import { setError, resetError } from '../../common/middleware/redux/commonAction';
import Section from './Section'
import { setValueToObjectByPath, getValueFromPath, isDependentExists, findValueFromObjectByPath } from '../../common/utils/object.utils';
import { FULL_ACCESS } from '../../common/privileges';
import { UPDATE_PROFILE_BUTTON, CANCEL_UPDATE_PROFILE_BUTTON } from './Constant';
import Button from '../../common/components/fieldbank/Button';
import { getItemFromBrowserStorage, BROWSER_STORAGE_KEY_PROGRAM_TYPE } from '../../common/utils/storage.utils';

/**
 * @author Ajmal Aliyar
 * Component to render user profile fields and update profile data
 */
class UpdateProfile extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            request: JSON.parse(JSON.stringify(props.profileData)),
            errorCodes: [],
            showWarningAndError: false,
            isButtonClicked: false
        }
    }

    componentDidMount() {
        this.props.resetError();
    }

    updateProfileDetails() {
        const { errorCodes, request } = this.state;
        const { config } = this.props;
        this.props.resetError();
        if (errorCodes.length > 0) {
            this.props.setError(errorCodes);
        } else {
            if (config && config.ui && config.ui.request && config.ui.request.additionalMapping) {
                config.ui.request.additionalMapping.forEach((fields) => {
                    let { fromPath, toPath, dependentPath } = fields
                    let value = ""
                    fromPath.forEach((path, index)=>{
                        let returnValue = getValueFromPath(path, {config, request})
                        if (returnValue && isDependentExists(dependentPath, {config, request})) {
                            value += (index>0?" ":"") + returnValue
                        }
                    })
                    if(value){
                        constructJsonPath(toPath, value, this.state.request)
                        setValueToObjectByPath(this.state.request, toPath, value)
                    }
                })
            }

            this.props.updateProfileDetails(request, UPDATE_PROFILE_BUTTON);
        }
        window.scrollTo(0, 0);
        this.setState({ showWarningAndError: true, isButtonClicked:true })
    }
   
    /**
     * Callback is received from Section with updated request.
     *  1. updated request is set to state
     *  2. showWarningAndError is set to false
     * @param {*} request 
     * @author Ajmal V Aliyar
     */
    handleRequestChange(request) {
        this.setState({
            request,
            showWarningAndError: false
        })
    }

    /**
     * new set of error codes are received from Section. 
     * It is set to state as errorCodes
     * @param {*} codes 
     * @author Ajmal V Aliyar
     */
    handleErrorMessagesFromSection(codes) {
        if (!codes.length) { this.props.resetError() }
        if(JSON.stringify(codes) != JSON.stringify(this.state.errorCodes)){
            this.setState({ errorCodes: codes })
        }
    }

    resetFormData(){
        this.setState({
            isButtonClicked: false,
            request: JSON.parse(JSON.stringify(this.props.profileData)),
            showWarningAndError : false
        })
        this.props.resetError();
        window.scrollTo(0, 0);
    }

    render() {
        const { profileData, t, errors, sections, uiLayout, privilegeCheckData } = this.props;
        const { request, errorCodes, showWarningAndError } = this.state
        const isSuccess = errors[0] && errors[0] === 'profile.successMessage';
        const canTranslate =  errors[0] && errors[0] === 'profile.successMessage'?true:errorCodes.length>0
        const dynamicAttributeProperties = {
            "path": this.props.dynamicAttributesPath,
            "attributes": this.props.dynamicAttributes
        }
        const porgramType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE)
        const canWrite = privilegeCheckData?privilegeCheckData.permission === FULL_ACCESS:true
        return (
            <>
                {showWarningAndError && <CustomMessage type={isSuccess ? "success" : "danger"} message={errorCodes.length>0?errorCodes: errors} canTranslate={canTranslate} />}
                <div className="profileContentWrap">
                    {!this.props.isProfileComplete &&
                        <CustomMessage message={[t('profileCompletion.warningMessage')]}
                            type={"warning"} canTranslate={false} />}
                    {/* This is where the new component will be */}

                    {
                        sections.map((section, i) => {
                            return <Section
                                key={i}
                                page={"form.profile"}
                                canWrite={uiLayout.elements[section].enabled}
                                id={section}
                                displayElements={uiLayout.elements[section]}
                                request={request}
                                onRequestChange={(req) => this.handleRequestChange(req)}
                                dynamicAttributes={dynamicAttributeProperties}
                                errorCodes={errorCodes}
                                showWarningAndError={showWarningAndError}
                                onErrorCodes={(codes) => this.handleErrorMessagesFromSection(codes)}
                                isButtonClicked={this.state.isButtonClicked}
                            />
                        })
                    }

                    {
                        canWrite && (porgramType != PROGRAM_TYPE_CORPORATE) &&
                        <div className="text-right btn-wrap btn-wrap--grp">
                            <Button
                                className="btn btn-secondary"
                                handleOnClick={() => this.resetFormData()}
                                id={CANCEL_UPDATE_PROFILE_BUTTON}
                                data-test={CANCEL_UPDATE_PROFILE_BUTTON}
                                enabled={this.state.btnProceedToPay}
                                label={t("profile.cancelBtn")} />
                            <Button
                                className="btn btn-primary"
                                handleOnClick={() => this.updateProfileDetails()}
                                id={UPDATE_PROFILE_BUTTON}
                                data-test={UPDATE_PROFILE_BUTTON}
                                enabled={this.state.btnProceedToPay}
                                label={t("profile.updateBtn")} />
                        </div>
                    }
                </div>
            </>
        )
    }
}

const mapStateToProps = state => {
    return {
        profileData: state.profileDataReducer.profileData,
        sections: findValueFromObjectByPath(state, 'configurationReducer.profile.ui.layout.order', []),
        dynamicAttributes: findValueFromObjectByPath(state, 'configurationReducer.profile.dynamicAttributes.updateProfile', []),
        dynamicAttributesPath: findValueFromObjectByPath(state, 'configurationReducer.profile.ui.dynamicAttributesPath', []),
        uiLayout: findValueFromObjectByPath(state, 'configurationReducer.profile.ui.layout', []),
        errors: findValueFromObjectByPath(state, 'commonErrorReducer.error', []),
        config: state.configurationReducer[CONFIG_SECTION_PROFILE],
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT]
    }
}

const mapDispatchToProps = dispatch => {
    return {
        updateProfileDetails: (profileData, t) => dispatch(updateProfileDetails(profileData, t)),
        setError: messageArray => dispatch(setError(messageArray)),
        resetError: () => dispatch(resetError())
    }
}

UpdateProfile.defaultProps = {
    errors: []
}
 
export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(UpdateProfile)));