export const UPDATE_PROFILE_BUTTON = "update-profile-button"
export const CANCEL_UPDATE_PROFILE_BUTTON = "cancel-update-profile-button"