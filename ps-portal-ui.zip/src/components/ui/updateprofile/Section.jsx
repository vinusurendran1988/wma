import React from 'react';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { withSuspense, getRelativeDate, getCurrentDate, getFormattedDate, isEmptyOrSpaces } from '../../common/utils';
import FieldBank from '../../common/components/fieldbank';
import { FIELDTYPE_DROPDOWN, FIELDTYPE_CHECKBOXGROUP, FIELDTYPE_DROPDOWN_TEXTFIELD, FIELDTYPE_CUSTOM_COUNTY_DROPDOWN, FIELDTYPE_RADIOBUTTONGROUP, FIELDTYPE_CUSTOM_SEARCH_DROPDOWN, FIELDTYPE_DATE, FIELDTYPE_SECURITY_QUESTION, FIELDTYPE_TEXTFIELD_WITH_BUTTON, FIELDTYPE_ALERT_BOX } from '../../common/components/fieldbank/Constants';
import { fetchMasterData, resetError } from '../../common/middleware/redux/commonAction';
import { CONFIG_SECTION_DEFAULT, YYYY_MM_DD } from '../../common/utils/Constants';
import { findValueFromObjectByPath, setValueToObjectByPath } from '../../common/utils/object.utils';
import { performValidationsOnValue } from '../../common/utils/validation.utils';
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';
import {
    SECURITY_QUESTION_ATTRIBUTE_KEY,
    SECURITY_ANSWER_ATTRIBUTE_KEY
} from '../security/Constants'
import parse from 'html-react-parser';

/**
 * Section component. 
 * @description Dynamically populates a form under a section.
 * The user interactions with the forms are handled within
 * @author Ajmal Aliyar
 */
class Section extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            masterListNamesToLoad: []
        }
    }

    componentDidMount() {
        this.initiateLoadingRequiredMasterData()
        this.props.resetError()
    }

    componentDidUpdate(prevProps, prevState) {
        const { masterListNamesToLoad } = this.state
        const { masterData, masterEntityLookup, masterEntityLookupFilters } = this.props

        if (masterListNamesToLoad && Object.keys(masterEntityLookup).length > 0) {
            //find what is not inside masterListAlreadyInvoked; call the master service foe the rest. and then
            masterListNamesToLoad.forEach(masterKey => {
                // console.log("masterListNamesToLoad [masterKey]: ",masterKey, masterData);
                if (masterData &&
                    (!masterData[masterKey])) {
                    // console.log("masterListNamesToLoad [masterKey] invoking..!");
                    this.props.fetchMasterData(masterKey, masterEntityLookup, masterEntityLookupFilters)
                }
            })
        }
    }

    initiateLoadingRequiredMasterData() {
        const { displayElements } = this.props
        let masterListNamesToLoad = []
        displayElements.fields.forEach((field) => {

            if (field.source && field.source.type) {
                if (field.source.type == 'master') {
                    masterListNamesToLoad = this.addToMasterListArray(masterListNamesToLoad, field.source.key)
                }
            }
            if (field.additional && field.additional.length) {
                field.additional.forEach(subField => {
                    if ((subField.source && subField.source.type) && subField.source.type == 'master') {
                        masterListNamesToLoad = this.addToMasterListArray(masterListNamesToLoad, subField.source.key)
                    }
                })
            }
        })
        this.setState({ masterListNamesToLoad })
    }

    addToMasterListArray(array, key) {
        if (
            key &&
            !array.includes(key)
        ) {
            array.push(key)
        }
        return array
    }

    findIfRequired = (field) => {
        const currentType = findValueFromObjectByPath(this.props.request, field.requiredAdditional.fromPath)
        return currentType == field.requiredAdditional.type
    }


    prepareFieldProperties(field) {

        const { t, isButtonClicked, canWrite,template,allErrors } = this.props
        const fieldType = field.fieldType
        const isRequired = field.required? field.required : (field.requiredAdditional? this.findIfRequired(field):false)
        const id = `${this.props.id}_${field.id}`
        const i18 = field.i18?field.i18:`form.${field.name}`
        const toolTip = field.toolTip && i18 && t(`${i18}.tooltipMessage`)
        const placeholderi18n = field.i18?`${field.i18}.placeholder`:`form.${field.name}.placeholder`
        const placeholder = t(placeholderi18n)!=placeholderi18n?t(placeholderi18n):""
        const removeDefaultOption= field.removeDefaultOption && field.removeDefaultOption

        let label = ""
        let info = ""
        try {label = t(`${i18}.label`)!=`${i18}.label`?t(`${i18}.label`):""}catch(e){console.warn("no label for : ",`${i18}.label`)}
        try { info = t(`${i18}.info`) != `${i18}.info` ? t(`${i18}.info`) : "" } catch (e) {/**console.warn("no info for : ",`${i18}.info`) */ }
        if (!isEmptyOrSpaces(label)) {
            if (template && template.name == "template_required_optional" && !isRequired) {
                label += t(template.i18_text)
            }
            else {
                if(isRequired && !template){
                    label += t('form.warningSymbol')
                }
            }
        }
        const options = this.populateOptions(field)
        const value = this.setValueIfPresent(field)
        const onChange = (updatedValue) => this.handleOnChangeInField(updatedValue, field)
        const onClick = () => this.props.onClick()


        const error = (isButtonClicked && field.error)?true:false
        const additionalError = (isButtonClicked && field.additional && field.additional.length && field.additional[0].error)?true:false
        const enabled = (canWrite == undefined)?(field.enabled!=undefined?field.enabled:true):canWrite
        const testIdentifier =this.props.id +"_"+ field.name
        const handleOnClick = this.props.handleOnClick
        let errorMessage
        if(allErrors && Object.keys(allErrors).length > 0){
            allErrors.map(element=> {
                if( element.includes(i18)){
                    errorMessage = element
                }
            })
        }
        let properties = { fieldType, label, isRequired, id, options, value, onChange, error, info, enabled, placeholder, removeDefaultOption, testIdentifier, handleOnClick, additionalError, errorMessage, onClick, toolTip }


        if(fieldType == FIELDTYPE_DATE){
            if(field.minDate){
                properties["minDate"] = getFormattedDate(getRelativeDate(getCurrentDate(), field.minDate), YYYY_MM_DD)
            }
            if(field.maxDate){
                properties["maxDate"] = field.maxDate == "currentDate"? new Date():getFormattedDate(getRelativeDate(getCurrentDate(), field.maxDate), YYYY_MM_DD)
            }
            if(field.yearNavigator){
                properties["yearNavigator"] = true
            }
            if(field.monthNavigator){
                properties["monthNavigator"] = true
            }
        }
        if (field.fieldType == FIELDTYPE_TEXTFIELD_WITH_BUTTON) {
            try { properties["buttonName"] = t(`${i18}.btnName`) != `${i18}.btnName` ? t(`${i18}.btnName`) : "" } catch (e) { console.warn("no label for : ", `${i18}.label`) }
        }

        if (fieldType == FIELDTYPE_SECURITY_QUESTION) {
            const { dynamicAttributes, additionalConfig, request } = this.props
            const { attributes } = dynamicAttributes
            const securityQuestion = attributes.find(attribute => attribute.attributeKey === FIELDTYPE_SECURITY_QUESTION)
            properties["numberOfQuestions"] = additionalConfig.count?additionalConfig.count:1
            properties["securityQuestionType"] = field.additionalType
            properties["securityQuestionFilterType"] = field.filterType
            properties["securityQuestionFilterValue"] = securityQuestion ? securityQuestion[field.filterType] : ""
            properties["values"] = []
            properties["renderType"] = field.renderType
            properties["questionWraperClass"] = field.questionWrapperClass?field.questionWrapperClass:"col-lg-6 questionsLabel"
            properties["answerWrapperClass"] = field.answerWrapperClass?field.answerWrapperClass: "col-lg-6"
        }
        if(fieldType == FIELDTYPE_ALERT_BOX){
            properties["i18MessageCode"] = field.i18MessageCode ? field.i18MessageCode : ""
            properties["boxType"] = field.boxType ? field.boxType : ""
        }
        return properties
    }

    checkAndFetchDynamicAttribute(field) {
        const { dynamicAttributes } = this.props
        if (dynamicAttributes && dynamicAttributes.path && dynamicAttributes.attributes) {
            const { attributes } = dynamicAttributes
            return attributes.find((attr) => { return attr.attributeMapping == field.name })
        }
    }


    handleOnChangeInField(value, field) {
        const { onRequestChange, request } = this.props
        let requestToAmend = request
        if (field.path) {
            if(field.path.state && this.props.addValueToState){
                this.props.addValueToState(field, value)
            }
            const pathString = (field.path.request) ? field.path.request : undefined
            if (field.fieldType == FIELDTYPE_DROPDOWN_TEXTFIELD) {
                const additionalPathString = (field.additional[0].path && field.additional[0].path.request)
                    ? field.additional[0].path.request
                    : undefined
                setValueToObjectByPath(requestToAmend, pathString, value.text)
                setValueToObjectByPath(requestToAmend, additionalPathString, value.option)

                // this.validateAndSetValue(field, requestToAmend, pathString, value.text)
                // this.validateAndSetValue(field.additional[0], requestToAmend, additionalPathString, value.option)
            } else {
                if(pathString){
                    setValueToObjectByPath(requestToAmend, pathString, value)
                }
                // this.validateAndSetValue(field, requestToAmend, pathString, value)
            }
        }
        const dynamicAttributeConfig = this.checkAndFetchDynamicAttribute(field)
        if(dynamicAttributeConfig && Object.keys(dynamicAttributeConfig).length > 0){
            this.handleChangeIfDynammicAttribute(dynamicAttributeConfig, requestToAmend, value, field)
        }
        onRequestChange(requestToAmend)
    }

    validate(field, value) {
        field.error = false
        if (field.additional) { field.additional[0].error = false }
        const { onErrorCodes, errorCodes } = this.props
        const requiredField = field.requiredAdditional ? this.findIfRequired(field) : field.required
        let updatedErrorCodes = errorCodes
        if (field.visibility && field.validations && field.validations.length > 0) {
            let flag = false
            if (requiredField || value) {
                let validationError = []
                let validatedStateReturnValue = false
                field.validations.forEach(validation => {
                    if (!validation.state) {
                        validationError.push(validation)
                    } else if (this.props.validateWithStateVariable) {
                        validatedStateReturnValue = this.props.validateWithStateVariable(field, validation, value)
                        field.error = validatedStateReturnValue
                    }
                })

                if (validationError.length > 0) {
                    const validationResult = performValidationsOnValue(validationError, value)
                    if (!validationResult.isError) {
                        field.error = validatedStateReturnValue
                        validationError.forEach(valErr => {
                            const index = updatedErrorCodes.indexOf(valErr.customMessageId)
                            if (index > -1) {
                                flag = true
                                updatedErrorCodes.splice(index, 1)
                            }
                        })
                    } else {
                        field.error = true
                        validationError.forEach(validationErr => {

                            if (!validationResult.errorMessages.includes(validationErr.customMessageId) && updatedErrorCodes.includes(validationErr.customMessageId)) {
                                const index = updatedErrorCodes.indexOf(validationErr.customMessageId)
                                flag = true
                                updatedErrorCodes.splice(index, 1)
                            } else if (validationResult.errorMessages.includes(validationErr.customMessageId) && !updatedErrorCodes.includes(validationErr.customMessageId)) {
                                flag = true
                                updatedErrorCodes.push(validationErr.customMessageId)
                            }
                        })
                    }

                }
                // setValueToObjectByPath(request, path, updatedAtributeList)
            } else {
                field.validations.map(validation => {
                    const index = updatedErrorCodes.indexOf(validation.customMessageId)
                    if (index > -1) {
                        flag = true;
                        updatedErrorCodes.splice(index, 1);
                    }
                    //    updatedErrorCodes.includes(validation.customMessageId)
                })
            }
            if (flag) {
                onErrorCodes(updatedErrorCodes)
            }
            // setValueToObjectByPath(request, path, updatedAtributeList)
        }
    }

    handleChangeIfDynammicAttribute(dynamicAttributeConfig, request, value , field) {
        const { path, attributes } = this.props.dynamicAttributes
        let dynamicAttributesFromResponse = findValueFromObjectByPath(request, path)
        if(!dynamicAttributesFromResponse){
            dynamicAttributesFromResponse = []
            setValueToObjectByPath(request, path, dynamicAttributesFromResponse)
        }

        if (field && field.fieldType == SECURITY_QUESTION_ATTRIBUTE_KEY) {
            value.map(answerVal => {
                const { groupInstanceID, question, answer } = answerVal
                const securityAttribute = attributes.filter(attribute => attribute.groupInstanceID == groupInstanceID)
                securityAttribute.map(attr => {
                    if (attr.attributeKey == SECURITY_QUESTION_ATTRIBUTE_KEY) {
                        attr["attributeValue"] = question
                    }
                    if (attr.attributeKey == SECURITY_ANSWER_ATTRIBUTE_KEY) {
                        attr["attributeValue"] = answer
                    }
                    // dynamicAttributesFromResponse.push(attr)
                })
            })

        } else {
            const index = dynamicAttributesFromResponse.findIndex(attr => attr.attributeCode == dynamicAttributeConfig.attributeCode)
            // AdditionalMapping field is used only to add the noOfEmployees upperLimit during enrolment/profile 
            if(dynamicAttributeConfig.additionalMapping){
                const { defaultConfig } = this.props
                let dataFromDefaultConfig = (defaultConfig.data)?defaultConfig.data[dynamicAttributeConfig.attributeMapping]:undefined
                if(!dataFromDefaultConfig){
                    const currentProgram = getCurrentProgramFromDefaultConfig(defaultConfig)
                    if(currentProgram){
                        dataFromDefaultConfig = currentProgram.defaults[dynamicAttributeConfig.attributeMapping]
                    }
                }
                if(dataFromDefaultConfig){
                    dataFromDefaultConfig = dataFromDefaultConfig.find(e=>e.key == value)
                    value = dataFromDefaultConfig[dynamicAttributeConfig.additionalMapping]
                }
            }
            if(index>-1){
                dynamicAttributesFromResponse[index]["attributeValue"] = value
            } else{
                dynamicAttributeConfig["attributeValue"] = value
                dynamicAttributesFromResponse.push(dynamicAttributeConfig)
            }
        }
    }

    populateOptions(field) {

        if ([
            FIELDTYPE_DROPDOWN,
            FIELDTYPE_CHECKBOXGROUP,
            FIELDTYPE_DROPDOWN_TEXTFIELD,
            FIELDTYPE_CUSTOM_COUNTY_DROPDOWN,
            FIELDTYPE_CUSTOM_SEARCH_DROPDOWN,
            FIELDTYPE_RADIOBUTTONGROUP
        ].includes(field.fieldType)
        ) {

            const { masterData, defaultConfig } = this.props

            let sourceType = (field.source) ? field.source.type : undefined
            let key = (sourceType) ? field.source.key : undefined
            let labelSelector = (sourceType && field.source.selector) ? field.source.selector.label : undefined
            let valueSelector = (sourceType && field.source.selector) ? field.source.selector.value : undefined


            if (field.fieldType == FIELDTYPE_DROPDOWN_TEXTFIELD) {
                const additionalField = field.additional[0]
                sourceType = (additionalField && additionalField.source) ? additionalField.source.type : undefined
                key = (sourceType) ? additionalField.source.key : undefined
                labelSelector = (sourceType && additionalField.source.selector) ? additionalField.source.selector.label : undefined
                valueSelector = (sourceType && additionalField.source.selector) ? additionalField.source.selector.value : undefined
            }

            let source
            switch (sourceType) {
                case 'master':
                    source = masterData
                    break
                case 'default':
                    source = (defaultConfig) ?
                        (defaultConfig.data && defaultConfig.data[key]?
                            defaultConfig.data:
                            getCurrentProgramFromDefaultConfig(defaultConfig).data):
                        undefined
                    break
                case 'props':
                    source = this.props
                    break
                default:
            }
            const derivedList = (source && source[key]) ? source[key] : undefined
            if (derivedList && derivedList.length) {
                return derivedList.map((option, index) => {
                    return {
                        id: index,
                        label: option[labelSelector],
                        value: option[valueSelector]
                    }
                })
            }
        }
        return undefined
    }

    /**
     * 
     * @param {*} field 
     * Prepopulate value to a field if it is already availabel from API.
     * 
     * @author Ajmal V Aliyar
     */
    setValueIfPresent(field) {
        const { request,response } = this.props
        let returnValue = ""
        let returnValueReq = ""
        let returnValueResponse = ""

        if((request && Object.keys(request).length>0) || (response && Object.keys(response).length>0 )){
            if (!field.path || (field.path && (!field.path.response && !field.path.request && this.checkAndFetchDynamicAttribute(field)))) { //check if the field is dynamicAttribute (without path)
                returnValue = this.setValueIfDynamicAttribute(field)
                this.validate(field, returnValue)
            } else if (field.fieldType == FIELDTYPE_DROPDOWN_TEXTFIELD) {
                let returnText ="";
                if(field.path.response && field.path.request && field.path.response != field.path.request){
                    returnText = findValueFromObjectByPath(response, field.path.response, "");
                }else{
                    returnText = findValueFromObjectByPath(request, field.path.request, "");
                }
                //const returnText = field.path.response && field.path.response.length>0?findValueFromObjectByPath(response, field.path.response, ""):findValueFromObjectByPath(request, field.path.request, "");       
                returnValue = {
                    text: returnText,
                    option: (
                        field.additional &&
                        field.additional.length &&
                        field.additional[0].path &&
                        field.additional[0].path.response
                    )
                        ? findValueFromObjectByPath(response, field.additional[0].path.response)
                        : findValueFromObjectByPath(request, field.additional[0].path.request)
                }
                this.validate(field, returnValue.text)
                this.validate(field.additional[0], returnValue.option)

                if(field.path.response && field.path.request && field.path.response != field.path.request){
                    setValueToObjectByPath(request, field.path.request, returnValue.text)
                    setValueToObjectByPath(request, field.additional[0].path.request, returnValue.option)
                }

            }else if(field.path && field.path.response  && field.path.response != field.path.request){
                if(field.path.request){
                    returnValueReq = findValueFromObjectByPath(request, field.path.request)
                    if(!returnValueReq && field.defaultValue){
                        returnValueReq = field.defaultValue;
                    }
                    setValueToObjectByPath(request, field.path.request, returnValueReq)
                    this.validate(field, returnValueReq)
                }
                if(field.path.response){
                    returnValue = findValueFromObjectByPath(response, field.path.response)
                    if(!returnValue && field.defaultValue){
                        returnValue = field.defaultValue;
                    }
                    setValueToObjectByPath(response, field.path.response, returnValue)
                    this.validate(field, returnValue)
                }
                

            } else if (field.path && field.path.request && field.path.response || (field.path && field.path.request)) {
                if (field.path.request) {
                    returnValue = findValueFromObjectByPath(request, field.path.request)
                    if (!returnValue && field.defaultValue) {
                        returnValue = field.defaultValue;
                    }
                    setValueToObjectByPath(request, field.path.request, returnValue)
                    this.validate(field, returnValue)

                }
                if (field.path.response) {
                    returnValueResponse = findValueFromObjectByPath(response, field.path.response)
                    if (!returnValueResponse && field.defaultValue) {
                        returnValueResponse = field.defaultValue;
                    }
                    setValueToObjectByPath(response, field.path.response, returnValueResponse)
                    this.validate(field, returnValueResponse)
                }
            }
            else if (field.path && field.path.state && !field.path.request) {
                returnValue = this.props.findValueFromState(field.name, field.fieldType)
                this.validate(field, returnValue)
            }

        }
        return returnValue
    }

    setValueIfDynamicAttribute(field) {
        const { dynamicAttributes, request } = this.props
        if (dynamicAttributes && dynamicAttributes.path && dynamicAttributes.attributes && request) {
            const { path, attributes } = dynamicAttributes
            const attributesFromResponse = findValueFromObjectByPath(request, path)
            if(field.fieldType == SECURITY_QUESTION_ATTRIBUTE_KEY){
                return attributesFromResponse
            }
            const dynamicAttribute = attributes.find((attr) => { return attr.attributeMapping == field.name })
            if(dynamicAttribute){
                const responseItem = attributesFromResponse && attributesFromResponse.find((attr) => { return attr.attributeCode == dynamicAttribute.attributeCode })
                if (responseItem) {
                    return responseItem.attributeValue
                }
            }
        }
        return undefined
    }

    defaultRender() {
        const { id, t, displayElements, page } = this.props
        return (
            displayElements.visibility !=false &&
            <>
                {t(`${page}.${id}.title`) != `${page}.${id}.title` && <h2 className="mb-4">{t(`${page}.${id}.title`)}</h2>}
                {displayElements && displayElements.description &&
                    <>
                    <span className="mb-4"> {parse(t(displayElements.description))} </span>
                    <br/>
                    <br />

                    </>
                }
                <div className="row">
                    {
                        displayElements &&
                        displayElements.fields &&
                        displayElements.fields.length &&
                        displayElements.fields.map((object, i) => {
                            if (object.visibility !== true) {
                                return null;
                            } else {
                                const field = this.prepareFieldProperties(object)
                                return <FieldBank
                                    field={field}
                                    className={object.className?object.className:(displayElements.className?displayElements.className:"")}
                                    key={i}
                                />
                            }
                        })
                    }
                </div>
            </>
        )
    }

    render1_1 = ()=>{
        const { id, t, displayElements, page } = this.props
        let canHeader = 0
        return (
            <>
                {
                    displayElements &&
                    displayElements.fields &&
                    displayElements.fields.length &&
                    displayElements.fields.map((object, i) => {
                        if (object.visibility == true) {
                            const field = this.prepareFieldProperties(object)
                            return (
                                <>
                                    {
                                        (canHeader++ == 0) &&
                                        t(`${page}.${id}.title`) != `${page}.${id}.title` &&
                                        <div className="col-md-12"> <h2>{t(`${page}.${id}.title`)}</h2> </div>
                                    }
                                    <>
                                        <span className="mb-4"> {parse(t(displayElements.description))} </span>
                                        <br />
                                        <br />

                                    </>
                                    {
                                        field.fieldType && field.fieldType == SECURITY_QUESTION_ATTRIBUTE_KEY ?
                                            <FieldBank
                                                field={field}
                                                className={object.className ? object.className : (displayElements.className ? displayElements.className : "")}
                                                key={i}
                                            /> :

                                            <div className="col-md-12">
                                                <div className="row">
                                                    {/* <div class={`${field.wrapperClass ? field.wrapperClass : "col-lg-5 col-md-7"}`}> */}
                                                    <FieldBank
                                                        field={field}
                                                        className={object.className ? object.className : (displayElements.className ? displayElements.className : "")}
                                                        key={i}
                                                    />
                                                    {/* </div> */}
                                                </div>
                                            </div>
                                    }
                                </>
                            )
                        }
                    })
                }
            </>
        )
    }

    render(){
        const { renderType } = this.props
        if(renderType){
            return this.render1_1()
        }
        return this.defaultRender()
    }
}

const mapStateToProps = state => {
    return {
        masterData: state.masterData,
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        masterEntityLookup: state.masterEntityDataReducer.masterEntityLookup,
        masterEntityLookupFilters: state.masterEntityDataReducer.masterEntityLookupFilters,
        allErrors: state.commonErrorReducer.error,
    }
}

const mapDispatchToProps = {
    fetchMasterData,
    resetError
}

Section.defaultProps = {
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(Section)));