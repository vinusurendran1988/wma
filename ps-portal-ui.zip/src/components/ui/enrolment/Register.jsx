import React, { Component } from 'react';
import parse from 'html-react-parser';
import { connect } from 'react-redux';
import {
    enrolment, checkGhostCardNumber
} from './action'
import {
    findValueFromObjectByPath,
    setValueToObjectByPath,
    getValueFromPath
} from '../../common/utils/object.utils';
import { withTranslation } from 'react-i18next';
import {
    withSuspense,
    generateRequestBodyWithEmptyValue,
    isPatternMatch,
    constructJsonPath,
    isEmptyOrSpaces
} from '../../common/utils'
import {
    _URL_ENROLMENT,
    _URL_PREAFFILIATED_ENROLMENT,
    _URL_ENROLMENT_CORPORATE
} from '../../common/config/config'
import {
    resetError,
    fetchConfiguration,
    logOut,
    setError,
    fetchDefaultUserProfileData
} from '../../common/middleware/redux/commonAction'
import {
    AMP, MPN, ID_SUBMIT_BUTTON, TOKEN, GET_DATA_FROM_URL
} from './Constants'
import CustomMessage from '../../common/components/custommessage';
import {
    CONFIG_SECTION_ENROL,
    CONFIG_SECTION_DEFAULT,
    CONFIG_SECTION_LOGIN,
    CONFIG_SECTION_ACCOUNT_SUMMARY,
    CONFIG_SECTION_MEMBERCHECK,
    CONFIC_SECTION_ALREADY_HAVE_FFNO,
    PROGRAM_TYPE_CORPORATE
} from '../../common/utils/Constants'
import {
    getItemFromBrowserStorage,
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    BROWSER_STORAGE_KEY_PROGRAM_TYPE
} from '../../common/utils/storage.utils';
import Section from '../updateprofile/Section';
import { FIELDTYPE_CHECKBOX } from '../../common/components/fieldbank/Constants';
import Button from '../../common/components/fieldbank/Button';
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';


class Register extends Component {
    constructor(props) {
        super(props)
        this.state = {
            showWarningAndError: false,
            showPreaffiliatedMessage: false,
            request: generateRequestBodyWithEmptyValue(props.config),
            companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
            programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
            errorCodes: [],
            isButtonClicked: false,
            isHavingFFNo: undefined,
            corporateFlag: false,
        }
        this.enroll = this.enroll.bind(this)
        this.onCancel = this.onCancel.bind(this)
    }

    componentDidMount() {
        // setItemToBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE, "CP") // Should be removed

        this.props.resetError()
        if (this.state.errorCodes.length) {
            this.setState({
                errorCodes: []
            })
        }
        // const currentProgram = getCurrentProgramFromDefaultConfig(defaultConfig)
        // if(currentProgram.programType == PROGRAM_TYPE_CORPORATE && !this.state.corporateFlag){
        //     this.setState({
        //         corporateFlag:true
        //     })
        // }

        if (!this.props.config || this.props.config[BROWSER_STORAGE_KEY_PROGRAM_CODE] != getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE)) {
            this.props.fetchConfiguration(CONFIG_SECTION_ENROL)
        }
        if (!this.props.loginConfig) {
            // Required in the index.js, once the user is successfully enrolled via singleStep.
            // The api to login requires extra data
            this.props.fetchConfiguration(CONFIG_SECTION_LOGIN)
        }
        document.body.scrollTop = document.documentElement.scrollTop = 0
        if (!this.props.profileData &&
            !isEmptyOrSpaces(getItemFromBrowserStorage(TOKEN)) &&
            this.props.isProtected) {
            this.props.fetchDefaultUserProfileData();
        }

    }
    
    componentDidUpdate(prevProps, prevState) {

        const { t, defaultConfig, profileData } = this.props
        const { corporateFlag } = this.state
        const currentProgram = getCurrentProgramFromDefaultConfig(defaultConfig)
        if(currentProgram.programType == PROGRAM_TYPE_CORPORATE && !corporateFlag){
            this.setState({
                corporateFlag:true
            })
        }
        if (prevProps.config != this.props.config) {
            this.setState({
                request: generateRequestBodyWithEmptyValue(this.props.config),
                errorCodes: [],
            })
        }
        if (prevProps.enrolmentData != this.props.enrolmentData) {
            this.props.postEnrolment(this.props.enrolmentData, this.state)
        }
        // if (prevProps.preaffliatedEnrolmentData != this.props.preaffliatedEnrolmentData) {
        //     this.props.postEnrolment(this.props.preaffliatedEnrolmentData, this.state)
        // }
        if (this.props.preaffliatedData && (prevProps.preaffliatedData != this.props.preaffliatedData)) {
            this.setState({
                isHavingFFNo: this.props.preaffliatedData.object.status ? undefined : true,
                showPreaffiliatedMessage: true,
                preaffiliatedMessage: this.props.preaffliatedData.object.status ? [t('enrolment.preaffiliated.success_true')] : [t('enrolment.preaffiliated.success_false')],
                customMsgType: this.props.preaffliatedData.object.status ? "success" : "danger",
                isFFnoValidatedSuccesFully: this.props.preaffliatedData.object.status
            })
        }
        else if (this.props.preaffliatedError && (prevProps.preaffliatedError != this.props.preaffliatedError)) {
            this.setState({
                isHavingFFNo: true,
                showPreaffiliatedMessage: true,
                preaffiliatedMessage: this.props.preaffliatedError.error,
                customMsgType: "danger",
                isFFnoValidatedSuccesFully: false,
            })
        }
        if (this.state.clearDataFlag) {
            let requestObj = this.state.request;
            requestObj.object.memberAccount.membershipNumber = "";
            requestObj.object.memberAccount.partner = "";
            this.setState({
                request: requestObj,
                clearDataFlag: false
            })
        }
    }

    setTranslatedErrorMessages(errorCodes) {
        const { t } = this.props
        const translatedMessages = errorCodes.map(code => {
            return t(code)
        })
        this.setState({ errors: translatedMessages })
    }
    /**
     * Function to retrieve the reference value from the url
     * @author Somdas M
     * @param {string} url - The string containing the reference key
     */
    getDataFromUrl(url, key) {
        if (url.includes(key)) {
            let value = url.substring(url.indexOf(key), url.length)
            if (value.includes(AMP)) {
                value = value.substring(key.length + 1, value.indexOf(AMP))
            } else {
                value = value.substring(key.length + 1, value.length)
            }
            return value
        }else{
            return ""
        }
    }

    /**
     * Function to check if the request body is valid.
     * If valid, post the request.
     * @author Somdas M
     */
    enroll() {
        const { errorCodes, isFFnoValidatedSuccesFully, isHavingFFNo } = this.state;
        if ((isFFnoValidatedSuccesFully && isHavingFFNo) || (!isHavingFFNo)) {
            if (errorCodes.length > 0) {
                this.props.setError(errorCodes);
            } else {
                this.props.resetError()
                this.createPayloadAndEnroll();
            }
            this.setState({ showWarningAndError: true, isButtonClicked: true })
        } else {
            this.setState({
                showPreaffiliatedMessage: true,
                preaffiliatedMessage: ['enrolment.preaffiliated.membershipNumber.invalid'],
                customMsgType: "danger"
            })
        }
        window.scrollTo(0, 0);

    }

    getValueFromPath(path,key) {
        let returnValue = ""
        if (path.startsWith(GET_DATA_FROM_URL)) {
            returnValue = this.getDataFromUrl(window.location.hash,key)
        } else {
            returnValue = getValueFromPath(path, { ...this.props, ...this.state })
        }
        return returnValue
    }

    isDependentExists(dependentPath,invertFlag=false) {
        if (!dependentPath) {
            return true
        }
        let tValue = ""
        dependentPath.forEach((path) => {
            let returnValue = this.getValueFromPath(path,"")
            if (returnValue) {
                tValue += " " + returnValue
            }
        })
        if (tValue) {
            return invertFlag?false:true
        }
        return invertFlag?true:false
    }
    /**
     * Function to create the request body and enroll
     * @author Somdas M
     */
    createPayloadAndEnroll() {
        const { config } = this.props
        const { request, corporateFlag } = this.state
        if (config && config.ui && config.ui.request && config.ui.request.additionalMapping) {
            config.ui.request.additionalMapping.forEach((fields) => {
                let { fromPath, toPath, dependentPath,invertDepandantPath,key } = fields
                let value = ""
                fromPath.forEach((path, index) => {
                    let returnValue = this.getValueFromPath(path,key)
                    if (returnValue && this.isDependentExists(dependentPath,invertDepandantPath)) {
                        value += (index > 0 ? " " : "") + returnValue
                    }
                })
                if (value) {
                    constructJsonPath(toPath, value, request)
                    setValueToObjectByPath(request, toPath, value)
                }
            })
        }
        if (config && config.ui && config.ui.request && config.ui.request.postProcessing) {
            config.ui.request.postProcessing.forEach((postProcessCondition) => {
                if (postProcessCondition.type == "removal") {
                    postProcessCondition.condition.every(condition => {
                        const { path } = postProcessCondition
                        const parentPath = path.substring(0, path.lastIndexOf("."))
                        const obj = findValueFromObjectByPath(request, path)
                        const parentObj = findValueFromObjectByPath(request, parentPath)
                        if (obj && parentObj) {
                            if (isPatternMatch(condition.pattern, JSON.stringify(obj))) {
                                if (parentObj.constructor === Object) {
                                    setValueToObjectByPath(request, path, undefined)
                                } else if (parentObj.constructor === Array) {
                                    let lastIndex = parseInt(path.substring(path.lastIndexOf(".") + 1))
                                    if (lastIndex > -1) parentObj.splice(lastIndex, 1);
                                } else {
                                    setValueToObjectByPath(request, path, undefined)
                                }
                            }
                        }
                    })
                }
            })
        }

        const canProcess = this.additionalValidation()
        if (!canProcess) {
            if (this.state.isFFnoValidatedSuccesFully) {
                this.props.enrolment(this.state.request, ID_SUBMIT_BUTTON, _URL_PREAFFILIATED_ENROLMENT)
            } else if (corporateFlag) {
                this.props.enrolment(this.state.request, ID_SUBMIT_BUTTON, _URL_ENROLMENT_CORPORATE)
            } else {
                this.props.enrolment(this.state.request, ID_SUBMIT_BUTTON, _URL_ENROLMENT)
            }
        }
    }

    additionalValidation() {

        const { config, uiLayout, sections } = this.props
        const { request, errorCodes } = this.state
        const elementIds = [], errorElementIds = []
        let canUpdateState = false
        if (config && config.ui && config.ui.request && config.ui.request.additionalValidation) {

            config.ui.request.additionalValidation.forEach((validations) => {
                const { path, pattern } = validations.preCondition
                const obj = findValueFromObjectByPath(request, path)
                let value = ""
                if (obj) {
                    if (obj.constructor === Object || obj.constructor === Array) {
                        value = JSON.stringify(obj)
                    } else {
                        value = obj
                    }
                }
                let errorCodeIndex = errorCodes.indexOf(validations.customMessageId)
                if (isPatternMatch(pattern, value)) {
                    let canAddErrorCode = false
                    validations.postCondition.forEach(condition => {
                        elementIds.push(condition.elementId)
                        const tObj = findValueFromObjectByPath(request, condition.path)
                        let tValue = ""
                        if (tObj != undefined) {
                            if (tObj.constructor === Object || tObj.constructor === Array) {
                                tValue = JSON.stringify(vObj)
                            } else {
                                tValue = tObj
                            }
                        }
                        if (!isPatternMatch(condition.pattern, tValue)) {
                            canAddErrorCode = true
                            canUpdateState = true
                            errorElementIds.push(condition.elementId)
                        }
                    })
                    if (errorCodeIndex > -1 && !canAddErrorCode) {
                        errorCodes.splice(errorCodeIndex, 1)
                        canUpdateState = true
                    } else if (canAddErrorCode && errorCodeIndex == -1) {
                        errorCodes.push(validations.customMessageId)
                    }
                } else if (errorCodeIndex > -1) {
                    validations.postCondition.forEach(condition => {
                        elementIds.push(condition.elementId)
                    })
                    errorCodes.splice(errorCodeIndex, 1)
                    canUpdateState = true
                }
            })
            if (canUpdateState) {
                this.setState({ errorCodes })
            }
            sections.forEach(sec => {
                uiLayout &&
                    uiLayout.elements &&
                    uiLayout.elements[sec] &&
                    uiLayout.elements[sec].fields &&
                    uiLayout.elements[sec].fields.forEach(field => {
                        if (errorElementIds.includes(field.id)) {
                            field.error = true
                        } else if (elementIds.includes(field.id)) {
                            field.error = false
                        }
                    })
            })
        }

        return canUpdateState
    }

    handleRequestChange(request) {

        this.setState({ request, showWarningAndError: false, showPreaffiliatedMessage: false })
        this.additionalValidation()
    }

    handleErrorMessagesFromSection(codes) {
        if (!codes.length) { this.props.resetError() }
        if (JSON.stringify(codes) != JSON.stringify(this.state.errorCodes)) {
            this.setState({ errorCodes: codes })
        }
    }

    addValueToState(field, value) {
        let newState = {}
        if (field.fieldType == FIELDTYPE_CHECKBOX) {
            if (field.name == CONFIG_SECTION_MEMBERCHECK) {
                this.setState({
                    isHavingFFNo: value ? true : undefined,
                    clearDataFlag: value ? false : true
                })
            }
            if (field.childRelation) {
                field.childRelation.forEach(child => {
                    newState[child] = value
                })
            } else if (field.parentRelation) {
                newState[field.parentRelation] = true
                if (field.siblingRelation) {
                    newState[field.parentRelation] = newState[field.parentRelation] && value
                    field.siblingRelation.forEach(sibling => {
                        newState[field.parentRelation] = this.state[sibling] && newState[field.parentRelation]

                    })
                }
            }
        }
        newState[field.name] = value
        this.setState(newState)
    }

    validateWithStateVariable(field, validation, value) {
        let { pattern, fields } = validation
        let isValidationSuccess = true, canUpdateState = false
        fields.forEach((fd) => {
            const newPattern = pattern.replace("[fields]", this.state[fd])
            if (!isPatternMatch(newPattern, value)) {
                isValidationSuccess = false
            }
        })
        let { errorCodes } = this.state
        if (!isValidationSuccess) {
            if (!errorCodes.includes(validation.customMessageId)) {
                errorCodes.push(validation.customMessageId)
                canUpdateState = true
            }
        } else if (errorCodes.includes(validation.customMessageId)) {
            const index = errorCodes.indexOf(validation.customMessageId)
            if (index > -1) {
                canUpdateState = true
                errorCodes.splice(index, 1)
            }
        }
        field.error = !isValidationSuccess
        if (canUpdateState) {
            this.setState({
                errorCodes
            })
        }
        return !isValidationSuccess
    }

    findValueFromState(stateFieldName, fieldType) {
        if (fieldType == FIELDTYPE_CHECKBOX) {
            return this.state[stateFieldName] ? this.state[stateFieldName] : false
        } else {
            return this.state[stateFieldName] ? this.state[stateFieldName] : ""
        }
    }

    getDynamicAttributesPath() {
        const { additionalMappings } = this.props
        const attribute = additionalMappings.find((attr) => { return attr.name.includes("dynamicAttributes") })
        if (attribute) {
            return attribute.path
        }
        return ""
    }

    handleOnClick = (event, value) => {
        if (value) {
            let payload = {
                "object": {
                    "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                    "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                    "membershipNumber": value,
                }
            };
            this.props.checkGhostCardNumber(payload, ID_SUBMIT_BUTTON)
        } else {
            this.setState({
                showPreaffiliatedMessage: true,
                preaffiliatedMessage: ['enrolment.preaffiliated.membershipNumber.invalid'],
                customMsgType: "danger"
            })
        }
    }
    onCancel() {
       this.setState({
           request:generateRequestBodyWithEmptyValue(this.props.config),
           isButtonClicked :false,
           showWarningAndError :false
       })
    }
    render() {
        const {
            request, errorCodes, showWarningAndError, isHavingFFNo,
            customMsgType, showPreaffiliatedMessage, preaffiliatedMessage,
            isFFnoValidatedSuccesFully, corporateFlag } = this.state
        const { t, uiLayout, sections, error, config, profileData } = this.props
        const dynamicAttributeProperties = {
            "path": this.props.dynamicAttributesPath,
            "attributes": this.props.dynamicAttributes
        }
        const disableSidePannel = config ? config.ui.disableEnrolSidePannel : false
        const isBannerRequred = config ? config.ui.isBannerRequred : true

        return (
            <div>
                {isBannerRequred &&
                    <div className="pageHeader container-fluid p-5">
                        <div className="display-3">{t('enrolment.cover_title')}</div>
                    </div>
                }
                <div className={this.props.subClassName}>
                    <div className="row">
                        <div className="col-12 mb-5">
                            {showWarningAndError && <CustomMessage type="danger" message={errorCodes.length > 0 ? errorCodes : error} data-test="customMessageComponent" canTranslate={errorCodes.length > 0} />}
                            {showPreaffiliatedMessage && <CustomMessage type={customMsgType} message={preaffiliatedMessage} data-test="customMessageComponentFFNo" canTranslate={true} />}
                            <div className="form-row">
                                <div className="col-9">
                                    <h1>{corporateFlag ? t('enrolment.corporateTitle') : t('enrolment.title')}</h1>
                                    <p>
                                        {corporateFlag ? parse(t('enrolment.corporateSubtitle')) : parse(t('enrolment.subtitle'))}
                                    </p>
                                    <p>
                                        {corporateFlag ? parse(t('enrolment.corporateSubtitle1')) : ""}
                                    </p>
                                </div>
                                <div className="col-3 text-right">
                                    {/* <div className="display-1">2%</div> */}
                                </div>
                            </div>
                            {/* <h1 id="enrolment_title">{t("enrolment.title")}</h1> */}
                            {/* <div>{t("enrolment.description")}</div>
                        <div className="alert alert-light" role="alert"><i className="fa fa-trophy" aria-hidden="true"></i> {parse(t("enrolment.subtitle"))} </div> */}
                        </div>
                    </div>
                    <div className="row">
                        {!disableSidePannel &&
                            <div className="col-lg-4">
                                <div className="enrollmentFeatures">
                                    <div className="h3">{t('enrolment.join_loyalty_program')}</div>
                                    <div className="h5">{t('enrolment.register_free')} </div>
                                    <div>{t('enrolment.register_free_description')}</div>
                                    <ul className="list-group list-group-flush">
                                        <li className="list-group-item">{t('enrolment.description_1')}</li>
                                        <li className="list-group-item">{t('enrolment.description_2')}</li>
                                    </ul>
                                </div>
                            </div>
                        }
                        <div className={`col-lg-${disableSidePannel ? "12" : "8"}`}>
                            <div className="enrollmentForm" data-test="enrollmentForm">
                                {
                                    sections && sections.map((section, i) => {
                                        return uiLayout.elements[section] && <Section
                                            key={i}
                                            id={section}
                                            displayElements={uiLayout.elements[section]}
                                            request={request}
                                            response={profileData}
                                            page={`${this.props.page}`}
                                            onRequestChange={(req) => this.handleRequestChange(req)}
                                            dynamicAttributes={dynamicAttributeProperties}
                                            errorCodes={errorCodes}
                                            showWarningAndError={showWarningAndError}
                                            onErrorCodes={(codes) => this.handleErrorMessagesFromSection(codes)}
                                            addValueToState={(field, value) => this.addValueToState(field, value)}
                                            validateWithStateVariable={(field, validation, value) => this.validateWithStateVariable(field, validation, value)}
                                            findValueFromState={(stateFieldName, fieldType) => this.findValueFromState(stateFieldName, fieldType)}
                                            isButtonClicked={this.state.isButtonClicked}
                                            handleOnClick={this.handleOnClick}
                                            canWrite={isHavingFFNo ? isHavingFFNo : isFFnoValidatedSuccesFully && section == CONFIC_SECTION_ALREADY_HAVE_FFNO ? false : undefined}
                                        />
                                    })
                                }
                                <div className="col-12 text-right btn-wrap btn-wrap--grp">

                                    <Button
                                        className="btn btn-secondary"
                                        handleOnClick={() => this.onCancel()}
                                        id={ID_SUBMIT_BUTTON}
                                        testIdentifier="btnCancel"
                                        label={t("enrolment.btn_cancel")} />

                                    <Button
                                        className="btn btn-primary"
                                        handleOnClick={() => this.enroll()}
                                        id={ID_SUBMIT_BUTTON}
                                        testIdentifier="btnEnrollment"
                                        label={t("enrolment.btn_sign_up")} />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        )
    }
}

function mapStateToProps(state) {
    return {
        sections: findValueFromObjectByPath(state, 'configurationReducer.enrol.ui.layout.order', []),
        uiLayout: findValueFromObjectByPath(state, 'configurationReducer.enrol.ui.layout', []),
        additionalMappings: findValueFromObjectByPath(state, 'configurationReducer.enrol.ui.request.additionalMapping', []),
        dynamicAttributes: findValueFromObjectByPath(state, 'configurationReducer.enrol.dynamicAttributes.enrol', []),
        dynamicAttributesPath: findValueFromObjectByPath(state, 'configurationReducer.enrol.ui.dynamicAttributesPath', ""),
        error: state.commonErrorReducer.error,
        enrolmentData: state.enrolment.enrolmentData,
        preaffliatedEnrolmentData: state.enrolment.preaffliatedEnrolmentData,
        preaffliatedData: state.enrolment.preaffliatedData,
        preaffliatedError: state.enrolment.preaffliatedError,
        config: state.configurationReducer[CONFIG_SECTION_ENROL],
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        accountSummaryConfig: state.configurationReducer[CONFIG_SECTION_ACCOUNT_SUMMARY],
        loginConfig: state.configurationReducer[CONFIG_SECTION_LOGIN],
        profileData: state.defaultUserProfileDataReducer.profileData,
    }
}

const mapDispatchToProps = {
    enrolment,
    checkGhostCardNumber,
    resetError,
    fetchConfiguration,
    logOut,
    setError,
    fetchDefaultUserProfileData
}
export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(Register)));
