import React, { Component } from 'react'
import parse from 'html-react-parser';
import { withTranslation } from 'react-i18next';
import { withSuspense } from '../../common/utils'
import './style.scss'
import PasswordImage from '../../../../public/images/image-password.png'

/**
 * PostEnrolment class.
 * @description For activation after enrolment.
 * @author Somdas M
 */
class PostEnrolmentCorporate extends Component {
    render() {
        const { t, data } = this.props
        return <main role="main" class="container">
            <div class="row">
                <div class="col-lg-4 col-md-4">
                    <div class="thumb">
                        <img src={PasswordImage} alt="password" />
                    </div>
                </div>
                <div class="col-lg-8 col-md-8">
                    <div class="description description--password">
                        <h1>{t('enrolment.success.corporateHeader')}</h1>
                        <p>{parse(t('enrolment.success.corporateDescription1').replace('{EMAIL_ADDRESS}', data.email ? data.email : ""))}</p>
                    </div>
                </div>
            </div>
        </main>
    }
}


PostEnrolmentCorporate.defaultProps = {
    data: {}
}

export default withSuspense()(withTranslation()(PostEnrolmentCorporate));