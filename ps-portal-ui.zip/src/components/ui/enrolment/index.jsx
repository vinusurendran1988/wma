import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import {
    withSuspense
} from '../../common/utils'

import {
    enrollLoginDetails,
} from './action'
import {
    ID_SUBMIT_BUTTON, ACTIVATION_TYPE_TWO_STEP
} from './Constants'
import {
    CONFIG_SECTION_ENROL, CONFIG_SECTION_LOGIN, CONFIG_SECTION_DEFAULT, PROGRAM_TYPE_CORPORATE,PROGRAM_TYPE_INDIVIDUAL
} from '../../common/utils/Constants'
import {
    getItemFromBrowserStorage,
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    BROWSER_STORAGE_KEY_PROGRAM_TYPE,
    setItemToBrowserStorage
} from '../../common/utils/storage.utils';
import Register from './Register';
import PostEnrolmentMember from './PostEnrolmentMember';
import PostEnrolmentCorporate from './PostEnrolmentCorporate';
import { findValueFromObjectByPath } from '../../common/utils/object.utils';
import { NAVIGATE_MEMBER_LOGIN } from '../../common/utils/urlConstants';
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';


/**
 * Enrolment class.
 * @description Registers a new user or displays activation message for an enrolled user.
 * @author Somdas M
 */
class Enrolment extends Component {

    constructor(props) {
        super(props)
        this.state = {
            activationType: 1
        }
        this.postEnrolment = this.postEnrolment.bind(this)
    }

    componentDidMount() {
        this.props.setPageInfo(this.props, { config: this.props.config, confSection: CONFIG_SECTION_ENROL })
    }
    
    postEnrolment(enrolmentData, stateData) {
        if (enrolmentData.object) {
            const programType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE)

            let { config } = this.props

            if (config.activationType == ACTIVATION_TYPE_TWO_STEP) {
                let emailAddress = ""
                if (programType == PROGRAM_TYPE_CORPORATE) {
                    if (config.ui && config.ui.layout && config.ui.layout.elements
                        && config.ui.layout.elements.postEnrolment && config.ui.layout.elements.postEnrolment.emailPath) {
                        emailAddress = findValueFromObjectByPath(stateData.request, config.ui.layout.elements.postEnrolment.emailPath, emailAddress)
                    }
                }
                this.setState({
                    activationType: 2,
                    emailAddress
                })
            } else {
                if (programType == PROGRAM_TYPE_CORPORATE) {
                    window.location.href = `#${NAVIGATE_MEMBER_LOGIN}`
                } else {
                    const membershipNumber = enrolmentData.object.memberAccount.membershipNumber
                    let payload = {
                        data: {
                            "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                            "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                            "membershipNumber": membershipNumber,
                            "customerPassword": stateData.password
                        },
                        clientId: this.props.loginConfig.ui.clientId,
                        secredId: this.props.loginConfig.ui.secret
                    };
                    this.props.enrollLoginDetails(payload, ID_SUBMIT_BUTTON)
                }
            }
        }
    }

    render() {
        const { t, defaultConfig } = this.props
        const currentProgram = getCurrentProgramFromDefaultConfig(defaultConfig)

        return (
            <div className="page__enrollment" data-test="enrolmentComponent">
                {
                    this.state.activationType == 1 ?
                        <Register postEnrolment={this.postEnrolment} {...this.props} /> :
                        currentProgram.programType == PROGRAM_TYPE_CORPORATE ?
                            <PostEnrolmentCorporate data={{ email: this.state.emailAddress }} /> :
                            <PostEnrolmentMember data={{ email: this.state.emailAddress }} />

                }
            </div>
        );
    }
}

function mapStateToProps(state) {
    return {
        config: state.configurationReducer[CONFIG_SECTION_ENROL],
        loginConfig: state.configurationReducer[CONFIG_SECTION_LOGIN],
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
    }
}

const mapDispatchToProps = { enrollLoginDetails }
export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(Enrolment)));
