import { startApiLoading, startButtonSpinner, stopApiLoading, stopButtonSpinner } from "../../common/components/fieldbank/loader/action";
import { _URL_ADD_COMPANION, _URL_RETRIEVE_NOMINEES } from "../../common/config/config";
import { getApiErrorMessage } from "../../common/utils";
import { doPost } from "../../common/utils/api";
import { ACTION_ADD_MEMBER_TRAVELLER, ACTION_RETRIEVE_TRAVEL_COMPANION, ADD_MEMBER_TRAVELLER } from "./constants";

/**
 * Action call to add travel companion
 * @param {JSON} payload Request payload to be dispatched
 * @param {String} id
 * 
 * @author Amrutha J Raj
 */

export const addOrDeleteTravelCompanion  = (payload, id) => {
    return async dispatch => {
        dispatch({
            type: ACTION_ADD_MEMBER_TRAVELLER,
            payload: {}
        })
        dispatch(startButtonSpinner(id, ADD_MEMBER_TRAVELLER))
        await doPost(_URL_ADD_COMPANION, payload)
            .then((response) => {
                dispatch(stopButtonSpinner(id, ADD_MEMBER_TRAVELLER))
                dispatch({
                    type: ACTION_ADD_MEMBER_TRAVELLER,
                    payload: response.data
                })
            })
            .catch((error) => {
                dispatch(stopButtonSpinner(id, ADD_MEMBER_TRAVELLER))
                dispatch({
                    type: ACTION_ADD_MEMBER_TRAVELLER,
                    payload: { error: getApiErrorMessage(error.response.data) }
                })
            })
    }
}


/**
 * Action call to retrieve travel companions
 * @param {JSON} payload Request payload to be dispatched
 * @param {String} id
 * 
 * @author Amrutha J Raj
 */
export const fetchTravelCompanion = (payload) => {
    return async dispatch => {
        dispatch({
            type: ACTION_RETRIEVE_TRAVEL_COMPANION,
            payload: {}
        })
        dispatch(startApiLoading("fetchTravelCompanion"))
        return await doPost(_URL_RETRIEVE_NOMINEES, payload)
            .then(response => {
                dispatch(stopApiLoading("fetchTravelCompanion"))
                dispatch({
                    type: ACTION_RETRIEVE_TRAVEL_COMPANION,
                    payload: response.data
                })
            })
            .catch((error) => {
                dispatch(stopApiLoading("fetchTravelCompanion"))
                dispatch({
                    type: ACTION_RETRIEVE_TRAVEL_COMPANION,
                    payload: { error: getApiErrorMessage(error.response.data) }
                })
            })
    };

}