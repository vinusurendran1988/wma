import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import CustomMessage from '../../common/components/custommessage';
import Button from '../../common/components/fieldbank/Button';
import {
    clearValidateResponse,
    fetchMasterData,
    resetError,
    setError,
    validateMemberDetails
} from '../../common/middleware/redux/commonAction';
import { getApiErrorMessage, withSuspense } from '../../common/utils';
import { CONFIG_SECTION_TRAVEL_COMPANION, COUNTRY_ISD, LANGUAGE, MEMBER, TITLE_GENDER, TITLE_GENDER_GF } from '../../common/utils/Constants';
import { doAdditionalMapping } from '../../common/utils/object.utils';
import { ADD_MEMBER } from '../manageaccountusers/Constants';
import Section from '../updateprofile/Section';
import { addOrDeleteTravelCompanion  } from './actions';
import { ADD_MEMBER_TRAVELLER, ADD_NON_MEMBER, DANGER, TAB_MEMBER, TAB_NON_MEMBER, VALIDATE_MEMBER } from './constants';

class AddTravelCompanion extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedTab: "",
            showWarningAndErrorValidate: false,
            showWarningAndErrorAdd: false,
            isValidateButtonClicked: false,
            isAddButtonClicked: false,
            isAddNonMemberButtonClicked: false,
            validateMemberRequest: {},
            validateUserResponseObject: {},
            isValidationSuccess: false,
            validateMemberError: [],
            addUserError: [],
            addNonMemberError: [],
            addUserAccountRequest: {},
            addMemberTravelCompanionRequest: {},
            addNonMemberTravelCompanionRequest: {},
            accountStatus: "",
            apiResponse: {
                type: "",
                messages: [],
                canTranslate: false
            },
            translate: false,
            disableValidateInfo: true
        }

    }
    componentDidMount() {
        this.changeTab(TAB_MEMBER)
        if (!this.props.languages || this.props.languages.length == 0) {
            this.props.fetchMasterData(LANGUAGE, this.props.masterEntityLookup, this.props.masterEntityLookupFilters)
        }
        if (!this.props.countries || this.props.countries.length == 0) {
            this.props.fetchMasterData(COUNTRY_ISD, this.props.masterEntityLookup, this.props.masterEntityLookupFilters)
        }

        if (!this.props.titles || this.props.titles.length == 0) {
            this.props.fetchMasterData(TITLE_GENDER_GF, this.props.masterEntityLookup, this.props.masterEntityLookupFilters)
        }


    }

    componentDidUpdate(prevProps) {
        const { config, errors } = this.props
        if (this.props.memberData && Object.keys(this.props.memberData).length > 0) {
            if (JSON.stringify(prevProps.memberData) !== JSON.stringify(this.props.memberData)) {
                if (config) {
                    if (config.ui && config.ui.layout &&
                        config.ui.layout.elements && config.ui.layout.elements &&
                        config.ui.layout.elements.add_travel_companion.layout &&
                        config.ui.layout.elements.add_travel_companion.layout.elements &&
                        config.ui.layout.elements.add_travel_companion.layout.elements.add_companion &&
                        config.ui.layout.elements.add_travel_companion.layout.elements.add_companion.member &&
                        config.ui.layout.elements.add_travel_companion.layout.elements.add_companion.member.request &&
                        config.ui.layout.elements.add_travel_companion.layout.elements.add_companion.member.request.additionalMapping
                    ) {
                        doAdditionalMapping(this, "addMemberTravelCompanionRequest", config.ui.layout.elements.add_travel_companion.layout.elements.add_companion.member.request.additionalMapping)
                    }
                }
                this.setState({
                    isValidationSuccess: true,
                    disableValidateInfo: false,
                    addUserError: [],
                    addNonMemberError: [],
                    validateMemberError: [],
                    validateUserResponseObject: {
                        object: this.props.memberData
                    }
                })
            }
        }
        if (errors) {
            if (errors.message && JSON.stringify(errors) != JSON.stringify(prevProps.errors)) {
                this.setState({
                    apiResponse: {
                        type: DANGER,
                        messages: getApiErrorMessage(errors),
                        canTranslate: false
                    }
                })
            }
        }

        if (JSON.stringify(prevProps.companionAddedResponse) != JSON.stringify(this.props.companionAddedResponse)) {
            this.props.companionAdded()
        }

    }

    /**
    * Handles the tab change
    * @param {Event} event 
    * @author Amrutha J Raj
    */
    changeTab(tab) {
        const { config } = this.props
        if (this.state.selectedTab != tab) {
            if (tab == TAB_NON_MEMBER) {
                this.setState({
                    addMemberTravelCompanionRequest: {},
                    validateMemberRequest: {},
                    isValidationSuccess: false
                })
                this.doAdditionalMappingForNonMember(tab);
                this.props.clearValidateResponse()
            }
            else if (tab == MEMBER) {
                this.initializePage()
                this.setState(
                    {
                        disableValidateInfo: true,
                        addNonMemberTravelCompanionRequest: {}
                    })
            }

            this.setState({
                selectedTab: tab,
                dropdownDisplay: "none",
                showWarningAndErrorValidate: false,
                showWarningAndErrorAdd: false,
                showWarningAndErrorNonMember: false,
                isAddButtonClicked: false,
                isValidateButtonClicked: false,
                isAddNonMemberButtonClicked: false
            })

        }
    }


    /**
    * Method to invoke additional mapping for non member
    * 
    * @param {String} tab
    * @author Amrutha J Raj
    */
    doAdditionalMappingForNonMember = (tab) => {
        const { config } = this.props
        if (config && config.ui && config.ui.layout && config.ui.layout.elements &&
            config.ui.layout.elements.add_travel_companion && config.ui.layout.elements.add_travel_companion.layout &&
            config.ui.layout.elements.add_travel_companion.layout.elements &&
            config.ui.layout.elements.add_travel_companion.layout.elements.add_companion[tab] &&
            config.ui.layout.elements.add_travel_companion.layout.elements.add_companion[tab].request &&
            config.ui.layout.elements.add_travel_companion.layout.elements.add_companion[tab].request.additionalMapping) {
            doAdditionalMapping(this, "addNonMemberTravelCompanionRequest",
                config.ui.layout.elements.add_travel_companion.layout.elements.add_companion[tab].request.additionalMapping)
        }
    }
    /**
    * Initialize the page
    * 
    * @author Amrutha J Raj
    */
    initializePage() {
        const { config } = this.props

        if (config) {
            if (config.ui && config.ui.layout &&
                config.ui.layout.elements &&
                config.ui.layout.elements.add_travel_companion &&
                config.ui.layout.elements.add_travel_companion.layout &&
                config.ui.layout.elements.add_travel_companion.layout.elements &&
                config.ui.layout.elements.add_travel_companion.layout.elements.validate_companion &&
                config.ui.layout.elements.add_travel_companion.layout.elements.validate_companion.request &&
                config.ui.layout.elements.add_travel_companion.layout.elements.validate_companion.request.additionalMapping
            ) {
                doAdditionalMapping(this, "validateMemberRequest", config.ui.layout.elements.add_travel_companion.layout.elements.validate_companion.request.additionalMapping)
            }
        }
    }

    /**
    * Method to get the tabs from config
    * 
    * @author Amrutha J Raj
    */
    getTabsFromConfig = () => {
        const { config } = this.props
        if (config.ui && config.ui.layout &&
            config.ui.layout.elements &&
            config.ui.layout.elements.add_travel_companion &&
            config.ui.layout.elements.add_travel_companion.tabs) {
            return config.ui.layout.elements.add_travel_companion.tabs
        }
    }

    /**
    * Handle request change for textfield from Section
    * @param {Object} request
    * @author Amrutha J Raj
    */
    handleRequestChange(request, key) {
        const payload = {}
        if (key == VALIDATE_MEMBER) {
            this.setState({ validateMemberRequest: request })
        }
        else if (key == ADD_MEMBER) {
            this.setState({ addMemberTravelCompanionRequest: request })
        }
        else if (key == ADD_NON_MEMBER) {
            this.setState({ addNonMemberTravelCompanionRequest: request })
        }
        this.setState({
            showWarningAndErrorValidate: false,
            showWarningAndErrorAdd: false,
            showWarningAndErrorNonMember: false
        })
    }

    /**
     * Handle validation error messages from Section
     * @param {key} request
     * @param {codes} codes
     * @author Amrutha J Raj
     */
    handleErrorMessagesFromSection(key, codes) {
        if (!codes.length) { this.props.resetError() }
        if (JSON.stringify(codes) != JSON.stringify(this.state[key])) {
            this.setState({ [key]: codes })
        }
    }

    /**
    * Set state from Section
    * @param {Object} field
    * @param {String} value
    * 
    * @author Amrutha J Raj
    */
    addValueToState(field, value) {
        let newState = {}
        newState[field.name] = value
        this.setState(newState)
    }

    /**
    * Method to handle validations from Section
    * @param {Object} field
    * @param {Object} validation
    * @param {String} value 
    *
    * @author Amrutha J Raj
    */
    validateWithStateVariable(field, validation, value, key) {
        let { pattern, fields } = validation
        let isValidationSuccess = true, canUpdateState = false
        fields.forEach((fd) => {
            const newPattern = pattern.replace("[fields]", this.state[fd])
            if (!isPatternMatch(newPattern, value)) {
                isValidationSuccess = false
            }
        })
        let errorCodes = this.state[key]
        if (!isValidationSuccess) {
            if (!errorCodes.includes(validation.customMessageId)) {
                errorCodes.push(validation.customMessageId)
                canUpdateState = true
            }
        } else if (errorCodes.includes(validation.customMessageId)) {
            const index = errorCodes.indexOf(validation.customMessageId)
            if (index > -1) {
                canUpdateState = true
                errorCodes.splice(index, 1)
            }
        }
        field.error = !isValidationSuccess
        if (canUpdateState) {
            this.setState({
                [key]: errorCodes,
                translate: true
            })
        }
        return !isValidationSuccess
    }

    /**
    * Method to find value from state
    * @param {Object} stateFieldName
    * 
    * @author Amrutha J Raj
    */
    findValueFromState(stateFieldName) {
        return this.state[stateFieldName] ? this.state[stateFieldName] : ""
    }

    /**
    * Method to validate member
    * 
    * 
    * @author Amrutha J Raj
    */
    validateMember = () => {
        const { validateMemberError, validateMemberRequest } = this.state;
        this.setState({ addUserError: [], apiResponse: {}, addNonMemberError: [] })
        if (validateMemberError.length > 0) {
            this.props.setError(validateMemberError);
        } else {
            this.props.resetError()
            this.props.validateMemberDetails(validateMemberRequest)
        }
        this.setState({
            showWarningAndErrorValidate: true,
            isValidateButtonClicked: true
        })
    }

    /**
    * Method to reset form data
    * 
    * 
    * @author Amrutha J Raj
    */
    resetFormData() {
        this.props.resetError()
        this.props.clearValidateResponse()

        this.setState({
            isValidateButtonClicked: false,
            isAddButtonClicked: false,
            isAddNonMemberButtonClicked: false,
            validateMemberRequest: {},
            disableValidateInfo: true,
            validateUserResponseObject: {},
            isValidationSuccess: false,
            addUserAccountRequest: {},
            addMemberTravelCompanionRequest: {},
            addNonMemberTravelCompanionRequest: {},
            showWarningAndErrorValidate: false,
            showWarningAndErrorAdd: false,
            showWarningAndErrorNonMember: false
        }, () => {
            this.initializePage()
            if (this.state.selectedTab == TAB_NON_MEMBER) {
                this.doAdditionalMappingForNonMember(TAB_NON_MEMBER)
            }
        })
    }


    /**
    * Method to add travel companion(member/non-member)
    * 
    * 
    * @author Amrutha J Raj
    */
    addTravelCompanion = () => {
        const { addUserError, addNonMemberError, selectedTab } = this.state;
        const { config } = this.props

        if (addUserError.length > 0 && selectedTab == TAB_MEMBER) {
            this.props.setError(addUserError);
            this.setState({
                showWarningAndErrorAdd: true,
                isAddButtonClicked: true
            })
        }
        else if (addNonMemberError.length > 0 && selectedTab == TAB_NON_MEMBER) {
            this.props.setError(addNonMemberError);
            this.setState({
                showWarningAndErrorNonMember: true,
                isAddNonMemberButtonClicked: true
            })
        }
        else {
            this.props.selectedAction("add")
            if (this.state.selectedTab == TAB_MEMBER) {
                this.props.addOrDeleteTravelCompanion (this.state.addMemberTravelCompanionRequest, ADD_MEMBER_TRAVELLER)
            }
            else if (this.state.selectedTab == TAB_NON_MEMBER) {
                this.props.addOrDeleteTravelCompanion (this.state.addNonMemberTravelCompanionRequest, ADD_NON_MEMBER)
            }
        }

    }
    render() {
        const { t, config, memberData } = this.props
        const {
            showWarningAndErrorAdd,
            isValidateButtonClicked,
            isAddButtonClicked,
            isAddNonMemberButtonClicked,
            showWarningAndErrorValidate,
            showWarningAndErrorNonMember,
            apiResponse,
            selectedTab,
            validateMemberError,
            addUserError,
            addNonMemberError } = this.state
        let errorCodes = []
        if (isAddButtonClicked ) {
            errorCodes = [...validateMemberError, ...addUserError]
        }
        else if (isValidateButtonClicked ) {
            errorCodes = [...validateMemberError]
        }
        else if (isAddNonMemberButtonClicked) {
            errorCodes = [...addNonMemberError]
        }
        const tabs = config && this.getTabsFromConfig()
        let sectionElements = {}
        let memberSectionElements = {}
        let nonMemberSectionElements = {}
        if (config && config.ui && config.ui.layout &&
            config.ui.layout.elements && config.ui.layout.elements.add_travel_companion &&
            config.ui.layout.elements.add_travel_companion.layout &&
            config.ui.layout.elements.add_travel_companion.layout.elements
        ) {
            sectionElements = config.ui.layout.elements.add_travel_companion.layout.elements
            if (sectionElements && sectionElements.add_companion && sectionElements.add_companion.member &&
                sectionElements.add_companion.member.layout && sectionElements.add_companion.member.layout.elements &&
                sectionElements.add_companion.member.layout.elements.memberFields
            ) {
                memberSectionElements = sectionElements.add_companion.member.layout.elements.memberFields
            }
            if (sectionElements && sectionElements.add_companion && sectionElements.add_companion.nonMember &&
                sectionElements.add_companion && sectionElements.add_companion.nonMember.layout &&
                sectionElements.add_companion.nonMember.layout.elements && sectionElements.add_companion.nonMember.layout.elements &&
                sectionElements.add_companion.nonMember.layout.elements.nonMemberFields
            ) {
                nonMemberSectionElements = sectionElements.add_companion.nonMember.layout.elements.nonMemberFields
            }
        }
        return (
            <div>
                {(showWarningAndErrorValidate || showWarningAndErrorAdd || showWarningAndErrorNonMember) &&
                    <CustomMessage type={errorCodes.length > 0 ? DANGER : apiResponse.type}
                        message={errorCodes.length > 0 ? errorCodes : apiResponse.messages}
                        data-test="customMessageComponent"
                        canTranslate={errorCodes.length > 0 ? errorCodes.length > 0 : apiResponse.canTranslate} />}
                <nav data-test="navigation" className="tab">
                    <div id='countries' className="tab__mob">
                        <i className="fa fa-caret-down" aria-hidden="true"></i>
                        <dl>
                            <dt>
                                <a data-test="default-tab" onClick={() => this.setState({ dropdownDisplay: "block" })}>
                                    <span>{t(`travel_companion.add_travel_companion.tabs.${selectedTab}`)}</span></a>
                            </dt>
                            <dd>
                                <ul data-test="tab-list" style={{ display: this.state.dropdownDisplay }}>
                                    {tabs && tabs.map((tab, index) => {
                                        return (<li key={index}>
                                            <a data-test={`tab-Mob-${index}`} onClick={() => this.changeTab(tab)}>
                                                {t(`travel_companion.add_travel_companion.tabs.${tab}`)}</a></li>)
                                    })}
                                </ul>
                            </dd>
                        </dl>
                    </div>

                    <div className="nav nav-tabs nav-tabs--booking" id="nav-tab" role="tablist">
                        {tabs && tabs.map((tab, index) => {
                            return (
                                <a className={"nav-item nav-link " + (selectedTab === tab ? "active" : "")}
                                    key={index}
                                    data-test={`tab-btn-${index}`}
                                    id="nav-home-tab"
                                    onClick={() => this.changeTab(tab)}
                                    data-toggle="tab" href={`${tab}`} role="tab" aria-controls="nav-1" aria-selected="true">
                                    <span>  {t(`travel_companion.add_travel_companion.tabs.${tab}`)}</span>
                                </a>
                            )
                        })}
                    </div>
                </nav>
                <div className="tab-content" id="nav-tabContent">
                    <div className="tab-pane fade show active" id="nav-1" role="tabpanel" aria-labelledby="nav-home-tab">
                        <div className="col-xl-8 col-lg-10 col-md-12">
                            <div className="form-row">
                                {
                                    this.state.selectedTab == TAB_MEMBER ?
                                        // Add Travel Companion Member 
                                        <>
                                            <div className="col-lg-12">
                                                {sectionElements && <Section
                                                    key={"add-account-user"}
                                                    page={"add_account_user"}
                                                    id={"add-account-user"}
                                                    displayElements={sectionElements.validate_companion}
                                                    request={this.state.validateMemberRequest}
                                                    canWrite={this.state.disableValidateInfo}
                                                    onRequestChange={(req) => this.handleRequestChange(req, VALIDATE_MEMBER)}
                                                    dynamicAttributes={""}
                                                    errorCodes={this.state.validateMemberError}
                                                    handleOnClick={() => this.validateMember()}
                                                    showWarningAndError={showWarningAndErrorValidate}
                                                    onErrorCodes={(codes) => this.handleErrorMessagesFromSection(codes, "validateMemberError")}
                                                    isButtonClicked={isValidateButtonClicked}
                                                    addValueToState={(field, value) => this.addValueToState(field, value)}
                                                    validateWithStateVariable={(field, validation, value) => this.validateWithStateVariable(field, validation, value, "validateMemberError")}
                                                    findValueFromState={(stateFieldName, fieldType) => this.findValueFromState(stateFieldName, fieldType)}
                                                />}
                                            </div>
                                            {this.state.isValidationSuccess ?
                                                <>
                                                    <div className="col-lg-12">
                                                        {sectionElements && <Section
                                                            key={"add-account-user"}
                                                            page={"add_account_user"}
                                                            id={"add-account-user"}
                                                            displayElements={memberSectionElements}
                                                            request={this.state.addMemberTravelCompanionRequest}
                                                            onRequestChange={(req) => this.handleRequestChange(req, ADD_MEMBER)}
                                                            dynamicAttributes={""}
                                                            errorCodes={this.state.addUserError}
                                                            showWarningAndError={showWarningAndErrorAdd}
                                                            onErrorCodes={(codes) => this.handleErrorMessagesFromSection(codes, "addUserError")}
                                                            isButtonClicked={isAddButtonClicked}
                                                            addValueToState={(field, value) => this.addValueToState(field, value)}
                                                            validateWithStateVariable={(field, validation, value) => this.validateWithStateVariable(field, validation, value, "addUserError")}
                                                            findValueFromState={(stateFieldName, fieldType) => this.findValueFromState(stateFieldName, fieldType)}
                                                        />}

                                                        <div className="btn-wrap btn-wrap--grp text-lg-right">
                                                            <Button
                                                                className="btn btn-secondary"
                                                                handleOnClick={() => this.resetFormData()}
                                                                id={"id-cancel"}
                                                                label={t("travel_companion.add_travel_companion.cancelBtn")} />
                                                            <Button
                                                                className="btn btn-primary"
                                                                handleOnClick={() => this.addTravelCompanion()}
                                                                id={"id-add"}
                                                                label={t("travel_companion.add_travel_companion.addBtn")} />
                                                        </div>
                                                    </div>
                                                </>
                                                :
                                                ""
                                            }


                                        </>
                                        :
                                        // Add Travel Companion Non-Member 
                                        <div className="col-lg-12">
                                            {sectionElements && <Section
                                                key={"add-account-user"}
                                                page={"add_account_user"}
                                                id={"add-account-user"}
                                                displayElements={nonMemberSectionElements}
                                                request={this.state.addNonMemberTravelCompanionRequest}
                                                onRequestChange={(req) => this.handleRequestChange(req, ADD_NON_MEMBER)}
                                                dynamicAttributes={""}
                                                errorCodes={this.state.addNonMemberError}
                                                showWarningAndError={showWarningAndErrorNonMember}
                                                onErrorCodes={(codes) => this.handleErrorMessagesFromSection(codes, "addNonMemberError")}
                                                isButtonClicked={isAddNonMemberButtonClicked}
                                                addValueToState={(field, value) => this.addValueToState(field, value)}
                                                validateWithStateVariable={(field, validation, value) => this.validateWithStateVariable(field, validation, value, "addNonMemberError")}
                                                findValueFromState={(stateFieldName, fieldType) => this.findValueFromState(stateFieldName, fieldType)}
                                            />}

                                            <div className="btn-wrap btn-wrap--grp text-lg-right">
                                                <Button
                                                    className="btn btn-secondary"
                                                    handleOnClick={() => this.resetFormData()}
                                                    id={"id-cancel"}
                                                    label={t("travel_companion.add_travel_companion.cancelBtn")} />
                                                <Button
                                                    className="btn btn-primary"
                                                    handleOnClick={() => this.addTravelCompanion()}
                                                    id={"id-add"}
                                                    label={t("travel_companion.add_travel_companion.addBtn")} />
                                            </div>
                                        </div>
                                }

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        config: state.configurationReducer[CONFIG_SECTION_TRAVEL_COMPANION],
        memberData: state.validateMemberDetailReducer.validateMemberData,
        masterEntityLookup: state.masterEntityDataReducer.masterEntityLookup,
        languages: state.masterData[LANGUAGE] ? state.masterData[LANGUAGE] : [],
        countries: state.masterData[COUNTRY_ISD] ? state.masterData[COUNTRY_ISD] : [],
        titles: state.masterData[TITLE_GENDER] ? state.masterData[TITLE_GENDER] : [],
        masterEntityLookupFilters: state.masterEntityDataReducer.masterEntityLookupFilters,
        errors: state.commonErrorReducer.error,
        companionAddedResponse: state.travelCompanionReducer.response
    }
}
const mapDispatchToProps = {
    setError,
    resetError,
    validateMemberDetails,
    addOrDeleteTravelCompanion,
    fetchMasterData,
    clearValidateResponse
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(AddTravelCompanion)));
