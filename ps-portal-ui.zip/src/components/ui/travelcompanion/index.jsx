import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import CustomMessage from '../../common/components/custommessage';
import Button from '../../common/components/fieldbank/Button';
import {
  clearValidateResponse,
  fetchAccountNominee, fetchConfiguration
} from '../../common/middleware/redux/commonAction';
import {
  getApiErrorMessage, getCurrentDate, withSuspense
} from '../../common/utils';
import {
  CONFIG_SECTION_TRAVEL_COMPANION, DD_MMM_YYYY
} from '../../common/utils/Constants';
import { doAdditionalMapping } from '../../common/utils/object.utils';
import { fetchTravelCompanion } from './actions';
import AddTravelCompanion from './AddTravelCompanion';
import { DANGER, RESPONSE_SUCCESS, SUCCESS } from './constants';
import TravelCompanionTable from './TravelCompanionTable';

/**
 * Travel companion class.
 * @description Loads data to display .
 * @author Geo George
 */
class TravelCompanion extends Component {
  constructor(props) {
    super(props);
    this.state = {
      claimToDate: getCurrentDate(DD_MMM_YYYY),
      claimFromDate: undefined,
      pageNumber: undefined,
      pageSize: undefined,
      listToDisplay: [],
      loading: false,
      doEnableNextButton: false,
      doEnablePreviousButton: false,
      indexList: [],
      currentIndexListArrayPosition: 0,
      availablePageSizes: [],
      isRedirected: false,
      referenceNo: "",
      redirectToAddTravelCompanion: false,
      apiResponse: {},
      travellerDeleted: false,
      buttonClicked: "",
      viewTravelCompanionRequest: {}
    }
    this.handleTravelCompanionTableChange = this.handleTravelCompanionTableChange.bind(this);
    this.resetToInitialState = this.resetToInitialState.bind(this);
    this.handlePreviousButtonClick = this.handlePreviousButtonClick.bind(this);
    this.handleNextButtonClick = this.handleNextButtonClick.bind(this);
  }

  componentDidMount() {
    this.props.setPageInfo(this.props, { config: this.props.config, confSection: CONFIG_SECTION_TRAVEL_COMPANION })
    if (this.props.config) {
      const config = this.props.config
      const availablePageSizes = []
      config.ui.availablePageSizes.forEach(p => {
        availablePageSizes.push({
          label: p,
          value: p
        })
      })
      this.setState({
        pageSize: config.ui.defaultPageSize,
        indexList: [config.ui.defaultAbsoluteIndex],
        pageNumber: config.ui.defaultPageNumber,
        availablePageSizes: availablePageSizes
      })
      this.fetchTravelCompanionList();
    }

  }

  componentDidUpdate(prevProps, prevState) {
    const { apiResponse, buttonClicked } = this.state
    const { companionAddedResponse, config, travelCompanionList } = this.props
    if (prevProps.config != this.props.config) {
      if (
        this.props.config &&
        this.props.config.ui
      ) {
        const config = this.props.config
        const availablePageSizes = []
        config.ui.availablePageSizes.forEach(p => {
          availablePageSizes.push({
            label: p,
            value: p
          })
        })
        this.setState({
          //   claimFromDate: getRelativeDate(this.state.claimToDate, -1 * config.ui.claimDuration, DD_MMM_YYYY, DD_MMM_YYYY),
          pageSize: config.ui.defaultPageSize,
          indexList: [config.ui.defaultAbsoluteIndex],
          pageNumber: config.ui.defaultPageNumber,
          availablePageSizes: availablePageSizes
        })
      }
    }

    if (JSON.stringify(prevProps.travelCompanionList) !== JSON.stringify(travelCompanionList)
      && travelCompanionList && Object.keys(travelCompanionList).length > 0) {
      let list = [];
      if (travelCompanionList.nomineeDetails) {
        list = travelCompanionList.nomineeDetails
      }
      this.setState({
        listToDisplay: list,
        loading: false
      });
      this.fetchTravelCompanionList()
    }

    let status = this.state.buttonClicked
    if (JSON.stringify(prevProps.companionAddedResponse) != JSON.stringify(companionAddedResponse)) {
      this.fetchTravelCompanionList()
      if (companionAddedResponse && companionAddedResponse.statusMessage == RESPONSE_SUCCESS &&
        buttonClicked == "add") {
        apiResponse["type"] = SUCCESS
        apiResponse["messages"] = [('travel_companion.messages.add_message')]
        apiResponse["canTranslate"] = true
      }
      else if (companionAddedResponse && companionAddedResponse.statusMessage == RESPONSE_SUCCESS &&
        buttonClicked == "delete") {
        apiResponse["type"] = SUCCESS
        apiResponse["messages"] = [('travel_companion.messages.deleted_messsage')]
        apiResponse["canTranslate"] = true
        status = ""
      }
      else if (companionAddedResponse && companionAddedResponse.error) {
        apiResponse["type"] = DANGER
        apiResponse["messages"] = companionAddedResponse.error.length > 0 && getApiErrorMessage(companionAddedResponse.error[0].error)
        apiResponse["canTranslate"] = false
      }
      this.setState({ apiResponse, buttonClicked: status })
    }

  }

  fetchTravelCompanionList() {
    if (!this.state.loading) {
      this.setState({
        loading: true
      });
      if (this.props.config && this.props.config.ui &&
        this.props.config.ui.layout && this.props.config.ui.layout.elements &&
        this.props.config.ui.layout.elements && this.props.config.ui.layout.elements.view_travel_companion &&
        this.props.config.ui.layout.elements.view_travel_companion.request &&
        this.props.config.ui.layout.elements.view_travel_companion.request.additionalMapping
      ) {
        doAdditionalMapping(this, "viewTravelCompanionRequest", this.props.config.ui.layout.elements.view_travel_companion.request.additionalMapping)
      }
      this.props.fetchTravelCompanion(this.state.viewTravelCompanionRequest)
    }
  }

  handleTravelCompanionTableChange(value) {
    this.setState({
      pageSize: value,
      listToDisplay: []
    })
  }

  resetToInitialState() {
    this.setState({
      pageNumber: this.props.config.ui.defaultPageNumber,
      listToDisplay: [],
      loading: false,
      doEnableNextButton: false,
      doEnablePreviousButton: false,
      indexList: [this.props.config.ui.defaultAbsoluteIndex],
      currentIndexListArrayPosition: 0
    });
  }

  handlePreviousButtonClick(event) {
    this.setState({
      currentIndexListArrayPosition: this.state.currentIndexListArrayPosition - 1
    })
  }

  handleNextButtonClick(event) {
    this.setState({
      currentIndexListArrayPosition: this.state.currentIndexListArrayPosition + 1
    })
  }

  getCompanionAddedResponse = () => {
    this.setState(
      { redirectToAddTravelCompanion: false, showSuccessMessage: true })
  }

  render() {

    const {
      availablePageSizes,
      listToDisplay,
      pageSize,
      doEnableNextButton,
      doEnablePreviousButton,
      apiResponse
    } = this.state;
    const { config, t, travelCompanionRequest } = this.props;
    let columns = []
    if (
      config &&
      config.ui &&
      config.ui.layout &&
      config.ui.layout.elements &&
      config.ui.layout.elements.view_travel_companion &&
      config.ui.layout.elements.view_travel_companion.table &&
      config.ui.layout.elements.view_travel_companion.table.columns
    ) {
      columns = config.ui.layout.elements.view_travel_companion.table.columns
    }
    // }

    return (
      <>
        <h1>{this.state.redirectToAddTravelCompanion ?
          t('travel_companion.add_travel_companion.title') :
          t('travel_companion.title')}</h1>
        {apiResponse && apiResponse.type && apiResponse.type.length > 0 &&
          <CustomMessage type={apiResponse.type}
            message={apiResponse.messages}
            data-test="customMessageComponent" canTranslate={apiResponse.canTranslate} />
        }
        <div className="form-row mb-4 align-items-center">
          <div className="col-lg-10">
            <p>
              {t('travel_companion.add_travel_companion.descriptionOne')}
              <br />
              {t('travel_companion.add_travel_companion.descriptionTwo')}
            </p>
          </div>
          <div className="col-lg-2 text-right">
            <Button
              type="button"
              className="btn btn-secondary btn-sm"
              handleOnClick={() => {
                this.props.clearValidateResponse()
                this.setState({
                  redirectToAddTravelCompanion: !this.state.redirectToAddTravelCompanion, apiResponse: {}
                })
              }
              }
              label={this.state.redirectToAddTravelCompanion ?
                t("travel_companion.view_travel_companion.view_travel_btn") :
                t("travel_companion.add_travel_companion.add_travel_btn")
              }
            />
          </div>
        </div>
        {this.state.redirectToAddTravelCompanion ?
          <AddTravelCompanion
            selectedAction={(actionType) => this.setState({ buttonClicked: actionType })}
            companionAdded={() => this.getCompanionAddedResponse()} />
          :
          <>
            <TravelCompanionTable
              selectedAction={(actionType) => this.setState({ buttonClicked: actionType })}
              field={{
                values: listToDisplay ? listToDisplay : [],
                columns: columns ? columns : [],
                globalFilter: undefined
              }}
              className={"table table-striped"}
            />
          </>
        }
      </>
    )

  }
}

const mapStateToProps = (state) => {
  return {
    config: state.configurationReducer[CONFIG_SECTION_TRAVEL_COMPANION],
    travelCompanionList: state.retrieveTravelCompanionReducer.companions,
    companionAddedResponse: state.travelCompanionReducer.response
  }
}

const mapDispatchToProps = {
  fetchConfiguration,
  fetchAccountNominee,
  fetchTravelCompanion,
  clearValidateResponse
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(withRouter(TravelCompanion))));

