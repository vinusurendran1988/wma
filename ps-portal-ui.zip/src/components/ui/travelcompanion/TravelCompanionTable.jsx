import { Dialog } from 'primereact/dialog';
import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import FieldBank from '../../common/components/fieldbank';
import Button from '../../common/components/fieldbank/Button';
import { FIELDTYPE_TABLE } from '../../common/components/fieldbank/Constants';
import {
    fetchConfiguration, fetchMasterData
} from '../../common/middleware/redux/commonAction';
import {
    withSuspense
} from '../../common/utils';
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';
import {
    CONFIG_SECTION_DEFAULT, CONFIG_SECTION_TRAVEL_COMPANION
} from '../../common/utils/Constants';
import { doAdditionalMapping } from '../../common/utils/object.utils';
import { addOrDeleteTravelCompanion } from './actions';
import { ACCOUNT_STATUS, ACTIVE, DELETED } from './constants';

let relationshipList = [];
class TravelCompanionTable extends Component {
    constructor(props) {
        super(props);
        this.state = {
            pageSize: this.props.maxPageSize,
            deleteTravelCompanionRequest: {},
            openDeleteConfirmModal : false,
            companionToBeDeleted : {}
        }
        this.deleteTravelCompanion = this.deleteTravelCompanion.bind(this)

    }

    componentDidMount() {
        if (!this.props.accountStatusList || this.props.accountStatusList.length == 0) {
            this.props.fetchMasterData(ACCOUNT_STATUS, this.props.masterEntityLookup, this.props.masterEntityLookupFilters)
        }
        this.setState({
            pageSize: this.props.pageSize
        })
        const defaultConfig = getCurrentProgramFromDefaultConfig(this.props.defaultConfig)
        relationshipList = defaultConfig && defaultConfig.data ? defaultConfig.data.relationshipCodes : [];
    }

  

  /**
  * Column template for delete action
  * @param {rowData} 
  * @param {props} props
  * @author Amrutha J Raj
  * 
  */
    actionBodyTemplate = (rowData, props) => {
        return (
            rowData.nomineeStatus == ACTIVE &&
            <React.Fragment>
                <div className="actions">
                    <i className="fa fa-trash custom-icon" type="button"
                        title="Delete"
                        onClick={() => this.setState({ companionToBeDeleted: rowData, openDeleteConfirmModal: true })} aria-hidden="true"></i>
                </div>
            </React.Fragment>
        )
    }

 /**
    * Method to delete travel companion 
    * @param {travelCompanion}  travelCompanion to be deleted
    *
    * @author Amrutha J Raj
    *
    */
    deleteConfirmModal = () => {
        return (<Dialog
            aria-labelledby={`Label`}
            aria-modal="true"
            id={"delete"}
            dismissableMask={true}
            closable={false}
            visible={this.state.openDeleteConfirmModal}
            header=""
            className="confirm-modal"
            onHide={() => this.setState({ openDeleteConfirmModal: false })}
            footer={
                <div className="btn-wrap btn-wrap--grp">
                    <Button
                        className="btn btn-secondary"
                        handleOnClick={() => this.setState({ openDeleteConfirmModal: false })}
                        id="delete-cancel"
                        label={this.props.t("travel_companion.delete_prompt.cancel")} />
                    <Button
                        className="btn btn-primary"
                        handleOnClick={() => this.deleteTravelCompanion(this.state.companionToBeDeleted)}
                        id="delete-button"
                        label={this.props.t("travel_companion.delete_prompt.submit")} />
                </div>
            }
        >
            <div className="modal-body">
                <h4>{this.props.t("travel_companion.delete_prompt.message")}</h4>
            </div>
        </Dialog>
        )
    }


    /**
  * Column template for showing the status
  * @param {rowData} 
  * @param {props} props
  * @author Amrutha J Raj
  * 
  */
    statusBodyTemplate = (rowData, props) => {
        if (this.props.accountStatusList) {
            let selectedObj = this.props.accountStatusList.find(item => item.FieldValue == rowData.nomineeStatus)
            if (selectedObj && Object.keys(selectedObj).length > 0) {
                return (
                    <React.Fragment>
                        <span className={`badge ${selectedObj.FieldDescription == DELETED ?
                            "badge-danger" : "badge-success"}`}>
                            {selectedObj.FieldDescription}</span>
                    </React.Fragment>
                );
            }
        }
    }

  /**
  * Method to delete a travel companion
  * @param {rowData} 
  * @param {props} props
  * @author Amrutha J Raj
  * 
  */
    deleteTravelCompanion = (companionData) => {
        const { config } = this.props
        this.setState({ travellerDetails: companionData, openDeleteConfirmModal : false }, () => {
            this.props.selectedAction("delete")
            if (config) {
                if (config.ui && config.ui.layout &&
                    config.ui.layout.elements &&
                    config.ui.layout.elements.delete_travel_companion &&
                    config.ui.layout.elements.delete_travel_companion.request &&
                    config.ui.layout.elements.delete_travel_companion.request.additionalMapping) {
                    doAdditionalMapping(this, "deleteTravelCompanionRequest", config.ui.layout.elements.delete_travel_companion.request.additionalMapping)
                    this.props.addOrDeleteTravelCompanion(this.state.deleteTravelCompanionRequest)

                }
            }
        })
    }

/**
     * Template for showing relationship
     * @param {rowData} 
     * @param {props} props
     * @author Amrutha J Raj
     * 
     */
    relationshipTemplate(rowData, props) {
        let keyVal = rowData[props.field];
        let filterObj = relationshipList.filter(item => item.key == keyVal);
        let relationshipval = filterObj[0].value;
        return <React.Fragment>
            <span>{relationshipval}</span>
        </React.Fragment>
    }

    render() {
        const { globalFilter, field, t, className } = this.props;
        return (
            <>
            <FieldBank
                field={{
                    fieldType: FIELDTYPE_TABLE,
                    globalFilter: globalFilter,
                    emptyMessage: t("claim_summary.no_summary"),
                    bodyTemplates: {
                        "actionBodyTemplate": this.actionBodyTemplate,
                        "dateTemplate": this.dateTemplate,
                        "relationshipTemplate": this.relationshipTemplate,
                        "statusBodyTemplate": this.statusBodyTemplate,

                    },
                    ...field
                }}
                className={className}
            />
             { this.deleteConfirmModal()}
            </>
        );
    }

}

TravelCompanionTable.propTypes = {
};

TravelCompanionTable.defaultProps = {
};

const mapStateToProps = (state) => {
    return ({
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        masterEntityLookup: state.masterEntityDataReducer.masterEntityLookup,
        masterEntityLookupFilters: state.masterEntityDataReducer.masterEntityLookupFilters,
        accountStatusList: state.masterData[ACCOUNT_STATUS] ? state.masterData[ACCOUNT_STATUS] : [],
        config: state.configurationReducer[CONFIG_SECTION_TRAVEL_COMPANION],

    })
}
const mapDispatchToProps = {
    fetchConfiguration,
    fetchMasterData,
    addOrDeleteTravelCompanion
}


export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(TravelCompanionTable)));