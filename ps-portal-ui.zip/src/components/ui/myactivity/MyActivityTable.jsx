import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import {
    withSuspense
} from '../../common/utils';
import FieldBank from '../../common/components/fieldbank';
import { FIELDTYPE_TABLE } from '../../common/components/fieldbank/Constants';
import { _IMAGE_BASEURL } from '../../common/config/config';


/**
 * Table to display activity history.
 * @author Ajmal Aliyar
 */
class MyActivityTable extends Component {
    constructor(props) {
        super(props);
        this.state = {
            pageSize: this.props.pageSize
        }
        this.getPointByFieldName = this.getPointByFieldName.bind(this)
        this.pointsBodyTemplate = this.pointsBodyTemplate.bind(this)
        //this.getPartnerNameByCode = this.getPartnerNameByCode.bind(this)
        this.partnerTemplate = this.partnerTemplate.bind(this)

    }

    componentDidMount() {
        this.setState({
            pageSize: this.props.pageSize
        })
    }

    descriptionColumnBodyTemplate(data, props) {
        let creditFlag = true;
        let debitFlag = true;
        return (
            <React.Fragment>
                <span className="p-column-title">{props.header}</span>
                <div class="desc-wrap">
                    <div class="desc-icon">
                        {
                            data.pointDetails.map(item => {
                                if (item.points < 0 && debitFlag) {
                                    debitFlag = false
                                    return (<i className="icon-arw"> <img src={`${_IMAGE_BASEURL}/icons/icon-arw-rit-red.svg`} alt={"right arrow"}></img> <br /></i>)
                                } else if (item.points > 0 && creditFlag) {
                                    creditFlag = false
                                    return (<i className="icon-arw"> <img src={`${_IMAGE_BASEURL}/icons/icon-arw-left-green.svg`} alt={"left arrow"}></img><br /></i>)
                                }
                            })
                        }
                    </div>
                    <div class="desc-text">
                        {data[props.field]}
                    </div>
                </div>
            </React.Fragment>
        );
    }
    getPointByFieldName(rowData, field) {
        let data = rowData.pointDetails.find(item => item.pointDetails === field)
        return data ? data.points : '';
    }
    pointsBodyTemplate(rowData, props) {
        let point = this.getPointByFieldName(rowData, props.field);
        if (point != undefined) {
            if (rowData[props.field] == undefined) {
                rowData[props.field] = point
            }
            return (
                <React.Fragment>
                    <span className="p-column-title">{props.header}</span>
                    <strong className={`${(point < 0) ? "danger" : "success"}`}>
                        {point && parseInt(point)}
                    </strong>
                </React.Fragment>
            );
        }
    }

    dateTemplate(rowData, props) {
        const date = rowData[props.field].split("-")
        return <React.Fragment>
            <span className="p-column-title">{props.header}</span>
            <span className="p-column-date">
                {date[0]}<span className="devider">-</span>{date[1]}<span className="devider">-</span>{date[2]}
            </span>
        </React.Fragment>

    }
    getPartnerNameByCode(partnerCode, partnerList) {
        let data = partnerList.find(item => item.value === partnerCode)
        return data ? data.name : '';
    }
    partnerTemplate(rowData, props) {
        let partnerName = this.getPartnerNameByCode(rowData[props.field.split("-")[0]], props.partnerList);
        if (partnerName != undefined) {
            rowData[props.field] = partnerName
            return (
                <React.Fragment>
                    <span className="p-column-title">{props.header}</span>
                    <span className="p-column-partner">{partnerName}</span>
                </React.Fragment>
            );
        }
    }
    render() {
        const { field, className, t, globalFilter, exportStr, exportFileName, onValueChange, partnerList } = this.props;
        return (<FieldBank
            field={{
                fieldType: FIELDTYPE_TABLE,
                globalFilter: globalFilter,
                exportStr: exportStr,
                exportFileName: exportFileName,
                onValueChange: onValueChange,
                partnerList: partnerList,
                emptyMessage: t("my_activity.my_activity_table.no_activities_found"),
                bodyTemplates: {
                    "pointsBodyTemplate": this.pointsBodyTemplate,
                    "defaultColumnBodyTemplate": this.partnerTemplate,
                    "descriptionColumnBodyTemplate": this.descriptionColumnBodyTemplate,
                    "dateTemplate": this.dateTemplate
                },
                ...field
            }}
            className={className}
        />);
    }

}

MyActivityTable.propTypes = {
};

MyActivityTable.defaultProps = {
};

const mapStateToProps = (state) => {
    return {
    }
}
const mapDispatchToProps = {
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(MyActivityTable)));