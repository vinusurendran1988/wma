import React from 'react';
import MyActivity from './index';
import { findByTestAttr, findComponent, mockServiceResponse } from '../../common/testUtils/index';
import { testStore } from '../../common/utils';
import moxios from 'moxios';
import { mount } from 'enzyme';
import ReactTestUtils from 'react-dom/test-utils';
import { Provider } from 'react-redux';
import {
    actionRetrieveActivityDetails
} from './actions';
import { CONFIG_SECTION_ACTIVITYDETAILS } from '../../common/utils/Constants';
import { fetchConfiguration } from '../../common/middleware/redux/commonAction';
import { axiosInstance } from '../../common/utils/api'
import MyActivityTable from './MyActivityTable';
let store = undefined
let rootComponent;
let rootComponentChild;
let component;
let childComponent
let storeState;

const setUp = (props) => {
    props.setPageInfo = jest.fn();
    rootComponent = mount(
        <Provider store={store}>
            <MyActivity {...props} />
        </Provider>
    );
    component = findComponent(rootComponent, 'MyActivity');
};

const setUpChild = (props) => {
    rootComponentChild = mount(
        <Provider store={store}>
            <MyActivityTable {...props} />
        </Provider>
    );
    childComponent = findComponent(rootComponentChild, 'MyActivityTable');
};

/**
 * Tests for MyActivity Component.
 * @author Ajmal Aliyar
 */
describe("MyActivity Component", () => {

    describe("Success scenarios", () => {
        beforeEach(() => {
            store = undefined
            store = testStore({})
            moxios.install(axiosInstance);
        });

        afterEach(() => {
            moxios.uninstall(axiosInstance);
        });

        test("Page navigation", () => {
            setUp({});
            mockServiceResponse(configResponse, 200)
            return ReactTestUtils.act(() => {
                return store.dispatch(
                    fetchConfiguration(CONFIG_SECTION_ACTIVITYDETAILS)
                )
                    .then(() => {
                        rootComponent.update();
                        component = component.update()
                        storeState = store.getState();
                        expect(storeState.myActivityReducer.config).toBe(configResponse.config);

                        mockServiceResponse(response01, 200)
                        return store.dispatch(
                            actionRetrieveActivityDetails({
                                attr: "attr1String"
                            })
                        ).then(() => {
                            rootComponent.update();
                            storeState = store.getState();
                            expect(storeState.myActivityReducer.activityDetail).toBe(response01.object);
                            let nextButton = findByTestAttr(rootComponent, 'myactivity-next-page-btn');
                            expect(nextButton.length).toBe(1);
                            rootComponent.update();
                            nextButton.props().onClick({})

                            mockServiceResponse(response02, 200)
                            return store.dispatch(
                                actionRetrieveActivityDetails({
                                    attr: "attr1String"
                                })
                            )
                                .then(() => {
                                    rootComponent.update();
                                    let previousPageButton = findByTestAttr(rootComponent, 'myactivity-prev-page-btn');
                                    expect(previousPageButton.length).toBe(1);
                                    rootComponent.update();
                                    previousPageButton.props().onClick({})

                                    mockServiceResponse(response01, 200)
                                    return store.dispatch(
                                        actionRetrieveActivityDetails({
                                            attr: "attr1String"
                                        })
                                    )
                                        .then(() => {
                                            rootComponent.update();

                                            //PageSize change
                                            let pageSizeDropDown = findByTestAttr(rootComponent, "activity-page-size-id")
                                            // pageSizeDropDown = pageSizeDropDown.find(Dropdown);
                                            pageSizeDropDown.prop('onChange')({ target: { value: '20' } })

                                            //ActivityTypeFilter Change
                                            let activityTypeFilter = findByTestAttr(rootComponent, "category-dropdown-id")
                                            activityTypeFilter.prop('onChange')({ target: { value: 'AC' } })

                                            //MonthSpanFilter Change (1 month)
                                            rootComponent.update();

                                            let monthSpanFilter = findByTestAttr(rootComponent, "category-transactions-id")
                                            monthSpanFilter.prop('onChange')({ target: { value: '1' } })

                                           

                                        })
                                })

                        })

                    });
            });
        })

        test("Page Filters", () => {
            setUp({});
            mockServiceResponse(configResponse, 200)
            return ReactTestUtils.act(() => {
                return store.dispatch(
                    fetchConfiguration(CONFIG_SECTION_ACTIVITYDETAILS)
                )
                    .then(() => {
                        rootComponent.update();
                        component = component.update()
                        storeState = store.getState();
                        expect(storeState.myActivityReducer.config).toBe(configResponse.config);

                        mockServiceResponse(response01, 200)
                        return store.dispatch(
                            actionRetrieveActivityDetails({
                                attr: "attr1String"
                            })
                        ).then(() => {
                            rootComponent.update();
                            let myActivity = findByTestAttr(rootComponent, "MyActivity")
                            storeState = store.getState();
                            expect(storeState.myActivityReducer.activityDetail).toBe(response01.object);            
                        })

                    });
            });
        })
        test("Page search", () => {
            setUp({});
            mockServiceResponse(configResponse, 200)
            return ReactTestUtils.act(() => {
                return store.dispatch(
                    fetchConfiguration(CONFIG_SECTION_ACTIVITYDETAILS)
                )
                    .then(() => {
                        rootComponent.update();
                        component = component.update()
                        storeState = store.getState();
                        expect(storeState.myActivityReducer.config).toBe(configResponse.config);

                        mockServiceResponse(response01, 200)
                        return store.dispatch(
                            actionRetrieveActivityDetails({
                                attr: "attr1String"
                            })
                        ).then(() => {
                            rootComponent.update();
                            storeState = store.getState();
                            expect(storeState.myActivityReducer.activityDetail).toBe(response01.object);
                            let tableSearch = findByTestAttr(rootComponent, "table-search")
                            tableSearch.prop('onChange')({ target: { value: '2021' } })
                            rootComponent.update();
                        })

                    });
            });
        })

        test("Page partner filter", () => {
            setUp({});
            mockServiceResponse(configResponse, 200)
            return ReactTestUtils.act(() => {
                return store.dispatch(
                    fetchConfiguration(CONFIG_SECTION_ACTIVITYDETAILS)
                )
                    .then(() => {
                        rootComponent.update();
                        component = component.update()
                        storeState = store.getState();
                        expect(storeState.myActivityReducer.config).toBe(configResponse.config);

                        mockServiceResponse(response01, 200)
                        return store.dispatch(
                            actionRetrieveActivityDetails({
                                attr: "attr1String"
                            })
                        ).then(() => {
                            rootComponent.update();
                            storeState = store.getState();
                            expect(storeState.myActivityReducer.activityDetail).toBe(response01.object);
                            let tableSearch = findByTestAttr(rootComponent, "export-link")
                            tableSearch = tableSearch.find("#dropdownMenuLink");
                            expect(tableSearch.getDOMNode().getAttribute('href')).toBe("#");
                            rootComponent.update();                           

                            let partnerFilter = findByTestAttr(rootComponent, "partner-filter")
                            let partnerSearch = findByTestAttr(partnerFilter, "filterPartner")
                            partnerSearch.prop('handleSelectEvent')({ target: { value: 'NZ' } })
                            rootComponent.update();

                            let cancelButton = findByTestAttr(rootComponent, 'partner-filter-cancel-btn');
                            expect(cancelButton.length).toBe(1);
                            rootComponent.update();
                            cancelButton.props().onClick({})
                            rootComponent.update();

                            let applyButton = findByTestAttr(rootComponent, 'partner-filter-apply-btn');
                            expect(applyButton.length).toBe(1);
                            rootComponent.update();
                            applyButton.props().onClick({})
                            rootComponent.update();


                        })

                    });
            });
        })

        test("Date range clear function", () => {
            setUp({});        
            component.instance().handleDateRangeClear()
        })
        test("handle date range", () => {
            setUp({});     
            const minDate= new Date()
            const maxDate= new Date()   
            const dateObj=[minDate,maxDate];   
            component.instance().handleDateRangeSelection(dateObj)
        })
        test("MyActivity table points body template", () => {
             
            setUpChild({});  
            const rowDate = {"pointDetails":[{"pointDetails":"BASE","points":"1000"},{"pointDetails":"LP","points":"2000"}]}      
            const props = {"field":"BASE","header":"BASE"}
            childComponent.instance().pointsBodyTemplate(rowDate,props)
        })

        test("MyActivity table description body template", () => {
             
            setUpChild({});  
            const rowDate = {"pointDetails":[{"pointDetails":"BASE","points":"1000"},{"pointDetails":"LP","points":"2000"}]}      
            const props = {"field":"BASE","header":"BASE"}
            childComponent.instance().descriptionColumnBodyTemplate(rowDate,props)
        })

        test("MyActivity table date body template", () => {
             
            setUpChild({});  
            const rowDate = {"date":"23-05-21"}      
            const props = {"field":"date","header":"date"}
            childComponent.instance().dateTemplate(rowDate,props)
        })

   
    })

    describe('Failure Scenarios', () => {
        beforeEach(() => {
            store = undefined
            store = testStore({})
            moxios.install(axiosInstance);
        });

        afterEach(() => {
            moxios.uninstall(axiosInstance);
        });

        test('activities Service call', () => {
            mockServiceResponse(activitiesResponseError, 500)
            return store.dispatch(
                actionRetrieveActivityDetails({
                    attr: "blum"
                })
            )
                .then(() => {
                    const newState = store.getState();
                    expect(newState.myActivityReducer.activityDetail).toBeUndefined();
                });
        })
    })

})

const configResponse = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "section": "activitydetails", "companyCode": "IBS", "programCode": "PRG14", "isProtectedApi": true, "activityStatus": "P", "activityCode": "", "openingBalanceRequired": false, "activityAttributesRequired": "N", "sortOrder": "D", "preferredLanguageCode": "EN", "dateTypeIdentifier": "A", "activityTypes": [{ "code": "", "name": "All Transactions" }, { "code": "AC", "name": "Accrual Activity" }, { "code": "EP", "name": "Expire Points" }, { "code": "MU", "name": "Manual Adjustment" }, { "code": "ME", "name": "Member Enrollment" }, { "code": "BP", "name": "Purchase Miles" }, { "code": "TP", "name": "Transfer Miles" }, { "code": "RP", "name": "Renew Miles" }, { "code": "RD", "name": "Redemption" }, { "code": "TC", "name": "Tier Change" }, { "code": "RPE", "name": "Reset Mile Expiry" }, { "code": "COMP", "name": "Compensations" }], "ui": {"defaultNumberOfDaysToDisplay": "30", "defaultPageNumber": 1, "defaultAbsoluteIndex": 1, "defaultPageSize": 10, "availablePageSizes": [10, 20, 50, 100], "transactionMonthSpans": [{ "label": "Transactions in 1 month", "value": "1" }, { "label": "Transactions in 3 months", "value": "3" }, { "label": "Transactions in 6 months", "value": "6" }, { "label": "Transactions this year", "value": "12" }, { "label": "Date Range", "value": "DATE_RANGE" }] } } }
const configResponseError = { "statuscode": "500", "statusMessage": "FAILURE", "error": { "code": "500", "type": "INTERNAL_SERVER_ERROR", "message": "Some error" } }
const activitiesResponseError = { "statuscode": "500", "statusMessage": "FAILURE", "error": { "code": "500", "type": "INTERNAL_SERVER_ERROR", "message": "Some error" } }
const response01 = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0000000515", "activityDetails": [{ "activityType": "Point Transfer", "activityDate": "24-Jul-2020", "locationActivityDate": "24-Jul-2020 19:46:01", "activityDescription": "Miles  transferred from KUMAR SRINIVAS.", "activityStatusCode": "P", "activityStatusDescription": "Processed", "reasonCode": null, "parentActivityType": null, "activityReferenceNumber": "ACT5117", "hasNextPage": true, "absoluteIndex": 81, "partnerCode": null, "activityCode": "TP", "poolActivity": "false", "dependentActivity": null, "pointDetails": [{ "pointType": "BASE", "pointDetails": "Skypass Miles", "points": 1000, "bonusDetails": [], "creditLimit": 0 }], "activityAttributes": [], "accrualDynamicAttributes": [], "redemptionDynamicAttributes": [], "partnerDynamicAttributes": [], "activityAdhocAttributes": [], "multilingualActivityDescriptions": [{ "languageCode": "EN", "description": "Miles  transferred from KUMAR SRINIVAS." }], "multilingualActivityRemarks": [] }, { "activityType": "Point Transfer", "activityDate": "24-Jul-2020", "locationActivityDate": "24-Jul-2020 19:46:01", "activityDescription": "Miles  transferred from KUMAR SRINIVAS.", "activityStatusCode": "P", "activityStatusDescription": "Processed", "reasonCode": null, "parentActivityType": null, "activityReferenceNumber": "ACT5117", "hasNextPage": true, "absoluteIndex": 81, "partnerCode": null, "activityCode": "TP", "poolActivity": "false", "dependentActivity": null, "pointDetails": [{ "pointType": "BASE", "pointDetails": "Skypass Miles", "points": -1000, "bonusDetails": [], "creditLimit": 0 }], "activityAttributes": [], "accrualDynamicAttributes": [], "redemptionDynamicAttributes": [], "partnerDynamicAttributes": [], "activityAdhocAttributes": [], "multilingualActivityDescriptions": [{ "languageCode": "EN", "description": "Miles  transferred from KUMAR SRINIVAS." }], "multilingualActivityRemarks": [] }, { "activityType": "Adhoc Activity", "activityDate": "14-Jul-2020", "locationActivityDate": "14-Jul-2020 14:44:52", "activityDescription": "Purchase Miles", "activityStatusCode": "P", "activityStatusDescription": "Processed", "reasonCode": null, "parentActivityType": null, "activityReferenceNumber": "ACT4080", "hasNextPage": true, "absoluteIndex": 81, "partnerCode": null, "activityCode": "BP", "poolActivity": "false", "dependentActivity": null, "pointDetails": [], "activityAttributes": [], "accrualDynamicAttributes": [], "redemptionDynamicAttributes": [], "partnerDynamicAttributes": [], "activityAdhocAttributes": [], "multilingualActivityDescriptions": [{ "languageCode": "EN", "description": "Purchase Miles" }], "multilingualActivityRemarks": [] }, { "activityType": "Adhoc Activity", "activityDate": "14-Jul-2020", "locationActivityDate": "14-Jul-2020 11:56:59", "activityDescription": "Purchase Miles", "activityStatusCode": "P", "activityStatusDescription": "Processed", "reasonCode": null, "parentActivityType": null, "activityReferenceNumber": "ACT4075", "hasNextPage": true, "absoluteIndex": 81, "partnerCode": "KE", "activityCode": "BP", "poolActivity": "false", "dependentActivity": null, "pointDetails": [], "activityAttributes": [], "accrualDynamicAttributes": [], "redemptionDynamicAttributes": [], "partnerDynamicAttributes": [], "activityAdhocAttributes": [], "multilingualActivityDescriptions": [{ "languageCode": "EN", "description": "Purchase Miles" }], "multilingualActivityRemarks": [] }, { "activityType": "Adhoc Activity", "activityDate": "14-Jul-2020", "locationActivityDate": "14-Jul-2020 11:13:42", "activityDescription": "Purchase Miles", "activityStatusCode": "P", "activityStatusDescription": "Processed", "reasonCode": null, "parentActivityType": null, "activityReferenceNumber": "ACT4072", "hasNextPage": true, "absoluteIndex": 81, "partnerCode": "PRG1", "activityCode": "BP", "poolActivity": "false", "dependentActivity": null, "pointDetails": [], "activityAttributes": [], "accrualDynamicAttributes": [], "redemptionDynamicAttributes": [], "partnerDynamicAttributes": [], "activityAdhocAttributes": [], "multilingualActivityDescriptions": [{ "languageCode": "EN", "description": "Purchase Miles" }], "multilingualActivityRemarks": [] }, { "activityType": "Adhoc Activity", "activityDate": "14-Jul-2020", "locationActivityDate": "14-Jul-2020 11:13:21", "activityDescription": "Purchase Miles", "activityStatusCode": "P", "activityStatusDescription": "Processed", "reasonCode": null, "parentActivityType": null, "activityReferenceNumber": "ACT4071", "hasNextPage": true, "absoluteIndex": 81, "partnerCode": "PRG", "activityCode": "BP", "poolActivity": "false", "dependentActivity": null, "pointDetails": [], "activityAttributes": [], "accrualDynamicAttributes": [], "redemptionDynamicAttributes": [], "partnerDynamicAttributes": [], "activityAdhocAttributes": [], "multilingualActivityDescriptions": [{ "languageCode": "EN", "description": "Purchase Miles" }], "multilingualActivityRemarks": [] }, { "activityType": "Adhoc Activity", "activityDate": "14-Jul-2020", "locationActivityDate": "14-Jul-2020 11:13:05", "activityDescription": "Purchase Miles", "activityStatusCode": "P", "activityStatusDescription": "Processed", "reasonCode": null, "parentActivityType": null, "activityReferenceNumber": "ACT4070", "hasNextPage": true, "absoluteIndex": 81, "partnerCode": "PRG", "activityCode": "BP", "poolActivity": "false", "dependentActivity": null, "pointDetails": [], "activityAttributes": [], "accrualDynamicAttributes": [], "redemptionDynamicAttributes": [], "partnerDynamicAttributes": [], "activityAdhocAttributes": [], "multilingualActivityDescriptions": [{ "languageCode": "EN", "description": "Purchase Miles" }], "multilingualActivityRemarks": [] }, { "activityType": "Adhoc Activity", "activityDate": "14-Jul-2020", "locationActivityDate": "14-Jul-2020 11:12:42", "activityDescription": "Purchase Miles", "activityStatusCode": "P", "activityStatusDescription": "Processed", "reasonCode": null, "parentActivityType": null, "activityReferenceNumber": "ACT4069", "hasNextPage": true, "absoluteIndex": 81, "partnerCode": "PRG", "activityCode": "BP", "poolActivity": "false", "dependentActivity": null, "pointDetails": [], "activityAttributes": [], "accrualDynamicAttributes": [], "redemptionDynamicAttributes": [], "partnerDynamicAttributes": [], "activityAdhocAttributes": [], "multilingualActivityDescriptions": [{ "languageCode": "EN", "description": "Purchase Miles" }], "multilingualActivityRemarks": [] }, { "activityType": "Adhoc Activity", "activityDate": "06-Jul-2020", "locationActivityDate": "06-Jul-2020 19:56:33", "activityDescription": "Purchase Miles", "activityStatusCode": "P", "activityStatusDescription": "Processed", "reasonCode": null, "parentActivityType": null, "activityReferenceNumber": "ACT4011", "hasNextPage": true, "absoluteIndex": 81, "partnerCode": "PRG", "activityCode": "BP", "poolActivity": "false", "dependentActivity": null, "pointDetails": [], "activityAttributes": [], "accrualDynamicAttributes": [], "redemptionDynamicAttributes": [], "partnerDynamicAttributes": [], "activityAdhocAttributes": [], "multilingualActivityDescriptions": [{ "languageCode": "EN", "description": "Purchase Miles" }], "multilingualActivityRemarks": [] }, { "activityType": "Adhoc Activity", "activityDate": "06-Jul-2020", "locationActivityDate": "06-Jul-2020 10:43:52", "activityDescription": "Purchase Miles", "activityStatusCode": "P", "activityStatusDescription": "Processed", "reasonCode": null, "parentActivityType": null, "activityReferenceNumber": "ACT4010", "hasNextPage": true, "absoluteIndex": 81, "partnerCode": "PRG", "activityCode": "BP", "poolActivity": "false", "dependentActivity": null, "pointDetails": [], "activityAttributes": [], "accrualDynamicAttributes": [], "redemptionDynamicAttributes": [], "partnerDynamicAttributes": [], "activityAdhocAttributes": [], "multilingualActivityDescriptions": [{ "languageCode": "EN", "description": "Purchase Miles" }], "multilingualActivityRemarks": [] }], "openingBalancePointDetails": null } }
const response02 = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0000000515", "activityDetails": [{ "activityType": "Point Transfer", "activityDate": "24-Jul-2020", "locationActivityDate": "24-Jul-2020 19:46:01", "activityDescription": "Miles  transferred from KUMAR SRINIVAS.", "activityStatusCode": "P", "activityStatusDescription": "Processed", "reasonCode": null, "parentActivityType": null, "activityReferenceNumber": "ACT5117", "hasNextPage": false, "absoluteIndex": 82, "partnerCode": null, "activityCode": "TP", "poolActivity": "false", "dependentActivity": null, "pointDetails": [{ "pointType": "BASE", "pointDetails": "Skypass Miles", "points": 1000, "bonusDetails": [], "creditLimit": 0 }], "activityAttributes": [], "accrualDynamicAttributes": [], "redemptionDynamicAttributes": [], "partnerDynamicAttributes": [], "activityAdhocAttributes": [], "multilingualActivityDescriptions": [{ "languageCode": "EN", "description": "Miles  transferred from KUMAR SRINIVAS." }], "multilingualActivityRemarks": [] }, { "activityType": "Point Transfer", "activityDate": "24-Jul-2020", "locationActivityDate": "24-Jul-2020 19:46:01", "activityDescription": "Miles  transferred from KUMAR SRINIVAS.", "activityStatusCode": "P", "activityStatusDescription": "Processed", "reasonCode": null, "parentActivityType": null, "activityReferenceNumber": "ACT5117", "hasNextPage": false, "absoluteIndex": 82, "partnerCode": null, "activityCode": "TP", "poolActivity": "false", "dependentActivity": null, "pointDetails": [{ "pointType": "BASE", "pointDetails": "Skypass Miles", "points": -1000, "bonusDetails": [], "creditLimit": 0 }], "activityAttributes": [], "accrualDynamicAttributes": [], "redemptionDynamicAttributes": [], "partnerDynamicAttributes": [], "activityAdhocAttributes": [], "multilingualActivityDescriptions": [{ "languageCode": "EN", "description": "Miles  transferred from KUMAR SRINIVAS." }], "multilingualActivityRemarks": [] }, { "activityType": "Adhoc Activity", "activityDate": "14-Jul-2020", "locationActivityDate": "14-Jul-2020 14:44:52", "activityDescription": "Purchase Miles", "activityStatusCode": "P", "activityStatusDescription": "Processed", "reasonCode": null, "parentActivityType": null, "activityReferenceNumber": "ACT4080", "hasNextPage": false, "absoluteIndex": 82, "partnerCode": null, "activityCode": "BP", "poolActivity": "false", "dependentActivity": null, "pointDetails": [], "activityAttributes": [], "accrualDynamicAttributes": [], "redemptionDynamicAttributes": [], "partnerDynamicAttributes": [], "activityAdhocAttributes": [], "multilingualActivityDescriptions": [{ "languageCode": "EN", "description": "Purchase Miles" }], "multilingualActivityRemarks": [] }, { "activityType": "Adhoc Activity", "activityDate": "14-Jul-2020", "locationActivityDate": "14-Jul-2020 11:56:59", "activityDescription": "Purchase Miles", "activityStatusCode": "P", "activityStatusDescription": "Processed", "reasonCode": null, "parentActivityType": null, "activityReferenceNumber": "ACT4075", "hasNextPage": false, "absoluteIndex": 82, "partnerCode": "KE", "activityCode": "BP", "poolActivity": "false", "dependentActivity": null, "pointDetails": [], "activityAttributes": [], "accrualDynamicAttributes": [], "redemptionDynamicAttributes": [], "partnerDynamicAttributes": [], "activityAdhocAttributes": [], "multilingualActivityDescriptions": [{ "languageCode": "EN", "description": "Purchase Miles" }], "multilingualActivityRemarks": [] }, { "activityType": "Adhoc Activity", "activityDate": "14-Jul-2020", "locationActivityDate": "14-Jul-2020 11:13:42", "activityDescription": "Purchase Miles", "activityStatusCode": "P", "activityStatusDescription": "Processed", "reasonCode": null, "parentActivityType": null, "activityReferenceNumber": "ACT4072", "hasNextPage": false, "absoluteIndex": 82, "partnerCode": "PRG1", "activityCode": "BP", "poolActivity": "false", "dependentActivity": null, "pointDetails": [], "activityAttributes": [], "accrualDynamicAttributes": [], "redemptionDynamicAttributes": [], "partnerDynamicAttributes": [], "activityAdhocAttributes": [], "multilingualActivityDescriptions": [{ "languageCode": "EN", "description": "Purchase Miles" }], "multilingualActivityRemarks": [] }, { "activityType": "Adhoc Activity", "activityDate": "14-Jul-2020", "locationActivityDate": "14-Jul-2020 11:13:21", "activityDescription": "Purchase Miles", "activityStatusCode": "P", "activityStatusDescription": "Processed", "reasonCode": null, "parentActivityType": null, "activityReferenceNumber": "ACT4071", "hasNextPage": false, "absoluteIndex": 82, "partnerCode": "PRG", "activityCode": "BP", "poolActivity": "false", "dependentActivity": null, "pointDetails": [], "activityAttributes": [], "accrualDynamicAttributes": [], "redemptionDynamicAttributes": [], "partnerDynamicAttributes": [], "activityAdhocAttributes": [], "multilingualActivityDescriptions": [{ "languageCode": "EN", "description": "Purchase Miles" }], "multilingualActivityRemarks": [] }, { "activityType": "Adhoc Activity", "activityDate": "14-Jul-2020", "locationActivityDate": "14-Jul-2020 11:13:05", "activityDescription": "Purchase Miles", "activityStatusCode": "P", "activityStatusDescription": "Processed", "reasonCode": null, "parentActivityType": null, "activityReferenceNumber": "ACT4070", "hasNextPage": false, "absoluteIndex": 82, "partnerCode": "PRG", "activityCode": "BP", "poolActivity": "false", "dependentActivity": null, "pointDetails": [], "activityAttributes": [], "accrualDynamicAttributes": [], "redemptionDynamicAttributes": [], "partnerDynamicAttributes": [], "activityAdhocAttributes": [], "multilingualActivityDescriptions": [{ "languageCode": "EN", "description": "Purchase Miles" }], "multilingualActivityRemarks": [] }, { "activityType": "Adhoc Activity", "activityDate": "14-Jul-2020", "locationActivityDate": "14-Jul-2020 11:12:42", "activityDescription": "Purchase Miles", "activityStatusCode": "P", "activityStatusDescription": "Processed", "reasonCode": null, "parentActivityType": null, "activityReferenceNumber": "ACT4069", "hasNextPage": false, "absoluteIndex": 82, "partnerCode": "PRG", "activityCode": "BP", "poolActivity": "false", "dependentActivity": null, "pointDetails": [], "activityAttributes": [], "accrualDynamicAttributes": [], "redemptionDynamicAttributes": [], "partnerDynamicAttributes": [], "activityAdhocAttributes": [], "multilingualActivityDescriptions": [{ "languageCode": "EN", "description": "Purchase Miles" }], "multilingualActivityRemarks": [] }, { "activityType": "Adhoc Activity", "activityDate": "06-Jul-2020", "locationActivityDate": "06-Jul-2020 19:56:33", "activityDescription": "Purchase Miles", "activityStatusCode": "P", "activityStatusDescription": "Processed", "reasonCode": null, "parentActivityType": null, "activityReferenceNumber": "ACT4011", "hasNextPage": false, "absoluteIndex": 82, "partnerCode": "PRG", "activityCode": "BP", "poolActivity": "false", "dependentActivity": null, "pointDetails": [], "activityAttributes": [], "accrualDynamicAttributes": [], "redemptionDynamicAttributes": [], "partnerDynamicAttributes": [], "activityAdhocAttributes": [], "multilingualActivityDescriptions": [{ "languageCode": "EN", "description": "Purchase Miles" }], "multilingualActivityRemarks": [] }, { "activityType": "Adhoc Activity", "activityDate": "06-Jul-2020", "locationActivityDate": "06-Jul-2020 10:43:52", "activityDescription": "Purchase Miles", "activityStatusCode": "P", "activityStatusDescription": "Processed", "reasonCode": null, "parentActivityType": null, "activityReferenceNumber": "ACT4010", "hasNextPage": false, "absoluteIndex": 82, "partnerCode": "PRG", "activityCode": "BP", "poolActivity": "false", "dependentActivity": null, "pointDetails": [], "activityAttributes": [], "accrualDynamicAttributes": [], "redemptionDynamicAttributes": [], "partnerDynamicAttributes": [], "activityAdhocAttributes": [], "multilingualActivityDescriptions": [{ "languageCode": "EN", "description": "Purchase Miles" }], "multilingualActivityRemarks": [] }], "openingBalancePointDetails": null } }
