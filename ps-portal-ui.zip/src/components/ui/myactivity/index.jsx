import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withSuspense, getFormattedDate,setTimeForDate } from '../../../components/common/utils';
import { withTranslation } from 'react-i18next';
import Button from '../../common/components/fieldbank/Button';
import MyActivityTable from './MyActivityTable';
import {
    actionRetrieveActivityDetails,
} from './actions';
import {
    getCurrentDate,
    getRelativeDate,
    getDateWithRelativeMonth
} from '../../common/utils/index';
import {
    fetchConfiguration,
    fetchMasterData
} from '../../common/middleware/redux/commonAction'
import {
    CONFIG_SECTION_ACTIVITYDETAILS,PROGRAM_TYPE_CORPORATE, CONFIG_SECTION_DEFAULT, DD_MM_YYYY_HH_MM_SS, DD_MM_YYYY, AIRLINES, EXPORT_CSV, EXPORT_XLSX, EXPORT_PDF, CALENDAR_SELECTION_MODE
} from '../../common/utils/Constants';
import {
    SELECT_DATE_RANGE
} from './Constants';
import {
    getItemFromBrowserStorage,
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
    BROWSER_STORAGE_KEY_PROGRAM_TYPE,
} from '../../common/utils/storage.utils';
import DropDown from '../../common/components/fieldbank/DropDown';
import AutoCompleteField from '../../common/components/AutocompleteField';
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';
import { FIELDTYPE_DATE } from '../../common/components/fieldbank/Constants';
import FieldBank from '../../common/components/fieldbank';
import parse from 'html-react-parser';

/**
 * Page which display activity summary.
 * @author Ajmal Aliyar
 */
class MyActivity extends Component {

    constructor(props) {
        super(props);
        this.state = {
            enableCustomDaterange: false,
            indexList: [],
            currentIndexListArrayPosition: 0,
            doEnableNextButton: false,
            doEnablePreviousButton: false,
            loading: false,
            availablePageSizes: [],
            activityTypes: [],
            defaultNumberOfDaysToDisplay: "",
            transactionMonthSpans: [],
            selectedMonthSpan: "",
            activityStatus: "",
            activityCode: "",
            openingBalanceRequired: "",
            activityAttributesRequired: "",
            fromDate: "",
            toDate: "",
            sortOrder: "",
            preferredLanguageCode: "",
            dateTypeIdentifier: "",
            pageNumber: "",
            pageSize: "",
            transactionId: "_",
            globalFilter: "",
            partnerFilterFlag: false,
            listToDisplay: [],
            filterActiveFlag: false,
            selectedPartner: {
                name: "",
                value: ""
            },
            canFilterPopUpShow: false,
            exportFlag: false

        }
        this.datePicker = React.createRef();

        this.handleActivityTypeFilterChange = this.handleActivityTypeFilterChange.bind(this)
        this.handleMonthSpanFilterChange = this.handleMonthSpanFilterChange.bind(this)
        this.onMonthSpanChange = this.onMonthSpanChange.bind(this)
        this.handlePageSizeChange = this.handlePageSizeChange.bind(this)
        this.handlePreviousButtonClick = this.handlePreviousButtonClick.bind(this)
        this.updateNextButtonStatus = this.updateNextAndPreviousButtonStatuses.bind(this)
        this.handleNextButtonClick = this.handleNextButtonClick.bind(this)
        this.handleDateRangeSelection = this.handleDateRangeSelection.bind(this)
        this.callRetrieveActivitiesApi = this.callRetrieveActivitiesApi.bind(this)

    }

    componentDidMount() {
        this.props.setPageInfo(this.props, {config: this.props.config, confSection: CONFIG_SECTION_ACTIVITYDETAILS})
        if (this.props.config) {
            this.setConfigurations(this.props.config);
        }
    }

    componentDidUpdate(prevProps, prevState) {

        if ((prevProps.config !== this.props.config) && this.props.config) {
            this.setConfigurations(this.props.config);
        }

        if (this.shouldFireRetrieveActivities(prevState, this.state)) {
            this.setState({ loading: true })
            this.callRetrieveActivitiesApi();
        }

        if (prevProps.activityDetail !== this.props.activityDetail) {
            const listToDisplay = (this.props.activityDetail && this.props.activityDetail.activityDetails)
                ? this.props.activityDetail.activityDetails
                : []
            this.setState({
                listToDisplay,
                exportFlag: listToDisplay.length > 0 ? true : false
            })
            this.updateNextAndPreviousButtonStatuses(listToDisplay)
        }

        if (prevState.selectedMonthSpan !== this.state.selectedMonthSpan) {
            this.onMonthSpanChange();
        }

        if (this.state.exportStr && this.state.exportStr.length > 0) {
            this.setState({ exportStr: "" })
        }

    }


    /**
     * Decides if the Next and Previous buttons should be enabled or not and updates the indexList
     * @param {JSON} activityDetails 
     * @author Ajmal Aliyar
     */
    updateNextAndPreviousButtonStatuses(activityDetails) {
        let enable = false
        let currentIndexList = this.state.indexList
        if (activityDetails.length) {
            const lastObject = activityDetails[activityDetails.length - 1]
            if (lastObject.absoluteIndex && lastObject.hasNextPage) {
                enable = true
                if (!currentIndexList.includes(lastObject.absoluteIndex)) {
                    currentIndexList.push(lastObject.absoluteIndex)
                }
            }
        }
        this.setState({
            doEnableNextButton: enable,
            doEnablePreviousButton: this.state.currentIndexListArrayPosition > 0 ? true : false,
            indexList: currentIndexList,
            loading: false
        })
    }

    /**
     * Return true if the API to retrieve activities is to be called.
     * @param {object} prevState 
     * @param {object} currentState 
     * @author Ajmal Aliyar
     */
    shouldFireRetrieveActivities(prevState, currentState) {
        if (
            (
                (currentState.activityStatus || currentState.activityCode) &&
                currentState.fromDate &&
                currentState.toDate
            )
            &&
            ((prevState.activityStatus !== currentState.activityStatus) ||
                prevState.activityCode !== currentState.activityCode ||
                prevState.openingBalanceRequired !== currentState.openingBalanceRequired ||
                prevState.activityAttributesRequired !== currentState.activityAttributesRequired ||
                prevState.sortOrder !== currentState.sortOrder ||
                prevState.preferredLanguageCode !== currentState.preferredLanguageCode ||
                prevState.dateTypeIdentifier !== currentState.dateTypeIdentifier ||
                prevState.pageNumber !== currentState.pageNumber ||
                prevState.currentIndexListArrayPosition !== currentState.currentIndexListArrayPosition ||
                prevState.pageSize !== currentState.pageSize ||
                prevState.fromDate !== currentState.fromDate ||
                prevState.toDate !== currentState.toDate
            )
        )
            return true;
    }

    /**
     * Set states from the configurations API
     * @author Ajmal Aliyar
     */
    setConfigurations(config) {
        let toDate = getCurrentDate(DD_MM_YYYY_HH_MM_SS);
        let fromDate = getRelativeDate(toDate, -1 * config.ui.defaultNumberOfDaysToDisplay, DD_MM_YYYY_HH_MM_SS, DD_MM_YYYY_HH_MM_SS)
        let selectedMonthSpan = ""
        config.ui.transactionMonthSpans.forEach((obj, index) => {
            if (obj.default) {
                selectedMonthSpan = obj.value
            }
        })
        const availablePageSizes = []
        config.ui.availablePageSizes.forEach(p => {
            availablePageSizes.push({
                label: p,
                value: p
            })
        })
        this.setState({
            activityTypes: config.activityTypes.map(it => ({ label: it.value, value: it.key })),
            defaultNumberOfDaysToDisplay: config.ui.defaultNumberOfDaysToDisplay,
            transactionMonthSpans: config.ui.transactionMonthSpans,
            selectedMonthSpan,
            activityStatus: config.activityStatus,
            activityCode: config.activityCode,
            openingBalanceRequired: config.openingBalanceRequired,
            activityAttributesRequired: config.activityAttributesRequired,
            sortOrder: config.sortOrder,
            preferredLanguageCode: config.preferredLanguageCode,
            dateTypeIdentifier: config.dateTypeIdentifier,
            pageNumber: config.ui.defaultPageNumber,
            indexList: [config.ui.defaultAbsoluteIndex],
            currentIndexListArrayPosition: 0,
            availablePageSizes: availablePageSizes,
            pageSize: config.ui.defaultPageSize,
            fromDate,
            toDate
        })
    }

    /**
     * Resets the indexList and currentIndexListArrayPosition along with the states passed in.
     * @param {Object} states 
     * @author Ajmal Aliyar
     */
    resetToInitialStateWith(states) {
        this.setState({
            ...states,
            indexList: this.props.config ? [this.props.config.ui.defaultAbsoluteIndex] : 1,
            currentIndexListArrayPosition: 0
        })
    }

    /****
     * Generate request payload and fire the API to retrieve activities.
     * @author Ajmal Aliyar
     */
    callRetrieveActivitiesApi() {
        this.setState({
            loading: true,
            globalFilter: ""
        })
        const payload = {
            "object": {
                "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                "membershipNumber": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                "transactionId": this.state.transactionId,
                "activityStatus": this.state.activityStatus,
                "activityCode": this.state.activityCode,
                "openingBalanceRequired": this.state.openingBalanceRequired,
                "activityAttributesRequired": this.state.activityAttributesRequired,
                "fromDate": this.state.fromDate,
                "toDate": setTimeForDate(this.state.toDate,23,59),
                "sortOrder": this.state.sortOrder,
                "preferredLanguageCode": this.state.preferredLanguageCode,
                "dateTypeIdentifier": this.state.dateTypeIdentifier,
                "pageNumber": this.state.pageNumber,
                "absoluteIndex": this.state.indexList[this.state.currentIndexListArrayPosition],
                "pageSize": this.state.pageSize,
                "partnerCode": this.state.selectedPartner ? this.state.selectedPartner.value : ""

            }
        }
        this.props.actionRetrieveActivityDetails(payload);
    }

    /**
     * Handles the event emitted by activity type filter dropdown.
     * @param {event} event 
     * @author Ajmal Aliyar
     */
    handleActivityTypeFilterChange(value) {
        this.resetToInitialStateWith({
            activityCode: value,
        })
    }

    /**
     * Handles the event emitted by month span filter dropdown.
     * @param {Event} value 
     * @author Ajmal Aliyar
     */
    handleMonthSpanFilterChange(value) {
        this.setState({
            selectedMonthSpan: value,
            selectedCustomDate: undefined,
        })
    }

    /**
     * Sets corresponding fromDate when selected month span is changed.
     * @author Ajmal Aliyar
     */
    onMonthSpanChange() {
        const selectedMonthSpan = this.state.selectedMonthSpan
        if (selectedMonthSpan == SELECT_DATE_RANGE) {
            this.resetToInitialStateWith({
                enableCustomDaterange: true,
                fromDate: "",
                toDate: "",
            })
        } else {
            const fromDate = getDateWithRelativeMonth(getCurrentDate(), -1 * parseInt(selectedMonthSpan), DD_MM_YYYY_HH_MM_SS, DD_MM_YYYY)
            const toDate = getCurrentDate(DD_MM_YYYY_HH_MM_SS)
            this.resetToInitialStateWith({
                fromDate,
                toDate,
                enableCustomDaterange: false,
                selectedCustomDate: undefined
            })
        }
    }

    /**
     * Sets fromDate and toDate when a customDate is selected.
     * @param {Array} selectedCustomDate 
     * @author Ajmal Aliyar
     */
    handleDateRangeSelection(selectedCustomDate) {
        if (selectedCustomDate) {
            const fromDate = selectedCustomDate[0]
            const toDate = selectedCustomDate[1]
            if (fromDate && toDate) {
                this.resetToInitialStateWith({
                    fromDate: getFormattedDate(fromDate, DD_MM_YYYY_HH_MM_SS),
                    toDate: getFormattedDate(toDate, DD_MM_YYYY_HH_MM_SS),
                })
            }
            this.datePicker.current.onButtonClick()
        }
    }
    /**
     * Handles the event emitted by pageSize dropdown.
     * @param {Event} event 
     * @author Ajmal Aliyar
     */
    handlePageSizeChange(value) {
        this.resetToInitialStateWith({
            pageSize: value,
        })
    }

    /**
     * Decrease currentIndexListArrayPosition in the state by 1.
     * @param {Event} event 
     * @author Ajmal Aliyar
     */
    handlePreviousButtonClick(event) {
        this.setState({
            currentIndexListArrayPosition: this.state.currentIndexListArrayPosition - 1,
        })
        window.scrollTo(0, 0)
    }

    /**
     * Increase currentIndexListArrayPosition in the state by 1.
     * @param {Event} event 
     * @author Ajmal Aliyar
     */
    handleNextButtonClick(event) {
        this.setState({
            currentIndexListArrayPosition: this.state.currentIndexListArrayPosition + 1,
        })
        window.scrollTo(0, 0)
    }
    /**
     * Set states with partner filter selection
     * @author Geo George
     */
    handlePartnerChange(event) {

        this.setState({
            selectedPartner: event,
            partnerFilterFlag: true,
            canFilterPopUpShow: true

        })
    }
    handledateChange(value) {
        this.setState({
            selectedCustomDate: value,
            selectedMonthSpan: SELECT_DATE_RANGE
        })
    }
    getMinDate(priorMonthValue) {
        let date = new Date();
        date.setMonth(date.getMonth() - priorMonthValue);
        return date;
    }
    handleDateRangeClear() {
        this.datePicker.current.onClearButtonClick();

        this.setState({
            selectedCustomDate: [],
            selectedMonthSpan: 1,
        }, () => this.onMonthSpanChange());
    }

    getFooterContent() {
        const { t } = this.props
        return (
            <React.Fragment>
                <hr />
                <div className="btn-wrap btn-wrap--grp mt-3 text-right">
                    <Button
                        className="btn btn-secondary btn-sm"
                        handleOnClick={() => this.handleDateRangeClear()}
                        id={"calendar-cancel"}
                        testIdentifier="calendar-cancel-btn"
                        label={t("my_activity.partner_clear_btn")} />
                    <Button
                        className="btn btn-primary btn-sm"
                        handleOnClick={() =>
                            this.handleDateRangeSelection(this.state.selectedCustomDate)()
                        }
                        id={"calendar-apply"}
                        label={t("my_activity.parner_filter_btn")}
                        testIdentifier="calendar-apply-btn"
                        enabled={true}
                    />
                </div>
            </React.Fragment>
        );
    }
    onValueChange(e) {
        this.setState({ exportFlag: e.length > 0 ? true : false })
    }
    render() {
        const { t, config } = this.props
        const {
            activityCode,
            activityTypes,
            pageSize,
            availablePageSizes,
            doEnableNextButton,
            doEnablePreviousButton,
            transactionMonthSpans,
            selectedMonthSpan,
            selectedCustomDate,
            globalFilter,
            listToDisplay,
            partnerFilterFlag,
            filterActiveFlag,
            selectedPartner,
            exportStr,
            exportFlag
        } = this.state;

        const programType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE)

        let columns = (config && config.ui && config.ui.layout && config.ui.layout && config.ui.layout.elements && config.ui.layout.elements.table && config.ui.layout.elements.table.columns)
            ? config.ui.layout.elements.table.columns
            : []
        const defaultConfig = getCurrentProgramFromDefaultConfig(this.props.defaultConfig)
        const partnerList = defaultConfig && defaultConfig.data ? defaultConfig.data.partners : [];
        return (
            <>
                <div className="title title--page">
                    <h1>{t(programType == PROGRAM_TYPE_CORPORATE?'my_activity.activity_statement_corporate':'my_activity.activity_statement')}</h1>
                </div>
                <p>{parse(t("my_activity.description"))}</p>
                {/* <!--form starts here--> */}
                <form className="form form--horizontal form--activity">
                    <div className="form--horizontal__left">
                        <div className="form-group">
                            {/* <label className="input-label" htmlFor={"category-transactions-id"}>{t("my_activity.duration")}</label> */}
                            <div className="input-wrap select-wrap">
                                <DropDown
                                    label={t("my_activity.duration")}
                                    placeholder={"Duration"}
                                    options={transactionMonthSpans}
                                    id="category-transactions-id"
                                    value={selectedMonthSpan}
                                    onChange={this.handleMonthSpanFilterChange}
                                    testIdentifier={"category-transactions-id"}
                                    enabled={true}
                                />
                                <span>{t("my_activity.or_text")}</span>
                            </div>
                        </div>
                        <div className="form-group">
                            <FieldBank
                                field={{
                                    label: t("my_activity.custom_duration"),
                                    fieldType: FIELDTYPE_DATE,
                                    placeholder: t("my_activity.date_range"),
                                    value: { selectedCustomDate },
                                    onChange: (e) => this.handledateChange(e),
                                    id: "category-date-range-id",
                                    testIdentifier: "category-date-range-id",
                                    maxDate: new Date(),
                                    minDate: this.getMinDate(config && config.ui && config.ui.calendarMinDateDurationInMonth),
                                    dateFormat: config && config.ui && config.ui.calendarDisplayDateFormat,
                                    readOnlyInput: true,
                                    selectionMode: CALENDAR_SELECTION_MODE,
                                    numberOfMonths: config && config.ui && config.ui.calendarNoOfMonths,
                                    enabled: true,
                                    footerTemplate: () => this.getFooterContent(),
                                    calenderRef: this.datePicker
                                }}
                            />
                        </div>
                    </div>
                </form>
                {/* <!--form ends here--> */}
                {/* <!--tab starts here--> */}

                <div className="tab-content" id="nav-tabContent" data-test="MyActivity">
                    <div className="tab-pane fade show active" id="nav-1" role="tabpanel">
                        {/* <!--filter starts here--> */}
                        <div className="filter filter--table">
                            <div className="select-wrap">
                                <DropDown
                                    label={"Activity category"}
                                    labelClassName={"sr-only"}
                                    placeholder={"Activity category"}
                                    options={activityTypes}
                                    id="category-dropdown-id"
                                    value={activityCode}
                                    onChange={this.handleActivityTypeFilterChange}
                                    testIdentifier={"category-dropdown-id"}
                                    enabled={true}
                                    removeDefaultOption={true}
                                />
                            </div>
                            <div className="filter__utils">
                                <label className="sr-only" htmlFor={"search-txt"}>{t("my_activity.search_text")}</label>
                                <div className="txt-wrap">
                                    <input
                                        id="search-txt"
                                        type="text"
                                        className="txt"
                                        placeholder="Search"
                                        data-test="table-search"
                                        value={globalFilter}
                                        onChange={(e) => this.setState({ globalFilter: e.target.value })}
                                    />
                                </div>

                                <div className={`utils export dropdown ${this.state.exportFlag ? "" : "disable"}`} data-test="export-link" title="Download">
                                    <a href="#" role="button" id="dropdownMenuLink" aria-label="export link" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <svg version="1.1" width="15px" height="18px" xmlns="http://www.w3.org/2000/svg">
                                            <g transform="matrix(1 0 0 1 -1148 -369 )">
                                                <path d="M 11.2890625 0.683035714285715  L 14.3359375 3.81696428571429  C 14.5182291666667 4.00446428571428  14.6744791666667 4.25892857142857  14.8046875 4.58035714285714  C 14.9348958333333 4.90178571428572  15 5.19642857142857  15 5.46428571428572  L 15 17.0357142857143  C 15 17.3035714285714  14.9088541666667 17.53125  14.7265625 17.71875  C 14.5442708333333 17.90625  14.3229166666667 18  14.0625 18  L 0.9375 18  C 0.677083333333333 18  0.455729166666667 17.90625  0.2734375 17.71875  C 0.0911458333333333 17.53125  0 17.3035714285714  0 17.0357142857143  L 0 0.964285714285715  C 0 0.696428571428571  0.0911458333333333 0.468749999999999  0.2734375 0.28125  C 0.455729166666667 0.0937500000000007  0.677083333333333 0  0.9375 0  L 9.6875 0  C 9.94791666666667 0  10.234375 0.0669642857142865  10.546875 0.200892857142857  C 10.859375 0.334821428571428  11.1067708333333 0.495535714285714  11.2890625 0.683035714285715  Z M 10.400390625 1.58705357142857  C 10.322265625 1.50669642857143  10.1888020833333 1.43303571428571  10 1.36607142857143  L 10 5.14285714285714  L 13.671875 5.14285714285714  C 13.6067708333333 4.94866071428571  13.53515625 4.81138392857143  13.45703125 4.73102678571428  L 10.400390625 1.58705357142857  Z M 1.25 16.7142857142857  L 13.75 16.7142857142857  L 13.75 6.42857142857143  L 9.6875 6.42857142857143  C 9.42708333333333 6.42857142857143  9.20572916666667 6.33482142857143  9.0234375 6.14732142857143  C 8.84114583333333 5.95982142857143  8.75 5.73214285714286  8.75 5.46428571428572  L 8.75 1.28571428571429  L 1.25 1.28571428571429  L 1.25 16.7142857142857  Z M 7.3046875 8.3671875  C 7.66276041666667 9.46540178571428  8.13802083333333 10.2622767857143  8.73046875 10.7578125  C 8.9453125 10.9319196428571  9.21875 11.1194196428571  9.55078125 11.3203125  C 9.93489583333333 11.2734375  10.3157552083333 11.25  10.693359375 11.25  C 11.650390625 11.25  12.2265625 11.4140625  12.421875 11.7421875  C 12.5260416666667 11.8895089285714  12.5325520833333 12.0636160714286  12.44140625 12.2645089285714  C 12.44140625 12.2712053571429  12.4381510416667 12.2779017857143  12.431640625 12.2845982142857  L 12.412109375 12.3046875  L 12.412109375 12.3147321428571  C 12.373046875 12.5691964285714  12.1419270833333 12.6964285714286  11.71875 12.6964285714286  C 11.40625 12.6964285714286  11.0319010416667 12.6294642857143  10.595703125 12.4955357142857  C 10.1595052083333 12.3616071428571  9.736328125 12.1841517857143  9.326171875 11.9631696428571  C 7.88736979166667 12.1238839285714  6.611328125 12.4017857142857  5.498046875 12.796875  C 4.501953125 14.5513392857143  3.71419270833333 15.4285714285714  3.134765625 15.4285714285714  C 3.037109375 15.4285714285714  2.94596354166667 15.4051339285714  2.861328125 15.3582589285714  L 2.626953125 15.2377232142857  C 2.62044270833333 15.2310267857143  2.60091145833333 15.2142857142857  2.568359375 15.1875  C 2.50325520833333 15.1205357142857  2.48372395833333 15  2.509765625 14.8258928571429  C 2.568359375 14.5580357142857  2.75065104166667 14.2516741071429  3.056640625 13.9068080357143  C 3.36263020833333 13.5619419642857  3.79231770833333 13.2388392857143  4.345703125 12.9375  C 4.43684895833333 12.8772321428571  4.51171875 12.8973214285714  4.5703125 12.9977678571429  C 4.58333333333333 13.0111607142857  4.58984375 13.0245535714286  4.58984375 13.0379464285714  C 4.92838541666667 12.46875  5.27669270833333 11.8091517857143  5.634765625 11.0591517857143  C 6.07747395833333 10.1484375  6.416015625 9.27120535714286  6.650390625 8.42745535714286  C 6.494140625 7.87834821428571  6.39485677083333 7.34430803571428  6.3525390625 6.82533482142857  C 6.31022135416667 6.30636160714286  6.33138020833333 5.87946428571429  6.416015625 5.54464285714286  C 6.48763020833333 5.27678571428571  6.62434895833333 5.14285714285714  6.826171875 5.14285714285714  L 7.03125 5.14285714285714  L 7.041015625 5.14285714285714  C 7.19075520833333 5.14285714285714  7.3046875 5.19308035714286  7.3828125 5.29352678571428  C 7.5 5.43415178571428  7.529296875 5.66183035714286  7.470703125 5.9765625  C 7.45768229166667 6.01674107142857  7.44466145833333 6.04352678571428  7.431640625 6.05691964285714  C 7.43815104166667 6.07700892857143  7.44140625 6.10379464285714  7.44140625 6.13727678571428  L 7.44140625 6.43861607142857  C 7.42838541666667 7.26227678571428  7.3828125 7.90513392857143  7.3046875 8.3671875  Z M 3.5888671875 14.1428571428571  C 3.35123697916667 14.4375  3.19010416666667 14.6852678571429  3.10546875 14.8861607142857  C 3.44401041666667 14.7254464285714  3.88997395833333 14.1964285714286  4.443359375 13.2991071428571  C 4.111328125 13.5669642857143  3.82649739583333 13.8482142857143  3.5888671875 14.1428571428571  Z M 6.9921875 5.625  L 6.9921875 5.64508928571428  C 6.89453125 5.92633928571428  6.88802083333333 6.36830357142857  6.97265625 6.97098214285714  C 6.97916666666667 6.92410714285714  7.001953125 6.77678571428571  7.041015625 6.52901785714286  C 7.041015625 6.50892857142857  7.06380208333333 6.36495535714286  7.109375 6.09709821428572  C 7.11588541666667 6.0703125  7.12890625 6.04352678571428  7.1484375 6.01674107142857  C 7.14192708333333 6.01004464285714  7.138671875 6.00334821428571  7.138671875 5.99665178571428  C 7.13216145833333 5.98325892857143  7.12890625 5.97321428571428  7.12890625 5.96651785714286  C 7.12239583333333 5.81919642857143  7.080078125 5.69866071428571  7.001953125 5.60491071428572  C 7.001953125 5.61160714285714  6.99869791666667 5.61830357142857  6.9921875 5.625  Z M 6.220703125 11.4508928571429  C 6.025390625 11.8258928571429  5.87890625 12.1037946428571  5.78125 12.2845982142857  C 6.66015625 11.9229910714286  7.58463541666667 11.6517857142857  8.5546875 11.4709821428571  C 8.54166666666667 11.4642857142857  8.49934895833333 11.4324776785714  8.427734375 11.3755580357143  C 8.35611979166667 11.3186383928571  8.30403645833334 11.2734375  8.271484375 11.2399553571429  C 7.77669270833334 10.7912946428571  7.36328125 10.2020089285714  7.03125 9.47209821428572  C 6.85546875 10.0479910714286  6.58528645833333 10.7075892857143  6.220703125 11.4508928571429  Z M 12.109375 12.1540178571429  C 12.109375 12.1473214285714  12.1028645833333 12.1372767857143  12.08984375 12.1238839285714  C 11.93359375 11.9631696428571  11.4778645833333 11.8828125  10.72265625 11.8828125  C 11.2174479166667 12.0703125  11.62109375 12.1640625  11.93359375 12.1640625  C 12.0247395833333 12.1640625  12.0833333333333 12.1607142857143  12.109375 12.1540178571429  Z " fill-rule="nonzero" stroke="none" transform="matrix(1 0 0 1 1148 369 )" />
                                            </g>
                                        </svg>
                                    </a>
                                    <div className="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuLink">
                                        <a className="dropdown-item" onClick={(e) => this.setState({ exportStr: exportFlag ? EXPORT_PDF : "" })} role="button">{t("export_file.exportPdf")}</a>
                                        <a className="dropdown-item" onClick={(e) => this.setState({ exportStr: exportFlag ? EXPORT_XLSX : "" })} role="button">{t("export_file.exportXlsx")}</a>
                                        <a className="dropdown-item" onClick={(e) => this.setState({ exportStr: exportFlag ? EXPORT_CSV : "" })} role="button">{t("export_file.exportCsv")}</a>
                                    </div>
                                </div>

                                <div className="utils filtrate dropdown" title="Search by partner" title="Search by partner">
                                    <a className={filterActiveFlag ? "active" : ''} onClick={(e) => this.setState({ canFilterPopUpShow: !this.state.canFilterPopUpShow })} role="button" id="dropdownMenuLink" aria-haspopup="true" aria-expanded="false">
                                        <svg version="1.1" width="19px" height="18px" xmlns="http://www.w3.org/2000/svg">
                                            <g transform="matrix(1 0 0 1 -1154 -530 )">
                                                <path d="M 18.0341981135853 0.70312524719247  C 18.0341981135853 0.314758411438504  17.7194397021468 0  17.3312101867536 0  L 0.738278345488481 0  C 0.349911509734515 0  0.035153098296011 0.314758411438504  0.035153098296011 0.70312524719247  C 0.035153098296011 2.66116424806556  0.874508862132022 4.53048867087492  2.33802560321213 5.83140769854177  L 5.41735713891462 8.56837763732026  C 5.9512928735014 9.04298717917518  6.25753689522781 9.72496375487007  6.25753689522781 10.4394872951323  L 6.25753689522781 17.2960570884576  C 6.25753689522781 17.8563600198141  6.88375781850861 18.1922671379064  7.35053957245532 17.8809419464249  L 11.4988412105301 15.11554486484  C 11.6943979199055 14.985082190068  11.8119516721705 14.7656301910419  11.8119516721705 14.5305226865119  L 11.8119516721705 10.4394872951323  C 11.8119516721705 9.72496375487007  12.1181956587407 9.04298717917518  12.6521313933274 8.56837763732026  L 15.7313256086692 5.83140769854177  C 17.1948423497493 4.53048867087492  18.0341981135853 2.66116424806556  18.0341981135853 0.70312524719247  Z M 16.5824916969697 1.40611317402416  C 16.4138514658072 2.70085239873717  15.7840600022086 3.90303175887835  14.7970753935031 4.78029036807083  L 11.7178812133176 7.51739766236637  C 10.8840186154753 8.25870039563686  10.4057011777856 9.3236879614528  10.4057011777856 10.4393499747715  L 10.4057011777856 14.154240815944  L 7.66365003409572 15.9822291382837  L 7.66365003409572 10.4394872951322  C 7.66365003409572 9.32368796145279  7.18533259640599 8.25870039563686  6.35146999856367 7.51739766236636  L 3.27227581837822 4.78042768843161  C 2.28542853003347 3.90303175887835  1.65549974607413 2.70085239873717  1.48685955006781 1.40611317402416  L 16.5824916969697 1.40611317402416  Z " fill-rule="nonzero" stroke="none" transform="matrix(1 0 0 1 1154 530 )" />
                                            </g>
                                        </svg>
                                    </a>
                                    <div className={`dropdown-menu dropdown-menu-right ${this.state.canFilterPopUpShow ? "show" : ""}`} id="partnerTab" aria-labelledby="dropdownMenuLink" >
                                        <div className="title">{t("my_activity.filter_by_partners")}</div>
                                        <div className="txt-wrap" data-test="partner-filter">
                                            <label className="sr-only" htmlFor={"filterPartner"}>{t('my_activity.search_partners')}</label>
                                            <AutoCompleteField
                                                list={partnerList}
                                                inputId="filterPartner"
                                                placeholder={t('my_activity.search_partners')}
                                                handleSelectEvent={(e) => this.handlePartnerChange(e)}
                                                selected={selectedPartner}
                                                dataForTest="filterPartner"
                                                className={"txt"}
                                                disabled={partnerList.length == 0}
                                            />

                                            <div className="btn-wrap btn-wrap--grp mt-3 text-right">
                                                <Button
                                                    className="btn btn-secondary btn-sm"
                                                    handleOnClick={() => this.setState({
                                                        partnerFilterFlag: false,
                                                        filterActiveFlag: false,
                                                        canFilterPopUpShow: false,
                                                        selectedPartner: {
                                                            name: "",
                                                            value: ""
                                                        },
                                                    }, () => {
                                                        this.callRetrieveActivitiesApi();
                                                    })}
                                                    id={"cancel"}
                                                    testIdentifier="partner-filter-cancel-btn"
                                                    label={t("my_activity.partner_clear_btn")} />

                                                <Button
                                                    className="btn btn-primary btn-sm"
                                                    handleOnClick={() => this.setState({
                                                        filterActiveFlag: true,
                                                        canFilterPopUpShow: false,
                                                    }, () => {
                                                        this.callRetrieveActivitiesApi();
                                                    })}
                                                    id={"filter"}
                                                    label={t("my_activity.parner_filter_btn")}
                                                    testIdentifier="partner-filter-apply-btn"
                                                    enabled={partnerFilterFlag}
                                                />

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        {/* <!--filter ends here--> */}

                        {/* <!--table starts here--> */}
                        <MyActivityTable
                            field={{
                                values: listToDisplay,
                                columns: columns,
                                globalFilter: globalFilter,
                                exportStr: exportStr,
                                partnerList: partnerList,
                                exportFileName: config && config.ui && config.ui.exportFileName,
                            }}

                            onValueChange={(e) => this.onValueChange(e)}

                            className={"table"}
                        />
                        {/* <!--table ends here--> */}

                        {/* <!--pagination starts here--> */}
                        <div className="pagination">
                            <div className="pagination__count">
                                <label className="text" htmlFor={"activity-page-size-id"}>{t("my_activity.page_size")}</label>
                                {/* <div className="select-wrap"> */}
                                <DropDown
                                    label={"page size"}
                                    labelClassName={"sr-only"}
                                    placeholder={t("my_activity.page_size")}
                                    options={availablePageSizes}
                                    id="activity-page-size-id"
                                    value={pageSize}
                                    onChange={this.handlePageSizeChange}
                                    testIdentifier={"activity-page-size-id"}
                                    enabled={true}
                                    removeDefaultOption={true}
                                />
                                {/* </div> */}
                            </div>
                            <div className="btn-wrap btn-wrap--grp">
                                {/* <span className="text">1 to 20 of 102 results</span> */}
                                <Button
                                    className="btn btn-secondary btn-sm"
                                    handleOnClick={this.handlePreviousButtonClick}
                                    id={"myactivity-prev-page-btn"}
                                    testIdentifier="myactivity-prev-page-btn"
                                    label={t("my_activity.previous")}
                                    enabled={doEnablePreviousButton}
                                />
                                <Button
                                    className="btn btn-secondary btn-sm"
                                    handleOnClick={this.handleNextButtonClick}
                                    id={"myactivity-next-page-btn"}
                                    testIdentifier="myactivity-next-page-btn"
                                    label={t("my_activity.next")}
                                    enabled={doEnableNextButton}
                                />
                            </div>
                        </div>

                        {/* <!--pagination ends here--> */}
                    </div>
                </div>
                {/* <!--tab ends here--> */}
            </>
        );
    }
}

MyActivity.propTypes = {

};

const mapStateToProps = (state) => {
    return {
        config: state.configurationReducer[CONFIG_SECTION_ACTIVITYDETAILS],
        activityDetail: state.myActivityReducer.activityDetail,
        authenticateTransaction: state.myActivityReducer.authenticateTransaction,
        logoutTransaction: state.myActivityReducer.logoutTransaction,
        airlines: state.masterData[AIRLINES],
        masterEntityLookup: state.masterEntityDataReducer.masterEntityLookup,
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],

    }
}

const mapDispatchToProps = {
    actionRetrieveActivityDetails,
    fetchConfiguration,
    fetchMasterData
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(MyActivity)));
