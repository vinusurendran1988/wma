import { mount } from 'enzyme';
import * as actions from './actions';
import * as reducers from './reducers';
import { testStore } from '../../common/utils';
import * as loadingSpinnerActions from '../loadingspinner/action';
import moxios from 'moxios';
import configureMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import FamilyMembers from './index';
import { Provider } from 'react-redux';
import React from 'react';
import FamilyMemberCard from './FamilyMemberCard';
import { findByTestAttr } from '../../common/testUtils';

const middlewares = [thunk];
const mockStore = configureMockStore(middlewares);
  
const configData = {
  "section": "family",
  "companyCode": "IBS",
  "programCode": "PRG14",
  "nominee": {
    "accountGroupType": "F",
    "maxLimit": 8
  },
  "relationshipCodes": [
    {
      "code": "F",
      "value": "Father"
    },
    {
      "code": "M",
      "value": "Mother"
    },
    {
      "code": "S",
      "value": "Spouse"
    },
    {
      "code": "B",
      "value": "Brother"
    },
    {
      "code": "C",
      "value": "Children"
    },
    {
      "code": "E",
      "value": "Step children"
    },
    {
      "code": "G",
      "value": "Grandfather"
    },
    {
      "code": "N",
      "value": "Grandmother"
    },
    {
      "code": "P",
      "value": "Step parents"
    },
    {
      "code": "I",
      "value": "Parents in law"
    },
    {
      "code": "T",
      "value": "Sister"
    },
    {
      "code": "O",
      "value": "Others"
    }
  ],
  "ui": {
    "pointTypes": {
      "progress": [
        "BASE"
      ],
      "pooling": [
        "BASE"
      ],
      "expiry": [
        "BASE"
      ]
    },
    "tierMapping": [
      {
        "tierName": "LATAM",
        "pointsRequired": 0,
        "color": ""
      },
      {
        "tierName": "Gold",
        "pointsRequired": 20000,
        "color": ""
      },
      {
        "tierName": "Gold Plus",
        "pointsRequired": 30000,
        "color": ""
      },
      {
        "tierName": "Platinum",
        "pointsRequired": 50000,
        "color": ""
      },
      {
        "tierName": "Black",
        "pointsRequired": 100000,
        "color": ""
      },
      {
        "tierName": "Black Signature",
        "pointsRequired": 200000,
        "color": ""
      }
    ],
    "maxFamilyMembers": 10
  }
}

const familyMemberDetails = {
  "statuscode": "200",
  "statusMessage": "SUCCESS",
  "object": [
    {
      "membershipNumber": "IM0000000335",
      "displayName": "MR KHAYALI ABDAL",
      "relationship": "Children",
      "dateOfBirth": "21-Jul-2004",
      "emailAddress": "kayali.abdul@aol.com",
      "nomineeStatus": "Active",
      "tierCode": "BLU",
      "tierName": "Blue",
      "expiryDetails": [
        {
          "pointType": "TIER",
          "points": 8700,
          "expiryDate": "02-Jan-2021"
        },
        {
          "pointType": "FS",
          "points": 2,
          "expiryDate": "02-Jan-2021"
        },
        {
          "pointType": "TIER",
          "points": 3400,
          "expiryDate": "05-Jan-2021"
        },
        {
          "pointType": "TIER",
          "points": 7000,
          "expiryDate": "06-Jan-2021"
        },
        {
          "pointType": "FS",
          "points": 1,
          "expiryDate": "06-Jan-2021"
        },
        {
          "pointType": "BASE",
          "points": 19100,
          "expiryDate": "31-Jan-2023"
        },
        {
          "pointType": "BONUS",
          "points": 5175,
          "expiryDate": "31-Jan-2023"
        },
        {
          "pointType": "BASE",
          "points": 1000,
          "expiryDate": "28-Jun-2023"
        },
        {
          "pointType": "BASE",
          "points": 1000,
          "expiryDate": "30-Jun-2023"
        }
      ],
      "pointDetails": [
        {
          "pointType": "BASE",
          "pointTypeGroup": "Total Miles",
          "totalAccuredpoints": 24500,
          "totalRedeemedpoints": 3400,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 21100,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "BONUS",
          "pointTypeGroup": "Total Miles",
          "totalAccuredpoints": 7575,
          "totalRedeemedpoints": 2400,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 5175,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "TIER",
          "pointTypeGroup": "Qualifying Miles",
          "totalAccuredpoints": 22500,
          "totalRedeemedpoints": 3400,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 19100,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "TIERKE",
          "pointTypeGroup": "Qualifying Miles",
          "totalAccuredpoints": 0,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 0,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "FS",
          "pointTypeGroup": "Qualifying Segments",
          "totalAccuredpoints": 3,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 3,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "FC",
          "pointTypeGroup": "Qualifying Segments",
          "totalAccuredpoints": 0,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 0,
          "bonusDetails": [],
          "creditLimit": 0
        }
      ],
      "activeNominee": true
    },
    {
      "membershipNumber": "IM0000000328",
      "displayName": "MRS John Bindu",
      "relationship": "Grandmother",
      "dateOfBirth": "03-Jun-1965",
      "emailAddress": "bindu.john@gmail.com",
      "nomineeStatus": "Active",
      "tierCode": "PLT",
      "tierName": "Platinum",
      "expiryDetails": [
        {
          "pointType": "FS",
          "points": 5,
          "expiryDate": "01-Feb-2021"
        },
        {
          "pointType": "FS",
          "points": 3,
          "expiryDate": "02-Feb-2021"
        },
        {
          "pointType": "FS",
          "points": 1,
          "expiryDate": "07-May-2021"
        },
        {
          "pointType": "BONUS",
          "points": 3025,
          "expiryDate": "31-Jan-2023"
        },
        {
          "pointType": "BASE",
          "points": 2000,
          "expiryDate": "31-May-2023"
        },
        {
          "pointType": "BONUS",
          "points": 1875,
          "expiryDate": "31-May-2023"
        },
        {
          "pointType": "BASE",
          "points": 2000,
          "expiryDate": "17-Jun-2023"
        },
        {
          "pointType": "BASE",
          "points": 9000,
          "expiryDate": "30-Jun-2023"
        }
      ],
      "pointDetails": [
        {
          "pointType": "BASE",
          "pointTypeGroup": "Total Miles",
          "totalAccuredpoints": 16000,
          "totalRedeemedpoints": 3000,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 13000,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "BONUS",
          "pointTypeGroup": "Total Miles",
          "totalAccuredpoints": 4900,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 4900,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "TIER",
          "pointTypeGroup": "Qualifying Miles",
          "totalAccuredpoints": 56750,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 56750,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "TIERKE",
          "pointTypeGroup": "Qualifying Miles",
          "totalAccuredpoints": 0,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 0,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "FS",
          "pointTypeGroup": "Qualifying Segments",
          "totalAccuredpoints": 9,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 9,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "FC",
          "pointTypeGroup": "Qualifying Segments",
          "totalAccuredpoints": 0,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 0,
          "bonusDetails": [],
          "creditLimit": 0
        }
      ],
      "activeNominee": true
    },
    {
      "membershipNumber": "IM0000000322",
      "displayName": "Haya Hussein",
      "relationship": "Father",
      "dateOfBirth": "03-Dec-1980",
      "emailAddress": "haya.hussein@gmail.com",
      "nomineeStatus": "Active",
      "tierCode": "GOL",
      "tierName": "Gold",
      "expiryDetails": [
        {
          "pointType": "FS",
          "points": 2,
          "expiryDate": "02-Feb-2021"
        },
        {
          "pointType": "FS",
          "points": 6,
          "expiryDate": "05-Feb-2021"
        },  
        {
          "pointType": "FS",
          "points": 20,
          "expiryDate": "06-Feb-2021"
        },
        {
          "pointType": "TIER",
          "points": 200,
          "expiryDate": "27-Apr-2021"
        },
        {
          "pointType": "FS",
          "points": 1,
          "expiryDate": "29-Apr-2021"
        },
        {
          "pointType": "TIER",
          "points": 200,
          "expiryDate": "29-Apr-2021"
        },
        {
          "pointType": "FS",
          "points": 1,
          "expiryDate": "27-May-2021"
        },
        {
          "pointType": "BONUS",
          "points": 4930,
          "expiryDate": "31-Jan-2023"
        },
        {
          "pointType": "BASE",
          "points": 46949,
          "expiryDate": "31-Jan-2023"
        },
        {
          "pointType": "BASE",
          "points": 8766.67,
          "expiryDate": "30-Apr-2023"
        },
        {
          "pointType": "BONUS",
          "points": 2000,
          "expiryDate": "30-Apr-2023"
        },
        {
          "pointType": "BASE",
          "points": 2000,
          "expiryDate": "28-Jun-2023"
        },
        {
          "pointType": "BASE",
          "points": 8000,
          "expiryDate": "30-Jun-2023"
        }
      ],
      "pointDetails": [
        {
          "pointType": "BASE",
          "pointTypeGroup": "Total Miles",
          "totalAccuredpoints": 112316.67,
          "totalRedeemedpoints": 46601,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 65715.67,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "BONUS",
          "pointTypeGroup": "Total Miles",
          "totalAccuredpoints": 27330,
          "totalRedeemedpoints": 18400,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 6930,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "TIER",
          "pointTypeGroup": "Qualifying Miles",
          "totalAccuredpoints": 64200,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 64200,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "TIERKE",
          "pointTypeGroup": "Qualifying Miles",
          "totalAccuredpoints": 0,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 0,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "FS",
          "pointTypeGroup": "Qualifying Segments",
          "totalAccuredpoints": 30,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 30,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "FC",
          "pointTypeGroup": "Qualifying Segments",
          "totalAccuredpoints": 0,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 0,
          "bonusDetails": [],
          "creditLimit": 0
        }
      ],
      "activeNominee": true
    },
    {
      "membershipNumber": "IM0008010253",
      "displayName": "MR Abraham OE",
      "relationship": "Children",
      "dateOfBirth": "16-Jan-2001",
      "emailAddress": "pthgkjhj2934n@gmail.com",
      "nomineeStatus": "Active",
      "tierCode": "BLU",
      "tierName": "Blue",
      "expiryDetails": [
        {
          "pointType": "BONUS",
          "points": 500,
          "expiryDate": "30-Jun-2023"
        }
      ],
      "pointDetails": [
        {
          "pointType": "BASE",
          "pointTypeGroup": "Total Miles",
          "totalAccuredpoints": 0,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 0,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "BONUS",
          "pointTypeGroup": "Total Miles",
          "totalAccuredpoints": 500,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 500,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "TIER",
          "pointTypeGroup": "Qualifying Miles",
          "totalAccuredpoints": 0,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 0,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "TIERKE",
          "pointTypeGroup": "Qualifying Miles",
          "totalAccuredpoints": 0,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 0,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "FS",
          "pointTypeGroup": "Qualifying Segments",
          "totalAccuredpoints": 0,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 0,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "FC",
          "pointTypeGroup": "Qualifying Segments",
          "totalAccuredpoints": 0,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 0,
          "bonusDetails": [],
          "creditLimit": 0
        }
      ],
      "activeNominee": true
    },
    {
      "membershipNumber": "IM0008010252",
      "displayName": "MR Abraham Po",
      "relationship": "Children",
      "dateOfBirth": "16-Jan-2000",
      "emailAddress": "po2934n@gmail.com",
      "nomineeStatus": "Active",
      "tierCode": "BLU",
      "tierName": "Blue",
      "expiryDetails": [
        {
          "pointType": "BONUS",
          "points": 500,
          "expiryDate": "30-Jun-2023"
        }
      ],
      "pointDetails": [
        {
          "pointType": "BASE",
          "pointTypeGroup": "Total Miles",
          "totalAccuredpoints": 0,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 0,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "BONUS",
          "pointTypeGroup": "Total Miles",
          "totalAccuredpoints": 500,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 500,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "TIER",
          "pointTypeGroup": "Qualifying Miles",
          "totalAccuredpoints": 0,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 0,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "TIERKE",
          "pointTypeGroup": "Qualifying Miles",
          "totalAccuredpoints": 0,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 0,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "FS",
          "pointTypeGroup": "Qualifying Segments",
          "totalAccuredpoints": 0,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 0,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "FC",
          "pointTypeGroup": "Qualifying Segments",
          "totalAccuredpoints": 0,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 0,
          "bonusDetails": [],
          "creditLimit": 0
        }
      ],
      "activeNominee": true
    },
    {
      "membershipNumber": "IM0008010326",
      "displayName": "ps-test-001",
      "relationship": "Father",
      "dateOfBirth": "22-Sep-1992",
      "emailAddress": "ps-test-001@loyalty.com",
      "nomineeStatus": "Active",
      "tierCode": "BLU",
      "tierName": "Blue",
      "expiryDetails": [
        {
          "pointType": "BONUS",
          "points": 500,
          "expiryDate": "30-Jun-2023"
        }
      ],
      "pointDetails": [
        {
          "pointType": "BASE",
          "pointTypeGroup": "Total Miles",
          "totalAccuredpoints": 0,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 0,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "BONUS",
          "pointTypeGroup": "Total Miles",
          "totalAccuredpoints": 500,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 500,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "TIER",
          "pointTypeGroup": "Qualifying Miles",
          "totalAccuredpoints": 0,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 0,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "TIERKE",
          "pointTypeGroup": "Qualifying Miles",
          "totalAccuredpoints": 0,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 0,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "FS",
          "pointTypeGroup": "Qualifying Segments",
          "totalAccuredpoints": 0,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 0,
          "bonusDetails": [],
          "creditLimit": 0
        },
        {
          "pointType": "FC",
          "pointTypeGroup": "Qualifying Segments",
          "totalAccuredpoints": 0,
          "totalRedeemedpoints": 0,
          "pointsToNextTier": 0,
          "pointsForTierRetention": 0,
          "points": 0,
          "bonusDetails": [],
          "creditLimit": 0
        }
      ],
      "activeNominee": true
    }
  ]
}

const familyMember = {
  "membershipNumber": "IM0000000335",
  "displayName": "MR KHAYALI ABDAL",
  "relationship": "Children",
  "dateOfBirth": "21-Jul-2004",
  "emailAddress": "kayali.abdul@aol.com",
  "nomineeStatus": "Active",
  "tierCode": "BLU",
  "tierName": "Blue",
  "expiryDetails": [
    {
      "pointType": "TIER",
      "points": 8700,
      "expiryDate": "02-Jan-2021"
    },
    {
      "pointType": "FS",
      "points": 2,
      "expiryDate": "02-Jan-2021"
    },
    {
      "pointType": "TIER",
      "points": 3400,
      "expiryDate": "05-Jan-2021"
    },
    {
      "pointType": "FS",
      "points": 1,
      "expiryDate": "06-Jan-2021"
    },
    {
      "pointType": "TIER",
      "points": 7000,
      "expiryDate": "06-Jan-2021"
    },
    {
      "pointType": "BASE",
      "points": 19100,
      "expiryDate": "31-Jan-2023"
    },
    {
      "pointType": "BONUS",
      "points": 5175,
      "expiryDate": "31-Jan-2023"
    },
    {
      "pointType": "BASE",
      "points": 1000,
      "expiryDate": "28-Jun-2023"
    },
    {
      "pointType": "BASE",
      "points": 1000,
      "expiryDate": "30-Jun-2023"
    },
    {
      "pointType": "BASE",
      "points": 1000,
      "expiryDate": "19-Jul-2023"
    }
  ],
  "pointDetails": [
    {
      "pointType": "BASE",
      "pointTypeGroup": "Total Miles",
      "totalAccuredpoints": 25500,
      "totalRedeemedpoints": 3400,
      "pointsToNextTier": 0,
      "pointsForTierRetention": 0,
      "points": 22100,
      "bonusDetails": [],
      "creditLimit": 0
    },
    {
      "pointType": "BONUS",
      "pointTypeGroup": "Total Miles",
      "totalAccuredpoints": 7575,
      "totalRedeemedpoints": 2400,
      "pointsToNextTier": 0,
      "pointsForTierRetention": 0,
      "points": 5175,
      "bonusDetails": [],
      "creditLimit": 0
    },
    {
      "pointType": "TIER",
      "pointTypeGroup": "Qualifying Miles",
      "totalAccuredpoints": 22500,
      "totalRedeemedpoints": 3400,
      "pointsToNextTier": 0,
      "pointsForTierRetention": 0,
      "points": 19100,
      "bonusDetails": [],
      "creditLimit": 0
    },
    {
      "pointType": "TIERKE",
      "pointTypeGroup": "Qualifying Miles",
      "totalAccuredpoints": 0,
      "totalRedeemedpoints": 0,
      "pointsToNextTier": 0,
      "pointsForTierRetention": 0,
      "points": 0,
      "bonusDetails": [],
      "creditLimit": 0
    },
    {
      "pointType": "FS",
      "pointTypeGroup": "Qualifying Segments",
      "totalAccuredpoints": 3,
      "totalRedeemedpoints": 0,
      "pointsToNextTier": 0,
      "pointsForTierRetention": 0,
      "points": 3,
      "bonusDetails": [],
      "creditLimit": 0
    },
    {
      "pointType": "FC",
      "pointTypeGroup": "Qualifying Segments",
      "totalAccuredpoints": 0,
      "totalRedeemedpoints": 0,
      "pointsToNextTier": 0,
      "pointsForTierRetention": 0,
      "points": 0,
      "bonusDetails": [],
      "creditLimit": 0
    }
  ],
  "activeNominee": true
}

describe("actions", () => {
  it('should return action to set config', () => {
    const expectedAction = {
      type: actions.SET_FAMILY_CONFIG,
      payload: configData
    }
    expect(actions.setFamilyConfig(configData)).toEqual(expectedAction)
  })

  describe('test api calls', () => {
    beforeEach(() => moxios.install());
    afterEach(() => moxios.uninstall());
    const params = {
      companyCode: 'IBS',
      programCode: 'PRG14',
      membershipNumber: '123456789'
    }
    test('should fetch family member details', async (done) => {
      const store = mockStore({});
      moxios.wait(() => {
        const request = moxios.requests.mostRecent();
        request.respondWith({ status: 200, response: familyMemberDetails })
      })

      await store.dispatch(actions.getFamilyDetails(params)).then(response => {
        const actionsCalled = store.getActions();
        expect(actionsCalled[0]).toEqual({ type: loadingSpinnerActions.LOADING_SPINNER, payload: { loading: true } });
        expect(actionsCalled[1]).toEqual({ type: loadingSpinnerActions.LOADING_SPINNER, payload: { loading: false } });
        expect(actionsCalled[2]).toEqual({ type: actions.SET_FAMILY_DETAILS, payload: familyMemberDetails.object })
      })
      done();
    })

    test('should hide loader if api call fails - family member details', async (done) => {
      const store = mockStore({})
      moxios.wait(() => {
        const request = moxios.requests.mostRecent();
        request.respondWith({ status: 500, response: "internal server error" })
      })

      await store.dispatch(actions.getFamilyDetails(params)).then(response => {
        const actionsCalled = store.getActions();
        expect(actionsCalled[0]).toEqual({ type: loadingSpinnerActions.LOADING_SPINNER, payload: { loading: true } });
        expect(actionsCalled[1]).toEqual({ type: loadingSpinnerActions.LOADING_SPINNER, payload: { loading: false } });
      })
      done();
    })



  })
})

describe('reducers', () => {
  describe('set family member details reducer', () => {
    it('should return default state', () => {
      expect(reducers.familyMemberDetails(undefined, { type: '', payload: '' })).toEqual(reducers.initialState);
    })
    it('should set passed data', () => {
      const action = {
        type: actions.SET_FAMILY_DETAILS,
        payload: familyMemberDetails
      }
      expect(reducers.familyMemberDetails(undefined, action)).toEqual({ details: familyMemberDetails })
    })
  })
  describe('set family config reducer', () => {
    it('should set passed data', () => {
      const action = actions.setFamilyConfig(configData);
      expect(reducers.familyConfig(undefined, action)).toEqual({ config: configData })
    })
  })
})

describe('components', () => {
  beforeEach(() => moxios.install());
  afterEach(() => moxios.uninstall());

  test('render the component', async (done) => {

    moxios.wait(() => {
      const request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: {} });
    })

    const store = testStore({});
    
    let wrapper = mount(
      <Provider store={store}>
        <FamilyMembers t={jest.fn()} />
      </Provider>
    )

    wrapper.prop('store').dispatch(loadingSpinnerActions.loadingSpinner({loading: false, divId: undefined}));
    wrapper.update();

    done();
  })

  test('shallow render to test add button functionality', ()=>{
    const initialValues = {
      familyMemberDetails: {
        details: [
          familyMember
        ]
      },
      familyConfig: {
        config: configData
      }
    }
    const store = testStore(initialValues);
    let wrapper = mount(<FamilyMembers t={jest.fn()} store={store} />)
    let familymembers = wrapper.find('FamilyMembers');
    const button2 = findByTestAttr(familymembers, 'transferButton');
    button2.simulate('click');
    wrapper = wrapper.update();
    wrapper.update();
  })

  test('render family member card', ()=>{
    mount(
      <FamilyMemberCard
        t={jest.fn()}
        details={familyMember}
        progressPointType="BASE"
        tierMapping={configData.tierMapping}
      />)
  })

})