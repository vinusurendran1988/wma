import React from 'react';
import { connect } from 'react-redux';
import FamilyMemberCard from './FamilyMemberCard';
import { CONFIG_SECTION_MYFAMILY, CONFIG_SECTION_DEFAULT, CONFIG_SECTION_ACCOUNT_SUMMARY } from '../../common/utils/Constants';
import { withTranslation } from 'react-i18next';
import {
    withSuspense
} from '../../common/utils';
import {
    fetchConfiguration,
    getFamilyMembers
} from '../../common/middleware/redux/commonAction';
import { NAVIGATE_FAMILY_MEMBER_ADD, NAVIGATE_TRANSFER } from '../../common/utils/urlConstants';
import {
    getItemFromBrowserStorage,
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    BROWSER_STORAGE_KEY_COMPANY_CODE
} from '../../common/utils/storage.utils';
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';

class FamilyMembers extends React.Component {

    componentDidMount() {
        const object = {
            companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
            programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
            membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)
        }
        this.props.setPageInfo(this.props, {config: this.props.familyConfig, confSection: CONFIG_SECTION_MYFAMILY})
        if (!this.props.familyMemberDetails) {
            this.props.fetchFamilyMemberDetails({object});
        }
    }

    render() {

        const {
            familyMemberDetails,
            maximumFamilyMembers,
            progressPointType,
            t,
            familyConfig,
            defaultConfig,
            accountSummaryConfig
        } = this.props;
        let tierMapping = []
        let nominee = undefined
        if (familyConfig && familyConfig.ui && familyConfig.ui.tierMapping) {
            tierMapping = familyConfig.ui.tierMapping
            nominee = familyConfig.nominee
        }
        let selectedDefaultConfig = getCurrentProgramFromDefaultConfig(defaultConfig)

        return (
            <div className="col-lg-9  col-md-8 rightSidePanel">
                <div className="form-row">
                    <div className="col-6">
                        <h1 id="my_family_title">{t("my_family.title")}</h1>
                    </div>
                    <div className="col-6 text-right btn-wrap btn-wrap--grp">
                        {familyMemberDetails && familyMemberDetails.length < maximumFamilyMembers &&
                            <button type="button" className="btn btn-outline-primary btn-sm" onClick={() => window.location.href = `#${NAVIGATE_FAMILY_MEMBER_ADD}`} data-test="addFamily">{t("my_family.add_family")}</button>
                        }
                        {/* <button type="button" className="btn btn-outline-primary btn-sm">SKYPETS</button> */}
                        <button type="button" className="btn btn-outline-primary btn-sm" onClick={() => window.location.href = `#${NAVIGATE_TRANSFER}`} data-test="transferButton">{t("my_family.transfer_btn")}</button>
                    </div>
                </div>
                <div className="">
                    <div className="form-row">
                        {
                            familyMemberDetails.map((details, index) => {
                                return (
                                    <div key={index} className="col-lg-6">
                                        <FamilyMemberCard
                                            details={details}
                                            progressPointType={progressPointType}
                                            tierMapping={tierMapping}
                                            t={t}
                                            defaultConfig={selectedDefaultConfig}
                                            accountSummaryConfig={accountSummaryConfig}
                                        />
                                    </div>
                                )
                            })
                        }
                        {/* <div className="col-6"></div> */}
                        {nominee && familyMemberDetails &&
                            familyMemberDetails.length < nominee.maxLimit &&
                            <div className="col-6">
                                <div className="addNewMember">
                                    <a href={`#${NAVIGATE_FAMILY_MEMBER_ADD}`} className="stretched-link">
                                        <img src={`${_IMAGE_BASEURL}/addNewMember.png`} style={{maxWidth:"96px", maxHeight: "96px"}} alt="add new member" />
                                        {t("my_family.add_family")}
                                    </a>
                                </div>
                            </div>
                        }
                    </div>
                </div>
            </div>
        )
    }
}

const mapStateToProps = state => {
    const getValue = (variable, location = [], defaultValue = {}) => {
        try {
            if (!location.length) {
                return variable;
            }
            return getValue(variable[location.shift()], location, defaultValue);
        } catch (error) {
            return defaultValue;
        }
    }
    const familyConfig = state.configurationReducer[CONFIG_SECTION_MYFAMILY];
    const relationshipCodes = getValue(familyConfig, ['relationshipCodes']);
    const maximumFamilyMembers = familyConfig ? getValue(familyConfig, ['nominee', 'maxLimit'], familyConfig.ui.maxFamilyMembers) : 0;
    const progressPointType = getValue(familyConfig, ['ui', 'pointTypes', 'progress'], '');
    return {
        familyMemberDetails: state.familyListReducer.members,
        relationshipCodes,
        maximumFamilyMembers,
        progressPointType,
        familyConfig,
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        accountSummaryConfig: state.configurationReducer[CONFIG_SECTION_ACCOUNT_SUMMARY]
    }
}

const mapDispatchToProps = dispatch => {
    return {
        fetchFamilyMemberDetails: params => dispatch(getFamilyMembers(params)),
        fetchConfiguration: param => dispatch(fetchConfiguration(param))
    }
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(FamilyMembers)));