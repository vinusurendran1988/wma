import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { withSuspense, getLink } from '../../common/utils'
import { CONFIG_SECTION_SUMMARY, CONFIG_SECTION_DEFAULT, CONFIG_SECTION_ACCOUNT_SUMMARY } from '../../common/utils/Constants';
import { getItemFromBrowserStorage, BROWSER_STORAGE_KEY_PROGRAM_TYPE } from '../../common/utils/storage.utils';
import { NAVIGATE_MEMBER_DASHBOARD } from '../../common/utils/urlConstants';
import { JSONPath } from 'jsonpath-plus';

class HeaderMenu extends Component {
    constructor (props) {
        super(props);
        this.state = {}
    }

    renderBreadcrumbMenuItems(menuitem, index) {
        const { t } = this.props
        const { child, condition } = menuitem
        let title = t(`breadcrumb.${menuitem.key}`)
        if (title === `breadcrumb.${menuitem.key}`) {
            title = t(`breadcrumb.${menuitem.key}`)
        }
        if(condition && Object.keys(condition).length>0){
            const { source, key, pattern, patternValue } = condition
            if (source && key && pattern) {
                const json = this[source][key]
                const conditionResult = JSONPath({ path: pattern, json })   
                if (patternValue && 
                    conditionResult && 
                    conditionResult.length!=0 && 
                    eval(`${conditionResult}${patternValue}`)) {
                    if(child && child.length > 0 ){
                        return this.renderMenuItemWithChild(child, menuitem, title, index)
                    } else {
                        return this.renderMenuItemWithoutChild(menuitem, title, index)
                    }
                }

            }
        } else if (child && child.length > 0) {
            return this.renderMenuItemWithChild(child, menuitem, title, index)
        } else {
            return this.renderMenuItemWithoutChild(menuitem, title, index)
        }
    }

    renderMenuItemWithChild = (child, menuitem, title, index) => {
        const { t } = this.props
        return (
            <li key={index} className={`nav-item hasHover ${(this.props.menuReference === menuitem.key ? " active" : "")}`}>
                <a className="nav-link" drole="button" aria-haspopup="true" aria-expanded="false">{title}</a>
                <ul className="dropdown-menu" >
                    {
                        child.map((childMenu, innerIndex) => {
                            if (childMenu.visible) {
                                let childTitle = t(`breadcrumb.${childMenu.key}`)
                                let uriLink = getLink(childMenu.link) || getLink(NAVIGATE_MEMBER_DASHBOARD)
                                if (childTitle === `breadcrumb.${childMenu.key}`) {
                                    childTitle = t(`breadcrumb.${childMenu.key}`)
                                }
                                return (
                                    <li key={innerIndex}>
                                        <a className="nav-link" role="button" target={childMenu.target ? childMenu.target : "_self"} href={uriLink}>{childTitle}</a>
                                    </li>
                                )
                            }
                        })
                    }
                </ul>
            </li>
        )
    }

    renderMenuItemWithoutChild = (menuitem, title, index) => {
        let linkClass = `nav-link ${menuitem.additinalClass} ${menuitem.enable ? (this.props.menuReference === menuitem.key ? " active" : "") : " disabled"}`
        let liClass = `nav-item ${menuitem.enable ? (this.props.menuReference === menuitem.key ? " active" : "") : " disabled"}`
        let uriLink = getLink(menuitem.link) || getLink(NAVIGATE_MEMBER_DASHBOARD)
        return (
            menuitem.enable ?
                <li key={`${menuitem.id}-${index}`} className={liClass}>
                    <a target={menuitem.target ? menuitem.target : "_self"} className={linkClass} href={uriLink}>{title}</a>
                </li> :
                <li key={`${menuitem.id}-${index}`} className={liClass}>
                    <a target={menuitem.target ? menuitem.target : "_self"} className={linkClass} tabIndex="-1" href={uriLink}>{title}</a>
                </li>
        )
    }

    render() {

        const { summaryConfig, accountSummary, t } = this.props
        return (
            <div className="header__portal-menu">
                <div className="container">
                    <nav className="navbar navbar-expand-lg menuWrap3">
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item">
                                <span>{t('quickaccessmenu.header.welcome_back')}</span>&nbsp;
                                <strong>{accountSummary && `${accountSummary.givenName}`}</strong>
                            </li>
                            {/* <li className="breadcrumb-item active" aria-current="page"></li> */}
                        </ol>
                        <button className="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                            <div className="hamburger"> <span></span> <span></span> <span></span> </div>
                        </button>
                        <div className="collapse navbar-collapse" id="navbarNavAltMarkup">
                            <ul className="navbar-nav">

                                {
                                    summaryConfig &&
                                    summaryConfig.ui &&
                                    summaryConfig.ui.layout &&
                                    summaryConfig.ui.layout.elements &&
                                    summaryConfig.ui.layout.elements.breadcrumbMenuItems &&
                                    summaryConfig.ui.layout.elements.breadcrumbMenuItems.visibility &&
                                    summaryConfig.ui.layout.elements.breadcrumbMenuItems.menuItems &&
                                    summaryConfig.ui.layout.elements.breadcrumbMenuItems.menuItems.map((breadcrumbItem, index) => {
                                        if (breadcrumbItem.visible) {
                                            return this.renderBreadcrumbMenuItems(breadcrumbItem, index)
                                        }
                                    })
                                }
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        );
    }
}

function mapStateToProps(state) {

    return {
        accountSummary: state.accountSummaryReducer.accountSummary,
        menuReference: state.menuReferenceReducer.payload,
        summaryConfig: state.configurationReducer[CONFIG_SECTION_SUMMARY],
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        accountSummaryConfig: state.configurationReducer[CONFIG_SECTION_ACCOUNT_SUMMARY],
        currentUserData: state.currentLoginUserDataReducer.currentUserData,
        corporateNominees: state.retriveAccountNomineeReducer.corporateNominees,
        profileData: state.profileDataReducer.profileData
    }
}

export default withSuspense()(connect(mapStateToProps, {})(withTranslation()(HeaderMenu)));