import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { withSuspense, numberWithCommas, getLink } from '../../common/utils'
import { CONFIG_SECTION_SUMMARY, CONFIG_SECTION_DEFAULT, CONFIG_SECTION_ACCOUNT_SUMMARY } from '../../common/utils/Constants';
import { getItemFromBrowserStorage, BROWSER_STORAGE_KEY_MEMBERSHIP_NO, BROWSER_STORAGE_KEY_COMPANY_CODE, BROWSER_STORAGE_KEY_PROGRAM_CODE } from '../../common/utils/storage.utils';
import { FIELD_ID,
        QR,
        GOLD_STAR,
        FLIGHT_IMAGE
} from './Constants'
import parse from 'html-react-parser'
import { getQrCodeImage, setTierDetails } from '../../common/middleware/redux/commonAction'
import { _IMAGE_BASEURL } from '../../common/config/config';
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';
import {JSONPath} from 'jsonpath-plus';
import profile from '../profile';

class QuickAccessMenu extends Component {
    constructor(props) {
        super(props);
        this.state = {}
    }

    componentDidMount(){
        const { accountSummary, accountSummaryConfig } = this.props
        if(accountSummary && accountSummaryConfig){
            this.props.setTierDetails(accountSummary, accountSummaryConfig)
        }
    }

    componentDidUpdate = (prevProps) => {
        if(prevProps.accountSummaryConfig != this.props.accountSummaryConfig){
            const { accountSummary, accountSummaryConfig } = this.props
            this.props.setTierDetails(accountSummary, accountSummaryConfig)
        }
    }
    getPoints(accountSummary, pointTypeList) {
        let point = 0
        accountSummary.pointDetails.map((pointData) => {
            if (pointTypeList.includes(pointData.pointType)) point += pointData.points
        })
        return point;
    }

    renderQuickLinkMenues = (menu, t) => {
        switch(menu.action) {
            case QR: 
                return <li>
                    <a onClick={() => this.getQrCode()} role="button" data-toggle="modal" data-target="#digital-card-modal">
                        <i>{parse(menu.svgCode)}</i>
                        <span>{t('quickaccessmenu.menucard.' + menu.id)}</span>
                    </a>
                </li>
            default: 
                return <li>
                    <a target={menu.target?menu.target:"_self"} href={getLink(menu.link)} >
                        <i>{parse(menu.svgCode)}</i>
                        <span>{t('quickaccessmenu.menucard.' + menu.id)}</span>
                    </a>
                </li>
        }
    }

    getPointsIcon = (field) => {
        switch (field.icon) {
            case GOLD_STAR:
                return <i class={field.iconClass ? field.iconClass : ""}>
                    <img src={`${_IMAGE_BASEURL}/icons/icon-gold-star.svg`} alt="gold star icon" />
                </i>
            case FLIGHT_IMAGE:
                return <i class={field.iconClass ? field.iconClass : ""}>
                    <img src={`${_IMAGE_BASEURL}/icons/icon-flight-outline.svg`} alt="gold star icon" />
                </i>
        }
    }

    getQrCode = () => {
        const companyCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE)
        const programCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE)
        const membershipNumber = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)
        const qrimagerequest = {
            object: {
                companyCode,
                programCode,
                membershipNumber
            }
        }
        if (!this.props.qrcodeImage || 
            !this.props.qrcodeImage.qrCode) {
            this.props.getQrCodeImage(qrimagerequest);
        } 
    }

    getDisplayName = (summaryConfig, profileData) => {
        let displayName = ""
        if(summaryConfig != undefined &&
            summaryConfig.ui &&
            summaryConfig.ui.layout && profileData){
                const uiPath = summaryConfig.ui.layout.elements.pointDropdown.displayName.uiPath
                displayName = JSONPath({path: uiPath, json: profileData})
        }
        return displayName
    }

    getCurrentProgramName = (currentDefaultConfig, memberTierDetails) => {
        let currentProgramName = ""
        if (currentDefaultConfig &&
            currentDefaultConfig.programType &&
            currentDefaultConfig.programType == "individual") {
            currentProgramName = memberTierDetails && memberTierDetails.tier1 && memberTierDetails.tier1.type ?
                memberTierDetails.tier1.type : ""
        } else {
            currentProgramName = currentDefaultConfig && currentDefaultConfig.programName
        }
        return currentProgramName
    }

    render() {

        const { t, accountSummary, summaryConfig, memberTierDetails, defaultConfig, profileData } = this.props
        const currentDefaultConfig = getCurrentProgramFromDefaultConfig(defaultConfig)
        const displayName = this.getDisplayName(summaryConfig, profileData)
        const currentProgramName = this.getCurrentProgramName(currentDefaultConfig, memberTierDetails)

        return (
            <div className="container">
                <div className="card mb-3 profile-overview">
                    <a className="icon-menu" data-toggle="collapse" href="#multiCollapseExample1" role="button" aria-expanded="false" aria-controls="multiCollapseExample1">
                        <i className="fa fa-ellipsis-h" aria-hidden="true"></i>
                    </a>
                    <div className="card-body ">
                        <div className="row">
                            <div className="col-lg-5 profile-overview__user">
                                <div className="ml-2">
                                    <div className="name1">
                                        {t('quickaccessmenu.header.welcome_back')}
                                        <span>{displayName}</span>
                                    </div>
                                    <div className="name2">{t('quickaccessmenu.header.ff_no')}{getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)}</div>
                                </div>
                                <div className="dropdown">
                                    <a className="btn btn-outline-primary dropdown-toggle" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <span className="text">
                                            <em className="text-uppercase">
                                                {
                                                    memberTierDetails && 
                                                    memberTierDetails.tier1 ?
                                                    memberTierDetails.tier1.name: ""
                                                }
                                            </em>
                                            {
                                                summaryConfig && accountSummary &&
                                                summaryConfig.ui.layout.elements.pointDropdown.totalPoints.map((totalPoint, idx) =>  {
                                                    return <> {
                                                                `${t('quickaccessmenu.pointsdesc.' + totalPoint.name)}: 
                                                                ${numberWithCommas(parseInt(this.getPoints(accountSummary, totalPoint.data.pointTypes)))}`
                                                                }
                                                            </>
                                                })
                                            }
                                            {/* {
                                                `${t(`quickaccessmenu.pointsdesc.${FIELD_ID}`)}: 
                                                ${this.getTotalPoints(summaryConfig, accountSummary)}`
                                            } */}
                                            </span>
                                    </a>
                                    <div className="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                        <div class="tier-status">
                                            <strong class="main-tier">
                                                 {currentProgramName}
                                                <span className="text-uppercase ml-1">
                                                    {
                                                        memberTierDetails &&
                                                        memberTierDetails.tier1 &&
                                                        memberTierDetails.tier1.name ?
                                                        memberTierDetails.tier1.name : ""
                                                    }
                                                </span>
                                            </strong>
                                        </div>
                                        {
                                            memberTierDetails && 
                                            memberTierDetails.enable && 
                                            memberTierDetails.tier2 ?
                                            <span class={`badge-brand badge-brand${memberTierDetails.tierDetails.themeClass} mb-3 w-100`}>
                                                {memberTierDetails.tier2.type?memberTierDetails.tier2.type:""}
                                                <strong className="text-uppercase ml-1">{memberTierDetails.tier2.name?memberTierDetails.tier2.name:""}</strong>
                                            </span>:""
                                        }
                                        <ul>
                                            {
                                                summaryConfig && accountSummary &&
                                                summaryConfig.ui.layout.elements.pointDropdown.fields.map((field, idx) => {
                                                    if (!field.link &&
                                                        field.visibility) {
                                                        return <li>
                                                            <a target={field.target ? field.target : "_self"} className="dropdown-item" role="button">
                                                                {
                                                                    this.getPointsIcon(field)
                                                                }
                                                                {t('quickaccessmenu.pointsdesc.' + field.name)}
                                                            </a>
                                                            <span className="points">{numberWithCommas(parseInt(this.getPoints(accountSummary, field.data.pointTypes)))}</span>
                                                        </li>
                                                    }
                                                })
                                            }

                                        </ul>
                                        {
                                             summaryConfig && accountSummary &&
                                             summaryConfig.ui.layout.elements.pointDropdown.totalPoints.map((totalPoint, idx) =>  {
                                                 if(totalPoint.visibility){
                                                     return <span class="tier-total">
                                                                {
                                                                    `${t('quickaccessmenu.pointsdesc.' + totalPoint.name)}: 
                                                                    ${numberWithCommas(parseInt(this.getPoints(accountSummary, totalPoint.data.pointTypes)))}`
                                                                }
                                                            </span>
                                                 }
                                             })
                                        }
                                        {/* <span class="tier-total">
                                            {
                                                `${t('quickaccessmenu.pointsdesc.pointType1')}: 
                                                ${this.getTotalPoints(summaryConfig, accountSummary)}`
                                            }
                                        </span> */}
                                        {
                                            summaryConfig && accountSummary &&
                                            summaryConfig.ui.layout.elements.pointDropdown.fields.map((field, idx) => {
                                                if (field.link &&
                                                    field.visibility) {
                                                    return <a target={field.target ? field.target : "_self"} href={getLink(field.link)} className="link">
                                                        {t('quickaccessmenu.header.upgrade_tiernow')}
                                                        <i className="icon-link"><img src={`${_IMAGE_BASEURL}/icons/icon-rit-arw.svg`} alt="right arrow" /></i>
                                                    </a>
                                                }
                                            })
                                        }

                                    </div>
                                </div>
                            </div>
                            <nav className="col-lg-7 profile-overview__links">
                                <div className="collapse" id="multiCollapseExample1">
                                    <ul className="quick-nav">
                                        {
                                            summaryConfig &&
                                            summaryConfig.ui.layout.elements.quickLinks.fields.map((field, idx) => {
                                                if (field.visibility) {
                                                    return this.renderQuickLinkMenues(field, t)
                                                }
                                            })
                                        }

                                    </ul>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    getTotalPoints(summaryConfig, accountSummary) {
        if (summaryConfig && accountSummary && summaryConfig.ui && summaryConfig.ui.layout
            && summaryConfig.ui.layout.elements && summaryConfig.ui.layout.elements.pointDropdown &&
            summaryConfig.ui.layout.elements.pointDropdown.fields) {
            const field = summaryConfig.ui.layout.elements.pointDropdown.fields.find(e => e.id == FIELD_ID && e.visibility)
            if (field) {
                return numberWithCommas(parseInt(this.getPoints(accountSummary, field.data.pointTypes)))
            }
        }
        return ""
    }
}


function mapStateToProps(state) {

    return {
        accountSummary: state.accountSummaryReducer.accountSummary,
        menuReference: state.menuReferenceReducer.payload,
        summaryConfig: state.configurationReducer[CONFIG_SECTION_SUMMARY],
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        accountSummaryConfig: state.configurationReducer[CONFIG_SECTION_ACCOUNT_SUMMARY],
        currentUserData: state.currentLoginUserDataReducer.currentUserData,
        corporateNominees: state.retriveAccountNomineeReducer.corporateNominees,
        profileData: state.profileDataReducer.profileData,
        qrcodeImage: state.qrCodeImageReducer.qrImage,
        memberTierDetails : state.setTierDetailsReducer.payload
    }
}

const mapDispatchToProps = {
    getQrCodeImage,
    setTierDetails
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(QuickAccessMenu)));