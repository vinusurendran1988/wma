import React, { Component } from 'react';
import { connect } from 'react-redux';
import { changeLanguage } from './actions';
import { withTranslation } from 'react-i18next';
import { withSuspense, toTitleCase, getSwitchProgramList, isEmptyOrSpaces } from '../../common/utils'
import logoImg from '../../../assets/logo.png'
import ReactCountryFlag from "react-country-flag"
import { logOut, fetchConfiguration } from '../../common/middleware/redux/commonAction'
import { 
    NAVIGATE_MEMBER_LOGIN, 
    NAVIGATE_MEMBER_BOOKING, 
    NAVIGATE_MEMBER_DASHBOARD, 
    NAVIGATE_404, 
    NAVIGATE_CORPORATE_BOOKING,
    NAVIGATE_CLUB,
    NAVIGATE_CORPORATE_OVERVIEW
} from '../../common/utils/urlConstants';
import { 
    getItemFromBrowserStorage, 
    setItemToBrowserStorage, 
    BROWSER_STORAGE_KEY_TOKEN, 
    BROWSER_STORAGE_KEY_PROGRAM_CODE, 
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO, 
    BROWSER_STORAGE_KEY_PROGRAM_TYPE, 
    BROWSER_STORAGE_KEY_CUSTOMER_NO, 
    BROWSER_STORAGE_KEY_EMAIL, 
    BROWSER_STORAGE_KEY_i18_LANG
} from '../../common/utils/storage.utils';
import { 
    CONFIG_SECTION_SUMMARY, 
    CONFIG_SECTION_DEFAULT, 
    PROGRAM_TYPE_CORPORATE, 
    PROGRAM_TYPE_INDIVIDUAL 
} from '../../common/utils/Constants';
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';
import ApiLoader from '../../common/components/fieldbank/loader/ApiLoader';
import { _DEFAULT_LANGUAGE, _WHITELIST_LANGUAGES } from '../../common/config/config';

class DefaultHeader extends Component {

    constructor(props) {

        super(props);
        const newState = { switchProgramList : []}
        this.logOutUser = this.logOutUser.bind(this)

        if(this.props.currentUserData && this.props.defaultConfig) {
            const programCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE)
            const { programs } = props.currentUserData.userDetails
            const defaultPrograms = props.defaultConfig.programs
            const switchProgramList = getSwitchProgramList(programs, defaultPrograms, props.currentUserData, programCode)
            if(switchProgramList.length > 0) {
                newState["switchProgramList"] = switchProgramList
                newState["programCode"] = programCode
            }
        }

        this.state = newState

    }

    updateSwitchMenu() {
        const programCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE)
        if(this.props.currentUserData && this.props.defaultConfig &&
            (this.state.switchProgramList.length == 0 || programCode != this.state.programCode)) {

            const { programs } = this.props.currentUserData.userDetails
            const defaultPrograms = this.props.defaultConfig.programs
            const switchProgramList = getSwitchProgramList(programs, defaultPrograms, this.props.currentUserData, programCode)
            if(switchProgramList.length > 0) this.setState({switchProgramList, programCode})
        }
    }

    componentDidUpdate(prevProp, prevState) {
        this.updateSwitchMenu()
    }

    componentDidMount(){
        let lang = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_i18_LANG)
        if(!lang){
           lang = _WHITELIST_LANGUAGES.find(e=>e.code == _DEFAULT_LANGUAGE)
        } else {
            lang = JSON.parse(lang)
        }
        this.props.changeLanguage(lang)
    }

    switchProgram(program) {

        const { programCode, programType, membershipNumber, email, customerNo } = program

        setItemToBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO, membershipNumber)
        setItemToBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE, programCode)
        setItemToBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE, programType)
        setItemToBrowserStorage(BROWSER_STORAGE_KEY_CUSTOMER_NO, customerNo)
        setItemToBrowserStorage(BROWSER_STORAGE_KEY_EMAIL, email)

        if(programType === PROGRAM_TYPE_CORPORATE) {
            window.location.href = `#${NAVIGATE_CORPORATE_OVERVIEW}`
            window.location.reload()
        } else if(programType === PROGRAM_TYPE_INDIVIDUAL) {
            window.location.href = `#${NAVIGATE_MEMBER_DASHBOARD}`
            window.location.reload()
        } else {
            window.location.href = `#${NAVIGATE_404}`
        }
    }

    getCompanyInfo(accountSummary) {
        let companyInfo = {}
        if (accountSummary) {
            let companyFullName = accountSummary.companyName
            if (companyFullName) {
                let names = companyFullName.split(" ")
                companyInfo = {
                    companyFirstName: names[0],
                    companyLastName: companyFullName.replace(names[0], '').trim(),
                    companyRegistrationNo: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                    tierName: accountSummary.tierName
                }
            }
        }
        return companyInfo
    }

    getLoginURL() {
        return `#${NAVIGATE_MEMBER_LOGIN}`
    }

    getBookingURL(programCode) {
        if(programCode === PROGRAM_TYPE_CORPORATE) {
            return `#${NAVIGATE_CORPORATE_BOOKING}`
        } else if(programCode === PROGRAM_TYPE_INDIVIDUAL) {
            return `#${NAVIGATE_MEMBER_BOOKING}`
        } else {
            return undefined
        }
    }

    getClubMembershipURL(programCode){
        if(programCode === PROGRAM_TYPE_INDIVIDUAL) {
            return `#${NAVIGATE_CLUB}`
        } else {
            return undefined
        }
    }

    getPrgramName(defaultConfig) {
        let programName = ""
        if(defaultConfig) {
            const currentProgram = getCurrentProgramFromDefaultConfig(defaultConfig)
            if(currentProgram) programName = currentProgram.programName
        }
        return programName
    }

    getLoginMenuTitle(programCode) {
        
        let title = ""
        const { t, accountSummary, defaultConfig } = this.props;

        const programName = this.getPrgramName(defaultConfig)
        if(programCode === PROGRAM_TYPE_INDIVIDUAL && !isEmptyOrSpaces(programName)) {
            title = t("header.welcome_to").replace("{PROGRAM_NAME}", programName)
        } else if(programCode === PROGRAM_TYPE_CORPORATE) {
            const companyInfo = this.getCompanyInfo(accountSummary)
            if(companyInfo) {
                title = `${t("header.welcome")} ${companyInfo.companyFirstName?companyInfo.companyFirstName:""} ${companyInfo.companyLastName?companyInfo.companyLastName:""}`
            } else if(!isEmptyOrSpaces(programName)) {
                title = t("header.welcome_to").replace("{PROGRAM_NAME}", programName)
            }
        }
        return isEmptyOrSpaces(title)?t("header.welcome"):title
    }

    logOutUser() {
        this.props.logOutDetails();
    }

    render() {
        
        const { language, t, currentUserData, summaryConfig, customerProfileData } = this.props;
        const isToken = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_TOKEN)
        const name = currentUserData?toTitleCase(`${currentUserData.name}`):""
        const programType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE)
        const menuTitle = this.getLoginMenuTitle(programType)
        const loginURL = this.getLoginURL()
        const bookingURL = this.getBookingURL(programType)
        const clubURL = this.getClubMembershipURL(programType)

        return (

            <div className=" fixed-top">
                <nav className="container navbar navbar-expand-lg menuWrap1 menu1st">
                    <div>
                        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation"> <span className="navbar-toggler-icon"></span> </button>
                        <a className="navbar-brand"><img src={logoImg} alt="Loyalty Program Logo" /></a>
                    </div> 
                    <div className="collapse navbar-collapse" id="navbarsExampleDefault">
                        <ul className="navbar-nav ml-auto">
                            {
                                isToken && bookingURL &&
                                <li className="nav-item"> 
                                    <a className="nav-link" href={bookingURL}> 
                                        <i className="fa fa-calendar"></i> {t('header.book')}<span className="sr-only">(current)</span>
                                    </a> 
                                </li>
                            }
                            <li className="nav-item"> <a className="nav-link"><i className="fa fa-paper-plane-o"></i> {t('header.programName')}</a> </li>
                            <li className="nav-item"> <a className="nav-link"><i className="fa fa-plane"></i>{t('header.travel_with_us')}</a> </li>
                            <li className="nav-item"> <a className="nav-link"><i className="fa fa-globe"></i>{t('header.offer_promotion')}</a> </li>
                            {
                                isToken &&
                                <li className="nav-item"> 
                                    <a className="nav-link" href={clubURL}>
                                        <i className="fa fa-globe"></i>{t('header.club_membership_home')}
                                    </a> 
                                </li>
                            }

                            {/* <li className="nav-item searchOption"> <a className="nav-link" ><i className="fa fa-search" aria-hidden="true"></i></a> </li> */}
                            <li className="nav-item dropdown langOption">
                                <a className="nav-link dropdown-toggle" data-toggle="dropdown"  role="button" aria-haspopup="true" aria-expanded="false"><ReactCountryFlag countryCode={language.flagCode} svg /> {language.name}</a>
                                <div className="dropdown-menu">
                                    {
                                        language.languageMap.map(lang =>
                                            <div key={lang.code} className="dropdown-item" onClick={() => this.props.changeLanguage(lang)}>
                                                <ReactCountryFlag countryCode={lang.flagCode} svg /> {lang.name}
                                            </div>
                                        )
                                    }

                                </div>
                            </li>
                            </ul>
                            </div>
                            <div>
                            {
                                isToken &&
                                <div className="profileOption mobileNavProfile">
                                    <span className="nav-link dropdown-toggle" data-toggle="dropdown"  role="button" aria-haspopup="true" aria-expanded="false">
                                        {/* <i className="fa fa-bars" aria-hidden="true"></i> */}
                                        {
                                            !isEmptyOrSpaces(name) && `${t('header.hi')} ${name}`
                                        }
                                    </span>
                                    <div className="dropdown-menu" style={{ "right": "0", "left": "auto" }}>
                                        <span className="dropdown-item">{menuTitle}</span>
                                        {
                                            this.state.switchProgramList &&
                                            this.state.switchProgramList.map((program, idx) => {
                                                return <a key={"switch-prg-" + idx} className="dropdown-item" role="button" onClick={() => this.switchProgram(program)}>
                                                    {`Switch to ${program.programName}`}
                                                </a>
                                            })
                                        }
                                        {
                                            summaryConfig && summaryConfig.ui && summaryConfig.ui.layout && summaryConfig.ui.layout.elements &&
                                                summaryConfig.ui.layout.elements.loginMenuItems && summaryConfig.ui.layout.elements.loginMenuItems.menuItems &&
                                                customerProfileData && Object.keys(customerProfileData).length > 0 ?
                                                <>
                                                    {
                                                        summaryConfig.ui.layout.elements.loginMenuItems.menuItems.map((menuItem, idx) => {
                                                            if (menuItem.visible) {
                                                                return <a key={"menuitem-" + idx} className="dropdown-item" href={`#${menuItem.link}`}>{t(`header.menuItems.${menuItem.key}`)}</a>
                                                            }
                                                        })
                                                    }
                                                    {/* <div className="dropdown-devider"></div> */}
                                                </> : <></>
                                        }
                                        <a className="dropdown-item" role="button" onClick={() => this.logOutUser()}>
                                            <i className="fa fa-sign-out" aria-hidden="true"> {t('header.logout')}</i>
                                        </a>
                                    </div>
                                </div>}
                            {
                                !isToken && loginURL &&
                                <div className="nav-item ">
                                    <a className="nav-link" href={loginURL}>{t('header.login')}</a>
                                </div>
                            }
                    </div>
                    <ApiLoader />
                </nav>
            </div>
        );
    }
}

DefaultHeader.propTypes = {

};

function mapStateToProps(state) {
    const { language } = state;
    return {
        language,
        summaryConfig: state.configurationReducer[CONFIG_SECTION_SUMMARY],
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        accountSummary: state.accountSummaryReducer.accountSummary,
        currentUserData: state.currentLoginUserDataReducer.currentUserData,
        customerProfileData: state.fetchCustomerProfileReducer?state.fetchCustomerProfileReducer.object:undefined,
        pageReference: state.pageReferenceReducer
    };
}

const mapDispatchToProps = dispatch => ({
    changeLanguage: (code) => dispatch(changeLanguage(code)),
    fetchConfiguration: (section) => dispatch(fetchConfiguration(section)),
    logOutDetails: (payload) => dispatch(logOut(payload))
})

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(DefaultHeader)));