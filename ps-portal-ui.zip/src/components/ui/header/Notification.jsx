import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import { _IMAGE_BASEURL } from '../../common/config/config';
import { fetchConfiguration } from '../../common/middleware/redux/commonAction';
import { numberWithCommas, withSuspense } from '../../common/utils';
import { CONFIG_SECTION_NOTIFICATION } from '../../common/utils/Constants';
import { findValueFromObjectByPath } from '../../common/utils/object.utils';
import { BROWSER_STORAGE_KEY_COMPANY_CODE, BROWSER_STORAGE_KEY_DEFAULT_PROGRAM_CODE, BROWSER_STORAGE_KEY_MEMBERSHIP_NO, getItemFromBrowserStorage } from '../../common/utils/storage.utils';
import { NAVIGATE_MEMBER_EXTEND_EXPIRY, NAVIGATE_MEMBER_PROFILE } from '../../common/utils/urlConstants';
import { getNotifications } from './actions';
import { NUMBER } from './Constants';

/**
 * @name Notification
 * @description Component to display member notifications.
 * 
 * @author Amrutha J Raj
 */
class Notification extends Component {
    constructor(props) {
        super(props);
        this.fetchNotifications = this.fetchNotifications.bind(this);
    }

    componentDidMount() {
        if (!this.props.config) {
            this.props.fetchConfiguration(CONFIG_SECTION_NOTIFICATION)
        }
        else {
            this.fetchNotifications()
        }
    }

    componentDidUpdate(prevProps) {
        if (JSON.stringify(prevProps.config) != JSON.stringify(this.props.config)) {
            this.fetchNotifications()
        }

    }

    /**
     * Method to get the notifications
     * 
     * @author Amrutha J Raj
     */
    fetchNotifications = () => {
        const requestPayload = {
            "object": {
                "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_DEFAULT_PROGRAM_CODE),
                "membershipNumber": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
            }
        }
        this.props.getNotifications(requestPayload)
    }

    /**
     * Method to form the notification message
     * 
     * @author Amrutha J Raj
     */
    getNotificationMessage = (message, data, config) => {
        config.map(element => {
            const value = findValueFromObjectByPath({ item: data }, element.path, "")
            message = message.replace(`{${element.placeholder}}`, element.type == NUMBER ? 
                      numberWithCommas(parseInt(value)):
                      value)
        })

        return message
    }

    /**
     * Method to render the notifications body
     * @param String Element to be rendered
     * @author Amrutha J Raj
     */
    renderNotificationBody = (element) => {
        const { notifications, t, config } = this.props

        const messageConfig = config && config.ui && config.ui.layout && config.ui.layout.expiryPointDetails &&
            config.ui.layout.expiryPointDetails.message ? config.ui.layout.expiryPointDetails.message : []

        const maxItem = config && config.ui && config.ui.layout && config.ui.layout.expiryPointDetails &&
            config.ui.layout.expiryPointDetails.maxItem

        switch (element) {
            case "expiryPointDetails": return notifications && notifications.expiryPointDetails && notifications.expiryPointDetails.map((item, index) => {
                if (index < maxItem) {
                    return (
                        <li onClick={() => window.location.href = `#${NAVIGATE_MEMBER_EXTEND_EXPIRY}`} role="button">
                            <div className="notification__text">
                                <i><img src={`${_IMAGE_BASEURL}/icons/icon-warning.svg`} alt="expiry notification" /></i>
                                {/* <strong>{t('notifications.expiry_message').replace("{NO_OF_MILES}", item.points).replace("{POINT_TYPE}", item.pointType).replace("{MILES}", item.displayName).replace("{DURATION}", item.expiryDate)}</strong> */}
                                <strong>{this.getNotificationMessage(t('notifications.expiry_message'), item, messageConfig)}</strong>
                            </div>
                            {/* <span className="date">24min</span> */}
                        </li>
                    );
                }
            })

            case "profileComplete": return notifications && notifications.profileComplete &&
                <li role="button" onClick={() => window.location.href = `#${NAVIGATE_MEMBER_PROFILE}`}>
                    <div className="notification__text">
                        <i><img src={`${_IMAGE_BASEURL}/icons/icon-info-small.svg`} alt="expiry notification" /></i>
                        <span>{t('notifications.profile_completion_message').replace("{COMPLETION_PERCENTAGE}", notifications.profileComplete.percentage)}</span>

                    </div>
                    {/* <span className="date">yesterday</span> */}
                </li>
        }
    }

    render() {
        const { t, config, notifications } = this.props
        return (
            <li className="notification">
                <a disabled={true} className="nav-link" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" >
                    {/* <span className="count">3</span> */}
                    <img src={`${_IMAGE_BASEURL}/icons/icon-noti.svg`} alt="notification button" />
                </a>
                <div className="dropdown-menu">
                    <div className="notification__title">{t('notifications.title')}</div>
                    <ul>
                        {config && config.ui && config.ui.layout && config.ui.layout.order
                            && config.ui.layout.order.length && config.ui.layout.order.map(element => this.renderNotificationBody(element))}

                        {(notifications && ((!notifications.expiryPointDetails || notifications.expiryPointDetails.length == 0) &&
                            (!notifications.profileComplete || notifications.profileComplete.length == 0)) || !notifications) &&
                            <li>
                                <div className="notification__text">
                                    <span>{t('notifications.no_notifications')}</span>
                                </div>
                            </li>
                        }
                    </ul>
                    {/* <div className="show-more"><a >Show All</a></div> */}

                </div>
            </li>
        );
    }
}

const mapStateToProps = (state) => {
    return {

        error: state.commonErrorReducer.error,
        notifications: state.getNotificationsReducer.notifications,
        config: state.configurationReducer[CONFIG_SECTION_NOTIFICATION],



    }
}
const mapDispatchToProps = {
    getNotifications,
    fetchConfiguration
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(Notification)));
