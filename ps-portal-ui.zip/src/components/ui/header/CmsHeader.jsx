import React, { Component } from 'react';
import { connect } from 'react-redux';
import { changeLanguage, getHeaderDetails } from './actions'
import { withTranslation } from 'react-i18next';
import { withSuspense, getSwitchProgramList, isEmptyOrSpaces, getLink } from '../../common/utils'
import ReactCountryFlag from "react-country-flag"
import { logOut, fetchConfiguration } from '../../common/middleware/redux/commonAction'
import {
    NAVIGATE_MEMBER_LOGIN,
    NAVIGATE_MEMBER_DASHBOARD,
    NAVIGATE_404,
    NAVIGATE_CORPORATE_OVERVIEW
} from '../../common/utils/urlConstants';
import {
    getItemFromBrowserStorage,
    setItemToBrowserStorage,
    BROWSER_STORAGE_KEY_TOKEN,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
    BROWSER_STORAGE_KEY_PROGRAM_TYPE,
    BROWSER_STORAGE_KEY_CUSTOMER_NO,
    BROWSER_STORAGE_KEY_EMAIL,
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_i18_LANG
} from '../../common/utils/storage.utils';
import {
    CONFIG_SECTION_SUMMARY,
    CONFIG_SECTION_DEFAULT,
    PROGRAM_TYPE_CORPORATE,
    PROGRAM_TYPE_INDIVIDUAL
} from '../../common/utils/Constants';
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';
import { _DEFAULT_LANGUAGE, _WHITELIST_LANGUAGES, _IMAGE_BASEURL } from '../../common/config/config';
import ApiLoader from '../../common/components/fieldbank/loader/ApiLoader'
import Notification from './Notification';

class CmsHeader extends Component {

    constructor(props) {

        super(props);
        const newState = {
            switchProgramList: [],
            request: {}
        }
        this.logOutUser = this.logOutUser.bind(this)

        if (this.props.currentUserData && this.props.defaultConfig) {
            const programCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE)
            const { programs } = props.currentUserData.userDetails
            const defaultPrograms = props.defaultConfig.programs
            const switchProgramList = getSwitchProgramList(programs, defaultPrograms, props.currentUserData, programCode)
            if (switchProgramList.length > 0) {
                newState["switchProgramList"] = switchProgramList
                newState["programCode"] = programCode
            }
        }

        this.state = newState

        const isToken = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_TOKEN)
        if (isToken && !this.props.summaryConfig) {
            this.props.fetchConfiguration(CONFIG_SECTION_SUMMARY)
        }
    }

    updateSwitchMenu() {
        const programCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE)
        if (this.props.currentUserData && this.props.defaultConfig &&
            (this.state.switchProgramList.length == 0 || programCode != this.state.programCode)) {
            const { programs } = this.props.currentUserData.userDetails
            const defaultPrograms = this.props.defaultConfig.programs
            const switchProgramList = getSwitchProgramList(programs, defaultPrograms, this.props.currentUserData, programCode)
            if (switchProgramList.length > 0) this.setState({ switchProgramList, programCode })
        }
    }

    /**
     * Handling of updations when props or state are updated.
     * @param {*} prevProp 
     * @param {*} prevState 
     */
    componentDidUpdate(prevProp, prevState) {
        this.updateSwitchMenu()
        if ( Object.keys(this.state.request).length == 0 ||
            (prevProp.language &&
            prevProp.language.code &&
            prevProp.language.code != this.props.language.code)) {
            this.getHeaderInfo();
        }
    }

    componentDidMount() {
        this.getHeaderInfo();
        let lang = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_i18_LANG)
        if (!lang) {
            lang = _WHITELIST_LANGUAGES.find(e => e.code == _DEFAULT_LANGUAGE)
        } else {
            lang = JSON.parse(lang)
        }
        this.props.changeLanguage(lang)
    }

    /**
     * When the component is loaded or the language is changed,
     * do the API call to get the header information
     * 
     */
    getHeaderInfo() {
        const { defaultConfig } = this.props;
        if (defaultConfig) {
            const currentProgram = getCurrentProgramFromDefaultConfig(defaultConfig)
            let queryData = {};
            if (currentProgram &&
                currentProgram.data &&
                currentProgram.data.cmsDetails &&
                currentProgram.data.cmsDetails.header) {
                queryData = currentProgram.data.cmsDetails.header
            }

            const request = {
                object: {
                    companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                    programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                    membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO) ?
                        getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO) : "",
                    ...queryData
                }
            }
            this.setState({request})
            this.props.getHeaderDetails(request)
        }
    }

    switchProgram(program) {

        const { programCode, programType, membershipNumber, email, customerNo } = program

        setItemToBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO, membershipNumber)
        setItemToBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE, programCode)
        setItemToBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE, programType)
        setItemToBrowserStorage(BROWSER_STORAGE_KEY_CUSTOMER_NO, customerNo)
        setItemToBrowserStorage(BROWSER_STORAGE_KEY_EMAIL, email)
        if (programType === PROGRAM_TYPE_CORPORATE) {
            window.location.href = `#${NAVIGATE_CORPORATE_OVERVIEW}`
            window.location.reload()
        } else if (programType === PROGRAM_TYPE_INDIVIDUAL) {
            window.location.href = `#${NAVIGATE_MEMBER_DASHBOARD}`
            window.location.reload()
        } else {
            window.location.href = `#${NAVIGATE_404}`
        }
    }

    getCompanyInfo(accountSummary) {
        let companyInfo = {}
        if (accountSummary) {
            let companyFullName = accountSummary.companyName
            if (companyFullName) {
                let names = companyFullName.split(" ")
                companyInfo = {
                    companyFirstName: names[0],
                    companyLastName: companyFullName.replace(names[0], '').trim(),
                    companyRegistrationNo: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                    tierName: accountSummary.tierName
                }
            }
        }
        return companyInfo
    }

    getLoginURL() {
        return `#${NAVIGATE_MEMBER_LOGIN}`
    }
    getPrgramName(defaultConfig) {
        let programName = ""
        if (defaultConfig) {
            const currentProgram = getCurrentProgramFromDefaultConfig(defaultConfig)
            if (currentProgram) programName = currentProgram.programName
        }
        return programName
    }

    getHeaderContent(headerResponse) {
        let headerInformation = []
        if (headerResponse &&
            headerResponse.headerdetails &&
            headerResponse.headerdetails.object &&
            headerResponse.headerdetails.object.data &&
            headerResponse.headerdetails.object.data.length > 0) {
            const { data } = headerResponse.headerdetails.object
            headerInformation['headerdetail'] = data[0].content ? JSON.parse(data[0].content.value) : {};
            headerInformation['logourl'] = data[1].url ? data[1].url : "";
        }
        return headerInformation
    }

    getLoginMenuTitle(programCode) {

        let title = ""
        const { t, accountSummary, defaultConfig } = this.props;
        const programName = this.getPrgramName(defaultConfig)
        if (programCode === PROGRAM_TYPE_INDIVIDUAL && !isEmptyOrSpaces(programName)) {
            title = t("header.welcome_to").replace("{PROGRAM_NAME}", programName)
        } else if (programCode === PROGRAM_TYPE_CORPORATE) {
            const companyInfo = this.getCompanyInfo(accountSummary)
            if (companyInfo) {
                title = `${t("header.welcome")} ${companyInfo.companyFirstName ? companyInfo.companyFirstName : ""} ${companyInfo.companyLastName ? companyInfo.companyLastName : ""}`
            } else if (!isEmptyOrSpaces(programName)) {
                title = t("header.welcome_to").replace("{PROGRAM_NAME}", programName)
            }
        }
        return isEmptyOrSpaces(title) ? t("header.welcome") : title
    }

    logOutUser() {
        this.props.logOut();
    }

    getHeaderDetailTemplate(headerInformation) {
        return headerInformation &&
            headerInformation.headerdetail &&
            headerInformation.headerdetail.length > 0 &&
            headerInformation.headerdetail.map((header, index) => {
                if (header.visibility &&
                    !header.child) {
                    return <li className={header.className ? header.className : "nav-item"} key={"main-header-"+index}>
                        <a className={header.linkClass ? header.linkClass : "nav-link"} href={getLink(header.link)} target={header.target?header.target:"_self"}>
                            {header.icon && <image src={header.icon} alt={`Icon for ${header.title}`} />}
                            {header.iconClass && <i className={header.iconClass}></i>}
                            <span>{header.title}</span>
                            {/* <span className="sr-only">(current)</span> */}
                        </a>
                    </li>
                } else if (header.visibility &&
                    header.child && header.child.length > 0) {
                    return <li className={header.className ? header.className : "nav-item"} key={"main-header-"+index}>
                        <a className={header.linkClass ? header.linkClass : "nav-link"}>
                            {header.icon && <image src={header.icon} alt={`Icon for ${header.title}`} />}
                            {header.iconClass && <i className={header.iconClass}></i>}
                            <span>{header.title}</span>
                        </a>
                        <div className="sub-nav">
                            <ul>
                                {
                                    header.child.map((child, index) => {
                                        if (child.header.visibility) {
                                            return <li key={"child-header-"+index}>
                                                <h6 className="hasHover">{child.header.title}</h6>
                                                <div className="sub-nav__blck">
                                                    {
                                                        child.body.map((bodyContent, index) => {
                                                            if (bodyContent.visibility) {
                                                                return <a key={"child-body-header-"+index} href={getLink(bodyContent.link)} className="sub-nav__item" target={bodyContent.target?bodyContent.target:"_self"}>
                                                                    {bodyContent.icon && <image src={bodyContent.icon} alt={`Icon for ${bodyContent.title}`} />}
                                                                    {bodyContent.iconClass && <i className={bodyContent.iconClass}></i>}
                                                                    {bodyContent.title}
                                                                </a>
                                                            }
                                                        })
                                                    }
                                                    {
                                                        child.footer.map((footerContent, index) => {
                                                            if (footerContent.visibility) {
                                                                return <a key={"child-footer-header-"+index} href={getLink(footerContent.link)} className="link" target={footerContent.target?footerContent.target:"_self"}>
                                                                            {footerContent.title}
                                                                            <i className="icon-link"> <img src={`${_IMAGE_BASEURL}/icons/icon-rit-arw.svg`} alt="right arrow" /> </i> 
                                                                        </a>
                                                            }
                                                        })
                                                    }
                                                </div>
                                            </li>
                                        }
                                    })
                                }
                            </ul>  </div>
                    </li>

                }
            })
    }

    getNotificationTemplate() {
        return <Notification/>}

    render() {

        const { language, t, currentUserData, summaryConfig, headerResponse, profileImage, includeHeader  } = this.props;
        const isToken = !isEmptyOrSpaces(getItemFromBrowserStorage(BROWSER_STORAGE_KEY_TOKEN))
        //const name = currentUserData ? toTitleCase(`${currentUserData.name}`) : ""
        const programType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE)
        const menuTitle = this.getLoginMenuTitle(programType)
        const loginURL = this.getLoginURL()
        const headerInformation = this.getHeaderContent(headerResponse)

        return (
            <div className="fixed-top">
                <div className="container">
                    <div className="header__top-menu">
                        <div className="logo"> 
                            <a className="navbar-brand" href="#">
                                <img src={headerInformation.logourl} alt="Logo" /> 
                            </a>
                        </div>
                        <div className="header__site-menu">
                            <nav className="navbar navbar-expand-lg menuWrap1 menu1st">
                                <div>
                                    <button className="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault"
                                        aria-expanded="false" aria-label="Toggle navigation">
                                        <div className="hamburger"> <span></span> <span></span> <span></span> </div>
                                    </button>
                                </div>
                                <div className="collapse navbar-collapse" id="navbarsExampleDefault">
                                    <ul className="navbar-nav ml-auto header__menu-list">
                                        {
                                            this.getHeaderDetailTemplate(headerInformation)
                                        }

                                    </ul>
                                </div>
                            </nav>
                            <ul className="header__search">
                                {/* <li> <a className="search" href="#" role="button"> <i className="fa fa-search"></i> <span className="sr-only">Search</span> </a> </li> */}
                                <li className="nav-item dropdown langOption">
                                    <a className="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <ReactCountryFlag alt={`${language.flagCode} - contry flag icon`} countryCode={language.flagCode} svg />
                                        <span className="text">{` ${language.name}`}</span>
                                    </a>
                                    <div className="dropdown-menu">
                                        {
                                            language.languageMap.map((lang, index) =>
                                                <a key={"language-drop-"+index} className="dropdown-item" role="button" onClick={() => this.props.changeLanguage(lang)}>
                                                    <ReactCountryFlag alt={`${lang.flagCode} - contry flag icon`} countryCode={lang.flagCode} svg />
                                                    {` ${lang.name}`}
                                                </a>
                                            )
                                        }
                                    </div>
                                </li>
                                {
                                    isToken && this.getNotificationTemplate()
                                }

                            </ul>
                            {
                                isToken &&
                                <div className="header__user mobileNavProfile">
                                    <a className="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <img src={
                                            profileImage ?
                                                "data:image/" +
                                                profileImage.profileImgType +
                                                ";" +
                                                profileImage.profileImgEncoder +
                                                "," +
                                                profileImage.profileImgData
                                                : `${_IMAGE_BASEURL}/default-profile-picture.png`
                                            }
                                            style={{maxWidth: "36px", maxHeight: "36px"}}
                                            alt="Profile Picture" /></a>
                                    <div className="dropdown-menu">
                                        <span >{menuTitle}</span>
                                        {
                                            this.state.switchProgramList &&
                                            this.state.switchProgramList.map((program, idx) => {
                                                return <a key={"switch-prg-" + idx} className="dropdown-item" role="button" onClick={() => this.switchProgram(program)}>
                                                    {`Switch to ${program.programName}`}
                                                </a>
                                            })
                                        }
                                        {
                                            includeHeader && summaryConfig && summaryConfig.ui && summaryConfig.ui.layout && summaryConfig.ui.layout.elements &&
                                                summaryConfig.ui.layout.elements.loginMenuItems && summaryConfig.ui.layout.elements.loginMenuItems.menuItems &&
                                                currentUserData && Object.keys(currentUserData).length > 0 ?
                                                <>
                                                    {
                                                        summaryConfig.ui.layout.elements.loginMenuItems.menuItems.map((menuItem, idx) => {
                                                            if (menuItem.visible) {
                                                                return <a key={"menuitem-" + idx} className="dropdown-item" href={`#${menuItem.link}`}>{t(`header.menuItems.${menuItem.key}`)}</a>
                                                            }
                                                        })
                                                    }
                                                    {/* <div className="dropdown-devider"></div> */}
                                                </> : <></>
                                        }
                                        <a className="dropdown-item" role="button" onClick={() => this.logOutUser()} data-test="logouttest">
                                            {t('header.logout')}
                                        </a>
                                    </div>
                                </div>
                            }
                            {
                                !isToken && document.URL.indexOf(`#${NAVIGATE_MEMBER_LOGIN}`) <= -1 && loginURL &&
                                <div className="nav-item">
                                    <a className="nav-link" href={loginURL}>{t('header.login')}</a>
                                </div>
                            }
                        </div>
                    </div>
                </div>
                <ApiLoader />
            </div>
        );
    }
}

function mapStateToProps(state) {
    const { language } = state;
    return {
        language,
        summaryConfig: state.configurationReducer[CONFIG_SECTION_SUMMARY],
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        currentUserData: state.currentLoginUserDataReducer.currentUserData,
        headerResponse: state.getHeaderDetailsReducer,
        profileImage: state.profileImageReducer.profileImage
    };
}

const mapDispatchToProps = {
    changeLanguage,
    fetchConfiguration,
    logOut,
    getHeaderDetails,
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(CmsHeader)));