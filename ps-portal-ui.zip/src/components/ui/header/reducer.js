import { SET_LANGUAGE, SET_HEADERDETAILS, GET_NOTIFICATIONS } from './actions';
import { _DEFAULT_LANGUAGE, _WHITELIST_LANGUAGES } from '../../common/config/config';
import { setItemToBrowserStorage, BROWSER_STORAGE_KEY_i18_LANG, getItemFromBrowserStorage } from '../../common/utils/storage.utils';

const initialState = {
    name: _WHITELIST_LANGUAGES.find(e=> e.code == _DEFAULT_LANGUAGE).name,
    code: _DEFAULT_LANGUAGE,
    flagCode: _WHITELIST_LANGUAGES.find(e=> e.code == _DEFAULT_LANGUAGE).flagCode,
    languageMap: _WHITELIST_LANGUAGES
}

export const initialConfig = {
    headerdetails: {}
}

export function language( state, action ) {
    const { type, payload } = action;
    if(!state) {
        const lang = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_i18_LANG)
        if (!lang || lang === "null" || lang === "undefined") {
            state = initialState
            const { name, code, flagCode } = state
            setItemToBrowserStorage(BROWSER_STORAGE_KEY_i18_LANG, JSON.stringify({ name, code, flagCode }))
        } else {
            state = { ...JSON.parse(lang), languageMap: _WHITELIST_LANGUAGES }
        }
    }
    if(type === SET_LANGUAGE) {
        const { lang } = payload
        setItemToBrowserStorage(BROWSER_STORAGE_KEY_i18_LANG, JSON.stringify(lang))
        return {
            name: lang.name,
            code: lang.code,
            flagCode: lang.flagCode,
            languageMap: _WHITELIST_LANGUAGES
        }
    } else {
        return state;
    }
}

export function getHeaderDetailsReducer( state, action ) {
    const { type, payload } = action;
    if(!state) state = {}
    if(type == SET_HEADERDETAILS){
        return{
            headerdetails : payload
        }
    } else {
        return state;
    }
}


/**
 * Reducer for getting notifications
 * @param {Object} state Initialised as empty object
 * @param {Object} action Object that contains request payload and action
 * @author Amrutha J Raj
 */
export function getNotificationsReducer(state, action) {
    const { type, payload } = action;
    if (!state) state = {}
    switch (type) {
        case GET_NOTIFICATIONS:
            return {
                ...state,
                notifications: payload.object
            }
        default:
            return state;
    }

}