
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withSuspense, isEmptyOrSpaces } from '../../common/utils'
import {
    fetchCurrentLoginUserData,
    fetchConfiguration,
    fetchProfileData
} from '../../common/middleware/redux/commonAction'
import {
    fetchAccountSummary,
    fetchAccountNominee,
    fetchProfileImage
} from '../../common/middleware/redux/commonAction'
import {
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
    getItemFromBrowserStorage,
    BROWSER_STORAGE_KEY_PROGRAM_TYPE
} from '../../common/utils/storage.utils';
import {
    CONFIG_SECTION_ACCOUNT_SUMMARY,
    CONFIG_SECTION_SUMMARY,
    PROGRAM_TYPE_CORPORATE,
    CONFIG_SECTION_DEFAULT
} from '../../common/utils/Constants';

class DataComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {}
    }

    inti = () => {
        const companyCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE)
        const programCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE)
        const membershipNumber = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)
        const porgramType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE)
        const canInitiateApiCall = !(isEmptyOrSpaces(companyCode) || isEmptyOrSpaces(programCode) || isEmptyOrSpaces(membershipNumber))
        const newState = {}
        if (!this.state.currentUserData && this.props.defaultConfig) {
            this.props.fetchCurrentLoginUserData(this.props.defaultConfig)
            newState["currentUserData"] = true
        }
        // if (!this.state.accountSummaryConfig && canInitiateApiCall) {
        //     this.props.fetchConfiguration(CONFIG_SECTION_ACCOUNT_SUMMARY)
        //     newState["accountSummaryConfig"] = true
        // }
        if (!this.state.profileData && canInitiateApiCall) {
            this.props.fetchProfileData()
            newState["profileData"] = true
        }
        if (porgramType === PROGRAM_TYPE_CORPORATE && !this.state.nomineeData  &&
            this.props.apiTriggerConfig.nominee && !this.props.corporateNominees && canInitiateApiCall) {
            this.props.fetchAccountNominee()
            newState["nomineeData"] = true
        }
        if (!this.state.accountSummary && 
            this.props.apiTriggerConfig.accountSummary &&
            this.props.currentUserData && canInitiateApiCall) {
            this.props.fetchAccountSummary()
            newState["accountSummary"] = true
        }
        if (this.state.nomineeData &&
            programCode &&
            this.props.corporateNominees && this.props.corporateNominees.programCode != programCode) {
            newState["nomineeData"] = false
        }
        if (this.state.profileData &&
            programCode &&
            this.props.profileData &&
            this.props.profileData.object &&
            this.props.profileData.object.memberAccount &&
            this.props.profileData.object.memberAccount.programCode != programCode) {
            newState["profileData"] = false
        }
        if (this.state.accountSummary &&
            programCode &&
            this.props.currentUserData &&
            this.props.accountSummary &&
            this.props.accountSummary.programCode != undefined &&
            this.props.accountSummary.programCode != programCode) {
            newState["accountSummary"] = false
        }
        if (this.state.currentUserData && !this.state.summaryConfig  && canInitiateApiCall) {
            // this.props.fetchConfiguration(CONFIG_SECTION_SUMMARY)
            newState["summaryConfig"] = true
        }
        // if (!this.state.profileImage && canInitiateApiCall) {
        //     const profileImageRequest = {
        //         object: {
        //             companyCode: companyCode,
        //             programCode: programCode,
        //             membershipNumber: membershipNumber,
        //         }
        //     }
        //     this.props.fetchProfileImage(profileImageRequest)
        //     newState["profileImage"] = true
        // }
        if (Object.keys(newState).length) this.setState(newState)
    }
    render() {
        this.inti()
        return (<></>);
    }
}

function mapStateToProps(state) {

    return {
        accountSummary: state.accountSummaryReducer.accountSummary,
        summaryConfig: state.configurationReducer[CONFIG_SECTION_SUMMARY],
        accountSummaryConfig: state.configurationReducer[CONFIG_SECTION_ACCOUNT_SUMMARY],
        corporateNominees: state.retriveAccountNomineeReducer.corporateNominees,
        profileData: state.profileDataReducer.profileData,
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT]
    }
}


const mapDispatchToProps = {
    fetchCurrentLoginUserData,
    fetchConfiguration,
    fetchAccountNominee,
    fetchAccountSummary,
    fetchProfileData,
    fetchProfileImage
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(DataComponent));