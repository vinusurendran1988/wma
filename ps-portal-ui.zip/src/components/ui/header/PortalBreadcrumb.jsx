import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withTranslation } from 'react-i18next';
import { withSuspense, isEmptyOrSpaces } from '../../common/utils';
import { getItemFromBrowserStorage, BROWSER_STORAGE_KEY_PROGRAM_TYPE } from '../../common/utils/storage.utils';
import { TOKEN } from '../enrolment/Constants';
import { handleQueryParamsInURL, handlePageRedirectionURL } from '../../common/utils/sso.utils';

class PortalBreadcrumb extends Component {

    constructor(props) {
        super(props)
    }

    componentDidMount() {
        this.isLoggedIn()
    }

    componentDidUpdate() {
        this.isLoggedIn()
    }

    isLoggedIn = () => {
        handleQueryParamsInURL()
        if(isEmptyOrSpaces(getItemFromBrowserStorage(TOKEN))) {
            handlePageRedirectionURL()
        }
    }

    render() {
        const { t } = this.props
        const programType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE)
        return (
            <ol className="breadcrumb">
                {
                    this.props.breadcrumbs.map((breadcrumb, index) => {
                        let breadcrumbTitle = t(`breadcrumb.${programType}.${breadcrumb.name}`)
                        if (breadcrumbTitle === `breadcrumb.${programType}.${breadcrumb.name}`) {
                            breadcrumbTitle = t(`breadcrumb.${breadcrumb.name}`)
                        }
                        return (
                            breadcrumb.link ?
                                <li key={index} className="breadcrumb-item">
                                    <a target={breadcrumb.target?breadcrumb.target:"_self"} href={`#${breadcrumb.link}`}>{breadcrumbTitle}</a>
                                </li> :
                                <li key={index} className="breadcrumb-item active">{breadcrumbTitle}</li>
                        )
                    })
                }
            </ol>
        );
    }
}

PortalBreadcrumb.propTypes = {
    breadcrumbs: PropTypes.array.isRequired
};

PortalBreadcrumb.defaultProps = {
    breadcrumbs: []
};

export default withSuspense()(withTranslation()(PortalBreadcrumb));