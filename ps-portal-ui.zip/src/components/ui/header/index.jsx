import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { withSuspense } from '../../common/utils'
import HeaderMenu from './HeaderMenu';
import DataComponent from './DataComponent';
import QuickAccessMenu from './QuickAccessMenu';
import { TOKEN } from '../enrolment/Constants';
import { getItemFromBrowserStorage } from '../../common/utils/storage.utils';
import { isEmptyOrSpaces } from '../../common/utils';
import { ROUTER_CONFIG } from '../../common/config/routing';
import { CONFIG_SECTION_SUMMARY } from '../../common/utils/Constants';

class PortalHeader extends Component {

    constructor(props) {
        super(props)
    }

    renderAuthindicatedHeaders = () => {
       
        const { 
            summaryConfig, accountSummary, 
            menuReference, includeHeader, 
            apiTriggerConfig, currentUserData 
        } = this.props
        //Fetching currentUserData is used to invoke render method again
        if (!isEmptyOrSpaces(getItemFromBrowserStorage(TOKEN))) {
            return(
                <>
                    <DataComponent apiTriggerConfig={apiTriggerConfig} currentUserData={currentUserData}/>
                    { /*summaryConfig && includeHeader!=false && <HeaderMenu menuReference={menuReference} />*/ }
                    { /*accountSummary && includeHeader!=false && <QuickAccessMenu />*/}
                </>
            )
        }
    }

    render() {
        return (
            <header className="header">
                <ROUTER_CONFIG.header.component includeHeader={this.props.includeHeader}/>
                {
                    this.renderAuthindicatedHeaders()
                }
            </header>
        );
    }
}

function mapStateToProps(state) {
    return {
        accountSummary: state.accountSummaryReducer.accountSummary,
        summaryConfig: state.configurationReducer[CONFIG_SECTION_SUMMARY],
        menuReference: state.menuReferenceReducer.payload,
        currentUserData: state.currentLoginUserDataReducer.currentUserData
    }
}

export default withSuspense()(connect(mapStateToProps, {})(withTranslation()(PortalHeader)));