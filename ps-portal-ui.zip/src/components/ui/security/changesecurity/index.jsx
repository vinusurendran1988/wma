import React from 'react';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { withSuspense } from '../../../common/utils';
import { SECURITY_QUESTION_ATTRIBUTE_KEY, SECURITY_ANSWER_ATTRIBUTE_KEY, CANCEL_UPDATE_SECURITY_QUESTION_BUTTON, UPDATE_SECURITY_QUESTION_BUTTON } from '../Constants';
import { updateSecurityQuestions } from './actions';
import FieldBank from '../../../common/components/fields/FieldBank';
import Button from '../../../common/components/fieldbank/Button';

/**
 * Component that allows to change security questions
 * @author Alan Kuriakose
 */
class ChangeSecurityQuestion extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            resetSecurityQuestions: false,
            pin: '',
            errorIndices: [],
            password: ''
        }
        this.securityQuestionAnswerMapping = [];
        this.handleChange = this.handleChange.bind(this)
    }

    updateSecurityQuestions() {
        if(this.areFieldsValid() === false) {
            return;
        }
        const { securityQuestionAttribute, securityAnswerAttribute, setCustomMessages } = this.props;
        const clearFields = () => {
            this.setState({
                password: '',
                pin: ''
            })
        }
        const { password, pin } = this.state;
        if(JSON.stringify(this.securityQuestionAnswerMapping) !== '[]') {
            const dynamicAttributes = [];
            this.securityQuestionAnswerMapping.forEach(mapping=>{
                const securityQuestion = JSON.parse(JSON.stringify(securityQuestionAttribute));
                const securityAnswer = JSON.parse(JSON.stringify(securityAnswerAttribute));
                securityQuestion.attributeValue = mapping.question;
                securityAnswer.attributeValue = mapping.answer;
                securityQuestion.groupInstanceID = mapping.groupInstanceID;
                securityAnswer.groupInstanceID = mapping.groupInstanceID;
                dynamicAttributes.push(securityQuestion, securityAnswer);
            })
            this.props.updateSecurityQuestions({
                pin,
                password,
                dynamicAttributes,
                setCustomMessages,
                clearFields,
            }, UPDATE_SECURITY_QUESTION_BUTTON);
        }
    }

    resetErrors() {
        this.props.uiConfig.fields.forEach((field)=>{
            if(field.validation) {
                const element = document.getElementById(field.id);
                if(field.name !== 'securityQuestions' && element) {
                    element.classList.remove('is-invalid');
                }
            }
        })
        this.setState({
            errorIndices: []
        })
        this.props.setCustomMessages({
            type: '',
            messages: []
        })
    }

    areFieldsValid() {
        let areValid = true;
        const errorMessages = []
        const { setCustomMessages } = this.props;
        this.props.uiConfig.fields.forEach((field)=>{
            if(field.validation) {
                const element = document.getElementById(field.id);
                if(field.name === 'securityQuestions') {
                    // validate security questions
                    const errorIndices = [];
                    this.securityQuestionAnswerMapping.forEach((mapping, index)=>{
                        if(!this.isValid(field.validation.pattern, mapping.answer)) {
                            errorIndices.push(index);
                            errorMessages.push(field.validation.customMessageId)
                            areValid = false;
                        }
                    })
                    this.setState({
                        errorIndices
                    })
                }else if(element) {
                    // validate normal fields
                    const value = this.state[field.name];
                    if(!this.isValid(field.validation.pattern, value)) {
                        element.classList.add('is-invalid');
                        errorMessages.push(field.validation.customMessageId);
                        areValid = false;
                    }
                }
            }
        })
        setCustomMessages({
            type: 'danger',
            messages: errorMessages
        })
        return areValid;
    }

    isValid(regex, value) {
        return new RegExp(regex).test(String(value));
    }

    handleChange(fieldName, event) {
        const value = event.target.value
        this.resetErrors();
        this.setState({
            [fieldName]: value
        })
    }

    render() {
        const { uiConfig, t, config, savedQuestionAnswerMapping, type, filterType, securityQuestionAttribute } = this.props
        const { resetSecurityQuestions, errorIndices, password } = this.state;
        const numberOfSecurityQuestions = getValue(config, ['count'], 0);
        const additionalSecurityEnabled = getValue(config, ['additionalSecurityEnabled'], false);
        const askPassword = additionalSecurityEnabled && getValue(config, ['securityType', 'password', 'enabled'], false);
        const askPin = additionalSecurityEnabled && getValue(config, ['securityType', 'pin', 'enabled'], false);
        return (
            <div className="pageClassChangeSecurity">
                <div className="form-row">
                {
                    uiConfig.fields.map((field, index)=>{
                        if(!field.visibility || (field.name === 'password' && !askPassword) || (field.name === 'pin' && !askPin)) {
                            return null;
                        }
                        return(
                            <FieldBank
                                idx={index}
                                key={index}
                                field={field}
                                count={numberOfSecurityQuestions}
                                manageSecurityQuestions={securityQuestions=>{
                                    this.resetErrors();
                                    this.securityQuestionAnswerMapping = securityQuestions;
                                }}
                                errorIndices={errorIndices}
                                values={savedQuestionAnswerMapping}
                                resetForm={resetSecurityQuestions}
                                handleChange={this.handleChange}
                                t={t}
                                securityQuestionType={type}
                                securityQuestionFilterType={filterType}
                                securityQuestionFilterValue={getValue(securityQuestionAttribute, ['attributeCode'])}
                                data={{
                                    password
                                }}
                                className = {field.className?field.className:"col-lg-4"}
                            />
                        )
                    })
                }
                    <div className="col-12 text-right btn-wrap btn-wrap--grp">
                        <Button
                            className="btn btn-secondary" 
                            handleOnClick={() => {
                                this.setState({
                                    resetSecurityQuestions: !resetSecurityQuestions,
                                    pin: '',
                                    password: ''
                                })
                                this.securityQuestionAnswerMapping = [];
                                this.resetErrors();
                            }} 
                            id={CANCEL_UPDATE_SECURITY_QUESTION_BUTTON} 
                            data-test="update-security-questions-cancel-button" 
                            label={t("profile.cancelBtn")} />
                        <Button 
                            className="btn btn-primary" 
                            handleOnClick={() => this.updateSecurityQuestions()} 
                            id={UPDATE_SECURITY_QUESTION_BUTTON} 
                            data-test="update-security-questions-update-button" 
                            label={t("profile.updateBtn")} />
                    </div>
                </div>
            </div>
        )
    }
}

ChangeSecurityQuestion.defaultProps = {
    config: {},
    dynamicAttributes: []
}

const getValue = (data, path=[], defaultValue='') => {
    try {
        path.forEach(location=>data = data[location]);
        return data;
    } catch(error) {
        return defaultValue;
    }
}

const mapStateToProps = (state, props) => {
    const configDynamicAttributes = props.dynamicAttributes;
    const securityQuestionAttribute = configDynamicAttributes.find(attribute=>attribute.attributeKey === SECURITY_QUESTION_ATTRIBUTE_KEY);
    const securityAnswerAttribute = configDynamicAttributes.find(attribute=>attribute.attributeKey === SECURITY_ANSWER_ATTRIBUTE_KEY);
    const securityQuestionAttributeCode = getValue(securityQuestionAttribute, ['attributeCode']);
    const securityAnswerAttributeCode = getValue(securityAnswerAttribute, ['attributeCode']);
    const dynamicAttributes = getValue(state, ['profile', 'profileData', 'object', 'memberAccount', 'memberDynamicAttributes'], [])
    // const savedSecurityQuestions = dynamicAttributes.filter(attribute=>[securityQuestionAttributeCode, securityAnswerAttributeCode].includes(attribute.attributeCode))
    const savedQuestionAnswerMapping = {}
    dynamicAttributes.forEach(attribute=>{
        if([securityQuestionAttributeCode, securityAnswerAttributeCode].includes(attribute.attributeCode)) {
            if(savedQuestionAnswerMapping[attribute.groupInstanceID] === undefined) {
                savedQuestionAnswerMapping[attribute.groupInstanceID] = {
                    groupInstanceID: attribute.groupInstanceID
                };
            }
            if(securityQuestionAttributeCode === attribute.attributeCode) {
                savedQuestionAnswerMapping[attribute.groupInstanceID].question = attribute.attributeValue;
            } else {
                savedQuestionAnswerMapping[attribute.groupInstanceID].answer = attribute.attributeValue;
            }
        }
    })
    return({
        savedQuestionAnswerMapping: Object.values(savedQuestionAnswerMapping),
        securityQuestionAttribute,
        securityAnswerAttribute
    })
}

const mapDispatchToProps = dispatch => {
    return {
        updateSecurityQuestions: (params, id) => dispatch(updateSecurityQuestions(params, id))
    }
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(ChangeSecurityQuestion)))
