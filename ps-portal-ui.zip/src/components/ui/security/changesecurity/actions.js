import { _URL_UPDATE_SECURITY_QUESTIONS } from '../../../common/config/config';
import { doPost } from '../../../common/utils/api';
import {
    getItemFromBrowserStorage,
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO
} from '../../../common/utils/storage.utils';
import { getApiErrorMessage } from '../../../common/utils';
import { stopButtonSpinner, startButtonSpinner } from '../../../common/components/fieldbank/loader/action';

/**
 * Function to update security questions of user
 * @param {object} params - request parameters for update security questions request
 * @author Alan Kuriakose
 */
export const updateSecurityQuestions = (params, id) => {
    const { password, pin, dynamicAttributes, setCustomMessages, clearFields } = params;
    const requestBody = {
        object: {
            companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
            programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
            membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
            password,
            pin,
            dynamicAttributes
        }
    }
    return dispatch => {
        dispatch(startButtonSpinner(id, "updateSecurityQuestions"))
        return doPost(_URL_UPDATE_SECURITY_QUESTIONS, requestBody)
            .then(response => {
                dispatch(stopButtonSpinner(id, "updateSecurityQuestions"))
                setCustomMessages({
                    type: 'success',
                    messages: ['security.changeSecurityQuestion.update_success_message']
                });
                clearFields();
            }).catch(error => {
                dispatch(stopButtonSpinner(id, "updateSecurityQuestions"))
                console.log(error);
                setCustomMessages({
                    type: 'danger',
                    messages: getApiErrorMessage(error.response.data.error)
                })
            })
    }
}