import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withTranslation } from 'react-i18next';
import { withSuspense, setFieldInvalid, setFieldValid } from '../../../common/utils';
import { changePinAction } from './actions';
import { connect } from 'react-redux';
import {
    getItemFromBrowserStorage,
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
    BROWSER_STORAGE_KEY_COMPANY_CODE, 
    BROWSER_STORAGE_KEY_PROGRAM_CODE
} from '../../../common/utils/storage.utils';
import FieldBank from '../../../common/components/fields/FieldBank';
import { resetError } from '../../../common/middleware/redux/commonAction'
import { FIELD_INVALID } from '../../enrolment/Constants';
import { SECURITY_QUESTION_ATTRIBUTE_KEY, SECURITY_ANSWER_ATTRIBUTE_KEY, UPDATE_PIN_BUTTON, CANCEL_UPDATE_PIN_BUTTON } from '../Constants';
import { clearErrorMarkings } from '../utils';
import Button from '../../../common/components/fieldbank/Button';

/**
 * @class ChangePin
 * @description Component that allows the user to change his/her memmber PIN.
 * @author Ajmal Aliyar
 */
class ChangePin extends Component {

    constructor(props) {
        super(props);
        this.state = {
            data: {},
            errorIndices: [],
            resetForm: false
        };
        this.handleNumberInput = this.handleNumberInput.bind(this);
        this.manageSecurityQuestions = this.manageSecurityQuestions.bind(this)
    }

    /**
     * Handles when and what to be displayed as messages on the top of the page.
     * @param {*} prevProps 
     * @param {*} prevState 
     * @author Ajmal Aliyar
     */
    componentDidUpdate(prevProps) {
        if (prevProps.changedPin != this.props.changedPin && Object.keys(this.props.changedPin).length > 0) {
            this.props.setCustomMessages({
                type: "success",
                messages: ['security.changePin.change_pin_success_message']
            })
            this.setState({
                data: {},
                resetForm: !this.state.resetForm
            })
        }

        if (this.props.errors && prevProps.errors != this.props.errors && this.props.errors.length > 0) {
            this.props.setCustomMessages({
                type: "danger",
                messages: this.props.errors
            }, false)
        }
    }

    /**
     * @description Method to handle the events created when use makes changes in the provided fields in the component.
     * It does the following tasks:
     *  1.  Clear the success/error messages when an input change occurs
     *  2.  Mark a field as valid if that was previously invalid and an onChange event occured.
     * @param {*} field name of the field which is being edited (from the configuration)
     * @param {*} event 
     * @author Ajmal Aliyar
     */
    handleNumberInput(field, event) {
        let { data } = this.state
        data[field] = event.target.value
        this.props.setCustomMessages({ type: "", messages: [] })
        this.props.resetError()
        if (event.target.classList.value.includes(FIELD_INVALID)) {
            setFieldValid(event.target.id)
        }
        this.setState({
            data
        })
    }

    /**
     * @description Resets the component
     *  1.  Clears all the error messages
     *  2.  CLears the clears all the fields in the form
     * @author Ajmal Aliyar
     */
    resetError() {
        this.props.setCustomMessages({ type: "", messages: [] })
        this.props.resetError();
        clearErrorMarkings(this.props.uiConfig.fields);
        this.setState({
            data: {},
            resetForm: !this.state.resetForm
        })
    }

    /**
     * @description manageSecurityQuestions is the method which handles callbacks from SecurityQuestions.
     * It will set the state[data] with the present questions and the answers entered by the user.
     * @param {*} securityQuestions Objects received from  the SecurityQuestions component.
     * @author Ajmal Aliyar
     */
    manageSecurityQuestions(securityQuestions) {
        let { data } = this.state
        let securityQns = []
        securityQuestions.map((securityQuestion, idx) => {
            securityQns.push(securityQuestion)
        })
        if (securityQns.length > 0) {
            data["securityQuestions"] = securityQns
            this.setState({
                data
            })
        }
    }

    /**
     * @description Evaluates regex pattern for value.
     * @param {*} pattern 
     * @param {*} value 
     * @returns boolean
     * @author Ajmal Aliyar
     */
    isPatternMatch(pattern, value) {
        const regex = new RegExp(pattern)
        return regex.test(value)
    }

    /**
     * @description Validates all the user inputs according to validtion provided in the configuration.
     *  1.  If the field is of type "security" :
     *          Pattern match for answers provided.
     *  2. For other types of fields, validates with the corresponding Regex expressions for each field.
     * 
     * If any errors are encountered, that corresponding field id is stored to show the warning '!' as well as the error message is added to errorMessages list.
     *  
     * @param {*} errorMessages 
     * @author Ajmal Aliyar
     */
    validateRequest(errorMessages) {
        const { uiConfig } = this.props
        if (uiConfig.fields) {
            uiConfig.fields.map((field, idx) => {
                if (field.visibility && field.validation) {
                    let value = this.state.data[field.name]
                    if (field.type == "security") {
                        // Validating the security questions
                        value = (value == undefined) ? [{ "question": "", "answer": "" }] : value
                        let errors = []
                        value.forEach((val, index) => {
                            // Collect the invalid questions and unmatched regex answers.
                            if (val.question == "" || !this.isPatternMatch(field.validation.pattern, val.answer)) {
                                errors.push(index)
                            }
                            // Store the error index to state, to pass to the securityQuestions component.
                            this.setState({
                                errorIndices: errors
                            })
                        })
                        // Check if any error present in the security questions section.
                        if (errors.length > 0)
                            errorMessages.push(field.validation.customMessageId)
                    } else {
                        // Validating fields other than the security question.
                        value = (value == undefined) ? "" : value
                        let foundError = false
                        // Validation based on the regex pattern specified against each field from the json configuration.
                        field.validation.forEach((validation) => {
                            let additionalPattern = validation.pattern
                            // Validate the present field based on the value of another field using the regex (>,<,==,!=)
                            // For example, to validate the oldPassword and newPassword are not same.
                            if (validation.field) {
                                // Constructing the regex pattern with multiple fields, if present
                                // For example,
                                //  Pattern = "//^((?![firstName]|[lasttName]).)*$//gi".
                                //  After this loop, the pattern will look like: "//^((?!IBS|123).)*$//gi"
                                validation.field.forEach((additionalField) => {
                                    additionalPattern = additionalPattern.replace('[' + additionalField + ']', this.state.data[additionalField])
                                })
                            }
                            if (!this.isPatternMatch(additionalPattern, value)) {
                                foundError = true
                                errorMessages.push(validation.customMessageId)
                            }
                        })
                        if (foundError) {
                            setFieldInvalid(field.id)
                        } else {
                            setFieldValid(field.id)
                        }
                    }
                }
            })
        }
    }

    /**
     * @description Does the steps to fire a changePin request.
     *  1.  invoke validation of fields.
     *  2.  If errors occur in validation, error messages are loaded with 'danger' type.
     *  3.  Else, create the request payload and fire the changePin API.
     * @author Ajmal Aliyar
     */
    attemptPinUpdate() {
        let messages = []
        this.validateRequest(messages)
        if (messages.length > 0) {
            this.props.setCustomMessages({
                type: "danger",
                messages
            })
        } else {
            const payload = this.createPayload()
            this.props.changePinAction(payload, UPDATE_PIN_BUTTON)
        }
    }

    /**
     * @description Creates the request payload for change PIN.
     * Dynamic attribute objects are also created with the help of configuration and the SecurityQuestions generated outputs.
     * @returns payload
     * @author Ajmal Aliyar
     */
    createPayload() {

        const payload = {
            "object": {
                "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                "membershipNumber": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                "oldPin": this.state.data.oldPin,
                "newPin": this.state.data.confirmPin,
            }
        }

        let { object } = payload
        let { dynamicAttributes } = this.props

        if (dynamicAttributes) {
            //Handle the 'dynamicAttributes' if present in the json configuration.
            object["dynamicAttributes"] = []
            let securityDynamicAttributes = []
            dynamicAttributes.forEach((dynamicAttribute) => {
                if (dynamicAttribute.attributeKey
                    && [SECURITY_QUESTION_ATTRIBUTE_KEY, SECURITY_ANSWER_ATTRIBUTE_KEY]
                        .includes(dynamicAttribute.attributeKey)) {
                    // Select the dynamic attibutes with attributeKey as SQ, SA
                    securityDynamicAttributes.push(dynamicAttribute)
                } else if (dynamicAttribute.attributeMapping) {
                    // Handle the dynamicAttributes other than SQ, SA.
                    // Map the values from this.state.data with the respective attributeMapping.
                    dynamicAttribute.attributeValue = this.state.data[dynamicAttribute.attributeMapping]
                    object["dynamicAttributes"].push(dynamicAttribute)
                }
            })

            // Mapping and constructing the data for SQ, SA.
            if (securityDynamicAttributes.length > 0) {
                securityDynamicAttributes.forEach((securityQn) => {
                    this.state.data["securityQuestions"].forEach((userInput) => {
                        if (securityQn.attributeKey == SECURITY_QUESTION_ATTRIBUTE_KEY) {
                            securityQn["attributeValue"] = userInput.question

                        } else if (securityQn.attributeKey == SECURITY_ANSWER_ATTRIBUTE_KEY) {
                            securityQn["attributeValue"] = userInput.answer
                        }
                        securityQn["groupInstanceID"] = userInput.groupInstanceID
                        object["dynamicAttributes"].push(JSON.parse(JSON.stringify(securityQn)))
                    })
                })
            }
        }
        return payload
    }

    /**
     * @description Renders the change PIN section
     * @author Ajmal Aliyar
     */
    render() {
        const { uiConfig, t } = this.props
        return (
            <div className="pageClassChangePin" data-test="ChangePinComponent">
                <div className="form-row">
                    {
                        uiConfig.fields && uiConfig.fields.map((field, idx) => {
                            if (field.visibility) {
                                let props = { ...this.props }
                                props[field.name] = this.state.data[field.name] ? this.state.data[field.name] : ""
                                props.field = field
                                props.idx = idx
                                props.key = idx
                                props.handleNumberInput = this.handleNumberInput
                                props.manageSecurityQuestions = this.manageSecurityQuestions
                                props.errorIndices = this.state.errorIndices
                                props.data=this.state.data
                                if (props.config && props.config.additionalSecurityEnabled &&
                                    props.config.securityType.securityQuestion &&
                                    props.config.securityType.securityQuestion.enabled &&
                                    props.config.securityType.securityQuestion.count) {
                                    props.count = props.config.securityType.securityQuestion.count
                                    props.securityQuestionType = props.type
                                    props.securityQuestionFilterType = props.filterType
                                    props.securityQuestionFilterValue =  props.dynamicAttributes.find(attribute=>attribute.attributeKey === SECURITY_QUESTION_ATTRIBUTE_KEY).attributeCode
                                }
                                props.resetForm = this.state.resetForm
                                props.className = field.className?field.className:"col-lg-4"
                                return <FieldBank {...props} />
                            }
                        })
                    }
                    <div className="col-12 text-right btn-wrap btn-wrap--grp">
                        <Button
                            className="btn btn-secondary" 
                            handleOnClick={() => this.resetError()} 
                            id={CANCEL_UPDATE_PIN_BUTTON} 
                            data-test="laterButton" 
                            label={t("security.changePin.cancelBtn")} />
                        <Button 
                            className="btn btn-primary" 
                            handleOnClick={() => this.attemptPinUpdate()} 
                            id={UPDATE_PIN_BUTTON} 
                            data-test="updateButton" 
                            label={t("security.changePin.updateBtn")} />
                    </div>
                </div>
            </div>
        );
    }
}

ChangePin.propTypes = {
    config: PropTypes.any.isRequired,
    dynamicAttributes: PropTypes.any.isRequired,
    uiConfig: PropTypes.any.isRequired,
    setCustomMessages: PropTypes.func.isRequired
};

function mapStateToProps(state) {
    return {
        changedPin: state.changePinReducer.changedPin,
        errors: state.commonErrorReducer.error
    }
}
const mapDispatchToProps = {
    changePinAction,
    resetError
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(ChangePin)))
