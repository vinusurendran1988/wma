import React, { Component } from 'react'
import { connect } from 'react-redux';
import { withSuspense } from '../../../components/common/utils';
import { withTranslation } from 'react-i18next';
import ChangePassword from './changepassword'

import {
    resetError,
    fetchConfiguration
} from '../../common/middleware/redux/commonAction'
import { CONFIG_SECTION_SECURITY } from '../../common/utils/Constants';
import ChangeSecurityQuestion from './changesecurity';
import ChangePin from './changepin'
import CustomMessage from '../../common/components/custommessage';

/**
 * SecurityComponent class.
 * @description Security Tab in Profile page.
 * @author Somdas M
 */

class SecurityComponent extends Component {

    constructor(props){
        super(props)
        this.state={
            customeMessage:{
                type:"",
                messages:[]
            },
            canTranslate: true
        }
        this.setCustomMessages = this.setCustomMessages.bind(this)
    }

    componentDidMount(){
        this.props.resetError()
        if (!this.props.config) {
            this.props.fetchConfiguration(CONFIG_SECTION_SECURITY)
        }
    }

    /**
     * Function to set the success/error message to be displayed
     * @author Somdas M
     * @param {object} customeMessage - Object {type: "success/danger", errorMessages:[]}
     * @param {string} canTranslate - If i18n translation is required or not.
     */
    setCustomMessages(customeMessage, canTranslate=true){
        this.setState({
            customeMessage,
            canTranslate
        })
    }

    render() {
        const { config, t } = this.props;
        const type = config && config.ui && config.ui.type;
        const filterType = config && config.ui && config.ui.filterType;
        return (
            <>
                <CustomMessage type={this.state.customeMessage.type} message={this.state.customeMessage.messages} canTranslate={this.state.canTranslate}/>
                <div className="accordion" id="accordionExample">
                    {
                        config && config.ui && config.ui.layout &&
                        config.ui.layout.order.map((layout, idx) => {
                            const uiConfig = config.ui.layout.elements[layout]
                            const dynamicAttributes = config.dynamicAttributes[layout]
                            const componentConfig = config[layout]
                            return < div className="card" key={idx}>
                                <div className="card-header" id="headingOne">
                                    <h2 className="mb-0">
                                        <button className="btn btn-link btn-block text-left" type="button" data-toggle="collapse"
                                            data-target={`#collapse${idx}`} aria-expanded="true" aria-controls={`collapse${idx}`} onClick={()=>{
                                                this.setCustomMessages([]);
                                            }}>
                                            {t(`security.${layout}.title`)}
                                        </button>
                                    </h2>
                                </div>

                                <div id={`collapse${idx}`} className={`collapse ${idx==0?"show":""}`} aria-labelledby="headingOne"
                                    data-parent="#accordionExample">
                                    <div className="card-body">
                                        {
                                            {
                                                "changePassword": <ChangePassword 
                                                                    config={componentConfig} 
                                                                    dynamicAttributes={dynamicAttributes} 
                                                                    uiConfig={uiConfig} 
                                                                    setCustomMessages={this.setCustomMessages}
                                                                    type={type}
                                                                    filterType={filterType}
                                                                />,
                                                "changePin": <ChangePin 
                                                                config={componentConfig} 
                                                                dynamicAttributes={dynamicAttributes} 
                                                                uiConfig={uiConfig} 
                                                                setCustomMessages={this.setCustomMessages}
                                                                type={type}
                                                                filterType={filterType}
                                                            />,
                                                "changeSecurityQuestion": <ChangeSecurityQuestion 
                                                                            config={componentConfig} 
                                                                            dynamicAttributes={dynamicAttributes} 
                                                                            uiConfig={uiConfig} 
                                                                            setCustomMessages={this.setCustomMessages}
                                                                            type={type}
                                                                            filterType={filterType}
                                                                        />,
                                            }[layout]
                                        }
                                    </div>
                                </div>
                            </div>
                            
                        })
                    }
                    </div>
            </>

        )
    }
}

const mapStateToProps = (state) => {
    return {
        config: state.configurationReducer.security
    }
}

const mapDispatchToProps = {
    resetError,
    fetchConfiguration
}
export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(SecurityComponent)));