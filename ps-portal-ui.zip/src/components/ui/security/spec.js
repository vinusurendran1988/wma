import React from 'react';
import {
    findByTestAttr,
    mockServiceResponse
} from '../../common/testUtils';
import { testStore } from '../../common/utils';
import moxios from 'moxios';
import { mount } from 'enzyme';
import ReactTestUtils from 'react-dom/test-utils';
import SecurityComponent from './index';
import { Provider } from 'react-redux';
import {
    SESSION_STORAGE_MEMBERSHIP_NO,
    SESSION_STORAGE_PROGRAM_CODE,
    SESSION_STORAGE_COMPANY_CODE
} from '../../common/utils/Constants';
import { fetchConfiguration } from '../../common/middleware/redux/commonAction';
import { CONFIG_SECTION_SECURITY } from '../../common/utils/Constants';
import ChangePin from './changepin/index';
import ChangePassword from './changepassword/index';
import { fetchSecurityQuestions } from './securityquestions/actions';
import { changePinAction } from './changepin/actions';
import { changePassword } from './changepassword/actions';
import ChangeSecurityQuestion from './changesecurity';
import thunk from 'redux-thunk';
import configureMockStore from 'redux-mock-store';
import { updateSecurityQuestions } from './changeSecurity/actions';

var store = testStore({})
let rootComponent;
let securityComponent;
const middlewares = [thunk];
const mockStore = configureMockStore(middlewares);

const setUp = (props = {}) => {
    window.sessionStorage.setItem(SESSION_STORAGE_COMPANY_CODE, 'IBS')
    window.sessionStorage.setItem(SESSION_STORAGE_PROGRAM_CODE, 'PRG14')
    localStorage.setItem(SESSION_STORAGE_MEMBERSHIP_NO, 'IM0008010415')
    rootComponent = mount(
        <Provider store={store} >
            <SecurityComponent {...props} />
        </Provider>
    );
    securityComponent = rootComponent.find(SecurityComponent)
};

/**
 * Test for Security component
 * @author Ajmal Aliyar
 */
describe("Security Component", () => {

    const responseSecurityConfig = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "section": "security", "companyCode": "IBS", "programCode": "PRG14", "changePassword": { "additionalSecurityEnabled": true, "securityType": { "pin": { "enabled": false }, "securityQuestion": { "enabled": true, "count": 1 } } }, "changePin": { "additionalSecurityEnabled": true, "securityType": { "password": { "enabled": false }, "securityQuestion": { "enabled": true, "count": 1 } } }, "changeSecurityQuestion": { "count": 1, "additionalSecurityEnabled": true, "securityType": { "pin": { "enabled": false }, "password": { "enabled": true } } }, "dynamicAttributes": { "changePin": [{ "attributeCode": "18", "attributeName": "Secret Question", "attributeValue": "", "type": "P", "attributeKey": "SQ" }, { "attributeCode": "19", "attributeName": "Secret Answer", "attributeValue": "", "type": "P", "attributeKey": "SA" }], "changePassword": [{ "attributeCode": "18", "attributeName": "Secret Question", "attributeValue": "", "type": "P", "attributeKey": "SQ" }, { "attributeCode": "19", "attributeName": "Secret Answer", "attributeValue": "", "type": "P", "attributeKey": "SA" }], "changeSecurityQuestion": [{ "attributeCode": "18", "attributeName": "Secret Question", "attributeValue": "", "type": "P", "attributeKey": "SQ" }, { "attributeCode": "19", "attributeName": "Secret Answer", "attributeValue": "", "type": "P", "attributeKey": "SA" }] }, "ui": { "layout": { "order": ["changePassword", "changePin", "changeSecurityQuestion"], "elements": { "changePassword": { "fields": [{ "name": "oldPassword", "id": "id-security-pwd-old-password", "visibility": true, "isRequired": true, "className": "col-lg-4 col-md-6", "validation": [{ "pattern": "^([a-zA-Z0-9!@#\\$%\\^\\&*\\)\\(+=._-~])+$", "customMessageId": "enrolment.old_password_msg" }] }, { "name": "newPassword", "id": "id-security-pwd-new-password", "visibility": true, "isRequired": true, "className": "col-lg-4 col-md-6", "validation": [{ "pattern": "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$", "customMessageId": "enrolment.form.password" }, { "pattern": "^((?![oldPassword]).)*$", "field": ["oldPassword"], "customMessageId": "enrolment.passwords_cannot_be_same" }] }, { "name": "confirmPassword", "id": "id-security-pwd-confirm-password", "visibility": true, "isRequired": true, "className": "col-lg-4 col-md-6", "validation": [{ "pattern": "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$", "customMessageId": "enrolment.confirm_password_msg" }, { "pattern": "^[newPassword]$", "field": ["newPassword"], "customMessageId": "enrolment.passwords_need_to_be_same" }] }, { "name": "memberPin", "id": "id-security-pwd-pin", "className": "col-lg-4 col-md-6", "visibility": false, "isRequired": true, "validation": { "pattern": "^[0-9]{4}$", "customMessageId": "enrolment.form.memberPin" } }, { "name": "securityQuestions", "id": "id-security-pwd-security-questions", "visibility": true, "className": "col-lg-12", "isRequired": true, "type": "security", "validation": { "pattern": "^(?=.*[a-zA-Z0-9])", "customMessageId": "enrolment.security_question.error.message" } }] }, "changePin": { "fields": [{ "name": "oldPin", "id": "id-security-pin-old-pin", "visibility": true, "isRequired": true, "className": "col-lg-4 col-md-6", "validation": [{ "pattern": "^[0-9]{4}$", "customMessageId": "enrolment.form.memberPin" }] }, { "name": "newPin", "id": "id-security-pin-new-pin", "visibility": true, "isRequired": true, "className": "col-lg-4 col-md-6", "validation": [{ "pattern": "^[0-9]{4}$", "customMessageId": "enrolment.form.memberPin" }, { "pattern": "^(?![oldPin]$).*$", "field": ["oldPin"], "customMessageId": "enrolment.change_pin_old_and_new_pins_cannot_be_same_message" }] }, { "name": "confirmPin", "id": "id-security-pwd-confirm-pin", "visibility": true, "isRequired": true, "className": "col-lg-4 col-md-6", "validation": [{ "pattern": "^[newPin]$", "field": ["newPin"], "customMessageId": "security.changePin.change_pin_new_and_confirm_pins_need_to_be_same_message" }] }, { "name": "securityQuestions", "type": "security", "id": "id-security-pin-security-questions", "visibility": true, "isRequired": true, "className": "col-lg-12", "validation": { "pattern": "^(?=.*[a-zA-Z0-9])", "customMessageId": "enrolment.security_question.error.message" } }] }, "changeSecurityQuestion": { "fields": [{ "name": "securityQuestions", "id": "id-security-questions-security-questions", "visibility": true, "isRequired": true, "validation": { "pattern": "^(?=.*[a-zA-Z0-9])", "customMessageId": "enrolment.form.securityQuestion" } }, { "name": "pin", "id": "id-security-questions-pin", "visibility": false, "isRequired": true, "validation": { "pattern": "^[0-9]{4}$", "customMessageId": "enrolment.form.memberPin" } }, { "name": "password", "id": "id-security-questions-password", "visibility": true, "isRequired": true, "validation": { "pattern": "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$", "customMessageId": "enrolment.form.password" } }] } } } } } }
    const responseAdditionalDetails = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "companyCode": "IBS", "programCode": "PRG14", "memberPreferences": [], "memberDynamicAttributes": [{ "attributeCode": "18", "attributeName": "Secret Question", "description": "Secret Question", "mandatory": false, "fieldType": "STRING", "dataType": "ALPHANUMERIC", "displayOrder": 24, "inputType": "B", "type": "M", "attributeInputOption": [{ "optionCode": "MN", "optionName": "Mother's Name", "sequenceNumber": 1, "defaultFlag": false }, { "optionCode": "WD", "optionName": "Anniversary Year", "sequenceNumber": 2, "defaultFlag": false }] }] } }

    /**
     * Calls two APIs 
     *  1.  security configuration 
     *  2.  fetch security questions (additional details)
     * @author Ajmal Aliyar
     */
    beforeEach(() => {
        moxios.install()
        setUp({})

        //Security configuration API call
        mockServiceResponse(responseSecurityConfig, 200)
        return store.dispatch(
            fetchConfiguration(CONFIG_SECTION_SECURITY)
        ).then(() => {
            rootComponent.update()
            expect(store.getState().configurationReducer.security).toBe(responseSecurityConfig.object)
            //Additional details API call : for security question fetching questions
            mockServiceResponse(responseAdditionalDetails, 200)
            return store.dispatch(
                fetchSecurityQuestions({ type: "", filterType: "", filterValue: "" })
            ).then(() => {
                rootComponent.update()

            })
        })
    })
    afterEach(() => {
        moxios.uninstall()
    })

    /**
     * Test for ChangePin component
     * @author Ajmal Aliyar
     */
    describe("ChangePin Component", () => {
        let changePinComponent
        let oldPinField
        let newPinField
        let confirmPinField
        let securityQNQuestionField
        let securityQNAnswerField
        let updateButton
        let laterButton

        beforeEach(() => {
            moxios.install()
        })

        afterEach(() => {
            moxios.uninstall()
        })

        /**
         * Happy flow for changing PIN
         * @author Ajmal Aliyar
         */
        test("success", () => {

            const responseChangePinSuccess = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "status": true } }

            const oldPinValue = "1234"
            const newPinValue = "4321"
            const confirmPinValue = "4321"
            const secQuestionValue = "MN"
            const secQnAnswerValue = "mother"

            changePinComponent = rootComponent.find(ChangePin)

            oldPinField = findByTestAttr(changePinComponent, "oldPin")
            oldPinField.prop('onChange')({ target: { value: oldPinValue, classList: { value: [] } } })
            rootComponent.update()

            newPinField = findByTestAttr(changePinComponent, "newPin")
            newPinField.prop('onChange')({ target: { value: newPinValue, classList: { value: [] } } })
            rootComponent.update()

            confirmPinField = findByTestAttr(changePinComponent, "confirmPin")
            confirmPinField.prop('onChange')({ target: { value: confirmPinValue, classList: { value: [] } } })
            rootComponent.update()

            securityQNQuestionField = findByTestAttr(changePinComponent, "securityQuestion_question_0")
            securityQNQuestionField.prop('onChange')({ target: { value: secQuestionValue, selectedIndex: 1 } })
            rootComponent.update()

            securityQNAnswerField = findByTestAttr(changePinComponent, "securityQuestion_answer_0")
            securityQNAnswerField.prop('onChange')({ target: { value: secQnAnswerValue } })
            rootComponent.update()

            updateButton = findByTestAttr(changePinComponent, "updateButton")
            updateButton.simulate('click')

            return ReactTestUtils.act(() => {
                mockServiceResponse(responseChangePinSuccess, 200)
                return store.dispatch(
                    changePinAction({})
                ).then(()=>{
                    laterButton = findByTestAttr(changePinComponent, "laterButton")
                    laterButton.simulate('click')
                    laterButton = findByTestAttr(changePinComponent, "updateButton")
                    laterButton.simulate('click')
                })
            })
        })
    })

    /**
     * Test for ChangePassword component
     * @author Ajmal Aliyar
     */
    describe("ChangePassword Component", () => {
        let changePasswordComponent
        let oldPasswordField
        let newPasswordField
        let confirmPasswordField
        let securityQNQuestionField
        let securityQNAnswerField
        let updateButton
        let laterButton

        beforeEach(() => {
            moxios.install()
        })

        afterEach(() => {
            moxios.uninstall()
        })

        /**
         * Happy flow for changing password.
         * @author Ajmal Aliyar
        */
        test("success", () => {

            const responseChangePasswordSuccess = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "status": true } }

            const oldPasswordValue = "Password@1234"
            const newPasswordValue = "9876#Boom!"
            const confirmPasswordValue = "9876#Boom!"
            const secQuestionValue = "MN"
            const secQnAnswerValue = "mother"

            changePasswordComponent = rootComponent.find(ChangePassword)

            oldPasswordField = findByTestAttr(changePasswordComponent, "oldPassword")
            oldPasswordField.prop('onChange')({ target: { value: oldPasswordValue, classList: { value: [] } } })
            rootComponent.update()

            newPasswordField = findByTestAttr(changePasswordComponent, "newPassword")
            newPasswordField.prop('onChange')({ target: { value: newPasswordValue, classList: { value: [] } } })
            rootComponent.update()

            confirmPasswordField = findByTestAttr(changePasswordComponent, "confirmPassword")
            confirmPasswordField.prop('onChange')({ target: { value: confirmPasswordValue, classList: { value: [] } } })
            rootComponent.update()

            securityQNQuestionField = findByTestAttr(changePasswordComponent, "securityQuestion_question_0")
            securityQNQuestionField.prop('onChange')({ target: { value: secQuestionValue, selectedIndex: 1 } })
            rootComponent.update()

            securityQNAnswerField = findByTestAttr(changePasswordComponent, "securityQuestion_answer_0")
            securityQNAnswerField.prop('onChange')({ target: { value: secQnAnswerValue } })
            rootComponent.update()

            updateButton = findByTestAttr(changePasswordComponent, "updateButton")
            updateButton.simulate('click')

            return ReactTestUtils.act(() => {
                mockServiceResponse(responseChangePasswordSuccess, 200)
                return store.dispatch(
                    changePassword({})
                ).then(()=>{
                    laterButton = findByTestAttr(changePasswordComponent, "laterButton")
                    laterButton.simulate('click')
                    laterButton = findByTestAttr(changePasswordComponent, "updateButton")
                    laterButton.simulate('click')
                })
            })
        })
    })

})

describe("Change security questions component", () =>{

    const dynamicAttributes = [
        {
            "attributeCode": "18",
            "attributeName": "Secret Question",
            "attributeValue": "",
            "type": "P",
            "attributeKey": "SQ"
        },
        {
            "attributeCode": "19",
            "attributeName": "Secret Answer",
            "attributeValue": "",
            "type": "P",
            "attributeKey": "SA"
        }
    ];

    const uiConfig = {
        "fields": [
            {
                "name": "securityQuestions",
                "id": "id-security-questions-security-questions",
                "visibility": true,
                "isRequired": true,
                "validation": {
                    "pattern": "^(?=.*[a-zA-Z0-9])",
                    "customMessageId": "security.changeSecurityQuestion.form.invalid_security_answer"
                }
            },
            {
                "name": "additionalSecurityInfo",
                "messageId": "security.changeSecurityQuestion.additional_security_info",
                "className": "col-sm-12",
                "visibility": true
            },
            {
                "name": "pin",
                "id": "id-security-questions-pin",
                "visibility": false,
                "isRequired": true,
                "validation": {
                    "pattern": "^[0-9]{4}$",
                    "customMessageId": "security.changeSecurityQuestion.form.invalid_pin"
                }
            },
            {
                "name": "password",
                "id": "id-security-questions-password",
                "visibility": true,
                "isRequired": true,
                "validation": {
                    "pattern": "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$",
                    "customMessageId": "enrolment.form.password"
                }
            }
        ]
    }

    const config = {
        "count": 1,
        "additionalSecurityEnabled": true,
        "securityType": {
            "pin": {
                "enabled": false
            },
            "password": {
                "enabled": true
            }
        }
    }

    const setSecurityQuestionsAction = {
        type: 'SET_MASTER_DATA',
        payload: {
          data: [
            {
              optionCode: 'MN',
              optionName: 'Mother\'s Name',
              sequenceNumber: 1,
              defaultFlag: false
            },
            {
              optionCode: 'WD',
              optionName: 'Anniversary Year',
              sequenceNumber: 2,
              defaultFlag: false
            }
          ],
          type: 'securityQuestions'
        }
      }
    
    const setProfileDataAction = {
        type: 'SET_PROFILE_DATA',
        payload: {
          object: {
            memberAccount: {
              companyCode: 'IBS',
              programCode: 'PRG14',
              membershipNumber: 'IM0008010632',
              accountStatus: 'A',
              enrolmentSource: 'W',
              enrolmentDate: '16-Sep-2020',
              extendToDay: '0',
              extendToMonth: '0',
              tier: 'BLU',
              tierFromDate: '17-Jul-2020',
              memberProfile: {
                membershipType: 'I',
                membershipStatus: 'A',
                individualInfo: {
                  memberNationality: 'BH',
                  preferredLanguage: 'EN',
                  preferredAddress: 'H',
                  preferredEmailAddress: 'H',
                  preferredPhoneNumber: 'HP',
                  title: 'MR',
                  givenName: 'Paul',
                  familyName: 'Gp',
                  secondName: 'L',
                  displayName: 'Paul GP',
                  initials: 'S',
                  gender: 'M',
                  maritalStatus: 'M',
                  dateOfBirth: '23-Oct-1990',
                  passportNumber: 'M0992353',
                  countryOfResidence: 'BH',
                  companyName: 'UnknownCmp',
                  memberContactInfos: [
                    {
                      addressType: 'H',
                      addressLine1: 'House no 70',
                      addressLine2: 'Block 319',
                      city: 'MA',
                      state: 'SF',
                      country: 'BH',
                      zipCode: '26814',
                      addressInvalid: false,
                      emailAddress: 'paul1876@gmail.com',
                      phoneISDCode: '+973',
                      phoneAreaCode: '1731',
                      phoneNumber: '161056',
                      mobileISDCode: '+242',
                      mobileAreaCode: '1731',
                      mobileNumber: '4267',
                      faxISDCode: '+993',
                      faxAreaCode: '1630',
                      faxNumber: '5678',
                      skypeID: 'paul.ge90e',
                      postalAddressStatus: 'V',
                      phoneNumberStatus: 'V',
                      mobileNumberStatus: 'V'
                    },
                    {
                      addressType: 'B',
                      addressLine1: 'House no 20',
                      addressLine2: 'Block 309',
                      city: 'MA',
                      state: 'SF',
                      country: 'BH',
                      zipCode: '26814',
                      addressInvalid: false,
                      emailAddress: 'paul996@gmail.com',
                      phoneISDCode: '+973',
                      phoneAreaCode: '1731',
                      phoneNumber: '161056',
                      mobileISDCode: '+973',
                      mobileAreaCode: '1731',
                      mobileNumber: '4267',
                      faxISDCode: '+993',
                      faxAreaCode: '1630',
                      faxNumber: '5678',
                      skypeID: 'paul.george',
                      postalAddressStatus: 'V',
                      phoneNumberStatus: 'V',
                      mobileNumberStatus: 'V'
                    }
                  ]
                },
                corporateInfo: null
              },
              memberDynamicAttributes: [
                {
                  attributeGroupName: 'Security Details',
                  attributeCode: '19',
                  groupInstanceID: '1',
                  attributeValue: 'test',
                  type: 'P'
                },
                {
                  attributeGroupName: 'Security Details',
                  attributeCode: '18',
                  groupInstanceID: '1',
                  attributeValue: 'MN',
                  type: 'P'
                },
                {
                  attributeGroupName: 'English Name',
                  attributeCode: '23',
                  groupInstanceID: '1',
                  attributeValue: 'PAUL998',
                  type: 'P'
                }
              ],
              periodType: 'O',
              period: 0
            },
            paymentDetail: null
          }
        }
      }

    beforeEach(()=>{
        const div = document.createElement('div');
        div.setAttribute('id', 'container');
        document.body.appendChild(div);
    })

    afterEach(()=>{
        const div = document.getElementById('container');
        if(div)
        document.body.removeChild(div);
    })

    test("Render the component", ()=>{
        const store = testStore({});
        let wrapper =mount(
            <Provider store={store}>
                <ChangeSecurityQuestion
                    dynamicAttributes={dynamicAttributes}
                    uiConfig={uiConfig}
                    config={config}
                    setCustomMessages={()=>{}}
                />
            </Provider>, { attachTo: document.getElementById('container') });
        wrapper.prop('store').dispatch(setSecurityQuestionsAction);
        wrapper = wrapper.update();
        wrapper.prop('store').dispatch(setProfileDataAction);
        wrapper = wrapper.update();
        let buttons = wrapper.find('button');
        buttons.forEach(b=>{
            b.simulate('click');
            wrapper = wrapper.update();
        })
        let passwordField = wrapper.find('input[type="password"][data-test="password"]');
        passwordField.simulate('change', {target: {value: 'Pwd@1234'}});
        wrapper = wrapper.update();
        let securityAnswer = wrapper.find('input[type="password"][data-test="securityQuestion_answer_0"]');
        securityAnswer.simulate('change', {target: {value: 'my test answer'}});
        wrapper = wrapper.update();
        buttons = wrapper.find('button[data-test="update-security-questions-update-button"]');
        buttons.simulate('click');
        wrapper = wrapper.update();
        

        let securityQuestion = wrapper.find('select[data-test="securityQuestion_question_0"]');
        securityQuestion.simulate('change', {target: {value: ''}});
        wrapper = wrapper.update();
        securityQuestion = wrapper.find('select[data-test="securityQuestion_question_0"]');
        securityQuestion.simulate('change', {target: {value: 'MN', selectedIndex: 1}});
        wrapper = wrapper.update();
        buttons = wrapper.find('button[data-test="update-security-questions-update-button"]');
        buttons.simulate('click');
        wrapper = wrapper.update();
        uiConfig.fields[0].validation.pattern = "$[a-z]^";
        wrapper.setProps({uiConfig});
        wrapper = wrapper.update();
        securityAnswer = wrapper.find('input[type="password"][data-test="securityQuestion_answer_0"]');
        securityAnswer.simulate('change', {target: {value: 'test@1#'}});
        wrapper = wrapper.update();
        buttons = wrapper.find('button[data-test="update-security-questions-update-button"]');
        buttons.simulate('click');
        wrapper = wrapper.update();
    })

    describe("Change security questions actions", ()=>{
        beforeEach(()=>{
            moxios.install();
        })
    
        afterEach(()=>{
            moxios.uninstall();
        })
    
        const params = {
            password: 'test_password',
            pin: '',
            dynamicAttributes: [],
            setCustomMessages: ()=>{}
        }
    
        test("update security questions failed", async (done)=>{
            const store = mockStore({});
            moxios.wait(()=>{
                const request = moxios.requests.mostRecent();
                request.respondWith({ status: 500, response: {
                    message: 'error occured',
                    error: {
                      errorDetails: ['error occured']
                    }
                } })
            })
            const mockFunction = jest.fn(()=>{})
            params.setCustomMessages = mockFunction;
            await store.dispatch(updateSecurityQuestions(params))
            expect(mockFunction.mock.calls.length).toBe(1);
            done();
        })
    
        test("update security questions success", async (done) => {
            const store = mockStore({});
            moxios.wait(()=>{
                const request = moxios.requests.mostRecent();
                request.respondWith({ status: 200, response: {
                    data: 'success'
                } })
            })
            const mockFunction = jest.fn(()=>{})
            params.setCustomMessages = mockFunction;
            await store.dispatch(updateSecurityQuestions(params))
            expect(mockFunction.mock.calls.length).toBe(1);
            done();
        })
    })
})