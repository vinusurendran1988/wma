import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { withSuspense, setFieldInvalid, setFieldValid } from '../../../common/utils';
import FieldBank from '../../../common/components/fields/FieldBank';
import { resetError } from '../../../common/middleware/redux/commonAction'
import { FIELD_INVALID } from '../../enrolment/Constants';
import {
    getItemFromBrowserStorage,
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
    BROWSER_STORAGE_KEY_COMPANY_CODE, 
    BROWSER_STORAGE_KEY_PROGRAM_CODE
} from '../../../common/utils/storage.utils';
import { SECURITY_QUESTION_ATTRIBUTE_KEY, SECURITY_ANSWER_ATTRIBUTE_KEY, UPDATE_PASSWORD_BUTTON, CANCEL_UPDATE_PASSWORD_BUTTON } from '../Constants';
import {
    changePassword
} from './actions'
import { clearErrorMarkings } from '../utils';
import Button from '../../../common/components/fieldbank/Button';

/**
 * ChangePassword class.
 * @description Change password section.
 * @author Somdas M
 */
class ChangePassword extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: {},
            errorIndices: [],
            resetForm: false
        }
        this.handleChange = this.handleChange.bind(this)
        this.manageSecurityQuestions = this.manageSecurityQuestions.bind(this)
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevProps.changedPassword != this.props.changedPassword && Object.keys(this.props.changedPassword).length > 0) {
            // Success response from the change password api.
            this.setState({
                data: {},
                resetForm: !this.state.resetForm
            })
            this.props.setCustomMessages({
                type: "success",
                messages: ["security.changePassword.change_password_success"]
            })
        }

        if (this.props.errors && prevProps.errors != this.props.errors && this.props.errors.length > 0) {
            // Error response from the change password api.
            this.props.setCustomMessages({
                type: "danger",
                messages: this.props.errors
            }, false)
        }
    }

    /**
     * Function to handle input change
     * @author Somdas M
     * @param {string} field - The modified field name which is same as that variable in data{}
     * @param {object} event - onChange event
     */
    handleChange(field, event) {
        let { data } = this.state
        data[field] = event.target.value
        // Clear the success/error messages when an input change occurs
        this.props.setCustomMessages({ type: "", messages: [] })
        this.props.resetError()
        if (event.target.classList.value.includes(FIELD_INVALID)) {
            // Mark a field as valid if that was previously invalid and an onChange event occured.
            setFieldValid(event.target.id)
        }
        this.setState({
            data
        })
    }

    /**
     * Function to reset the error messages and clear the state variable (data).
     * Invoked when the api response is success.
     * @author Somdas M
     */
    resetError() {
        // Clear the validation messages displayed, if any.
        this.props.setCustomMessages({ type: "", messages: [] })
        // Clear the api response messages displayed, if any.
        this.props.resetError()
        // Clear red exclamation error markings from text fields
        clearErrorMarkings(this.props.uiConfig.fields);
        // Clear the api response messages displayed, if any.
        this.setState({
            data: {
                confirmPassword: ''
            },
            resetForm: !this.state.resetForm
        })
    }

    /**
     * Function to evaluate whether the regex matches the input value
     * @author Somdas M
     * @param {string} pattern - The regex pattern to be matched
     * @param {string} value - The user specified value to be tested
     */
    isPatternMatch(pattern, value) {
        const regex = new RegExp(pattern)
        return regex.test(value)
    }

    /**
     * Function to validate the payload request
     * @author Somdas M
     * @param {object} errorMessages - List of error messages
     */
    validateRequest(errorMessages) {
        const { uiConfig } = this.props
        if (uiConfig.fields) {
            uiConfig.fields.map((field, idx) => {
                if (field.visibility && field.validation) {
                    let value = this.state.data[field.name]
                    if (field.type == "security") {
                        // Validating the security questions
                        value = (value == undefined) ? [{ "question": "", "answer": "" }] : value
                        let errors = []
                        value.forEach((val, index) => {
                            // Collect the invalid questions and unmatched regex answers.
                            if (val.question == "" || !this.isPatternMatch(field.validation.pattern, val.answer)) {
                                errors.push(index)
                            }
                            // Store the error index to state, to pass to the securityQuestions component.
                            this.setState({
                                errorIndices: errors
                            })
                        })
                        // Check if any error present in the security questions section.
                        if (errors.length > 0)
                            errorMessages.push(field.validation.customMessageId)
                    } else {
                        // Validating fields other than the security question.
                        value = (value == undefined) ? "" : value
                        let foundError = false
                        // Validation based on the regex pattern specified against each field from the json configuration.
                        field.validation.forEach((validation) => {
                            let additionalPattern = validation.pattern
                            // Validate the present field based on the value of another field using the regex (>,<,==,!=)
                            // For example, to validate the oldPassword and newPassword are not same.
                            if (validation.field) {
                                // Constructing the regex pattern with multiple fields, if present
                                // For example,
                                //  Pattern = "//^((?![firstName]|[lasttName]).)*$//gi".
                                //  After this loop, the pattern will look like: "//^((?!IBS|123).)*$//gi"
                                validation.field.forEach((additionalField) => {
                                    additionalPattern = additionalPattern.replace('[' + additionalField + ']', this.state.data[additionalField])
                                })
                            }
                            if (!this.isPatternMatch(additionalPattern, value)) {
                                foundError = true
                                errorMessages.push(validation.customMessageId)
                            }
                        })
                        if (foundError) {
                            setFieldInvalid(field.id)
                        } else {
                            setFieldValid(field.id)
                        }
                    }
                }
            })
        }
    }

    /**
     * Function to check if an api call is required when the user clicks update button
     * @author Somdas M
     */
    updatePassword() {
        let messages = []
        this.validateRequest(messages)
        if (messages.length > 0) {
            this.props.setCustomMessages({
                type: "danger",
                messages
            })
        } else {
            this.props.changePassword(this.createPayload(), UPDATE_PASSWORD_BUTTON)
        }
    }

    /**
     * Function to create payload for invoking the change password api
     * @author Somdas M
     */
    createPayload() {
        const payload = {
            "object": {
                "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                "membershipNumber": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                //"customerToken": "",
                "oldPassword": this.state.data.oldPassword,
                "newPassword": this.state.data.confirmPassword,
                //"customerNumber": ""
            }
        }

        let { object } = payload
        let { dynamicAttributes } = this.props

        if (dynamicAttributes) {
            //Handle the 'dynamicAttributes' if present in the json configuration.
            object["dynamicAttributes"] = []
            let securityDynamicAttributes = []
            dynamicAttributes.forEach((dynamicAttribute) => {
                if (dynamicAttribute.attributeKey
                    && [SECURITY_QUESTION_ATTRIBUTE_KEY, SECURITY_ANSWER_ATTRIBUTE_KEY]
                        .includes(dynamicAttribute.attributeKey)) {
                    // Select the dynamic attibutes with attributeKey as SQ, SA
                    securityDynamicAttributes.push(dynamicAttribute)
                } else if (dynamicAttribute.attributeMapping) {
                    // Handle the dynamicAttributes other than SQ, SA.
                    // Map the values from this.state.data with the respective attributeMapping.
                    dynamicAttribute.attributeValue = this.state.data[dynamicAttribute.attributeMapping]
                    object["dynamicAttributes"].push(dynamicAttribute)
                }
            })

            // Mapping and constructing the data for SQ, SA.
            if (securityDynamicAttributes.length > 0) {
                securityDynamicAttributes.forEach((securityQn) => {
                    this.state.data["securityQuestions"].forEach((userInput) => {
                        if (securityQn.attributeKey == SECURITY_QUESTION_ATTRIBUTE_KEY) {
                            securityQn["attributeValue"] = userInput.question

                        } else if (securityQn.attributeKey == SECURITY_ANSWER_ATTRIBUTE_KEY) {
                            securityQn["attributeValue"] = userInput.answer
                        }
                        securityQn["groupInstanceID"] = userInput.groupInstanceID
                        object["dynamicAttributes"].push(JSON.parse(JSON.stringify(securityQn)))
                    })
                })
            }
        }
        return payload
    }

    /**
     * Callback function from the securityQuestions component.
     * @author Somdas M
     * @param {array} securityQuestions - List of security questions
     */
    manageSecurityQuestions(securityQuestions) {
        let { data } = this.state
        let securityQns = []
        securityQuestions.map((securityQuestion, idx) => {
            securityQns.push(securityQuestion)
        })
        if (securityQns.length > 0) {
            data["securityQuestions"] = securityQns
            this.setState({
                data
            })
        }
    }

    render() {
        const { uiConfig, t } = this.props
        return (
            <div className="pageClassChangePassword">
                <div className="form-row">
                    {
                        uiConfig.fields && uiConfig.fields.map((field, idx) => {
                            if (field.visibility) {
                                // Render the fields only if the field visibility is enabled.
                                let props = { ...this.props }
                                props[field.name] = this.state.data[field.name] ? this.state.data[field.name] : ""
                                props.field = field
                                props.idx = idx
                                props.key = idx
                                props.handleChange = this.handleChange
                                props.manageSecurityQuestions = this.manageSecurityQuestions
                                props.errorIndices = this.state.errorIndices
                                props.data = this.state.data;
                                if (props.config && props.config.additionalSecurityEnabled &&
                                    props.config.securityType.securityQuestion &&
                                    props.config.securityType.securityQuestion.enabled &&
                                    props.config.securityType.securityQuestion.count) {
                                    // Manage the security question count from the json configuration.
                                    props.count = props.config.securityType.securityQuestion.count
                                    props.securityQuestionType = props.type
                                    props.securityQuestionFilterType = props.filterType
                                    props.securityQuestionFilterValue =  props.dynamicAttributes.find(attribute=>attribute.attributeKey === SECURITY_QUESTION_ATTRIBUTE_KEY).attributeCode
                                }
                                props.resetForm = this.state.resetForm
                                props.className = field.className?field.className:"col-lg-4"
                                return <FieldBank {...props} />
                            }
                        })
                    }
                    <div className="col-12 text-right btn-wrap btn-wrap--grp">
                        <Button
                            className="btn btn-secondary" 
                            handleOnClick={() => this.resetError()} 
                            id={CANCEL_UPDATE_PASSWORD_BUTTON} 
                            data-test="laterButton" 
                            label={t("security.changePassword.cancelBtn")} />
                        <Button 
                            className="btn btn-primary" 
                            handleOnClick={() => this.updatePassword()} 
                            id={UPDATE_PASSWORD_BUTTON} 
                            data-test="updateButton" 
                            label={t("security.changePassword.updateBtn")} />
                    </div>
                </div>
            </div>


        );
    }
}
function mapStateToProps(state) {
    return {
        changedPassword: state.changePsw.changePswInfo, // Success response of the reset password api call.
        errors: state.commonErrorReducer.error // Error response of the reset password api call.
    }
}
const mapDispatchToProps = {
    resetError, // Action to clear the commonErrorReducer data.
    changePassword // Action To invoke changePassword.
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(ChangePassword)))