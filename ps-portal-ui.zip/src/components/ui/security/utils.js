/**
 * Function to remove red exclamation error markings from text fields
 * @author Alan Kuriakose
 * @param {array} fields - array of fields for which error markings need to be removed
 */
export function clearErrorMarkings(fields = []) {
    fields.forEach(field => {
        const element = document.getElementById(field.id);
        if (element) {
            element.classList.remove('is-invalid');
        }
    })
}