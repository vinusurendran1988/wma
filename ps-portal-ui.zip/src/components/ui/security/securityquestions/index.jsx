import React from 'react';
import { fetchSecurityQuestions } from './actions';
import { connect } from 'react-redux';

/**
 * @author Alan Kuriakose
 * Security Questions component that renders all security questions and answer fields
 */
class SecurityQuestions extends React.Component {

    constructor(props) {
        super(props);
        this.state={
            result: this.initializeResult(props.numberOfQuestions, false),
            answerTypes: Array(props.numberOfQuestions).fill('password')
        }
    }

    componentDidMount() {
        if(!this.props.securityQuestions || this.props.securityQuestions.length == 0 ){
            const { type, filterType, filterValue } = this.props;
            this.props.fetchSecurityQuestions({
                type,
                filterType,
                filterValue
            });
        }
    }

    initializeResult(numberOfQuestions, setstate=true) {
        const { values } = this.props;
        const result = Array(numberOfQuestions).fill(0).map((v,k)=>({
            question: (values[k] && values[k].question) || '',
            answer: (values[k] && values[k].answer) ? '********' : '',
            groupInstanceID: (values[k] && values[k].groupInstanceID) || ''
        }))
        if(setstate) {
            this.setState({
                result
            })
        }
        return result;
    }

    handleChange(result) {
        const { values, onChange } = this.props;
        const tempObj = JSON.parse(JSON.stringify(result));
        tempObj.forEach((v,i)=>{
            if(v.answer === '********') {
                v.answer = values[i].answer;
            }
        })
        onChange(tempObj);
    }

    componentDidUpdate(prevProps) {
        if(
            prevProps.numberOfQuestions !== this.props.numberOfQuestions ||
            prevProps.reset !== this.props.reset ||
            JSON.stringify(prevProps.values) !== JSON.stringify(this.props.values)) {
            this.initializeResult(this.props.numberOfQuestions)
        }
    }

    render() {
        const { numberOfQuestions, securityQuestions, errorIndices, values } = this.props;
        const { result, answerTypes } = this.state;
        return (
            <React.Fragment>
                {Array.from({length: numberOfQuestions}, (v,k)=>{
                    const filteredQuestions = securityQuestions.filter(question=>{
                        return [-1, k].includes(result.findIndex(ob=> ob.question === question.optionCode))
                    })
                    return(
                        <div key={k} className="col-12">
                            <div className="form-row">
                                <div className="col-lg-6 questionsLabel">
                                    <div className="form-group">
                                        <select
                                            data-test={`securityQuestion_question_${k}`}
                                            className=""
                                            id="exampleFormControlSelect1"
                                            onChange={event=>{
                                                const value = event.target.value;
                                                result[k].question = value;
                                                if(value === '') {
                                                    result[k].groupInstanceID = '';
                                                } else {
                                                    result[k].groupInstanceID = filteredQuestions[event.target.selectedIndex-1].sequenceNumber;
                                                }
                                                this.handleChange(result);
                                                this.setState({
                                                    result
                                                })
                                            }}
                                            value={result[k].question}
                                        >
                                            <option value=''>Select Question</option>
                                            {
                                                filteredQuestions.map((question, index)=>{
                                                    return <option key={index} value={question.optionCode}>{question.optionName}</option>
                                                })
                                            }
                                        </select>
                                    </div>
                                </div>
                                <div className="col-lg-6">
                                    <div className="form-group">
                                        <label className="sr-only" htmlFor={`securityQuestion_answer_${this.props.idx}`}>Answer</label>
                                        <input
                                            id={`securityQuestion_answer_${this.props.idx}`}
                                            data-test={`securityQuestion_answer_${k}`}
                                            className={""+(errorIndices.includes(k)?' is-invalid':'')}
                                            type={answerTypes[k]}
                                            aria-required="true"
                                            placeholder="Answer"
                                            onFocus={(event)=>{
                                                result[k].answer = '';
                                                answerTypes[k] = 'text'
                                                this.setState({
                                                    result,
                                                    answerTypes
                                                })
                                            }}
                                            onBlur={(event)=>{
                                                if(event.target.value === '') {
                                                    result[k].answer = (values[k] && values[k].answer) ? '********' : '';
                                                    this.setState({
                                                        result
                                                    })
                                                }
                                                answerTypes[k] = 'password';
                                                this.setState({
                                                    answerTypes
                                                })
                                            }}
                                            onChange={event=>{
                                                result[k].answer = event.target.value;
                                                this.handleChange(result);
                                                this.setState({
                                                    result
                                                })
                                            }}
                                            value={result[k].answer}
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>)
                })}
            </React.Fragment>
        )
    }
}

SecurityQuestions.defaultProps = {
    numberOfQuestions: 1,
    onChange: ()=>{},
    type: '',
    filterType: '',
    filterValue: 0,
    errorIndices: [],
    values: [],
    reset: false
}

const mapStateToProps = state => {
    return({
        securityQuestions: state.masterData.securityQuestions,
    })
}

const mapDispatchToProps = dispatch => {
    return({
        fetchSecurityQuestions: (params) => dispatch(fetchSecurityQuestions(params))
    })
}

export default connect(mapStateToProps, mapDispatchToProps)(SecurityQuestions);