import { doPost } from "../../../common/utils/api";
import { SET_MASTER_DATA } from "../../../common/middleware/redux/commonAction";
import { _URL_ADDITIONAL_DETAILS } from "../../../common/config/config";
import {
    getItemFromBrowserStorage,
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_PROGRAM_CODE
} from '../../../common/utils/storage.utils';
import { SECURITY_QUESTION_FETCH_TYPE } from "../Constants";
import { startApiLoading, stopApiLoading } from "../../../common/components/fieldbank/loader/action";

export const fetchSecurityQuestions = (params) => {
    return async (dispatch, getState) => {
        if (getState().masterData.securityQuestions.length !== 0) {
            return;
        }
        const { type, filterType, filterValue } = params;
        const requestBody = {
            "object": {
                "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                type,
                "filterFieldDetail": {
                    filterType,
                    filterValue
                }
            }
        }
        dispatch(startApiLoading("fetchSecurityQuestions"))
        await doPost(_URL_ADDITIONAL_DETAILS, requestBody)
            .then(response => {
                dispatch(stopApiLoading("fetchSecurityQuestions"))
                dispatch({
                    type: SET_MASTER_DATA,
                    payload: {
                        data: response.data.object.memberDynamicAttributes[0].attributeInputOption,
                        type: SECURITY_QUESTION_FETCH_TYPE
                    }
                })
            }).catch(error => {
                dispatch(stopApiLoading("fetchSecurityQuestions"))
                console.log(error);
            })
    }
}