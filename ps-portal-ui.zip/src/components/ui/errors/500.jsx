import { NAVIGATE_MEMBER_DASHBOARD, NAVIGATE_CORPORATE_OVERVIEW } from "../../common/utils/urlConstants";
import { Component } from "react";
import React from 'react';
import { getItemFromBrowserStorage, BROWSER_STORAGE_KEY_PROGRAM_TYPE } from "../../common/utils/storage.utils";
import { PROGRAM_TYPE_INDIVIDUAL } from "../../common/utils/Constants";

class _500 extends Component {
    render() {
        const programType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE)
        return (
            <div className="container">
                <div className="row">
                    <div className="col-md-12">
                        <div className="error-template">
                            <span className="header">Oops!</span><br />
                            <span className="message"> 500 Server Error</span>
                            <div className="error-details">Sorry, an error has occured, Please try again or feel free to contact us if the problem persists!</div>
                            <div className="error-actions">
                                {/* <a href={`#${programType===PROGRAM_TYPE_INDIVIDUAL?NAVIGATE_MEMBER_DASHBOARD:NAVIGATE_CORPORATE_OVERVIEW}`} className="btn btn-primary btn-lg">
                                    <span className="glyphicon glyphicon-home"></span>
                                    Go to Dashboard
                                    </a> */}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default _500;