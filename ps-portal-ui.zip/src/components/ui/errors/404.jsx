import { NAVIGATE_MEMBER_DASHBOARD, NAVIGATE_CORPORATE_OVERVIEW } from "../../common/utils/urlConstants";
import { Component } from "react";
import React from 'react';
import { getItemFromBrowserStorage, BROWSER_STORAGE_KEY_PROGRAM_TYPE } from "../../common/utils/storage.utils";
import { PROGRAM_TYPE_INDIVIDUAL } from "../../common/utils/Constants";

class _404 extends Component {
    render() {
        const programType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE)
        return (
            <div className="container">
                <div className="row">
                    <div className="col-md-12">
                        <div className="error-template" style={{"align-items": "normal"}}>
                            {/* <span className="header h1">Oops!</span> */}
                            <br />
                            <span className="message h3">Page not found</span>
                            <div className="error-details mb-5">We could not find the requested page.</div>
                            {/* <div className="error-actions">
                                <a href={`#${programType===PROGRAM_TYPE_INDIVIDUAL?NAVIGATE_MEMBER_DASHBOARD:NAVIGATE_CORPORATE_OVERVIEW}`} className="btn btn-primary btn-lg">
                                    <span className="glyphicon glyphicon-home"></span>
                                    Go to Dashboard
                                    </a>
                            </div> */}
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default _404;