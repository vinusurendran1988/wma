import { Component } from "react";
import React from 'react';

class _403 extends Component {
    render() {
        return (
            <div className="container">
                <div className="row">
                    <div className="col-md-12">
                        <div className="error-template">
                            <span className="header">Oops!</span><br />
                            <span className="message"> 403 Unauthorized </span>
                            <div className="error-details">Sorry, an error has occured, Requested page is unauthorized!</div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default _403;