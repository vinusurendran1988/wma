import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { withSuspense } from '../../common/utils';
import { fetchConfiguration } from '../../common/middleware/redux/commonAction'
import { connect } from 'react-redux';
import { Slider } from 'primereact/slider';
import { fetchAccountSummary } from './../../common/middleware/redux/commonAction';
import { convertPoints } from './actions';
import CustomMessage from '../../common/components/custommessage';
import {
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
    getItemFromBrowserStorage,
  } from '../../common/utils/storage.utils';
import { CONFIG_SECTION_MIGRATEPOINTS } from '../../common/utils/Constants';
import { CONVERT_POINT_BTN, CONVERT_POINT_CANCEL_BTN } from './Constant';
import Button from '../../common/components/fieldbank/Button';

/**
 * Referral class.
 * @description To send referral to multiple users via email/social media.
 * @author Somdas M
 */
class MigratePoints extends Component {

    constructor(props) {
        super(props)
        this.state = {
            points: 0,
            minimum: 0,
            maximum: 0,
            val1: 0,
            selectedValue: 0,
            balance: -1,
            loyaltyPoints: 0,
            //success: false
            agreeTerms: false,
            customMessageType: "",
            customMessages: []
        }
        this.onChangeSlider1 = this.onChangeSlider1.bind(this);
        this.proceedToConvert = this.proceedToConvert.bind(this);
        this.sliderEnd = this.sliderEnd.bind(this);
        this.reset = this.reset.bind(this)
    }

    reset(){
        this.setState({
            points: 0,
            minimum: 0,
            maximum: 0,
            val1: 0,
            selectedValue: 0,
            balance: -1,
            loyaltyPoints: 0,
            //success: false
            agreeTerms: false,
            customMessageType: "",
            customMessages: []
        })
    }
    sliderEnd(e) {
        this.setState({
            selectedValue: e.value,
            balance: parseInt(this.state.points - e.value),
            loyaltyPoints: (e.value) * 200
        });
    }

    onChangeSlider1(e) {
        this.setState({
            val1: e.value,
        });
    }

    proceedToConvert() {
        this.setState({
            customMessageType: "",
            customMessages: []
        }, () => {
            if(this.state.agreeTerms){
                const payload = {
                    "object": {
                        "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                        "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                        "membershipNumber": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                        "partnerCode": "NZ",
                        "activityCode": "PS",
                        "activityDescription": "",
                        "adhocAttributes": [
                            {
                                "attributeCode": "PC",
                                "attributeValue": this.state.selectedValue
                            }
                        ],
                        "emailAddress": ""
                    }
                }
                this.props.convertPoints(payload, CONVERT_POINT_BTN);
            } else {
                this.setState({
                    customMessageType: "danger",
                    customMessages: [this.props.t('migratepoints.agreeTerms')]
                })
            }
        })
    }

    componentDidUpdate(prevProps, prevState) {
        if (this.props.config && this.state.balance == -1 && this.props.accountSummary) {
            const { pointTypes } = this.props.config.data
            const accountDetails = this.props.accountSummary.pointDetails
            accountDetails.forEach((item) => {
                if (item.pointType.includes(pointTypes)) {
                    this.setState({
                        points: parseInt(item.points),
                        val1: item.points > 10 ? 10 : 0,
                        maximum: item.points,
                        balance: parseInt(item.points)
                    })
                }
            })
        }
        if (JSON.stringify(prevProps.convertedPoints) !== JSON.stringify(this.props.convertedPoints)) {
            this.setState({
                selectedValue: 0,
                loyaltyPoints: 0,
                success: true
            });
            this.props.fetchAccountSummary();
        }

        if (JSON.stringify(prevProps.convertedPoints) !== JSON.stringify(this.props.convertedPoints)) {

            this.setState({
                selectedValue: 0,
                loyaltyPoints: 0,
                customMessageType: "success",
                customMessages: [this.props.t('migratepoints.success')],
                agreeTerms: false
            });
            this.props.fetchAccountSummary();
        }

        if(this.props.errors != prevProps.errors){
            this.setState({
                customMessageType: "danger",
                customMessages: this.props.errors
            })
        }
    }

    componentDidMount() {
        const { config } = this.props
        this.props.setPageInfo(this.props, {config, confSection: CONFIG_SECTION_MIGRATEPOINTS})
        if (!this.props.accountSummary) {
            this.props.fetchAccountSummary();
        }
        else if (config) {
            const accountDetails = this.props.accountSummary.pointDetails
            const { pointTypes } = config.data
            accountDetails.forEach((item) => {
                if (item.pointType.includes(pointTypes)) {
                    this.setState({
                        points: parseInt(item.points),
                        maximum: item.points
                    })
                }
            })
        }
    }

    acceptTerms(agreeTerms){
        this.setState({
            agreeTerms,
            customMessageType: "",
            customMessages: []
        })
    }

    render() {
        const { t } = this.props;
        return (
            <div className="col-lg-9  col-md-8 rightSidePanel">
                <div className="card mb-3 profileHeadWrap">
                    <div className="card-body">
                        <div className="d-flex justify-content-start">
                            <div className="profileImgEdit"></div>
                            <div className="ml-2">
                                <div>{t("migratepoints.title")}</div>
                                {t("migratepoints.description")} <strong>{t("migratepoints.target_point_type")}</strong>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="card">
                    <div className="card-body">
                    {
                            <CustomMessage type={this.state.customMessageType} message={this.state.customMessages} />
                        }
                        <div className="d-flex justify-content-between">
                            <div>{t("migratepoints.available")} : <strong>{this.state.points}</strong></div>
                            <div>{t("migratepoints.conversion_rate")}: <strong> 1 </strong>{t("migratepoints.source_point_type")} = <strong>200</strong> {t("migratepoints.target_point_type")} </div>
                        </div>
                        <div className="form-row conversionDetailsWrap">
                            <div className="col-lg-8">
                                <div className="heading">{(t("migratepoints.select_source_point_type_to_convert").replace("{SOURCE_POINT_TYPE}", t("migratepoints.source_point_type")))}</div><div className="text-center">
                                    <div className="row">
                                        <div className="col-lg-6">
                                            <div style={{ padding: 5 }}>
                                                <Slider
                                                    min={this.state.minimum}
                                                    value={this.state.val1}
                                                    onChange={this.onChangeSlider1}
                                                    style={{ width: '14em' }}
                                                    max={this.state.maximum}
                                                    onSlideEnd={this.sliderEnd}
                                                    step={10}
                                                />
                                            </div>
                                        </div>
                                        <div className="col-lg-4 text-left"><strong>{this.state.val1}</strong></div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-4"><div className="cDHeading">{t("migratepoints.source_point_type")}</div>
                                <div className="d-flex justify-content-between"><div>{t('migratepoints.selected')} <strong>{this.state.selectedValue}</strong></div><div className="text-right">{t('migratepoints.balance')} <strong>{this.state.balance}</strong></div></div>
                                <div className="cDTotal">{t("migratepoints.target_point_type")} <strong>{this.state.loyaltyPoints}</strong></div>
                            </div>
                        </div>
                        <div className="form-row">
                            <div className="col-12 buttonWrap d-flex justify-content-between">
                                <div className="buttonLeftTxt">
                                    <div className="form-check form-check-inline pt-2">
                                        <input className="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1" onChange={(e)=>this.acceptTerms(e.target.checked)} checked={this.state.agreeTerms} />
                                        <label className="form-check-label" htmlFor="inlineCheckbox1">{t("migratepoints.i_accept")} <a >{t("migratepoints.terms_and_conditions")}</a></label>
                                    </div>
                                </div>
                                <div className="btn-wrap btn-wrap--grp">
                                    <Button 
                                        className="btn btn-secondary" 
                                        handleOnClick={() => this.reset()} 
                                        id={CONVERT_POINT_CANCEL_BTN} 
                                        data-test={CONVERT_POINT_CANCEL_BTN}
                                        label={t("migratepoints.button_cancel")} />
                                    <Button 
                                        className="btn btn-primary" 
                                        handleOnClick={() => this.proceedToConvert()} 
                                        id={CONVERT_POINT_BTN} 
                                        data-test={CONVERT_POINT_BTN}
                                        label={t("migratepoints.button_confirm")} />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

}


function mapStateToProps(state) {
    return {
        accountSummary: state.accountSummaryReducer.accountSummary,
        convertedPoints: state.convertPointsReducer.pointsConverted,
        config: state.configurationReducer[CONFIG_SECTION_MIGRATEPOINTS],
        errors: state.commonErrorReducer.error
    }
}

const mapDispatchToProps = { fetchConfiguration, fetchAccountSummary, convertPoints }

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(MigratePoints)));