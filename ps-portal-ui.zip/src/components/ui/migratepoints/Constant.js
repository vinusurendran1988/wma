export const CONVERT_POINT_BTN = "convert-point-button"
export const CONVERT_POINT_CANCEL_BTN = "cancel-convert-point-button"