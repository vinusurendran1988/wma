export const RESET_PASSWORD_BUTTION = "reset-pasword-button"
export const TOKEN_PARAMS_KEY = "TKN"