import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { HashRouter as Redirect } from 'react-router-dom';
import { withSuspense } from '../../common/utils';
import { resetPasswordDetails } from './actions';
import { connect } from 'react-redux';
import { fetchConfiguration, logOut } from '../../common/middleware/redux/commonAction';
import { CONFIG_SECTION_DEFAULT } from '../../common/utils/Constants';
import {
    getApiErrorMessage
} from '../../common/utils';
import CustomMessage from '../../common/components/custommessage';
import { NAVIGATE_MEMBER_LOGIN } from '../../common/utils/urlConstants';
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';
import { getItemFromBrowserStorage, BROWSER_STORAGE_KEY_COMPANY_CODE, BROWSER_STORAGE_KEY_PROGRAM_CODE } from '../../common/utils/storage.utils';
import { RESET_PASSWORD_BUTTION } from './Constant';
import Button from '../../common/components/fieldbank/Button';

class ResetPassword extends Component {
    constructor(props) {
        super(props);
        this.handleChange = this.handleChange.bind(this);
        this.confirmPasswordCheck = this.confirmPasswordCheck.bind(this);
        this.redirection = this.redirection.bind(this);
        this.pswChange = this.pswChange.bind(this);
        this.state = {
            oldPsw: '',
            newPsw: '',
            confirmPsw: '',
            isConfirm: true,
            match: true,
            isEmpty: false,
            success: false,
            errors: {
                pswStrong: '',
                pswMatch: ''
            }
        };
    }

    componentDidMount() {
        this.props.setPageInfo(this.props, {})
    }

    componentDidUpdate(prevProps) {
        if (JSON.stringify(prevProps.resetPsw) !== JSON.stringify(this.props.resetPsw)) {
            let data = this.props.resetPsw;
            if (this.props.resetPsw.statusMessage == "SUCCESS") {
                this.setState({
                    success: true,
                    match: true,
                    newPsw: '',
                    confirmPsw: ''
                });
            }
            else {
                if (data.error) {
                    this.setState({
                        match: false,
                        success: false,
                        message: getApiErrorMessage(data.error)
                    });
                }
            }
        }
    }

    confirmPasswordCheck(e) {
        this.setState({
            isEmpty: false
        });
        let { errors } = this.state;
        if (this.state.newPsw != e.target.value && e.target.value != "") {
            if (errors.pswStrong == '') {
                errors.pswMatch = "Invalid";
            }
        }
        else {
            errors.pswMatch = "";
        }
        this.setState({
            confirmPsw: e.target.value,
            errors: errors,
            match: true
        });
    }

    pswChange(e) {
        this.setState({
            match: true,
            isEmpty: false,
            errors: {
                pswStrong: '',
                pswMatch: ''
            }
        });
        if (e.target.name == 'confirmPsw') {
            this.setState({
                confirmPsw: e.target.value,
            });
        }
        if (e.target.name == 'newPsw') {
            this.setState({
                newPsw: e.target.value,
            });
        }
    }

    redirection() {
        this.setState({
            isRedirection: true
        });
    }

    handleChange(e) {
        this.setState({
            isEmpty: false
        });
        let { errors } = this.state;
        const { configuration } = this.props
        if (configuration) {
            const config = getCurrentProgramFromDefaultConfig(configuration)
            if (config) {
                let pswValidator = new RegExp(config.defaults.passwordRegex);
                if (!pswValidator.test(e.target.value)) {
                    errors.pswStrong = "Invalid";
                    errors.pswMatch = "";
                }
                else {
                    errors.pswStrong = ""
                    this.setState({
                        isConfirm: false
                    });
                }
                this.setState({
                    newPsw: e.target.value,
                    errors: errors,
                    match: true
                });
            }
        }
    }
    goToLoginPage(){
        window.location.href = `#${NAVIGATE_MEMBER_LOGIN}`
    }

    formValidionCheck = () => {

        if (this.state.newPsw != '' && this.state.confirmPsw != '' && this.state.errors.pswStrong != "Invalid" && this.state.errors.pswMatch != "Invalid") {
            this.setState({
                isEmpty: false
            });
            let token = "";
            let memNo = "";
            let customerNo = ""
            let url = window.location.href;
            let urlQueryParams = (url.split("?"));
            if (urlQueryParams.length > 1) {
                let parameters = urlQueryParams[1].split("&");
                parameters.forEach((item) => {
                    let data = item.split("=");
                    if (data[0] == 'TKN') {
                        token = data[1];
                    }
                    if (data[0] == 'MEMSHPNUM') {
                        memNo = data[1];
                    }
                    if (data[0] == 'CUSID') {
                        customerNo = data[1];
                    }
                })
            }
            let payload = {
                "object": {
                    "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                    "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                    "membershipNumber": memNo,
                    "customerToken": token,
                    "oldPassword": "",
                    "newPassword": this.state.newPsw,
                    "customerNumber": customerNo
                }
            };

            this.props.resetPasswordDetails(payload, RESET_PASSWORD_BUTTION);
        }
        else {
            if ((this.state.confirmPsw == '' || this.state.newPsw == '') && (this.state.errors.pswStrong != "Invalid" && this.state.errors.pswMatch != "Invalid")) {
                this.setState({
                    isEmpty: true,
                    match: true
                });
            }
        }
    }


    render() {
        const { errors } = this.state;
        const { t } = this.props;
        return (
            <div className="col-12">
                { this.state.success ? (
                    <div className="success-bar">
                        <h1 className="success-text">{t('resetPsw.message.psw_success')}</h1>
                        <div className="success-button">
                            <button className="btn btn-primary btn-lg" onClick={() => this.goToLoginPage()}>{t('resetPsw.login_button')}</button>
                        </div>
                    </div>

                ) : (
                    <div className="password password--forget">
                        <h1>{t('resetPsw.title')}</h1>
                        {
                            errors.pswMatch != "" &&
                            <CustomMessage type="danger" message={[t('resetPsw.message.psw_not_match')]} />
                        }
                        {
                            errors.pswStrong != "" &&
                            <CustomMessage type="danger" message={[t('resetPsw.message.psw_not_strong1'), t('resetPsw.message.psw_not_strong2')]} />
                        }
                        {
                            this.state.isEmpty &&
                            <CustomMessage type="danger" message={[t('resetPsw.message.psw_empty')]} />
                        }
                        {
                            !this.state.match && <CustomMessage type="danger" message={this.state.message} />
                        }
                        
                        <label className="label">{t('changePsw.newPsw')}</label>
                        <div className="txt-wrap">
                            <input type="password" className="txt" value={this.state.newPsw} id="pswNew" name="newPsw" onChange={this.pswChange} onBlur={this.handleChange} />
                        </div>
                        <label className="label">{t('changePsw.confirmPsw')}</label>
                        <div className="txt-wrap">
                            <input type="password" className="txt" value={this.state.confirmPsw} id="pswConfirm" name="confirmPsw" onBlur={this.confirmPasswordCheck} onChange={this.pswChange} />
                        </div>
                            <div className="btn-wrap">
                                <Button
                                    className="btn btn-primary btn-lg"
                                    type="submit"
                                    handleOnClick={() => this.formValidionCheck()}
                                    id={RESET_PASSWORD_BUTTION}
                                    label={t("changePsw.submit_psw")} />

                            </div>

                    </div >
                )
                }
            </div>
        );
    }
}
function mapStateToProps(state) {
    return {
        resetPsw: state.resetpsw.resetPswInfo,
        configuration: state.configurationReducer[CONFIG_SECTION_DEFAULT]
    }
}
const mapDispatchToProps = {
    resetPasswordDetails,
    fetchConfiguration,
    logOut
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(ResetPassword)))
