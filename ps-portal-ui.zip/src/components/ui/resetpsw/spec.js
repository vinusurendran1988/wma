import React from 'react';
import ResetPassword from './index';
import { findByTestAttr, findComponent, mockServiceResponse } from '../../common/testUtils';
import { testStore } from '../../common/utils';
import moxios from 'moxios';
import { mount } from 'enzyme';
import ReactTestUtils from 'react-dom/test-utils';
import {
    fetchConfiguration
} from '../../common/middleware/redux/commonAction';
import { resetPasswordDetails } from './actions';
import {
    CONFIG_SECTION_DEFAULT
} from '../../common/utils/Constants'
import { NAVIGATE_RESET_PASSWORD } from '../../common/utils/urlConstants';


let store = testStore({})
let rootComponent;
let component;

const setUp = (props = {}) => {
    rootComponent = mount(<ResetPassword {...props} store={store} />);
    component = findComponent(rootComponent, 'ResetPassword');
};

describe('login Component', () => {
    beforeEach(() => {
        setUp({});
        component.setState({
            oldPsw: '',
            newPsw: '',
            confirmPsw: '',
            isConfirm: true,
            match: true,
            isEmpty: false,
            errors: {
                pswStrong: '',
                pswMatch: ''
            }
        });
        moxios.install();
        window.location.href = `http://localhost:8080/#${NAVIGATE_RESET_PASSWORD}?TKN=31F3542AB99AB11D150F71E6E8891AA434D403E2&MEMSHPNUM=800002865`;
    });

    afterEach(() => {
        moxios.uninstall();
    });

    it('forgotPsw: Fetch configuration for forgot password and render without errors', () => {
        mockServiceResponse(CONFIG_RESPONSE)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_DEFAULT))
                .then(() => {
                    const newState = store.getState();
                    expect(newState.configurationReducer.default).toStrictEqual(CONFIG_RESPONSE.object);
                    const ResetComponent = findByTestAttr(component, 'ResetComponent');
                    expect(ResetComponent.length).toBe(1);


                    rootComponent = rootComponent.update()
                    component = findComponent(rootComponent, 'ResetPassword');
                    const valueChange = findByTestAttr(component, 'newPsw')
                    expect(valueChange.length).toBe(1);
                    valueChange.simulate('change');

                    rootComponent = rootComponent.update()
                    component = findComponent(rootComponent, 'ResetPassword');
                    const valueBlur1 = findByTestAttr(component, 'newPsw')
                    expect(valueBlur1.length).toBe(1);
                    valueBlur1.simulate('blur');

                    rootComponent = rootComponent.update()
                    component = findComponent(rootComponent, 'ResetPassword');
                    const valueChange1 = findByTestAttr(component, 'confirmPsw')
                    expect(valueChange1.length).toBe(1);
                    valueChange1.simulate('change');

                    rootComponent = rootComponent.update()
                    component = findComponent(rootComponent, 'ResetPassword');
                    const valueChange2 = findByTestAttr(component, 'confirmPsw')
                    expect(valueChange2.length).toBe(1);
                    valueChange2.simulate('blur');

                    rootComponent = rootComponent.update()
                    const instance6 = component.instance();
                    instance6.forceUpdate();
                    component.setState({
                        newPsw: "Abc@123456",
                        confirmPsw: "Abc@123456",
                        errors: {
                            pswStrong: '',
                            pswMatch: ''
                        }
                    });
                    instance6.formValidionCheck();
                    let errors = {
                        pswStrong: '',
                        pswMatch: ''
                    };
                    expect(component.state('errors')).toStrictEqual(
                        errors
                    );

                    rootComponent = rootComponent.update()
                    const instance7 = component.instance();
                    instance7.forceUpdate();
                    component.setState({
                        newPsw: "abcde",
                        confirmPsw: "Abc@123456",
                        errors: {
                            pswStrong: 'Invalid',
                            pswMatch: 'Invalid'
                        }
                    });
                    instance7.formValidionCheck();
                    errors = {
                        pswStrong: 'Invalid',
                        pswMatch: 'Invalid'
                    };
                    expect(component.state('errors')).toStrictEqual(
                        errors
                    );

                    rootComponent = rootComponent.update()
                    const instance8 = component.instance();
                    instance8.forceUpdate();
                    let e = {
                        target:{
                          value:"Abc@123456"
                        },
                        "preventDefault": () => { },
                        "stopPropagation": () => { }
                    }
                    component.setState({
                        newPsw: "abcde",
                        confirmPsw: "Abc@123456",
                    });
                    instance7.confirmPasswordCheck(e);
                    errors = {
                        pswStrong: 'Invalid',
                        pswMatch: 'Invalid'
                    };
                    expect(component.state('errors')).toStrictEqual(
                        errors
                    );

                    rootComponent = rootComponent.update()
                    component = findComponent(rootComponent, 'ResetPassword');
                    const buttonSubmit = findByTestAttr(component, 'buttonSubmit')
                    expect(buttonSubmit.length).toBe(1);
                    buttonSubmit.simulate('click');
                    let data = {
                        "object": {
                            "companyCode": "IBS",
                            "programCode": "PRG14",
                            "membershipNumber": "IM0008010603",
                            "customerToken": "31F3542AB99AB11D150F71E6E8891AA434D403E2",
                            "oldPassword": "",
                            "newPassword": "Test@1234",
                            "customerNumber": ""
                        }
                    }
                    mockServiceResponse(CONFIG_RESPONSE1)
                    return ReactTestUtils.act(() => {
                        return store.dispatch(resetPasswordDetails(data))
                            .then(() => {
                                const newState1 = store.getState();
                                expect(newState1.resetpsw.resetPswInfo).toStrictEqual(CONFIG_RESPONSE1);
                            });
                    });
                });
        });
    });

});

const CONFIG_RESPONSE = { "statuscode": "200", "statusMessage": "SUCCESS", "object": [{ "section": "default", "companyCode": "IBS", "programCode": "PRG14", "skipPinChangeReminder": true, "defaultCurrency": "USD", "defaultPasswordRegex": "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$", "tiers": [{ "name": "Blue", "code": "BLU", "order": "1", "upgradeExpiryInMonths": "12", "downgradeExpiryInMonths": "12" }, { "name": "Silver", "code": "SIL", "order": "2", "upgradeExpiryInMonths": "12", "downgradeExpiryInMonths": "12" }, { "name": "Gold", "code": "GOL", "order": "3", "upgradeExpiryInMonths": "12", "downgradeExpiryInMonths": "12" }, { "name": "Platinum", "code": "PLT", "order": "4", "upgradeExpiryInMonths": "12", "downgradeExpiryInMonths": "12" }, { "name": "Diamond", "code": "DIA", "order": "5", "upgradeExpiryInMonths": "12", "downgradeExpiryInMonths": "12" }], "currencies": [{ "code": "HKD", "name": "Hong Kong Dollar" }, { "code": "HKD", "name": "Hong Kong Dollar" }, { "code": "TWD", "name": "New Taiwan Dollar" }, { "code": "PHP", "name": "PESO" }, { "code": "KRW", "name": "South Korean Won" }, { "code": "USD", "name": "US Dollar" }, { "code": "VND", "name": "Vietnam Don" }, { "code": "JPY", "name": "Yen" }, { "code": "CNY", "name": "Yuan Renminbi" }], "partners": [{ "value": "KE", "name": "Korean Air" }, { "value": "DL", "name": "Delta Airlines" }, { "value": "EY", "name": "Etihad Airways" }], "cabinClasses": { "KE": [{ "cabinClassCode": "E", "cabinClassName": "Economy" }, { "cabinClassCode": "B", "cabinClassName": "Prestige" }, { "cabinClassCode": "F", "cabinClassName": "First" }] }, "cabinClassBookingClassMapping": { "KE": [{ "cabinClass": "E", "bookingClass": "B" }, { "cabinClass": "B", "bookingClass": "R" }, { "cabinClass": "F", "bookingClass": "F" }] }, "gender": [{ "key": "U", "value": "Unknown" }, { "key": "M", "value": "Male" }, { "key": "F", "value": "Female" }] }] };
const CONFIG_RESPONSE1 = {
    "statuscode": "200",
    "statusMessage": "SUCCESS",
    "object": {
        "membershipNumber": "800004503"
    }
}