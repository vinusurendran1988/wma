import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { withSuspense, isEmptyOrSpaces } from '../../common/utils';
import { connect } from 'react-redux';
import { feedbackDetails } from './actions';
import { fetchConfiguration } from '../../common/middleware/redux/commonAction';
import { CONFIG_SECTION_FEEDBACK } from '../../common/utils/Constants';
import CustomMessage from '../../common/components/custommessage';
import {
  getApiErrorMessage
} from '../../common/utils';
import { 
  getItemFromBrowserStorage, 
  BROWSER_STORAGE_KEY_COMPANY_CODE, 
  BROWSER_STORAGE_KEY_PROGRAM_CODE,
  BROWSER_STORAGE_KEY_MEMBERSHIP_NO
} from '../../common/utils/storage.utils';
import { SENT_FEEDBACK_BTN } from './Constant';
import Button from '../../common/components/fieldbank/Button';
class FeedBack extends Component {
  constructor(props) {
    super(props);
    this.state = {
      serviceType: '',
      serviceDescription: "",
      isEmpty: false,
      success: false,
      match: true,
      reqId: '',
      isServiceDescriptionValid: false
    }
    this.handleChange = this.handleChange.bind(this);
    this.submitFeedBack = this.submitFeedBack.bind(this);
  }

  handleChange(e) {
    if (e.target.name == 'serviceType') {
      this.setState({
        serviceType: e.target.value,
        message: [],
        success: false,
        match: true
      });
    } else {
      let isServiceDescriptionValid = false
      if(e.target.value.trim().length <= e.target.maxLength &&
         e.target.value.trim().length >= e.target.minLength) {
          isServiceDescriptionValid = true
      }
      this.setState({
        serviceDescription: e.target.value,
        message: [],
        success: false,
        match: true,
        isServiceDescriptionValid
      });
    }
  }

  componentDidMount() {
    this.props.setPageInfo(this.props, {config: this.props.configuration, confSection: CONFIG_SECTION_FEEDBACK})
    if (this.props.configuration) {
      this.setState({
        configuration: this.props.configuration,
      });
    } 
  }

  componentDidUpdate(prevProps) {
    if (JSON.stringify(prevProps.feedback) !== JSON.stringify(this.props.feedback)) {
      let data = this.props.feedback;
      if (this.props.feedback.statusMessage == "SUCCESS") {
        let { object } = this.props.feedback;
        this.setState({
          success: true,
          match: true,
          reqId: object.serviceRequestId,
          serviceType: '',
          serviceDescription: "",
          isServiceDescriptionValid: false
        });
      }
      else {
        this.setState({
          match: false,
          success: false,
          message: getApiErrorMessage(data.error)
        });
      }
    }
    if (JSON.stringify(prevProps.configuration) !== JSON.stringify(this.props.configuration)) {
      this.setState({
        configuration: this.props.configuration,
      });
    }
  }

  submitFeedBack() {
    let { configuration } = this.state;
    if (isEmptyOrSpaces(this.state.serviceDescription) || isEmptyOrSpaces(this.state.serviceType)) {
      this.setState({
        isEmpty: true
      });
    }
    else {
      this.setState({
        isEmpty: false
      });
      let payload = {
        "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
        "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
        "membershipNumber": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
        "srType": this.state.serviceType,
        "srCategory": configuration.serviceCategories[0].serviceCategory,
        "descriptionRequest": this.state.serviceDescription,
        "channel": configuration.defaults.channel
      }

      let form_data = new FormData();
      for (var key in payload) {
        form_data.append(key, payload[key]);
      }
      this.props.feedbackDetails(form_data, SENT_FEEDBACK_BTN)
    }

  }

  render() {
    const { configuration } = this.state;
    const { t } = this.props;
    return (
      <div className="col-lg-12 col-md-8 rightSidePanel" data-test="feedbackComponent">
          <div className="form-row">
            <div className="col-12">
              {this.state.isEmpty &&
                <CustomMessage type="danger" message={[t('feedBack.message.psw_empty')]} />
              }
              {
                !this.state.match &&
                <CustomMessage type="danger" message={this.state.message} />
              }
              {this.state.success && <div className="alert alert-success" role="alert"> {t('feedBack.message.psw_success')}  <span className="serviceId">{this.state.reqId}</span>  {t('feedBack.message.psw_success1')}
              </div>
              }
              <h1 id="feedback_title">{t('feedBack.title')}</h1>
              <div className="alert alert-light" role="alert"><i className="fa fa-trophy" aria-hidden="true"></i> <strong>{t('feedBack.strongTitle')}</strong>{t('feedBack.subTitle')}</div>
            </div>
          </div>
          <div className="form-row">
            <div className="col-lg-7">
              <div className="form-row">
                {
                  configuration && configuration.ui.layout.elements.feedback.fields.map((field, index) => {
                    if (field.visibility) {
                      return {
                        "categoryList":
                          <div key={index}
                            className="col-12 ">
                            <div className="form-group">
                              <label htmlFor={field.name}>
                                {t('feedBack.category')}
                                {field.isRequired && <span className="text-warning">*</span>}
                              </label>
                              <select data-test="selectType" className="" name="serviceType" id={field.name} value={this.state.serviceType} onChange={this.handleChange}>
                                <option value={""}>{"-Select Category-"}</option>
                                {configuration ? configuration.serviceCategories[0].serviceTypes.map(o => <option key={o.key} value={o.key}>{o.value}</option>) : ''}
                              </select>
                            </div>
                          </div>,
                        "categoryDescription":
                          field.validation &&
                          <div key={index}
                            className="col-12 ">
                            <div className="form-group">
                              <label htmlFor={field.name}>
                                {t('feedBack.details')}
                                {field.isRequired && <span className="text-warning">*</span>}
                              </label>
                              <textarea data-test="details" id={field.name} maxLength={field.validation.maximumCharacter} minLength={field.validation.minimumCharacter} className="" name="description" placeholder={t('feedBack.provide_details_placeholder')} value={this.state.serviceDescription} onChange={this.handleChange} required></textarea>
                            </div>
                          </div>,
                        "reasonFile":
                          <div key={index}
                            className="col-12 ">
                            <div className="form-group">
                              <label htmlFor={field.name}>
                                {t('feedBack.attachment')}
                                {field.isRequired && <span className="text-warning">*</span>}
                              </label>
                              <input type="file" className="" id={field.name} />
                            </div>
                          </div>
                      }[field.name]
                    }
                  })
                }
                <div className="col-12 text-right buttonWrap">
                <Button
                    className="btn btn-primary" 
                    handleOnClick={() => this.submitFeedBack()} 
                    id={SENT_FEEDBACK_BTN} 
                    data-test="submit-button" 
                    enabled={!(!this.state.isServiceDescriptionValid || isEmptyOrSpaces(this.state.serviceType))}
                    label={t("feedBack.submit")} />
                </div>
              </div>
            </div>
            <div className="col-lg-5">
              <div className="enrollmentFeatures">
                <ul className="list-group list-group-flush">
                  <li className="list-group-item"><i className="fa fa-check" aria-hidden="true"></i> {t('feedBack.description1')}<br/>{t('feedBack.description2')}</li>
                </ul>
              </div>
            </div>
          </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  const { language } = state;
  return {
    language,
    feedback: state.feedback.feedBackDetails,
    configuration: state.configurationReducer[CONFIG_SECTION_FEEDBACK]
  }
}
const mapDispatchToProps = {
  feedbackDetails,
  fetchConfiguration
}


export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(FeedBack)));