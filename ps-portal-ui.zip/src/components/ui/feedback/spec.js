import React, { Suspense } from 'react';
import FeedBack from './index';
import { findByTestAttr, findComponent } from '../../common/testUtils';
import { testStore } from '../../common/utils';
import moxios from 'moxios';
import { mount, shallow } from 'enzyme';
import ReactTestUtils from 'react-dom/test-utils';
import { mockServiceResponse } from '../../common/testUtils'
import { feedbackDetails } from './actions'
import {
    fetchConfiguration
} from '../../common/middleware/redux/commonAction';
import {
    CONFIG_SECTION_FEEDBACK
} from '../../common/utils/Constants';

let store
let rootComponent;
let component;

const setUp = (props = {}) => {
    store = testStore({})
    rootComponent = mount(<FeedBack {...props} store={store} />);
    component = findComponent(rootComponent, 'FeedBack');
};

describe('feedback Component', () => {

    beforeEach(() => {
        setUp({});
        moxios.install();
        component.setState({
            serviceType: 'CMD',
            serviceDescription: "",
            isEmpty: false,
            success: false,
            match: true,
            reqId: ''
        });
        window.sessionStorage.setItem('companyCode', 'IBS');
        window.sessionStorage.setItem('programCode', 'PRG14');
        window.sessionStorage.setItem('membershipNumber', 'IM0008010415');
    });

    afterEach(() => {
        moxios.uninstall();
    });
    it('feedback: Fetch configuration for forgot password and render without errors', () => {
        mockServiceResponse(CONFIG_RESPONSE)
        return ReactTestUtils.act(() => {  
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_FEEDBACK))
            .then(() => { 
                const newState = store.getState();
                expect(newState.configurationReducer.servicerequest).toStrictEqual(CONFIG_RESPONSE.object);

                const ResetComponent = findByTestAttr(component, 'feedbackComponent');
                expect(ResetComponent.length).toBe(1);

                rootComponent = rootComponent.update()
                component = findComponent(rootComponent, 'FeedBack');
                const valueBlur = findByTestAttr(component, 'selectType')
                expect(valueBlur.length).toBe(1);
                valueBlur.simulate('change');

                rootComponent = rootComponent.update()
                component = findComponent(rootComponent, 'FeedBack');
                const value = findByTestAttr(component, 'details')
                expect(value.length).toBe(1);
                value.simulate('change', { target: { value: 'testing description', maxLength: 50, minLength: 1 } });

                rootComponent = rootComponent.update()
                const instance4 = component.instance();
                instance4.forceUpdate();
                component.setState({
                serviceDescription: ''
                });
                instance4.submitFeedBack();
                expect(component.state('isEmpty')).toStrictEqual(
                true
                );

                component.setState({
                    serviceDescription: 'abcdef'
                });
                rootComponent = rootComponent.update()
                component = findComponent(rootComponent, 'FeedBack');
                const value2 = findByTestAttr(component, 'submit-button')
                expect(value2.length).toBe(1);
                value2.simulate('click');
                let data = {
                    "companyCode": "IBS",
                    "programCode": "PRG14",
                    "membershipNumber": "IM0008010603",
                    "srType": "PN",
                    "srCategory": "Member Services",
                    "descriptionRequest": "Feedback details",
                    "channel": "W"
                };
                mockServiceResponse(CONFIG_RESPONSE1)
                return ReactTestUtils.act(() => {
                    return store.dispatch(feedbackDetails(data))
                        .then(() => {
                            const newState1 = store.getState();
                            //console.log(newState1);
                            expect(newState1.feedback.feedBackDetails).toStrictEqual(CONFIG_RESPONSE1);
                        });
                });
            });
        });
    });
});

const CONFIG_RESPONSE = {"statuscode":"200","statusMessage":"SUCCESS","object":{"section":"servicerequest","companyCode":"IBS","programCode":"PRG14","channel":"W","serviceCategories":[{"serviceCategory":"Member Services","serviceTypes":[{"type":"CMD","name":"Change Member Details"},{"type":"PN","name":"PNR"},{"type":"BP","name":"Purchase of Miles"},{"type":"ME","name":"Member Enrollment"},{"type":"MU","name":"Mileage Adjustments"}]}],"ui":{"layout":{"order":["feedback"],"elements":{"feedback":{"fields":[{"name":"categoryList","id":"id-select-category","visibility":true,"isRequired":true},{"name":"categoryDescription","id":"id-email","visibility":true,"isRequired":true,"validation":{"minimumCharacter":1,"maximumCharacter":500,"customMessageId":"forgotpsw.message.enter-valid-email_address"}},{"name":"reasonFile","id":"id-file","visibility":true,"isRequired":true}]}}}}}};
const CONFIG_RESPONSE1={"statuscode":"200","statusMessage":"SUCCESS","object":{"serviceRequestId":"SR197"}};