import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { withSuspense, isPatternMatch, isEmptyOrSpaces } from '../../common/utils';
import { CONFIG_SECTION_REFERRAL, HTTP } from '../../common/utils/Constants';
import {
    fetchConfiguration
} from '../../common/middleware/redux/commonAction'
import { connect } from 'react-redux';
import { _URL_REFFERAL, _URL_FB_REFERRAL, _URL_TWITTER_REFERRAL, _IMAGE_BASEURL } from '../../common/config/config';
import {
    getItemFromBrowserStorage,
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
} from '../../common/utils/storage.utils';
import CustomMessage from '../../common/components/custommessage';
import Button from '../../common/components/fieldbank/Button';
import FieldBank from '../../common/components/fieldbank';
import {
    referral,
} from './actions';
import {
    ID_SEND_BUTTON,ID_CANCEL_BUTTON
} from './Constants'
/**
 * Referral class.
 * @description To send referral to multiple users via email/social media.
 * @author Somdas M
 */
class Referral extends Component {

    constructor(props) {
        super(props)
        this.state = {
            url: _URL_REFFERAL.replace("{memNo}", getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)),
            emailList: [],
            data: {},
            error: {},
            message: [],
            remember: false,
            validationObj: {}
        }
        this.handleChange = this.handleChange.bind(this)
        this.handleKeyDown = this.handleKeyDown.bind(this)
        this.handleDelete = this.handleDelete.bind(this)
        this.mailTo = this.mailTo.bind(this)
        //this.handleRememberChange = this.handleRememberChange.bind(this)
    }

    componentDidMount() {
        this.props.setPageInfo(this.props, { config: this.props.config, confSection: CONFIG_SECTION_REFERRAL })
    }
    componentDidUpdate(prevProps, prevState) {
        let apiResponseMsg = [];
        if (prevProps.referralDataError != this.props.referralDataError) {
            this.setState({
                //message: this.props.referralDataError.error,
                message: ['referral.sent_mail_failed_message'],
                isSuccessMessage: false
            })
        }
        else if (prevProps.referralData != this.props.referralData) {
            this.setState({
                message: ['referral.sent_mail_success_message'],
                isSuccessMessage: true,
                data: {},
                validationObj: {},
                emailList: [],
                error: {},
            })
        }     
    }

    handleChange(fieldName, value, validation) {
        let { data, error } = this.state
        data[fieldName] = value
        if (value.length > 0 && !isPatternMatch(validation.pattern, value)) {
            if (!error[fieldName]) {
                error[fieldName] = true
            }
            this.setState({
                validationObj: {
                    ...this.state.validationObj,
                    [fieldName]: validation.customMessageId
                }
            })
        } else {
            error[fieldName] = false
        }
        this.setState({
            data,
            error,
            message: [],
        })

    }

    handleKeyDown(fieldName, e, validation, maximumAllowedValues,minimumAllowedValues) {
        if (['Enter', 'Tab', ','].includes(e.key)) {
            let { data, emailList, error} = this.state          
            let isError = true
            if (data[fieldName]) {
                if (isPatternMatch(validation.pattern, data[fieldName])) {
                    e.preventDefault();
                    var email = data[fieldName].trim();
                    if (email && !emailList.includes(email)) {
                        isError = false
                        data[fieldName] = '',
                            error[fieldName] = false
                        if (emailList.length < maximumAllowedValues) {
                            this.setState({
                                emailList: [...emailList, email],
                                data,
                                error,
                                minimumAllowedValues
                            });
                        } else {
                            this.setState({
                                message: ['referral.max_limit_exceed_msg']
                            })
                        }
                    }
                }
                if (isError) {
                    error[fieldName] = true
                    this.setState({
                        error
                    })
                }
            }
        }
    }
    handleDelete(removeEmail) {
        this.setState({
            emailList: this.state.emailList.filter(email => email !== removeEmail),
            message: []
        });
    }

    // handleRememberChange(e){
    //     this.setState({
    //         remember:  !this.state.remember
    //     })
    // }
    onCancel(){
        this.setState({
            message: [],
            data: {},
            validationObj: {},
            emailList: [],
            error: {},
        })
    }

    
    render() {
        const { t, config } = this.props
        const { url, data, emailList, error, isSuccessMessage } = this.state
        let registerUrl = url
        if (!registerUrl.startsWith(HTTP)) {
            registerUrl = window.location.origin + window.location.pathname + registerUrl
        }

        return (
            <>
                <div className="title title--page">
                    <h1 id="referral_title">{t("referral.title")}</h1>
                </div>
                <CustomMessage message={this.state.message} type={isSuccessMessage ? "success" : "danger"} canTranslate={true} />
                <div className="row">
                    <div className="col-md-7">
                        <div className="share-friends">
                            <h2>{t("referral.subTitle")}</h2>
                            <div className="form-row">
                                {
                                    config && config.ui && config.ui.layout && config.ui.layout.order &&
                                    config.ui.layout.order.map((layout) => {
                                        const section = config.ui.layout.elements[layout]
                                        if (section) {
                                            const { fields } = section
                                            return fields.map((field, index) => {
                                                if (field.visibility) {
                                                    return (                                                 
                                                        <FieldBank
                                                            field={{
                                                                value: data[field.name],
                                                                key: `referral-form-${index}`,
                                                                itemList: emailList,
                                                                label: t(`form.${field.name}.label`),
                                                                placeholder: t(`form.${field.name}.${field.isMultipleValueAllowed?'placeholderMultiple':'placeholder'}`),
                                                                handleKeyDown: (e) => this.handleKeyDown(field.name, e, field.validation, field.maximumAllowedValues,field.minimumAllowedValues),
                                                                handleDelete: (e) => this.handleDelete(e),
                                                                onChange: (e) => this.handleChange(field.name, e, field.validation),
                                                                error: error[field.name],
                                                                enabled: field.visibility,
                                                                ...field
                                                            }}
                                                            className="col-lg-12"
                                                        />
                                                    );
                                                }
                                            })
                                        }
                                    })
                                }

                            </div>
                            <div className="form-row">
                                <div className="col-12 buttonWrap">
                                    <div className="form-row">
                                        <div className="col-lg-7 col-md-12 buttonLeftTxt">
                                            {/* <div className="form-check form-check-inline">
                                                <input className="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1" checked={remember} onChange={this.handleRememberChange} data-test="rememberDays"/>
                                                <label className="form-check-label" htmlFor="inlineCheckbox1">{t('referral.rememnber_after_seven_days')}</label>
                                            </div> */}
                                        </div>                   
                                        <div className="col-lg-5 col-md-12 text-right btn-wrap btn-wrap--grp">
                                            <Button
                                                className="btn btn-secondary"
                                                handleOnClick={() => this.onCancel()}
                                                id={ID_CANCEL_BUTTON}
                                                testIdentifier="btnCancel"
                                                enabled={!(((emailList.length == 0) && (isEmptyOrSpaces(data.referralEmail))) && isEmptyOrSpaces(data.referralDescription))}
                                                label={t("enrolment.btn_cancel")} />

                                            <Button
                                                className="btn btn-primary"
                                                handleOnClick={this.mailTo}
                                                id={ID_SEND_BUTTON}
                                                data-test="btnInvite"
                                                enabled={!(((emailList.length == 0) && (isEmptyOrSpaces(data.referralEmail))) || isEmptyOrSpaces(data.referralDescription))}
                                                label={t('referral.send')} />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {
                                config && config.ui && config.ui.canShareInSocialMedia &&
                                <>
                                    <hr />
                                    <h2>{t("referral.share_on_social_media")}</h2>
                                    <div className="form-row">
                                        <div className="col-12">
                                            <div className="social-share">
                                                <div className="description">
                                                    <p>{t("referral.shareDesc")}</p>
                                                </div>
                                                <div className="btn-wrap btn-social">
                                                    {
                                                        config && config.socialLoginTypes &&
                                                        config.socialLoginTypes.map((type, index) => {
                                                            return {
                                                                "facebook": <button key={`social-media-${index}`} onClick={(e) => window.open(_URL_FB_REFERRAL + registerUrl, '_blank')} className="btn btn-fb mr-1"><i className="fa fa-facebook"></i>{t("referral.shareByFb")}</button>,
                                                                "twitter": <button onClick={(e) => window.open(_URL_TWITTER_REFERRAL + registerUrl, '_blank')} className="btn btn-tw"><i className="fa fa-twitter"></i>{t("referral.shareByTw")}</button>
                                                            }[type]
                                                        })
                                                    }
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </>
                            }

                        </div>
                    </div>

                    <div className="col-md-5">
                        <div className="listing listing--refferal">
                            <h3>{t("referral.referrer.title")}</h3>
                            <ul>
                                <li>
                                    <div className="thumb">
                                        <img src={`${_IMAGE_BASEURL}/reffer-1.png`} alt="thumb" />
                                    </div>{t("referral.referrer.step_one")}
                                </li>
                                <li><div className="thumb">
                                    <img src={`${_IMAGE_BASEURL}/reffer-2.png`} alt="thumb" />
                                </div>{t("referral.referrer.step_two")}</li>
                                <li><div className="thumb">
                                    <img src={`${_IMAGE_BASEURL}/reffer-3.png`} alt="thumb" />
                                </div>{t("referral.referrer.step_three")}</li>
                            </ul>
                        </div>
                        <div className="listing listing--refferal">
                            <h3>{t("referral.referee.title")}</h3>
                            <ul>
                                <li><div className="thumb">
                                    <img src={`${_IMAGE_BASEURL}/reffer-4.png`} alt="thumb" />
                                </div>{t("referral.referee.step_one")}</li>
                                <li><div className="thumb">
                                    <img src={`${_IMAGE_BASEURL}/reffer-5.png`} alt="thumb" />
                                </div>{t("referral.referee.step_two")}</li>
                                <li><div className="thumb">
                                    <img src={`${_IMAGE_BASEURL}/reffer-6.png`} alt="thumb" />
                                </div>{t("referral.referee.step_three")}</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </>
        );
    }

    mailTo() {
        const { validationObj, error, data, emailList,minimumAllowedValues } = this.state
        const {t}= this.props
        let ErrorMessages = [];
        Object.keys(error).map(function (key) {
            if (error[key]) {
                ErrorMessages.push(validationObj[key])
            }
        });
        if (ErrorMessages.length > 0) {
            this.setState({
                message: ErrorMessages,
                isSuccessMessage: false
            })
        }else if(emailList.length>0 && emailList.length<minimumAllowedValues){
            this.setState({
                message: [t('referral.min_limit_msg')+" "+minimumAllowedValues],
                isSuccessMessage: false
            })
        }        
        else {
            const payload = {
                "object": {
                    "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                    "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                    "membershipNumber": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                    "referreeEmailId": emailList.length > 0 ? emailList : data["referralEmail"],
                    "remarks": data["referralDescription"],
                    "referreeName": "",
                    "refereePhone": ""
                }
            }
            this.props.referral(payload,ID_SEND_BUTTON);
        }
    }
}

function mapStateToProps(state) {
    return {
        config: state.configurationReducer[CONFIG_SECTION_REFERRAL],
        referralData: state.referralDataReducer.referralData,
        referralDataError: state.referralDataReducer.referralDataError

    }
}

const mapDispatchToProps = { fetchConfiguration, referral }

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(Referral)));