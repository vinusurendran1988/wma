import React from 'react';
import { testStore } from '../../common/utils';
import moxios from 'moxios';
import { mount } from 'enzyme';
import {
    findByTestAttr,
    findComponent,
    mockServiceResponse
} from '../../common/testUtils';
import Referral from './index'
import ReactTestUtils from 'react-dom/test-utils';
import { Provider } from 'react-redux'
import {
    fetchConfiguration
} from '../../common/middleware/redux/commonAction'
import { CONFIG_SECTION_REFERRAL } from '../../common/utils/Constants';

let store;
let rootComponent;
let component;

const setUpReferral = (props = {}) => {
    store = testStore({})
    rootComponent = mount(<Provider store={store}>
        <Referral {...props} store={store} />
    </Provider>);
    component = findComponent(rootComponent, 'Referral');
};

describe('Referral Page: Render', () => {
    beforeEach(() => {
        store = undefined
        setUpReferral({});
        moxios.install();
    });


    afterEach(() => {
        moxios.uninstall();
    });

    it('Should render without errors ', () => {
        rootComponent = rootComponent.update()
        component = findComponent(rootComponent, 'Referral');
        mockServiceResponse(CONFIG_RESPONSE)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_REFERRAL))
                .then(() => {
                    let newState = store.getState()
                    expect(newState.configurationReducer[CONFIG_SECTION_REFERRAL]).toBe(CONFIG_RESPONSE.object)

                    rootComponent = rootComponent.update()
                    component = findComponent(rootComponent, 'Referral');

                    const referralComponent = findByTestAttr(component, 'referralComponent');
                    expect(referralComponent.length).toBe(1);

                    const referralEmail = findByTestAttr(component, 'referralEmail');
                    expect(referralEmail.length).toBe(1);
                    referralEmail.simulate('change',{target:{value:'test'}})
                    referralEmail.simulate('keyDown',{key:"Enter"})
                    referralEmail.simulate('change',{target:{value:'test@test.com'}})
                    referralEmail.simulate('keyDown',{key:"Enter"})

                    rootComponent = rootComponent.update()
                    component = findComponent(rootComponent, 'Referral');

                    const deleteBtn = findByTestAttr(component, 'deleteBtn');
                    expect(deleteBtn.length).toBe(1);
                    deleteBtn.simulate('click')

                    const rememberDays = findByTestAttr(component, 'rememberDays');
                    expect(rememberDays.length).toBe(1);
                    rememberDays.simulate('change')
                })
        })
    })
})

const CONFIG_RESPONSE = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "section": "referral", "companyCode": "IBS", "programCode": "PRG14", "socialLoginTypes": ["facebook", "twitter"], "ui": { "layout": { "order": ["referralCard"], "elements": { "referralCard": { "fields": [{ "name": "referralEmail", "id": "id-email", "visibility": true, "isRequired": true, "validation": { "pattern": "\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$", "customMessageId": "referral.Enter_valid_mail_address" } }, { "name": "referralDescription", "id": "id-details", "visibility": true, "isRequired": true, "minimumCharacter": 200, "maximumCharacter": 500 }] } } } } } }

