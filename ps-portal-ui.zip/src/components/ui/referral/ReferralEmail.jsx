import React from 'react'
import { withTranslation } from 'react-i18next';
import { withSuspense } from '../../common/utils';


class ReferralEmail extends React.Component {

    render() {
        const {t, field } = this.props
        return (
                <div className="form-group">
                    <label htmlFor={field.id}>{t(field.label)}{field.isRequired && <span className="text-warning">*</span>}</label>
                    <input
                        className={""+(field.hasError?" is-invalid":"")}
                        id={field.id}
                        placeholder={t(field.placeholder)}
                        type="text"
                        value={field.value}
                        onChange={(e)=>this.props.field.onChange(e.target.value)}
                        onKeyDown={field.isMultipleValueAllowed?this.props.field.handleKeyDown:""}
                        data-test={field.name}
                    />
                    {field.isMultipleValueAllowed && field.itemList.map(email => (
                        <div className="tag-item email-chip" key={email}>
                            {email}
                            <button
                                type="button"
                                className="close-button"
                                onClick={() => this.props.field.handleDelete(email)}
                                data-test="deleteBtn">
                                &times;
                          </button>
                        </div>
                    ))}
                </div>
        )
    }
}

export default withSuspense()(withTranslation()(ReferralEmail));