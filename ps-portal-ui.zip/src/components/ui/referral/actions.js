import {
  _URL_REFERRAL,
} from '../../common/config/config'

import { 
  startButtonSpinner, 
  stopButtonSpinner
} from '../../common/components/fieldbank/loader/action';
import { doPost } from '../../common/utils/api'
import {
  getApiErrorMessage
} from '../../common/utils'
// Action Type

import {
  SET_LOGIN_DATA,SET_SOCIAL_LOGIN_DATA,REFERRAL_DATA,REFERRAL_ERROR,REFERRAL_API_REFERENCE
} from './Constants'
var jwtDecode = require('jwt-decode');

/**
 * Social Media login 
 * @param {*} payload 
 */
export const SocialMediaLoginDetails = (payload) => {
  return dispatch => {
    // doPost(_URL_LOGIN_DETAILS, payload);
    // localStorage.setItem("token","eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxIiwiY2xpZW50SWQiOiJhdXRoLWNoYW5uZWwiLCJzZWNyZXQiOiJfREhGSFNHRFNGRFNEQVEiLCJpYXQiOjE1OTQwOTgzNzcsImV4cCI6MTU5NDE4NDc3N30.YQov0_phpKa5ZmfM_2l3Cj-eNTJknYeOa6vBjEhVf1GbIpgcB4ibWWDXNVyNAiWQmHqyvYP-a14Ub7ImptetQw");
    dispatch({
      type: SET_SOCIAL_LOGIN_DATA,
      payload: payload
    })
  };
}


/**
 * Creates Action of type <i>_URL_FETCH_PROFILE_DETAILS</i> with given data
 *
 * @function Referral
 * @param {object} payload Object to be passed as data in Action
 *
 */
 export const referral = (payload, id) => {
  return async dispatch => {
    dispatch(startButtonSpinner(id, REFERRAL_API_REFERENCE))
    await doPost(_URL_REFERRAL, payload)
    .then((response) => {
        dispatch(stopButtonSpinner(id, REFERRAL_API_REFERENCE))
        dispatch({
            type: REFERRAL_DATA,
            payload: response.data
        })
    })
    .catch((error) => {
        dispatch(stopButtonSpinner(id, REFERRAL_API_REFERENCE))
        dispatch({
            type: REFERRAL_ERROR,
            payload: {error: getApiErrorMessage(error.response.data.error)}
        })
    })
  };
}