import { mount } from 'enzyme';
import * as actions from './action';
import * as reducers from './reducer';
import AddFamilyMember from './index';
import { Provider } from 'react-redux';
import { testStore } from '../../common/utils';
import React from 'react';
import moxios from 'moxios';
import configureMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import {
  searchMember
} from './action'
import {
  mockServiceResponse,
} from '../../common/testUtils'
import ReactTestUtils from 'react-dom/test-utils';
import { CONFIG_SECTION_MYFAMILY } from '../../common/utils/Constants';
import { fetchConfiguration } from '../../common/middleware/redux/commonAction';

const middlewares = [thunk];
const mockStore = configureMockStore(middlewares);
var store = testStore({})

const findFamilyMemberAction = {
  type: 'NEW_FAMILY_MEMBER_SEARCH',
  payload: {
    statuscode: '200',
    object: {
      firstName: 'Mike',
      surname: 'Cook',
      secondName: '',
      membershipStatus: 'Active',
      accountStatus: 'Active',
      tierCode: 'BLU',
      tierName: 'Blue',
      mobileISDCode: '',
      mobileAreaCode: '',
      mobileNumber: '',
      dateOfBirth: '16-Apr-1995',
      emailAddress: 'mike-cook@test.com',
      membershipNumber: 'IM0008010244'
    }
  }
}

const populateFamilyMembersAction = {
  type: 'SET_FAMILY_MEMBERS',
  payload: []
}

const familyMember = {
  membershipNumber: 'IM0000000335',
  displayName: 'MR KHAYALI ABDAL',
  relationship: 'Others',
  dateOfBirth: '21-Jul-2004',
  emailAddress: 'kayali.abdul@aol.com',
  nomineeStatus: 'Active',
  tierCode: 'BLU',
  tierName: 'Blue',
  expiryDetails: [
    {
      pointType: 'FS',
      points: 2,
      expiryDate: '02-Jan-2021'
    },
    {
      pointType: 'TIER',
      points: 8700,
      expiryDate: '02-Jan-2021'
    },
    {
      pointType: 'TIER',
      points: 3400,
      expiryDate: '05-Jan-2021'
    },
    {
      pointType: 'TIER',
      points: 7000,
      expiryDate: '06-Jan-2021'
    },
    {
      pointType: 'FS',
      points: 1,
      expiryDate: '06-Jan-2021'
    },
    {
      pointType: 'BASE',
      points: 19100,
      expiryDate: '31-Jan-2023'
    },
    {
      pointType: 'BONUS',
      points: 5175,
      expiryDate: '31-Jan-2023'
    },
    {
      pointType: 'BASE',
      points: 1000,
      expiryDate: '28-Jun-2023'
    },
    {
      pointType: 'BASE',
      points: 1000,
      expiryDate: '30-Jun-2023'
    },
    {
      pointType: 'BASE',
      points: 1000,
      expiryDate: '19-Jul-2023'
    },
    {
      pointType: 'BASE',
      points: 1000,
      expiryDate: '21-Jul-2023'
    }
  ],
  pointDetails: [
    {
      pointType: 'BASE',
      pointTypeGroup: 'Total Miles',
      totalAccuredpoints: 26500,
      totalRedeemedpoints: 3400,
      pointsToNextTier: 0,
      pointsForTierRetention: 0,
      points: 23100,
      bonusDetails: [],
      creditLimit: 0
    },
    {
      pointType: 'BONUS',
      pointTypeGroup: 'Total Miles',
      totalAccuredpoints: 7575,
      totalRedeemedpoints: 2400,
      pointsToNextTier: 0,
      pointsForTierRetention: 0,
      points: 5175,
      bonusDetails: [],
      creditLimit: 0
    },
    {
      pointType: 'TIER',
      pointTypeGroup: 'Qualifying Miles',
      totalAccuredpoints: 22500,
      totalRedeemedpoints: 3400,
      pointsToNextTier: 0,
      pointsForTierRetention: 0,
      points: 19100,
      bonusDetails: [],
      creditLimit: 0
    },
    {
      pointType: 'TIERKE',
      pointTypeGroup: 'Qualifying Miles',
      totalAccuredpoints: 0,
      totalRedeemedpoints: 0,
      pointsToNextTier: 0,
      pointsForTierRetention: 0,
      points: 0,
      bonusDetails: [],
      creditLimit: 0
    },
    {
      pointType: 'FS',
      pointTypeGroup: 'Qualifying Segments',
      totalAccuredpoints: 3,
      totalRedeemedpoints: 0,
      pointsToNextTier: 0,
      pointsForTierRetention: 0,
      points: 3,
      bonusDetails: [],
      creditLimit: 0
    },
    {
      pointType: 'FC',
      pointTypeGroup: 'Qualifying Segments',
      totalAccuredpoints: 0,
      totalRedeemedpoints: 0,
      pointsToNextTier: 0,
      pointsForTierRetention: 0,
      points: 0,
      bonusDetails: [],
      creditLimit: 0
    }
  ],
  activeNominee: true
}

const addFamilyMemberAction = JSON.parse(JSON.stringify(findFamilyMemberAction));
addFamilyMemberAction.type = 'ADD_FAMILY_MEMBER';

for (let i = 0; i < 7; i++) {
  populateFamilyMembersAction.payload.push(JSON.parse(JSON.stringify(familyMember)))
}

describe("action", () => {
  beforeEach(() => {
    moxios.install();
  })
  afterEach(() => {
    moxios.uninstall();
  });
  it('searchMember: should not returnany error', () => {
    let data = { "statuscode": "200", "object": { "firstName": "Prithviraj", "surname": "Sukumaran", "secondName": "", "membershipStatus": "Active", "accountStatus": "Active", "tierCode": "BLU", "tierName": "Blue", "mobileISDCode": "+91", "mobileAreaCode": "", "mobileNumber": "1982347563", "dateOfBirth": "22-Jul-1993", "emailAddress": "ps-test-001@loyalty.com", "membershipNumber": "IM0008010415" } }
    mockServiceResponse(data, 200)
    return ReactTestUtils.act(() => {
      return store.dispatch(searchMember({ "test": "test" }, false))
        .then(() => {
          const newState = store.getState();
          expect(newState.newFamilyMemberSearchReducer.tierChart).toBe(data.object);
        })
    });
  })
})

describe('component', () => {
  beforeAll(() => {
    const div = document.createElement('div');
    window.domNode = div;
    document.body.appendChild(div);
  })
  beforeEach(() => moxios.install());
  afterEach(() => moxios.uninstall());
  test('render the component', () => {
    let store = testStore({});

    mockServiceResponse(familyConfiguration, 200)
    return store.dispatch(
      fetchConfiguration(CONFIG_SECTION_MYFAMILY)
    ).then(() => {
      let wrapper = mount(
        <Provider store={store}>
          <AddFamilyMember />
        </Provider>
        , { attachTo: window.domNode })
      wrapper.setProps({
        userInfo: { emailAddress: "", membershipNumber: "" }
      })
      wrapper = wrapper.update()
      let select = wrapper.find('select');
      expect(select.instance().value).toEqual('search_by_email')
      // console.log(select.debug()); 
      select.simulate('change', { target: { value: 'search_by_member_number' } });
      wrapper = wrapper.update();
      select = wrapper.find('select');
      expect(select.instance().value).toEqual('search_by_member_number');
      // console.log("select:::::::::: ",select.debug())

      // console.log(wrapper.find('AddFamilyMember').state())

      // console.log("wrapper::::::::::::: ", wrapper.debug());

      let search = wrapper.find('input[type="text"]');
      // console.log("search::::::::::::::::", search.debug())
      // expect(search.instance().placeholder).toEqual('Membership Number')
      search.simulate('change', { target: { value: 'IM0008010244' } });
      wrapper = wrapper.update();
      let check = wrapper.find('button[className="btn btn-outline-primary mt-4"]');
      check.simulate('click');
      wrapper = wrapper.update();

      wrapper.prop('store').dispatch(findFamilyMemberAction);
      wrapper = wrapper.update();

      let submit = wrapper.find('button[type="button"][testid="submit"]')
      // console.log(submit.debug())
      submit.simulate('click');
      wrapper = wrapper.update();

      wrapper.prop('store').dispatch(populateFamilyMembersAction);
      wrapper = wrapper.update();

      wrapper.prop('store').dispatch({ type: 'ADD_FAMILY_MEMBER_ERROR', payload: { error: ['error message'] } });
      wrapper = wrapper.update();

      wrapper.prop('store').dispatch(addFamilyMemberAction);
      wrapper = wrapper.update();

      let navs = wrapper.find('input[type="radio"]');
      navs.at(0).simulate('click')
      navs.at(1).simulate('click')

      // console.log(wrapper.debug())

    })


  })
})

const familyConfiguration = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "section": "family", "companyCode": "IBS", "programCode": "PRG14", "nominee": { "accountGroupType": "F", "maxLimit": 6 }, "relationshipCodes": [{ "code": "F", "value": "Father" }, { "code": "M", "value": "Mother" }, { "code": "S", "value": "Spouse" }, { "code": "B", "value": "Brother" }, { "code": "C", "value": "Children" }, { "code": "E", "value": "Step children" }, { "code": "G", "value": "Grandfather" }, { "code": "N", "value": "Grandmother" }, { "code": "P", "value": "Step parents" }, { "code": "I", "value": "Parents in law" }, { "code": "T", "value": "Sister" }, { "code": "O", "value": "Others" }], "ui": { "pointTypes": { "progress": ["BASE"], "pooling": ["BASE"], "expiry": ["BASE"] }, "tierMapping": [{ "tierName": "Blue", "pointsRequired": 0, "color": "#162953" }, { "tierName": "Silver", "pointsRequired": 10000, "color": "#7f7f7f" }, { "tierName": "Gold", "pointsRequired": 40000, "color": "#97700c" }, { "tierName": "Platinum", "pointsRequired": 70000, "color": "#323232" }, { "tierName": "Diamond", "pointsRequired": 100000, "color": "#0e7baa" }] } } }