import React, { Component } from 'react'
import { withTranslation } from 'react-i18next';
import { withSuspense } from '../../common/utils';
import { connect } from 'react-redux';
import {
    SEARCH_TYPES,
    ID_SEARCH_INPUT,
    ID_SEARCH_TYPE,
    REDIRECT_FAMILY_MEMBERS,
    CANNOT_ADD_FAMILY_MEMBER,
    MEMBER_TYPE,
    ID_ADD_FAMILY_MEMBER_BTN
} from './Constants'

import {
    searchMember,
    addFamilyMember
} from './action'
import {
    fetchConfiguration,
    getFamilyMembers
} from '../../common/middleware/redux/commonAction';
import {
    setFieldInvalid,
    setFieldValid,
} from '../../common/utils'
import { 
    CONFIG_SECTION_MYFAMILY, CONFIG_SECTION_DEFAULT
} from '../../common/utils/Constants';
import CustomMessage from '../../common/components/custommessage';
import { 
    getItemFromBrowserStorage, 
    BROWSER_STORAGE_KEY_COMPANY_CODE, 
    BROWSER_STORAGE_KEY_PROGRAM_CODE, 
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO 
} from '../../common/utils/storage.utils';
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';
import Button from '../../common/components/fieldbank/Button';

class AddFamilyMember extends Component {
    constructor() {
        super();
        this.state = {
            relation: "",
            tabIndex: 0,
            searchType: "search_by_email",
            searchContent: "",
            searchFirstName: "",
            searchResultFirstName: "",
            searchResultLastName: "",
            searchResultDob: "",
            searchMembershipNumber: "",
            isSubmitDisabled: true,
            canAddMember: true,
            errorMessage: [],
            showMessage:false
        }
    }

    componentDidMount() {
        this.props.setPageInfo(this.props, {config: this.props.familyConfig, confSection: CONFIG_SECTION_MYFAMILY})
        if (!this.props.familyMemberDetails || this.props.familyMemberDetails.length == 0) {
            this.props.getFamilyMembers({
                object: {
                    companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                    programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                    membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)
                }
            });
        }
        this.checkIfMaxLimit(this.props.familyConfig, this.props.familyMemberDetails);
    }

    loadInitialRelation() {
        const { defaultConfig } = this.props
        if (defaultConfig) {
            let defaultProgram = getCurrentProgramFromDefaultConfig(defaultConfig)
            if (defaultProgram && defaultProgram.data) {
               return defaultProgram.data.relationshipCodes[0].value
            }
        }
        return ""
    }

    clearFields() {
        this.setState({
            searchResultFirstName: "",
            searchResultLastName: "",
            searchResultDob: "",
            searchMembershipNumber: "",
            errorMessage: [],
            relation: this.loadInitialRelation()
        })
    }

    submit(searchMembershipNumber, relation) {
        const payload = {
            "object": {
                "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                "membershipNumber": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                "nomineeMembershipNumber": searchMembershipNumber,
                "memberType": MEMBER_TYPE,
                "relation": relation
            }
        }
        this.props.addFamilyMember(payload, ID_ADD_FAMILY_MEMBER_BTN)
    }

    componentDidUpdate(prevProps, prevState) {
        const { familyConfig, familyMemberDetails } = this.props
        this.checkIfMaxLimit(familyConfig, familyMemberDetails);

        if (prevProps.searchResult != this.props.searchResult) {
            if(this.props.searchResult.membershipNumber){
                this.submit(this.props.searchResult.membershipNumber, this.state.relation)
            }
            
        }

        if (prevProps.error != this.props.error) {
            setFieldInvalid(ID_SEARCH_INPUT)
            this.setState({
                errorMessage: this.props.error
            })
        }

        if ((prevProps.familyMember != this.props.familyMember) && this.props.familyConfig) {
            this.clearFields()
            const object = {
                companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)
            }
            this.props.getFamilyMembers({object});
            // window.location.href = REDIRECT_FAMILY_MEMBERS
            this.setState({
                showMessage: true
            })
        }

        if (
            prevState.searchContent != this.state.searchContent ||
            prevState.searchFirstName != this.state.searchFirstName ||
            prevState.relation != this.state.relation
        ) {
            if (
                this.state.searchContent && 
                this.state.searchFirstName && 
                this.state.relation
                ) {
                this.setState({ isSubmitDisabled: false })
            } else {
                this.setState({ isSubmitDisabled: true })
            }
        }
    }

    checkIfMaxLimit = (familyConfig, familyMemberDetails) => {
        if (familyConfig && familyMemberDetails &&
            familyConfig.nominee &&
            familyMemberDetails.length >= familyConfig.nominee.maxLimit &&
            this.state.errorMessage[0] != this.props.t("add_family_member." + CANNOT_ADD_FAMILY_MEMBER).replace("{MAX_COUNT}", familyConfig.nominee.maxLimit)) {
            this.setState({
                errorMessage: [this.props.t("add_family_member." + CANNOT_ADD_FAMILY_MEMBER).replace("{MAX_COUNT}", familyConfig.nominee.maxLimit)],
                canAddMember: false
            });
        }
    }

    handleChange(field, e) {
        const fieldId = e.target.id
        if (document.getElementById(ID_SEARCH_INPUT).className.includes("is-invalid")) {
            setFieldValid(ID_SEARCH_INPUT)
        }
        if (this.state.searchMembershipNumber.length > 0 && (fieldId == ID_SEARCH_INPUT || fieldId == ID_SEARCH_TYPE)) {
            this.clearFields()
        }
        this.setState({
            [field]: e.target.value,
            errorMessage: []
        })
    }

    checkIfSameUser() {
        const { userInfo } = this.props
        const { searchContent, searchType } = this.state
        if(userInfo) {
            switch (searchType) {
                case 'search_by_email':
                    return searchContent == userInfo.emailAddress
                case 'search_by_member_number':
                    return searchContent == userInfo.membershipNumber
                default:
                    return false
            }
        }
    }

    verifyUser() {
        if (!this.checkIfSameUser()) {
            const { searchType, searchContent , searchFirstName} = this.state
            const requestBody = {
                object: {
                    companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                    programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                    absoluteIndex: '1',
                    pageSize: '1'
                }
            }

            if(searchType == 'search_by_email'){
                requestBody.object.emailAddress = searchContent
            } else {
                requestBody.object.membershipNumber = searchContent;
            }
            if (searchFirstName) {
                requestBody.object.memberName = searchFirstName;
            }
            this.props.searchMember(requestBody, ID_ADD_FAMILY_MEMBER_BTN)
            this.setState({isSubmitDisabled: true})
        } else {
            this.setState({
                errorMessage: [this.props.t('add_family_member.add_existing_member.self_addition_message')]
            })
        }
    }

    renderRadioButtonView = (t) => {
        return <ul className="radio-wrap">
            <li>
                <input type="radio" id="test1" name="radio-group" checked />
                <label htmlFor="test1">{t('add_family_member.add_existing_member.title')}</label>
            </li>
            <li>
                <input type="radio" id="test2" name="radio-group" disabled={true} />
                <label htmlFor="test2">{t('add_family_member.add_new_member.title')}</label>
            </li>
        </ul>
    }

    renderTabView = (t) =>{
        const { tabIndex } = this.state
        return <nav className="tab">
            <div className="nav nav-tabs nav-tabs--booking" id="nav-tab" role="tablist">
            <a className={`nav-item nav-link active`}
                    id="test1"
                    data-toggle="tab"
                    role="tab"
                    aria-controls={tabIndex} aria-selected='true'>
                    <span>{t('add_family_member.add_existing_member.title')}</span>
            </a>
            <a className={`nav-item nav-link disabled`}
                    id="test2"
                    data-toggle="tab"
                    role="tab"
                    aria-controls={tabIndex} aria-selected='true'>
                    <span>{t('add_family_member.add_new_member.title')}</span>
            </a>
            </div>
        </nav>
    }

    render() {
        const { tabIndex, searchType } = this.state
        const { t, error, defaultConfig, familyConfig } = this.props 
        const isSuccess = error[0] && error[0] === 'add_family_member.add_existing_member.successMessage';
        const canTranslate = error[0] && error[0] === 'add_family_member.add_existing_member.successMessage' ? true : error.length > 0
        let relations = []
        if(defaultConfig ){
            let defaultProgram = getCurrentProgramFromDefaultConfig(defaultConfig)
            if(defaultProgram && defaultProgram.data){
                relations =  defaultProgram.data.relationshipCodes
            }
        }
        return (
            <>
                <div className="title title--page">
                    <h1 id="add_family">{t('add_family_member.title')}</h1>
                </div>
                <div className="row">
                    <div className="col-md-8">
                        <div className="form form--family">
                            <p>{t('add_family_member.description')}</p>
                            <h2>{t('add_family_member.memberinfo')}</h2>
                            {
                                familyConfig && familyConfig.ui && familyConfig.ui.showRadioButtonView ?
                                this.renderRadioButtonView(t) :
                                this.renderTabView(t)
                            }
                            
                            <div className="form-row align-items-end">
                                {
                                    tabIndex == 0 &&
                                    <div className="toggle1">
                                       <div className="step2">

                                            <CustomMessage
                                                type={isSuccess ? "success" : "danger"}
                                                message={this.state.errorMessage}
                                                canTranslate={canTranslate}
                                            />
                                             {this.state.showMessage && <CustomMessage
                                                type="success"
                                                message={[t("my_family.addFamilySuccess")]}
                                                data-test="customMessageComponent" canTranslate={false} />
                                             }

                                            <div className="form-row">
                                                <div className="col-lg-6 col-md-6">
                                                    <div className="form-group">
                                                        <label htmlFor={ID_SEARCH_TYPE}>
                                                            {t("add_family_member.add_existing_member.search_by")}
                                                            <span className="text-warning">*</span>
                                                        </label>
                                                        <select  id={ID_SEARCH_TYPE} disabled={!this.state.canAddMember} value={searchType} onChange={(e) => {
                                                            this.handleChange('searchType', e);
                                                        }}>
                                                            {
                                                                SEARCH_TYPES.map((type) => {
                                                                    return <option key={type} value={type}>{t('add_family_member.add_existing_member.' + type)}</option>
                                                                })
                                                            }
                                                        </select>
                                                    </div>
                                                </div>

                                                <div className="col-lg-6 col-md-6">
                                                    <div className="form-group">
                                                        <label htmlFor={ID_SEARCH_INPUT}>
                                                            {t('add_family_member.add_existing_member.' + searchType)}
                                                            <span className="text-warning">*</span>
                                                        </label>
                                                        <input  className="txt" type="text" placeholder={t('add_family_member.add_existing_member.' + searchType + "_placeholder")} id={ID_SEARCH_INPUT}
                                                            value={this.state.searchContent} disabled={!this.state.canAddMember}
                                                            onChange={(e) => this.handleChange('searchContent', e)}
                                                        />
                                                    </div>
                                                </div>

                                                <div className="col-lg-6 col-md-6">
                                                    <div className="form-group">
                                                        <label
                                                            htmlFor="firstName">
                                                            {t('add_family_member.add_existing_member.first_name')}
                                                            <span className="text-warning">*</span>
                                                        </label>
                                                        <input
                                                            className="txt"
                                                            type="text"
                                                            placeholder={t('add_family_member.add_existing_member.placeholder_first_name')}
                                                            id="firstName"
                                                            value={this.state.searchFirstName}
                                                            disabled={!this.state.canAddMember}
                                                            onChange={(e) => this.setState({ searchFirstName: e.target.value })}
                                                        />
                                                    </div>
                                                </div>

                                                <div className="col-lg-6 col-md-6">
                                                    <div className="form-group">
                                                        <label htmlFor="relationship">
                                                            {t('add_family_member.add_existing_member.relationship')}
                                                            <span className="text-warning">*</span>
                                                        </label>
                                                        <select id="relationship"
                                                            value={this.state.relation}
                                                            disabled={!this.state.canAddMember}
                                                            onChange={(e) =>
                                                                this.setState({
                                                                    relation: e.target.value
                                                                })}
                                                        >
                                                            <option value={""}>{t('fieldbank.dropdown_default_option')}</option>
                                                            {
                                                                relations &&
                                                                relations.map((relation) => {
                                                                    return <option key={relation.key} value={relation.key}>{relation.value}</option>
                                                                })
                                                            }
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="form-row align-items-end">
                                                <div className="col-lg-12 text-lg-right">
                                                    <Button
                                                        className="btn btn-primary"
                                                        handleOnClick={() => this.verifyUser()}
                                                        id={ID_ADD_FAMILY_MEMBER_BTN}
                                                        data-test="submit"
                                                        enabled={!this.state.isSubmitDisabled}
                                                        label={t("add_family_member.add_existing_member.submit_btn")} />
                                                </div>  </div>
                                        </div>
                                    </div>
                                }
                                {
                                    tabIndex == 1 &&
                                    <div className="toggle2">
                                        <div className="step1">

                                            <div className="form-row">
                                                <div className="col-lg-6 col-md-6">
                                                    <div className="form-group">
                                                        <label htmlFor="f1"> First Name</label>
                                                        <input className="" type="text" aria-required="true" placeholder="Default input" id="f1" />
                                                    </div>
                                                </div>
                                                <div className="col-lg-6 col-md-6">
                                                    <div className="form-group">
                                                        <label htmlFor="f1"> Last Name</label>
                                                        <input className="" type="text" aria-required="true" placeholder="Default input" id="f1" />
                                                    </div>
                                                </div>
                                                <div className="col-lg-6 col-md-6">
                                                    <div className="form-group">
                                                        <label htmlFor="f2">Date of Birth</label>
                                                        <input className="" type="text" id="f2" />
                                                    </div>
                                                </div>
                                                <div className="col-lg-6 col-md-6">
                                                    <div className="form-group">
                                                        <label htmlFor="f2">Relationship</label>
                                                        <select className="" id="f1">
                                                            <option>Platinum</option>
                                                            <option>2</option>
                                                            <option>3</option>
                                                            <option>4</option>
                                                            <option>5</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div className="col-lg-6 col-md-6">
                                                    <div className="form-group">
                                                        <label htmlFor="f2">Attach Proof of Relationship</label>
                                                        <input type="file" className="form-control-file" id="exampleFormControlFile1" />
                                                    </div>
                                                </div>

                                            </div>

                                            <div className="form-row">
                                                <div className="col-12 buttonWrap">
                                                    <div className="form-row">

                                                        <div className="col-lg-12 text-lg-right">
                                                            <button type="button" className="btn btn-primary">Submit</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                }
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4">
                        <div className="listing listing--text">
                            <h5>{t('add_family_member.notes.note')}</h5>
                            <ul>
                                <li>{t('add_family_member.notes.notes1')}</li>
                                <li>{t('add_family_member.notes.notes2')}</li>
                                <li>{t('add_family_member.notes.notes3')}</li>
                                <li>{t('add_family_member.notes.notes4')}</li>
                                <li>{t('add_family_member.notes.notes5')}</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </>
        )
    }

}

function mapStateToProps(state) {
    return {
        searchResult: state.newFamilyMemberSearchReducer.tierChart,
        error: state.commonErrorReducer.error,
        familyMember: state.addFamilyMemberReducer,
        userInfo: state.userInfoReducer.userInfo,
        familyConfig: state.configurationReducer[CONFIG_SECTION_MYFAMILY],
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        familyMemberDetails: state.familyListReducer.members
    }
}

const mapDispatchToProps = {
    searchMember,
    addFamilyMember,
    fetchConfiguration,
    getFamilyMembers
}

AddFamilyMember.defaultProps = {
    error: []
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(AddFamilyMember)));