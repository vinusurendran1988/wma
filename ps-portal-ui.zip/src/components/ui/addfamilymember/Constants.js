import { NAVIGATE_FAMILY_POOLING } from "../../common/utils/urlConstants"

export const SEARCH_TYPES = ["search_by_email", "search_by_member_number"]
export const ID_SEARCH_INPUT = "id-search-input"
export const ID_SEARCH_TYPE = "id-search-type"
export const ID_ADD_FAMILY_MEMBER_BTN = "id-add-family-member"
export const REDIRECT_FAMILY_MEMBERS = `#${NAVIGATE_FAMILY_POOLING}`
export const CANNOT_ADD_FAMILY_MEMBER = "max_member_message"
export const EMPTY_VALUE = ""
export const ID_SPINNER_CHECK_USER = "id-spinner-check-user"
export const ID_SPINNER_SUBMIT_FAMILY_MEMBER = "id-spinner-submit-family-member"
export const MEMBER_TYPE = "M"

