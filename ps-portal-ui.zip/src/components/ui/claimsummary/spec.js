import React from 'react';
import ClaimSummary from './index';
import { findByTestAttr, findComponent, } from '../../common/testUtils/index';
import { testStore } from '../../common/utils';
import moxios from 'moxios';
import { mount } from 'enzyme';
import ReactTestUtils from 'react-dom/test-utils';
import { retrieveRetroClaimRequests } from './actions';
import { Provider } from 'react-redux';
import { Button } from 'primereact/button';
import { CONFIG_SECTION_CLAIMMILES } from '../../common/utils/Constants';
import { fetchConfiguration } from '../../common/middleware/redux/commonAction';


let store = undefined
let rootComponent;
let component;
let storeState

const setUp = (props = {}) => {
    rootComponent = mount(
        <Provider store={store}>
            <ClaimSummary {...props} />
        </Provider>
    );
    component = findComponent(rootComponent, 'ClaimSummary');
};

describe('ClaimSummary Component', () => {

    beforeEach(() => {
        store = undefined
        store = testStore({})
        moxios.install();
    });

    describe('Service call', () => {
        beforeEach(() => {
            moxios.install();
        });

        afterEach(() => {
            moxios.uninstall();
        });


        test('Failure', () => {
            moxios.wait(() => {
                const request = moxios.requests.mostRecent();
                request.respondWith({
                    status: 400,
                    response: {
                        "statuscode": "400",
                        "statusMessage": "FAILURE",
                        "error": {
                            "code": "400",
                            "type": "BAD_REQUEST",
                            "message": "Invalid input received",
                            "errorDetails": [
                                {
                                    "field": "object.companyCode",
                                    "message": "Company code cannot be empty"
                                }
                            ]
                        }
                    }
                });
            });
            return ReactTestUtils.act(() => {
                return store.dispatch(
                    retrieveRetroClaimRequests({
                        attr: "attr1String"
                    })
                )
                    .then(() => {
                        storeState = store.getState();
                        expect(storeState.retroClaimRequestsReducer.retrievedRetroClaimRequests).toBeUndefined();
                    });
            });
        });

        test('Success', () => {
            mockServiceCallResponse(data1);
            return ReactTestUtils.act(() => {
                return store.dispatch(
                    retrieveRetroClaimRequests({
                        attr: "attr1String"
                    })
                )
                    .then(() => {
                        storeState = store.getState();
                        expect(storeState.retroClaimRequestsReducer.retrievedRetroClaimRequests).toBe(data1.object);
                    });
            });
        });

    })

    describe('Rendering', () => {
        beforeEach(() => {
            store = undefined
            store = testStore({})
            moxios.install();
        });

        afterEach(() => {
            moxios.uninstall();
        });

        test('Rendering ClaimSummary', () => {
            mockServiceCallResponse(claimMilesConfigresponse);
            setUp({
                loadingSpinner: { loading: false },
                loadingProgressBar: jest.fn()
            });

            return ReactTestUtils.act(() => {
                return store.dispatch(
                    fetchConfiguration(CONFIG_SECTION_CLAIMMILES)
                ).then(() => {
                    rootComponent = rootComponent.update();
                    mockServiceCallResponse(data1);

                    return store.dispatch(
                        retrieveRetroClaimRequests({
                            attr: "attr1String"
                        })
                    )
                        .then(() => {
                            rootComponent.update();
                            storeState = store.getState();
                            expect(storeState.retroClaimRequestsReducer.retrievedRetroClaimRequests).toBe(data1.object);

                            //checks if prop is updated by store
                            component = findComponent(rootComponent, 'ClaimSummary');
                            let claimSummary = component;
                            expect(claimSummary.length).toBe(1);
                            expect(claimSummary.props().retrievedRetroClaimRequests).toBe(data1.object);

                            //checks if all the received data is passed down to claimSummaryTable
                            const claimSummaryTable = claimSummary.find('ClaimSummaryTable');
                            expect(claimSummaryTable.length).toBe(1);
                            expect(claimSummaryTable.props().inputData).toBe(data1.object.retroClaimList);
                            expect(claimSummaryTable.props().inputData.length).toBe(12);

                            mockServiceCallResponse(data2);

                            //next page button click
                            let nextButton = findByTestAttr(claimSummary, 'nextPageButton');
                            expect(nextButton.length).toBe(1);
                            nextButton = nextButton.find(Button);
                            nextButton.simulate('click');

                            //second service call
                            return store.dispatch(
                                retrieveRetroClaimRequests({
                                    attr: "attr1String"
                                })
                            )
                                .then(() => {
                                    //check if the store is updated correctly with second service call
                                    storeState = store.getState();
                                    expect(storeState.retroClaimRequestsReducer.retrievedRetroClaimRequests).toBe(data2.object);

                                    //click back button
                                    rootComponent.update();
                                    let previousButton = findByTestAttr(rootComponent, 'previousPageButton');
                                    expect(previousButton.length).toBe(1);
                                    previousButton = previousButton.find(Button);
                                    previousButton.simulate('click');

                                    //dropdown select
                                    rootComponent.update();
                                    mockServiceCallResponse(data3);
                                    component = findComponent(rootComponent, 'ClaimSummary');
                                    component.instance().handleSummaryTableChange({
                                        target: { value: '20' }
                                    });
                                    rootComponent.setProps({
                                        loadingSpinner: { loading: true },
                                        loadingProgressBar: jest.fn()
                                    });
                                    rootComponent.update();
                                });
                        });
                })


            });
        });
    });

});

const mockServiceCallResponse = (data) => {
    moxios.wait(() => {
        const request = moxios.requests.mostRecent();
        request.respondWith({
            status: 200,
            response: data
        });
    });
}

const data1 = {
    object: { "companyCode": "IBS", "retroClaimList": [{ "retroclaimReferenceNumber": "4105", "partnerCode": "KE", "memberName": "Vicha S", "membershipNumber": "IM0000000328", "retroClaimStatus": "R", "accrualReferenceNumber": "8404", "accrualStatus": "R", "accrualReason": "Passenger Name Mismatch", "accrualRemark": "Rejected", "businesstype": "A", "activityDate": "12-Jun-2020", "claimDate": "15-Jun-2020", "claimDescription": "Origin :ICN-Incheon International , Destination :HKG-Hong Kong International , Cabin Class : Discounted Economy", "oprah": null, "ian": null, "revisionStatus": "A", "flightNumber": "123", "ticketNumber": "345345", "origin": "ICN", "destination": "HKG", "rejectionReason": "Passenger Name Mismatch", "pointDetails": [], "accrualResponseDetail": [] }, { "retroclaimReferenceNumber": "4109", "partnerCode": "KE", "memberName": "Vicha S", "membershipNumber": "IM0000000328", "retroClaimStatus": "R", "accrualReferenceNumber": "8407", "accrualStatus": "R", "accrualReason": "Passenger Name Mismatch", "accrualRemark": "Rejected", "businesstype": "A", "activityDate": "12-Jun-2020", "claimDate": "15-Jun-2020", "claimDescription": "Origin :ICN-Incheon International , Destination :HKG-Hong Kong International , Cabin Class : Discounted Economy", "oprah": null, "ian": null, "revisionStatus": "A", "flightNumber": "123", "ticketNumber": "123", "origin": "ICN", "destination": "HKG", "rejectionReason": "Passenger Name Mismatch", "pointDetails": [], "accrualResponseDetail": [] }, { "retroclaimReferenceNumber": "4105", "partnerCode": "KE", "memberName": "Vicha S", "membershipNumber": "IM0000000328", "retroClaimStatus": "R", "accrualReferenceNumber": "8404", "accrualStatus": "R", "accrualReason": "Passenger Name Mismatch", "accrualRemark": "Rejected", "businesstype": "A", "activityDate": "12-Jun-2020", "claimDate": "15-Jun-2020", "claimDescription": "Origin :ICN-Incheon International , Destination :HKG-Hong Kong International , Cabin Class : Discounted Economy", "oprah": null, "ian": null, "revisionStatus": "A", "flightNumber": "123", "ticketNumber": "345345", "origin": "ICN", "destination": "HKG", "rejectionReason": "Passenger Name Mismatch", "pointDetails": [], "accrualResponseDetail": [] }, { "retroclaimReferenceNumber": "4109", "partnerCode": "KE", "memberName": "Vicha S", "membershipNumber": "IM0000000328", "retroClaimStatus": "C", "accrualReferenceNumber": "8407", "accrualStatus": "R", "accrualReason": "Passenger Name Mismatch", "accrualRemark": "Rejected", "businesstype": "A", "activityDate": "12-Jun-2020", "claimDate": "15-Jun-2020", "claimDescription": "Origin :ICN-Incheon International , Destination :HKG-Hong Kong International , Cabin Class : Discounted Economy", "oprah": null, "ian": null, "revisionStatus": "A", "flightNumber": "123", "ticketNumber": "123", "origin": "ICN", "destination": "HKG", "rejectionReason": "Passenger Name Mismatch", "pointDetails": [], "accrualResponseDetail": [] }, { "retroclaimReferenceNumber": "4105", "partnerCode": "KE", "memberName": "Vicha S", "membershipNumber": "IM0000000328", "retroClaimStatus": "P", "accrualReferenceNumber": "8404", "accrualStatus": "R", "accrualReason": "Passenger Name Mismatch", "accrualRemark": "Rejected", "businesstype": "A", "activityDate": "12-Jun-2020", "claimDate": "15-Jun-2020", "claimDescription": "Origin :ICN-Incheon International , Destination :HKG-Hong Kong International , Cabin Class : Discounted Economy", "oprah": null, "ian": null, "revisionStatus": "A", "flightNumber": "123", "ticketNumber": "345345", "origin": "ICN", "destination": "HKG", "rejectionReason": "Passenger Name Mismatch", "pointDetails": [], "accrualResponseDetail": [] }, { "retroclaimReferenceNumber": "4109", "partnerCode": "KE", "memberName": "Vicha S", "membershipNumber": "IM0000000328", "retroClaimStatus": "D", "accrualReferenceNumber": "8407", "accrualStatus": "R", "accrualReason": "Passenger Name Mismatch", "accrualRemark": "Rejected", "businesstype": "A", "activityDate": "12-Jun-2020", "claimDate": "15-Jun-2020", "claimDescription": "Origin :ICN-Incheon International , Destination :HKG-Hong Kong International , Cabin Class : Discounted Economy", "oprah": null, "ian": null, "revisionStatus": "A", "flightNumber": "123", "ticketNumber": "123", "origin": "ICN", "destination": "HKG", "rejectionReason": "Passenger Name Mismatch", "pointDetails": [], "accrualResponseDetail": [] }, { "retroclaimReferenceNumber": "4105", "partnerCode": "KE", "memberName": "Vicha S", "membershipNumber": "IM0000000328", "retroClaimStatus": "R", "accrualReferenceNumber": "8404", "accrualStatus": "R", "accrualReason": "Passenger Name Mismatch", "accrualRemark": "Rejected", "businesstype": "A", "activityDate": "12-Jun-2020", "claimDate": "15-Jun-2020", "claimDescription": "Origin :ICN-Incheon International , Destination :HKG-Hong Kong International , Cabin Class : Discounted Economy", "oprah": null, "ian": null, "revisionStatus": "A", "flightNumber": "123", "ticketNumber": "345345", "origin": "ICN", "destination": "HKG", "rejectionReason": "Passenger Name Mismatch", "pointDetails": [], "accrualResponseDetail": [] }, { "retroclaimReferenceNumber": "4109", "partnerCode": "KE", "memberName": "Vicha S", "membershipNumber": "IM0000000328", "retroClaimStatus": "R", "accrualReferenceNumber": "8407", "accrualStatus": "R", "accrualReason": "Passenger Name Mismatch", "accrualRemark": "Rejected", "businesstype": "A", "activityDate": "12-Jun-2020", "claimDate": "15-Jun-2020", "claimDescription": "Origin :ICN-Incheon International , Destination :HKG-Hong Kong International , Cabin Class : Discounted Economy", "oprah": null, "ian": null, "revisionStatus": "A", "flightNumber": "123", "ticketNumber": "123", "origin": "ICN", "destination": "HKG", "rejectionReason": "Passenger Name Mismatch", "pointDetails": [], "accrualResponseDetail": [] }, { "retroclaimReferenceNumber": "4105", "partnerCode": "KE", "memberName": "Vicha S", "membershipNumber": "IM0000000328", "retroClaimStatus": "R", "accrualReferenceNumber": "8404", "accrualStatus": "R", "accrualReason": "Passenger Name Mismatch", "accrualRemark": "Rejected", "businesstype": "A", "activityDate": "12-Jun-2020", "claimDate": "15-Jun-2020", "claimDescription": "Origin :ICN-Incheon International , Destination :HKG-Hong Kong International , Cabin Class : Discounted Economy", "oprah": null, "ian": null, "revisionStatus": "A", "flightNumber": "123", "ticketNumber": "345345", "origin": "ICN", "destination": "HKG", "rejectionReason": "Passenger Name Mismatch", "pointDetails": [], "accrualResponseDetail": [] }, { "retroclaimReferenceNumber": "4109", "partnerCode": "KE", "memberName": "Vicha S", "membershipNumber": "IM0000000328", "retroClaimStatus": "", "accrualReferenceNumber": "8407", "accrualStatus": "R", "accrualReason": "Passenger Name Mismatch", "accrualRemark": "Rejected", "businesstype": "A", "activityDate": "12-Jun-2020", "claimDate": "15-Jun-2020", "claimDescription": "Origin :ICN-Incheon International , Destination :HKG-Hong Kong International , Cabin Class : Discounted Economy", "oprah": null, "ian": null, "revisionStatus": "A", "flightNumber": "123", "ticketNumber": "123", "origin": "ICN", "destination": "HKG", "rejectionReason": "Passenger Name Mismatch", "pointDetails": [], "accrualResponseDetail": [] }, { "retroclaimReferenceNumber": "4105", "partnerCode": "KE", "memberName": "Vicha S", "membershipNumber": "IM0000000328", "retroClaimStatus": "R", "accrualReferenceNumber": "8404", "accrualStatus": "R", "accrualReason": "Passenger Name Mismatch", "accrualRemark": "Rejected", "businesstype": "A", "activityDate": "12-Jun-2020", "claimDate": "15-Jun-2020", "claimDescription": "Origin :ICN-Incheon International , Destination :HKG-Hong Kong International , Cabin Class : Discounted Economy", "oprah": null, "ian": null, "revisionStatus": "A", "flightNumber": "123", "ticketNumber": "345345", "origin": "ICN", "destination": "HKG", "rejectionReason": "Passenger Name Mismatch", "pointDetails": [], "accrualResponseDetail": [] }, { "retroclaimReferenceNumber": "4109", "partnerCode": "KE", "memberName": "Vicha S", "membershipNumber": "IM0000000328", "retroClaimStatus": "A", "accrualReferenceNumber": "8407", "accrualStatus": "R", "accrualReason": "Passenger Name Mismatch", "accrualRemark": "Rejected", "businesstype": "A", "activityDate": "12-Jun-2020", "claimDate": "15-Jun-2020", "claimDescription": "Origin :ICN-Incheon International , Destination :HKG-Hong Kong International , Cabin Class : Discounted Economy", "oprah": null, "ian": null, "revisionStatus": "A", "flightNumber": "123", "ticketNumber": "123", "origin": "ICN", "destination": "HKG", "rejectionReason": "Passenger Name Mismatch", "pointDetails": [], "accrualResponseDetail": [] }], "hasNextPage": true, "absoluteIndex": 4 }
}

const data2 = {
    object: { "companyCode": "IBS", "retroClaimList": [{ "retroclaimReferenceNumber": "4105", "partnerCode": "KE", "memberName": "Vicha S", "membershipNumber": "IM0000000328", "retroClaimStatus": "R", "accrualReferenceNumber": "8404", "accrualStatus": "R", "accrualReason": "Passenger Name Mismatch", "accrualRemark": "Rejected", "businesstype": "A", "activityDate": "12-Jun-2020", "claimDate": "15-Jun-2020", "claimDescription": "Origin :ICN-Incheon International , Destination :HKG-Hong Kong International , Cabin Class : Discounted Economy", "oprah": null, "ian": null, "revisionStatus": "A", "flightNumber": "123", "ticketNumber": "345345", "origin": "ICN", "destination": "HKG", "rejectionReason": "Passenger Name Mismatch", "pointDetails": [], "accrualResponseDetail": [] }, { "retroclaimReferenceNumber": "4109", "partnerCode": "KE", "memberName": "Vicha S", "membershipNumber": "IM0000000328", "retroClaimStatus": "R", "accrualReferenceNumber": "8407", "accrualStatus": "R", "accrualReason": "Passenger Name Mismatch", "accrualRemark": "Rejected", "businesstype": "A", "activityDate": "12-Jun-2020", "claimDate": "15-Jun-2020", "claimDescription": "Origin :ICN-Incheon International , Destination :HKG-Hong Kong International , Cabin Class : Discounted Economy", "oprah": null, "ian": null, "revisionStatus": "A", "flightNumber": "123", "ticketNumber": "123", "origin": "ICN", "destination": "HKG", "rejectionReason": "Passenger Name Mismatch", "pointDetails": [], "accrualResponseDetail": [] }], "hasNextPage": false, "absoluteIndex": 2 }
}

const data3 = {
    object: { "companyCode": "IBS", "retroClaimList": [{ "retroclaimReferenceNumber": "4105", "partnerCode": "KE", "memberName": "Vicha S", "membershipNumber": "IM0000000328", "retroClaimStatus": "R", "accrualReferenceNumber": "8404", "accrualStatus": "R", "accrualReason": "Passenger Name Mismatch", "accrualRemark": "Rejected", "businesstype": "A", "activityDate": "12-Jun-2020", "claimDate": "15-Jun-2020", "claimDescription": "Origin :ICN-Incheon International , Destination :HKG-Hong Kong International , Cabin Class : Discounted Economy", "oprah": null, "ian": null, "revisionStatus": "A", "flightNumber": "123", "ticketNumber": "345345", "origin": "ICN", "destination": "HKG", "rejectionReason": "Passenger Name Mismatch", "pointDetails": [], "accrualResponseDetail": [] }], "hasNextPage": false, "absoluteIndex": 2 }
}

const claimMilesConfigresponse = {"statuscode":"200","statusMessage":"SUCCESS","object":{"section":"claimmiles","companyCode":"IBS","programCode":"PRG14","businessType":"A","retroClaimStatus":"D","requiredAction":"P","cabinClass":"D","bookingClass":"D","ui":{"claimDuration":60,"claimDurationUnit":"days","availablePageSizes":[5,10,20,50,100],"maximumPageSize":100,"defaultPageSize":10,"defaultPageNumber":1,"defaultAbsoluteIndex":1}}}