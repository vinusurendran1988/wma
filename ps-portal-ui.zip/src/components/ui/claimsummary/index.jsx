import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import {
  withSuspense,
  getCurrentDate,
  getRelativeDate
} from '../../common/utils';
import Button from '../../common/components/fieldbank/Button';
import { retrieveRetroClaimRequests } from './actions';
import {
  fetchConfiguration
} from '../../common/middleware/redux/commonAction';
import { connect } from 'react-redux';
import ClaimSummaryTable from './ClaimSummaryTable';
import {
  CONFIG_SECTION_CLAIMMILES, PROGRAM_TYPE_CORPORATE, DD_MMM_YYYY
} from '../../common/utils/Constants';
import {
  getItemFromBrowserStorage,
  BROWSER_STORAGE_KEY_COMPANY_CODE,
  BROWSER_STORAGE_KEY_PROGRAM_CODE,
  BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
  BROWSER_STORAGE_KEY_PROGRAM_TYPE,
} from '../../common/utils/storage.utils';
import { NAVIGATE_MEMBER_CLAIMSUBMIT, NAVIGATE_CORPORATE_CLAIMSUBMIT } from '../../common/utils/urlConstants';
import DropDown from '../../common/components/fieldbank/DropDown';
import { withRouter } from 'react-router-dom';
import CustomMessage from '../../common/components/custommessage';

/**
 * ClaimSummary class.
 * @description Loads data to display claims summary.
 * @author Ajmal Aliyar
 */
class ClaimSummary extends Component {
  constructor(props) {
    super(props);
    this.state = {
      claimToDate: getCurrentDate(DD_MMM_YYYY),
      claimFromDate: undefined,
      pageNumber: undefined,
      pageSize: undefined,
      listToDisplay: [],
      loading: false,
      doEnableNextButton: false,
      doEnablePreviousButton: false,
      indexList: [],
      currentIndexListArrayPosition: 0,
      availablePageSizes: [],
      isRedirected: false,
      referenceNo : ""
    }
    this.handleSummaryTableChange = this.handleSummaryTableChange.bind(this);
    this.updateNextPageButton = this.updateNextPageButton.bind(this);
    this.resetToInitialState = this.resetToInitialState.bind(this);
    this.handlePreviousButtonClick = this.handlePreviousButtonClick.bind(this);
    this.handleNextButtonClick = this.handleNextButtonClick.bind(this);
  }

  componentDidMount() {
    this.props.setPageInfo(this.props, {config: this.props.claimSummaryConfig, confSection: CONFIG_SECTION_CLAIMMILES})
    if (this.props.claimSummaryConfig) {
      const config = this.props.claimSummaryConfig
      const availablePageSizes = []
      config.ui.availablePageSizes.forEach(p => {
        availablePageSizes.push({
          label: p,
          value: p
        })
      })
      this.setState({
        claimFromDate: getRelativeDate(this.state.claimToDate, -1 * config.ui.claimDuration, DD_MMM_YYYY, DD_MMM_YYYY),
        pageSize: config.ui.defaultPageSize,
        indexList: [config.ui.defaultAbsoluteIndex],
        pageNumber: config.ui.defaultPageNumber,
        availablePageSizes: availablePageSizes
      })
    }
  }

  componentDidUpdate(prevProps, prevState) {

    if (prevProps.claimSummaryConfig != this.props.claimSummaryConfig) {
      if (
        this.props.claimSummaryConfig &&
        this.props.claimSummaryConfig.ui
      ) {
        const config = this.props.claimSummaryConfig
        const availablePageSizes = []
        config.ui.availablePageSizes.forEach(p => {
          availablePageSizes.push({
            label: p,
            value: p
          })
        })
        this.setState({
          claimFromDate: getRelativeDate(this.state.claimToDate, -1 * config.ui.claimDuration, DD_MMM_YYYY, DD_MMM_YYYY),
          pageSize: config.ui.defaultPageSize,
          indexList: [config.ui.defaultAbsoluteIndex],
          pageNumber: config.ui.defaultPageNumber,
          availablePageSizes: availablePageSizes
        })
      }
    }


    if (prevProps.retrievedRetroClaimRequests !== this.props.retrievedRetroClaimRequests) {
      let list = [];
      if (this.props.retrievedRetroClaimRequests && this.props.retrievedRetroClaimRequests.retroClaimList) {
        list = this.props.retrievedRetroClaimRequests.retroClaimList
      }
      this.setState({
        listToDisplay: list,
        loading: false
      });
      this.updateNextPageButton();
    }

    if (prevState.claimFromDate !== this.state.claimFromDate) {
      this.fetchRetroClaimRequests();
    } else if (prevState.pageSize !== this.state.pageSize) {
      this.resetToInitialState();
      this.fetchRetroClaimRequests();
    } else if (prevState.currentIndexListArrayPosition !== this.state.currentIndexListArrayPosition) {
      if (this.state.currentIndexListArrayPosition === 0) {
        this.setState({
          doEnablePreviousButton: false
        })
      } else {
        this.setState({
          doEnablePreviousButton: true
        })
      }
      this.fetchRetroClaimRequests();
    }

  }

  updateNextPageButton() {
    if (this.props.retrievedRetroClaimRequests.hasNextPage) {
      let currentIndexList = this.state.indexList;
      currentIndexList.push(this.props.retrievedRetroClaimRequests.absoluteIndex)
      this.setState({
        doEnableNextButton: true,
        indexList: currentIndexList
      })
    } else {
      this.setState({
        doEnableNextButton: false
      })
    }
  }

  fetchRetroClaimRequests() {
    if (!this.state.loading) {
      this.setState({
        loading: true
      });
      const requestPayload = {
        "object": {
          "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
          "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
          "retroclaimReferenceNumber": "",
          "membershipNumber": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
          "partnerCode": "",
          "status": "",
          "businessType": "",
          "activityFromDate": "",
          "activityToDate": "",
          "claimFromDate": this.state.claimFromDate,
          "claimToDate": this.state.claimToDate,
          "oprah": "",
          "ian": "",
          "revisionStatus": "",
          "airCategoryFilter": {
            "carrierCode": "",
            "flightNumber": "",
            "origin": "",
            "destination": "",
            "ticketNumber": ""
          },
          "nonAirCategoryFilter": {
            "billNumber": ""
          },
          "pageNumber": this.state.pageNumber,
          "pageSize": this.state.pageSize,
          "absoluteIndex": this.state.indexList[this.state.currentIndexListArrayPosition]
        }
      };
      this.props.retrieveRetroClaimRequests(requestPayload);
    }
  }

  handleSummaryTableChange(value) {
    this.setState({
      pageSize: value,
      listToDisplay: []
    })
  }

  resetToInitialState() {
    this.setState({
      pageNumber: this.props.claimSummaryConfig.ui.defaultPageNumber,
      listToDisplay: [],
      loading: false,
      doEnableNextButton: false,
      doEnablePreviousButton: false,
      indexList: [this.props.claimSummaryConfig.ui.defaultAbsoluteIndex],
      currentIndexListArrayPosition: 0
    });
  }

  handlePreviousButtonClick(event) {
    this.setState({
      currentIndexListArrayPosition: this.state.currentIndexListArrayPosition - 1
    })
  }

  handleNextButtonClick(event) {
    this.setState({
      currentIndexListArrayPosition: this.state.currentIndexListArrayPosition + 1
    })
  }

  redirectToSubmitClaim() {
    const programType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE)
    let location = `#${NAVIGATE_MEMBER_CLAIMSUBMIT}`
    if (programType == PROGRAM_TYPE_CORPORATE) {
      location = `#${NAVIGATE_CORPORATE_CLAIMSUBMIT}`
    }
    window.location.href = location
  }

  render() {

    const {
      availablePageSizes,
      listToDisplay,
      pageSize,
      doEnableNextButton,
      doEnablePreviousButton
    } = this.state;
    const { claimSummaryConfig, t, claimRequest } = this.props;

    const referenceNo = claimRequest && claimRequest.newClaimRequest && claimRequest.newClaimRequest.object
      && claimRequest.newClaimRequest.object.retroclaimReferenceNumber
    let config = undefined;
    let columns = []
    if (claimSummaryConfig) {
      config = claimSummaryConfig
      if (
        config.ui &&
        config.ui.layout &&
        config.ui.layout.elements &&
        config.ui.layout.elements.table &&
        config.ui.layout.elements.table.columns
      ) {
        columns = config.ui.layout.elements.table.columns
      }
    }

    return (
      <>
        <h1>{t("claim_summary.title")}</h1>
        {this.props.location && this.props.location.state && this.props.location.state.isRedirected &&
            <CustomMessage message={[t("claimsubmit.message.success").replace("{CLAIM_REF_NUMBER}", referenceNo)]} 
            type={"success"} canTranslate={false} />
          }
        <div className="form-row mb-4 align-items-center">
          <div className="col-lg-10">
            <p>{ t("claim_summary.descriptionOne")}</p>
            <p>{ t("claim_summary.descriptionTwo")}</p>
          </div>
          <div className="col-lg-2 text-right">
            <button
              type="button"
              className="btn btn-secondary btn-sm"
              onClick={() => this.redirectToSubmitClaim()}
            >
              {t("claim_summary.claim_miles_btn")}
            </button>
          </div>
        </div>
        <ClaimSummaryTable
          field={{
            values: listToDisplay ? listToDisplay : [],
            columns: columns ? columns : [],
            globalFilter: undefined
          }}
          className={"table table-striped"}
        />
        <div className="pagination">
          <div className="pagination__count">
            <DropDown
              label={""}
              placeholder={"Page Size"}
              options={availablePageSizes}
              id="claimlist-page-size-id"
              value={pageSize}
              onChange={this.handleSummaryTableChange}
              testIdentifier={"claimlist-page-size-id"}
              enabled={true}
            />
          </div>
          <div className="text-lg-right btn-wrap btn-wrap--grp">
            <Button
              handleOnClick={this.handlePreviousButtonClick}
              className='btn btn-secondary btn-sm'
              label={t("claim_summary.previous")}
              enabled={doEnablePreviousButton}
            />
            <Button
              handleOnClick={this.handleNextButtonClick}
              className='btn btn-secondary btn-sm'
              label={t("claim_summary.next")}
              enabled={doEnableNextButton}
            />

          </div>
        </div>
      </>
    )

  }
}

ClaimSummary.propTypes = {
};

ClaimSummary.defaultProps = {
};

const mapStateToProps = (state) => {
  return {
    retrievedRetroClaimRequests: state.retroClaimRequestsReducer.retrievedRetroClaimRequests,
    claimSummaryConfig: state.configurationReducer[CONFIG_SECTION_CLAIMMILES],
    claimRequest: state.claimsubmitReducer
  }
}

const mapDispatchToProps = {
  fetchConfiguration,
  retrieveRetroClaimRequests
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(withRouter(ClaimSummary))));

