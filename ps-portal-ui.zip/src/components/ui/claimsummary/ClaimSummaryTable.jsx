import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import {
    withSuspense, isEmptyOrSpaces
} from '../../common/utils';
import FieldBank from '../../common/components/fieldbank';
import { FIELDTYPE_TABLE } from '../../common/components/fieldbank/Constants';

class ClaimSummaryTable extends Component {
    constructor(props) {
        super(props);
        this.state = {
            pageSize: this.props.maxPageSize
        }
    }

    componentDidMount() {
        this.setState({
            pageSize: this.props.pageSize
        })
    }

    flightBodyTemplate(rowData, props) {
        return <React.Fragment>
            <span className="p-column-title">{props.header}</span>
            {`${rowData.partnerCode}-${rowData.flightNumber}`}
        </React.Fragment>
    }

    tripBodyTemplate(rowData, props) {
        let spanElement = <span></span>
        if (!isEmptyOrSpaces(rowData.destination) && !isEmptyOrSpaces(rowData.origin)) {
            spanElement = <span>
                {rowData.origin.trim()}
                <span className="devider">
                    <span className="fa fa-plane" aria-hidden="true" style={{ transform: "rotate(45deg)" }}></span>
                </span>
                {rowData.destination.trim()}
            </span>
        }
        return <React.Fragment>
            <span className="p-column-title">{props.header}</span>
            {spanElement}
        </React.Fragment>
    }

    dateTemplate(rowData, props) {
        const date = rowData[props.field].split("-")
        return <React.Fragment>
            {date[0]}<span className="devider">-</span>{date[1]}<span className="devider">-</span>{date[2]}
        </React.Fragment>
    }

    statusBodyTemplate(rowData, props) {
        let spanElement = undefined;
        if (rowData.retroClaimStatus) {
            switch (rowData.retroClaimStatus) {
                case 'C':
                    spanElement = <span className={`badge badge-success`}>
                        Confirmed</span>
                    break;
                case 'P':
                    spanElement = <span className={`badge badge-primary`}>
                        Processed</span>
                    break;
                case 'D':
                    spanElement = <span className={`badge`}>
                        In Progress</span>
                    break;
                case 'R':
                    spanElement =
                        <span>
                            <span className={`badge badge--danger`}>Rejected</span>
                            <span title={`${rowData.rejectionReason}`} data-toggle="tooltip">
                                <i className="fa fa-info-circle" aria-hidden="true"></i>
                            </span>
                        </span>
                    break;
                default:
            }
            return <React.Fragment>
                <span className="p-column-title">{props.header}</span>
                {spanElement}
            </React.Fragment>
        } else return null;
    }

    render() {
        const { globalFilter, field,t, className } = this.props;
        return (
            <FieldBank
                field={{
                    fieldType: FIELDTYPE_TABLE,
                    globalFilter: globalFilter,
                    emptyMessage:t("claim_summary.no_summary"),
                    bodyTemplates: {
                        "tripBodyTemplate": this.tripBodyTemplate,
                        "flightBodyTemplate": this.flightBodyTemplate,
                        "statusBodyTemplate": this.statusBodyTemplate,
                        "dateTemplate": this.dateTemplate
                    },
                    ...field
                }}
                className={className}
            />
        );
    }

}

ClaimSummaryTable.propTypes = {
};

ClaimSummaryTable.defaultProps = {
};

const mapStateToProps = (state) => {
    return {
    }
}

const mapDispatchToProps = {
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(ClaimSummaryTable)));