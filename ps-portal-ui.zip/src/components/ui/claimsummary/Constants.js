export const ID_SPINNER_SUBMIT_CLAIM = "id-spinner-submit-claim"
