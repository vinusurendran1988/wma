import React, { Component } from 'react';
import {
    withSuspense,
    generateRequestBodyWithEmptyValue,
    constructJsonPath,
    toTitleCase
} from '../../common/utils';
import {
    ID_SPINNER_SUBMIT_CLAIM
} from './Constants'
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import {
    requestClaim
} from './actions';
import {
    fetchConfiguration,
    getFamilyMembers,
    setError,
    resetError
} from '../../common/middleware/redux/commonAction';
import {
    CONFIG_SECTION_SUBMITMILES, PROGRAM_TYPE_INDIVIDUAL, PROGRAM_TYPE_CORPORATE
} from '../../common/utils/Constants';
import CustomMessage from '../../common/components/custommessage';
import { NAVIGATE_MEMBER_CLAIMSUMMARY } from '../../common/utils/urlConstants';
import {
    findValueFromObjectByPath,
    getValueFromPath,
    isDependentExists,
    setValueToObjectByPath
} from '../../common/utils/object.utils';
import Section from '../updateprofile/Section';
import { getItemFromBrowserStorage, BROWSER_STORAGE_KEY_PROGRAM_TYPE, BROWSER_STORAGE_KEY_COMPANY_CODE, BROWSER_STORAGE_KEY_PROGRAM_CODE, BROWSER_STORAGE_KEY_MEMBERSHIP_NO } from '../../common/utils/storage.utils';
import Button from '../../common/components/fieldbank/Button';
import { withRouter } from 'react-router'

/**
 * @name SubmitClaim component.
 * @description Component to Submit Claim 
 *
 * @author Amrutha
 */
class SubmitClaim extends Component {
    constructor(props) {
        super(props)
        this.state = {
            showWarningAndError: false,
            request: generateRequestBodyWithEmptyValue(props.config),
            errorCodes: [],
            messageType: "danger",
            canTranslate: true,
            isButtonClicked: false,
            selectedPassengerDetails: {
                ticketTitle: props.accountSummary && props.accountSummary.title,
                ticketedFirstName: props.accountSummary && props.accountSummary.givenName,
                ticketedLastName: props.accountSummary && props.accountSummary.familyName,
                membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                recipientMembershipNumber: ""
            }

        }
        this.handleSubmit = this.handleSubmit.bind(this);
        this.doAdditionalMapping = this.doAdditionalMapping.bind(this)
        this.getPassengerDetails = this.getPassengerDetails.bind(this)
        this.findValueFromState = this.findValueFromState.bind(this)
    }


    componentDidMount() {
        window.scrollTo(0, 0);
        const { config } = this.props
        this.props.setPageInfo(this.props, {config, confSection: CONFIG_SECTION_SUBMITMILES})
        if (config) {
            this.doAdditionalMapping()
        }

        if (!this.props.familyMembers || this.props.familyMembers.length == 0) {
            const object = {
                companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)
            }
            this.props.getFamilyMembers({ object });
        }

        const newState = {}
        this.setNameToState(newState)
        if (newState)
            this.setState(newState)
    }

    setNameToState(newState) {
        const programType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE)
        const { accountSummary, customerProfileData } = this.props
        if (programType == PROGRAM_TYPE_INDIVIDUAL && accountSummary) {
            newState["title"] = toTitleCase(accountSummary.title)
            newState["givenName"] = toTitleCase(accountSummary.givenName)
            newState["familyName"] = toTitleCase(accountSummary.familyName)
        } else if (programType == PROGRAM_TYPE_CORPORATE && customerProfileData && customerProfileData.object) {
            newState["title"] = toTitleCase(customerProfileData.object.customerProfile.individualInfo.title)
            newState["givenName"] = toTitleCase(customerProfileData.object.customerProfile.individualInfo.givenName)
            newState["familyName"] = toTitleCase(customerProfileData.object.customerProfile.individualInfo.familyName)
        }
    }
    /**
    * Method invoked when component is updated
    *
    * @author Amrutha
    */
    componentDidUpdate(prevProps, prevState) {
        if (prevProps.config !== this.props.config) {
            this.setState({
                request: generateRequestBodyWithEmptyValue(this.props.config)
            }, () => {
                this.doAdditionalMapping()
            })
        }

        const newState = {}
        this.setNameToState(newState)

        if (newState &&
            (this.state.title != newState.title ||
                this.state.givenName != newState.givenName || this.state.familyName != newState.familyName)) {
            this.setState(newState)
        }

        if (prevProps.claim && (JSON.stringify(prevProps.claim.newClaimRequest) !== JSON.stringify(this.props.claim.newClaimRequest))) {
            this.props.history.push({
                pathname: `${NAVIGATE_MEMBER_CLAIMSUMMARY}`,
                state: { isRedirected: true }
            })

        }
    }
    /**
    * Method to map the additional fields from the configuration to the request object
    *
    * @author Somdas
    */

    doAdditionalMapping() {
        const { config } = this.props
        let { request } = this.state

        if (config && config.ui && config.ui.request && config.ui.request.additionalMapping) {
            config.ui.request.additionalMapping.forEach((fields) => {
                let { fromPath, toPath, dependentPath } = fields
                let value = undefined
                fromPath.forEach((path, index) => {
                    if (value == undefined) value = ""
                    let returnValue = getValueFromPath(path, { config, request, state: this.state, props: this.props })
                    if (returnValue && isDependentExists(dependentPath, { config, request, state: this.state, props: this.props })) {
                        value += (index > 0 ? " " : "") + returnValue
                    }
                })
                if (value != undefined) {
                    constructJsonPath(toPath, value, request)
                    setValueToObjectByPath(request, toPath, value)
                    this.setState({
                        request
                    })
                }
            })
        }
    }
    /**
    * Method to submit the claim details
    * 
    * @author Somdas
    */
    handleSubmit() {
        const { errorCodes, messageType } = this.state;
        if (errorCodes.length > 0 && messageType == "danger") {
            this.setState({
                canTranslate: true
            })
            this.props.setError(errorCodes);
        } else {
            this.props.resetError()
            this.setState(({
                errorCodes: [],
                messageType: "danger"
            }))
            this.doAdditionalMapping()
            this.props.requestClaim(this.state.request, ID_SPINNER_SUBMIT_CLAIM)
        }
        window.scrollTo(0, 0);
        this.setState({ showWarningAndError: true, isButtonClicked: true })
    }
    /**
    * Method to detect changes in the input fields
    * 
    * @author Amrutha
    */
    handleRequestChange(request) {
        const { passengerDetails, selectedPassengerDetails } = this.state
        let dropDownDetails = { ...selectedPassengerDetails }
        const memberDetails = this.props.familyMembers.find(member => member.membershipNumber === passengerDetails)
        if (memberDetails) {
            dropDownDetails = {
                ticketTitle: memberDetails.title,
                ticketedFirstName: memberDetails.givenName,
                ticketedLastName: memberDetails.familyName,
                membershipNumber: memberDetails.membershipNumber,
                recipientMembershipNumber: memberDetails.membershipNumber

            }
        }
        else {
            dropDownDetails =
            {
                ticketTitle: this.props.accountSummary.title,
                ticketedFirstName: this.props.accountSummary.givenName,
                ticketedLastName: this.props.accountSummary.familyName,
                membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                recipientMembershipNumber: ""
            }
        }
        this.setState({ selectedPassengerDetails: dropDownDetails }, () => {
            this.setState({ request, showWarningAndError: false, canTranslate: true })
        })

    }

    handleErrorMessagesFromSection(codes) {
        if (!codes.length) { this.props.resetError() }
        if (JSON.stringify(codes) != JSON.stringify(this.state.errorCodes)) {
            this.setState({ errorCodes: codes, messageType: "danger" })
        }
    }

    findValueFromState(stateFieldName) {
        return this.state[stateFieldName] && Object.keys(this.state[stateFieldName]) ? this.state[stateFieldName].membershipNumber : ""

    }
    addValueToState(field, value) {
        this.setState({
            [field.name]: value
        }, () => {
            this.handleRequestChange(this.state.request)
        })

    }

    /**
    * Method to get the passenger details for claim submission
    * Returns an array consisting of the member and family
    * @author Amrutha
    */
    getPassengerDetails() {
        const membershipNumber = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)
        const selfDetails = {
            membershipNumber: membershipNumber,
            displayName: this.props.t('claimsubmit.self')
        }
        const passengerDetails = []
        passengerDetails.push(selfDetails)
        passengerDetails.push(...this.props.familyMembers)
        return passengerDetails
    }

    render() {
        const { errorCodes, request, showWarningAndError, messageType, canTranslate } = this.state;
        const { t, config, sections, uiLayout, error } = this.props
        const dynamicAttributeProperties = {
            "path": this.props.dynamicAttributesPath,
            "attributes"
                : this.props.dynamicAttributes
        }
        return (
            <div className="rightSidePanel" data-test="SubmitClaim">
                <h1 id="claim_submit_title">{t("claimsubmit.title")}</h1>
                <div className="form-row">
                    <div className="col-12">
                        <p>{config && config.data && t("claimsubmit.description").replace("{DURATION}", config.data.claimDuration).replace("{MEASUREMENT}", config.data.claimDurationUnit)}</p>
                    </div>
                    {/* <div className="col-2 text-right">
                        <a onClick={()=>this.redirectToClaimSummary()} className="btn btn-outline-primary btn-sm">{t("claimsubmit.claim_summary_btn")}</a>
                    </div> */}
                </div>
                {showWarningAndError && <CustomMessage message={errorCodes.length > 0 ? errorCodes : error} type={messageType} canTranslate={canTranslate} />}
                <div className="claim-wrapper">
                    {
                        config && config.ui && config.ui.layout && config.ui.layout.order && config.ui.layout.elements &&
                        sections && sections.map((section, i) => {
                            return uiLayout.elements[section] && <Section
                                key={i}
                                id={section}
                                family={this.getPassengerDetails()}
                                displayElements={uiLayout.elements[section]}
                                request={request}
                                page={`form.submitclaim`}
                                onRequestChange={(req) => this.handleRequestChange(req)}
                                dynamicAttributes={dynamicAttributeProperties}
                                errorCodes={errorCodes}
                                showWarningAndError={showWarningAndError}
                                onErrorCodes={(codes) => this.handleErrorMessagesFromSection(codes)}
                                addValueToState={(field, value) => this.addValueToState(field, value)}
                                //validateWithStateVariable={(field, validation, value) => this.validateWithStateVariable(field, validation, value)}
                                findValueFromState={(stateFieldName) => this.findValueFromState(stateFieldName)}
                                isButtonClicked={this.state.isButtonClicked}
                            />
                        })
                    }
                    <div className="text-right buttonWrap">
                        <Button
                            className="btn btn-primary"
                            handleOnClick={() => this.handleSubmit()}
                            id={ID_SPINNER_SUBMIT_CLAIM}
                            testIdentifier="btnSubmit1"
                            // enabled={}
                            label={t("claimsubmit.submit_btn")} />
                    </div>
                </div>
            </div>);
    }
}

const mapStateToProps = (state) => {
    return {
        claim: state.claimsubmitReducer,
        customerProfileData: state.fetchCustomerProfileReducer,
        accountSummary: state.accountSummaryReducer.accountSummary,
        familyMembers: state.familyListReducer.members,
        error: state.commonErrorReducer.error,
        config: state.configurationReducer[CONFIG_SECTION_SUBMITMILES],
        uiLayout: findValueFromObjectByPath(state, `configurationReducer.${CONFIG_SECTION_SUBMITMILES}.ui.layout`, []),
        sections: findValueFromObjectByPath(state, `configurationReducer.${CONFIG_SECTION_SUBMITMILES}.ui.layout.order`, []),
        dynamicAttributes: findValueFromObjectByPath(state, `configurationReducer.${CONFIG_SECTION_SUBMITMILES}.dynamicAttributes`, []),
        dynamicAttributesPath: findValueFromObjectByPath(state, `configurationReducer.${CONFIG_SECTION_SUBMITMILES}.ui.dynamicAttributesPath`, ""),
    }
}

const mapDispatchToProps = {
    requestClaim,
    getFamilyMembers,
    fetchConfiguration,
    setError,
    resetError
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(withRouter(SubmitClaim))));
