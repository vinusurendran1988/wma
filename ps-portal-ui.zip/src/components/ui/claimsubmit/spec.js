import { mount } from 'enzyme';
import moxios from 'moxios';
import React from 'react';
import ReactTestUtils from 'react-dom/test-utils';
import { Provider } from 'react-redux';
import { BrowserRouter as Router } from 'react-router-dom';
import { fetchAccountSummary, fetchConfiguration, fetchMasterData, getFamilyMembers } from '../../common/middleware/redux/commonAction';
import { findByTestAttr, findComponent, mockServiceResponse } from '../../common/testUtils';
import { testStore } from '../../common/utils';
import { axiosInstance } from '../../common/utils/api';
import { AIRPORT, CONFIG_SECTION_SUBMITMILES, PARTNERS, SESSION_STORAGE_COMPANY_CODE, SESSION_STORAGE_PROGRAM_CODE } from '../../common/utils/Constants';
import { BROWSER_STORAGE_KEY_PROGRAM_TYPE } from '../../common/utils/storage.utils';
import { requestClaim } from './actions';
import SubmitClaim from './index';
var store = testStore({})
let rootComponent;
let component;

const setUp = (props = {}) => {
    rootComponent = mount(
        
        <Provider store={store} >
            <Router>
                <SubmitClaim {...props} />
            </Router>
        </Provider>

    );
};

const getCurrentComponent = () => {
    return findComponent(rootComponent, 'withRouter(SubmitClaim)')
}

describe('Submit Claim Component', () => {

    beforeEach(() => {
        window.scrollTo = jest.fn();
        moxios.install(axiosInstance);
        window.sessionStorage.setItem(SESSION_STORAGE_COMPANY_CODE, 'IBS')
        window.sessionStorage.setItem(SESSION_STORAGE_PROGRAM_CODE, 'PRG14')
        window.localStorage.setItem(BROWSER_STORAGE_KEY_PROGRAM_TYPE, "individual")
        store = testStore({});
        setUp({})
        mockServiceResponse(claimMilesConfigresponse, 200)
        return ReactTestUtils.act(() => {
            return store.dispatch(
                fetchConfiguration(CONFIG_SECTION_SUBMITMILES)
            ).then(() => {
                rootComponent.update();
                component = getCurrentComponent()
                const newState = store.getState()
                expect(newState.configurationReducer[CONFIG_SECTION_SUBMITMILES]).toBe(claimMilesConfigresponse.object)
                mockServiceResponse(accountSummaryResponse)
                return store.dispatch(
                    fetchAccountSummary({ test: "" })
                ).then(() => {
                    rootComponent.update();
                    component = getCurrentComponent()
                    let newState=store.getState()
                    expect(newState.accountSummaryReducer.accountSummary).toBe(accountSummaryResponse.object)
                    mockServiceResponse(airlineMasterresponse)
                    return store.dispatch(
                        fetchMasterData(PARTNERS, MASTER_ENTITY_LOOKUP)
                    ).then(() => {
                        rootComponent.update();
                        component = getCurrentComponent()
                        const masterAirlineDataState = store.getState()
                        expect(masterAirlineDataState.masterData.partners).toBe(airlineMasterresponse.object.masterRecordList)

                        mockServiceResponse(airportMasterResponse)
                        return store.dispatch(
                            fetchMasterData(AIRPORT, MASTER_ENTITY_LOOKUP)
                        ).then(async () => {

                            rootComponent.update();
                            component = getCurrentComponent()
                            const masterAirportDataState = store.getState()
                            expect(masterAirportDataState.masterData.airport).toBe(airportMasterResponse.object.masterRecordList)

                            mockServiceResponse(familyRetrieveResponse)
                            return store.dispatch(
                                getFamilyMembers({ "test": "test" })
                            ).then(() => {
                                rootComponent.update();
                                component = getCurrentComponent()
                                const familyDataState = store.getState()

                                expect(familyDataState.familyMembers.members).toBe(familyRetrieveResponse.object)
                                const airlineField = findByTestAttr(component, 'submitClaim_partnerCode')
                                const flightNumberField = findByTestAttr(component, 'submitClaim_flightNumber')
                                const depDateField = findByTestAttr(component, 'submitClaim_travelDate')
                                const originAirportField = findByTestAttr(component, 'submitClaim_originAirport')
                                const destinationSelectedField = findByTestAttr(component, 'submitClaim_destinationAirport')
                                const familyMembersField = findByTestAttr(component, 'submitClaim_passengerDetails')
                                const ticketNoField = findByTestAttr(component, 'submitClaim_ticketNumber')
                                const bookingRefField = findByTestAttr(component, 'submitClaim_bookingReferenceNumber')
                                const btnSubmit = findByTestAttr(component, 'btnSubmit1')

                                expect(airlineField.length).toBe(1);
                                expect(btnSubmit.length).toBe(1);
                                expect(depDateField.length).toBe(1);
                                expect(originAirportField.length).toBe(1);
                                expect(destinationSelectedField.length).toBe(1);
                                expect(ticketNoField.length).toBe(1);
                                expect(bookingRefField.length).toBe(1);

                                airlineField.prop('onChange')({ target: { id: 'airline', value: 'KE' } }, undefined)
                                flightNumberField.prop('onChange')({ target: { id: 'fNumber', value: '123' } }, undefined)
                                depDateField.prop('onChange')({ target: { id: 'depDate', value: '06-May-2021' } }, undefined)
                                originAirportField.prop('onChange')({
                                    target: {
                                        value: {
                                            name: "name",
                                            value: "ICN"
                                        }
                                    }
                                })
                                destinationSelectedField.prop('onChange')({
                                    target: {
                                        value: {
                                            name: "name2",
                                            value: "SNG"
                                        }
                                    }
                                })
                                familyMembersField.prop('onChange')(
                                    {
                                        target: {
                                            value: {
                                                name: "name3",
                                                value: "FMG"
                                            }
                                        }
                                    }
                                )
                                rootComponent = rootComponent.update()
                                component = findComponent(rootComponent, 'SubmitClaim');
                                btnSubmit.props().onClick({})

                            })

                        })
                    })
                })

            })
        })

    })

    it('Request Claim Success', () => {
        mockServiceResponse(submitClaimSuccess)
        return store.dispatch(
            requestClaim({}, true)
        ).then(() => {
            // console.log("failure");
        })
    })
    it('Request Claim Failure', () => {

        mockServiceResponse(submitClaimError)
        return store.dispatch(
            requestClaim({}, true)
        ).then(() => {
            // console.log("failure");
        })
    })

    it('Request Claim  Internal Server Error', () => {
        store = testStore({});
        mockServiceResponse(errorResponse, 500)
        return store.dispatch(
            requestClaim({ test: "test" }, true)
        )
            .then(() => {
                const newState = store.getState();
                expect(newState.claimsubmitReducer.newClaimRequest).toBeUndefined();
            });
    });

    it('Get Family Members Failure', () => {
        store = testStore({});
        mockServiceResponse(errorResponse, 500)
        return store.dispatch(
            getFamilyMembers({ test: "test" })
        )
            .then(() => {
                const newState = store.getState();
                expect(newState.claimsubmitReducer.members).toBeUndefined();
            });
    });

    afterEach(() => {
        moxios.uninstall();
    });
})

const claimMilesConfigresponse = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "section": "submitmiles", "companyCode": "IBS", "programCode": "PRG14", "data": { "businessType": "A", "retroClaimStatus": "D", "requiredAction": "P", "cabinClass": "D", "bookingClass": "D", "defaultSelectedPassenger": "Self", "claimDuration": 60, "claimDurationUnit": "days", "empty": "" }, "ui": { "request": { "additionalMapping": [{ "fromPath": ["window.localStorage.companyCode"], "toPath": "object.companyCode" }, { "fromPath": ["window.localStorage.programCode"], "toPath": "object.programCode" }, { "fromPath": ["window.localStorage.memNo"], "toPath": "object.membershipNumber" }, { "fromPath": ["config.data.businessType"], "toPath": "object.businessType" }, { "fromPath": ["state.familyName"], "toPath": "object.familyName" }, { "fromPath": ["state.givenName"], "toPath": "object.airRetroclaimRequest.ticketedFirstName" }, { "fromPath": ["state.familyName"], "toPath": "object.airRetroclaimRequest.ticketedLastName" }, { "fromPath": ["state.title"], "toPath": "object.airRetroclaimRequest.ticketTitle" }, { "fromPath": ["state.title"], "toPath": "object.title" }, { "fromPath": ["state.givenName"], "toPath": "object.givenName" }, { "fromPath": ["config.data.retroClaimStatus"], "toPath": "object.retroClaimStatus" }, { "fromPath": ["config.data.requiredAction"], "toPath": "object.requiredAction" }, { "fromPath": ["config.data.cabinClass"], "toPath": "object.airRetroclaimRequest.cabinClass" }, { "fromPath": ["config.data.bookingClass"], "toPath": "object.airRetroclaimRequest.bookingClass" }, { "fromPath": ["config.data.empty"], "toPath": "object.reasonCode" }, { "fromPath": ["object.partnerCode"], "toPath": "object.airRetroclaimRequest.carrierCode" }, { "fromPath": ["config.data.empty"], "toPath": "object.processingDate" }, { "fromPath": ["config.data.empty"], "toPath": "object.remarks" }, { "fromPath": ["config.data.empty"], "toPath": "object.confirmationSentDate" }, { "fromPath": ["getCurrentDate()"], "toPath": "object.claimDate" }, { "fromPath": ["config.data.empty"], "toPath": "object.confirmedDate" }, { "fromPath": ["config.data.empty"], "toPath": "object.retroclaimReferenceNumber" }] }, "layout": { "order": ["submitClaim"], "elements": { "submitClaim": { "className": "col-lg-4 col-md-6", "fields": [{ "path": { "request": "object.partnerCode", "response": "" }, "visibility": true, "name": "partnerCode", "id": "id-partnerCode", "validations": [{ "pattern": "^[A-Z]{1,2}$", "customMessageId": "form.partnerCode.errorMessage.invalid" }], "fieldType": "SD", "source": { "type": "master", "key": "airlines", "selector": { "label": "AirlineName", "value": "TwoAlphaCode" } }, "required": true, "error": true }, { "path": { "request": "object.airRetroclaimRequest.flightNumber", "response": "" }, "visibility": true, "name": "flightNumber", "id": "id-flightNumber", "validations": [{ "pattern": "^[0-9]{1,6}$", "customMessageId": "form.flightNumber.errorMessage.invalid" }], "fieldType": "TF", "required": true, "error": true }, { "path": { "request": "object.activityDate", "response": "" }, "visibility": true, "name": "travelDate", "id": "id-travelDate", "validations": [{ "pattern": "^[0-9]{2}-[a-zA-Z]{3}-[0-9]{4}$", "customMessageId": "form.travelDate.errorMessage.invalid" }], "fieldType": "D", "minDate": -60, "maxDate": -3, "required": true, "error": true }, { "path": { "request": "object.airRetroclaimRequest.originAirport", "response": "" }, "visibility": true, "name": "originAirport", "id": "id-originAirport", "validations": [{ "pattern": "^[ a-zA-Z0-9]{1,20}$", "customMessageId": "form.originAirport.errorMessage.invalid" }], "fieldType": "SD", "source": { "type": "master", "key": "airport", "selector": { "label": "AirportName", "value": "AirportCode" } }, "required": true, "error": true }, { "path": { "request": "object.airRetroclaimRequest.destinationAirport", "response": "" }, "visibility": true, "name": "destinationAirport", "id": "id-destinationAirport", "validations": [{ "pattern": "^[ a-zA-Z0-9]{1,20}$", "customMessageId": "form.destinationAirport.errorMessage.invalid" }], "fieldType": "SD", "source": { "type": "master", "key": "airport", "selector": { "label": "AirportName", "value": "AirportCode" } }, "required": true, "error": true }, { "path": { "response": "" }, "visibility": true, "name": "passengerDetails", "id": "id-passengerDetails", "fieldType": "B", "source": { "type": "props", "key": "family", "selector": { "label": "displayName", "value": "membershipNumber" } }, "required": true, "removeDefaultOption": true }, { "path": { "request": "object.airRetroclaimRequest.ticketNumber", "response": "" }, "visibility": true, "name": "ticketNumber", "id": "id-ticketNumber", "validations": [{ "pattern": "^[ a-zA-Z0-9]{1,20}$", "customMessageId": "form.ticketNumber.errorMessage.invalid" }], "fieldType": "TF", "required": true, "error": true }, { "path": { "request": "object.airRetroclaimRequest.pnr", "response": "" }, "visibility": true, "name": "bookingReferenceNumber", "id": "id-bookingReferenceNumber", "validations": [{ "pattern": "^[ a-zA-Z0-9]{1,20}$", "customMessageId": "form.bookingReferenceNumber.errorMessage.invalid" }], "fieldType": "TF", "required": true, "error": true }] } } } } } }
const accountSummaryResponse = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "title": "Mr", "givenName": "Indrajith", "familyName": "Sukumaran", "membershipType": "Individual", "membershipStatus": "Active", "membershipStatusCode": "A", "accountStatus": "Active", "accountStatusCode": "A", "suspended": false, "tierCode": "BLU", "tierName": "Blue", "tierFromDate": "01-Jul-2020", "tierToDate": "", "prospectTier": "", "companyName": "", "expiryDate": null, "lastActivityDate": "17-Aug-2020", "activityType": "Add Account Nominee", "expiryDetails": [{ "pointType": "FS", "points": 1.0, "expiryDate": "28-Jul-2021" }, { "pointType": "BONUS", "points": 1750.0, "expiryDate": "31-Jul-2023" }, { "pointType": "BASE", "points": 6500.0, "expiryDate": "31-Jul-2023" }], "pointDetails": [{ "pointType": "BASE", "pointTypeGroup": "Total Miles", "totalAccuredpoints": 16500.0, "totalRedeemedpoints": 10000.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 6500.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "BONUS", "pointTypeGroup": "Total Miles", "totalAccuredpoints": 1750.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 1750.0, "bonusDetails": [{ "bonusCode": "CBNBNS", "bonusName": "Cabin Bonus", "points": 1250.0 }, { "bonusCode": "ENB", "bonusName": "Enrolment Partner Bonus", "points": 500.0 }], "creditLimit": 0.0 }, { "pointType": "TIER", "pointTypeGroup": "Qualifying Miles", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "TIERKE", "pointTypeGroup": "Qualifying Miles", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "FS", "pointTypeGroup": "Qualifying Segments", "totalAccuredpoints": 1.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 1.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "FC", "pointTypeGroup": "Qualifying Segments", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }] } }
const airlineMasterresponse = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "companyCode": "IBS", "entityCode": "ARLMST", "programCode": "PRG14", "masterRecordList": [{ "AlphaCodeInUse": "1", "AirlineIdentifier": "3001", "TwoAlphaCode": "NH", "AirlineName": "ANA", "NumericCodeInUse": "1" }, { "AlphaCodeInUse": "1", "AirlineIdentifier": "9100", "TwoAlphaCode": "AM", "AirlineName": "Aeromexico", "NumericCodeInUse": "1" }, { "AlphaCodeInUse": "1", "AirlineIdentifier": "7005", "TwoAlphaCode": "BX", "AirlineName": "Air Busan", "NumericCodeInUse": "1" }, { "AlphaCodeInUse": "2", "FourNumericCode": "0014", "AirlineIdentifier": "1014", "TwoAlphaCode": "AC", "ThreeNumericCode": "014", "AirlineName": "Air Canada", "NumericCodeInUse": "3" }, { "AlphaCodeInUse": "1", "AirlineIdentifier": "1011", "TwoAlphaCode": "PG", "AirlineName": "Bangkok Airways", "NumericCodeInUse": "1" }, { "AlphaCodeInUse": "1", "AirlineIdentifier": "1106", "TwoAlphaCode": "BW", "AirlineName": "Caribbean Airlines", "NumericCodeInUse": "1" }, { "AlphaCodeInUse": "1", "AirlineIdentifier": "160", "TwoAlphaCode": "CX", "AirlineName": "Cathay Pacific", "NumericCodeInUse": "1" }, { "AlphaCodeInUse": "1", "AirlineIdentifier": "1120", "TwoAlphaCode": "CM", "AirlineName": "Copa Airlines", "NumericCodeInUse": "1" }, { "AlphaCodeInUse": "1", "AirlineIdentifier": "9200", "TwoAlphaCode": "DL", "AirlineName": "Delta Airlines", "NumericCodeInUse": "1" }, { "AlphaCodeInUse": "1", "AirlineIdentifier": "6000", "TwoAlphaCode": "EK", "AirlineName": "Emirates", "NumericCodeInUse": "1" }, { "AlphaCodeInUse": "1", "AirlineIdentifier": "7001", "TwoAlphaCode": "EY", "AirlineName": "Etihad", "NumericCodeInUse": "1" }, { "AlphaCodeInUse": "1", "AirlineIdentifier": "7000", "TwoAlphaCode": "GF", "AirlineName": "Gulf Air", "NumericCodeInUse": "1" }, { "AlphaCodeInUse": "2", "AirlineIdentifier": "70074", "TwoAlphaCode": "HA", "AirlineName": "Hawaiian Airlines", "NumericCodeInUse": "2" }, { "AlphaCodeInUse": "2", "AirlineIdentifier": "1131", "TwoAlphaCode": "JL", "ThreeNumericCode": "131", "AirlineName": "Japan Airlines", "NumericCodeInUse": "3" }, { "AlphaCodeInUse": "2", "AirlineIdentifier": "9999", "TwoAlphaCode": "KQ", "ThreeNumericCode": "999", "AirlineName": "Kenya Airways", "NumericCodeInUse": "3" }, { "AlphaCodeInUse": "2", "AirlineIdentifier": "8760", "ThreeAlphaCode": "KAL", "TwoAlphaCode": "KE", "AirlineName": "Korean Air", "NumericCodeInUse": "2" }, { "AlphaCodeInUse": "1", "AirlineIdentifier": "1910", "TwoAlphaCode": "WY", "AirlineName": "Oman Air", "NumericCodeInUse": "1" }, { "AlphaCodeInUse": "1", "AirlineIdentifier": "2001", "ThreeAlphaCode": "PAL", "TwoAlphaCode": "PR", "AirlineName": "Philippine Airlines", "NumericCodeInUse": "3" }, { "AlphaCodeInUse": "1", "AirlineIdentifier": "6500", "TwoAlphaCode": "QF", "AirlineName": "Qantas", "NumericCodeInUse": "1" }, { "AlphaCodeInUse": "0", "AirlineIdentifier": "1618", "TwoAlphaCode": "SQ", "AirlineName": "Singapore Airlines", "NumericCodeInUse": "0" }, { "AlphaCodeInUse": "2", "FourNumericCode": "0083", "AirlineIdentifier": "1083", "TwoAlphaCode": "SA", "ThreeNumericCode": "083", "AirlineName": "South African Airways", "NumericCodeInUse": "3" }, { "AlphaCodeInUse": "1", "AirlineIdentifier": "2300", "TwoAlphaCode": "UX", "AirlineName": "Unicorn", "NumericCodeInUse": "1" }, { "AlphaCodeInUse": "1", "AirlineIdentifier": "9008", "TwoAlphaCode": "VN", "AirlineName": "Vietnam Airlines", "NumericCodeInUse": "2" }, { "AlphaCodeInUse": "1", "AirlineIdentifier": "1001", "ThreeAlphaCode": "VTU", "TwoAlphaCode": "VT", "AirlineName": "Virgin Train USA", "NumericCodeInUse": "1" }, { "AlphaCodeInUse": "0", "AirlineIdentifier": "5000", "TwoAlphaCode": "UK", "AirlineName": "Vistara Airlines", "NumericCodeInUse": "1" }] } }
const airportMasterResponse = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "companyCode": "IBS", "entityCode": "ARPMST", "programCode": "PRG14", "masterRecordList": [{ "AirportCode": "---", "AirportName": "----Herzlia", "CountryCode": "IL" }, { "AirportCode": "0A7", "AirportName": "0A7-Hendersonville Airport", "CountryCode": "US" }, { "AirportCode": "AAD", "AirportName": "AAD-Ad-Dabbah", "CountryCode": "SD" }, { "AirportCode": "AAF", "AirportName": "AAF-Municipal", "CountryCode": "US" }, { "AirportCode": "AAH", "AirportName": "AAH-Aachen/Merzbruck", "CountryCode": "DE" }, { "AirportCode": "AAJ", "AirportName": "AAJ-Cayana Airstrip", "CountryCode": "SR" }, { "AirportCode": "AAL", "AirportName": "AALBORG", "CountryCode": "DK" }, { "AirportCode": "ZTG", "AirportName": "AALBORG RAIL", "CountryCode": "DK" }, { "AirportCode": "AES", "AirportName": "AALESUND", "CountryCode": "NO" }, { "AirportCode": "AAP", "AirportName": "AAP-Andrau Airpark", "CountryCode": "US" }, { "AirportCode": "AAR", "AirportName": "AARHUS", "CountryCode": "DK" }, { "AirportCode": "ZJH", "AirportName": "AARHUS RAIL", "CountryCode": "DK" }] } }
const MASTER_ENTITY_LOOKUP = [{ "key": "airport", "value": "ARPMST" }, { "key": "country", "value": "CNTMST" }, { "key": "partners", "value": "ARLMST" }, { "key": "airline_booking_class", "value": "ARLBKGCLSMST" }, { "key": "title", "value": "TLEMST" }, { "key": "mileage", "value": "MILMST" }, { "key": "language", "value": "LNGMST" }, { "key": "state", "value": "STTMST" }, { "key": "city", "value": "CTYMST" }]
const familyRetrieveResponse = {
    "statuscode": "200", "statusMessage": "SUCCESS", "object":
        [{ "membershipNumber": "IM0008010963", "displayName": "MR Ahmad Ali", "relationship": "B", "dateOfBirth": "20-Mar-1985", "emailAddress": "ahmad_ali@testemail.com", "nomineeStatus": "Active", "tierCode": "GOL", "tierName": "Gold", "expiryDetails": [{ "pointType": "TIER", "points": 600, "expiryDate": "26-Mar-2022" }, { "pointType": "KC", "points": 4, "expiryDate": "26-Mar-2022" }, { "pointType": "LP", "points": 1000, "expiryDate": "27-Mar-2023" }, { "pointType": "LP", "points": 1000, "expiryDate": "28-Mar-2023" }, { "pointType": "LP", "points": 1000, "expiryDate": "04-Apr-2023" }, { "pointType": "LP", "points": 1000, "expiryDate": "23-Apr-2023" }, { "pointType": "LP", "points": 1000, "expiryDate": "24-Apr-2023" }, { "pointType": "BASE", "points": 1000, "expiryDate": "25-Apr-2023" }, { "pointType": "LP", "points": 1000, "expiryDate": "26-Apr-2023" }, { "pointType": "BONUS", "points": 200, "expiryDate": "26-Mar-2024" }, { "pointType": "LP", "points": 5000, "expiryDate": "26-Mar-2024" }], "pointDetails": [{ "pointType": "BASE", "pointTypeGroup": "Airpoints Dollars", "totalAccuredpoints": 1000, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 1000, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "BONUSAPD", "pointTypeGroup": "Airpoints Dollars", "totalAccuredpoints": 0, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 0, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "LP", "pointTypeGroup": "Loyalty Points", "totalAccuredpoints": 11000, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 11000, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "BONUS", "pointTypeGroup": "Loyalty Points", "totalAccuredpoints": 200, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 200, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "DPTPNT", "pointTypeGroup": "Loyalty Points", "totalAccuredpoints": 0, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 0, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "SECLSTYER", "pointTypeGroup": "Loyalty Points", "totalAccuredpoints": 0, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 0, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "THRLSTYER", "pointTypeGroup": "Loyalty Points", "totalAccuredpoints": 0, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 0, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "TIER", "pointTypeGroup": "Status Points", "totalAccuredpoints": 600, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 600, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "TIERCC", "pointTypeGroup": "Status Points", "totalAccuredpoints": 400, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 400, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "FS", "pointTypeGroup": "Total Flights", "totalAccuredpoints": 0, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 0, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "FC", "pointTypeGroup": "Total Flights", "totalAccuredpoints": 0, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 0, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "REVENUE", "pointTypeGroup": "Revenue (NZD)", "totalAccuredpoints": 0, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 0, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "BC", "pointTypeGroup": "Benefits", "totalAccuredpoints": 1, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 1, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "KC", "pointTypeGroup": "Benefits", "totalAccuredpoints": 4, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 4, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "WIFI", "pointTypeGroup": "Benefits", "totalAccuredpoints": 5, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 5, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "CV", "pointTypeGroup": "Benefits", "totalAccuredpoints": 3, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 3, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "DF", "pointTypeGroup": "Benefits", "totalAccuredpoints": 1, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 1, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "MV", "pointTypeGroup": "Benefits", "totalAccuredpoints": 0, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 0, "bonusDetails": [], "creditLimit": 0 }], "activeNominee": true }, {
            "membershipNumber": "IM0008010965", "displayName": "MR Althaf Mohamed", "relationship": "F", "dateOfBirth": "06-Mar-1950", "emailAddress": "althaf@gmail.com", "nomineeStatus": "Active", "tierCode": "ELT", "tierName": "Elite", "expiryDetails": [{ "pointType": "TIER", "points": 1000, "expiryDate": "28-Mar-2022" }, { "pointType": "KC", "points": 7, "expiryDate": "28-Mar-2022" }, { "pointType": "LP", "points": 5000, "expiryDate": "28-Mar-2024" }, { "pointType": "BONUS", "points": 1000, "expiryDate": "28-Mar-2024" }, { "pointType": "BASE", "points": 1000, "expiryDate": "28-Mar-2025" }], "pointDetails": [{ "pointType": "BASE", "pointTypeGroup": "Airpoints Dollars", "totalAccuredpoints": 1000, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 1000, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "BONUSAPD", "pointTypeGroup": "Airpoints Dollars", "totalAccuredpoints": 0, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 0, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "LP", "pointTypeGroup": "Loyalty Points", "totalAccuredpoints": 5000, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 5000, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "BONUS", "pointTypeGroup": "Loyalty Points", "totalAccuredpoints": 1000, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 1000, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "DPTPNT", "pointTypeGroup": "Loyalty Points", "totalAccuredpoints": 0, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 0, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "SECLSTYER", "pointTypeGroup": "Loyalty Points", "totalAccuredpoints": 0, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 0, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "THRLSTYER", "pointTypeGroup": "Loyalty Points", "totalAccuredpoints": 0, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 0, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "TIER", "pointTypeGroup": "Status Points", "totalAccuredpoints": 1000, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 1000, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "TIERCC", "pointTypeGroup": "Status Points", "totalAccuredpoints": 500, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 500, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "FS", "pointTypeGroup": "Total Flights", "totalAccuredpoints": 2, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 2, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "FC", "pointTypeGroup": "Total Flights", "totalAccuredpoints": 0, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 0, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "REVENUE", "pointTypeGroup": "Revenue (NZD)", "totalAccuredpoints": 0, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 0, "bonusDetails": [], "creditLimit": 0 }, {
                "pointType": "BC", "pointTypeGroup": "Benefits", "totalAccuredpoints": 2, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 2, "bonusDetails": [],
                "creditLimit": 0
            }, {
                "pointType": "KC", "pointTypeGroup": "Benefits", "totalAccuredpoints": 7, "totalRedeemedpoints": 0,
                "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 7, "bonusDetails": [], "creditLimit": 0
            }, {
                "pointType": "WIFI",
                "pointTypeGroup": "Benefits", "totalAccuredpoints": 5, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0,
                "points": 5, "bonusDetails": [], "creditLimit": 0
            }, { "pointType": "CV", "pointTypeGroup": "Benefits", "totalAccuredpoints": 2, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 2, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "DF", "pointTypeGroup": "Benefits", "totalAccuredpoints": 10, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 10, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "MV", "pointTypeGroup": "Benefits", "totalAccuredpoints": 10, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 10, "bonusDetails": [], "creditLimit": 0 }], "activeNominee": true
        }, { "membershipNumber": "IM0008010336", "displayName": "Mr Rasheed K", "relationship": "B", "dateOfBirth": "24-Jan-1967", "emailAddress": "rasheedk67@gmail.com", "nomineeStatus": "Active", "tierCode": "SIL", "tierName": "Silver", "expiryDetails": [{ "pointType": "FLTCNT", "points": 9, "expiryDate": "07-Oct-2021" }, { "pointType": "TIER", "points": 325, "expiryDate": "07-Oct-2021" }, { "pointType": "CV", "points": 2, "expiryDate": "07-Oct-2021" }, { "pointType": "KC", "points": 4, "expiryDate": "07-Oct-2021" }, { "pointType": "TIERCC", "points": 230, "expiryDate": "07-Oct-2021" }, { "pointType": "LP", "points": 1000, "expiryDate": "18-Apr-2023" }, { "pointType": "BASE", "points": 1000, "expiryDate": "25-Apr-2023" }, { "pointType": "BASE", "points": 1000, "expiryDate": "27-Apr-2023" }, { "pointType": "BASE", "points": 190, "expiryDate": "07-Oct-2024" }, { "pointType": "BASE", "points": 5000, "expiryDate": "25-Apr-2025" }, { "pointType": "BASE", "points": 1000, "expiryDate": "27-Apr-2025" }], "pointDetails": [{ "pointType": "BASE", "pointTypeGroup": "Airpoints Dollars", "totalAccuredpoints": 8190, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 8190, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "BONUSAPD", "pointTypeGroup": "Airpoints Dollars", "totalAccuredpoints": 0, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 0, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "LP", "pointTypeGroup": "Loyalty Points", "totalAccuredpoints": 2100, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 2100, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "BONUS", "pointTypeGroup": "Loyalty Points", "totalAccuredpoints": 0, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 0, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "DPTPNT", "pointTypeGroup": "Loyalty Points", "totalAccuredpoints": 190, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 0, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "SECLSTYER", "pointTypeGroup": "Loyalty Points", "totalAccuredpoints": 0, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 0, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "THRLSTYER", "pointTypeGroup": "Loyalty Points", "totalAccuredpoints": 0, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 0, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "TIER", "pointTypeGroup": "Status Points", "totalAccuredpoints": 325, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 325, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "TIERCC", "pointTypeGroup": "Status Points", "totalAccuredpoints": 230, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 230, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "FS", "pointTypeGroup": "Total Flights", "totalAccuredpoints": 0, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 0, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "FC", "pointTypeGroup": "Total Flights", "totalAccuredpoints": 0, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 0, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "REVENUE", "pointTypeGroup": "Revenue (NZD)", "totalAccuredpoints": 0, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 0, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "BC", "pointTypeGroup": "Benefits", "totalAccuredpoints": 0, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 0, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "KC", "pointTypeGroup": "Benefits", "totalAccuredpoints": 4, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 4, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "WIFI", "pointTypeGroup": "Benefits", "totalAccuredpoints": 0, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 0, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "CV", "pointTypeGroup": "Benefits", "totalAccuredpoints": 2, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 2, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "DF", "pointTypeGroup": "Benefits", "totalAccuredpoints": 0, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 0, "bonusDetails": [], "creditLimit": 0 }, { "pointType": "MV", "pointTypeGroup": "Benefits", "totalAccuredpoints": 0, "totalRedeemedpoints": 0, "pointsToNextTier": 0, "pointsForTierRetention": 0, "points": 0, "bonusDetails": [], "creditLimit": 0 }], "activeNominee": true }]
}

const submitClaimError = { "statuscode": "500", "statusMessage": "FAILURE", "error": { "code": "500", "type": "INTERNAL_SERVER_ERROR", "message": "Retro claim failed", "errorDetails": [{ "message": "Miles flown to zero" }] } }
const submitClaimSuccess = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010336", "partnerCode": "NZ", "retroclaimReferenceNumber": "5402", "status": "P" } }
const errorResponse = { "statuscode": "500", "statusMessage": "FAILURE", "error": { "code": "500", "type": "INTERNAL_SERVER_ERROR", "message": "Some error" } }
const reqToSubmitClaim = { "object": { "partnerCode": "NZ", "airRetroclaimRequest": { "flightNumber": "1111", "originAirport": "AKL", "destinationAirport": "YVR", "ticketNumber": "12345", "pnr": "12345", "ticketedFirstName": "Ahmad", "ticketedLastName": "Ali", "ticketTitle": "MR", "cabinClass": "D", "bookingClass": "D", "carrierCode": "NZ" }, "activityDate": "02-May-2021", "recipientMembershipNumber": "IM0008010963", "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010964", "businessType": "A", "familyName": "Ali", "title": "MR", "givenName": "Ahmad", "retroClaimStatus": "D", "requiredAction": "P", "reasonCode": "", "processingDate": "", "remarks": "", "confirmationSentDate": "", "claimDate": "07-May-2021", "confirmedDate": "", "retroclaimReferenceNumber": "" } }