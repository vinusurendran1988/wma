import React, { Component } from 'react';
import { getDiffByTwoDate, getCurrentDate, getFormattedDate, withSuspense, toTitleCase } from '../../common/utils';
import { DD_MMM_YYYY, CONFIG_SECTION_DEFAULT, CONFIG_SECTION_ACCOUNT_SUMMARY } from '../../common/utils/Constants';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';
import { getItemFromBrowserStorage, BROWSER_STORAGE_KEY_COMPANY_CODE, BROWSER_STORAGE_KEY_PROGRAM_CODE } from '../../common/utils/storage.utils';
import { doPost } from '../../common/utils/api';
import { _URL_FETCH_PROFILE_IMAGE, _IMAGE_BASEURL } from '../../common/config/config';
import DonutChart from './donutChart';
class FamilyPoolingCard extends Component {
    constructor(props){
        super(props)
        this.state = {
            profileImage: props.image?props.image:`${_IMAGE_BASEURL}/default-profile-picture.png`
        }
    }

    componentDidMount(){
        this.fetchProfilePhoto(this.props.membershipNumber)
    }

    getAge(dateString = "") {
        return getDiffByTwoDate(getCurrentDate(DD_MMM_YYYY), getFormattedDate(dateString, DD_MMM_YYYY, DD_MMM_YYYY), DD_MMM_YYYY, DD_MMM_YYYY, "years")
    }

    getStyleClassName = (tierName) => {
        return {
            "standard": "blue",
            "gold":"gold",
            "silver": "silver",
            "elite": "black"

        }[tierName.toLowerCase()]
    }

    /**
     * Function to get the expanded relationName from the defaultConfig when provided respective relationCode
     * @author Somdas M
     * @param {string} relationCode - The relation code in short
     */
    getRelationship(relationCode){
        const { defaultConfig, isSelf } = this.props
        if(isSelf){
            return this.props.t("my_family.my_self").toUpperCase()
        }
        const currentDefaultConfig = getCurrentProgramFromDefaultConfig(defaultConfig)
        if(currentDefaultConfig){
           const relation =  currentDefaultConfig.data.relationshipCodes.find(e=>e.key==relationCode)
            if(relation){
                return relation.value.toUpperCase()
            }
        }
        return ""
    }

    fetchProfilePhoto(membershipNumber) {
        const { details } = this.props;
        const requestBody = {
            object: {
                companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                membershipNumber: membershipNumber
            }
        }
        doPost(_URL_FETCH_PROFILE_IMAGE, requestBody)
            .then(response => {
                const profileImage = 'data:image/png;base64, ' + response.data.object.profileImgData;
                this.setState({
                    profileImage
                })
            }).catch(error => {
                console.log(error);
            })
    }

    
    render() {
        const {
            currentTier,
            fullName,
            totalMiles,
            relation,
            dateOfBirth,
            membershipNumber,
            email,
            totalPoints,
            accountSummaryConfig,
            currentPoints,
            nextPoints,
            icon,
            color,
            iconType,
            t
        } = this.props

        const {
            profileImage 
        } = this.state

        return (
            <ul className="listing--family__content">
                <li className={`list ${this.getStyleClassName(currentTier)}`}> <span className="tag">{currentTier}</span>
                    <div className="items">
                        <div className="items__thumb">
                            <img src={profileImage} width={"100px"}/>
                        </div>
                        <div className="items__details">
                            <h3>{toTitleCase(fullName)} / {totalMiles} {t('my_family.points')}</h3>
                            <span className="badge">{this.getRelationship(relation)} - {this.getAge(dateOfBirth)}</span>
                            <div className="info"> <span>{`${t('my_family.ffpNo')} ${membershipNumber}`}</span>
                                <span>{email}</span>
                            </div>
                        </div>
                        <div className="items__graph">
                            <div className="items__title d-md-blok d-lg-none">{t("my_family.progress_header")}</div>
                            <div className="graph">
                                <DonutChart
                                    // currentTier={currentTier}
                                    // nextTier={nextTier ? nextTier.tierName : ""}
                                    pointsAchieved={currentPoints}
                                    nextTarget={nextPoints}
                                    // difference={parseInt(option.diff)}
                                    icon={iconType?iconType:"point"}
                                    colors={color}
                                    totalPoints={totalPoints}
                                />
                            </div> 
                            {/* <span>21,801 MORE MILES TO PLATINUM</span> */}
                        </div>
                        <div className="items__access">
                            {/* <div className="items__title d-md-blok d-lg-none">Who else can use this miles</div>
                            <ul>
                                <li><i><img src={`${_IMAGE_BASEURL}/icon-tick.svg`} width="18" height="18" /></i><span>Paul Barbara</span>
                                </li>
                                <li><i><img src={`${_IMAGE_BASEURL}/icon-cancel.svg`} width="18" height="18" /></i><span>Paul Barbara</span>
                                </li>
                                <li><i><img src={`${_IMAGE_BASEURL}/icon-tick.svg`} width="18" height="18" /></i><span>Paul Barbara</span>
                                </li>
                            </ul> */}
                        </div>
                        <div className="items__utils">
                            <div className="p-2">
                                <div className="dropdown">
                                    {/* <a className="" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i className="fa fa-ellipsis-v" aria-hidden="true"></i>
                                    </a>
                                    <div className="dropdown-menu" aria-labelledby="dropdownMenuLink"> <a className="dropdown-item" href="#">View Tickets</a>
                                        <a className="dropdown-item" href="#">Manage Booking</a>
                                        <a className="dropdown-item" href="#">Upgrade Class</a>
                                        <a className="dropdown-item" href="#">Cancel Booking</a>
                                    </div> */}
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
        );
    }
}

const mapStateToProps = state => {
    return {
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        accountSummary: state.accountSummaryReducer.accountSummary,
        accountSummaryConfig: state.configurationReducer[CONFIG_SECTION_ACCOUNT_SUMMARY]
    }
}

const mapDispatchToProps = {
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(FamilyPoolingCard)));