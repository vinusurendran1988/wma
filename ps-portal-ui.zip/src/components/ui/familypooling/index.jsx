import React from 'react';
import { connect } from 'react-redux';
import parse from 'html-react-parser';
import { 
    CONFIG_SECTION_MYFAMILY, 
    CONFIG_SECTION_DEFAULT,
    CONFIG_SECTION_ACCOUNT_SUMMARY
} from '../../common/utils/Constants';
import { withTranslation } from 'react-i18next';
import {
    withSuspense,
    numberWithCommas
} from '../../common/utils';
import {
    fetchAccountSummary,
    fetchConfiguration,
    getFamilyMembers
} from '../../common/middleware/redux/commonAction';
import {
    NAVIGATE_FAMILY_MEMBER_ADD,
    NAVIGATE_TRANSFER
} from '../../common/utils/urlConstants';
import {
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
    getItemFromBrowserStorage,
} from '../../common/utils/storage.utils';
import FamilyPoolingCard from './FamilyPoolingCard';

class FamilyMembers extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            totalSkypassPoint: 0,
            totalPooledPoints: 0,
            totalFamilyMembers: 0,
            from: [],
            to: [],
            membershipNumber: "",
        }
    }
    componentDidMount() {
        const object = {
            companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
            programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
            membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)
        }
        this.props.setPageInfo(this.props, {config: this.props.familyConfig, confSection: CONFIG_SECTION_MYFAMILY})
        if(!this.props.familyConfig){
            this.props.fetchConfiguration(CONFIG_SECTION_MYFAMILY)
        }
        if (!this.props.familyMemberDetails || this.props.familyMemberDetails.length == 0) {
            this.props.fetchFamilyMemberDetails({object});
        }
        if(!this.props.accountSummary){
            this.props.fetchAccountSummary()
        }
        this.reCalculate()
    }

    componentDidUpdate() {
        this.reCalculate()
    }

    reCalculate = () => {

            const newState = {}
            let totalSkypassPoint = 0, totalPooledPoints = 0, totalFamilyMembers = 0
    
            if (this.props.familyConfig && Object.keys(this.props.familyConfig).length > 0 ) {
                const poolingPointType = this.props.familyConfig.ui.pointTypes.pooling
                const poolingSharingConfig = this.props.familyConfig.ui.poolingSharingConfig
                if (this.props.familyMemberDetails.length == 0 && poolingSharingConfig && poolingPointType) {
                    totalFamilyMembers++;
                    if (this.props.accountSummary && Object.keys(this.props.accountSummary).length > 0) {
                        poolingPointType.forEach(pointType => {
                            try {
                                const pointDetails = this.props.accountSummary.pointDetails.find(ob => ob.pointType === pointType);
                                totalSkypassPoint += parseInt(pointDetails.points)
                                totalPooledPoints += parseInt(pointDetails.points)
                            } catch (error) {
                                console.log(error);
                            }
                        })
                    }
                } else if (this.props.accountSummary &&
                    Object.keys(this.props.accountSummary).length > 0 &&
                    poolingSharingConfig && poolingPointType) {
    
                    if (this.state.membershipNumber === "") newState["membershipNumber"] = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)
                    if (this.state.from.length == 0) newState["from"] = poolingSharingConfig[getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)] ? poolingSharingConfig[getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)].from : [""]
                    if (this.state.to.length == 0) newState["to"] = poolingSharingConfig[getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)] ? poolingSharingConfig[getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)].to : [""]
    
                    this.props.familyMemberDetails.map(member => {
                        totalFamilyMembers++
                        poolingPointType.forEach(pointType => {
                            try {
                                const pointDetails = member.pointDetails.find(ob => ob.pointType === pointType);
                                totalSkypassPoint += parseInt(pointDetails.points);
                                if (poolingSharingConfig.accessForAll || (poolingSharingConfig[getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)] &&
                                    poolingSharingConfig[getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)].from.includes(member.membershipNumber))) {
                                    totalPooledPoints += parseInt(pointDetails.points)
                                }
                            } catch (error) {
                                console.log(error);
                            }
                        })
                    })
                    totalFamilyMembers++;
                    poolingPointType.forEach(pointType => {
                        try {
                            const pointDetails = this.props.accountSummary.pointDetails.find(ob => ob.pointType === pointType);
                            totalSkypassPoint += parseInt(pointDetails.points);
                            totalPooledPoints += parseInt(pointDetails.points)
                        } catch (error) {
                            console.log(error);
                        }
                    })
                }
            }
            if (this.state.totalFamilyMembers != totalFamilyMembers && totalFamilyMembers > 0) {
                newState["totalFamilyMembers"] = totalFamilyMembers
            }
            if (this.state.totalPooledPoints != totalPooledPoints && totalPooledPoints > 0) {
                newState["totalPooledPoints"] = totalPooledPoints
            }
            if (this.state.totalSkypassPoint != totalSkypassPoint && totalSkypassPoint > 0) {
                newState["totalSkypassPoint"] = totalSkypassPoint
            }
            if (Object.keys(newState).length > 0) {
                this.setState(newState)
            }
        
    }


    getNextTier = (currentTierCode) => {
        const { accountSummaryConfig } = this.props
        if(accountSummaryConfig){
           let currentTierIndex = -1
            accountSummaryConfig.tiers.some((e, i)=> {
               if(e.code == currentTierCode) {
                   return currentTierIndex=i
               }
            })
            if (currentTierIndex > -1 && currentTierIndex < accountSummaryConfig.tiers.length - 2) {
                return {
                    "name": accountSummaryConfig.tiers[++currentTierIndex].name,
                    "code": accountSummaryConfig.tiers[currentTierIndex].code
                }
            }
        }
        return {}
    }
    getTotalMiles = (member) => {
        let points = 0;
        if (this.props.familyConfig && Object.keys(this.props.familyConfig).length > 0) {
            const poolingPointType = this.props.familyConfig.ui.pointTypes.pooling
            if (member && poolingPointType) {
                poolingPointType.forEach(pointType => {
                    try {
                        const pointDetails = member.pointDetails.find(ob => ob.pointType === pointType);
                        points += parseInt(pointDetails.points)
                    } catch (error) {
                        console.log(error);
                    }
                })
            }
        }
        return numberWithCommas(parseInt(points))
    }

    navigateTo = (url) => {
        window.location.href = `#${url}`
    }

    getCurrentPointDetails = (pointDetails) => {
        const { familyConfig } = this.props
        let currentPoints = 0;
        if(familyConfig && Object.keys(familyConfig).length>0){
            const pointTypes = familyConfig.ui.pointTypes.progress
            pointDetails.map(pointDetail=>{
                if(pointTypes.includes(pointDetail.pointType)){
                    currentPoints += pointDetail.points
                }
            })
        }
        return currentPoints
    }

    render() {

        const {
            familyMemberDetails,
            maximumFamilyMembers,
            t,
            familyConfig,
            accountSummary,
            profileData
        } = this.props;

        let tierMapping = []
        let nominee = undefined
        if (familyConfig && familyConfig.ui && familyConfig.ui.tierMapping) {
            tierMapping = familyConfig.ui.tierMapping
            nominee = familyConfig.nominee
        }
        if (accountSummary && profileData) {

            const { individualInfo } = profileData.object.memberAccount.memberProfile
            const preferredAddress = individualInfo.memberContactInfos.find(e=>e.addressType == individualInfo.preferredEmailAddress)
            const preferredEmailAddress = preferredAddress?preferredAddress.emailAddress:""

            accountSummary["membershipNumber"] = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)
            accountSummary["displayName"] = accountSummary["title"] + " " + accountSummary["givenName"] + " " + accountSummary["familyName"]
            accountSummary["dateOfBirth"] = individualInfo.dateOfBirth
            accountSummary["relationship"] = t("my_family.my_self")
            accountSummary["emailAddress"] = preferredEmailAddress
        }

        const totalPooledPoints = numberWithCommas(parseInt(this.state.totalPooledPoints))
        return (
            <>
                <div className="title title--page">
                    <h1>{parse(t('my_family.title').replace("{TOTAL_POOLED_POINTS}", totalPooledPoints))}</h1>
                    <div className="btn-wrap btn-wrap--grp">
                        <button className="btn btn-secondary" onClick={()=>{this.navigateTo(NAVIGATE_FAMILY_MEMBER_ADD)}} disabled={maximumFamilyMembers <= familyMemberDetails.length}>{t("my_family.add_family_btn")}</button>
                        <button className="btn btn-secondary" onClick={()=>{this.navigateTo(NAVIGATE_TRANSFER)}}>{t("my_family.transfer_btn")}</button>
                    </div>
                </div>
                {/* <!--listing family starts here--> */}
                <div className="listing listing--family">
                    <ul className="listing--family__title">
                        <li>{t('my_family.first_column_header')}</li>
                        <li className="d-none d-lg-block">{t("my_family.progress_header")}</li>
                        {/* <li className="d-none d-lg-block">WHO ELSE CAN USE THIS MILES</li> */}
                    </ul>
                    {
                        familyConfig && accountSummary && profileData && profileData.object &&
                        <FamilyPoolingCard
                           currentTier = {accountSummary.tierName}
                           fullName= {profileData.object.memberAccount.memberProfile.individualInfo.displayName} //todo: make configurable
                           totalMiles ={this.getTotalMiles(accountSummary)}
                           relation = {""}
                           isSelf={true}
                           dateOfBirth ={profileData.object.memberAccount.memberProfile.individualInfo.dateOfBirth}
                           membershipNumber ={profileData.object.memberAccount.memberProfile.membershipNumber}
                           email = {profileData.object.memberAccount.memberProfile.individualInfo.memberContactInfos.find(e=>e.addressType==profileData.object.memberAccount.memberProfile.individualInfo.preferredAddress).emailAddress}
                           nextTier = {this.getNextTier(accountSummary.tierCode)}
                           totalPoints = {totalPooledPoints}
                           currentPoints = {this.getCurrentPointDetails(accountSummary.pointDetails)}
                           nextPoints = {this.state.totalPooledPoints}
                           />
                    }
                    {
                       familyConfig && familyMemberDetails.map((member, index)=>{
                           return <FamilyPoolingCard
                           currentTier = {member.tierName}
                           fullName= {member.displayName}
                           totalMiles ={this.getTotalMiles(member)}
                           relation = {member.relationship}
                           dateOfBirth ={member.dateOfBirth}
                           membershipNumber ={member.membershipNumber}
                           email = {member.emailAddress}
                           nextTier = {this.getNextTier(member.tierCode)}
                           totalPoints = {totalPooledPoints}
                           currentPoints = {this.getCurrentPointDetails(member.pointDetails)}
                           nextPoints = {this.state.totalPooledPoints}
                           />

                       })
                    }
                </div>
                {/* <!--listing family ends here--> */}
            </>
        )
    }
}

const mapStateToProps = state => {
    const getValue = (variable, location = [], defaultValue = {}) => {
        try {
            if (!location.length) {
                return variable;
            }
            return getValue(variable[location.shift()], location, defaultValue);
        } catch (error) {
            return defaultValue;
        }
    }
    const familyConfig = state.configurationReducer[CONFIG_SECTION_MYFAMILY];
    const relationshipCodes = getValue(familyConfig, ['relationshipCodes']);
    const maximumFamilyMembers = familyConfig ? getValue(familyConfig, ['nominee', 'maxLimit'], familyConfig.ui.maxFamilyMembers) : 0;

    return {
        accountSummary: state.accountSummaryReducer.accountSummary,
        familyMemberDetails: state.familyListReducer.members,
        relationshipCodes,
        maximumFamilyMembers,
        familyConfig,
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        profileData: state.profileDataReducer.profileData,
        accountSummaryConfig: state.configurationReducer[CONFIG_SECTION_ACCOUNT_SUMMARY]
    }
}

const mapDispatchToProps = dispatch => {
    return {
        fetchFamilyMemberDetails: params => dispatch(getFamilyMembers(params)),
        fetchConfiguration: param => dispatch(fetchConfiguration(param)),
        fetchAccountSummary: () => dispatch(fetchAccountSummary())
    }
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(FamilyMembers)));