import React from 'react';
import { doPost } from '../../common/utils/api';
import { numberWithCommas, getCurrentDate, getFormattedDate, getDiffByTwoDate } from '../../common/utils';
import './FamilyMemberCard.css';
import { toTitleCase } from '../../common/utils'
import Stars from './Stars';
import { _URL_FETCH_PROFILE_IMAGE, _IMAGE_BASEURL } from '../../common/config/config.js';
import { getItemFromBrowserStorage, BROWSER_STORAGE_KEY_COMPANY_CODE, BROWSER_STORAGE_KEY_PROGRAM_CODE } from '../../common/utils/storage.utils';
import { DD_MMM_YYYY } from '../../common/utils/Constants';
import { getTierByCode } from '../../common/utils/tier.utils';

/**
 * This renders the family member card
 * @author Alan Kuriakose
 */
export default class FamilyMemberCard extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            image: `${_IMAGE_BASEURL}/default-profile-picture.png`,
            basePoints: {},
            nextTier: '',
            difference: 0,
            nextTarget: '',
            message: ''
        }
        this.arc1Ref = React.createRef();
        this.arc2Ref = React.createRef();
        this.circleRef = React.createRef();
        this.rectRef = React.createRef();
        this.triangleRef = React.createRef();
        this.tooltipRef = React.createRef();
        this.text1Ref = React.createRef();
        this.text2Ref = React.createRef();
        this.starsRef = React.createRef();
        this.colors = {}
    }

    componentDidMount() {
        this.fetchProfilePhoto();
        this.setExpiryDetails();
        this.setProgress();
        const { tierMapping } = this.props;
        this.colors = tierMapping.reduce((total, current) => {
            total[current.tierName] = current.color;
            return total;
        }, {})
    }
  
    componentDidUpdate() {
        if(this.state.nextTarget === '' || 
            this.state.nextTarget != this.props.totalSkypassPoint) this.setProgress()
    }

    /**
     * Function to calculate expiry details
     * @author Alan Kuriakose
     */
    setExpiryDetails() {
        const { details, progressPointType } = this.props;
        try {
            const basePoints = details.expiryDetails
                .sort((a, b) => new Date(a.expiryDate) - new Date(b.expiryDate))
                .find(ob => progressPointType.includes(ob.pointType)) || {};
            this.setState({
                basePoints
            })
        } catch (error) {
            console.log(error);
        }
    }

    /**
     * Blue
     * Silver >= 10000
     * Invitation silver
     * Gold >=40000
     * Lifetime gold
     * Platinum >= 70000
     * Lifetime platinum
     * Diamond >=100000
     * @author Alan Kuriakose
     */
    setProgress() {
        const { details, progressPointType, tierMapping, t, totalSkypassPoint } = this.props;
        if (progressPointType) {
            let pointsAchieved = 0;
            try {
                details.pointDetails.map(ob => {
                    if (progressPointType.includes(ob.pointType)) {
                        pointsAchieved += ob.points;
                    }
                });
            } catch (error) {
                console.log(error);
            }
            const { tierName } = details;
            const tierNames = tierMapping.map(tier => tier.tierName);
            //const pointLimits = tierMapping.map(tier => tier.pointsRequired);
            const tierIndex = tierNames.indexOf(tierName);
            let nextTarget = totalSkypassPoint//pointLimits[tierIndex + 1] || pointLimits[tierIndex];
            const nextTier = tierNames[tierIndex + 1] || tierNames[tierNames.length - 1];
            const difference = nextTarget - pointsAchieved;

            let message = ''
            if (difference < 0) {
                message = <div className="small text-center"><strong>{numberWithCommas(Math.floor(-difference))}</strong> {t("my_family.more_miles_than")} <strong>{nextTier}</strong></div>
            } else {
                message = <div className="small text-center"><strong>{numberWithCommas(Math.floor(difference))}</strong> {t("my_family.more_miles_to")} <strong>{nextTier}</strong></div>
            }
            this.setState({
                nextTier,
                difference,
                nextTarget,
                message
            })

            this.drawProgressBar(pointsAchieved, nextTarget < pointsAchieved ? pointsAchieved : nextTarget);
        }
    }

    /**
     * Function to draw progress bar
     * @author Alan Kuriakose
     * @param {integer} achieved - points achieved
     * @param {integer} target - target points to achieve
     */
    drawProgressBar(achieved = 1, target = 1) {
        const centerX = 119;
        const centerY = 70;
        const radius = 55;
        const startAngle = 230;
        const endAngle = 490;
        const tooltipHeight = 15;
        const tooltipMid = tooltipHeight / 2;
        const smallerCircleRadius = 10;
        const triangleStart = 5;
        const triangleWidth = 1;
        const achievedAngle = startAngle + achieved * (endAngle - startAngle) / (target==0?10:target);
        this.arc1Ref.current.setAttribute("d", this.describeArc(centerX, centerY, radius, startAngle, endAngle));
        this.arc2Ref.current.setAttribute("d", this.describeArc(centerX, centerY, radius, startAngle, achievedAngle));
        const circleCenter = this.polarToCartesian(centerX, centerY, radius, achievedAngle);
        this.circleRef.current.setAttribute("cx", circleCenter.x);
        this.circleRef.current.setAttribute("cy", circleCenter.y);
        this.tooltipRef.current.setAttribute('transform', `translate(${circleCenter.x + smallerCircleRadius}, ${circleCenter.y - tooltipHeight / 2})`)
        const trianglepath = `M ${triangleStart} ${tooltipMid} L ${triangleStart + triangleWidth} ${tooltipMid - 1} L ${triangleStart + triangleWidth} ${tooltipMid + 1}  Z`;
        this.triangleRef.current.setAttribute('d', trianglepath);
        this.rectRef.current.setAttribute('x', triangleStart + triangleWidth);
        this.rectRef.current.setAttribute('y', 0);
        const text = this.text2Ref.current;
        text.textContent = numberWithCommas(parseInt(achieved));
        text.setAttribute('x', triangleStart + triangleWidth + 5);
        text.setAttribute('y', tooltipMid + 5);
        this.starsRef.current.setAttribute('transform', `translate(${centerX - 22}, ${centerY - 25})`);
        this.rectRef.current.setAttribute('width', (typeof text.getBBox === "function") ? text.getBBox().width + 8 : 0)
        this.text1Ref.current.setAttribute('x', centerX);
        this.text1Ref.current.setAttribute('y', centerY + 30);
    }

    /**
     * Function to convert polar coordinates to rectangular coordinates
     * @author Alan Kuriakose
     * @param {integer} centerX - center x axis
     * @param {integer} centerY - center y axis
     * @param {integer} radius - radius
     * @param {integer} angleInDegrees - angle in degrees
     */
    polarToCartesian(centerX, centerY, radius, angleInDegrees) {
        const angleInRadians = (angleInDegrees - 90) * Math.PI / 180.0;

        return {
            x: centerX + (radius * Math.cos(angleInRadians)),
            y: centerY + (radius * Math.sin(angleInRadians))
        };
    }

    /**
     * Function to generate path for arc in svg
     * @author Alan Kuriakose
     * @param {integer} x - center x axis
     * @param {integer} y - center y axis
     * @param {integer} radius - radius
     * @param {integer} startAngle - start angle in degrees
     * @param {integer} endAngle - end angle in degrees
     */
    describeArc(x, y, radius, startAngle, endAngle) {

        const start = this.polarToCartesian(x, y, radius, endAngle);
        const end = this.polarToCartesian(x, y, radius, startAngle);

        const largeArcFlag = endAngle - startAngle <= 180 ? "0" : "1";

        const d = [
            "M", start.x, start.y,
            "A", radius, radius, 0, largeArcFlag, 0, end.x, end.y
        ].join(" ");

        return d;
    }

    /**
     * Function to fetch profile photo
     * @author Alan Kuriakose
     */
    fetchProfilePhoto() {
        const { details } = this.props;
        const requestBody = {
            object: {
                companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                membershipNumber: details.membershipNumber
            }
        }
        doPost(_URL_FETCH_PROFILE_IMAGE, requestBody)
            .then(response => {
                const image = 'data:image/png;base64, ' + response.data.object.profileImgData;
                this.setState({
                    image
                })
            }).catch(error => {
                console.log(error);
            })
    }

    /**
     * Function to calculate age
     * @author Alan Kuriakose
     * @param {string} dateString - the date string
     */
    getAge(dateString = "") {
        return getDiffByTwoDate(getCurrentDate(DD_MMM_YYYY), getFormattedDate(dateString, DD_MMM_YYYY, DD_MMM_YYYY), DD_MMM_YYYY, DD_MMM_YYYY, "years")
    }

    /**
     * Function to get the expanded relationName from the defaultConfig when provided respective relationCode
     * @author Somdas M
     * @param {string} relationCode - The relation code in short
     */
    getRelationship(relationCode){
        const { defaultConfig, isSelf } = this.props
        if(isSelf){
            return this.props.t("my_family.my_self").toUpperCase()
        }
        if(defaultConfig && defaultConfig.data && defaultConfig.data.relationshipCodes){
           const relation =  defaultConfig.data.relationshipCodes.find(e=>e.key==relationCode)
            if(relation){
                return relation.value.toUpperCase()
            }
        }
        return ""
    }

    render() {
        const { image, basePoints, nextTier, nextTarget, message } = this.state;
        const { details, fromMembers, toMembers, t, accountSummaryConfig } = this.props;
        const age = this.getAge(details.dateOfBirth);
        let themeClass = ""
        if (accountSummaryConfig) {
            const tierObject = getTierByCode(details.tierCode, accountSummaryConfig.tiers)
            if (tierObject) themeClass = tierObject.themeClass
        }
        let allowFromClass = "fa fa-times text-danger", allowToClass = "fa fa-times text-danger", isAllow = this.props.isAdmin
        if (details) {
            if (fromMembers) allowFromClass = fromMembers.filter(function (e) { return e === details.membershipNumber }).length > 0 ? "fa fa-check text-success" : "fa fa-times text-danger"
            if (toMembers) allowToClass = toMembers.filter(function (e) { return e === details.membershipNumber }).length > 0 ? "fa fa-check text-success" : "fa fa-times text-danger"
            if (!this.props.isAdmin) isAllow = allowFromClass === "fa fa-check text-success"
        }

        return (
            <div className={`familyContentWrap family${themeClass}`}>
                <div className="form-row">
                    <div className="col-4 familyContentLeft">
                        <div className="profileImgEdit"><img src={image} alt="Profile Photo" width="75" className="rounded mx-auto d-block" /><span className="iconWrap"><i className="fa fa-check" aria-hidden="true"></i><span className="sr-only">{details.nomineeStatus}</span></span></div>
                        <div className="text-center">
                            <h3>{toTitleCase(details.displayName)}</h3>
                            <div><span className="badge badge-pill badge-primary">{this.getRelationship(details.relationship)} - {age}</span></div>
                            <div><span className="badge badge-light">{details.tierName}</span></div>
                        </div>
                    </div>
                    <div className="col-8 familyContentRight">
                        <div className="d-flex justify-content-between">
                            <div>{t("my_family.ffpNo")} #{details.membershipNumber} <span>{details.emailAddress}</span></div>
                            {/* <div className="btn-group dropleft">
                                <a className="btn dropdown-toggle"  role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i className="fa fa-ellipsis-h" aria-hidden="true"></i>
                                </a>
                                <div className="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                    <a className="dropdown-item" href={`#${NAVIGATE_TRANSFER}?membershipNumber=${details.membershipNumber}`}>{t("my_family.transfer_to")} </a>
                                    {
                                        this.props.isAdmin &&
                                        <a className="dropdown-item" href=".">{t("my_family.edit_rivilege")}</a>
                                    }
                                </div>
                            </div> */}
                        </div>
                        <div className=" text-center graphWrap">
                            <svg width="238" height="123" alt="">
                                <path ref={this.arc1Ref} fill="none" stroke="#ddd" className="arc-path" />
                                <path ref={this.arc2Ref} fill="none" stroke="#446688" className="arc-path" />
                                <circle ref={this.circleRef} fill="orange" stroke="white" strokeWidth="2" r="10" />
                                <g ref={this.starsRef}>
                                    <Stars width={45} height={35} color={this.colors[nextTier] || this.colors.Diamond} />
                                </g>
                                <text ref={this.text1Ref} fontWeight="bold" textAnchor="middle" stroke={this.colors[nextTier] || this.colors.Diamond} >{numberWithCommas(parseInt(this.props.totalSkypassPoint))}</text>
                                <g ref={this.tooltipRef}>
                                    <path ref={this.triangleRef} fill="none" stroke="black" strokeWidth="3" className="tooltip-triangle" />
                                    <rect ref={this.rectRef} height="15" fill="orange" rx="5" ry="5" />
                                    <text ref={this.text2Ref} fontWeight="bold" fontSize="smaller" ></text>
                                </g>
                            </svg>
                        </div>
                        {/* {message} */}
                        {basePoints.expiryDate &&
                            <div className="text-danger small text-center">{numberWithCommas(parseInt(basePoints.points))} {t("my_family.expiry_meg")} {new Date(basePoints.expiryDate).toDateString()}!</div>
                        }
                    </div>
                </div>
                {
                    (!this.props.isAdmin && this.props.showDetails) &&
                    <div className="form-row">
                        <div className="col-lg-12">
                            <div className="previllageWrap d-flex justify-content-between">
                                <div>
                                    <i className={allowToClass} aria-hidden="true"></i>
                                    {t("my_family.allow_my_miles")}
                                </div>
                                <span className="sep"></span>
                                <div>
                                    <i className={allowFromClass} aria-hidden="true"></i>
                                    {t("my_family.use_miles")}
                                </div>
                            </div>
                        </div>
                    </div>
                }
            </div>
        )
    }
}

FamilyMemberCard.defaultProps = {
    details: {},
    progressPointType: '',
    tierMapping: []
}