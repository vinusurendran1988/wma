import React, { Component } from 'react';
import { withSuspense, getDateFormatted, getDiffByTwoDate, getCurrentDate, formatTime } from '../../../components/common/utils';
import { withTranslation } from 'react-i18next';
import { Calendar } from 'primereact/calendar';
// import moment from 'moment'
import { YYYY_MM_DD, DDMMMYYYY, PAST } from './Constants';
import { _IMAGE_BASEURL } from '../../common/config/config';

/**
 * MyBooking Component
 * @description Displays the list upcoming and past flight bookings
 * @author Amrutha
 */
class MyBookings extends Component {
    constructor(props) {
        super(props);

        this.state = {
            dateSelected: null,
            durationSelected: props.duration && props.duration.length>0 && this.getDefaultDuration(props.duration),
            durationValue: "",
            isFiltered: false,
            pastBookings: []

        }
        this.handleDropDownChange = this.handleDropDownChange.bind(this)
        this.getDefaultDuration = this.getDefaultDuration.bind(this)
    }
    componentDidMount(){
        this.setState({
            durationSelected: this.props.duration && this.props.duration.length>0 && this.getDefaultDuration(this.props.duration),
        })
    }
    getDefaultDuration=(duration)=>{
       return duration.filter(item=>!!item.default)[0]
    }

    formatDate(date) {
        const splitDate = date.split(" ");
        return getDateFormatted(splitDate[0], YYYY_MM_DD, DDMMMYYYY)
    }

    getDateDiff = (departureDate, arrivalDate) => {
        const formattedArrivalDate = getDateFormatted(arrivalDate, YYYY_MM_DD, YYYY_MM_DD)
        const formattedDepartureDate = getDateFormatted(departureDate, YYYY_MM_DD, YYYY_MM_DD)
        const dateDiff = getDiffByTwoDate(formattedArrivalDate, formattedDepartureDate, YYYY_MM_DD, YYYY_MM_DD, "days")
        return dateDiff
    }

    getPastBookings = (fromDate) => {
        const filteredBookings = this.props.bookings.filter(
            booking => (getDiffByTwoDate(fromDate, booking.scheduledDepartureDateTime.split(" ")[0], YYYY_MM_DD, YYYY_MM_DD, "days") < 0) &&
                (getDiffByTwoDate(getCurrentDate(YYYY_MM_DD), booking.scheduledDepartureDateTime.split(" ")[0], YYYY_MM_DD, YYYY_MM_DD, "days") > 0)
        )
        this.setState({
            isFiltered: true,
            pastBookings: filteredBookings
        })
    }
    handleDropDownChange = (e) => {
        this.setState({
            durationSelected: this.props.duration && this.props.duration.length>0 &&  this.props.duration.filter(item=>item.value==e.target.value)[0],
            dateSelected: null
        })
        // const fromDate=getDateFromDuration(e.target.value, YYYY_MM_DD);
        //const fromDate="2020-02-26"
        //this.getPastBookings(fromDate)
        
        // const startDate=getDateFromDuration(e.target.value, YYYY_MM_DD)
        // const endDate=getCurrentDate(YYYY_MM_DD)
        // this.props.durationSelected(startDate,endDate)
    }

    handleDatePickerChange = (e) => {
        this.setState({
            dateSelected: e.value,
            durationSelected: this.props.duration && this.props.duration.length>0 && this.getDefaultDuration(this.props.duration)
        })
        //this.getPastBookings(moment(e.value).format(YYYY_MM_DD))
        // const startDate=getDateFromDuration(e.value, YYYY_MM_DD)
        // const endDate=getCurrentDate(YYYY_MM_DD)
        // this.props.durationSelected(startDate,endDate)

    }
    render() {
        const { bookings, id, duration, t } = this.props;
        var isFiltered = this.props.id == PAST ? false : false
        var bookingData = isFiltered ? this.state.pastBookings : bookings
        return (
            <div id={id} className="tab-pane fade show active" role="tabpanel" aria-labelledby="nav-home-tab">
                {id == "past1" && <form className="form form--horizontal form--activity">
                    <div className="form--horizontal__left">
                        <div className="form-group">
                            <label className="input-label">{t("my_flights.duration_label")}</label>
                            <div className="input-wrap select-wrap">
                                <select id="country" name="country"
                                    value={this.state.durationSelected.value}
                                    defaultValue={this.state.durationSelected.value}
                                    onChange={(e) => { this.handleDropDownChange(e) }}>
                                    {duration &&
                                        duration.map(item => {
                                            return (<option value={item.value}
                                            >{ item.label}</option>)
                                        })}
                                </select>
                                <span>{t("my_flights.or")}</span>
                            </div>
                        </div>
                        <div className="form-group">
                            <label className="input-label">{t('my_flights.duration_label')}</label>
                            <div className="input-wrap date-wrap">
                                <Calendar
                                    placeholder={"dd-mm-yyyy"}
                                    dateFormat="dd-mm-yy"
                                    minDate={this.returnMinDate2}
                                    onChange={(e) => this.handleDatePickerChange(e)}
                                    value={this.state.dateSelected}
                                    enabled={true}
                                    showOtherMonths={true}
                                    maxDate={new Date()}
                                >
                                </Calendar>
                            </div>
                        </div>
                    </div>
                    {/* <div className="form--horizontal__right">
                        <div className="input-wrap txt-wrap">
                            <input type="text" className="txt" placeholder="Search" />
                        </div>
                        <div className="print utils">
                            <a href="#">
                                <img src={`${_IMAGE_BASEURL}/icons/icon-print.svg`} />
                            </a>
                        </div>
                    </div> */}
                </form>
                }

                {(bookingData && bookingData.length > 0) ?
                    <ul className="listing listing--booking">
                        {
                            bookingData.map(bookedItem => {
                            return (
                                <li className="item">
                                    <div className="item__blck">
                                        <div className="item__thumb"><img src={`${_IMAGE_BASEURL}/icons/icon-flight.svg`} /></div>
                                        <div className="item__details">
                                            <div className="name"> {bookedItem.origin} <span>-</span> {bookedItem.destination}</div>
                                            <div className="flight-info">
                                                {/* <small> {bookedItem.airlineCode} {bookedItem.flightNumber}</small> <span className="devider">|</span>  */}
                                                <small>{this.formatDate(bookedItem.scheduledArrivalDateTime)}  {formatTime(bookedItem.scheduledDepartureDateTime)} - {formatTime(bookedItem.scheduledArrivalDateTime)} + {this.getDateDiff(bookedItem.scheduledDepartureDateTime,bookedItem.scheduledArrivalDateTime)}</small>
                                                {/* | <small>Economy</small>  
                                             | <a href="#"> Flight Details</a> */}
                                            </div>
                                        </div>
                                    </div>
                                    <div className="item__info">
                                        <ul>
                                            <li className="seat">
                                                <span className="type">{t('my_flights.column_name.pnrNumber')}</span>
                                                <strong className="text">{bookedItem.pnrNumber}</strong>
                                            </li>
                                            <li className="acrrual">
                                                <span className="type">{t('my_flights.column_name.pnrStatus')}</span>
                                                <strong className="text">{bookedItem.pnrStatus}</strong>
                                            </li>
                                            <li className="redeem">
                                                <span className="type">{t('my_flights.column_name.flightNumber')}</span>
                                                <strong className="text">{`${bookedItem.airlineCode}-${bookedItem.flightNumber}`}</strong>
                                            </li>
                                            {/* <li className="redeem">
                                            <span className="type">Miles Redeem</span>
                                            <strong className="text">0</strong>
                                        </li> */}
                                        </ul>
                                        {/* <span className="badge badge-warning">Free Upgrade available</span> */}
                                    </div>
                                    {/* <div className="item__utils">

                                    <div className="p-2">
                                        <div className="dropdown">
                                            <a className="" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i className="fa fa-ellipsis-v" aria-hidden="true"></i>
                                            </a>

                                            <div className="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                <a className="dropdown-item" href="#">View Tickets</a>
                                                <a className="dropdown-item" href="#">Manage Booking</a>
                                                <a className="dropdown-item" href="#">Upgrade className</a>
                                                <a className="dropdown-item" href="#">Cancel Booking</a>
                                            </div>
                                        </div>
                                    </div>
                                </div> */}
                                </li>

                            );
                        })
                        }
                    </ul>
                    :
                    <div>{t('my_flights.emptyListMessage')}</div>
                }

            </div>

        );

    }
}

export default withSuspense()(withTranslation()(MyBookings));
