import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import parse from 'html-react-parser';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { connect } from 'react-redux';
import {
    withSuspense, getFormattedDate, isEmptyOrSpaces
} from '../../common/utils';
import { COLUMN_TRIP, COLUMN_FLIGHT_DATE, AIRLINE_CODE, ARRIVAL_DATE, DEPATURE_DATE } from './Constants';
import { DD_MM_YYYY, DD_MMM_YYYY, DD_MMM_YYYY_HH_MM } from '../../common/utils/Constants';

/**
 * MyFlightsTable component
 * @description The table displays list of flights.
 * 
 * Props to be passed : 
 * 
 *  1.  header -> Header body
 *  2.  columnList -> List of string of column titles
 *  3.  inputData -> Array of objects containing data of each row
 *  4.  pageSize -> PageSize to display
 *  5.  availablePageSizes -> Array of integers to populate dropdown for available page sizes
 * 
 * @author Ajmal Aliyar
 */
class MyFlightsTable extends Component {
    constructor(props) {
        super(props);
        this.state = {
        }
    }

    componentDidMount() {
        this.setState({
            pageSize: this.props.pageSize
        })
    }

    populateColumns() {
        const { columnList, t } = this.props
        if (columnList && columnList.length) {
            return columnList.map((column) => {
                let props = {
                    header: t(`my_flights.column_name.${column}`),
                    sortable: true,
                    style: { textAlign: 'center' }
                }
                switch (column) {
                    case COLUMN_TRIP:
                        props.field = column
                        props.body = this.tripBodyTemplate
                        break;
                    case ARRIVAL_DATE:
                    case DEPATURE_DATE:
                        props.field = column
                        props.body = this.dateTimeBodyTemplate
                        break;
                    case COLUMN_FLIGHT_DATE:
                        props.field = column
                        props.body = this.dateBodyTemplate
                        break;
                    case AIRLINE_CODE:
                        props.field = column
                        props.body = this.airlineCodeTemplate
                        break;
                    default:
                        props.field = column
                        props.body = this.defaultColumnBodyTemplate
                }
                return <Column
                    {...props}
                />
            })
        }
    }

    defaultColumnBodyTemplate(data, props) {
        return (
            <React.Fragment>
                <span className="p-column-title">{props.header}</span>
                {data[props.field]}
            </React.Fragment>
        );
    }
    
    airlineCodeTemplate(rowData, props){
        const { airlineCode, flightNumber, flightSuffix } = rowData
        return (
            <React.Fragment>
                <span className="p-column-title">{props.header}</span>
                {airlineCode+"-"+(flightNumber?flightNumber:"")+(flightSuffix && flightSuffix!="*" ?"-"+flightSuffix:"")}
            </React.Fragment>
        );
    }
    dateBodyTemplate(rowData, props) {
        return (
            <React.Fragment>
                <span className="p-column-title">{props.header}</span>
                {getFormattedDate(rowData["scheduledDepartureDateTime"], DD_MMM_YYYY, DD_MMM_YYYY_HH_MM)}
            </React.Fragment>
        );
    }

    dateTimeBodyTemplate(rowData, props) {
        return (
            <React.Fragment>
                <span className="p-column-title">{props.header}</span>
                {rowData[props.field]}
                {/* {getFormattedDate(rowData[props.field], DD_MMM_YYYY_HH_MM)} */}
            </React.Fragment>
        );
    }

    tripBodyTemplate(rowData, props) {
        let spanElement = <span></span>
        if(!isEmptyOrSpaces(rowData.destination) && !isEmptyOrSpaces(rowData.origin)) {
            spanElement = <span>
                {rowData.origin.trim()}
                &nbsp;
                <span className="fa fa-plane" aria-hidden="true" style={{transform: "rotate(45deg)"}}></span>
                &nbsp;
                {rowData.destination.trim()}
            </span>
        } 
        return (
            <React.Fragment>
                <span className="p-column-title">{props.header}</span>
                {spanElement}
            </React.Fragment>
        );
    }

    render() {
        const { pageSize, header, inputData, t, availablePageSizes } = this.props;
        return (
            <div className="datatable-responsive-demo">
                <div className="card">
                    <DataTable
                        paginator={true}
                        paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
                        rows={pageSize}
                        rowsPerPageOptions={availablePageSizes}
                        emptyMessage={t('my_flights.emptyListMessage')}
                        header={header}
                        value={inputData}
                        removableSort={true}
                        rowHover
                        scrollable={true}
                        className={"p-datatable-responsive-demo"}
                    >
                        {this.populateColumns()}
                    </DataTable>
                </div>
            </div>
        );
    }

}

MyFlightsTable.propTypes = {
};

MyFlightsTable.defaultProps = {
};

const mapStateToProps = (state) => {
    return {
    }
}

const mapDispatchToProps = {
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(MyFlightsTable)));