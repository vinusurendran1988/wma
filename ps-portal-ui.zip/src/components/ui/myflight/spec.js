import React from 'react';
import MyFlight from './index'
import {
    findComponent,
    mockServiceResponse,
    findByTestAttr
} from '../../common/testUtils';
import { testStore } from '../../common/utils';
import moxios from 'moxios';
import { mount } from 'enzyme';
import {
    fetchConfiguration
} from '../../common/middleware/redux/commonAction';
import { SESSION_STORAGE_COMPANY_CODE, SESSION_STORAGE_PROGRAM_CODE, SESSION_STORAGE_MEMBERSHIP_NO, CONFIG_SECTION_MYFLIGHTS } from '../../common/utils/Constants';
import { Provider } from 'react-redux';
import { action_fetchFlights } from './actions';

var store;
let rootComponent;
let component;
var t = jest.fn()

const setUp = (props = {}) => {
    window.sessionStorage.setItem(SESSION_STORAGE_COMPANY_CODE, 'IBS')
    window.sessionStorage.setItem(SESSION_STORAGE_PROGRAM_CODE, 'PRG14')
    localStorage.setItem(SESSION_STORAGE_MEMBERSHIP_NO, 'IM0008010415')
    rootComponent = mount(
        <Provider store={store} >
            <MyFlight {...props} />
        </Provider>
    );
};

/**
 * Test for MyFlight Component
 * @author Ajmal Aliyar
 */
describe('MyFlight Component', () => {

    /**
     * Tests related to rendering the page.
     * @author Ajmal Aliyar
     */
    describe('Render', () => {
        /**
         * Before each test, loads up the page and
         *  1.  fetch configuration,
         *  2.  retrieve flights with default set of 
         *      data in the request.
         * @author Ajmal Aliyar
         */
        beforeEach(() => {
            const RESPONSE_CONFIGURATION_MYFLIGHTS = {"statuscode":"200","statusMessage":"SUCCESS","object":{"section":"myflights","companyCode":"IBS","programCode":"PRG14","defaultAirLineCode":"QH","upcomingFlightDurationInDays":60,"profileId":"GPR672","ui":{"availablePageSizes":[10,20,50,100],"defaultPageSize":10,"columns":["flightDate","airlineCode","trip","scheduledDepartureDateTime","scheduledArrivalDateTime","pnrNumber","pnrStatus"],"filterOptions":[{"uriPath":"/upcoming-flights","id":"upcoming"},{"uriPath":"/past-flights","id":"past"}]}}}
            const RESPONSE_FLIGHTS_UPCOMING_DEFAULT = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "upComingFlightLists": [{ "flightDate": "2020-09-09", "origin": "HAN", "destination": "DLI", "scheduledDepartureDateTime": "FlightNumber", "scheduleArrivalDateTime": "FlightSuffix", "airlineCode": "AirlineCode", "pnrNumber": "99983232", "pnrStatus": "ACTIVE" }, { "flightDate": "2020-09-09", "origin": "HAN", "destination": "DLI", "scheduledDepartureDateTime": "FlightNumber", "scheduleArrivalDateTime": "FlightSuffix", "airlineCode": "AirlineCode", "pnrNumber": "99983232", "pnrStatus": "ACTIVE" }, { "flightDate": "2020-09-09", "origin": "HAN", "destination": "DLI", "scheduledDepartureDateTime": "FlightNumber", "scheduleArrivalDateTime": "FlightSuffix", "airlineCode": "AirlineCode", "pnrNumber": "99983232", "pnrStatus": "ACTIVE" }, { "flightDate": "2020-09-09", "origin": "HAN", "destination": "DLI", "scheduledDepartureDateTime": "FlightNumber", "scheduleArrivalDateTime": "FlightSuffix", "airlineCode": "AirlineCode", "pnrNumber": "99983232", "pnrStatus": "ACTIVE" }, { "flightDate": "2020-09-09", "origin": "HAN", "destination": "DLI", "scheduledDepartureDateTime": "FlightNumber", "scheduleArrivalDateTime": "FlightSuffix", "airlineCode": "AirlineCode", "pnrNumber": "99983232", "pnrStatus": "ACTIVE" }, { "flightDate": "2020-09-09", "origin": "HAN", "destination": "DLI", "scheduledDepartureDateTime": "FlightNumber", "scheduleArrivalDateTime": "FlightSuffix", "airlineCode": "AirlineCode", "pnrNumber": "99983232", "pnrStatus": "ACTIVE" }, { "flightDate": "2020-09-09", "origin": "HAN", "destination": "DLI", "scheduledDepartureDateTime": "FlightNumber", "scheduleArrivalDateTime": "FlightSuffix", "airlineCode": "AirlineCode", "pnrNumber": "99983232", "pnrStatus": "ACTIVE" }, { "flightDate": "2020-09-09", "origin": "HAN", "destination": "DLI", "scheduledDepartureDateTime": "FlightNumber", "scheduleArrivalDateTime": "FlightSuffix", "airlineCode": "AirlineCode", "pnrNumber": "99983232", "pnrStatus": "ACTIVE" }, { "flightDate": "2020-09-09", "origin": "HAN", "destination": "DLI", "scheduledDepartureDateTime": "FlightNumber", "scheduleArrivalDateTime": "FlightSuffix", "airlineCode": "AirlineCode", "pnrNumber": "99983232", "pnrStatus": "ACTIVE" }, { "flightDate": "2020-09-09", "origin": "HAN", "destination": "DLI", "scheduledDepartureDateTime": "FlightNumber", "scheduleArrivalDateTime": "FlightSuffix", "airlineCode": "AirlineCode", "pnrNumber": "99983232", "pnrStatus": "ACTIVE" }, { "flightDate": "2020-09-09", "origin": "HAN", "destination": "DLI", "scheduledDepartureDateTime": "FlightNumber", "scheduleArrivalDateTime": "FlightSuffix", "airlineCode": "AirlineCode", "pnrNumber": "99983232", "pnrStatus": "ACTIVE" }, { "flightDate": "2020-09-09", "origin": "HAN", "destination": "DLI", "scheduledDepartureDateTime": "FlightNumber", "scheduleArrivalDateTime": "FlightSuffix", "airlineCode": "AirlineCode", "pnrNumber": "99983232", "pnrStatus": "ACTIVE" }] } }
            store = testStore({})
            moxios.install()
            setUp({})
            let newState = store.getState();
            mockServiceResponse(RESPONSE_CONFIGURATION_MYFLIGHTS, 200)
            return store.dispatch(
                fetchConfiguration(CONFIG_SECTION_MYFLIGHTS)
            ).then(() => {
                rootComponent.update()
                newState = store.getState();
                //checking if the myFlight configuration is loaded
                expect(newState.configurationReducer[CONFIG_SECTION_MYFLIGHTS]).toBe(RESPONSE_CONFIGURATION_MYFLIGHTS.object)
                mockServiceResponse(RESPONSE_FLIGHTS_UPCOMING_DEFAULT, 200)
                return store.dispatch(
                    action_fetchFlights('', {})
                ).then(() => {
                    rootComponent.update()
                    newState = store.getState();
                    //check responseFlightList
                    expect(newState.myFlightsReducer).toMatchObject(RESPONSE_FLIGHTS_UPCOMING_DEFAULT.object)
                })
            })

        })

        /**
         * Uninstall moxios after each test.
         * @author Ajmal Aliyar
         */
        afterEach(() => {
            store = undefined
            moxios.uninstall()
        })

        /**
         * Select Past Flights from the dropdown filter, 
         * loads the result from the new response.
         * @author Ajmal Aliyar
         */
        test("Change Filter type to 'Past Flights'", () => {
            component = findComponent(rootComponent, 'MyFlight');
            //Change the dropdown selected
            let dropdown = findByTestAttr(component, "TypeFilter")
            expect(dropdown.length).toBe(1)
            dropdown.prop('onChange')({ value: "past" ,id: "past"})
            const RESPONSE_FLIGHTS_PAST = {"statuscode":"200","statusMessage":"SUCCESS","object":{"pastFlightLists":[{"origin":"HAN","destination":"DAD","scheduledDepartureDateTime":"2020-01-07 06:00:00","scheduledArrivalDateTime":"2020-01-07 07:20:00","airlineCode":"QH","flightNumber":"101","flightSuffix":null,"ticketNumber":null,"pnrNumber":"A3HZ43","pnrStatus":"ACTIVE"},{"origin":"HAN","destination":"DAD","scheduledDepartureDateTime":"2020-03-03 15:50:00","scheduledArrivalDateTime":"2020-03-03 17:10:00","airlineCode":"QH","flightNumber":"103","flightSuffix":null,"ticketNumber":null,"pnrNumber":"T22CXN","pnrStatus":"ACTIVE"},{"origin":"HAN","destination":"DAD","scheduledDepartureDateTime":"2020-02-03 06:00:00","scheduledArrivalDateTime":"2020-02-03 07:20:00","airlineCode":"QH","flightNumber":"101","flightSuffix":null,"ticketNumber":null,"pnrNumber":"VLA2R7","pnrStatus":"ACTIVE"}]}}
            mockServiceResponse(RESPONSE_FLIGHTS_PAST, 200)
            return store.dispatch(
                action_fetchFlights('', {})
            ).then(() => {
                //check the updated responseFlightList
                rootComponent.update()
                let newState = store.getState();
                //check responseFlightList
                expect(newState.myFlightsReducer).toMatchObject(RESPONSE_FLIGHTS_PAST.object)

                component = findComponent(rootComponent, 'MyFlight');
                let claimSubmitButton = findByTestAttr(component, "claimSubmitButton")
                expect(claimSubmitButton.length).toBe(1)
                claimSubmitButton.simulate('click')
            })
        })

        test("Click on button 'Find your Destination'", () => { 
            component = findComponent(rootComponent, 'MyFlight');
            let findYourDestinationButton = findByTestAttr(component, "findYourDestinationButton")  
            findYourDestinationButton.simulate('click')
        })
    })

    describe("Actions", () => {
        beforeEach(() => {
            store = testStore({})
            moxios.install()
        })
        afterEach(() => {
            store = undefined
            moxios.uninstall()
        })
        test("fetch flights API failure", () => {
            const RESPONSE_FETCH_FLIGHTS_FAILURE = {"statuscode":"400","statusMessage":"FAILURE","error":{"code":"400","type":"BAD_REQUEST","message":"Retrieve flights failed","errorDetails":[{"field":"object.pageSize","message":"Some problem"}]}}
            mockServiceResponse(RESPONSE_FETCH_FLIGHTS_FAILURE, 500)
            return store.dispatch(
                action_fetchFlights('', {})
            )
        })
    })
})