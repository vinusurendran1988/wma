import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withSuspense, getCurrentDate, getRelativeDate } from '../../../components/common/utils';
import { withTranslation } from 'react-i18next';
import {
    CONFIG_SECTION_MYFLIGHTS,
    CONFIG_SECTION_DEFAULT,
    YYYY_MM_DD,
    DD_MMM_YYYY,
    CONFIG_SECTION_ACCOUNT_SUMMARY
} from '../../common/utils/Constants';
import { fetchConfiguration } from '../../common/middleware/redux/commonAction'
import { actionFetchFlights } from './actions'
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';
import {
    getItemFromBrowserStorage,
    BROWSER_STORAGE_KEY_PROGRAM_TYPE
} from '../../common/utils/storage.utils';
import MyBookings from './MyBookings';
import SearchFlights from '../../common/components/fieldbank/SearchFlights';
import { UPCOMING } from './Constants';

/**
 * MyFlight Component
 * @description Displays the list of flights in a table
 * @author Ajmal Aliyar
 */
class MyFlight extends Component {
    constructor(props) {
        super(props);
        this.state = {
            type: "",
            uriPath: undefined,
            requestPayload: {},
            selectedTab: "",
            duration: [],
            bookFlight: false,
            dropdownDisplay: "none"
        }
        this.onFilterTypeChange = this.onFilterTypeChange.bind(this)
    }

    /**
     * Runs once the page is mounted.
     * @description If the configuration for MyFlights
     * page is not present in the props, calls the
     * function to fetch MyFlights configuration.
     * @author Ajmal Aliyar
     */
    componentDidMount() {
        const { myFlightsConfig } = this.props

        this.props.setPageInfo(this.props, {config: this.props.myFlightsConfig, confSection: CONFIG_SECTION_MYFLIGHTS})
        if (myFlightsConfig) {
            this.initializePage()
        } 
        if (!this.props.accountSummaryConfig) { this.props.fetchConfiguration(CONFIG_SECTION_ACCOUNT_SUMMARY) }
    }

    /**
     * Detects changes happening in props and states, trigger respective actions.
     *  1.  If MyFlights Configuration is loaded -> Initialize page
     *  2.  If uriPath changed -> fire API request to retrieve flights
     *  3.  If flight list received from API -> Update flight list to display
     * @param {*} prevProps
     * @param {*} prevState 
     * @author Ajmal Aliyar
     */
    componentDidUpdate(prevProps, prevState) {

        const { myFlightsConfig } = this.props
        const { uriPath } = this.state

        // check 1
        if (prevProps.myFlightsConfig !== myFlightsConfig) {
            this.initializePage()
        }

        //check 2
        if (prevState.uriPath !== uriPath) {
            this.retrieveFlights()
        }
    }

    /**
     * Updates states with data from myFlight configuration.
     *  1.  Select the first option from the filter type dropdown.
     * @author Ajmal Aliyar
     */
    initializePage() {
        const { myFlightsConfig } = this.props
        if (
            myFlightsConfig.ui &&
            myFlightsConfig.ui.filterOptions &&
            myFlightsConfig.ui.filterOptions.length
        ) {
            const value = myFlightsConfig.ui.filterOptions[0]
            const configValue = myFlightsConfig.ui.filterOptions[1]
            this.setState({
                uriPath: value.uriPath,
                type: value.displayText,
                selectedTab: value.tab,
                duration: configValue.duration

            })
        }
    }

    /**
     *
     * @author Ajmal Aliyar
     */
    retrieveFlights() {
        const { myFlightsConfig } = this.props
        const { uriPath } = this.state
        const { data } = myFlightsConfig
        let { defaultAirLineCode, profileId, dateInclusive } = data
        if (uriPath) {
            // const  membershipNumber = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)
            // const programCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE)
            // const companyCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE)
            const object = {
                "profileId": profileId,
                "loyaltyNumber": "",
                "origin": "",
                "destination": "",
                "airlineCode": defaultAirLineCode,
                "flightNumber": "",
                "pnrNumber": "",
                "pnrStatus": ""
            }
            // if (this.state.type == "my_flights.past_flights" && dateInclusive) {
            //     object["flightStartDate"] = getCurrentDate(YYYY_MM_DD)
            //     object["flightEndDate"] = getRelativeDate(getCurrentDate(DD_MMM_YYYY), myFlightsConfig.upcomingFlightDurationInDays, "yyyy-MM-dd", DD_MMM_YYYY)
            // }
            this.setState(prevState => ({
                requestPayload: {
                    object
                }
            }), () => {
                this.props.actionFetchFlights(uriPath, this.state.requestPayload)
            })
        }
    }

    navigateURL(url) {
        window.location = url;
    }


    onFilterTypeChange(event, tab) {
        const { myFlightsConfig } = this.props
        if (myFlightsConfig && myFlightsConfig.ui && myFlightsConfig.ui.filterOptions) {
            const value = myFlightsConfig.ui.filterOptions.find(e => e.tab == tab)
            const duration = myFlightsConfig.ui.filterOptions[1].duration

            this.setState({
                uriPath: value.uriPath,
                type: value.displayText,
                selectedTab: tab,
                duration: duration,
                bookFlight: false,
                dropdownDisplay: "none"
            });
        }
    }


    render() {
        const { myFlightsConfig, responseFlightsList, t } = this.props
        const { selectedTab, dropdownDisplay } = this.state;
        const programType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE)

        return (
            <>
               
                    <div className="title title--page">
                        <h2>{t('my_flights.title')}</h2>
                    {this.state.bookFlight && <div className="btn-wrap">
                        <button className="btn btn-secondary" onClick={() => this.setState({ bookFlight: !this.state.bookFlight })} >{t('my_flights.book_flight')}</button>
                    </div>}
                    </div>
                <SearchFlights />

                <nav className="tab">
                    <div id='countries' className="tab__mob">
                        <i className="fa fa-caret-down" aria-hidden="true"></i>
                        <dl>
                            <dt>
                                <a onClick={()=>this.setState({dropdownDisplay: "block"})}><span>
                                    {this.state.selectedTab == UPCOMING ? t('my_flights.upcoming_flights') : t('my_flights.past_flights')}</span></a>
                            </dt>
                            <dd>
                                <ul style={{display: dropdownDisplay}}>
                                    {myFlightsConfig &&
                                        myFlightsConfig.ui &&
                                        myFlightsConfig.ui.filterOptions &&
                                        myFlightsConfig.ui.filterOptions.length && myFlightsConfig.ui.filterOptions.map(option => {
                                            return (<li onClick={(e) => this.onFilterTypeChange(e, option.tab)} aria-controls={option.tab} aria-selected="true">
                                                {t(`${option.displayText}`)}</li>)
                                        })
                                    }
                                </ul>
                            </dd>
                        </dl>
                    </div>
                    <div className="nav nav-tabs nav-tabs--booking" id="nav-tab" role="tablist">
                        {myFlightsConfig &&
                            myFlightsConfig.ui &&
                            myFlightsConfig.ui.filterOptions &&
                            myFlightsConfig.ui.filterOptions.length && myFlightsConfig.ui.filterOptions.map(option => {
                                return (
                                    <a className={`nav-item nav-link ${option.tab == this.state.selectedTab ? 'active' : ''}`}
                                        id={`${option.tab}`}
                                        data-toggle="tab"
                                        href={`#${option.tab}`}
                                        role="tab"
                                        onClick={(e) => this.onFilterTypeChange(e, option.tab)} aria-controls={option.tab} aria-selected="true">
                                        <span>{t(`${option.displayText}`)}</span>
                                    </a>
                                )
                            })
                        }
                    </div>
                </nav>

                <div className="tab-content" id="nav-tabContent">
                    <MyBookings
                        id={this.state.selectedTab}
                        bookings={(responseFlightsList && responseFlightsList[selectedTab]) ? responseFlightsList[selectedTab] : []}
                        duration={this.state.duration} />
                </div>
            </>
        );
    }
}

MyFlight.propTypes = {

};

const mapStateToProps = (state) => {
    return {
        myFlightsConfig: state.configurationReducer[CONFIG_SECTION_MYFLIGHTS],
        responseFlightsList: state.myFlightsReducer,
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        accountSummaryConfig: state.configurationReducer[CONFIG_SECTION_ACCOUNT_SUMMARY]
    }
}

const mapDispatchToProps = {
    fetchConfiguration,
    actionFetchFlights
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(MyFlight)));
