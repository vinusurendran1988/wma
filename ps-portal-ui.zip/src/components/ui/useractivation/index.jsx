import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import PasswordImage from '../../../../public/images/image-password.png';
import CustomMessage from '../../common/components/custommessage';
import Button from '../../common/components/fieldbank/Button';
import { FIELDTYPE_SECURITY_QUESTION } from '../../common/components/fieldbank/Constants';
import { NAVIGATE_CLUB_OVERVIEW } from '../../common/utils/urlConstants';
import {
    startApiLoading,
    stopApiLoading
} from '../../common/components/fieldbank/loader/action';
import { ROUTER_CONFIG } from '../../common/config/routing';
import {
    fetchConfiguration,
    resetError,
    setError
} from '../../common/middleware/redux/commonAction';
import { constructJsonPath, generateRequestBodyWithEmptyValue, withSuspense } from '../../common/utils';
import { CONFIG_SECTION_ACTIVATION, CONFIG_SECTION_DEFAULT } from '../../common/utils/Constants';
import { doAdditionalMapping, findValueFromObjectByPath, getValueFromPath, isDependentExists, setValueToObjectByPath } from '../../common/utils/object.utils';
import { BROWSER_STORAGE_KEY_FIRST_TIME_USER, BROWSER_STORAGE_KEY_MEMBERSHIP_NO, setItemToBrowserStorage } from '../../common/utils/storage.utils';
import { NAVIGATE_MEMBER_LOGIN } from '../../common/utils/urlConstants';
import { isPatternMatch } from '../../common/utils/validation.utils';
import { SECURITY_ANSWER_ATTRIBUTE_KEY, SECURITY_QUESTION_ATTRIBUTE_KEY } from '../security/Constants';
import { fetchSecurityQuestions } from '../security/securityquestions/actions';
import Section from '../updateprofile/Section';
import { activate } from './action';
import { CONTEXT, DEFAULT, EA, ID_ACTIVATE_BTN, NA } from './Constant';
import parse from 'html-react-parser';
import './style.scss';
/**
 * 
 * @author Somdas M
 * 
 * @description The UserActivation component is valid/used in the scenario when the enrolment is twoStep activation.
 * If the enrolment activationType is 'twoStep', then the user needs to check his/her mail to find the link which loads this component.
 * Before the login, the user needs to set the security credentials.
 * UserActivation component handles the security modules like Passwords, PINs, SecurityQuestions which are configurable by the page configuration.
 * 
 */
class UserActivation extends Component {

    constructor(props) {
        super(props)
        this.state = {
            successResponse: false, // denotes if the api returns a success response.
            isActivationCalled: false, // denotes if the activation api was invoked or not.
            error: [],
            activeSections: [], // contains the names of sections that are enabled (from config).
            elements: [], // holds the elements from config.ui.layout.elements.
            request: {}, // final request body to invoke api.
            data: {}, // holds all the data,
            dynamicAttributes: [], // contains the list of dynamicAttributes specified in the configuration.
            errorCodes: [], // contain the list of customMessageId, where the validation fails.
            isButtonClicked: false, // to monitor if the submit button was clicked.
            hasSecurityQuestions: false, // whether the securityQuestions are enabled in configuration.
            groupInstanceID: {}, // contains the groupInstanceID's as {questionValue: groupInstanceID} 
            paramsObject: {},
            activationRequestObject: {},
            programCode: "",
            showMessage: false
        }
    }

    componentDidMount() {
        const { config } = this.props
        if (config) {
            this.initalizeActivationPage()
            if (config && config.ui && config.ui.layout &&
                config.ui.layout.elements && config.ui.layout.elements[this.state.currentContextType] == DEFAULT) {

            }
        }
        this.props.setPageInfo(this.props, { config: this.props.config, confSection: CONFIG_SECTION_ACTIVATION })
    }

    componentDidUpdate(prevProps) {
        const { config } = this.props
        if (JSON.stringify(prevProps.config) != JSON.stringify(config)) {
            this.initalizeActivationPage()
        }
        if (JSON.stringify(prevProps.success) != JSON.stringify(this.props.success)) {
            const { success } = this.props
            const membershipNumber = (success && success.memberActivityStatus && success.memberActivityStatus.membershipNumber)
                ? success.memberActivityStatus.membershipNumber : this.state.data.membershipNumber
            setItemToBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO, membershipNumber)
            if (ROUTER_CONFIG.welcomeMessageConfig.enable) {
                if (this.state.contextType == DEFAULT) {
                    setItemToBrowserStorage(BROWSER_STORAGE_KEY_FIRST_TIME_USER, true)
                }
            }
            this.setState({
                successResponse: true,
                showMessage: true
            }, () => {
                window.scrollTo(0, 0);
            })
        }
        if (JSON.stringify(prevProps.error) != JSON.stringify(this.props.error)) {
            this.setState({
                showMessage: true
            })
        }
    }

    /**
     * @author Somdas M
     * @description addValueToState is a callback method from the Section component.
     * This method is used to store a field's value in the state.
     * The state variable has the same name as that of the fieldName (field.name) specified in the configuration.
     * The fields are stored under the 'data' object in state. Like, state = { data : { [field.name]: value }} 
     * @param {*} field The field object
     * @param {*} value Respective value of the field
     * 
     */
    addValueToState(field, value) {
        let { data, groupInstanceID } = this.state
        data[field.name] = value
        if (field.name.includes("question")) {
            if (!groupInstanceID[value]) {
                const { securityQuestions } = this.props
                const currentQuestion = securityQuestions.find(sq => sq[field.source.selector.value] == value)
                groupInstanceID[value] = currentQuestion.sequenceNumber
            }
        }
        this.setState({
            data,
            groupInstanceID
        })
    }

    /**
     * @author Somdas M
     * @description handleRequestChange is a callback method from the Section component.
     * This method is used to store a the updated request object to state.
     * @param {*} request The updated request object
     * 
     */
    handleRequestChange = (request) => {
        this.props.resetError()
        this.setState({
            request
        })
    }

    /**
    * @author Somdas M
    * @description setInitialData is to retrieve certain properties from the configuration and store in state.
    * This method is invoked only when the page configuration is loaded.
    * 
    */
    setInitialData = () => {
        const { config } = this.state
        this.props.resetError() // reset the errors
        if (config && Object.keys(config).length) {
            const request = generateRequestBodyWithEmptyValue(config) // generate a request body from the configuration with defaultValue as "".
            const { order, elements } = config.layout
            const { dynamicAttributes } = this.props.config
            const activeSections = order.filter(o => this.props.config[o] && this.props.config[o].enable == true) // activeSections contains the list of names of the enabled ones. The enable property is specified in respective section in configuration.
            const { hash } = window.location
            let membershipNumber = "", token = ""
            let { data } = this.state
            if (hash && hash.split('?')) { // token and membershipNumber should be available in the redirected url.
                const params = new URLSearchParams(window.location.hash.split('?')[1]);
                membershipNumber = params.get('MEM_ID') || ''; // retrieve the membershipNumber
                token = params.get('TKN') || '' // retrieve the token
                customerNumber = params.get('CUST_ID') || '' // retrieve the customer number
            }
            data["membershipNumber"] = membershipNumber
            data["token"] = token
            data["customerNumber"] = customerNumber
            // Handle only if the securityQuestions are enabled, fetch the list of security questions.
            if (activeSections.includes("securityQuestion")) {
                const { securityQuestion } = this.props.config
                if (securityQuestion && dynamicAttributes.securityQuestion) {
                    const securityQuestionDynamicAttribute = dynamicAttributes.securityQuestion.find(attribute => attribute.attributeKey === FIELDTYPE_SECURITY_QUESTION)
                    this.props.fetchSecurityQuestions({
                        type: securityQuestion.additionalType,
                        filterType: securityQuestion.filterType,
                        filterValue: securityQuestionDynamicAttribute ? securityQuestionDynamicAttribute[securityQuestion.filterType] : ""
                    })
                }
            }

            this.setState({
                activeSections,
                elements,
                dynamicAttributes,
                data,
                request,
                dynamicAttributesPath: request.dynamicAttributesPath ? request.dynamicAttributesPath : "",
                hasSecurityQuestions: dynamicAttributes.securityQuestion ? true : false
            })
        }
    }

    /**
     * @author Somdas M
     * @description findValueFromState is a callback method from the Section component.
     * This method is used to retieve a field's value from the state.
     * The values are stored inside the 'data' object in state. Hence the retieval will be from data[fieldName] 
     * @param {string} stateFieldName The field name
     * 
     */
    findValueFromState(stateFieldName) {
        const { data } = this.state
        return data[stateFieldName] ? data[stateFieldName] : ""
    }

    /**
     * @author Somdas M
     * @description handleErrorMessagesFromSection is a callback method from the Section component.
     * Invokes the reset error method if code length is empty.
     * @param {*} codes The list of error codes
     * 
     */
    handleErrorMessagesFromSection(codes) {
        if (!codes.length) { this.props.resetError() }
    }


    /**
     * @author Somdas M 
     * @description doAdditionalMappingAndActivateUser is to perform the additional mapping specified in the configuration.
     * This method also manipulates the dynamicAttributes in the path specified to update the security questions.
     * 
     */
    doAdditionalMappingAndActivateUser = () => {
        const { config, t } = this.state
        let { request, hasSecurityQuestions, groupInstanceID } = this.state
        let hasDuplicateQuestion = false // to check if same questions were selcted

        // handle only if the security questions are enabled
        if (hasSecurityQuestions && config && config.request && config.request.dynamicAttributesPath) {
            const { dynamicAttributesPath } = config.request // gets the dynamicAttributesPath
            if (this.props.config && this.props.config.dynamicAttributes && this.props.config.dynamicAttributes.securityQuestion) {
                setValueToObjectByPath(request, dynamicAttributesPath, this.props.config.dynamicAttributes.securityQuestion)
            }
            const memberDynamicAttributes = getValueFromPath(dynamicAttributesPath, { request }) // get the value from the dynamicAttributesPath in request. 
            const securityQuestions = memberDynamicAttributes.filter(attribute => attribute.attributeKey == SECURITY_QUESTION_ATTRIBUTE_KEY) // retrieves all the security questions.
            const existingQuestions = []
            securityQuestions.map((question, index) => {
                const questionValue = getValueFromPath(`state.data.question${index + 1}`, { state: this.state }) // fetch the respective question with the user input which is stored in state.
                if (questionValue && !existingQuestions.includes(questionValue)) {
                    existingQuestions.push(questionValue)
                    question["attributeValue"] = questionValue
                    question["groupInstanceID"] = groupInstanceID[questionValue]
                    // find the respective answer object in the memberDynamicAttributes which has the same groupInstanceID as that of question. 
                    const answer = memberDynamicAttributes.find(attribute => attribute.attributeKey == SECURITY_ANSWER_ATTRIBUTE_KEY)
                    if (answer) {
                        answer["attributeValue"] = getValueFromPath(`state.data.answer${index + 1}`, { state: this.state })  // update the respective answer object
                        answer["groupInstanceID"] = groupInstanceID[questionValue]
                    }
                } else {
                    this.props.setError([t('user_activation.securityQuestion.errorMessage.duplicateFound')])
                    hasDuplicateQuestion = true
                    return;
                }
            })
        }

        // proceed only if the questions selected are not similar
        if (!hasDuplicateQuestion) {
            //handle the additionalMapping, if specified in the configuration.
            if (config && config.request && config.request.additionalMapping) {
                // Gather information from the 'fromPath' and update the 'toPath'. 
                config.request.additionalMapping.forEach((fields) => {
                    let { fromPath, toPath, dependentPath } = fields
                    let value = undefined
                    fromPath.forEach((path, index) => {
                        if (value == undefined) value = ""
                        let returnValue = getValueFromPath(path, { config, request, state: this.state, props: this.props })
                        if (returnValue && isDependentExists(dependentPath, { config, request, state: this.state, props: this.props })) {
                            value += (index > 0 ? " " : "") + returnValue
                        }
                    })
                    if (value != undefined) {
                        constructJsonPath(toPath, value, request)
                        setValueToObjectByPath(request, toPath, value)
                        this.setState({
                            request
                        })
                    }
                })
            }
            this.props.activate(this.state.request, ID_ACTIVATE_BTN, this.state.config.apiUrl)
        }
    }

    /**
     * @author Somdas M
     * @description validateWithStateVariable is a callback method from the Section component.
     * This method is used to perform the validation on the state variables.
     * @param {*} field The respective field
     * @param {*} validation The list of validation parameters
     * @param {*} value Field's value
     * 
     */
    validateWithStateVariable = (field, validation, value) => {
        let { pattern, fields } = validation
        let isValidationSuccess = true, canUpdateState = false
        fields.forEach((fd) => {
            const { data } = this.state
            const newPattern = pattern.replace("[fields]", data[fd])
            if (!isPatternMatch(newPattern, value)) {
                isValidationSuccess = false
            }
        })
        let { errorCodes } = this.state
        if (!isValidationSuccess) {
            if (!errorCodes.includes(validation.customMessageId)) {
                errorCodes.push(validation.customMessageId)
                canUpdateState = true
            }
        } else if (errorCodes.includes(validation.customMessageId)) {
            const index = errorCodes.indexOf(validation.customMessageId)
            if (index > -1) {
                canUpdateState = true
                errorCodes.splice(index, 1)
            }
        }
        field.error = !isValidationSuccess
        if (canUpdateState) {
            this.setState({
                errorCodes
            })
        }
        return !isValidationSuccess
    }

    /**
     * @author Somdas M
     * @description Method is triggered once the user clicks the 'Submit' button.
     * The api is invoked only if the errorCodes are empty, else after performing the additionalMapping the api is invoked.
     * @param {*} e  The click event
     * 
     */
    handleSubmit = (e) => {
        window.scrollTo(0, 0)
        const { errorCodes } = this.state
        this.setState({
            isButtonClicked: true
        }, () => {
            if (errorCodes.length == 0) {
                this.props.resetError()
                this.doAdditionalMappingAndActivateUser()
            } else {
                this.props.setError(errorCodes);
            }
        })
    }

    /**
     * @author Amrutha J Raj
     * @description This method is used to set the context path and UrlParamObject from the URL parameters
     * 
     */
    initalizeActivationPage = () => {
        let newState = {}
        const params = new URLSearchParams(window.location.hash.split('?')[1])
        params.forEach((value, key) => {
            newState[key] = value
        })
        this.setState({
            paramsObject: newState,
            contextType: params.get(CONTEXT) && params.get(CONTEXT).length > 0 ?
                params.get(CONTEXT) : DEFAULT
        },
            () => {
                if (this.state.contextType) {
                    this.getConfigObjectBasedOnContextType()
                }
            }
        )
    }

    /**
     * @author Amrutha J Raj
     * @description This method is used to get the config object based on the 
     * context type from the URL param
     * 
     */
    getConfigObjectBasedOnContextType = () => {
        const { config } = this.props
        if (config && config.ui && config.ui.contextMapping) {
            let selectedObject = config.ui.contextMapping.find(item => item[this.state.contextType])

            if (selectedObject && Object.keys(selectedObject.length > 0)) {
                let currentContextType = selectedObject[this.state.contextType]
                if (currentContextType) {
                    if (config.ui.layout && config.ui.layout.elements &&
                        Object.keys(config.ui.layout.elements).length > 0) {
                        this.setState({ config: config.ui.layout.elements[currentContextType] },
                            () => {
                                if (this.state.contextType == DEFAULT) {
                                    this.setInitialData()
                                }
                                else if (this.state.config && !this.state.config.isLayoutRequired && this.state.config.request && this.state.config.request.additionalMapping) {
                                    if (this.state.contextType != DEFAULT) {
                                        //setting program code 
                                        const programCodeObj = this.props.defaultConfig &&
                                            this.props.defaultConfig.programs.find(obj => obj.id == this.state.paramsObject.IDENTIFIER)
                                        if (programCodeObj && Object.keys(programCodeObj)) {
                                            this.setState({
                                                programCode: programCodeObj.programCode
                                            }, () => {
                                                doAdditionalMapping(this, "activationRequestObject", this.state.config.request.additionalMapping)
                                                // const jasper = { ...this.state, activationRequestObject: {"hello": "world"} }
                                                // this.setState(() => ({jasper}))
                                                this.props.activate(this.state.activationRequestObject, ID_ACTIVATE_BTN, this.state.config.apiUrl)
                                            })
                                        }
                                    }
                                }
                            })
                    }
                }
            }
        }
    }
    /**
    * @author Somdas
    * @description This method is used to render the user activation
    * page after enrollment
    * 
    */
    renderUserActivation = () => {
        const { t, securityQuestions } = this.props
        const { activeSections, elements, request, dynamicAttributesPath, errorCodes, successResponse, isButtonClicked, config } = this.state
        const dynamicAttributeProperties = {
            "path": dynamicAttributesPath,
            "attributes": findValueFromObjectByPath(request, dynamicAttributesPath)
        }
        return (
            <>
                <CustomMessage message={this.props.error} type="danger" canTranslate={true} />
                <div className={`description description--form ${!successResponse ? "" : "d-none"}`}>
                    <h1>{t('user_activation.title')}</h1>
                    <p>{t('user_activation.description')}</p>
                </div>
                <div className={`form form--password ${!successResponse ? "" : "d-none"}`}>
                    <div className="form-row">
                        {
                            activeSections && activeSections.map((activeSection, i) => {
                                const currentSection = elements[activeSection]
                                const additionalConfig = config[activeSection] ? config[activeSection] : undefined
                                if (currentSection) {
                                    return <Section
                                        key={i}
                                        id={activeSection}
                                        displayElements={currentSection}
                                        request={request}
                                        page={`user_activation`}
                                        onRequestChange={(req) => this.handleRequestChange(req)}
                                        dynamicAttributes={dynamicAttributeProperties}
                                        errorCodes={errorCodes}
                                        onErrorCodes={(codes) => this.handleErrorMessagesFromSection(codes)}
                                        addValueToState={(field, value) => this.addValueToState(field, value)}
                                        validateWithStateVariable={(field, validation, value) => this.validateWithStateVariable(field, validation, value)}
                                        findValueFromState={(stateFieldName, fieldType) => this.findValueFromState(stateFieldName, fieldType)}
                                        isButtonClicked={isButtonClicked}
                                        // securityQuestions = {data.securityQuestions?data.securityQuestions:[]}
                                        additionalConfig={additionalConfig}
                                        renderType={"render1_1"}
                                        securityQuestions={securityQuestions}
                                    />
                                }

                            })
                        }

                        <div className="col-md-12">
                            <div className="row">
                                <div className="col-lg-5 col-md-7">
                                    <div className="btn-wrap">
                                        <Button
                                            label={t('user_activation.btn_submit')}
                                            id={ID_ACTIVATE_BTN}
                                            handleOnClick={(e) => this.handleSubmit(e)}
                                            testIdentifier="submit"
                                            className="btn btn-primary"
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className={`description description--password ${successResponse ? "" : "d-none"}`}>
                    <p>{t(`user_activation.membershipNumber`)} : {this.state.data.membershipNumber}</p>
                    <h1>{t('user_activation.success')}</h1>
                    <h3>{t(`user_activation.login_to_access_message`)}</h3>
                    <div className="btn-wrap mt-5">
                        <button className="btn btn-primary" onClick={() => { window.location.href = `#${NAVIGATE_MEMBER_LOGIN}` }} data-test="loginBtn">{t('user_activation.login_to')}</button>
                    </div>
                </div>
            </>

        )
    }

    /**
    * @author Amrutha
    * @description Method to show messages after activation
    * 
    */
    showMessage = () => {
        const { t } = this.props
        return (
            <h2>
                {this.props.success && this.props.success.status != "Failed" ?
                    <>
                        {t(`${this.state.config.message.success}.messageOne`)}
                        <br />
                        {t(`${this.state.config.message.success}.messageTwo`)}
                    </>
                    :
                    <>
                        {t(`${this.state.config.message.failure}.messageOne`)}
                        <br />
                        {t(`${this.state.config.message.failure}.messageTwo`)}
                    </>
                }
            </h2>
        )
    }

    /**
    * @author Amrutha
    * @description Method to show messages after activation for nominees
    * 
    */
    showMessageNominee = (message) => {
        const { t } = this.props
        return (
            <h2>
                {this.props.error && Object.keys(this.props.error).length ?
                    <>
                        {message[this.state.paramsObject.IDENTIFIER] &&
                            t(`${message[this.state.paramsObject.IDENTIFIER].failure}`)}

                    </>
                    :
                    <>
                        {message[this.state.paramsObject.IDENTIFIER] &&
                            t(`${message[this.state.paramsObject.IDENTIFIER].success}`)}
                    </>
                }
            </h2>
        )
    }

    /**
    * @author Amrutha
    * @description Method to render activation page which does not have a layout
    * 
    */
    renderActivationWithoutLayout = () => {
        switch (this.state.contextType) {
            case NA: {
                return (this.state.config && this.state.config.message && this.state.showMessage &&
                    this.showMessageNominee(this.state.config.message))
            }
            case EA: {
                return (this.state.config && this.state.config.message && this.state.showMessage && this.showMessage())
            }
            default: return <div></div>
        }
    }

    /**
     * 
     */
    goToKoru = () => {
        window.location = `#${NAVIGATE_CLUB_OVERVIEW}`
    }

    /**
     * 
     */
    renderCorporateInvitation = () => {
        const { t } = this.props
        const company = new URLSearchParams(window.location.hash.split('?')[1]).get('COMPANY');
        if (Object.keys(this.props.success).length > 0) {
            return (
                <>
                    <div>
                        <h1>Invite accepted</h1>
                    </div>

                    <div className="alert alert-success hide-fontawesome" role="alert"> <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M6.99986 14.1727L3.53319 10.706C3.14291 10.3158 2.51014 10.3158 2.11986 10.706C1.72958 11.0963 1.72958 11.7291 2.11986 12.1194L6.29275 16.2923C6.68328 16.6828 7.31644 16.6828 7.70697 16.2923L18.2932 5.70604C18.6835 5.31576 18.6835 4.68299 18.2932 4.29271C17.9029 3.90243 17.2701 3.90243 16.8799 4.29271L6.99986 14.1727Z" fill="white"></path>
                        <mask id="mask0_6869_9148" style={{ maskType: "alpha" }} maskUnits="userSpaceOnUse" x="1" y="4" width="18" height="13">
                            <path d="M6.99986 14.1727L3.53319 10.706C3.14291 10.3158 2.51014 10.3158 2.11986 10.706C1.72958 11.0963 1.72958 11.7291 2.11986 12.1194L6.29275 16.2923C6.68328 16.6828 7.31644 16.6828 7.70697 16.2923L18.2932 5.70604C18.6835 5.31576 18.6835 4.68299 18.2932 4.29271C17.9029 3.90243 17.2701 3.90243 16.8799 4.29271L6.99986 14.1727Z" fill="white"></path>
                        </mask>
                        <g mask="url(#mask0_6869_9148)">
                        </g>
                    </svg> {parse(t(`activationMessages.accountUserAddedSuccess`).replace('{COMPANY}', company))}</div>

                    <div class="col-lg-10" style={{ "padding-top": "2rem", "padding-left": "0px", "margin-left": "-15px;" }}>
                        <button type="button" class="btn btn-primary" onClick={() => { this.goToKoru() }} data-test="payment-test">Go to Koru</button>
                    </div>
                </>
            )
        } else if (typeof this.props.error != "undefined" && Object.keys(this.props.success).length == 0) {
            return (
                <>
                    <div>
                        <h1>Unable to join the corporate account</h1>
                    </div>


                    <CustomMessage
                        type={"danger"}
                        message={[parse(t(`activationMessages.accountUserAddedFailure`))]}
                        canTranslate={false}
                    />
                    <p> If a new invite needs to be sent, please contact your company administrator to send a new invitation</p>
                </>
            )
        }
    }

    /**
    * @author Amrutha
    * @description Method to render activation page
    * 
    */
    renderActivationPage = () => {
        switch (this.state.contextType) {
            case NA:
            case EA:
                {
                    return this.renderCorporateInvitation()
                }
            case DEFAULT: {
                return this.renderUserActivation()
            }
            default: return <div></div>
        }
    }
    render() {
        return (
            <main role="main" id="content" class="container member-plan cart-view">
                {
                    this.renderActivationPage()
                }
                <hr style={{ "margin-top": "4rem" }} />
                <div class=" latamClub">
                    <div class="row">
                    <div class="col-lg-12">
                            <h2>Koru contact centre</h2>
                            <p>If you have a question about Koru or if you've misplaced/lost your Koru membership card, please contact our Koru contact centre.</p>
                            <div class="contact--address">
                                <p><strong>Tel: </strong>0800 736 000 (within NZ) or +64 9 375 0285 (outside NZ) on weekdays between 8:30am - 5:00pm NZST</p>
                                <p><strong>Email: </strong>korucc@airnz.co.nz</p>
                                <p><strong>Mail: </strong>Koru contact centre, Private Bag 93537, Takapuna, North Shore City 0740, New Zealand</p>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        )
    }
}
function mapStateToProps(state) {
    return {
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        config: state.configurationReducer[CONFIG_SECTION_ACTIVATION],
        error: state.commonErrorReducer.error,
        success: state.activateReducer,
        securityQuestions: state.masterData.securityQuestions
    }
}

const mapDispatchToProps = { startApiLoading, stopApiLoading, fetchConfiguration, resetError, activate, setError, fetchSecurityQuestions }
export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(UserActivation)));