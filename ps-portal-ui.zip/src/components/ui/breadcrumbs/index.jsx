import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux'
import { withTranslation } from 'react-i18next';
import { withSuspense } from '../../common/utils'
import { NAVIGATE_MEMBER_DASHBOARD, NAVIGATE_CORPORATE_OVERVIEW } from '../../common/utils/urlConstants';
import { CONFIG_SECTION_SUMMARY, PROGRAM_TYPE_INDIVIDUAL, CONFIG_SECTION_DEFAULT, PROGRAM_TYPE_CORPORATE, CONFIG_SECTION_ACCOUNT_SUMMARY } from '../../common/utils/Constants';
import { getItemFromBrowserStorage, BROWSER_STORAGE_KEY_PROGRAM_TYPE, BROWSER_STORAGE_KEY_PROGRAM_CODE, BROWSER_STORAGE_KEY_COMPANY_CODE, BROWSER_STORAGE_KEY_MEMBERSHIP_NO, BROWSER_STORAGE_KEY_CUSTOMER_NO } from '../../common/utils/storage.utils';
import { fetchCurrentLoginUserData, fetchConfiguration, fetchProfileData } from '../../common/middleware/redux/commonAction'
import {
    fetchAccountSummary,
    fetchAccountNominee
} from '../../common/middleware/redux/commonAction'

class PortalBreadcrumb extends Component {

    constructor (props) {
        super(props)
    }

    renderBreadcrumbMenuItems(menuitem, index) {
        const { t } = this.props
        const { child } = menuitem
        const programType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE)
        let title = t(`breadcrumb.${programType}.${menuitem.key}`)
        if (title === `breadcrumb.${programType}.${menuitem.key}`) {
            title = t(`breadcrumb.${menuitem.key}`)
        }
        if (child && child.length > 0) {
            return (
                <li className={`nav-item dropdown langOption ${( this.props.menuReference === menuitem.key ? " active" : "")}`}>
                    <a className="nav-link dropdown-toggle" data-toggle="dropdown"  role="button" aria-haspopup="true" aria-expanded="false">{title}</a>
                    <div className="dropdown-menu">
                        {
                            child.map(childMenu => {
                                if (childMenu.visible) {
                                    let childTitle = t(`breadcrumb.${programType}.${childMenu.key}`)
                                    if (childTitle === `breadcrumb.${programType}.${childMenu.key}`) {
                                        childTitle = t(`breadcrumb.${childMenu.key}`)
                                    }
                                    return (
                                        <div className="dropdown-item" role="button" onClick={() => window.location = `#${childMenu.link || NAVIGATE_MEMBER_DASHBOARD}`}>
                                            {childTitle}
                                        </div>
                                    )
                                }
                            })
                        }
                    </div>
                </li>
            )

        } else {
            let linkClass = `nav-link ${menuitem.additinalClass} ${menuitem.enable ? (this.props.menuReference === menuitem.key ? " active" : "") : " disabled"}`
            let liClass = `nav-item ${menuitem.enable ? (this.props.menuReference === menuitem.key ? " active" : "") : " disabled"}`
            let uriLink = `#${menuitem.link || NAVIGATE_MEMBER_DASHBOARD}`
            return (
                menuitem.enable ?
                    <li key={`${menuitem.id}-${index}`} className={liClass}>
                        <a className={linkClass} href={uriLink}>{title}</a>
                    </li> :
                    <li key={`${menuitem.id}-${index}`} className={liClass}>
                        <a className={linkClass} tabIndex="-1" href={uriLink}>{title}</a>
                    </li>
            )
        }
    }

    render() {
        const { t, summaryConfig } = this.props
        const programType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE)
        return (
            <div className="menu2nd">
                <div className="container">
                    <nav aria-label="breadcrumb" className="breadcrumbWrap">
                        <ol className="breadcrumb">
                            {
                                this.props.breadcrumbs.map((breadcrumb, index) => {
                                    let breadcrumbTitle = t(`breadcrumb.${programType}.${breadcrumb}`)
                                    if (breadcrumbTitle === `breadcrumb.${programType}.${breadcrumb}`) {
                                        breadcrumbTitle = t(`breadcrumb.${breadcrumb}`)
                                    }
                                    return (
                                        index + 1 !== this.props.breadcrumbs.length ?
                                            <li key={index} className="breadcrumb-item">
                                                <a href={`#${programType == PROGRAM_TYPE_INDIVIDUAL
                                                    ? NAVIGATE_MEMBER_DASHBOARD
                                                    : NAVIGATE_CORPORATE_OVERVIEW}`
                                                }>{breadcrumbTitle}</a>
                                            </li> :
                                            <li key={index} className="breadcrumb-item active">{breadcrumbTitle}</li>
                                    )
                                })
                            }
                        </ol>
                    </nav>
                    <div className="">
                        <nav className="navbar navbar-expand-lg menuWrap3" style={{ flexDirection: "row-reverse" }}>
                            <button className="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation"> 
                                <span className="navbar-toggler-icon"></span>
                            </button>
                            <div className="navbar-collapse flex-row-reverse collapse" id="navbarNavAltMarkup">
                                <ul className="navbar-nav ml-auto">
                                    {
                                        summaryConfig &&
                                        summaryConfig.ui &&
                                        summaryConfig.ui.layout &&
                                        summaryConfig.ui.layout.elements &&
                                        summaryConfig.ui.layout.elements.breadcrumbMenuItems &&
                                        summaryConfig.ui.layout.elements.breadcrumbMenuItems.visibility &&
                                        summaryConfig.ui.layout.elements.breadcrumbMenuItems.menuItems &&
                                        summaryConfig.ui.layout.elements.breadcrumbMenuItems.menuItems.map((breadcrumbItem, index) => {
                                            if (breadcrumbItem.visible) {
                                                return this.renderBreadcrumbMenuItems(breadcrumbItem, index)
                                            }
                                        })
                                    }
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        );
    }
}

PortalBreadcrumb.propTypes = {
    breadcrumbs: PropTypes.array.isRequired
};

PortalBreadcrumb.defaultProps = {
    breadcrumbs: []
};

function mapStateToProps(state) {

    return {
        accountSummary: state.accountSummaryReducer.accountSummary,
        menuReference: state.menuReferenceReducer.payload,
        summaryConfig: state.configurationReducer[CONFIG_SECTION_SUMMARY],
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        accountSummaryConfig: state.configurationReducer[CONFIG_SECTION_ACCOUNT_SUMMARY],
        currentUserData: state.currentLoginUserDataReducer.currentUserData,
        corporateNominees: state.retriveAccountNomineeReducer.corporateNominees,
        profileData: state.profileDataReducer.profileData
    }
}


const mapDispatchToProps = {
    fetchCurrentLoginUserData,
    fetchConfiguration,
    fetchAccountNominee,
    fetchAccountSummary,
    fetchProfileData
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(PortalBreadcrumb)));