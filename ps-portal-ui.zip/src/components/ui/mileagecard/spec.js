import React from 'react';
import MemberCard from './index'
import {
    findByTestAttr,
    findComponent,
    mockServiceResponse
} from '../../common/testUtils';
import { testStore } from '../../common/utils';
import moxios from 'moxios';
import { mount } from 'enzyme';
import {
    fetchUserInfo,
    fetchAccountSummary
} from '../../common/middleware/redux/commonAction';
import { SESSION_STORAGE_COMPANY_CODE, SESSION_STORAGE_PROGRAM_CODE, SESSION_STORAGE_MEMBERSHIP_NO } from '../../common/utils/Constants';
import { Provider } from 'react-redux';
import { fetchProfileImage, getQrCodeImage } from './action';


var store = testStore({})
let rootComponent;
let component;
var t = jest.fn()

const setUp = (props = {}) => {
    window.sessionStorage.setItem(SESSION_STORAGE_COMPANY_CODE, 'IBS')
    window.sessionStorage.setItem(SESSION_STORAGE_PROGRAM_CODE, 'PRG14')
    localStorage.setItem(SESSION_STORAGE_MEMBERSHIP_NO, 'IM0008010415')
    rootComponent = mount(
        <Provider store={store} >
            <MemberCard {...props} />
        </Provider>
    );
    component = findComponent(rootComponent, 'MemberCard');
};


describe('MemberCard Component', () => {
    describe('Render without errors', () => {

        const config = { "fields": [{ "name": "totalMiles", "id": "totalMiles", "category": "points", "visibility": true, "grouping": "summary", "data": { "pointTypes": ["BASE", "BONUS"] } }, { "name": "myPoints", "id": "myPoints", "visibility": true, "category": "points", "grouping": "pointTypesDisplay", "data": { "pointTypes": ["BASE"] } }, { "name": "partnerPoints", "id": "partnerPoints", "visibility": true, "category": "points", "grouping": "pointTypesDisplay", "data": { "pointTypes": ["BONUS"] } }, { "name": "myFlights", "id": "myFlights", "visibility": true, "category": "points", "grouping": "pointTypesDisplay", "data": { "pointTypes": ["FC"] } }, { "name": "notification", "id": "notification", "visibility": true, "category": "message", "grouping": "notification", "data": { "pointTypes": ["BASE", "BONUS"], "threshold": -5000 } }, { "name": "includeMileageLink", "id": "includeMileageLink", "link": "#", "category": "navigation", "grouping": "links", "visibility": false }] }
        const defaultValues = { "defaultAbsoluteIndex": 1, "defaultPageSize": 10, "isBonusRequiredForAccoutnSummary": "Y" }
        let props = { config, defaultValues, t }
        const RESPONSE_SEARCH_MEMBER = { "statuscode": "200", "object": { "firstName": "Supriya", "surname": "Prithviraj", "secondName": "", "membershipStatus": "Active", "accountStatus": "Active", "tierCode": "BLU", "tierName": "Blue", "mobileISDCode": "", "mobileAreaCode": "", "mobileNumber": "", "dateOfBirth": "22-Jul-1993", "emailAddress": "ps-test-901@loyalty.com", "membershipNumber": "IM0008010949" } }
        const RESPONSE_ACCOUNT_SUMMARY = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "title": "Mrs", "givenName": "Supriya", "familyName": "Prithviraj", "membershipType": "Individual", "membershipStatus": "Active", "membershipStatusCode": "A", "accountStatus": "Active", "accountStatusCode": "A", "suspended": false, "tierCode": "BLU", "tierName": "Blue", "tierFromDate": "25-Aug-2020", "tierToDate": "", "prospectTier": "", "companyName": "", "expiryDate": null, "lastActivityDate": "24-Sep-2020", "activityType": "Accrual Activity", "expiryDetails": [{ "pointType": "FS", "points": 1.0, "expiryDate": "23-Sep-2021" }, { "pointType": "BASE", "points": 2000.0, "expiryDate": "24-Aug-2023" }, { "pointType": "BASE", "points": 1000.0, "expiryDate": "25-Aug-2023" }, { "pointType": "BONUS", "points": 500.0, "expiryDate": "31-Aug-2023" }, { "pointType": "BASE", "points": 1000.0, "expiryDate": "31-Aug-2023" }, { "pointType": "BASE", "points": 1200.0, "expiryDate": "30-Sep-2023" }, { "pointType": "BONUS", "points": 600.0, "expiryDate": "30-Sep-2023" }], "pointDetails": [{ "pointType": "BASE", "pointTypeGroup": "Total Miles", "totalAccuredpoints": 5200.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 5200.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "BONUS", "pointTypeGroup": "Total Miles", "totalAccuredpoints": 1100.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 1100.0, "bonusDetails": [{ "bonusCode": "ENB", "bonusName": "Enrolment Partner Bonus", "points": 500.0 }, { "bonusCode": "CBNBNS", "bonusName": "Cabin Bonus", "points": 600.0 }], "creditLimit": 0.0 }, { "pointType": "TIER", "pointTypeGroup": "Qualifying Miles", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "TIERKE", "pointTypeGroup": "Qualifying Miles", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "FS", "pointTypeGroup": "Qualifying Segments", "totalAccuredpoints": 1.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 1.0, "bonusDetails": [], "creditLimit": 0.0 }, { "pointType": "FC", "pointTypeGroup": "Qualifying Segments", "totalAccuredpoints": 0.0, "totalRedeemedpoints": 0.0, "pointsToNextTier": 0.0, "pointsForTierRetention": 0.0, "points": 0.0, "bonusDetails": [], "creditLimit": 0.0 }] } }
        const RESPONSE_IMAGE = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "profileImgData": "/9j/4AAQSkZJRgABAQEAYABgAAD/4UF4RXhpZgAATU0AKgAAd6q3aqsUEu6Ni+RtVvn9MkelFFUkSzL1K6NzeErAsZWNRtj4GAMFqKKK3MOVH//Z", "profileImgType": "jpg", "isPrivate": false, "profileImgEncoder": "base64" } }
        beforeEach(() => {
            moxios.install()
            setUp({ ...props })
            //Security configuration API call
            mockServiceResponse(RESPONSE_SEARCH_MEMBER, 200)
            return store.dispatch(
                fetchUserInfo({})
            ).then(() => {
                rootComponent.update()
                mockServiceResponse(RESPONSE_ACCOUNT_SUMMARY, 200)
                return store.dispatch(
                    fetchAccountSummary({})
                ).then(() => {
                    rootComponent.update()
                    mockServiceResponse(RESPONSE_IMAGE, 200)
                    return store.dispatch(
                        fetchProfileImage({})
                    )
                })
            })
        })

        afterEach(() => {
            moxios.uninstall()
        })

        test("Success", () => {
            const RESPONSE_QR_CODE = {"object":{"qrCode":"iVBORw0KGgoggg=="}}
            rootComponent.update()
            mockServiceResponse(RESPONSE_QR_CODE, 200)
            let qrLink = findByTestAttr(rootComponent, "qrLink")
            qrLink.prop('onClick')()
            return store.dispatch(
                getQrCodeImage({})
            ).then(() => {
                rootComponent.update()
            })
        })


    })
})