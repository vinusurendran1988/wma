import React, { Component } from 'react';
import { connect } from 'react-redux';
import {
    numberWithCommas,
    getExpiryText,
    isEmptyOrSpaces,
    toTitleCase
} from '../../common/utils'
import {
    getQrCodeImage
} from '../../common/middleware/redux/commonAction'
import {
    fetchAccountSummary,
    resetError,
    fetchProfileImage
} from '../../common/middleware/redux/commonAction'
import { 
    CATEGORY_POINTS, 
    GROUPING_POINTTYPES_DISPLAY, 
    GROUPING_SUMMARY, 
    GROUPING_NOTIFICATION, 
    CATEGORY_NAVIGATION, 
    GROUPING_LINKS, 
    CATEGORY_MESSAGE 
} from './Constants';
import {
    getItemFromBrowserStorage,
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO
} from '../../common/utils/storage.utils';
import DigitalCard from '../../common/components/fieldbank/DigitalCard';
import { _IMAGE_BASEURL } from '../../common/config/config';
class MemberCard extends Component {

    constructor(props) {
        super(props)
        this.state = {
            companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
            programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
            membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
            totalMiles: 0,
            baseExpiry: "",
            pointTypeList: []
        }
        this.getQrCode = this.getQrCode.bind(this);
    }

    getQrCode() {
        const companyCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE)
        const programCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE)
        const membershipNumber = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)
        const qrimagerequest = {
            object: {
                companyCode,
                programCode,
                membershipNumber
            }
        }

        if (this.props.qrcodeImage && this.props.qrcodeImage.qrCode) {
            setTimeout(() => {
                this.setState({ qrcode: 'data:image/png;base64,' + this.props.qrcodeImage.qrCode });
            }, 1000)
        } else {
            this.props.getQrCodeImage(qrimagerequest);
        }
    }


    componentDidUpdate(prevProps) {
        if (this.props.qrcodeImage && this.props.qrcodeImage.qrCode && !this.state.qrcode) {
            this.setState({ qrcode: 'data:image/png;base64,' + this.props.qrcodeImage.qrCode });
        }
    }

    getPoints(accountSummary, pointTypeList) {
        let point = 0
        accountSummary.pointDetails.map((pointData) => {
            if (pointTypeList.includes(pointData.pointType)) point += pointData.points
        })
        return point;
    }

    componentDidMount() {
        this.props.resetError()
        if (!this.props.accountSummary) {
            this.props.fetchAccountSummary()
        }

        if (!this.props.profileImage) {
            const profileImageRequest = {
                object: {
                    companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                    programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                    membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)
                }
            }
            this.props.fetchProfileImage(profileImageRequest)
        }

    }

    render() {

        const { config, accountSummary, t } = this.props
        return (
            <>
                <div className="card mb-3 cardWrap cardWrap1" data-test="MemberCard">
                    <div className="d-sm-none d-md-block">

                        <div className="card-header userDetails ">
                            <h5>
                                {this.props.accountSummary && this.props.accountSummary.tierName} {t('sidebar.mileage_card.member')}
                                <a className="membershipCard" data-toggle="modal" data-target="#exampleModalCenter" onClick={() => this.getQrCode()} data-test="qrLink"><i className="fa fa-credit-card-alt" aria-hidden="true"></i></a>
                            </h5>
                            <div className="d-flex justify-content-start"><div><img
                                src={
                                    this.props.profileImage ?
                                        "data:image/" +
                                        this.props.profileImage.profileImgType +
                                        ";" +
                                        this.props.profileImage.profileImgEncoder +
                                        "," +
                                        this.props.profileImage.profileImgData
                                        : `${_IMAGE_BASEURL}/default-profile-picture.png`
                                }
                                alt="Profile Photo" width="50" className="rounded mx-auto d-block" /></div>
                                <div className="ml-2">
                                    {this.props.accountSummary && localStorage.setItem('loggerUser', toTitleCase(this.props.accountSummary.givenName + " " + this.props.accountSummary.familyName))}
                                    <div>
                                        {this.props.accountSummary && toTitleCase(this.props.accountSummary.givenName)}
                                        &nbsp;
                                        <span>{this.props.accountSummary && toTitleCase(this.props.accountSummary.familyName)}</span>
                                    </div>
                                    {`${t('sidebar.mileage_card.ffpNo')} ${this.state.membershipNumber}`}
                                    <a className="membershipCard" onClick={() => this.getQrCode()} data-toggle="modal" data-target="#digital-card-modal"><i className="fa fa-credit-card-alt" aria-hidden="true"></i> {t("sidebar.mileage_card.view_card")}</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    {
                        config && accountSummary &&
                        <div className="card-body">
                            {
                                config.fields.map((field, idx) => {
                                    if (field.category === CATEGORY_POINTS && field.visibility) {
                                        return {
                                            [GROUPING_SUMMARY]: <div data-test="Summary-Card" key={`${field.category}-${field.grouping}-${idx}`} className="h3 text-center d-md-block d-sm-none">{`${numberWithCommas(parseInt(this.getPoints(accountSummary, field.data.pointTypes)))} ${t('sidebar.mileage_card.miles')}`}</div>
                                        }[field.grouping]
                                    }
                                })
                            }
                            <div className="d-flex justify-content-between text-center mb-2">
                                {
                                    config.fields.map((field, idx) => {
                                        if (field.category === CATEGORY_POINTS && field.visibility) {
                                            return {
                                                [GROUPING_POINTTYPES_DISPLAY]: <div data-test="PointType-Card" key={`${field.category}-${field.grouping}-${idx}`}>{t('sidebar.mileage_card.' + field.id)}<span className="d-block">{numberWithCommas(parseInt(this.getPoints(accountSummary, field.data.pointTypes)))}</span></div>
                                            }[field.grouping]
                                        }
                                    })
                                }
                            </div>
                            {
                                config.fields.map(field => {
                                    if (field.category === CATEGORY_MESSAGE && field.visibility) {
                                        return field.data.pointTypes.map((pointType, idx) => {
                                            let baseExpiry = getExpiryText(this.props.accountSummary.expiryDetails, pointType, this.props.t('sidebar.mileage_card.expiry_message'), field.data.threshold ? field.data.threshold : -1)
                                            if (!isEmptyOrSpaces(baseExpiry))
                                                return {
                                                    [GROUPING_NOTIFICATION]: <div className="mb-1" key={`${field.category}-${field.grouping}-${idx}`}><span className="badge badge-warning d-block text-left"><i className="fa fa-exclamation-circle" aria-hidden="true"></i>&nbsp;&nbsp;{baseExpiry}</span></div>
                                                }[field.grouping]
                                        })
                                    }
                                })
                            }
                            {
                                config.fields.map((field, idx) => {
                                    if (field.category === [CATEGORY_NAVIGATION] && field.visibility) {
                                        return {
                                            [GROUPING_LINKS]: <div key={`${field.category}-${field.grouping}-${idx}`} className="text-center"><a href={field.link}>{t('sidebar.mileage_card.includeMileageLink')}<i className="fa fa-angle-right" aria-hidden="true"></i></a></div>
                                        }[field.grouping]
                                    }
                                })
                            }
                        </div>
                    }
                </div>
                <DigitalCard id="digital-card-modal" membershipNumber={this.state.membershipNumber} qrCode={this.state.qrcode} accountSummary={this.props.accountSummary} />

            </>
        );
    }
}

function mapStateToProps(state) {
    return {
        accountSummary: state.accountSummaryReducer.accountSummary,
        profileImage: state.profileImageReducer.profileImage,
        qrcodeImage: state.qrCodeImageReducer.qrImage
    }
}

const mapDispatchToProps = { fetchAccountSummary, getQrCodeImage, fetchProfileImage, resetError }
export default connect(mapStateToProps, mapDispatchToProps)(MemberCard);
