
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { withSuspense, isEmptyOrSpaces, setItemsToBrowserStorageFromConfig, isLoggedIn, getLandingPageURL } from '../../common/utils';
import { _URL_SOCIAL_LOGIN_FACEBOOK, _URL_SOCIAL_LOGIN_GOOGLE, _URL_CALLBACK, _URL_AIRNZ_IDP_LOGIN } from '../../common/config/config';
import { loginDetails, clearLoginResponse } from './actions';
import { fetchConfiguration, logOut } from '../../common/middleware/redux/commonAction';
import { redirectPage } from '../../common/utils/sso.utils'
import {
    CONFIG_SECTION_LOGIN,
    CONFIG_SECTION_DEFAULT,
    PROGRAM_TYPE_CORPORATE,
    PROGRAM_TYPE_INDIVIDUAL
} from '../../common/utils/Constants';
import { FIELD_INVALID } from '../enrolment/Constants';
import CustomMessage from '../../common/components/custommessage';
import { NAVIGATE_MEMBER_DASHBOARD, NAVIGATE_FORGOT_PASSWORD, NAVIGATE_MEMBER_REGISTER, NAVIGATE_404, NAVIGATE_403, NAVIGATE_CORPORATE_REGISTER, NAVIGATE_CORPORATE_OVERVIEW } from '../../common/utils/urlConstants';
import {
    getItemFromBrowserStorage,
    BROWSER_STORAGE_KEY_TOKEN,
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    BROWSER_STORAGE_KEY_PROGRAM_TYPE
} from '../../common/utils/storage.utils';
import Button from '../../common/components/fieldbank/Button';
import { LOGIN_BUTTION } from './Constant';

class Login extends Component {

    constructor(props) {
        super(props);
        this.state = {
            loginType: "",
            rememberMe: false,
            data: {},
            errorMessages: [],
            canTranslate: false,
            errorFields: [],
            validation: {},
            passwordValidation: {},
            noOfAttempts: 0,
            canProceed: false
        }
        this.loginTypeOnchange = this.loginTypeOnchange.bind(this);
        this.setConfigToState = this.setConfigToState.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleRememberMe = this.handleRememberMe.bind(this)
        this.validateData = this.validateData.bind(this)
        this.fieldInvalid = this.fieldInvalid.bind(this)
        this.fieldValid = this.fieldValid.bind(this)
        this.isPatternMatch = this.isPatternMatch.bind(this)
        this.submitLogin = this.submitLogin.bind(this)
        this.handleOnBlur = this.handleOnBlur.bind(this)
        this.setValidationRegex = this.setValidationRegex.bind(this)
        this.querParams = this.querParams.bind(this)
        this.faceBookLogin = this.faceBookLogin.bind(this)
        this.googleLogin = this.googleLogin.bind(this)
        this.setPwd = this.setPwd.bind(this)
    }

    componentDidMount() {
        if (!isLoggedIn()) {
            const hasStorageItemChanged = setItemsToBrowserStorageFromConfig(this.props.browserStorage)
            if(hasStorageItemChanged){
                this.props.refreshStorageData(this.props.defaultConfig, this.props.configuration, CONFIG_SECTION_LOGIN)
            }
            if (this.props.configuration) {
                this.setConfigToState({})
            }
            if (getItemFromBrowserStorage(BROWSER_STORAGE_KEY_TOKEN)) {
                this.props.logOut(false)
            }
            this.props.setPageInfo(this.props, {config: this.props.configuration, confSection: CONFIG_SECTION_LOGIN})
        }
        this.airNZLogin();
    }
    componentDidUpdate(prevProps) {
        let newState = {}

        const { loginData, configuration, currentUserData } = this.props
        
        if(configuration && this.state.canProceed){
            if(loginData && Object.keys(loginData).length>0 && !loginData.success){
                    newState["noOfAttempts"] = this.state.noOfAttempts + 1,
                    newState["errorMessages"] = [this.props.loginData.message],
                    newState["canTranslate"] = false,
                    newState["canProceed"] = false
                let { maxLoginAttempt } = configuration.ui
                maxLoginAttempt = maxLoginAttempt ? maxLoginAttempt : 3
                if (newState.noOfAttempts > maxLoginAttempt)  {
                    newState["errorMessages"].push(this.props.t("login.message.more_fail_attempts"))
                }
            } else if(loginData && Object.keys(loginData).length>0 && currentUserData){
                newState["canProceed"] = false
                if (loginData.show == undefined || !loginData.show) {
                    window.location = `#${NAVIGATE_403}`
                } else {

                    if (getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE) === PROGRAM_TYPE_CORPORATE) {
                        window.location = `#${NAVIGATE_CORPORATE_OVERVIEW}`
                    } else if (getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE) === PROGRAM_TYPE_INDIVIDUAL) {
                        redirectPage()
                    } else {
                        window.location = `#${NAVIGATE_404}`
                    }
                }
            }
        }

        if (this.props.configuration &&
            JSON.stringify(prevProps.configuration) !== JSON.stringify(this.props.configuration)) {
            this.setConfigToState(newState)
        } else if (Object.keys(newState).length > 0) {
            this.setState(newState)
        }

        // if (!isEmptyOrSpaces(getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE)) &&
        //     !isEmptyOrSpaces(getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE)) &&
        //     this.props.configuration &&
        //     this.props.configuration.programCode != getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE)) {
        //     this.props.fetchConfiguration(CONFIG_SECTION_LOGIN)
        // }
    }

    querParams() {
        return new URLSearchParams(window.location.search);
    }

    loginTypeOnchange(loginType) {
        const { errorFields, passwordValidation } = this.state
        errorFields.forEach(fieldId => {
            this.fieldValid(fieldId)
        })
        let newState = {
            loginType,
            data: {},
            errorFields: [],
            errorMessages: [],
            canTranslate: false,
            rememberMe: false
        }

        let rememberMeState = {}
        rememberMeState = this.handleRememberMe(rememberMeState)
        if (rememberMeState.loginType === loginType) {
            newState["data"] = rememberMeState["data"]
            newState["rememberMe"] = rememberMeState["rememberMe"]
        }
        newState = this.setValidationRegex(newState)
        this.setState(newState, () => {
            if (this.state.rememberMe) {
                this.setPwd()
            } else {
                if (passwordValidation.id && document.getElementById(passwordValidation.id))
                    document.getElementById(passwordValidation.id).value = ''
            }
        });
    }

    setValidationRegex(newState) {
        if (this.props.configuration) {
            this.props.configuration.ui.layout.elements.loginCard.fields.forEach(f => {
                if (f.loginType === newState.loginType &&
                    f.validation && Object.keys(f.validation).length > 0) {
                    newState["validation"] = f.validation
                    newState["validation"].id = f.id
                } else if (f.type === "password") {
                    newState["passwordValidation"] = f.validation
                    newState["passwordValidation"].id = f.id
                    newState["passwordValidation"].fieldName = f.name
                }
            })
        }
        return newState
    }

    setConfigToState(newState) {
        newState = this.handleRememberMe(newState)
        newState["loginConfigration"] = this.props.configuration
        if (isEmptyOrSpaces(newState.loginType)) {
            newState["loginType"] = this.props.configuration.ui.defaultLoginTypes
        }
        newState = this.setValidationRegex(newState)
        if (!isEmptyOrSpaces(this.querParams().get('error'))) {
            const errorMessages = ["login.message.no_user_register"]
            newState["errorMessages"] = errorMessages
            newState["canTranslate"] = true
        }
        this.setState(
            newState, () => {
                this.setPwd()
            }
        );
    }

    setPwd() {
        const { passwordValidation, data } = this.state
        if (passwordValidation && Object.keys(data).length > 0 && passwordValidation.id && document.getElementById(passwordValidation.id)) {
            const password = data.customerPassword ? data.customerPassword : data.password
            document.getElementById(passwordValidation.id).value = password
        }
    }

    handleChange(e, field) {
        const { data, errorFields, loginType } = this.state

        this.props.clearLoginResponse()
        const newState = { data }
        if (errorFields.length > 0) errorFields.forEach(fieldId => { this.fieldValid(fieldId) })
        newState.data[field.name] = e.target.value.trim()
        if (field.loginType == loginType) {
            newState["validation"] = field.validation
            newState["validation"].id = e.target.id
        }
        newState["errorFields"] = []
        newState["errorMessages"] = []
        newState["canTranslate"] = false
        this.setState(newState)
    }

    handleOnBlur(field) {
        const { data } = this.state
        if (field.toUpper && data[field.name]) {
            data[field.name] = data[field.name].toUpperCase()
            this.setState({ data })
        }
    }

    handleRememberMe(newState) {
        newState["rememberMe"] = false
        try {
            if (document.cookie) {
                let cookieValue = document.cookie.split(";");
                if (cookieValue.length) {
                    let data = undefined
                    cookieValue.forEach(item => {
                        let splitElement = item.split("=")
                        if (!data && splitElement[0].trim().includes("rememberMe")) {
                            if (splitElement[0].trim() == "rememberMe-" + getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE)) {
                                data = splitElement[1].trim()
                                if (!isEmptyOrSpaces(data) && data != "null" && !isEmptyOrSpaces(window.atob(data))) {
                                    try {
                                        data = JSON.parse(window.atob(data))
                                        const { loginType } = data
                                        delete data["loginType"]
                                        newState = {
                                            loginType,
                                            data,
                                            rememberMe: true
                                        }
                                    } catch (error) {
                                        console.log("Parse error: ", error)
                                    }
                                }
                            } else {
                                newState = {
                                    loginType: "",
                                    data: {},
                                    rememberMe: false
                                }
                                if (this.props.configuration &&
                                    !isEmptyOrSpaces(this.props.configuration.ui.defaultLoginTypes)) {
                                    newState["loginType"] = this.props.configuration.ui.defaultLoginTypes
                                }
                            }
                        }
                    });
                }
            }
        } catch (error) {
            console.log("error: remember me : error : ", error)
        }
        return newState
    }

    validateData() {
        const errorMessages = [], errorFields = [], canTranslate = true
        const fields = this.props.configuration.ui.layout.elements.loginCard.fields.filter(f => { return f.loginType == this.state.loginType })
        const userInput = this.state.data[fields[0].name]
        //Validation for user id or email id or membership number
        if (Object.keys(this.state.validation).length > 0) {
            if (!this.isPatternMatch(this.state.validation.pattern, userInput)) {
                errorMessages.push(this.state.validation.customMessageId)
                this.fieldInvalid(this.state.validation.id)
                errorFields.push(this.state.validation.id)
            } else {
                this.fieldValid(this.state.validation.id)
            }
        }
        //Validation for password
        if (Object.keys(this.state.passwordValidation).length > 0) {
            if (!this.isPatternMatch(this.state.passwordValidation.pattern, this.state.data[this.state.passwordValidation.fieldName])) {
                errorMessages.push(this.state.passwordValidation.customMessageId)
                this.fieldInvalid(this.state.passwordValidation.id)
                errorFields.push(this.state.passwordValidation.id)
            } else {
                this.fieldValid(this.state.passwordValidation.id)
            }
        }
        if (errorMessages.length > 0) {
            this.setState({ errorMessages, errorFields, canTranslate })
            return false
        }
        return true
    }

    fieldInvalid(id) {
        if (id && document.getElementById(id))
            document.getElementById(id).className = document.getElementById(id).className + " " + FIELD_INVALID
    }

    fieldValid(id) {
        if (id && document.getElementById(id))
            document.getElementById(id).classList.remove(FIELD_INVALID)
    }

    isPatternMatch(pattern, value) {
        if (value == undefined) return false
        const regex = new RegExp(pattern)
        return regex.test(value)
    }

    faceBookLogin() {
        const fbloginurl = _URL_SOCIAL_LOGIN_FACEBOOK +
            encodeURIComponent(_URL_CALLBACK) +
            '&companyCode=' +
            getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE) +
            '&programCode=' +
            getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE) +
            '&t=l&source=login'
        location.href = fbloginurl;
    }

    googleLogin() {
        const gloginurl = _URL_SOCIAL_LOGIN_GOOGLE +
            encodeURIComponent(_URL_CALLBACK) +
            '&companyCode=' +
            getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE) +
            '&programCode=' +
            getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE) +
            '&source=login'
        location.href = gloginurl;
    }

    airNZLogin() {
        if (isLoggedIn() && typeof this.props.currentUserData != "undefined") {
            window.location.href = getLandingPageURL(this.props.currentUserData.userDetails);
        } else {
            const airNZ = _URL_AIRNZ_IDP_LOGIN +
                encodeURIComponent(_URL_CALLBACK) +
                '&companyCode=' +
                getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE) +
                '&programCode=' +
                getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE) +
                '&source=login'
            location.href = airNZ;
        }
    }

    submitLogin(e) {
        if(e){
            e.stopPropagation();
            e.preventDefault();
        }
        if (this.validateData()) {
            const { data, loginType, noOfAttempts, rememberMe, loginConfigration } = this.state
            let clientId = loginConfigration ? loginConfigration.ui.clientId : '';
            let secredId = loginConfigration ? loginConfigration.ui.secret : '';
            let secretKey = loginConfigration ? loginConfigration.ui.secretKey : '';
            let expireDate = loginConfigration ? loginConfigration.ui.rememberMeExpiresDays : '';

            let payload = {
                data: { ...data },
                clientId,
                secredId,
                secretKey,
                expireDate
            }
            this.setState({
                canProceed: true
            })
            this.props.loginDetails(payload, noOfAttempts, rememberMe, this.props.defaultConfig, loginType, LOGIN_BUTTION);
        } else {
            console.log("validation error")
        }
    }

    render() {
        const { t } = this.props;
        const { loginConfigration } = this.state;
        const loginTypes = loginConfigration ? loginConfigration.loginTypes : [];
        const socialLoginTypes = loginConfigration ? loginConfigration.socialLoginTypes : [];
        let fields = loginConfigration ? loginConfigration.ui.layout.elements.loginCard.fields : [];
        const programType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE)

        return (
            <div data-test="LoginComponent">
                <div className="modal-dialog loginComponent">
                    <div className="modal-content">
                        {
                            loginConfigration &&
                            <div className="modal-body p-5">
                                <form className="form-signin" onSubmit={(e) => this.submitLogin(e)}>
                                    <div className="login-heading">
                                        <h1 id="login-component-title">{t(loginConfigration.ui.layout.elements.loginCard.i18n ? loginConfigration.ui.layout.elements.loginCard.i18n.title : 'login.title')}</h1>
                                        <p>{t(loginConfigration.ui.layout.elements.loginCard.i18n ? loginConfigration.ui.layout.elements.loginCard.i18n.subTitle : `login.sub_title`)}</p>
                                    </div>
                                    <CustomMessage message={this.state.errorMessages} type={"danger"} canTranslate={this.state.canTranslate} />
                                    <div className="form-row">
                                        <div className="col-lg-10 text-left">
                                            <div className="form-group">
                                                <ul className="radio-wrap">
                                                {
                                                    loginTypes.map((type, index) => {
                                                        return {
                                                            "userId": <li key={'login-type-' + index}>
                                                                <input type="radio"
                                                                    id="userIdInput"
                                                                    name="inlineRadioOptions"
                                                                    onChange={() => { this.loginTypeOnchange(type) }}
                                                                    checked={this.state.loginType === type}
                                                                    data-test="userIdInput" />
                                                                <label htmlFor="userIdInput">{t('login.user-input')}</label>
                                                            </li>,
                                                            "membershipNumber": 
                                                            <li key={'login-type-' + index}>
                                                                <input type="radio"
                                                                    id="memberInput"
                                                                    name="inlineRadioOptions"
                                                                    onChange={() => { this.loginTypeOnchange(type) }}
                                                                    checked={this.state.loginType === type}
                                                                    data-test="memberInput" />
                                                                <label htmlFor="memberInput">{t('login.user-membership')}</label>
                                                            </li>,
                                                            "email": 
                                                                <li key={'login-type-' + index}>
                                                                    <input type="radio"
                                                                        id="emailInput"
                                                                        name="inlineRadioOptions"
                                                                        onChange={() => { this.loginTypeOnchange(type) }}
                                                                        checked={this.state.loginType === type}
                                                                        data-test="emailInput" />
                                                                    <label htmlFor="emailInput">{t('login.email-input')}</label>
                                                                </li>

                                                        }[type] || <div key={'login-type-'+index}></div>
                                                    })
                                                }
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="form-row">
                                        {
                                            fields.map((field, index) => {
                                                if (field.visibility) {
                                                    return {
                                                        "userId":
                                                            this.state.loginType === field.loginType ?
                                                                <div key={'field-'+index}
                                                                    className="col-lg-12">
                                                                    <div className="form-group">
                                                                        <label className="sr-only" htmlFor={field.id}>{t('login.user-input')}</label>
                                                                        <input data-test="userName"
                                                                            className=""
                                                                            type="text"
                                                                            name={field.name}
                                                                            placeholder={t('login.user-input')}
                                                                            onChange={(e) => this.handleChange(e, field)}
                                                                            value={this.state.data[field.name] ? this.state.data[field.name] : ''}
                                                                            id={field.id}
                                                                            autoComplete="off" />
                                                                    </div>
                                                                </div> : "",
                                                        "preferredEmail":
                                                            this.state.loginType === field.loginType ?
                                                                <div key={'field-'+index}
                                                                    className="col-lg-12">
                                                                    <div className="form-group">
                                                                        <label className="sr-only" htmlFor={field.id}>{t('login.email-input')}</label>
                                                                        <input data-test="userName"
                                                                            className=""
                                                                            type="text"
                                                                            name={field.name}
                                                                            placeholder={t('login.email-input')}
                                                                            onChange={(e) => this.handleChange(e, field)}
                                                                            value={this.state.data[field.name] ? this.state.data[field.name] : ''}
                                                                            id={field.id}
                                                                            autoComplete="off" />
                                                                    </div>
                                                                </div> : "",
                                                        "membershipNumber":
                                                            this.state.loginType === field.loginType ?
                                                                <div key={'field-'+index}
                                                                    className="col-lg-12">
                                                                    <div className="form-group">
                                                                        <label className="sr-only" htmlFor={field.id}>{t('login.user-membership')}</label>
                                                                        <input data-test="userName"
                                                                            className=""
                                                                            type="text"
                                                                            name={field.name}
                                                                            placeholder={t('login.user-membership')}
                                                                            onChange={(e) => this.handleChange(e, field)}
                                                                            onBlur={() => this.handleOnBlur(field)}
                                                                            value={this.state.data[field.name] ? this.state.data[field.name] : ''}
                                                                            id={field.id}
                                                                            autoComplete="off" />
                                                                    </div>
                                                                </div> : "",
                                                        "customerPassword":
                                                            <div key={'field-'+index}
                                                                className="col-lg-12">
                                                                <div className="form-group">
                                                                    <label className="sr-only" htmlFor={field.id}>{t('login.psw')}</label>
                                                                    <input data-test="password"
                                                                        name={field.name}
                                                                        type="password"
                                                                        placeholder={t('login.psw')}
                                                                        className=""
                                                                        onChange={(e) => this.handleChange(e, field)}
                                                                        id={field.id} />
                                                                </div>
                                                            </div>,
                                                        "password":
                                                            <div key={'field-'+index}
                                                                className="col-lg-12">
                                                                <div className="form-group">
                                                                    <label className="sr-only" htmlFor={field.id}>{t('login.psw')}</label>
                                                                    <input data-test="password"
                                                                        name={field.name}
                                                                        type="password"
                                                                        placeholder={t('login.psw')}
                                                                        className=""
                                                                        onChange={(e) => this.handleChange(e, field)}
                                                                        id={field.id} />
                                                                </div>
                                                            </div>,
                                                        "rememberMe":
                                                            // <div className="col-6 form-check form-check-inline" key={'field-'+index}>
                                                            //     <input className="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1" />
                                                            //     <label className="form-check-label" htmlFor="inlineCheckbox1">Save this Recipient</label>
                                                            // </div>
                                                            <div key={'field-' + index}
                                                                className="col-6">
                                                                <div className="checkbox mb-3">
                                                                    <div className="form-check form-check-inline">
                                                                        <input
                                                                            className="form-check-input"
                                                                            type="checkbox"
                                                                            data-test="rememberMe"
                                                                            id="inlineCheckbox1"
                                                                            onChange={() => { this.setState({ [field.name]: !this.state[field.name] }) }}
                                                                            checked={this.state[field.name]}
                                                                        />
                                                                        <label className="form-check-label" htmlFor="inlineCheckbox1">{` ${t('login.remember_me')}`}</label>
                                                                    </div>
                                                                </div>
                                                            </div>,
                                                        "forgotPassword":
                                                            <div key={'field-'+index}
                                                                className="col-6 text-right">
                                                                <a data-test="forgotPassword"
                                                                    className="btn-link"
                                                                    onClick={() => window.location.href = `#${NAVIGATE_FORGOT_PASSWORD}`}>
                                                                    {t('login.forgot_psw')}
                                                                </a>
                                                            </div>,
                                                        "loginBtn":
                                                            <div key={'field-'+index}
                                                                className="col-lg-12">
                                                                <div className="form-group">
                                                                <Button 
                                                                    className="btn btn-lg btn-primary btn-block" 
                                                                    type="submit"
                                                                    handleOnClick={() => this.submitLogin()} 
                                                                    id={LOGIN_BUTTION} 
                                                                    data-test="buttonSubmit" 
                                                                    enabled={this.state.btnProceedToPay}
                                                                    label={t(loginConfigration.ui.layout.elements.loginCard.i18n ? loginConfigration.ui.layout.elements.loginCard.i18n : 'login.title')} />
                                                                </div>
                                                            </div>,
                                                        "joinNow":
                                                            <div key={'field-'+index}
                                                                className="col-lg-12">
                                                                {`${t('login.not-member')} `}
                                                                <a data-test="register" onClick={() => window.location.href = `#${programType===PROGRAM_TYPE_INDIVIDUAL?NAVIGATE_MEMBER_REGISTER:NAVIGATE_CORPORATE_REGISTER}`} className="btn-link">
                                                                    <strong>{t('login.register')}</strong>
                                                                </a>
                                                            </div>,
                                                        "seperator":
                                                            <div key={'field-'+index}
                                                                className="col-lg-12 p-3">
                                                                <hr />
                                                            </div>,
                                                        "socialLogin":
                                                            <div key={'field-'+index}
                                                                className="col-lg-12">
                                                                <h3>{t('login.social-media-logn')}</h3>
                                                                <div className="form-row">
                                                                    {
                                                                        socialLoginTypes.map((type, idx) => {
                                                                            return {
                                                                                "facebook": <div key={'social-login-'+idx} className="col-lg-4"><a className="fb btn d-block mb-2" data-test="facebook" onClick={this.faceBookLogin}><i className="fa fa-facebook fa-fw" ></i> <strong>{t('login.facebook')}</strong></a></div>,
                                                                                "twitter": <div key={'social-login-'+idx} className="col-lg-4"><a  className="twitter btn d-block mb-2 disabled"><i className="fa fa-twitter fa-fw"></i> <strong>{t('login.twitter')}</strong></a></div>,
                                                                                "google": <div key={'social-login-'+idx} className="col-lg-4"><a data-test="google" className="google btn d-block mb-2" onClick={this.googleLogin}><i className="fa fa-google fa-fw"></i> <strong>{t('login.google')}</strong></a></div>
                                                                            }[type] || <div key={'social-login-'+index}></div>
                                                                        })
                                                                    }
                                                                </div>
                                                            </div>
                                                    }[field.name] || <div key={'field-'+index}></div>
                                                } else {
                                                    return <div key={'field-'+index}></div>
                                                }
                                            })
                                        }
                                    </div>
                                </form>
                            </div>
                        }
                    </div>
                </div>
            </div>
        )
    }
}

function mapStateToProps(state) {
    return {
        loginData: state.login.loginInfo,
        configuration: state.configurationReducer[CONFIG_SECTION_LOGIN],
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        currentUserData: state.currentLoginUserDataReducer.currentUserData
    }
}
const mapDispatchToProps = {
    loginDetails,
    fetchConfiguration,
    logOut,
    clearLoginResponse
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(Login)))