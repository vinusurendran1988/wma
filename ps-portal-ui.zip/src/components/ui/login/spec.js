import React from 'react';
import Login from './index';
import { Provider } from 'react-redux';
import { SESSION_STORAGE_MEMBERSHIP_NO, CONFIG_SECTION_DEFAULT, SESSION_STORAGE_COMPANY_CODE, SESSION_STORAGE_PROGRAM_CODE } from '../../common/utils/Constants';
import {
    findByTestAttr,
    findComponent,
    mockServiceResponse
} from '../../common/testUtils';
import { testStore } from '../../common/utils';
import moxios from 'moxios';
import { mount, shallow } from 'enzyme';
import ReactTestUtils from 'react-dom/test-utils';
import { loginDetails } from './actions';
import { forGotPassword } from './actions';
import { entrolment } from './actions';

import {
    fetchConfiguration
} from '../../common/middleware/redux/commonAction';
import {
    CONFIG_SECTION_LOGIN
} from '../../common/utils/Constants';


let store, rootComponent, component;
const setUp = (props = {}) => {
    store = testStore({})
    window.sessionStorage.setItem(SESSION_STORAGE_COMPANY_CODE, 'IBS');
    window.sessionStorage.setItem(SESSION_STORAGE_PROGRAM_CODE, 'PRG14');
    window.localStorage.setItem(SESSION_STORAGE_MEMBERSHIP_NO, 'IM0008010415');
    Object.defineProperty(window.document, 'cookie', {
        writable: true,
        value: 'rememberMe=eyJtZW1iZXJzaGlwTnVtYmVyIjoiSU0wMDA4MDEwMTE0IiwiY3VzdG9tZXJQYXNzd29yZCI6IlB3ZEAxMjM0IiwibG9naW5UeXBlIjoibWVtYmVyc2hpcE51bWJlciJ9; expires=Thu, 18 Dec 2013 12:00:00',
    });
    global.window = Object.create(window)
    Object.defineProperty(window, 'location', {
        writable: true,
        value: {
            search: "error=true"
        },
    });
    rootComponent = mount(<Provider store={store}>
        <Login {...props} store={store} />
    </Provider>);
    component = findComponent(rootComponent, 'Login');
};

describe('Render the login component without errors',()=>{
    beforeEach(() => {
        setUp({})
        component.setState({
            loginType: "membershipNumber"
        })
        moxios.install();
    });

    afterEach(() => {
        moxios.uninstall();
    });

    describe('Login successfull',()=>{

        it('Successfully login with rememberMe enabled ', () => {
            mockServiceResponse(CONFIG_RESPONSE)
            return ReactTestUtils.act(() => {
                return store.dispatch(fetchConfiguration(CONFIG_SECTION_LOGIN))
                    .then(() => {
                        let newState = store.getState();
                        expect(newState.configurationReducer[CONFIG_SECTION_LOGIN]).toStrictEqual(CONFIG_RESPONSE.object);
                        mockServiceResponse(DEFAULT_RESPONSE)
                        return ReactTestUtils.act(() => {
                            return store.dispatch(fetchConfiguration(CONFIG_SECTION_DEFAULT))
                                .then(() => {
                                    newState = store.getState();
                                    expect(newState.configurationReducer[CONFIG_SECTION_DEFAULT]).toStrictEqual(DEFAULT_RESPONSE.object);
    
                                    const LoginComponent = findByTestAttr(component, 'LoginComponent');
                                    expect(LoginComponent.length).toBe(1);
    
                                    rootComponent = rootComponent.update()
                                    component = findComponent(rootComponent, 'Login');
                                    
                                    const newInstance = component.instance();
                                    const userIdInput = findByTestAttr(component, 'userIdInput')
                                    expect(userIdInput.length).toBe(1);
                                    userIdInput.simulate('click');
                                    newInstance.loginTypeOnchange("userId")
                                    
                                    const memNoRadioBtn = findByTestAttr(component, 'memberInput')
                                    expect(memNoRadioBtn.length).toBe(1);
                                    memNoRadioBtn.simulate('click');
                                    newInstance.loginTypeOnchange("membershipNumber")
    
                                    const userName = findByTestAttr(component, 'userName')
                                    expect(userName.length).toBe(1);
                                    component.setState({
                                        errorFields: ["id_user_id"]
                                    })
                                    userName.simulate('change',{target:{value:"IM0008010114"}},newState.configurationReducer[CONFIG_SECTION_LOGIN].ui.layout.elements.loginCard.fields[2]);
                                    userName.simulate('blur',newState.configurationReducer[CONFIG_SECTION_LOGIN].ui.layout.elements.loginCard.fields[2]);
    
                                    const password = findByTestAttr(component, 'password')
                                    expect(password.length).toBe(1);
                                    password.simulate('change',{target:{value:"Abcd@1234"}},newState.configurationReducer[CONFIG_SECTION_LOGIN].ui.layout.elements.loginCard.fields[2]);
    
                                    const rememberMe = findByTestAttr(component, 'rememberMe')
                                    expect(rememberMe.length).toBe(1);
                                    rememberMe.simulate('change');
    
                                    const buttonSubmit = findByTestAttr(component, 'buttonSubmit')
                                    expect(buttonSubmit.length).toBe(1);
    
                                    mockServiceResponse(LOGIN_SUCCESS_RESPONSE)
                                    return ReactTestUtils.act(()=>{
                                        buttonSubmit.simulate('click');
                                        return store.dispatch(loginDetails({"data":{}},0,true)).then(()=>{
                                            newState = store.getState();
                                            expect(newState.login.loginInfo).toStrictEqual(LOGIN_SUCCESS_RESPONSE);
                                        })
                                    })
                                    
                                });
                        });
                    });
            });
    
        })

        it('Successfully login with rememberMe disabled ', () => {
            mockServiceResponse(CONFIG_RESPONSE)
            return ReactTestUtils.act(() => {
                return store.dispatch(fetchConfiguration(CONFIG_SECTION_LOGIN))
                    .then(() => {
                        let newState = store.getState();
                        expect(newState.configurationReducer[CONFIG_SECTION_LOGIN]).toStrictEqual(CONFIG_RESPONSE.object);
                        mockServiceResponse(DEFAULT_RESPONSE)
                        return ReactTestUtils.act(() => {
                            return store.dispatch(fetchConfiguration(CONFIG_SECTION_DEFAULT))
                                .then(() => {
                                    mockServiceResponse(LOGIN_SUCCESS_RESPONSE)
                                    return ReactTestUtils.act(()=>{
                                        return store.dispatch(loginDetails({"data":{}},0,false)).then(()=>{
                                            newState = store.getState();
                                            expect(newState.login.loginInfo).toStrictEqual(LOGIN_SUCCESS_RESPONSE);
                                        })
                                    })
                                    
                                });
                        });
                    });
            });
    
        })

        it('Forgot password',()=>{
            mockServiceResponse(CONFIG_RESPONSE)
            return ReactTestUtils.act(() => {
                return store.dispatch(fetchConfiguration(CONFIG_SECTION_LOGIN))
                    .then(() => {
                        let newState = store.getState();
                        expect(newState.configurationReducer[CONFIG_SECTION_LOGIN]).toStrictEqual(CONFIG_RESPONSE.object);
                        mockServiceResponse(DEFAULT_RESPONSE)
                        return ReactTestUtils.act(() => {
                            return store.dispatch(fetchConfiguration(CONFIG_SECTION_DEFAULT))
                                .then(() => {
                                    newState = store.getState();
                                    expect(newState.configurationReducer[CONFIG_SECTION_DEFAULT]).toStrictEqual(DEFAULT_RESPONSE.object);

                                    const LoginComponent = findByTestAttr(component, 'LoginComponent');
                                    expect(LoginComponent.length).toBe(1);

                                    rootComponent.update()
                                    component = findComponent(rootComponent, 'Login');
                                    const forgotPassword = findByTestAttr(component, 'forgotPassword')
                                    expect(forgotPassword.length).toBe(1);
                                    forgotPassword.simulate('click');
                                });
                        });
                    });
            });
        })

        it('Join Now',()=>{
            mockServiceResponse(CONFIG_RESPONSE)
            return ReactTestUtils.act(() => {
                return store.dispatch(fetchConfiguration(CONFIG_SECTION_LOGIN))
                    .then(() => {
                        let newState = store.getState();
                        expect(newState.configurationReducer[CONFIG_SECTION_LOGIN]).toStrictEqual(CONFIG_RESPONSE.object);
                        mockServiceResponse(DEFAULT_RESPONSE)
                        return ReactTestUtils.act(() => {
                            return store.dispatch(fetchConfiguration(CONFIG_SECTION_DEFAULT))
                                .then(() => {
                                    newState = store.getState();
                                    expect(newState.configurationReducer[CONFIG_SECTION_DEFAULT]).toStrictEqual(DEFAULT_RESPONSE.object);

                                    const LoginComponent = findByTestAttr(component, 'LoginComponent');
                                    expect(LoginComponent.length).toBe(1);

                                    rootComponent.update()
                                    component = findComponent(rootComponent, 'Login');
                                    const register = findByTestAttr(component, 'register')
                                    expect(register.length).toBe(1);
                                    register.simulate('click');
                                });
                        });
                    });
            });
        })

        it('Socail media login',()=>{
            mockServiceResponse(CONFIG_RESPONSE)
            return ReactTestUtils.act(() => {
                return store.dispatch(fetchConfiguration(CONFIG_SECTION_LOGIN))
                    .then(() => {
                        let newState = store.getState();
                        expect(newState.configurationReducer[CONFIG_SECTION_LOGIN]).toStrictEqual(CONFIG_RESPONSE.object);
                        mockServiceResponse(DEFAULT_RESPONSE)
                        return ReactTestUtils.act(() => {
                            return store.dispatch(fetchConfiguration(CONFIG_SECTION_DEFAULT))
                                .then(() => {
                                    newState = store.getState();
                                    expect(newState.configurationReducer[CONFIG_SECTION_DEFAULT]).toStrictEqual(DEFAULT_RESPONSE.object);

                                    const LoginComponent = findByTestAttr(component, 'LoginComponent');
                                    expect(LoginComponent.length).toBe(1);

                                    rootComponent.update()
                                    component = findComponent(rootComponent, 'Login');
                                    const facebook = findByTestAttr(component, 'facebook')
                                    expect(facebook.length).toBe(1);
                                    facebook.simulate('click');

                                    const google = findByTestAttr(component, 'google')
                                    expect(google.length).toBe(1);
                                    google.simulate('click');
                                });
                        });
                    });
            });
        })
    });

})

describe('handling the error scenarios',()=>{
    beforeEach(() => {
        setUp({})
        component.setState({
            loginType: "userId",
            errorFields: ["id_user_id"]
        })
        moxios.install();
    });

    afterEach(() => {
        moxios.uninstall();
    });
    describe('Failure scenarios',()=>{
        it('Login failed as credentials failed to match', () => {
            mockServiceResponse(LOGIN_FAILURE_RESPONSE, 500)
            return ReactTestUtils.act(() => {
                return store.dispatch(loginDetails({ "data": {} })).then(() => {
                    let newState = store.getState();
                    expect(newState.login.loginInfo).toStrictEqual(LOGIN_FAILURE_RESPONSE);
                })
            })
        })

        it('Validaiton patterns were not matching with user inputs',()=>{
            mockServiceResponse(CONFIG_RESPONSE)
            return ReactTestUtils.act(() => {
                return store.dispatch(fetchConfiguration(CONFIG_SECTION_LOGIN))
                    .then(() => {
                        let newState = store.getState();
                        expect(newState.configurationReducer[CONFIG_SECTION_LOGIN]).toStrictEqual(CONFIG_RESPONSE.object);
                        mockServiceResponse(DEFAULT_RESPONSE)
                        return ReactTestUtils.act(() => {
                            return store.dispatch(fetchConfiguration(CONFIG_SECTION_DEFAULT))
                                .then(() => {
                                    newState = store.getState();
                                    expect(newState.configurationReducer[CONFIG_SECTION_DEFAULT]).toStrictEqual(DEFAULT_RESPONSE.object);

                                    const LoginComponent = findByTestAttr(component, 'LoginComponent');
                                    expect(LoginComponent.length).toBe(1);

                                    rootComponent.update()
                                    component = findComponent(rootComponent, 'Login');
                                    const memNoRadioBtn = findByTestAttr(component, 'memberInput')
                                    expect(memNoRadioBtn.length).toBe(1);
                                    memNoRadioBtn.simulate('click');

                                    const userName = findByTestAttr(component, 'userName')
                                    expect(userName.length).toBe(1);
                                    userName.simulate('change', { target: { value: "a21!@", id: "id_mem_id" } }, newState.configurationReducer[CONFIG_SECTION_LOGIN].ui.layout.elements.loginCard.fields[2]);
                                    userName.simulate('blur', newState.configurationReducer[CONFIG_SECTION_LOGIN].ui.layout.elements.loginCard.fields[2]);

                                    const password = findByTestAttr(component, 'password')
                                    expect(password.length).toBe(1);
                                    password.simulate('change', { target: { value: "a1" } }, newState.configurationReducer[CONFIG_SECTION_LOGIN].ui.layout.elements.loginCard.fields[2]);

                                    const rememberMe = findByTestAttr(component, 'rememberMe')
                                    expect(rememberMe.length).toBe(1);
                                    rememberMe.simulate('change');

                                    const buttonSubmit = findByTestAttr(component, 'buttonSubmit')
                                    expect(buttonSubmit.length).toBe(1);
                                    buttonSubmit.simulate('click');

                                });
                        });
                    });
            });
        })

        it('Maximum number of login attempts reached',()=>{
            mockServiceResponse(CONFIG_RESPONSE)
            return ReactTestUtils.act(() => {
                return store.dispatch(fetchConfiguration(CONFIG_SECTION_LOGIN))
                    .then(() => {
                        let newState = store.getState();
                        expect(newState.configurationReducer[CONFIG_SECTION_LOGIN]).toStrictEqual(CONFIG_RESPONSE.object);
                        mockServiceResponse(DEFAULT_RESPONSE)
                        return ReactTestUtils.act(() => {
                            return store.dispatch(fetchConfiguration(CONFIG_SECTION_DEFAULT))
                                .then(() => {
                                    newState = store.getState();
                                    expect(newState.configurationReducer[CONFIG_SECTION_DEFAULT]).toStrictEqual(DEFAULT_RESPONSE.object);
    
                                    const LoginComponent = findByTestAttr(component, 'LoginComponent');
                                    expect(LoginComponent.length).toBe(1);
    
                                    rootComponent = rootComponent.update()
                                    component = findComponent(rootComponent, 'Login');
                                    
                                    const newInstance = component.instance();
                                    const userIdInput = findByTestAttr(component, 'userIdInput')
                                    expect(userIdInput.length).toBe(1);
                                    userIdInput.simulate('click');
                                    newInstance.loginTypeOnchange("userId")
                                    
                                    const memNoRadioBtn = findByTestAttr(component, 'memberInput')
                                    expect(memNoRadioBtn.length).toBe(1);
                                    memNoRadioBtn.simulate('click');
                                    newInstance.loginTypeOnchange("membershipNumber")
    
                                    const userName = findByTestAttr(component, 'userName')
                                    expect(userName.length).toBe(1);
                                    component.setState({
                                        errorFields: ["id_user_id"]
                                    })
                                    userName.simulate('change',{target:{value:"IM0008010114"}},newState.configurationReducer[CONFIG_SECTION_LOGIN].ui.layout.elements.loginCard.fields[2]);
                                    userName.simulate('blur',newState.configurationReducer[CONFIG_SECTION_LOGIN].ui.layout.elements.loginCard.fields[2]);
    
                                    const password = findByTestAttr(component, 'password')
                                    expect(password.length).toBe(1);
                                    password.simulate('change',{target:{value:"Abcd@1234"}},newState.configurationReducer[CONFIG_SECTION_LOGIN].ui.layout.elements.loginCard.fields[2]);
    
                                    const rememberMe = findByTestAttr(component, 'rememberMe')
                                    expect(rememberMe.length).toBe(1);
                                    rememberMe.simulate('change');
    
                                    const buttonSubmit = findByTestAttr(component, 'buttonSubmit')
                                    expect(buttonSubmit.length).toBe(1);
    
                                    const errorLoop = ()=>{
                                        mockServiceResponse(LOGIN_FAILURE_RESPONSE, 500)
                                        return ReactTestUtils.act(() => {
                                            return store.dispatch(loginDetails({ "data": {} })).then(() => {
                                                newState = store.getState();
                                                expect(newState.login.loginInfo).toStrictEqual(LOGIN_FAILURE_RESPONSE);
                                                buttonSubmit.simulate('click')

                                            })
                                        })
                                    }
                                    // for(let i=0; i<5;i++){
                                    //     errorLoop()
                                    // }
                                    
                                    
                                });
                        });
                    });
            });
        })
    })
})

const CONFIG_RESPONSE = {"statuscode":"200","statusMessage":"SUCCESS","object":{"section":"login","companyCode":"IBS","programCode":"PRG14","loginTypes":["userId","email","membershipNumber"],"socialLoginTypes":["facebook","google","twitter"],"ui":{"order":["loginCard"],"defaultLoginTypes":"membershipNumber","clientId":"auth-channel","secret":"_DHFHSGDSFDSDAQ","rememberMeExpiresDays":30,"maxLoginAttempt":3,"secretKey":"487439fc-27ac-446e-96f7-2cd9d5f8b73f","layout":{"elements":{"loginCard":{"fields":[{"name":"userId","loginType":"userId","id":"id_user_id","visibility":true,"isRequired":true,"validation":{"pattern":"[a-zA-Z0-9]{5,20}","customMessageId":"login.message.enter_user_id"}},{"name":"preferredEmail","loginType":"email","id":"id_email_id","visibility":true,"isRequired":true,"validation":{"pattern":"\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$","customMessageId":"login.message.enter_valid_email"}},{"name":"membershipNumber","toUpper":true,"loginType":"membershipNumber","id":"id_mem_id","visibility":true,"isRequired":true,"validation":{"pattern":"[a-zA-Z0-9]{6,15}","customMessageId":"login.message.enter_valid_mem_id"}},{"name":"customerPassword","id":"id-psw","visibility":true,"isRequired":true,"type":"password","validation":{"pattern":"^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$","customMessageId":"login.message.enter_valid_password"}},{"name":"rememberMe","id":"id-remember-me","visibility":true},{"name":"forgotPassword","id":"id-forgot-password","visibility":true},{"name":"loginBtn","id":"id-login-btn","visibility":true},{"name":"joinNow","id":"id-join-now","visibility":true},{"name":"seperator","id":"id-seperator","visibility":true},{"name":"socialLogin","id":"id-social-login","visibility":true}]}}}}}}
const DEFAULT_RESPONSE = {"statuscode":"200","statusMessage":"SUCCESS","object":[{"section":"default","companyCode":"IBS","programCode":"PRG14","skipPinChangeReminder":true,"defaultCurrency":"USD","defaultPosCity":"SEO","defaultPosCountry":"KE","defaultPasswordRegex":"^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$","defaultEmailRegex":"\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$","requestTimedOutInMs":20000,"tiers":[{"name":"LATAM","code":"100","order":"1","upgradeExpiryInMonths":"0","downgradeExpiryInMonths":"0","themeClass":"userClass4"},{"name":"Gold","code":"200","order":"2","upgradeExpiryInMonths":"12","downgradeExpiryInMonths":"12","themeClass":"userClass2"},{"name":"Gold Plus","code":"300","order":"3","upgradeExpiryInMonths":"24","downgradeExpiryInMonths":"24","themeClass":"userClass2"},{"name":"Platinum","code":"400","order":"4","upgradeExpiryInMonths":"24","downgradeExpiryInMonths":"24","themeClass":"userClass3"},{"name":"Black","code":"500","order":"5","upgradeExpiryInMonths":"12","downgradeExpiryInMonths":"12","themeClass":"userClass5"},{"name":"Black Signature","code":"600","order":"5","upgradeExpiryInMonths":"0","downgradeExpiryInMonths":"0","themeClass":"userClass5"}],"currencies":[{"code":"HKD","name":"Hong Kong Dollar"},{"code":"TWD","name":"New Taiwan Dollar"},{"code":"PHP","name":"PESO"},{"code":"KRW","name":"South Korean Won"},{"code":"USD","name":"US Dollar"},{"code":"VND","name":"Vietnam Don"},{"code":"JPY","name":"Yen"},{"code":"CNY","name":"Yuan Renminbi"}],"partners":[{"value":"JL","name":"Japan Airlines"},{"value":"DL","name":"Delta Airlines"},{"value":"QF","name":"Qantas"},{"value":"LA","name":"Latam Airlines"}],"cabinClasses":{"LA":[{"cabinClassCode":"B","cabinClassName":"Business Class"},{"cabinClassCode":"E","cabinClassName":"Economy"}]},"cabinClassBookingClassMapping":{"LA":[{"cabinClass":"B","bookingClass":"J"},{"cabinClass":"B","bookingClass":"Z"},{"cabinClass":"B","bookingClass":"I"},{"cabinClass":"B","bookingClass":"D"},{"cabinClass":"B","bookingClass":"C"},{"cabinClass":"E","bookingClass":"Y"},{"cabinClass":"E","bookingClass":"M"},{"cabinClass":"E","bookingClass":"H"},{"cabinClass":"E","bookingClass":"L"},{"cabinClass":"E","bookingClass":"K"},{"cabinClass":"E","bookingClass":"B"}]},"gender":[{"key":"U","value":"Unknown"},{"key":"M","value":"Male"},{"key":"F","value":"Female"}]}]}
const LOGIN_SUCCESS_RESPONSE = {"success":true,"message":"Login Successful","errors":null,"details":{"cliams":{"sub":"IM0008010114","provider":null,"name":"Natsha","exp":1600318308,"userId":"IM0008010114","userDetails":{"membershipNumber":"IM0008010114","accountStatus":"A","preferredEmailAddress":"natJohn@gmail.com","membershipType":"I","preferredLanguage":"EN","tier":"100","tierFromDate":"03-Sep-2020","customerNumber":"6202"},"iat":1600231908,"email":"natJohn@gmail.com"}}}
const LOGIN_FAILURE_RESPONSE = {"success":false,"message":"Invalid Credentials","errors":null,"details":null}