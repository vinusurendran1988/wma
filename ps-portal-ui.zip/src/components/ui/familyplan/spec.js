import React from 'react';
import FamilyPlanCard from './index'
import {
    findComponent,
} from '../../common/testUtils';
import { testStore } from '../../common/utils';
import moxios from 'moxios';
import { mount } from 'enzyme';
import { SESSION_STORAGE_COMPANY_CODE, SESSION_STORAGE_PROGRAM_CODE, SESSION_STORAGE_MEMBERSHIP_NO } from '../../common/utils/Constants';
import { Provider } from 'react-redux';


var store = testStore({})
let rootComponent;
let component;
var t = jest.fn()

const setUp = (props = {}) => {
    window.sessionStorage.setItem(SESSION_STORAGE_COMPANY_CODE, 'IBS')
    window.sessionStorage.setItem(SESSION_STORAGE_PROGRAM_CODE, 'PRG14')
    localStorage.setItem(SESSION_STORAGE_MEMBERSHIP_NO, 'IM0008010415')
    rootComponent = mount(
        <Provider store={store} >
            <FamilyPlanCard {...props} />
        </Provider>
    );
    component = findComponent(rootComponent, 'FamilyPlanCard');
};


describe('FamilyPlanCard Component', () => {
    describe('Render without errors', () => {

        const config = {"fields":[{"name":"includeFamilyDetailLink","id":"includeFamilyDetailLink","grouping":"links","visibility":true},{"name":"pooledMiles","id":"pooledMiles","visibility":true,"data":{"pointTypes":["BASE","BONUS"]}},{"name":"notification","id":"notification","visibility":true,"category":"message","grouping":"notification","data":{"pointTypes":["BASE"],"threshold":-5000}}]}
        const defaultValues = { "defaultAbsoluteIndex": 1, "defaultPageSize": 10, "isBonusRequiredForAccoutnSummary": "Y" }
        const members = [{"membershipNumber":"IM0008010948","displayName":"Prithviraj Sukumaran","relationship":"Spouse","dateOfBirth":"22-Jul-1993","emailAddress":"ps-test-900@loyalty.com","nomineeStatus":"Active","tierCode":"BLU","tierName":"Blue","expiryDetails":[{"pointType":"BONUS","points":500,"expiryDate":"31-Aug-2023"},{"pointType":"BASE","points":11000,"expiryDate":"31-Aug-2023"},{"pointType":"BASE","points":1000,"expiryDate":"30-Sep-2023"}],"pointDetails":[{"pointType":"BASE","pointTypeGroup":"Total Miles","totalAccuredpoints":17000,"totalRedeemedpoints":5000,"pointsToNextTier":0,"pointsForTierRetention":0,"points":12000,"bonusDetails":[],"creditLimit":0},{"pointType":"BONUS","pointTypeGroup":"Total Miles","totalAccuredpoints":500,"totalRedeemedpoints":0,"pointsToNextTier":0,"pointsForTierRetention":0,"points":500,"bonusDetails":[],"creditLimit":0},{"pointType":"TIER","pointTypeGroup":"Qualifying Miles","totalAccuredpoints":0,"totalRedeemedpoints":0,"pointsToNextTier":0,"pointsForTierRetention":0,"points":0,"bonusDetails":[],"creditLimit":0},{"pointType":"TIERKE","pointTypeGroup":"Qualifying Miles","totalAccuredpoints":0,"totalRedeemedpoints":0,"pointsToNextTier":0,"pointsForTierRetention":0,"points":0,"bonusDetails":[],"creditLimit":0},{"pointType":"FS","pointTypeGroup":"Qualifying Segments","totalAccuredpoints":0,"totalRedeemedpoints":0,"pointsToNextTier":0,"pointsForTierRetention":0,"points":0,"bonusDetails":[],"creditLimit":0},{"pointType":"FC","pointTypeGroup":"Qualifying Segments","totalAccuredpoints":0,"totalRedeemedpoints":0,"pointsToNextTier":0,"pointsForTierRetention":0,"points":0,"bonusDetails":[],"creditLimit":0}],"activeNominee":true}]
        let props = { config, defaultValues, t, members }
        beforeEach(() => {
            moxios.install()
            setUp({ ...props })
        })

        afterEach(() => {
            moxios.uninstall()
        })

        test("Success", () => {
            rootComponent.update()
        })


    })
})