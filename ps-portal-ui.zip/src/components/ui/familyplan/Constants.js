export const FIELD_ID_NOTIFICATION = "notification"
export const FIELD_ID_POOLEDMILES = "pooledMiles"
export const CATEGORY_MESSAGE = "message"