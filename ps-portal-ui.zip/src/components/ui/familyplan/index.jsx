import React, { Component } from 'react';
import PropTypes from 'prop-types';
import {
    numberWithCommas,
    getExpiryText,
    toTitleCase,
    isEmptyOrSpaces
} from '../../common/utils'
import { NAVIGATE_FAMILY_POOLING } from '../../common/utils/urlConstants';
import {
    CATEGORY_MESSAGE,
    FIELD_ID_NOTIFICATION,
    FIELD_ID_POOLEDMILES
} from './Constants';

class FamilyPlanCard extends Component {

    constructor(props) {
        super(props);
    }

    getPoints(pointDetails) {
        const { config } = this.props
        let pointTypes = config.fields.find(object => {
            return object.id == FIELD_ID_POOLEDMILES
        }).data.pointTypes
        let totalPoints = 0
        pointDetails.forEach(p => {
            if(pointTypes.includes(p.pointType)){
                totalPoints += parseInt(p.points)
            }
        })
        return numberWithCommas(totalPoints)
    }
    
    render() {
        const { t, config } = this.props
        return (
            <div className="card mb-3 cardWrap cardWrap2" data-test="FamilyPlanCard">
                <div className="card-body">
                    <div className="d-flex justify-content-between">
                        <h5 className="card-title">{t('sidebar.family_card.family_plan')}</h5>
                        <a href={`#${NAVIGATE_FAMILY_POOLING}`} className="btn-link">{t('sidebar.family_card.family_details')}<i className="fa fa-angle-right" aria-hidden="true"></i></a>
                    </div>
                    <ul className="list-group list-group-flush">
                        {
                            this.props.members.map((member, idx)=> {
                                return (
                                    <li key={"list-"+idx} className="list-group-item">
                                        <div key={"list-div-"+idx} className="d-flex justify-content-between">
                                            <span  key={"list-div-span1"+idx}>{toTitleCase(member.displayName)}</span>
                                            <span key={"list-div-span2"+idx}>{this.getPoints(member.pointDetails)}</span>
                                        </div>
                                        {
                                            config.fields.map((field, index) => {
                                                if(field.category === CATEGORY_MESSAGE && field.visibility) {
                                                    return field.data.pointTypes.map(pointType => {
                                                       let baseExpiry = getExpiryText(member.expiryDetails, pointType, this.props.t('sidebar.family_card.expiry_message'), field.data.threshold?field.data.threshold:-1)
                                                       if(!isEmptyOrSpaces(baseExpiry))
                                                            return {
                                                                [FIELD_ID_NOTIFICATION]: <span key={"list-span"+index} key={"list-"+index} className="d-block text-left small text-danger">{baseExpiry}</span>
                                                            }[field.grouping]
                                                    })
                                                } 
                                            })
                                        }
                                    </li>
                                )
                            })
                        }
                    </ul>
                </div>
            </div>
        );
    }
}


FamilyPlanCard.propTypes = {
    members: PropTypes.array.isRequired
};

FamilyPlanCard.defaultProps = {
    members: []
};
export default FamilyPlanCard;