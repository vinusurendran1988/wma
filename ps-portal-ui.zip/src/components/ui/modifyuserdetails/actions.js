import { startButtonSpinner, stopButtonSpinner } from "../../common/components/fieldbank/loader/action";
import { _URL_CHANGE_EMAIL } from "../../common/config/config";
import { doPost } from "../../common/utils/api";
import { CHANGE_EMAIL } from "./Constants";

/**
 * Action call to change email
 * @param {JSON} payload Request payload to be dispatched
 * @author Amrutha J Raj
 */

export const changeEmail = (payload, id) => {
    return async dispatch => {
        dispatch(startButtonSpinner(id, CHANGE_EMAIL))
        dispatch({
            type: CHANGE_EMAIL,
            payload: {}
        })
        await doPost(_URL_CHANGE_EMAIL, payload)
            .then((response) => {
                dispatch({
                    type: CHANGE_EMAIL,
                    payload: response.data.object
                })
                dispatch(stopButtonSpinner(id, CHANGE_EMAIL))
            })
            .catch((error) => {
                dispatch({
                    type: CHANGE_EMAIL,
                    payload: error.response.data.error
                })
                dispatch(stopButtonSpinner(id, CHANGE_EMAIL))
            })

    };
}

