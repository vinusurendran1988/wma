import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import CustomMessage from '../../common/components/custommessage';
import Button from '../../common/components/fieldbank/Button';
import { fetchConfiguration, resetError, setError } from '../../common/middleware/redux/commonAction';
import { withSuspense } from '../../common/utils';
import { CONFIG_SECTION_MODIFY_USER_DETAILS } from '../../common/utils/Constants';
import { doAdditionalMapping, findValueFromObjectByPath } from '../../common/utils/object.utils';
import { isPatternMatch } from '../../common/utils/validation.utils';
import Section from '../updateprofile/Section';
import { changeEmail } from './actions';
import {
    BUSINESS, BUSINESS_PHONE, CANCEL_CHANGE_EMAIL_BUTTON, CHANGE_EMAIL_BUTTON,
    DANGER, HOME, HOME_MOBILE, HOME_PHONE, ID_SPINNER_CHANGE_EMAIL, SUCCESS, WHITE_SPACE
} from './Constants';

/**
 * Component to modify user details which is shown as a tab within the profile page
 * 
 * @author Amrutha J Raj
 */
class ModifyUserDetails extends Component {
    constructor(props) {
        super(props);
        this.state = {
            changeEmail: false,
            errorCodes: [],
            showWarningAndError: false,
            isButtonClicked: false,
            request: {},
            changeEmailRequest :{},
            apiResponse: {
                type: "",
                messages: [],
                canTranslate: false
            }
        }
        this.getPhoneNumberBasedOnPreferredComm = this.getPhoneNumberBasedOnPreferredComm.bind(this);
    }

    componentDidMount() {
        this.getMemberInfo()
        this.props.resetError()
        if (!this.props.config) {
            this.props.fetchConfiguration(CONFIG_SECTION_MODIFY_USER_DETAILS)
        }
        else {
            doAdditionalMapping(this, "changeEmailRequest")

        }
    }

    componentDidUpdate(prevProps) {
        if (JSON.stringify(prevProps.changeEmailResponse) !== JSON.stringify(this.props.changeEmailResponse) &&
            Object.keys(this.props.changeEmailResponse).length > 0) {
            const { t } = this.props
            const apiResponse = {}
            if (this.props.changeEmailResponse.status) {
                apiResponse["type"] = SUCCESS
                apiResponse["messages"] = [t('modify_user_details.changeEmailSuccessMessage')]
                apiResponse["canTranslate"] = true

            }
            else if (this.props.changeEmailResponse.errorDetails &&
                this.props.changeEmailResponse.errorDetails.length > 0) {
                apiResponse["type"] = DANGER
                apiResponse["messages"] = [t('modify_user_details.changeEmailFailureMessage').replace("{ERROR_RESPONSE}",
                    this.props.changeEmailResponse.errorDetails[0].message)]
                apiResponse["canTranslate"] = true
            }
            this.setState({
                apiResponse,
                changeEmail: false,
                changeEmailRequest: {},
                isButtonClicked: false,
                email: ""
            }, () => {
                doAdditionalMapping(this, "changeEmailRequest")
            })

        }

        if (JSON.stringify(this.props.config) != JSON.stringify(prevProps.config)) {
            doAdditionalMapping(this, "changeEmailRequest")

        }
    }
    
    /**
    * Get the member info from the profile data
    * 
    * @author Amrutha J Raj
    */
    getMemberInfo = () => {
        const { profileData } = this.props
        const individualInfo = profileData && profileData.object && profileData.object.memberAccount &&
            profileData.object.memberAccount.memberProfile && profileData.object.memberAccount.memberProfile.individualInfo

        const contactInfos = individualInfo.memberContactInfos && individualInfo.memberContactInfos.length > 0 &&
            individualInfo.memberContactInfos

        const emailObject = contactInfos.find(item => item.addressType == individualInfo.preferredEmailAddress)
        const currentEmail = emailObject && emailObject.emailAddress
        const contactInfo = (individualInfo.preferredPhoneNumber == HOME_PHONE || individualInfo.preferredPhoneNumber == HOME_MOBILE) ?
            contactInfos.find(item => item.addressType == HOME) : contactInfos.find(item => item.addressType == BUSINESS)

        const phone = contactInfo && this.getPhoneNumberBasedOnPreferredComm(contactInfo, individualInfo.preferredPhoneNumber)

        this.setState({
            displayName: individualInfo.displayName,
            phone, currentEmail
        })
    }

    /**
    * Get the phone number based on preferred communication
    * @param {contactInfo} String
    * @param {preferredPhone} String
    * 
    * @author Amrutha J Raj
    */
    getPhoneNumberBasedOnPreferredComm = (contactInfo, preferredPhone) => {
        if (preferredPhone == HOME_PHONE || preferredPhone == BUSINESS_PHONE) {
            return contactInfo && contactInfo.phoneISDCode + WHITE_SPACE + contactInfo.phoneNumber
        }
        else if (preferredPhone == HOME_MOBILE) {
            return contactInfo && contactInfo.mobileISDCode + WHITE_SPACE + contactInfo.mobileNumber
        }
    }

    /**
    * Handle request change for textfield from Section
    * @param {Object} request
    * @author Amrutha J Raj
    */
    handleRequestChange(request) {
        this.setState({
            changeEmailRequest,
            showWarningAndError: false
        })
    }

    /**
    * Handle validation error messages from Section
    * @param {Object} request
    * @author Amrutha J Raj
    */
    handleErrorMessagesFromSection(codes) {
        if (!codes.length) { this.props.resetError() }
        if (JSON.stringify(codes) != JSON.stringify(this.state.errorCodes)) {
            this.setState({ errorCodes: codes })
        }
    }

    /**
    * Set state from Section
    * @param {Object} field
    * @param {String} value
    * 
    * @author Amrutha J Raj
    */
    addValueToState(field, value) {
        let newState = {}
        newState[field.name] = value
        this.setState(newState)
    }

    /**
    * Method to handle validations from Section
    * @param {Object} field
    * @param {Object} validation
    * @param {String} value 
    *
    * @author Amrutha J Raj
    */
    validateWithStateVariable(field, validation, value) {
        let { pattern, fields } = validation
        let isValidationSuccess = true, canUpdateState = false
        fields.forEach((fd) => {
            const newPattern = pattern.replace("[fields]", this.state[fd])
            if (!isPatternMatch(newPattern, value)) {
                isValidationSuccess = false
            }
        })
        let { errorCodes } = this.state
        if (!isValidationSuccess) {
            if (!errorCodes.includes(validation.customMessageId)) {
                errorCodes.push(validation.customMessageId)
                canUpdateState = true
            }
        } else if (errorCodes.includes(validation.customMessageId)) {
            const index = errorCodes.indexOf(validation.customMessageId)
            if (index > -1) {
                canUpdateState = true
                errorCodes.splice(index, 1)
            }
        }
        field.error = !isValidationSuccess
        if (canUpdateState) {
            this.setState({
                errorCodes
            })
        }
        return !isValidationSuccess
    }

    /**
    * Method to find value from state
    * @param {Object} stateFieldName
    * 
    * @author Amrutha J Raj
    */
    findValueFromState(stateFieldName) {
        return this.state[stateFieldName] ? this.state[stateFieldName] : ""
    }

    /**
    * Method to change email on button click
    * 
    * 
    * @author Amrutha J Raj
    */
    changeEmail = () => {
        this.props.resetError();
        this.setState({
            showWarningAndError: true, apiResponse: {
                type: "",
                messages: [],
                canTranslate: false
            }, isButtonClicked: true
        }, () => {
            const { errorCodes, changeEmailRequest } = this.state;
            if (errorCodes.length > 0) {
                this.props.setError(errorCodes);
            } else {
                this.props.changeEmail(changeEmailRequest, ID_SPINNER_CHANGE_EMAIL)
            }
        })

    }

    /**
    * Method to reset form data
    * 
    * 
    * @author Amrutha J Raj
    */
    resetFormData() {
        this.props.resetError()
        this.setState({
            isButtonClicked: false,
            changeEmail: false,
            changeEmailRequest: {},
            email: "",
            showWarningAndError: false
        }, () => {
            doAdditionalMapping(this, "changeEmailRequest")

        })
    }

    render() {
        const { t, errors, config } = this.props;
        const { errorCodes, showWarningAndError, phone, currentEmail, displayName, apiResponse } = this.state
        const section = config && config.ui && config.ui.layout && config.ui.layout.elements &&
            config.ui.layout.elements.email

        return (
            <div className="profile-modify">
                {apiResponse && apiResponse.type && apiResponse.type.length > 0 && <CustomMessage type={apiResponse.type}
                    message={apiResponse.messages}
                    data-test="customMessageSuccess" canTranslate={apiResponse.canTranslate} />}

                {showWarningAndError && <CustomMessage type="danger"
                    message={errorCodes.length > 0 ? errorCodes : errors}
                    data-test="customMessageComponent" canTranslate={errorCodes.length > 0} />}

                {!this.state.changeEmail && <>
                    <h2>{t('modify_user_details.title')}</h2>
                    <ul className="profile-modify__info">
                        <li>
                            <span className="text">{t('modify_user_details.name')}</span>
                            <strong className="type">{displayName}</strong>
                            <a href="" className="link">{t('modify_user_details.change')}</a>
                        </li>
                        <li>
                            <span className="text">{t('modify_user_details.email.label')}</span>
                            <strong className="type">{currentEmail}</strong>
                            <a role="button" onClick={() => this.setState({
                                changeEmail: true,
                                apiResponse: {}
                            })} className="link">{t('modify_user_details.change')}</a>
                        </li>
                        <li>
                            <span className="text">{t('modify_user_details.mobile')}</span>
                            <strong className="type">{phone}</strong>
                            <a href="" className="link">{t('modify_user_details.change')}</a>
                        </li>

                    </ul>
                </>}

                <div className={`password password--change ${!this.state.changeEmail ? "d-none" : ""}`}>
                    <h1>{t('modify_user_details.changeEmailTitle')}</h1>
                    <form>
                        {section && <Section
                            key={"modify-user-details"}
                            page={"modify_user_details"}
                            id={"modify-user-details"}
                            displayElements={section}
                            request={this.state.changeEmailRequest}
                            onRequestChange={(req) => this.handleRequestChange(req)}
                            dynamicAttributes={""}
                            errorCodes={errorCodes}
                            showWarningAndError={this.state.showWarningAndError}
                            onErrorCodes={(codes) => this.handleErrorMessagesFromSection(codes)}
                            isButtonClicked={this.state.isButtonClicked}
                            addValueToState={(field, value) => this.addValueToState(field, value)}
                            validateWithStateVariable={(field, validation, value) => this.validateWithStateVariable(field, validation, value)}
                            findValueFromState={(stateFieldName, fieldType) => this.findValueFromState(stateFieldName, fieldType)}
                        />}
                        <div className="btn-wrap">
                            <Button
                                handleOnClick={() => this.changeEmail()}
                                label={t("modify_user_details.continueBtn")}
                                className="btn btn-primary btn-lg" />
                            <Button
                                className="btn btn-secondary"
                                handleOnClick={() => this.resetFormData()}
                                id={CANCEL_CHANGE_EMAIL_BUTTON}
                                data-test={CHANGE_EMAIL_BUTTON}
                                label={t("modify_user_details.cancelBtn")} />
                        </div>
                    </form>
                </div>
            </div>
        );
    }
}

const mapStateToProps = state => {
    return {
        // profileData: state.profile.profileData,
        profileData: state.profileDataReducer.profileData,
        config: state.configurationReducer[CONFIG_SECTION_MODIFY_USER_DETAILS],
        errors: findValueFromObjectByPath(state, 'commonErrorReducer.error', []),
        changeEmailResponse: state.changeEmailReducer? state.changeEmailReducer.changeEmail : [],
    }
}

const mapDispatchToProps = {

    fetchConfiguration,
    changeEmail,
    setError,
    resetError
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(ModifyUserDetails)));
