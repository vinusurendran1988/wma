import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import { withRouter } from "react-router";
import { withSuspense } from '../../common/utils';
import {
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    getItemFromBrowserStorage
} from '../../common/utils/storage.utils';
import Loader from '../../common/components/fieldbank/loader/Loader';
import { getPartnersBenefitsContent } from './actions'
import parse from 'html-react-parser'
import {
    CONFIG_SECTION_DEFAULT
} from '../../common/utils/Constants';
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';

class PromotionDetails extends Component {
    constructor(props) {
        super(props)
        this.state = {
            request: {}
        }
    }

    /**
     * The componentDidMount() method is called after the component is rendered
     * Method to get Recommended Benefits is called here
     */
    componentDidMount() {
        this.fetchPartnersBenefits();
        this.props.setPageInfo(this.props)
    }

    fetchPartnersBenefits() {
        if (Object.keys(this.state.request).length == 0 && this.props.defaultConfig) {
            const { defaultConfig } = this.props;
            const currentProgram = getCurrentProgramFromDefaultConfig(defaultConfig)
            let queryData = {};
            if (currentProgram &&
                currentProgram.data &&
                currentProgram.data.cmsDetails &&
                currentProgram.data.cmsDetails.viewDetailPartner) {
                queryData = currentProgram.data.cmsDetails.viewDetailPartner;
                /**
                 * Checking queryData and resource, also the tier name for the logged user
                 * Appending the tier name with the resource['tier'] in partners
                 */
                if (queryData.filter && this.props.match.params.id) {
                    queryData.filter['id'] = this.props.match.params.id
                }
            }
            const request = {
                object: {
                    companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                    programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                    membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                    ...queryData
                }
            }
            this.setState({
                request
            }, () => {
                this.props.getPartnersBenefitsContent(request)
            })
        }else{
            this.props.getPartnersBenefitsContent(request)
        }
    }

    getHTMLContent(htmlcontent) {
        let responseHtml = {};
        if (htmlcontent &&
            htmlcontent.data &&
            htmlcontent.data[0] &&
            htmlcontent.data[0].content &&
            htmlcontent.data[0].content.value) {
            responseHtml = htmlcontent.data[0].content.value
        }
        return responseHtml
    }

    render() {
        const { partnersBenefitsContent } = this.props
        let htmlcontent = {}
        htmlcontent = this.getHTMLContent(partnersBenefitsContent);

        return (
            Object.keys(htmlcontent).length > 0 ?
                <div className="col-lg-9 col-md-8 rightSidePanel">
                    <div className="enrollmentForm">
                        {
                            parse(htmlcontent)
                        }
                    </div> </div> : <div><Loader /></div>
        )
    }
}

const mapStateToProps = state => {
    return {
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        partnersBenefitsContent: state.partnersBenefitsReducer.partnersbenefitscontent
    }
}
const mapDispatchToProps = {
    getPartnersBenefitsContent
}
export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(withRouter(PromotionDetails))))