import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import { withSuspense } from '../../common/utils';
import { fetchAccountSummary } from '../../common/middleware/redux/commonAction'
import {
    CONFIG_SECTION_DEFAULT,
    CONFIG_SECTION_ACCOUNT_SUMMARY
} from '../../common/utils/Constants';
import {
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    getItemFromBrowserStorage
} from '../../common/utils/storage.utils';
import { NAVIGATE_PARTNERS } from '../../common/utils/urlConstants';
import ApiLoader from '../../common/components/fieldbank/loader/ApiLoader';
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';
import { fetchRecommededPartnersDetails } from '../dashboard/actions';
import { getTierByCode } from '../../common/utils/tier.utils';

class PartnersList extends Component {
    constructor(props) {
        super(props)
        this.state = {
            request: {}
        }
    }

    componentDidMount() {
        this.props.setPageInfo(this.props)
        if (!this.props.accountSummary) {
            const accountSummaryRequest = {
                object: {
                    companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                    programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                    membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                    isBonusRequired: "Y",
                    tierOptionsRequired: true
                }
            }
            this.props.fetchAccountSummary(accountSummaryRequest)
        }
        if (!this.props.recommendedPartnersData) {
            this.getRecommendedPartners();
        }
    }

    getRecommendedPartners() {
        let currentTier = '';
        if (this.props.accountSummary && this.props.accountSummaryConfig) {
            currentTier = getTierByCode(this.props.accountSummary.tierCode, this.props.accountSummaryConfig.tiers);
        }

        if (Object.keys(this.state.request).length == 0 && this.props.defaultConfig) {
            const { defaultConfig } = this.props;
            const currentProgram = getCurrentProgramFromDefaultConfig(defaultConfig)
            let queryData = {};
            if (currentProgram &&
                currentProgram.data &&
                currentProgram.data.cmsDetails &&
                currentProgram.data.cmsDetails.partners) {
                queryData = currentProgram.data.cmsDetails.partners;
                /**
                 * Checking queryData and resource, also the tier name for the logged user
                 * Appending the tier name with the resource['tier'] in partners
                 */
                if (queryData.resource && queryData.resource.tier && currentTier && currentTier.name) {
                    queryData.resource['tier'] = queryData.resource.tier + "_" + currentTier.name.toLocaleLowerCase()
                }
            }
            const request = {
                object: {
                    companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                    programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                    membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                    ...queryData
                }
            }
            this.setState({
                request
            }, () => {
                this.props.fetchRecommededPartnersDetails(this.state.request)
            })
        }
    }

    render() {
        const { t, recommendedPartnersData } = this.props

        if (recommendedPartnersData == undefined) {
            return <div><ApiLoader /></div>
        } else if (recommendedPartnersData && recommendedPartnersData.data) {
            return (
                <div className="col-lg-9 col-md-8 rightSidePanel">
                    <div className="enrollmentForm">
                        <div className="row promo">
                            {
                                recommendedPartnersData.data.map((item) => {
                                    return <div className="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                        <div className="card-group">
                                            <div className="card">
                                                {
                                                    item.metaData && item.metaData.contentLinkID ?
                                                        <a href={`#${NAVIGATE_PARTNERS}/` + item.metaData.contentLinkID} target="_blank" >
                                                            <img src={item.url} className="d-block" alt="attractions" />
                                                        </a> : <img src={item.url} className="d-block" alt="attractions" />
                                                }
                                                <div className="txtWraper">
                                                    <div className="txtHeading text-center">
                                                        {item.content.value}
                                                    </div></div>
                                            </div>

                                        </div>
                                    </div>
                                })
                            }</div></div></div>
            )
        } else {
            return <div className="text-center">{t(('dashboard.noPartners'))}</div>
        }
    }
}

const mapStateToProps = state => {
    return {
        accountSummary: state.accountSummaryReducer.accountSummary,
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        accountSummaryConfig: state.configurationReducer[CONFIG_SECTION_ACCOUNT_SUMMARY],
        recommendedPartnersData: state.offersPartnersReducer.recommendedPartners
    }
}
const mapDispatchToProps = {
    fetchAccountSummary,
    fetchRecommededPartnersDetails
}
export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(PartnersList)))