import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { withSuspense } from '../../common/utils';
import { connect } from 'react-redux';
import { CONFIG_SECTION_SUMMARY } from '../../common/utils/Constants';
import { LAYOUT_ORDER_USEFULLINKS } from './Constants';

class PortalFooter extends Component {
    render() {
        const { t } = this.props
        let selectedID = localStorage.getItem("membershipNumber") ? localStorage.getItem("membershipNumber") : "0008010647";
        const onchange = (e) => {
            if (e.target.value != "") {
                if(e.target.value.split('/').length == 2 && e.target.value.split('/')[0] == 'admin') {
                    localStorage.setItem("corpEmployeeDetails", JSON.stringify({
                        "membershipNumber": "69",
                        "fname": "Adam",
                        "lname": "John",
                        "email": "adamjohn@ibsplc.com",
                        "address": {
                            "addressLine1": "46 Cron Street",
                            "addressLine2": "Franz Josef",
                            "streetNumber": "",
                            "district": "",
                            "city": "Waiau",
                            "zip": "7856",
                            "state": "",
                            "country": "New Zealand"
                        }
                    }));
                    e.target.value = e.target.value.split('/')[1];
                    localStorage.setItem("membershipNumber", e.target.value);
                } else {
                    localStorage.setItem("membershipNumber", e.target.value);
                    localStorage.removeItem("corpEmployeeDetails");
                }
                localStorage.removeItem("overView");
                window.location.reload();
            }
        }

        return (
            <footer class="footer footer--compact">
                <div class="footer__main">
                    <div class="container">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-12 order-md-1 order-2">
                            <div class="footerLinks"> 
                                <a target='_blank' href="https://www.airnewzealand.co.nz/help-and-contact" class="d-block">Help & contact</a>
                                <a target='_blank' href="https://www.airnewzealand.co.nz/about-air-new-zealand" class="d-block">About Air New Zealand</a> 
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col1sm-12 order-md-2 order-3">
                            <div class="footerLinks"> 
                                <a target='_blank' href="https://www.airnewzealand.co.nz/airpoints-help" class="d-block">Airpoints Help</a> 
                                <a target='_blank' href="https://www.airnewzealand.co.nz/airpoints-terms-and-conditions" class="d-block">Airpoints terms and conditions</a> 
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col3sm-12 order-md-3 order-1">
                            <div class="footer__logo"><img src="images/footerlogo.svg" /></div>
                        </div>
                    </div>
                    
                    </div>
                </div>
                <div class="footer__copy">
                    <div class="container">
                        {/* <input class="tempSelect" type="text" onBlur={onchange} /> */}
                    <div class="footer3">Copyright © 2021 Air New Zealand Limited </div>
                    <div class="terms"><img src="images/footerAlliancelogo.svg" /></div>
                    </div>
                </div>
            </footer>
        );
    }
}

const mapStateToProps = state => {
    return {
        config: state.configurationReducer[CONFIG_SECTION_SUMMARY] ? state.configurationReducer[CONFIG_SECTION_SUMMARY].ui.layout.elements[LAYOUT_ORDER_USEFULLINKS] : {}
    }
}

const mapDispatchToProps = {}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(PortalFooter)));
