
import { doPost } from '../../common/utils/api'
import {
    _URL_UPDATE_CUSTOMER_PROFILE
} from '../../common/config/config'
import { getApiErrorMessage } from '../../common/utils'

// Action Type
export const SET_PROFILE_DATA = "SET_PROFILE_DATA";
export const SET_PROFILE_PICTURE = "SET_PROFILE_PICTURE";
export const ERROR_PROFILE_FETCH = "ERROR_PROFILE_FETCH";
export const SET_PROFILE_CONFIG = "SET_PROFILE_CONFIG";
export const SET_UPDATED_CUSTOMER_DATA = "SET_UPDATED_CUSTOMER_DATA";

import { 
    ERROR, fetchCustomerProfileData
} from '../../common/middleware/redux/commonAction';
import {
    stopButtonSpinner,
    startButtonSpinner
} from '../../common/components/fieldbank/loader/action';

/**
 * Method to invoke the update customer profile api
 * @author Somdas M
 */
export const updateProfileDetails = (profileData, id) => {
    return dispatch => {
        dispatch(startButtonSpinner(id, "updateProfileDetails"))
        return doPost(_URL_UPDATE_CUSTOMER_PROFILE, profileData)
            .then(response => {
                dispatch(stopButtonSpinner(id, "updateProfileDetails"))
                 dispatch(fetchCustomerProfileData())
                dispatch({
                    type: ERROR,
                    payload: { error: ['customerProfile.successMessage'] }
                })
            }).catch(error => {
                dispatch(stopButtonSpinner(id, "updateProfileDetails"))
                dispatch({
                    type: ERROR,
                    payload: { error: getApiErrorMessage(error.response.data.error) }
                })
            })
    }
}