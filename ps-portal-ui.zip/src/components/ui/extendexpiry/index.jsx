import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import CustomMessage from '../../common/components/custommessage';
import {
    fetchConfiguration
} from '../../common/middleware/redux/commonAction';
import { getCurrentDate, getRelativeDate, withSuspense } from '../../common/utils';
import { CONFIG_SECTION_RENEWPOINT, DD_MMM_YYYY, DD_MM_YYYY } from '../../common/utils/Constants';
import { BROWSER_STORAGE_KEY_ACTIVITY_CODE, BROWSER_STORAGE_KEY_COMPANY_CODE, BROWSER_STORAGE_KEY_MEMBERSHIP_NO, BROWSER_STORAGE_KEY_PROGRAM_CODE, getItemFromBrowserStorage, removeItemFromBrowserStorage, setItemToBrowserStorage } from '../../common/utils/storage.utils';
import { retrieveRenewOrExpiryPointDetails } from './actions';
import {
    PAYMENT_EQ_SUCCESS,
    PAYMENT_EQ_CANCELLED,
    PAYMENT_EQ_FAILED,
    TAB_EXPIRED,
    TAB_EXPIRING_SOON
} from './Constants';
import ExtendRenewTable from './ExtendRenewTable';
import { NAVIGATE_MEMBER_EXTEND_EXPIRY } from '../../common/utils/urlConstants';


/**
 * Component to extend expiry date of Expiring Soon miles and renew miles of Expired Miles
 * @author Amrutha J Raj
 */
class ExtendExpiry extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedTab: TAB_EXPIRING_SOON,
            paymentCompleted: false,
            paymentMessage: ""
        }
        this.changeTab = this.changeTab.bind(this)
        this.handleModalOpen = this.handleModalOpen.bind(this);
    }

    componentDidMount() {
        const { config } = this.props
        this.props.setPageInfo(this.props, { config, confSection: CONFIG_SECTION_RENEWPOINT })
        if (this.props.config) {
            this.fetchRenewOrExpiryPointDetails()
        }
    }

    componentDidUpdate(prevProps, prevState) {
        let newState = {}
        if (prevProps.config !== this.props.config) {
            this.initializePage()
        }
        if (prevState.selectedTab !== this.state.selectedTab) {
            this.fetchRenewOrExpiryPointDetails()
        }
        if (JSON.stringify(prevProps.renewMilesResponse) != this.props.renewMilesResponse) {
            const { renewMilesResponse } = this.props
            if (renewMilesResponse && renewMilesResponse.memberActivityStatus &&
                renewMilesResponse.memberActivityStatus.activityNumber) {
                setItemToBrowserStorage(BROWSER_STORAGE_KEY_ACTIVITY_CODE, renewMilesResponse.memberActivityStatus.activityNumber)
            }
        }
        if (prevState.paymentCompleted != this.state.paymentCompleted && this.state.paymentCompleted) {
            removeItemFromBrowserStorage(BROWSER_STORAGE_KEY_ACTIVITY_CODE)
            window.history.pushState({}, null, `#${NAVIGATE_MEMBER_EXTEND_EXPIRY}`)
            newState["acceptPaymentInvoked"] = true

        }
        if (window.location.href.includes(PAYMENT_EQ_SUCCESS) && !this.state.acceptPaymentInvoked &&
            getItemFromBrowserStorage(BROWSER_STORAGE_KEY_ACTIVITY_CODE)) {
            newState["paymentMessage"] = this.props.t('extend_expiry.payment_success_message').
                replace("{TRANS_ID}", window.location.href.split("tid=")[1])
            newState["paymentStatus"] = "success"
            newState["paymentCompleted"] = true

        }
        else if (window.location.href.includes(PAYMENT_EQ_CANCELLED) && !this.state.acceptPaymentInvoked &&
            getItemFromBrowserStorage(BROWSER_STORAGE_KEY_ACTIVITY_CODE)) {
            newState["paymentCompleted"] = true
            newState["paymentStatus"] = "warning"
            newState["paymentMessage"] = this.props.t('extend_expiry.payment_cancelled')
        }
        else if (window.location.href.includes(PAYMENT_EQ_FAILED) && !this.state.acceptPaymentInvoked &&
            getItemFromBrowserStorage(BROWSER_STORAGE_KEY_ACTIVITY_CODE)) {
            newState["paymentCompleted"] = true
            newState["paymentStatus"] = "danger"
            newState["paymentMessage"] = this.props.t('extend_expiry.payment_failed').
                replace("{TRANS_ID}", window.location.href.split("tid=")[1])
        }
        if (Object.keys(newState).length > 0) this.setState(newState)
    }

    /**
       * Initialize the page
       * 
       * @author Amrutha J Raj
       */
    initializePage() {
        const { config } = this.props
        if (
            config.ui &&
            config.ui.layout && config.ui.layout.elements && config.ui.layout.elements.tabs &&
            config.ui.layout.elements.tabs.length
        ) {
            const value = config.ui.layout.elements.tabs[0]
            this.setState({
                selectedTab: value
            })
        }
    }

    /**
         * Handles the tab change
         * @param {Event} event 
         * @author Amrutha J Raj
         */
    changeTab(tab) {
        this.setState({
            selectedTab: tab,
            dropdownDisplay: "none",
            acceptPaymentInvoked: false,
            paymentCompleted: false
        })
    }

    /**
         * Get the durationInDays from the config
         * @param {Event} type
         * @author Amrutha J Raj
         */
    getDurationInDays = (type) => {
        const { config } = this.props
        const actionType = config && config.actionTypes && config.actionTypes.find(item => item.key === type)
        return actionType && actionType.durationInDays
    }

    /**
         * Get the renewPointActionType from the config
         * @param {Event} type
         * @author Amrutha J Raj
         */
    getRenewPointActionType = (type) => {
        const { config } = this.props
        const actionType = config && config.actionTypes && config.actionTypes.find(item => item.key === type)
        return actionType && actionType.renewPointActionType
    }

    /**
     * Fetch renew/expiring point details
     *
     * @param {string} 
     * @param {string} 
     * 
     * @author Amrutha J Raj
     */
    fetchRenewOrExpiryPointDetails = () => {
        const requestPayload = {
            "object": {
                "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                "membershipNumber": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                "renewPointActionType": this.getRenewPointActionType(this.state.selectedTab),
                "applicableDate": this.state.selectedTab == TAB_EXPIRED ?
                    this.getApplicableDate(-1 * this.getDurationInDays(this.state.selectedTab)) :
                    this.getApplicableDate(this.getDurationInDays(this.state.selectedTab))
            }
        }
        this.props.retrieveRenewOrExpiryPointDetails(requestPayload)
    }

    /**
     * Fetch renew/expiring point details
     *
     * @param {string} 
     * @param {string} 
     * 
     * @author Amrutha J Raj
     */

    getApplicableDate = (offsetDays) => {
        return getRelativeDate(getCurrentDate(), offsetDays, DD_MMM_YYYY, DD_MM_YYYY);

    }
    /**
         * Handle extend/renew modal open
         *
         * @param {string} 
         * @param {string} 
         * 
         * @author Amrutha J Raj
         */
    handleModalOpen = () => {
        this.setState({
            acceptPaymentInvoked: false,
            paymentCompleted: false
        })
    }

    render() {
        const { t, config, extendOrRenewPointDetails } = this.props
        const {
            selectedTab
        } = this.state;

        const tabs = config && config.ui && config.ui.layout && config.ui.layout.elements && config.ui.layout.elements.tabs
        const expiringSoonTable = config && config.ui && config.ui.layout && config.ui.layout.elements &&
            config.ui.layout.elements.expiringSoon.table && config.ui.layout.elements.expiringSoon.table.columns

        const expiredTable = config && config.ui && config.ui.layout && config.ui.layout.elements &&
            config.ui.layout.elements.expired && config.ui.layout.elements.expired.table && config.ui.layout.elements.expired.table.columns

        return (
            <div>
                <div className="title title--page">
                    <h2>{t('extend_expiry.title')}</h2>
                </div>
                <div className="description">
                    <p>{t('extend_expiry.descriptionOne')} <br />{t('extend_expiry.descriptionTwo')}</p>
                    {
                        this.state.paymentCompleted &&
                        <CustomMessage message={[this.state.paymentMessage]} type={this.state.paymentStatus} canTranslate={false} />
                    }

                </div>
                <nav data-test="navigation" className="tab">
                    <div id='countries' className="tab__mob">
                        <i className="fa fa-caret-down" aria-hidden="true"></i>
                        <dl>
                            <dt>
                                <a data-test="default-tab" onClick={() => this.setState({ dropdownDisplay: "block" })}><span>{t(`extend_expiry.${selectedTab}`)}</span></a>
                            </dt>
                            <dd>
                                <ul data-test="tab-list" style={{ display: this.state.dropdownDisplay }}>
                                    {tabs && tabs.map((tab, index) => {
                                        return (<li key={index}><a data-test={`tab-Mob-${index}`} onClick={() => this.changeTab(tab)}>{t(`extend_expiry.${tab}`)}</a></li>)
                                    })}
                                </ul>
                            </dd>
                        </dl>
                    </div>

                    <div className="nav nav-tabs nav-tabs--booking" id="nav-tab" role="tablist">
                        {tabs && tabs.map((tab, index) => {
                            return (
                                <a className={"nav-item nav-link " + (selectedTab === tab ? "active" : "")}
                                    key={index}
                                    data-test={`tab-btn-${index}`}
                                    id="nav-home-tab"
                                    onClick={() => this.changeTab(tab)}
                                    data-toggle="tab" href={`${tab}`} role="tab" aria-controls="nav-1" aria-selected="true">
                                    <span>{t(`extend_expiry.${tab}`)}</span>
                                </a>
                            )
                        })}
                    </div>
                </nav>

                <div className="tab-content" id="nav-tabContent">
                    <div className="tab-pane fade show active" id="nav-1" role="tabpanel" aria-labelledby="nav-home-tab">
                        {/* <!--table starts here--> */}
                        {this.props.config && <ExtendRenewTable modalOpen={this.handleModalOpen} field={{
                            values: extendOrRenewPointDetails && extendOrRenewPointDetails.renewablePointBlockDetails,
                            columns: this.state.selectedTab == TAB_EXPIRING_SOON ? expiringSoonTable : expiredTable
                        }}
                            config={this.props.config}
                            selectedTab={this.state.selectedTab}
                            className={"table"} />
                        }
                        {/* <!--table ends here--> */}
                    </div>
                </div>
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        config: state.configurationReducer[CONFIG_SECTION_RENEWPOINT],
        extendOrRenewPointDetails: state.extendExpiryReducer.retrievedRenewOrExpiryDetails,
        renewMilesResponse: state.renewMilesPaymentReducer.renewMilesResponse

    }
}
const mapDispatchToProps = {

    fetchConfiguration,
    retrieveRenewOrExpiryPointDetails
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(ExtendExpiry)));
