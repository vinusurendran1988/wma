import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import FieldBank from '../../common/components/fieldbank';
import { FIELDTYPE_TABLE } from '../../common/components/fieldbank/Constants';
import {
    numberWithCommas,
    withSuspense
} from '../../common/utils';
import { TAB_EXPIRING_SOON } from './Constants';
import ExtendRenewModal from './ExtendRenewModal';


/**
 * Table to display miles that are expiring soon and expired
 * @author Amrutha
 */
class ExtendRenewTable extends Component {
    constructor(props) {
        super(props);
        this.state = {
            pointBlockObject: null,
            showModal: false
        }
        this.pointsBodyTemplate = this.pointsBodyTemplate.bind(this)
        this.actionBodyTemplate = this.actionBodyTemplate.bind(this)
    }


    /**
     * Column template for showing the miles
     * @param {rowData} Extend or Renew Table row
     * @param {props} props
     * @author Amrutha J Raj
     * 
     */
    pointsBodyTemplate(rowData, props) {
        const point = rowData && rowData.points
        return (
            <React.Fragment>
                <span className="p-column-title">{props.header}</span>
                {numberWithCommas(parseInt(point))}
            </React.Fragment>
        );

    }

    /**
      * Handle click for extend or renew button
      * @param {pointBlock}  Point block whose miles are to be extended or renewed
      * 
      * @author Amrutha J Raj
      * 
      */
    handleClick = (pointBlock) => {
        this.setState({ pointBlockObject: pointBlock, showModal: true })
        this.props.modalOpen()
    }

    /**
     * Column template for actions extend and renewal
     * @param {rowData} Extend or Renew Table row
     * 
     * @author Amrutha J Raj
     */
    actionBodyTemplate(rowData) {
        const tab = this.props && this.props.selectedTab
        const { t } = this.props
        return <React.Fragment>
            <button data-test="btnOpenModal" className="btn btn-primary btn-sm" data-toggle="modal" data-target="#ExtendRenewModal"
                onClick={() => this.handleClick(rowData)}>
                {tab == TAB_EXPIRING_SOON ? t('extend_expiry.extend_expiry') : t('extend_expiry.renew_miles')}</button>
        </React.Fragment>
    }

    render() {
        const { field, className, t, globalFilter, } = this.props;
        return (
            <>
                <FieldBank
                    field={{
                        fieldType: FIELDTYPE_TABLE,
                        globalFilter: globalFilter,
                        emptyMessage: t('extend_expiry.no_results_found'),
                        bodyTemplates: {
                            pointsBodyTemplate: this.pointsBodyTemplate,
                            actionBodyTemplate: this.actionBodyTemplate
                        },
                        ...field
                    }}
                    className={className}
                />
                {this.props.config && <ExtendRenewModal data-test="modal-extend-renew" id="ExtendRenewModal" showModal={this.state.showModal} pointBlock={this.state.pointBlockObject} 
                    selectedTab={this.props.selectedTab} />
                }
            </>);
    }

}

export default withSuspense()(withTranslation()(ExtendRenewTable));