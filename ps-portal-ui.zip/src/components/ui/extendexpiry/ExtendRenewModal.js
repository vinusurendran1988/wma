import parse from 'html-react-parser';
import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import Button from '../../common/components/fieldbank/Button';
import { _IMAGE_BASEURL, _URL_PAYMENT_EXTEND_RENEW_CANCELLED, _URL_PAYMENT_EXTEND_RENEW_FAILED, _URL_PAYMENT_EXTEND_RENEW_REDIRECT, _URL_PAYMENT_EXTEND_RENEW_SUCCESS } from '../../common/config/config';
import { fetchMasterData } from '../../common/middleware/redux/commonAction';
import { getRelativeDate, withSuspense } from '../../common/utils';
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';
import { CONFIG_SECTION_DEFAULT, DD_MMM_YYYY, RESET_POINT } from '../../common/utils/Constants';
import { findValueFromObjectByPath } from '../../common/utils/object.utils';
import { BROWSER_STORAGE_KEY_COMPANY_CODE, BROWSER_STORAGE_KEY_CURRENCY_CODE, BROWSER_STORAGE_KEY_MEMBERSHIP_NO, BROWSER_STORAGE_KEY_PROGRAM_CODE, getItemFromBrowserStorage } from '../../common/utils/storage.utils';
import { isPatternMatch } from '../../common/utils/validation.utils';
import { fetchRetrieveQuote, renewPointPayment } from './actions';
import { EMPTY_STRING, ID_SPINNER_PROCEED_TO_PAY, ONE_ITEM, TAB_EXPIRING_SOON } from './Constants';
class ExtendRenewModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      noOfMiles: undefined,
      isError: false,
      agreeTerms: false,
      proceedToPay: false,
      onPointFieldChange: false,
      amount: this.getRoundOffAmount()
    }
    this.handleAgreeTermsChanged = this.handleAgreeTermsChanged.bind(this)
  }

  componentDidMount() {
    const { masterEntityLookup, masterEntityLookupFilters } = this.props
    this.setState({ isError: false })

    if (!this.props.resetPoint || this.props.resetPoint.length == 0) {
      this.props.fetchMasterData(RESET_POINT, masterEntityLookup, masterEntityLookupFilters)
    }

  }

  componentDidUpdate(prevProps, prevState) {
    if ((JSON.stringify(prevProps.pointBlock) != JSON.stringify(this.props.pointBlock)) && this.props.showModal) {
      if ((this.props.pointBlock && (prevState.noOfMiles != this.props.pointBlock.points)) || this.state.noOfMiles == null) {
        this.setState({ noOfMiles: this.props.pointBlock && this.props.pointBlock.points })
      }
      this.props.pointBlock && this.fetchRetrieveQuote(this.props.pointBlock.points)
    }

    if (JSON.stringify(prevProps.renewMilesResponse) != JSON.stringify(this.props.renewMilesResponse)) {
      const redirectUrl = this.props.renewMilesResponse.redirectURL
      window.location.href = redirectUrl
    }

    if (this.props.retrieveQuoteResponse != prevProps.retrieveQuoteResponse && this.props.retrieveQuoteResponse.amount) {
      this.setState({
        amount: this.getRoundOffAmount(this.props.retrieveQuoteResponse.amount)
      })
    }


  }

getRoundOffAmount=(amount=0)=>{
  const roundOffDigit = this.props.configRenewPoint && this.props.configRenewPoint.ui && this.props.configRenewPoint.ui.roundOffDigit
  return parseFloat(amount).toFixed(roundOffDigit).toString()
}

  /**
  * Fetch retrieve quote API
  * @param {point} Points to be renewed
  * 
  * @author Amrutha J Raj
  */
  fetchRetrieveQuote = (point = this.state.noOfMiles) => {
    const requestPayload = {
      "object": {
        "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
        "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
        "partyType": this.props.configRenewPoint && this.props.configRenewPoint.ui && this.props.configRenewPoint.ui.partyType,
        "membershipNumber": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
        "activityCode": this.props.configRenewPoint && this.props.configRenewPoint.activityCode,
        "dynamicAttributes": [
          {
            "attributeCode": this.props.configRenewPoint && this.props.configRenewPoint.ui && this.props.configRenewPoint.ui.memNo,
            "attributeValue": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
            "attributeType": null
          },
          {
            "attributeCode": this.props.configRenewPoint && this.props.configRenewPoint.ui && this.props.configRenewPoint.ui.pointType,
            "attributeValue": this.props.pointBlock && this.props.pointBlock.pointType,
            "attributeType": null
          },
          {
            "attributeCode": this.props.configRenewPoint && this.props.configRenewPoint.ui && this.props.configRenewPoint.ui.points,
            "attributeValue": point,
            "attributeType": this.props.pointBlock && this.props.pointBlock.pointType,
          }
        ]
      }
    }
    this.props.fetchRetrieveQuote(requestPayload)
  }

  /**
  * Generate the request object for the renew miles payment API
  * @param {string} 
  * @param {string} 
  * 
  * @author Amrutha J Raj
  */
  generateRenewMilesRequest(retrieveQuoteResponse) {
    const { selectedTab, configRenewPoint, pointBlock, extendOrRenewPointDetails } = this.props
    const actionType = configRenewPoint && configRenewPoint.actionTypes &&
      configRenewPoint.actionTypes.find(actionType => actionType.key == selectedTab)
    const isPaymentRequired = actionType && actionType.isPaymentRequired
    const extendDurationInDays = configRenewPoint && configRenewPoint.ui && configRenewPoint.ui.extendDurationInDays
    const orderInfo = configRenewPoint && configRenewPoint.ui && configRenewPoint.ui.orderInfo
    //creating request object for renew miles API
    const object = {
      companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
      programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
      membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
      accountStatus: extendOrRenewPointDetails && extendOrRenewPointDetails.accountStatus,
      renewPointActionType: actionType && actionType.renewPointActionType,
      totalPointsToBeRenewed: this.state.noOfMiles,
      renewedExpiryDate: EMPTY_STRING,
      quoteReferenceNumber: retrieveQuoteResponse && retrieveQuoteResponse.quoteReferenceNumber,
      transactionID: EMPTY_STRING,
      renewablePointBlockDetails: [{
        pointType: pointBlock && pointBlock.pointType,
        displayName: pointBlock && pointBlock.displayName,
        points: pointBlock && pointBlock.points,
        expiryDate: getRelativeDate(pointBlock.expiryDate, extendDurationInDays, DD_MMM_YYYY, DD_MMM_YYYY),
      }]
    }
    if (isPaymentRequired) {
      const paymentGateway = {}
      paymentGateway["cancel_url"] = _URL_PAYMENT_EXTEND_RENEW_CANCELLED
      paymentGateway["success_url"] = _URL_PAYMENT_EXTEND_RENEW_SUCCESS
      paymentGateway["failure_url"] = _URL_PAYMENT_EXTEND_RENEW_FAILED
      paymentGateway["redirect_url"] = _URL_PAYMENT_EXTEND_RENEW_REDIRECT
      paymentGateway["terms_and_conditions"] = configRenewPoint && configRenewPoint.termsAndConditions
      if (this.props.defaultConfig) {
        const defaultConfig = getCurrentProgramFromDefaultConfig(this.props.defaultConfig)
        paymentGateway["purchase_totals"] = {
          order_amount: retrieveQuoteResponse && retrieveQuoteResponse.amount,
          order_currency: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_CURRENCY_CODE)
        }
        paymentGateway["point_of_sale"] = {
          pos_city: defaultConfig.defaults.posCity,
          pos_country: defaultConfig.defaults.posCountry
        }
      }
      paymentGateway["order_details"] = {
        order_info: orderInfo,
        order_type: EMPTY_STRING,
        items: [{
          airline_data: {
            origin_destination: [{
              segments: [{}]
            }]
          },
          quantity: ONE_ITEM,
          total_price: retrieveQuoteResponse && retrieveQuoteResponse.amount,
        }]
      }
      object["paymentGateway"] = paymentGateway
    }
    return { object }
  }

  /**
    * Proceed to payment button click 
    * @param {retrieveQuoteResponse} RetrieveQuoteResponse
    * 
    * @author Amrutha J Raj
    */
  proceedToPayment = (retrieveQuoteResponse) => {
    const requestBody = this.generateRenewMilesRequest(retrieveQuoteResponse)
    this.props.renewPointPayment(requestBody, ID_SPINNER_PROCEED_TO_PAY)
  }

  /**
  * On blur method for the no of miles text field
  * @param {point} no of miles
  *
  * @author Amrutha J Raj
  */
  handleOnBlur = (point) => {
    this.setState({ onPointFieldChange: false })
    if (this.state.noOfMiles) {
      if (this.state.noOfMiles > point) {
        this.setState({
          noOfMiles: point,
          isError: true,
        })
        this.fetchRetrieveQuote(point)
      }
      else {
        this.fetchRetrieveQuote()
      }
    }
    else{
      this.setState({amount:this.getRoundOffAmount()})
    }
  }
  /** 
 * On Change method for the no of miles text field
 * @param {event} text field event
 * 
 * @author Amrutha J Raj
 */
  handleOnChange = (event) => {
    const pattern = this.props.configRenewPoint && this.props.configRenewPoint.ui && this.props.configRenewPoint.ui.pointValidation
    if (isPatternMatch(pattern, event.target.value)) {
      this.setState({
        noOfMiles: event.target.value,
        isError: false
      })
    }
  }


  /**
   * Method to handle the AgreeTerms change from the Terms and condition checkbox
   * @param {*} e
   * 
   * @author Amrutha J Raj
   */
  handleAgreeTermsChanged(e) {
    this.setState({
      agreeTerms: !this.state.agreeTerms,
      proceedToPay: !this.state.agreeTerms
    })
  }
  /**
  * Method invoked on closing the modal
  * 
  * @author Amrutha J Raj
  */
  onClose = () => {
    this.setState({ isError: false, agreeTerms: false, proceedToPay: false, noOfMiles: this.props.pointBlock.points })
  }

  render() {
    const { t, configRenewPoint, selectedTab, resetPoint, retrieveQuoteResponse, pointBlock } = this.props
    const actionType = configRenewPoint && configRenewPoint.actionTypes &&
      configRenewPoint.actionTypes.find(actionType => actionType.key == selectedTab)
    const duration = resetPoint && resetPoint.length && resetPoint[0].FieldDescription
  
    return (
      // <!--form modal  starts here-->
      <div className="modal fade modal--form" id="ExtendRenewModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
        aria-hidden="true">
        <div className="modal-dialog modal-dialog-centered" role="document">
          <div className="modal-content">
            <div className="modal-header">
              <h2 id="exampleModalLongTitle">
                {this.props.selectedTab == TAB_EXPIRING_SOON ? t('extend_expiry.extend_popup.extend_miles_expiry') :
                  t('extend_expiry.extend_popup.renew_miles_expiry')}
              </h2>
              <button type="button" className="close" data-dismiss="modal" data-test="closeIcon" onClick={() => this.onClose()} aria-label="Close">
                <img src={`${_IMAGE_BASEURL}/icons/icon-close.svg`} alt="close" />
              </button>
            </div>
            <div className="modal-body">
              <div className="row">
                {/* <!--No of Miles--> */}
                <div className="form-group col-md-6">
                  <label htmlFor="no_of_miles">{t('extend_expiry.extend_popup.no_of_miles')}</label>
                  <input type="text" className=""
                    id="no_of_miles"
                    onChange={(e) => this.handleOnChange(e)}
                    value={this.state.noOfMiles}
                    placeholder={t('extend_expiry.extend_popup.no_of_miles')}
                    onBlur={() => { pointBlock && this.handleOnBlur(pointBlock.points) }}
                    onFocus={() => this.setState({ onPointFieldChange: true })}
                    data-test="pointTextField" />
                  {this.state.isError && <span style={{ "color": "red" }}>
                    {t('extend_expiry.extend_popup.no_of_miles_error')}</span>}
                </div>

                {/* <!--Extend or Renew--> */}
                <div className="form-group col-md-6">
                  <label htmlFor="extend_renew">{t(`extend_expiry.extend_popup.${selectedTab}`)}</label>
                  <input type="text" className="" id="extend_renew" value={duration} disabled placeholder={t(`extend_expiry.extend_popup.${selectedTab}`)} />
                </div>

                {/* <!--Total amount payable--> */}
                <div className="form-group col-md-6">
                  <label htmlFor="inputEmail4">{t('extend_expiry.extend_popup.total_amount_payable')}</label>
                  <input type="text" className="" value={this.state.amount} id="inputEmail4" disabled placeholder={t('extend_expiry.extend_popup.total_amount_payable')} />
                </div>

                <div className="col-md-12 d-flex align-items-start align-items-md-center justify-content-between mt-3 flex-column flex-md-row">
                  <div className="buttonLeftTxt mb-4 mb-md-0">
                    <div className="form-check form-check-inline mr-0">
                      <input className="form-check-input" type="checkbox"
                        id="inlineCheckbox1"
                        data-test="checkbox-terms"
                        value={this.state.agreeTerms} checked={this.state.agreeTerms} onChange={(e) => this.handleAgreeTermsChanged(e)}
                        value="option1" />
                      <label className="form-check-label" htmlFor="inlineCheckbox1">
                        <span>{t('extend_expiry.extend_popup.termsOne')}
                          <strong> {parse(t('extend_expiry.extend_popup.termsTwo'))}</strong>
                          {this.props.selectedTab == TAB_EXPIRING_SOON ? t('extend_expiry.extend_popup.termsThreeExtend') : t('extend_expiry.extend_popup.termsThreeRenew')}
                        </span></label>
                    </div></div>
                  {/* <!--Cancel or Proceed to Payment Button--> */}
                  <div className="btn-wrap btn-wrap--grp">
                    <Button
                      id="close-btn"
                      className="btn btn-secondary btn-sm"
                      label={t('extend_expiry.extend_popup.cancel')}
                      modal="modal"
                      testIdentifier="btnClose"
                      handleOnClick={() => this.onClose()} />

                    <Button
                      id="proceed-btn"
                      className="btn btn-primary btn-sm"
                      enabled={this.state.proceedToPay && this.state.noOfMiles && this.state.noOfMiles > 0 &&
                        !this.state.onPointFieldChange}
                      testIdentifier="btnProceedTobuy"
                      id={ID_SPINNER_PROCEED_TO_PAY}
                      handleOnClick={() => this.proceedToPayment(retrieveQuoteResponse)}
                      label={actionType && actionType.isPaymentRequired ? t('extend_expiry.extend_popup.proceedToPay') : t('extend_expiry.extend_popup.proceed')}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      // {/* <!--form modal ends here--> */}
    );
  }
}
const mapStateToProps = state => {
  return {
    masterEntityLookup: state.masterEntityDataReducer.masterEntityLookup,
    resetPoint: state.masterData[RESET_POINT] ? state.masterData[RESET_POINT] : [],
    configRenewPoint: findValueFromObjectByPath(state, 'configurationReducer.renewpoint', []),
    masterEntityLookupFilters: state.masterEntityDataReducer.masterEntityLookupFilters,
    retrieveQuoteResponse: state.retrieveQuoteReducer && state.retrieveQuoteReducer.retrieveQuoteResponse,
    defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
    renewMilesResponse: state.renewMilesPaymentReducer && state.renewMilesPaymentReducer.renewMilesResponse,
    extendOrRenewPointDetails: state.extendExpiryReducer && state.extendExpiryReducer.retrievedRenewOrExpiryDetails,
  }
}
const mapDispatchToProps = {
  fetchMasterData,
  fetchRetrieveQuote,
  renewPointPayment
}


export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(ExtendRenewModal)));
