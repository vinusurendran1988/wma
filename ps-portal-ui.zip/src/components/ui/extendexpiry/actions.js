import { startApiLoading, startButtonSpinner, stopApiLoading, stopButtonSpinner } from "../../common/components/fieldbank/loader/action";
import { _URL_RENEW_MILES_PAYMENT, _URL_RETRIEVE_QUOTE, _URL_RETRIEVE_RENEW_EXPIRY_POINT_DETAILS } from "../../common/config/config";
import { doPost } from "../../common/utils/api";
import { RENEW_POINT_PAYMENT_ERROR, RENEW_POINT_PAYMENT_SUCCESS, RETRIEVE_QUOTE_ERROR, RETRIEVE_QUOTE_SUCCESS, RETRIEVE_RENEW_EXPIRY_POINT_DETAILS_ERROR, RETRIEVE_RENEW_EXPIRY_POINT_DETAILS_SUCCESS } from "./Constants";

/**
 * Action call to retrieve extend/renew expiry details.
 * @param {JSON} payload Request payload to be dispatched
 * @author Amrutha J Raj
 */

export const retrieveRenewOrExpiryPointDetails = (payload) => {
    return async dispatch => {
        dispatch({
            type: RETRIEVE_RENEW_EXPIRY_POINT_DETAILS_ERROR,
            payload: []
        })
        dispatch(startApiLoading("retrieveRenewOrExpiryPointDetails"))
        await doPost(_URL_RETRIEVE_RENEW_EXPIRY_POINT_DETAILS, payload)
            .then((response) => {
                dispatch(stopApiLoading("retrieveRenewOrExpiryPointDetails"))
                dispatch({
                    type: RETRIEVE_RENEW_EXPIRY_POINT_DETAILS_SUCCESS,
                    payload: response.data
                })
            })
            .catch((error) => {
                dispatch(stopApiLoading("retrieveRenewOrExpiryPointDetails"))
                dispatch({
                    type: RETRIEVE_RENEW_EXPIRY_POINT_DETAILS_ERROR,
                    payload: error
                })
            })
    };
}


/**
 * Action call to fetch retrieve quote
 * @param {JSON} payload Request payload to be dispatched
 * @author Amrutha J Raj
 */

export const fetchRetrieveQuote = (payload) => {
    return async dispatch => {
        dispatch(startButtonSpinner("retrieveQuote"))
        await doPost(_URL_RETRIEVE_QUOTE, payload)
            .then((response) => {
                dispatch(stopApiLoading("retrieveQuote"))
                dispatch({
                    type: RETRIEVE_QUOTE_SUCCESS,
                    payload: response.data
                })
            })
            .catch((error) => {
                dispatch(stopButtonSpinner("retrieveQuote"))
                dispatch({
                    type: RETRIEVE_QUOTE_ERROR,
                    payload: error
                })
            })
    };
}

/**
 * Action call to extend/renew miles with payment
 * @param {JSON} payload Request payload to be dispatched
 * @param {String} id Extend/Renew id
 * @author Amrutha J Raj
 */

export const renewPointPayment = (payload, id) => {
    return async (dispatch) => {
        dispatch(startButtonSpinner(id, "renewPointPayment"))
        await doPost(_URL_RENEW_MILES_PAYMENT, payload)
            .then((response) => {
                dispatch(stopButtonSpinner(id, "renewPointPayment"))
                dispatch({
                    type: RENEW_POINT_PAYMENT_SUCCESS,
                    payload: response.data
                })
            })
            .catch((error) => {
                dispatch(stopButtonSpinner(id, "renewPointPayment"))
                dispatch({
                    type: RENEW_POINT_PAYMENT_ERROR,
                    payload: error.response.data
                })
            })
    }
}
