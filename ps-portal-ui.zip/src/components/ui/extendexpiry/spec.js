import { mount } from 'enzyme';
import moxios from 'moxios';
import React from 'react';
import ReactTestUtils from 'react-dom/test-utils';
import { Provider } from 'react-redux';
import { _URL_RENEW_MILES_PAYMENT, _URL_RETRIEVE_QUOTE, _URL_RETRIEVE_RENEW_EXPIRY_POINT_DETAILS } from '../../common/config/config';
import { fetchConfiguration } from '../../common/middleware/redux/commonAction';
import { findByTestAttr, findComponent, mockServiceResponse } from '../../common/testUtils';
import { testStore } from '../../common/utils';
import { axiosInstance } from '../../common/utils/api';
import { CONFIG_SECTION_RENEWPOINT } from '../../common/utils/Constants';
import { fetchRetrieveQuote, renewPointPayment, retrieveRenewOrExpiryPointDetails } from './actions';
import { TAB_EXPIRING_SOON } from './Constants';
import ExtendRenewModal from './ExtendRenewModal';
import ExtendRenewTable from './ExtendRenewTable';
import ExtendExpiry from './index';

var store = testStore({})
let rootComponent;
let childComponent;
let childModalComponent;
let component;
let rootComponentChild;

const setUp = (props = {}, isDefaultConfig = false) => {
    props.resetError = jest.fn();
    props.setPageInfo = jest.fn();
    props.setError = jest.fn();
    window.location = jest.fn();
    if (isDefaultConfig) {
        props["config"] = JSON.parse(JSON.stringify(CONFIG_RESPONSE)).object
    }
    rootComponent = mount(<Provider store={store}>
        <ExtendExpiry {...props} store={store} />
    </Provider>);
    component = findComponent(rootComponent, 'ExtendExpiry');
};

const setUpChild = (props) => {
    props["config"] = JSON.parse(JSON.stringify(CONFIG_RESPONSE)).object
    props["selectedTab"] = TAB_EXPIRING_SOON
    props["pointBlock"] = POINT_BLOCK
    props["field"] = FIELD

    props.modalOpen = jest.fn()
    rootComponentChild = mount(
        <Provider store={store}>
            <ExtendRenewTable {...props} />
        </Provider>
    );
    childComponent = findComponent(rootComponentChild, 'ExtendRenewTable');
};

const setUpChildModal = (props) => {
    props["config"] = JSON.parse(JSON.stringify(CONFIG_RESPONSE)).object
    props["selectedTab"] = TAB_EXPIRING_SOON
    props["configRenewPoint"] = JSON.parse(JSON.stringify(CONFIG_RESPONSE)).object
    props["pointBlock"] = POINT_BLOCK

    rootComponentChild = mount(
        <Provider store={store}>
            <ExtendRenewModal pointBlock={POINT_BLOCK} {...props} />
        </Provider>
    );
    childModalComponent = findComponent(rootComponentChild, 'ExtendRenewModal');
};


const updateComponents = () => {
    rootComponent = rootComponent.update()
    component = findComponent(rootComponent, 'ExtendExpiry');
}

describe('Extend Expiry Page : Should render the page', () => {
    beforeEach(() => {
        store = undefined
        store = testStore({})
        moxios.install(axiosInstance);

    });

    afterEach(() => {
        moxios.uninstall(axiosInstance);
    });

    it('Should show the default tab as expiring soon and to successfully test the happy flow of renew/extend miles', () => {
        setUp({});
        setUpChild({})
        setUpChildModal({})
        moxios.stubRequest(_URL_RETRIEVE_RENEW_EXPIRY_POINT_DETAILS, {
            status: 200,
            responseText: RETRIEVE_EXTEND_RENEW_RESPONSE
        })
        mockServiceResponse(CONFIG_RESPONSE)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_RENEWPOINT))
                .then(() => {
                    let newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_RENEWPOINT]).toBe(CONFIG_RESPONSE.object);
                    updateComponents();
                    const tab = findByTestAttr(component, 'tab-btn-1')
                    const tabMob = findByTestAttr(component, 'tab-Mob-0')
                    const defaultTab = findByTestAttr(component, 'default-tab')
                    expect(tab.length).toBe(1)
                    expect(tabMob.length).toBe(1)
                    expect(defaultTab.length).toBe(1)
                    //changing tab
                    tab.props().onClick("expired")
                    tabMob.props().onClick("expired")
                    defaultTab.props().onClick()

                    moxios.stubRequest(_URL_RETRIEVE_QUOTE, {
                        status: 200,
                        responseText: RETRIEVE_QUOTE_RESPONSE
                    })
                    moxios.stubRequest(_URL_RENEW_MILES_PAYMENT, {
                        status: 200,
                        responseText: EXTEND_RENEW_RESPONSE
                    })
                    const btnProceedTobuy = findByTestAttr(childModalComponent, 'btnProceedTobuy')
                    expect(btnProceedTobuy.length).toBe(1)
                    btnProceedTobuy.props().onClick()
                    updateComponents()
                })
        })
    })

    it('Should call the Extend API to get the list of expiring soon points', () => {
        setUp({});
        const newUrl = 'activation?TKN=604A81D3AF55F24D3F5814B2C6D25DF774710320&MEM_ID=IM0008010804';
        Object.defineProperty(window, 'location', {
            writable: true,
            value: {
                hash: newUrl,
                href: 'payment=success?T5F24D3F5814B2C6D25DF774710320&MEM_I'

            }
        });
        window.scrollTo = jest.fn()
        moxios.stubRequest(_URL_RETRIEVE_RENEW_EXPIRY_POINT_DETAILS, {
            status: 200,
            responseText: RETRIEVE_EXTEND_RENEW_RESPONSE
        })

        return ReactTestUtils.act(() => {
            return store.dispatch(retrieveRenewOrExpiryPointDetails(REQUEST_BODY))
                .then(() => {
                    let newState = store.getState();
                    expect(newState.extendExpiryReducer.retrievedRenewOrExpiryDetails).toBe(RETRIEVE_EXTEND_RENEW_RESPONSE.object)
                    updateComponents();
                })
        })
    })

    it('ExtendRenewTable  point body template', () => {
        setUp({});
        setUpChild({})
        setUpChildModal({})
        mockServiceResponse(CONFIG_RESPONSE)
        const props = { header: "test" }
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_RENEWPOINT))
                .then(() => {
                    let newState = store.getState();
                    childComponent.instance().pointsBodyTemplate(ROW_DATA, props)
                    expect(newState.configurationReducer[CONFIG_SECTION_RENEWPOINT]).toBe(CONFIG_RESPONSE.object);
                    updateComponents();
                })
        })

    })

    it('ExtendRenewTable  action body template', () => {
        setUp({});
        setUpChild({})
        setUpChildModal({})
        childComponent.instance().actionBodyTemplate(ROW_DATA)
        childComponent.instance().handleClick()
        updateComponents()
    })

    it('Should handle error case when retrieval API fails', () => {
        mockServiceResponse(EXTEND_EXPIRY_ERROR_RESPONSE, 500)
        return store.dispatch(
            retrieveRenewOrExpiryPointDetails({})
        ).then(() => {
            const newState = store.getState();
            expect(newState.extendExpiryReducer.retrievedRenewOrExpiryDetails).toHaveLength(0)
            updateComponents()
        })

    })

    it('Should handle error case when extend/renewal API fails', () => {
        mockServiceResponse(EXTEND_EXPIRY_ERROR_RESPONSE, 500)
        return store.dispatch(
            renewPointPayment({})
        ).then(() => {
            const newState = store.getState();
            expect(newState.renewMilesPaymentReducer.renewMilesPaymentReducer).toBeUndefined
            updateComponents()
        })

    })
    it('Open the modal on clicking the extend or renew button from the table ', () => {
        setUp({});
        setUpChild({})
        setUpChildModal({})
        mockServiceResponse(CONFIG_RESPONSE)
        const props = { header: "test" }
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_RENEWPOINT))
                .then(() => {
                    const extendOrRenewButton = findByTestAttr(childComponent, 'btnOpenModal')
                    expect(extendOrRenewButton.length).toBe(1)
                    extendOrRenewButton.props().onClick()
                })
        })
    })



    it('Payment completion ', () => {
        setUp({});
        setUpChild({})
        setUpChildModal({})
        mockServiceResponse(CONFIG_RESPONSE)
        const props = { header: "test" }
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_RENEWPOINT))
                .then(() => {
                    component.setState({ paymentCompleted: true })
                    updateComponents()
                })
        })
    })

    it('Call the retrieve quote api in the onBlur method', () => {
        setUp({});
        setUpChild({})
        setUpChildModal({})
        moxios.stubRequest(_URL_RETRIEVE_QUOTE, {
            status: 200,
            responseText: RETRIEVE_QUOTE_RESPONSE
        })
        childModalComponent.setState({
            noOfMiles: 100
        })
        updateComponents()
        const pointTextField = findByTestAttr(childModalComponent, 'pointTextField')
        expect(pointTextField.length).toBe(1)
        pointTextField.props().onBlur()
        mockServiceResponse(CONFIG_RESPONSE)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_RENEWPOINT))
                .then(() => {                 
                    let newState = store.getState();
                    expect(newState.retrieveQuoteReducer.retrieveQuoteResponse).toBe(RETRIEVE_QUOTE_RESPONSE.object)
                    updateComponents()
                })
        })
    })

    it('Entered points should be less than the point block points in onBlur method', () => {
        setUp({});
        setUpChild({})
        setUpChildModal({})
        childModalComponent.setState({ noOfMiles: 120 })
        updateComponents()
        const pointTextField = findByTestAttr(childModalComponent, 'pointTextField')
        expect(pointTextField.length).toBe(1)
        pointTextField.props().onBlur()
        expect(childModalComponent.state('isError')).toEqual(true)
    })

    it('Handle on change event for no of points text field', () => {
        setUp({});
        setUpChild({})
        setUpChildModal({})
        updateComponents()
        const pointTextField = findByTestAttr(childModalComponent, 'pointTextField')
        expect(pointTextField.length).toBe(1)
        pointTextField.props().onChange({ target: { value: 12 } })
        expect(childModalComponent.state('isError')).toEqual(false)
    })

    it('Handle on close button event', () => {
        setUp({});
        setUpChild({})
        setUpChildModal({})
        updateComponents()
        const btnClose = findByTestAttr(childModalComponent, 'btnClose')
        expect(btnClose.length).toBe(1)
        btnClose.props().onClick()
        const closeIcon = findByTestAttr(childModalComponent, 'closeIcon')
        expect(closeIcon.length).toBe(1)
        closeIcon.props().onClick()
        expect(childModalComponent.state('isError')).toEqual(false)
        expect(childModalComponent.state('agreeTerms')).toEqual(false)
        expect(childModalComponent.state('proceedToPay')).toEqual(false)
    })

    it('Handle on Change event for Accept terms checkbox', () => {
        setUp({});
        setUpChild({})
        setUpChildModal({})
        updateComponents()
        const checkBox = findByTestAttr(childModalComponent, 'checkbox-terms')
        expect(checkBox.length).toBe(1)
        checkBox.props().onChange()
        expect(childModalComponent.state('agreeTerms')).toEqual(true)
        expect(childModalComponent.state('proceedToPay')).toEqual(true)
    })

    it('Retrieve quote API failure', () => {
        setUp({});
        setUpChild({})
        setUpChildModal({})
        mockServiceResponse(RETRIEVE_QUOTE_ERROR_RESPONSE, 500)
        return store.dispatch(
            fetchRetrieveQuote({})
        ).then(() => {
            const newState = store.getState();
            expect(newState.retrieveQuoteReducer.retrieveQuoteResponse).toBeUndefined()
            updateComponents()
        })
    })

    it('Should handle when payment is cancelled', () => {
        setUp({});
        setUpChild({})
        setUpChildModal({})
        mockServiceResponse(CONFIG_RESPONSE)
        Object.defineProperty(window, 'location', {
            writable: true,
            value: {
                href: 'payment=cancelled?T5F24D3F5814B2C6D25DF774710320&MEM_I'

            }
        });
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_RENEWPOINT))
                .then(() => {
                    let newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_RENEWPOINT]).toBe(CONFIG_RESPONSE.object);
                    updateComponents();
                    const tab = findByTestAttr(component, 'tab-btn-1')
                    expect(tab.length).toBe(1)
                    tab.props().onClick("expired")
                    moxios.stubRequest(_URL_RETRIEVE_QUOTE, {
                        status: 200,
                        responseText: RETRIEVE_QUOTE_RESPONSE
                    })
                    moxios.stubRequest(_URL_RENEW_MILES_PAYMENT, {
                        status: 200,
                        responseText: EXTEND_RENEW_RESPONSE
                    })
                    const btnProceedTobuy = findByTestAttr(childModalComponent, 'btnProceedTobuy')
                    expect(btnProceedTobuy.length).toBe(1)
                    btnProceedTobuy.props().onClick()
                    updateComponents()
                })
        })

    })

    it('Should handle when payment is failed', () => {
        setUp({});
        setUpChild({})
        setUpChildModal({})
        mockServiceResponse(CONFIG_RESPONSE)
        Object.defineProperty(window, 'location', {
            writable: true,
            value: {
                href: 'payment=failed?T5F24D3F5814B2C6D25DF774710320&MEM_I'

            }
        });
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_RENEWPOINT))
                .then(() => {
                    let newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_RENEWPOINT]).toBe(CONFIG_RESPONSE.object);
                    updateComponents();
                    const tab = findByTestAttr(component, 'tab-btn-1')
                    expect(tab.length).toBe(1)
                    tab.props().onClick("expired")
                    moxios.stubRequest(_URL_RETRIEVE_QUOTE, {
                        status: 200,
                        responseText: RETRIEVE_QUOTE_RESPONSE
                    })
                    moxios.stubRequest(_URL_RENEW_MILES_PAYMENT, {
                        status: 200,
                        responseText: EXTEND_RENEW_RESPONSE
                    })
                    const btnProceedTobuy = findByTestAttr(childModalComponent, 'btnProceedTobuy')
                    expect(btnProceedTobuy.length).toBe(1)
                    btnProceedTobuy.props().onClick()
                    updateComponents()
                })
        })

    })
})

const CONFIG_RESPONSE = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "section": "renewpoint", "companyCode": "GF", "programCode": "FF", "activityCode": "RP", "termsAndConditions": "https:\/\/www.gulfair.com\/membership\/rules-terms?_gl=1%2A1sqwq73%2A_ga%2AMjc3NjUwODU3LjE2MTc3ODc3NTA.%2A_ga_0QVNSNCG0T%2AMTYyMTQwNTQ2OS4xNC4xLjE2MjE0MDYxNzQuMA", "actionTypes": [{ "key": "expired", "renewPointActionType": "RE", "durationInDays": 2000, "isPaymentRequired": true }, { "key": "expiringSoon", "renewPointActionType": "EP", "durationInDays": 2000, "isPaymentRequired": true }], "ui": { "pointValidation": "^[0-9]{0,15}$", "extendDurationInDays": 365, "roundOffDigit": 2, "memNo": "MEMSHPNUM", "pointType": "PNTTYP", "points": "PNTS", "partyType": "M", "orderInfo": "Payment for renew miles", "layout": { "elements": { "tabs": ["expiringSoon", "expired"], "expiringSoon": { "table": { "columns": [{ "body": "defaultColumnBodyTemplate", "field": "displayName", "header": "extend_expiry.point_type", "sortable": false, "className": "", "visibility": true }, { "body": "pointsBodyTemplate", "field": "points", "header": "extend_expiry.miles", "sortable": false, "visibility": true }, { "body": "defaultColumnBodyTemplate", "field": "expiryDate", "header": "extend_expiry.expiry_date", "sortable": false, "visibility": true }, { "body": "actionBodyTemplate", "field": "", "sortable": false, "visibility": true }] } }, "expired": { "table": { "columns": [{ "body": "defaultColumnBodyTemplate", "field": "displayName", "header": "extend_expiry.point_type", "sortable": false, "className": "", "visibility": true }, { "body": "pointsBodyTemplate", "field": "points", "header": "extend_expiry.miles", "sortable": false, "visibility": true }, { "body": "defaultColumnBodyTemplate", "field": "expiryDate", "header": "extend_expiry.expiry_date", "sortable": false, "visibility": true }, { "body": "actionBodyTemplate", "field": "", "sortable": false, "visibility": true }] } } } } } } }
const RETRIEVE_EXTEND_RENEW_RESPONSE = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "companyCode": "GF", "programCode": "FF", "accountStatus": "A", "membershipNumber": "0007111082", "totalRenewablePoints": 0, "accountPointExpiryDate": null, "renewablePointBlockDetails": [{ "pointType": "MILES", "displayName": "Falcon Flyer Miles", "points": 330, "expiryDate": "15-Jun-2021", "bonusCode": "" }, { "pointType": "MILES", "displayName": "Falcon Flyer Miles", "points": 330, "expiryDate": "29-Jan-2023", "bonusCode": "" }, { "pointType": "MILES", "displayName": "Falcon Flyer Miles", "points": 110, "expiryDate": "29-Jan-2023", "bonusCode": "WE" }] } }
const REQUEST_BODY = { "companyCode": "GF", "programCode": "FF", "membershipNumber": "0007111206", "renewPointActionType": "EP", "applicableDate": "11-Jun-2023" }
const EXTEND_EXPIRY_ERROR_RESPONSE = { "statuscode": "500", "statusMessage": "FAILURE", "error": { "code": "500", "type": "INTERNAL_SERVER_ERROR", "message": "Retrieve renew or expiry point details failed", "errorDetails": [{ "message": "Member with no expired points" }] } }
const ROW_DATA = { pointType: "MILES", displayName: "Falcon Flyer Miles", points: 1710, expiryDate: "25-May-2021", bonusCode: "" }
const EXTEND_RENEW_RESPONSE = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "companyCode": "GF", "programCode": "FF", "membershipNumber": "0007110414", "endDate": null, "memberActivityStatus": { "companyCode": "GF", "programCode": "FF", "membershipNumber": "0007110414", "activityNumber": "ACT6275", "activityType": "RP", "activityName": "RENEW_POINT", "activityStatus": "P", "activityCode": "RP", "pointDetails": [] }, "redirectURL": "http:\/\/192.168.45.252:8092\/paymentlite-ui\/ps\/payment?sessionKey=DBDA2FE278864C7E91306E8DA5D9886F" } }
const RETRIEVE_QUOTE_RESPONSE = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "companyCode": "GF", "programCode": "FF", "membershipNumber": "0007110414", "partnerCode": null, "quoteReferenceNumber": "QOT1340", "activityCode": "RP", "amount": "8.0", "points": 0, "paymentOption": "PCM", "conversionRate": "0.0", "expiryDate": "15-Jul-2021", "pointsPaymentAllowed": "false", "creditCardPaymentAllowed": "true", "chargeHeadDetails": [{ "chargeHead": { "chargeHeadCode": "CHG", "chargeHeadName": "Service charge", "amount": 8, "points": "0.0", "applicableTaxPercent": 0 } }] } }
const POINT_BLOCK = { "pointType": "MILES", "displayName": "Falcon Flyer Miles", "points": 110, "expiryDate": "07-Jul-2021", "bonusCode": "" }
const RETRIEVE_QUOTE_ERROR_RESPONSE = { "statuscode": "500", "statusMessage": "FAILURE", "error": { "code": "500", "type": "INTERNAL_SERVER_ERROR", "message": "Retrieve quote failed", "errorDetails": [{ "message": "Retrieve quote failed" }] } }
const FIELD = { "values": [{ "pointType": "MILES", "displayName": "Falcon Flyer Miles", "points": 600, "expiryDate": "30-Jan-2023", "bonusCode": "" }], "columns": [{ "body": "defaultColumnBodyTemplate", "field": "displayName", "header": "extend_expiry.point_type", "sortable": false, "className": "", "visibility": true }, { "body": "pointsBodyTemplate", "field": "points", "header": "extend_expiry.miles", "sortable": false, "visibility": true }, { "body": "defaultColumnBodyTemplate", "field": "expiryDate", "header": "extend_expiry.expiry_date", "sortable": false, "visibility": true }, { "body": "actionBodyTemplate", "field": "", "sortable": false, "visibility": true }] }