import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withSuspense } from '../../common/utils';
import { withTranslation } from 'react-i18next';
import {
    fetchConfiguration,
    fetchProfileData
} from '../../common/middleware/redux/commonAction'
import { CONFIG_SECTION_PREFERENCE } from '../../common/utils/Constants';
import SelectedPreference from './SelectedPreference';
import { fetchAdditionalDetails } from './actions'
import CustomMessage from '../../common/components/custommessage/index';
import { MESSAGE_TYPE_SUCCESS } from './Constants';

/**
 * @name Preferences component
 * @author Ajmal Aliyar
 */
class Preferences extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedTab: undefined,
            memberPreferences: [],
            messages: {
                message: [],
                type: MESSAGE_TYPE_SUCCESS
            }
        }
        this.handleMessageChange = this.handleMessageChange.bind(this)
    }

    componentDidMount() {
        const { preferenceConfig, profileData } = this.props
        if (!preferenceConfig) {
            this.props.fetchConfiguration(CONFIG_SECTION_PREFERENCE)
        }
        if (!profileData) {
            this.props.fetchProfileData()
        } else {
            this.populateMemberPreferenceDetails()
        }
    }

    componentDidUpdate(prevProps, prevState) {
        const {
            preferenceConfig,
            preferenceFieldConfigurations,
            profileData
        } = this.props
        const {
            selectedTab,
            messages
        } = this.state

        if (
            prevProps.preferenceConfig !== preferenceConfig &&
            preferenceConfig.additionalDetailsType
        ) {
            this.props.fetchAdditionalDetails(preferenceConfig.additionalDetailsType)
        }

        if (prevProps.preferenceFieldConfigurations !== preferenceFieldConfigurations) {
            this.initializePage()
            this.populateMemberPreferenceDetails()
        }

        if (selectedTab == undefined || prevState.selectedTab !== selectedTab) {
            if (selectedTab !== undefined) {
                this.setTabContentsToDisplay()
            } else {
                this.initializePage()
            }
        }

        if (prevProps.profileData !== profileData) {
            this.populateMemberPreferenceDetails()
        }

        if ((prevState.messages != messages) && messages.message.length) {
            this.props.fetchProfileData()
        }
    }

    addFieldTypeToPreferences() {
        const { profileData, preferenceFieldConfigurations } = this.props
        let memberPreferences=[]
        if (profileData && preferenceFieldConfigurations) {
            let allFieldConfigurations = []
            preferenceFieldConfigurations.forEach(tab => {
                allFieldConfigurations = allFieldConfigurations.concat(tab.memberPreferenceDetails)
            })

            memberPreferences = profileData.object.memberAccount.memberPreferences.map(preference => {
                const found = allFieldConfigurations.find(config => {
                    return config.preferenceCode == preference.preferenceCode
                })
                preference.fieldType = found ? found.fieldType : ""
                return preference
            })
        }
        return memberPreferences
    }

    populateMemberPreferenceDetails() {
        const { profileData } = this.props
        if (
            profileData &&
            profileData.object &&
            profileData.object.memberAccount &&
            profileData.object.memberAccount.memberPreferences
        ) {
            const memberPreferences = this.addFieldTypeToPreferences()
            this.setState({
                memberPreferences
            })
        }
    }

    initializePage() {
        const { preferenceFieldConfigurations } = this.props
        if (
            preferenceFieldConfigurations &&
            preferenceFieldConfigurations.length
        ) {
            this.setState({
                selectedTab: 0
            })
        }
    }

    setTabContentsToDisplay() {
        const { preferenceFieldConfigurations } = this.props
        const { selectedTab } = this.state
        if (
            preferenceFieldConfigurations &&
            preferenceFieldConfigurations.length
        ) {
            this.setState({ selectedTabContentToDisplay: preferenceFieldConfigurations[selectedTab] })
        }
    }

    handleMessageChange(paramMessages, status = MESSAGE_TYPE_SUCCESS) {
        const messagesToShow = {
            message: paramMessages,
            type: status
        }
        this.setState({ messages: messagesToShow })
    }

    render() {
        const { selectedTab, selectedTabContentToDisplay, memberPreferences, messages } = this.state
        const { t, preferenceFieldConfigurations,preferenceConfig  } = this.props
        const shouldDisplayPage = preferenceFieldConfigurations && preferenceFieldConfigurations.length
        const tabNames = shouldDisplayPage && preferenceFieldConfigurations.map((tab) => {
            return tab.groupName
        })

        return (
            (shouldDisplayPage)
                ? <>
                    <CustomMessage
                        message={messages.message}
                        type={messages.type}
                    />
                    <main role="main" className="pageClassPermission">
                        <div className="form-row">

                            {/* Title of the page */}
                            <div className="col-12">
                                <h2 className="mb-4">{t('preferences.pageTitle')}</h2>
                            </div>

                            {/* Left Tab : Holds the tabs that can be clicked to change the page */}
                            <div className="col-lg-3 vertical__tab--left">
                                <div
                                    className="nav flex-column nav-pills"
                                    id="v-pills-tab"
                                    role="tablist"
                                    aria-orientation="vertical"
                                >
                                    {tabNames.map((tabName, index) => {
                                        let classToBeAppended = ""
                                        let ariaSelected = false
                                        const selected = (index == selectedTab)
                                        if (selected) {
                                            classToBeAppended = "active"
                                            ariaSelected = true
                                        }
                                        return <a
                                            key={`${tabName}`}
                                            data-test={`${tabName}`}
                                            className={`nav-link ${classToBeAppended}`}
                                            id={`v-pills-${index}-tab`}
                                            data-toggle="pill"
                                            href={`#v-pills-${index}`}
                                            role="tab"
                                            aria-controls={`v-pills-${index}`}
                                            aria-selected={ariaSelected}
                                            onClick={() => {
                                                this.setState({ selectedTab: index })
                                            }}
                                        >{tabName}</a>
                                    })}
                                </div>
                            </div>

                            {/* Right Pane  : Holds the actual page content */}
                            <div className="col-lg-9 vertical__tab--right">
                                <div className="tab-content" id="v-pills-tabContent">

                                    {
                                        selectedTabContentToDisplay &&
                                        <div
                                            className="tab-pane fade show active"
                                            id={`v-pills-${selectedTab}`}
                                            role="tabpanel"
                                            aria-labelledby={`v-pills-${selectedTab}-tab`}>
                                            {
                                                <SelectedPreference
                                                    pageContent={selectedTabContentToDisplay}
                                                    memberPreferences={memberPreferences}
                                                    selectedTab={selectedTab}
                                                    handleMessageChange={this.handleMessageChange}
                                                    checkboxGroupClassName={preferenceConfig.checkboxGroupClassName}
                                                />
                                            }
                                        </div>
                                    }
                                </div>
                            </div>
                        </div>
                    </main>
                </>

                : <p>{t('preferences.loading_preferences')}</p>

        );
    }
}

Preferences.propTypes = {

};

const mapStateToProps = (state) => {
    return {
        preferenceConfig: state.configurationReducer[CONFIG_SECTION_PREFERENCE],
        preferenceFieldConfigurations: state.masterData.memberPreferenceDetails,
        profileData: state.profileDataReducer.profileData
    }
}

const mapDispatchToProps = {
    fetchConfiguration,
    fetchAdditionalDetails,
    fetchProfileData
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(Preferences)));
