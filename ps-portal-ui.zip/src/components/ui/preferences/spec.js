import React from 'react';
import { Provider } from 'react-redux';
import { mount } from 'enzyme';
import moxios from 'moxios';
import { testStore } from '../../common/utils';
import Preferences from './index'
import {
    SESSION_STORAGE_COMPANY_CODE,
    SESSION_STORAGE_PROGRAM_CODE,
    SESSION_STORAGE_MEMBERSHIP_NO,
    CONFIG_SECTION_PREFERENCE
} from '../../common/utils/Constants';
import {
    mockServiceResponse, findByTestAttr
} from '../../common/testUtils';
import { fetchConfiguration } from '../../common/middleware/redux/commonAction';
import { fetchAdditionalDetails, fetchProfileData, performSavePreference } from './actions';

var store;
let rootComponent;

const setUp = (props = {}) => {
    window.sessionStorage.setItem(SESSION_STORAGE_COMPANY_CODE, 'IBS')
    window.sessionStorage.setItem(SESSION_STORAGE_PROGRAM_CODE, 'PRG14')
    localStorage.setItem(SESSION_STORAGE_MEMBERSHIP_NO, 'IM0008010415')
    rootComponent = mount(
        <Provider store={store} >
            <Preferences {...props} />
        </Provider>
    );
};

/**
 * Tests for Preference component
 * @author Ajmal Aliyar
 */
describe('Preference Component', () => {
    describe('Render without errors', () => {
        beforeEach(() => {
            const RESPONSE_CONFIG_PREFERENCE = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "section": "preference", "companyCode": "IBS", "programCode": "PRG14", "additionalDetailsType": "memberPreference", "typeIdentifier": { "identifierProperty": "preferenceName", "identifierSuffix": "_CUSTOMER", "suffixPresent": "C", "suffixNotPresent": "P" } } }
            store = undefined
            store = testStore({})
            moxios.install();
            setUp({})
            mockServiceResponse(RESPONSE_CONFIG_PREFERENCE, 200)
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_PREFERENCE))
                .then(() => {
                    let newState = store.getState()
                    expect(newState.configurationReducer.preference).toBe(RESPONSE_CONFIG_PREFERENCE.object)

                    const RESPONSE_ADDITIONAL_DETAILS = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "companyCode": "IBS", "programCode": "PRG14", "memberPreferences": [{ "groupName": "Hotel Preferences", "memberPreferenceDetails": [{ "preferenceCode": 101, "preferenceName": "Hotel Chains_CUSTOMER", "preferenceQuestion": "Hotel Chains", "preferenceType": "H", "fieldType": "TF", "mandatory": false, "displayOrder": 1, "preferenceInputOption": [], "type": "C" }, { "preferenceCode": 102, "preferenceName": "Hotels_CUSTOMER", "preferenceQuestion": "Hotels", "preferenceType": "H", "fieldType": "TF", "mandatory": false, "displayOrder": 2, "preferenceInputOption": [], "type": "C" }, { "preferenceCode": 103, "preferenceName": "Room Categories_CUSTOMER", "preferenceQuestion": "Room Categories", "preferenceType": "H", "fieldType": "TF", "mandatory": false, "displayOrder": 3, "preferenceInputOption": [], "type": "C" }, { "preferenceCode": 104, "preferenceName": "Meal Plans_CUSTOMER", "preferenceQuestion": "Meal Plans", "preferenceType": "H", "fieldType": "TF", "mandatory": false, "displayOrder": 4, "preferenceInputOption": [], "type": "C" }, { "preferenceCode": 105, "preferenceName": "Hotel Amenities_CUSTOMER", "preferenceQuestion": "Hotel Amenities", "preferenceType": "H", "fieldType": "TF", "mandatory": false, "displayOrder": 5, "preferenceInputOption": [], "type": "C" }, { "preferenceCode": 106, "preferenceName": "Room Amenities_CUSTOMER", "preferenceQuestion": "Room Amenities", "preferenceType": "H", "fieldType": "TF", "mandatory": false, "displayOrder": 6, "preferenceInputOption": [], "type": "C" }] }, { "groupName": "Comms - General", "memberPreferenceDetails": [{ "preferenceCode": 33, "preferenceName": "DND", "preferenceQuestion": "Do not disturb (DND)?", "preferenceType": "C", "fieldType": "TF", "mandatory": false, "displayOrder": 1, "preferenceInputOption": [], "type": "P" }, { "preferenceCode": 34, "preferenceName": "All Comms", "preferenceQuestion": "Opt-in for all Comms?", "preferenceType": "C", "fieldType": "TF", "mandatory": false, "displayOrder": 2, "preferenceInputOption": [], "type": "P" }, { "preferenceCode": 31, "preferenceName": "Price Alerts", "preferenceQuestion": "Receive Fare Alerts?", "preferenceType": "B", "fieldType": "TF", "mandatory": false, "displayOrder": 3, "preferenceInputOption": [], "type": "P" }, { "preferenceCode": 32, "preferenceName": "Deals and Offers", "preferenceQuestion": "Receive Partner Deals and Offers?", "preferenceType": "O", "fieldType": "TF", "mandatory": false, "displayOrder": 4, "preferenceInputOption": [], "type": "P" }, { "preferenceCode": 5, "preferenceName": "SMS Alerts", "preferenceQuestion": "Do you want to receive SMS?", "preferenceType": "C", "fieldType": "TF", "mandatory": false, "displayOrder": 5, "preferenceInputOption": [], "type": "P" }, { "preferenceCode": 2, "preferenceName": "Preferred Card", "preferenceQuestion": "Preferred Card", "preferenceType": "C", "fieldType": "B", "mandatory": false, "displayOrder": 6, "preferenceInputOption": [{ "optionCode": "P", "optionName": "Physical Card", "sequenceNumber": 3 }], "type": "P" }] }, { "groupName": "Opt In", "memberPreferenceDetails": [{ "preferenceCode": 28, "preferenceName": "Travel Offers", "preferenceQuestion": "Opt in for travel package offers", "preferenceType": "C", "fieldType": "TF", "mandatory": false, "displayOrder": 7, "preferenceInputOption": [], "type": "P" }] }, { "groupName": "Newsletter", "memberPreferenceDetails": [{ "preferenceCode": 37, "preferenceName": "Newsletter", "preferenceQuestion": "Receive Newsletter?", "preferenceType": "C", "fieldType": "TF", "mandatory": false, "displayOrder": 8, "preferenceInputOption": [], "type": "P" }] }, { "groupName": "Comms - Language", "memberPreferenceDetails": [{ "preferenceCode": 14, "preferenceName": "Language Preference", "preferenceQuestion": "Which is your Preferred Language?", "preferenceType": "C", "fieldType": "B", "mandatory": false, "displayOrder": 9, "preferenceInputOption": [{ "optionCode": "EN", "optionName": "English", "sequenceNumber": 20 }, { "optionCode": "KN", "optionName": "Korean", "sequenceNumber": 21 }, { "optionCode": "JN", "optionName": "Japanese", "sequenceNumber": 22 }, { "optionCode": "AC", "optionName": "Arabic", "sequenceNumber": 23 }], "type": "P" }, { "preferenceCode": 38, "preferenceName": "Channel", "preferenceQuestion": "What is your Preferred Mode of Communication?", "preferenceType": "C", "fieldType": "C", "mandatory": false, "displayOrder": 10, "preferenceInputOption": [{ "optionCode": "EL", "optionName": "Email", "sequenceNumber": 24 }, { "optionCode": "SS", "optionName": "SMS", "sequenceNumber": 25 }, { "optionCode": "WP", "optionName": "Whatsap", "sequenceNumber": 26 }, { "optionCode": "PE", "optionName": "Phone", "sequenceNumber": 27 }], "type": "P" }] }, { "groupName": "Sports", "memberPreferenceDetails": [{ "preferenceCode": 10, "preferenceName": "Leisure", "preferenceQuestion": "Leisure", "preferenceType": "B", "fieldType": "TA", "mandatory": false, "displayOrder": 11, "preferenceInputOption": [], "type": "P" }] }, { "groupName": "Statement", "memberPreferenceDetails": [{ "preferenceCode": 23, "preferenceName": "Email Statement", "preferenceQuestion": "Email Statement Monthly", "preferenceType": "C", "fieldType": "TF", "mandatory": false, "displayOrder": 12, "preferenceInputOption": [], "type": "P" }, { "preferenceCode": 24, "preferenceName": "Post Statement", "preferenceQuestion": "Post Statement Monthly", "preferenceType": "C", "fieldType": "TF", "mandatory": false, "displayOrder": 13, "preferenceInputOption": [], "type": "P" }] }, { "groupName": "Entertainment", "memberPreferenceDetails": [{ "preferenceCode": 26, "preferenceName": "Movies", "preferenceQuestion": "What kind of movies do you like?", "preferenceType": "FIN", "fieldType": "TF", "mandatory": false, "displayOrder": 14, "preferenceInputOption": [], "type": "P" }] }, { "groupName": "Travel Preference", "memberPreferenceDetails": [{ "preferenceCode": 30, "preferenceName": "Seating Preference", "preferenceQuestion": "Which seat do you prefer in a travel?", "preferenceType": "S", "fieldType": "R", "mandatory": false, "displayOrder": 15, "preferenceInputOption": [{ "optionCode": "SS", "optionName": "Side Seat", "sequenceNumber": 6 }, { "optionCode": "WS", "optionName": "Window Seat", "sequenceNumber": 7 }, { "optionCode": "MS", "optionName": "Middle Seat", "sequenceNumber": 8 }], "type": "P" }, { "preferenceCode": 29, "preferenceName": "Destination Preferen", "preferenceQuestion": "What places do you prefer?", "preferenceType": "H", "fieldType": "C", "mandatory": false, "displayOrder": 16, "preferenceInputOption": [{ "optionCode": "AL", "optionName": "Australia", "sequenceNumber": 9 }, { "optionCode": "AI", "optionName": "Asia", "sequenceNumber": 10 }, { "optionCode": "AS", "optionName": "North America", "sequenceNumber": 11 }, { "optionCode": "EU", "optionName": "Europe", "sequenceNumber": 12 }, { "optionCode": "OH", "optionName": "Others", "sequenceNumber": 18 }], "type": "P" }, { "preferenceCode": 3, "preferenceName": "Movie Preference", "preferenceQuestion": "What movies do you like to watch?", "preferenceType": "B", "fieldType": "TF", "mandatory": false, "displayOrder": 17, "preferenceInputOption": [], "type": "P" }, { "preferenceCode": 4, "preferenceName": "Meal Preference", "preferenceQuestion": "What meal do you prefer?", "preferenceType": "M", "fieldType": "B", "mandatory": false, "displayOrder": 18, "preferenceInputOption": [{ "optionCode": "VG", "optionName": "Veg", "sequenceNumber": 4 }, { "optionCode": "NV", "optionName": "Non-Veg", "sequenceNumber": 5 }], "type": "P" }, { "preferenceCode": 7, "preferenceName": "Book Preference", "preferenceQuestion": "How do you often book your travel?", "preferenceType": "B", "fieldType": "R", "mandatory": false, "displayOrder": 19, "preferenceInputOption": [{ "optionCode": "AW", "optionName": "Airline Website", "sequenceNumber": 14 }, { "optionCode": "AY", "optionName": "Agency", "sequenceNumber": 15 }, { "optionCode": "OA", "optionName": "OTA", "sequenceNumber": 16 }, { "optionCode": "OS", "optionName": "Others", "sequenceNumber": 17 }], "type": "P" }] }, { "groupName": "Card Preference", "memberPreferenceDetails": [{ "preferenceCode": 6, "preferenceName": "Card Preference", "preferenceQuestion": "Card Preference", "preferenceType": "C", "fieldType": "B", "mandatory": false, "displayOrder": 20, "preferenceInputOption": [{ "optionCode": "P", "optionName": "Physical Card", "sequenceNumber": 2 }, { "optionCode": "D", "optionName": "Digital Card", "sequenceNumber": 3 }], "type": "P" }] }], "memberDynamicAttributes": [] } }
                    mockServiceResponse(RESPONSE_ADDITIONAL_DETAILS, 200)
                    return store.dispatch(fetchAdditionalDetails(newState.configurationReducer.preference.additionalDetailsType))
                        .then(() => {
                            rootComponent.update()
                            newState = store.getState()
                            expect(newState.masterData.memberPreferenceDetails).toBe(RESPONSE_ADDITIONAL_DETAILS.object.memberPreferences)

                            const RESPONSE_MEMBER_PROFILE = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "isAccrualValid": "NA", "isRedemptionValid": "NA", "memberAccount": { "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010976", "accountStatus": "Active", "accountStatusCode": "A", "enrolmentSource": "W", "enrolmentDate": "13-Oct-2020 00:00:00", "accountPeriodType": "O", "accountExpiryinMonths": 0, "extendToDay": "0", "extendToMonth": "0", "tier": "SIL", "tierFromDate": "01-Oct-2020", "tierToDate": "31-Jan-2022", "memberProfile": { "companyCode": "IBS", "membershipNumber": "IM0008010976", "membershipType": "I", "membershipStatus": "Active", "membershipStatusCode": "A", "enrollmentSource": "W", "customerPassword": "8D17CB61446744384230ECB80F260C518E287AA7", "individualInfo": { "memberNationality": "IN", "preferredLanguage": "EN", "preferredAddress": "H", "preferredEmailAddress": "H", "preferredPhoneNumber": "HP", "title": "MR", "givenName": "Deepak", "familyName": "Kumar", "displayName": "Deepak Kumar", "initials": "-Not Specified", "gender": "M", "dateOfBirth": "01-Jan-1992", "countryOfResidence": "IN", "companyName": "UnknownCmp", "industryType": "N", "incomeBand": "2", "memberContactInfos": [{ "addressType": "B", "zipCode": "1604001", "addressInvalid": false, "emailAddress": "test@test.com" }, { "addressType": "H", "addressLine1": "test address value", "addressLine2": "add", "country": "IN", "zipCode": "160-4001", "addressInvalid": false, "emailAddress": "deepakKumar@test.com", "mobileNumber": "123456", "emailAddressStatus": "V" }] } }, "memberPreferences": [{ "preferenceCode": 38, "sequenceNumber": 1, "preferenceValue": "EL", "type": "P" }], "memberDynamicAttributes": [{ "attributeGroupName": "Security Details", "attributeCode": "19", "groupInstanceID": "1", "attributeValue": "mother", "type": "P" }, { "attributeGroupName": "English Name", "attributeCode": "23", "groupInstanceID": "1", "attributeValue": "Thalaivarey", "type": "P" }, { "attributeGroupName": "Security Details", "attributeCode": "18", "groupInstanceID": "1", "attributeValue": "MN", "type": "P" }, { "attributeGroupName": "User Id", "attributeCode": "68", "groupInstanceID": "1", "attributeValue": "Deepak", "type": "C" }], "accrualSegment": [] }, "memberArtefactDetail": [{ "artefactIdentifier": "1", "artefactType": "C", "artefactStatus": "P", "statusChangeDate": "03-Sep-2020 15:01:29", "statusStartDate": "03-Sep-2020 15:01:29", "userCode": "SYSTEM" }] } }
                            mockServiceResponse(RESPONSE_MEMBER_PROFILE, 200)
                            return store.dispatch(fetchProfileData())
                                .then(() => {
                                    rootComponent.update()
                                    newState = store.getState()
                                    expect(newState.profileDataReducer.profileData).toBe(RESPONSE_MEMBER_PROFILE.object)
                                })
                        })
                })
        });

        afterEach(() => {
            moxios.uninstall()
        })

        test('Update "Travel Preferences"', () => {
            //Clicked Travel Preferences tab
            const tabTravelPreferences = findByTestAttr(rootComponent, "Travel Preference")
            tabTravelPreferences.simulate('click')
            rootComponent.update()

            //radiobutton 
            const radiobutton = findByTestAttr(rootComponent, "0-0")
            radiobutton.prop('onChange')({ target: { value: "SS" } })
            rootComponent.update()

            //checkbox
            const checkbox = findByTestAttr(rootComponent, "1-0")
            checkbox.prop('onChange')({ target: { checked: true } })
            rootComponent.update()

            //textField
            const textField = findByTestAttr(rootComponent, "2")
            textField.prop('onChange')({ target: { value: "test text" } })
            rootComponent.update()

            //textField
            const dropdown = findByTestAttr(rootComponent, "3")
            dropdown.prop('onChange')({ target: { value: "VG" } })
            rootComponent.update()

            //save
            const saveButton = findByTestAttr(rootComponent, "save")
            saveButton.simulate('click')
            const RESPONSE_PREFERENCE_UPDATE = {"statuscode":"200","statusMessage":"SUCCESS","object":{"memberActivityStatus":{"companyCode":"IBS","programCode":"PRG14","membershipNumber":"IM0008010976","accountStatus":"A","activityNumber":"NIL","activityStatus":"P","pointDetails":[]},"pointDetail":[]}}
            mockServiceResponse(RESPONSE_PREFERENCE_UPDATE, 200)
            return store.dispatch(performSavePreference({}))
                .then(() => {
                    rootComponent.update()
                    const newState = store.getState()
                    expect(newState.preferenceUpdateReducer.preference).toBe(RESPONSE_PREFERENCE_UPDATE.object)
                })
        })
        test('Update "Sports Preferences"', () => {

            //Clicked Sports tab
            const tabTravelPreferences = findByTestAttr(rootComponent, "Sports")
            tabTravelPreferences.simulate('click')
            rootComponent.update()

            //textArea check
            const textArea = findByTestAttr(rootComponent, "0")
            textArea.prop('onChange')({ target: { value: "test text" } })
            rootComponent.update()

            //save
            const saveButton = findByTestAttr(rootComponent, "save")
            saveButton.simulate('click')
            const RESPONSE_PREFERENCE_UPDATE = {"statuscode":"200","statusMessage":"SUCCESS","object":{"memberActivityStatus":{"companyCode":"IBS","programCode":"PRG14","membershipNumber":"IM0008010976","accountStatus":"A","activityNumber":"NIL","activityStatus":"P","pointDetails":[]},"pointDetail":[]}}
            mockServiceResponse(RESPONSE_PREFERENCE_UPDATE, 200)
            return store.dispatch(performSavePreference({}))
                .then(() => {
                    rootComponent.update()
                    const newState = store.getState()
                    expect(newState.preferenceUpdateReducer.preference).toBe(RESPONSE_PREFERENCE_UPDATE.object)
                })
        })
    })

})