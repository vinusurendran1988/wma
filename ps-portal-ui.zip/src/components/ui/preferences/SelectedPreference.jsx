import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withSuspense } from '../../common/utils';
import { withTranslation } from 'react-i18next';
import FieldBank from '../../common/components/fieldbank/index'
import { KEY_DISPLAYORDER, MESSAGE_TYPE_SUCCESS, MESSAGE_TYPE_DANGER, UPDATE_PREFERENCE_BTN } from './Constants';
import {
    FIELDTYPE_CHECKBOXGROUP,
    FIELDTYPE_TEXTAREA,
    FIELDTYPE_TEXTFIELD
} from '../../common/components/fieldbank/Constants';
import {
    getItemFromBrowserStorage,
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
    BROWSER_STORAGE_KEY_COMPANY_CODE, 
    BROWSER_STORAGE_KEY_PROGRAM_CODE
} from '../../common/utils/storage.utils';
import { performSavePreference } from './actions'
import Button from '../../common/components/fieldbank/Button';

/**
 * @name SelectedPreference
 * @description Preference display based on tab selection.
 * @author Ajmal Aliyar
 */
class SelectedPreference extends Component {
    constructor(props) {
        super(props);
        this.state = {
            fieldsToDisplay: [],
            memberPreferences: this.props.memberPreferences
        }
        this.handleSaveButtonClick = this.handleSaveButtonClick.bind(this)
    }

    componentDidMount() {
        this.prepareFieldsToDisplay()
    }

    componentDidUpdate(prevProps, prevState) {
        const { pageContent, preferenceUpdate, t, memberPreferences } = this.props
        if (
            prevProps.pageContent !== pageContent
        ) {
            this.prepareFieldsToDisplay()
        }

        if (prevProps.preferenceUpdate !== preferenceUpdate) {
            this.broadcastMessage(preferenceUpdate ? [t('preferences.message_preferrence_updated')] : [])
        }

        if (prevProps.memberPreferences != memberPreferences) {
            this.setState({ memberPreferences: memberPreferences })
        }

        if (prevState.memberPreferences != this.state.memberPreferences) {
            this.prepareFieldsToDisplay()
        }

        if (this.props.error) {
            if (this.props.error != prevProps.error) {
                this.broadcastMessage(this.props.error, MESSAGE_TYPE_DANGER)
            }
        }
    }

    broadcastMessage(messages = [], status = MESSAGE_TYPE_SUCCESS) {
        this.props.handleMessageChange(messages, status)
    }

    sortListByValueOf(list, key) {
        return list.sort((a, b) =>
            (a[key] > b[key]) ? 1 : -1
        )
    }

    prepareFieldsToDisplay() {
        let fieldsToDisplay = []
        const { pageContent, selectedTab } = this.props
        if (pageContent.memberPreferenceDetails && pageContent.memberPreferenceDetails.length) {
            // Sorting based on displayOrder of fields
            const sortedFields = this.sortListByValueOf(this.props.pageContent.memberPreferenceDetails, KEY_DISPLAYORDER)

            // Create renderable array from the received data
            fieldsToDisplay = sortedFields.map((field) => {
                const fieldType = field.fieldType
                const label = field.preferenceQuestion
                const isRequired = field.mandatory
                const id = `${selectedTab}_${field.preferenceCode}`
                const options = this.populateOptions(field)
                const value = this.setValueIfPresent(field)
                const enabled = field.enabled!=undefined?field.enabled: true
                const onChange = (updatedValue) => this.handleOnChangeInField(
                    updatedValue,
                    field.preferenceCode,
                    field.preferenceInputOption,
                    field.type,
                    fieldType,
                    field
                )

                return {
                    label,
                    fieldType,
                    options,
                    isRequired,
                    id,
                    value,
                    enabled,
                    onChange
                }
            })
            this.setState({
                fieldsToDisplay
            })
        }
    }

    setValueIfPresent(field) {
        let value = ""
        const { memberPreferences } = this.state
        const existingMatchingPreferences = memberPreferences.filter(preference => {
            return preference.preferenceCode == field.preferenceCode
        })
        if (field.fieldType == FIELDTYPE_CHECKBOXGROUP) {
            value = existingMatchingPreferences.map(pref => { return pref.preferenceValue })
        } else {
            if (existingMatchingPreferences.length == 1) {
                value = existingMatchingPreferences[0].preferenceValue
            }
        }
        return value
    }

    populateOptions(field) {
        let options = []
        if (field.preferenceInputOption && field.preferenceInputOption.length) {
            options = field.preferenceInputOption.map(option => {
                return {
                    label: option.optionName,
                    value: option.optionCode,
                    id: `${field.preferenceCode}`
                }
            })
        }
        return options
    }

    handleOnChangeInField(value, preferenceCode, options, type, fieldType) {
        
        this.broadcastMessage()

        const { memberPreferences } = this.state
        let availableOptions = []
        let preferenceListToBeAdded = []

        switch (fieldType) {
            case FIELDTYPE_TEXTAREA:
            case FIELDTYPE_TEXTFIELD:
                preferenceListToBeAdded.push(this.createPreferenceObject(
                    preferenceCode,
                    value,
                    type,
                    fieldType))
                break;
            default:
                availableOptions = this.getAvailableOptions(options, value)
                availableOptions.forEach(option => {
                    preferenceListToBeAdded.push(this.createPreferenceObject(
                        preferenceCode,
                        option.optionCode,
                        type,
                        fieldType))
                })
        }
        //Remove if preferenceValue is empty
        preferenceListToBeAdded = preferenceListToBeAdded.filter(preference => {
            return preference.preferenceValue
        })
        //Remove preferences with the preferenceCode in question
        let filteredMemberPreferences = memberPreferences.filter(preference => {
            return preference.preferenceCode != preferenceCode
        })
        //Concatenate both        
        let updatedPreferenceList = filteredMemberPreferences.concat(preferenceListToBeAdded)
        updatedPreferenceList.filter(preference => {
            return preference.preferenceCode
        })
        this.setState({ memberPreferences: updatedPreferenceList })
    }

    createPreferenceObject(preferenceCode, preferenceValue, type, fieldType) {
        const preferenceObject = {
            preferenceCode: preferenceCode,
            preferenceValue: preferenceValue,
            type: type,
            fieldType: fieldType
        }
        return preferenceObject
    }

    getAvailableOptions(options, value) {

        if (Array.isArray(value)) {
            return options.filter(option => {
                return value.includes(option.optionCode)
            })
        } else {
            return options.filter(option => {
                return value == option.optionCode
            })
        }
    }

    handleSaveButtonClick() {
        const { memberPreferences } = this.state
        const payload = {
            object: {
                companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                memberPreferences: memberPreferences
            }
        }
        this.props.performSavePreference(payload, UPDATE_PREFERENCE_BTN)
    }

    render() {
        const { pageContent, t ,checkboxGroupClassName } = this.props
        const { fieldsToDisplay } = this.state

        return (
            <>
                <div className="tabWrap">
                    <h2 className="mb-4">{pageContent.groupName}</h2>
                    {
                        fieldsToDisplay &&
                            fieldsToDisplay.length
                            ? fieldsToDisplay.map((properties, index) => {
                                properties.label ="";
                                properties.label = pageContent.groupName == properties.label?"":properties.label;
                                properties.checkboxGroupClassName = checkboxGroupClassName;
                                return <FieldBank
                                    key={index}
                                    field={properties}
                                    testIdentifier={`${index}`}
                                />
                            })
                            : <p>{t('preferences.no_preferences_found')}</p>
                    }
                </div>
                <div className="col-12 text-right buttonWrap">
                    <Button
                        className="btn btn-primary" 
                        handleOnClick={() => this.handleSaveButtonClick()} 
                        id={UPDATE_PREFERENCE_BTN} 
                        data-test="save" 
                        label={t("preferences.save_button")} />
                </div>

            </>
        )

    }
}

SelectedPreference.propTypes = {

};

const mapStateToProps = (state) => {
    return {
        preferenceUpdate: state.preferenceUpdateReducer.preference,
        error: state.commonErrorReducer.error
    }
}

const mapDispatchToProps = {
    performSavePreference
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(SelectedPreference)));
