import React from "react";
import { withTranslation } from 'react-i18next';
import { getFormattedDate } from "../../common/utils";
import { DATE_FORMAT_DMMMYYYY_WITH_SPACE } from "./Constants";
import Custommessage from "../../common/components/custommessage";
import parse from 'html-react-parser';
import { SELECT_MEMBERSHIP, trackData } from "../../common/utils/analytics.utils"

const ProductList = (props) => {
    const { status, t, productList, configSection,standAlonePurchaseFlag,config } = props
    const checkProratedMembershipStatus = (chargeHeadCode)=>{
        if(config.proratedChargeHeadCodes.includes(chargeHeadCode)){
            return true;
        }else{
            return false;
        }
    }
    return (
         
        <div className="col-lg-12">
            {!standAlonePurchaseFlag && configSection && configSection.fields &&
                <div>
                {productList && productList[0] && productList[0].commonExpiryDate && productList[0].hasCommonExpiry == "Y" && checkProratedMembershipStatus(productList[0].productReferenceCode) &&
                    <div>
                        <Custommessage
                            type={"info"}
                            message={[parse(t('subscription.productList.commonExpiryBannerMsg').replace('${COMMON_EXPIRY_DATE}',getFormattedDate(productList[0].commonExpiryDate, "D MMMM") ))]}
                            canTranslate={false}
                        />
                    </div>
                }
                    {configSection.fields.title && configSection.fields.title.visibility &&
                        <h2>Select membership</h2>
                    }
                    <div className="row">
                        {configSection.fields.contentBody && configSection.fields.contentBody.visibility && productList && productList.map((product, index) => {
                            return (
                                <div className={configSection.fields.contentBody.className ? configSection.fields.contentBody.className : "col-lg-4"}>
                                    <div className={`card membership ${product.isSelected && "membership--selected"} ${status && "membership--inactive"}`}>
                                        <div className="card-body">
                                            <div className="radio">
                                                <label className="rContainer">
                                                    <input
                                                        checked={product.isSelected}
                                                        data-test="prod-radio-btn"
                                                        onChange={() => {trackData(SELECT_MEMBERSHIP, [product, t(`productName.${product.i18nCode}`)]); props.onPackSelected(index, product)}}
                                                        disabled={status}
                                                        type="radio" name="radio"
                                                        aria-labelledby="pack1" />
                                                    <span className="checkmark"></span>
                                                </label>
                                            </div>
                                            {!checkProratedMembershipStatus(product.productReferenceCode) &&
                                                <h5 className="membership__heading">{product.duration}</h5>
                                            }
                                            <div className="membership__validity">{t(`productName.${product.i18nCode}`).replace(product.duration, "").trim()}</div>
                                            <h6 className="membership__date">
                                                {t("digital_card.expiry.validTo").replace("{EXPIRY_DATE}", getFormattedDate(checkProratedMembershipStatus(product.productReferenceCode)?product.commonExpiryDate:product.endDate, DATE_FORMAT_DMMMYYYY_WITH_SPACE))}
                                            </h6>
                                            {product.price && <div className="membership__fees">
                                                <div> <strong>{t('subscription.productList.joinFee')}</strong>
                                                    {!checkProratedMembershipStatus(product.productReferenceCode) ? 
                                                        <div>
                                                            {product.price && product.price.latestFee != 0 && '$'+product.price.latestFee} 
                                                            &nbsp;
                                                            {product.price.originalFee != product.price.latestFee && <strike style={{color : '#a9a9a9'}}>${product.price.originalFee}</strike>}
                                                        </div> : 
                                                        <div>{product.price && '$'+product.price.latestFee}</div> 
                                                    }
                                                </div>
                                                <div> <strong>{t('subscription.productList.cost')}</strong>
                                                    {!checkProratedMembershipStatus(product.productReferenceCode) ?
                                                        <div>
                                                            {product.price && product.price.latestCost != 0 && '$'+product.price.latestCost} 
                                                            &nbsp; 
                                                            {product.price.originalCost != product.price.latestCost && <strike style={{color : '#a9a9a9'}}>${product.price.originalCost}</strike>}
                                                        </div> :
                                                        <div>{product.price && '$'+product.price.latestCost} </div>
                                                    }
                                                </div>
                                            </div>}
                                            {checkProratedMembershipStatus(product.productReferenceCode)  && <div className="membership__fees membership__fees--total">
                                                <div> <strong>{t('subscription.productList.total')}</strong>
                                                    <div>${product.price && product.price.latestTotal}</div>
                                                </div>
                                            </div>}
                                            {!product.showDiscount && !checkProratedMembershipStatus(product.productReferenceCode)  && <div className="membership__fees membership__fees--total">
                                                <div> <strong>{t('subscription.productList.total')}</strong>
                                                    <div>${product.price && product.price.latestTotal}</div>
                                                </div>
                                            </div>}
                                            {product.showDiscount && !checkProratedMembershipStatus(product.productReferenceCode)  && <div className="membership__fees membership__fees--total membership__fees--offer">
                                                <div> 
                                                    <strong>{t('subscription.productList.total')}</strong>
                                                    <div>${product.price && product.price.latestTotal}</div>
                                                    <div className=" membership__fees--offer__text">
                                                        {/* <span>{t('subscription.productList.deal')}</span> */}
                                                        {t('subscription.productList.save')} ${product.price && product.price.discountValue}
                                                    </div>
                                                </div>
                                            </div>}
                                        </div>
                                    </div>
                                </div>
                            )
                        })}
                    </div>
                </div>
            }

        </div>);
}

export default withTranslation()(ProductList)