import { mount } from 'enzyme';
import moxios from 'moxios';
import React, * as reactModule from 'react';
import ReactTestUtils from 'react-dom/test-utils';
import { Provider } from 'react-redux';
import { _URL_PRODUCT_LIST } from '../../common/config/config';
import { findComponent, mockServiceResponse } from '../../common/testUtils';
import { testStore } from '../../common/utils';
import { axiosInstance } from '../../common/utils/api';
import { getProductDetails } from './actions';
import Subscription from './index';
import PlanSummary from './PlanSummary';
import ProductList from './ProductList';

var store = testStore({})
let rootComponent;
let productListComponent;
let planSummaryComponent;
let component;
let rootComponentChild
let rootComponentProductListChild
let rootComponentPlanSummaryChild

const setUp = (props = {}, isDefaultConfig = false) => {
    props.resetError = jest.fn();
    props.setPageInfo = jest.fn();
    props.setError = jest.fn();
    window.location = jest.fn();
    rootComponent = mount(<Provider store={store}>
        <Subscription {...props} />
    </Provider>);

    component = findComponent(rootComponent, 'Subscription');
    let setCartItem = jest.fn(x => CART_ITEM)
    reactModule.useState = jest
        .fn()
        .mockImplementationOnce(x => [x, setCartItem])
};

const setUpPlanSummary = (props) => {
    rootComponentPlanSummaryChild = mount(
        <Provider store={store}>
            <PlanSummary {...props} />
        </Provider>
    );
    planSummaryComponent = findComponent(rootComponentPlanSummaryChild, 'PlanSummary');
};

const setUpProductList = (props) => {
    props.product = PRODUCT_LIST_RESPONSE.object.productDetails
    props.ageMessage = {}
    rootComponentProductListChild = mount(
        <Provider store={store}>
            <ProductList {...props} />
        </Provider>
    );
    productListComponent = findComponent(rootComponentProductListChild, 'ProductList');
};

const updateComponents = () => {
    rootComponent = rootComponent.update()
    rootComponentPlanSummaryChild = rootComponentPlanSummaryChild.update()
    rootComponentProductListChild = rootComponentProductListChild.update()
    component = findComponent(rootComponent, 'Subscription');
    planSummaryComponent = findComponent(rootComponentPlanSummaryChild, 'PlanSummary');
    productListComponent = findComponent(rootComponentProductListChild, 'ProductList');


}

describe('Subscription Page : Should render the page', () => {
    beforeEach(() => {
        store = undefined
        store = testStore({})
        moxios.install(axiosInstance);

    });

    afterEach(() => {
        moxios.uninstall(axiosInstance);
    });

    it('Should get the list of products by calling the product-list api', () => {
        setUp({});
        setUpPlanSummary({})
        setUpProductList({})
        moxios.stubRequest(_URL_PRODUCT_LIST, {
            status: 200,
            responseText: PRODUCT_LIST_RESPONSE
        })
        mockServiceResponse(PRODUCT_LIST_RESPONSE)
        return ReactTestUtils.act(() => {
            return store.dispatch(getProductDetails({}))
                .then(() => {
                    let newState = store.getState();
                    expect(newState.subscriptionReducer.productDetails).toBe(PRODUCT_LIST_RESPONSE.object);
                    updateComponents();

                })
        })
    })

    it('Should handle error case', () => {
        setUp({});
        setUpPlanSummary({})
        setUpProductList({})
        updateComponents()
        moxios.stubRequest(_URL_PRODUCT_LIST, {
            status: 500,
            responseText: PRODUCT_LIST_ERROR_RESPONSE
        })
        mockServiceResponse(PRODUCT_LIST_ERROR_RESPONSE, 500)
        return ReactTestUtils.act(() => {
            return store.dispatch(getProductDetails({}))
                .then(() => {
                    const newState = store.getState();
                    expect(newState.subscriptionReducer.productDetails).toBeUndefined()
                    updateComponents()
                })

        })
    })

    it('Should call Plan Summary', () => {

        setUp({});
        setUpPlanSummary({})
        setUpProductList({})
        const myInitialState = 'My Initial State'
        updateComponents()
   
        moxios.stubRequest(_URL_PRODUCT_LIST, {
            status: 200,
            responseText: PRODUCT_LIST_RESPONSE
        })
        mockServiceResponse(PRODUCT_LIST_RESPONSE, 200)
        return ReactTestUtils.act(() => {
            return store.dispatch(getProductDetails({}))
                .then(() => {
                    const newState = store.getState();
                    updateComponents()
                })

        })
    })



})


const PRODUCT_LIST_RESPONSE = { "object": { "companyCode": "NZ", "programCode": "KORU", "membershipNumber": "1001825", "productDetails": [{ "id": "3", "type": "product", "name": "Enrol Individual Membership 1 year", "description": null, "startDate": "15 Sep 2021", "endDate": "30 Sep 2022", "duration": 1, "i18nCode": "join_main_pr-1", "price": { "interval": null, "currency": null, "originalFee": 255, "originalCost": 629, "latestFee": 255, "latestCost": 629, "latestTotal": 884 } }, { "id": "2", "type": "product", "name": "Enrol Individual  Membership 2 year", "description": null, "startDate": "15 Sep 2021", "endDate": "30 Sep 2023", "duration": 2, "i18nCode": "join_main_pr-2", "price": { "interval": null, "currency": null, "originalFee": 255, "originalCost": 1109, "latestFee": 255, "latestCost": 1109, "latestTotal": 1364 } }, { "id": "1", "type": "product", "name": "Enrol Individual  Membership 5 year", "description": null, "startDate": "15 Sep 2021", "endDate": "30 Sep 2026", "duration": 5, "i18nCode": "join_main_pr-3", "price": { "interval": null, "currency": null, "originalFee": 255, "originalCost": 2549, "latestFee": 255, "latestCost": 2549, "latestTotal": 2804 } }], "userMessageDetailList": [{ "code": "SUBSCRIPTION_TIER_MSG", "value": null, "purchaseAllowed": true }] } }
const PRODUCT_LIST_ERROR_RESPONSE = { "statuscode": "500", "statusMessage": "FAILURE", "error": { "code": "500", "type": "INTERNAL_SERVER_ERROR", "message": "Retrieve renew or expiry point details failed", "errorDetails": [{ "message": "Member with no expired points" }] } }
const CART_ITEM = { "membership": { "id": "3", "type": "product", "name": "Enrol Individual Membership 1 year", "description": null, "startDate": "15 Sep 2021", "endDate": "30 Sep 2022", "duration": "1 year", "i18nCode": "join_main_pr-1", "price": { "interval": null, "currency": null, "originalFee": 255, "originalCost": 629, "latestFee": 255, "latestCost": 629, "latestTotal": 884, "originalTotal": 884 }, "isSelected": true, "showDiscount": false } }