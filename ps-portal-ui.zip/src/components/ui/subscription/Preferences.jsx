import React, { useEffect } from "react";
import { withTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { getAddOns } from "./actions";
import { getOnBehalfEmployeeDetails, isOnBehalfAdminEnrolment} from "./Services/CommonUtils"
import { 
  BROWSER_STORAGE_KEY_COMPANY_CODE, 
  BROWSER_STORAGE_KEY_PROGRAM_CODE, 
  BROWSER_STORAGE_KEY_DEFAULT_PROGRAM_CODE,
  BROWSER_STORAGE_KEY_MEMBERSHIP_NO, 
  getItemFromBrowserStorage, 
} from "../../common/utils/storage.utils";

const Preferences = (props) => {
    const { t, status, configSection, standAlonePurchaseFlag } = props
    const cartItems = useSelector(state => state.cartReducer.cartDetails)
    const memType = useSelector(state => state.membershipTypeReducer.type)
    const onBehalfEmployee = getOnBehalfEmployeeDetails();

    const addOnDetails = useSelector(state => state.subscriptionReducer.addOnDetails)
    const addOnItems = getItemsFromCart("addOn", cartItems)

    const [selectedPreferences, setselectedPreferences] = React.useState({})
    let isPreferenceSelected = false
    if (addOnItems && Object.keys(addOnItems).length > 0 && addOnItems.isSelected) {
        isPreferenceSelected = addOnItems.isSelected
        if (JSON.stringify(selectedPreferences) != JSON.stringify(addOnItems)) {
            setselectedPreferences(addOnItems)
        }
    }
    const dispatch = useDispatch()

    useEffect(() => {
        if (!addOnDetails) {
            dispatch(getAddOns({
                "object": {
                    "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                    "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_DEFAULT_PROGRAM_CODE),
                    "membershipNumber": isOnBehalfAdminEnrolment() ? onBehalfEmployee.membershipNumber : getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                    "activityCode": "RBT",
                    "flowType":memType
                }
            }))
        }
    }, []);

    return (
        <>
            {configSection && configSection.fields &&
                <div className="col-lg-12">
                    {configSection.fields.title && configSection.fields.title.visibility &&
                        <h2 >{t(`subscription.preferences.${standAlonePurchaseFlag?'stanaloneTitle':'title'}`)} <span>{standAlonePurchaseFlag?"":t('subscription.preferences.subTitle')}</span></h2>
                    }
                    <div className="row">
                        {configSection.fields.contentBody && configSection.fields.contentBody.visibility &&  addOnDetails && addOnDetails.productDetails &&
                            addOnDetails.productDetails.map(addOnDetail => {
                                return (<div className="col-lg-4">
                                    <div className={`card preferences preferences--with-img  ${selectedPreferences.id == addOnDetail.id &&
                                        JSON.stringify(addOnItems) == JSON.stringify(selectedPreferences)
                                        ? "preferences--selected" : ""}`}> 
                                        <img src="images/card-img-mob.png" class="card-img-top card__img--mobile" alt="..."/>
                                        <img src="images/bagtag.jpg" className="card-img-top card__img--web" alt="..." />
                                        <div className="card-body">
                                            <div>
                                                <div className="preferences__rate">${addOnDetail.price && addOnDetail.price.latestCost}</div>
                                                <h5 className="preferences__title"> {t(`addOnName.${addOnDetail.i18nCode}`)}</h5>
                                                <a onClick={() => {
                                                    setselectedPreferences(addOnDetail)
                                                    props.selectedPreferences(addOnDetail)
                                                }}
                                                    className={`btn btn-outline-primary preferences__btn  ${status ? "disabled" : ""}`}>
                                                    {selectedPreferences.id == addOnDetail.id &&
                                                        JSON.stringify(addOnItems) == JSON.stringify(selectedPreferences) ?
                                                        <> Selected &nbsp;
                                                            < svg aria-hidden="true" focusable="false" data-prefix="fal" data-icon="check" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" className="svg-inline--fa fa-check fa-w-14 fa-2x">
                                                                <path fill="currentColor" d="M413.505 91.951L133.49 371.966l-98.995-98.995c-4.686-4.686-12.284-4.686-16.971 0L6.211 284.284c-4.686 4.686-4.686 12.284 0 16.971l118.794 118.794c4.686 4.686 12.284 4.686 16.971 0l299.813-299.813c4.686-4.686 4.686-12.284 0-16.971l-11.314-11.314c-4.686-4.686-12.284-4.686-16.97 0z" className=""></path>
                                                            </svg>
                                                        </>
                                                        :
                                                        "Select"}
                                                </a> </div>
                                        </div>
                                    </div>
                                </div>)
                            })}

                    </div>
                </div>
            }
        </>
    );
}

const getItemsFromCart = (itemType, cartItems) => {
    const items = cartItems && Object.keys(cartItems).length > 0 &&
        cartItems[itemType]
    return items
}

export default withTranslation()(Preferences)
