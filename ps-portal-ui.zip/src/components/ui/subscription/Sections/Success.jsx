import React, { useState, useEffect, useContext } from "react";
import ReactDOM from 'react-dom'
import { useLocation } from 'react-router-dom'
import { useHistory } from "react-router-dom";
import { NAVIGATE_CLUB_OVERVIEW } from '../../../common/utils/urlConstants';
import { withTranslation } from 'react-i18next';
import { isEmptyOrSpaces, withSuspense } from '../../../common/utils';
import { connect, useSelector, useDispatch } from 'react-redux';
import { addToCart, removeFromCart, doEnrollment, acceptPayment, getProfileDetails, getOverviewData } from "../actions";
import { BROWSER_STORAGE_KEY_COMPANY_CODE, BROWSER_STORAGE_KEY_DEFAULT_PROGRAM_CODE, BROWSER_STORAGE_KEY_MEMBERSHIP_NO_ANZ, BROWSER_STORAGE_KEY_PROGRAM_CODE, BROWSER_STORAGE_KEY_TOKEN, getItemFromBrowserStorage, setItemToBrowserStorage } from "../../../common/utils/storage.utils";
import { CONFIG_SECTION_SUBSCRIPTION } from "../../../common/utils/Constants";
import { fetchConfiguration, fetchCurrentLoginUserData, fetchNewToken } from "../../../common/middleware/redux/commonAction";
import DigitalCard from "../../../common/components/fieldbank/DigitalCard";
import { getDigitalCardDetails } from "../Services/DigitalCardUtils";
import { FLOW_TYPE, STANDALONE } from "../Constants";
import Custommessage from "../../../common/components/custommessage";
import parse from 'html-react-parser';
import { getOnBehalfEmployeeDetails, isOnBehalfAdminEnrolment} from "../Services/CommonUtils"
import { 
  PAYMENT_BACK_TO_BENEFITS, 
  PAYMENT_UPDATE_EMAIL_ADDRESS_LINK, 
  PAYMENT_CALL_CENTRE_TEXT_LINK, 
  PAYMENT_UPDATE_ADDRESS_LINK,
  PAYMENT_ADD_ADDRESS_LINK,
  PAYMENT_VIEW_DIGITAL_CARD,
  PAYMENT_VIEW_KORU_PROFILE,
  trackData 
} from "../../../common/utils/analytics.utils"

const Success = (props) => {
  const [paymentStatus, setPaymentStatus] = useState(null);
  const [type, setType] = useState(null);
  const [isAddonOpted, setIsAddonOpted] = useState(null);
  const [isDeliveryAddressPresent, setDeliveryAddressPresentFlag] = useState(false);
  const [profileForDisplay, setProfileForDisplay] = useState(null);
  const dispatch = useDispatch();
  const location = useLocation();
  const history = useHistory();
  const profileData = useSelector(state => state.subscriptionReducer.profileData);
  const overviewDataResponse = useSelector(state => state.subscriptionReducer.overviewData)
  const newToken = useSelector(state => state.currentLoginUserDataReducer.newToken)

  const memType = getItemFromBrowserStorage(FLOW_TYPE)
  const onBehalfEmployee = getOnBehalfEmployeeDetails();
  const onBehalfMessageBannerText = isOnBehalfAdminEnrolment() ? "You’re purchasing this membership on behalf of <b>"+
                                    onBehalfEmployee.fname+" "+onBehalfEmployee.lname
                                    +"</b>.You’ll see details from their Airpoints profile in relation to this purchase." : "";


  useEffect(() => {
    document.body.className = "theme__one view__compact";
    const queryParams = new URLSearchParams(location.search);
    let status = queryParams.get('payment');
    let type = queryParams.get('type');
    setPaymentStatus(status);
    setType(type);

  }, []);

  useEffect(() => {
    if (paymentStatus == "success") {
      dispatch(fetchNewToken())
    }
  }, [paymentStatus])


  useEffect(() => {
    if (!isEmptyOrSpaces(newToken)) {
      console.log("New token generated :  ", newToken);
      dispatch(getProfileDetails(prepareProfileDataPayload()))
      getOverviewDetails()
      dispatch(fetchCurrentLoginUserData())
    }
  }, [newToken])

  useEffect(() => {
    if (typeof profileData != "undefined" && Object.keys(profileData).includes('status') && profileData.status == "success") {
      setProfileForDisplay(getFormattedAddress(profileData.response));
      setIsAddonOpted(getAddonStatus(profileData.response.memberAccount.memberDynamicAttributes))
    }
  }, [profileData])

  const { t } = props;

  /**
   * Request formation for profile fetch
   */
  const prepareProfileDataPayload = () => {
    return {
      "object": {
        "companyCode": "NZ",
        "programCode": "KORU",
        "membershipNumber": getItemFromBrowserStorage("membershipNumber")
      }
    }
  }

  /**
   * 
   */
  const getAddonStatus = (dynamicAttrs) => {
    let addon = dynamicAttrs.filter(data => data.attributeCode == 26 && data.attributeValue == "Yes")
    if (addon.length) {
      return true;
    } else {
      return false;
    }
  }

  const getOverviewDetails = () => {
    if (!overviewDataResponse || (overviewDataResponse && Object.keys(overviewDataResponse).length == 0)) {
      dispatch(getOverviewData({
        "object": {
          "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
          "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_DEFAULT_PROGRAM_CODE),
          "membershipNumber": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO_ANZ)
        }
      }))
    }
  }

  /**
   * Get formated address
   */
  const getFormattedAddress = (profile) => {
    let preferredAddressType = profile.memberAccount.memberProfile.individualInfo.preferredAddress;
    let preferredEmailType = profile.memberAccount.memberProfile.individualInfo.preferredEmailAddress;
    let addrArray = profile.memberAccount.memberProfile.individualInfo.memberContactInfos;
    let name = profile.memberAccount.memberProfile.individualInfo.displayName;
    let address = {};
    let email = "";
    addrArray.forEach((addr) => {
      if (addr.addressType == preferredAddressType) {
        address.country = addr.country
        address.state = addr.state
        address.zip = addr.zipCode
        address.city = addr.city
        address.district = addr.district
        address.streetNumber = addr.streetNumber
        address.addressLine2 = addr.addressLine2
        address.addressLine1 = addr.addressLine1
      }
      if (addr.addressType == preferredEmailType) {
        email = addr.emailAddress;
      }
    })
    if (address && Object.keys(address).length) {
      let addrWithValue = Object.values(address).filter(x => {if(x != null && x != "" && x != undefined)  return x} );
      const isAddressMissing = addrWithValue.length;
      if(!isAddressMissing){
        setDeliveryAddressPresentFlag(true)
      }
    }
    return { address: address, email: email, name: name }
  }


  /**
   * 
   */
  const goToOverview = () => {
    window.location = `#${NAVIGATE_CLUB_OVERVIEW}`;
  }
  const gotToBenefit = () => {
    trackData(PAYMENT_BACK_TO_BENEFITS, {})
    window.location.assign('https://www.airnewzealand.co.nz/vloyalty/action/mybenefits');
  }
  
  if (!digitalCardObject || digitalCardObject && Object.keys(digitalCardObject).length == 0) {
    var digitalCardObject = overviewDataResponse && overviewDataResponse.response &&
      overviewDataResponse.response && getDigitalCardDetails(overviewDataResponse.response, t)
  }

  return (
    <main role="main" id="content" class="container member-plan cart-view">

      {digitalCardObject &&
        <DigitalCard id="digital-card-modal"
          displayName={digitalCardObject.displayName}
          expiryMessage={digitalCardObject.expiryMessage}
          title={digitalCardObject.title}
          descriptionRequired={digitalCardObject.descriptionRequired}
          membershipType={digitalCardObject.membershipType}
          footerMessage={digitalCardObject.footerMessage}
          membershipNumber={digitalCardObject.membershipNumber} />
      }
      {/* {paymentStatus == "failed" && <ol class="cart-view__timeline">
        <li class="cart-view__timeline cart-view__timeline--first cart-view__timeline--active">Select a member</li>
        <li class="cart-view__timeline cart-view__timeline--active">Check out</li>
        <li class="cart-view__timeline cart-view__timeline--active cart-view__timeline--active">Payment</li>
        <li class="cart-view__timeline cart-view__timeline--last">Success</li>
      </ol>} */}
      {isOnBehalfAdminEnrolment() && paymentStatus == "failed" && 
        <>
          <br />
          <Custommessage
            type={"info"}
            message={[parse(onBehalfMessageBannerText)]}
            canTranslate={false}
          /><br />
        </>
      }
      <div>
        {paymentStatus == "success" && <h1>Koru membership</h1>}
        {paymentStatus == "failed" && <h1>Payment cancelled</h1>}
      </div>
      {paymentStatus == "success" && type != "renew" && !isOnBehalfAdminEnrolment() && 
        <div class="alert alert-success hide-fontawesome" role="alert">
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M6.99986 14.1727L3.53319 10.706C3.14291 10.3158 2.51014 10.3158 2.11986 10.706C1.72958 11.0963 1.72958 11.7291 2.11986 12.1194L6.29275 16.2923C6.68328 16.6828 7.31644 16.6828 7.70697 16.2923L18.2932 5.70604C18.6835 5.31576 18.6835 4.68299 18.2932 4.29271C17.9029 3.90243 17.2701 3.90243 16.8799 4.29271L6.99986 14.1727Z" fill="white" />
            <mask id="mask0_6869_9148" style={{maskType:"alpha"}} maskUnits="userSpaceOnUse" x="1" y="4" width="18" height="13">
              <path d="M6.99986 14.1727L3.53319 10.706C3.14291 10.3158 2.51014 10.3158 2.11986 10.706C1.72958 11.0963 1.72958 11.7291 2.11986 12.1194L6.29275 16.2923C6.68328 16.6828 7.31644 16.6828 7.70697 16.2923L18.2932 5.70604C18.6835 5.31576 18.6835 4.68299 18.2932 4.29271C17.9029 3.90243 17.2701 3.90243 16.8799 4.29271L6.99986 14.1727Z" fill="white" />
            </mask>
            <g mask="url(#mask0_6869_9148)"> </g>
          </svg>
          <h5>{memType == STANDALONE ? <strong>Purchase complete!</strong> : <strong>It’s great to have you on board, {profileForDisplay && profileForDisplay.name}!</strong>}</h5>
          {memType != STANDALONE &&
            <p>Your Koru membership purchase was successful, and your order confirmation is on its way to {profileForDisplay  && <strong>{profileForDisplay.email}</strong> } </p>
          }
          {profileForDisplay && 
          <div>
            <a onClick={() => { trackData(PAYMENT_UPDATE_EMAIL_ADDRESS_LINK, ["https://www.airnewzealand.co.nz/membership/profile/personalInfo/contactDetails"]); }} href="javascript:void(0)">Update email address</a>
          </div>
          }<br />
          {/* {memType != STANDALONE && <div>
            If you have not received your confirmation email please contact the <a onClick={() => { trackData(PAYMENT_CALL_CENTRE_TEXT_LINK, ["https://www.airnewzealand.co.nz/koru#contact_"]); }} href="javascript:void(0)">call centre</a>
          </div>}
          {memType == STANDALONE && <div>
            If you have not received your email and would like it resent please contact the <a onClick={() => { trackData(PAYMENT_CALL_CENTRE_TEXT_LINK, ["https://www.airnewzealand.co.nz/koru#contact_"]); }} href="javascript:void(0)">Koru contact centre</a>
          </div>} */}
          {memType != STANDALONE && <div>
            If you don’t receive your email confirmation in a few minutes, please check your junk folder or get in touch with the <a href='https://www.airnewzealand.co.nz/koru#contact' target='_blank'>Koru contact centre</a>.
            We look forward to seeing you on board and in our lounges soon. 
          </div>}
          </div>
      }

      {paymentStatus == "success" && type == "renew" && !isOnBehalfAdminEnrolment() &&
        <div class="alert alert-success hide-fontawesome" role="alert">
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M6.99986 14.1727L3.53319 10.706C3.14291 10.3158 2.51014 10.3158 2.11986 10.706C1.72958 11.0963 1.72958 11.7291 2.11986 12.1194L6.29275 16.2923C6.68328 16.6828 7.31644 16.6828 7.70697 16.2923L18.2932 5.70604C18.6835 5.31576 18.6835 4.68299 18.2932 4.29271C17.9029 3.90243 17.2701 3.90243 16.8799 4.29271L6.99986 14.1727Z" fill="white" />
          <mask id="mask0_6869_9148" style={{maskType:"alpha"}} maskUnits="userSpaceOnUse" x="1" y="4" width="18" height="13">
            <path d="M6.99986 14.1727L3.53319 10.706C3.14291 10.3158 2.51014 10.3158 2.11986 10.706C1.72958 11.0963 1.72958 11.7291 2.11986 12.1194L6.29275 16.2923C6.68328 16.6828 7.31644 16.6828 7.70697 16.2923L18.2932 5.70604C18.6835 5.31576 18.6835 4.68299 18.2932 4.29271C17.9029 3.90243 17.2701 3.90243 16.8799 4.29271L6.99986 14.1727Z" fill="white" />
          </mask>
          <g mask="url(#mask0_6869_9148)"> </g>
        </svg>
        <h5><strong>Thank you!</strong></h5>
        <p>You have successfully renewed your Koru membership. We look forward to seeing you onboard and in our lounges again soon.</p>
        {profileForDisplay && <div>
          <p style={{ marginBottom: "0px" }}>We have sent your order confirmation to</p>
          <strong>{profileForDisplay.email}</strong> <a onClick={() => {trackData(PAYMENT_UPDATE_EMAIL_ADDRESS_LINK, ["https://www.airnewzealand.co.nz/membership/profile/personalInfo/personalDetails"]);}} href="javascript:void(0)">Update link</a>
        </div>}<br />
        <div>
            If you don’t receive your email confirmation in a few minutes, please check your junk folder or get in touch with the <a href='https://www.airnewzealand.co.nz/koru#contact' target='_blank'>Koru contact centre</a>.
            We look forward to seeing you on board and in our lounges soon. 
        </div>
      </div>}

      {paymentStatus == "success" && isOnBehalfAdminEnrolment() &&
         <div class="alert alert-success hide-fontawesome" role="alert">
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M6.99986 14.1727L3.53319 10.706C3.14291 10.3158 2.51014 10.3158 2.11986 10.706C1.72958 11.0963 1.72958 11.7291 2.11986 12.1194L6.29275 16.2923C6.68328 16.6828 7.31644 16.6828 7.70697 16.2923L18.2932 5.70604C18.6835 5.31576 18.6835 4.68299 18.2932 4.29271C17.9029 3.90243 17.2701 3.90243 16.8799 4.29271L6.99986 14.1727Z" fill="white" />
            <mask id="mask0_6869_9148" style={{maskType:"alpha"}} maskUnits="userSpaceOnUse" x="1" y="4" width="18" height="13">
              <path d="M6.99986 14.1727L3.53319 10.706C3.14291 10.3158 2.51014 10.3158 2.11986 10.706C1.72958 11.0963 1.72958 11.7291 2.11986 12.1194L6.29275 16.2923C6.68328 16.6828 7.31644 16.6828 7.70697 16.2923L18.2932 5.70604C18.6835 5.31576 18.6835 4.68299 18.2932 4.29271C17.9029 3.90243 17.2701 3.90243 16.8799 4.29271L6.99986 14.1727Z" fill="white" />
            </mask>
            <g mask="url(#mask0_6869_9148)"> </g>
          </svg>
            <h5><strong>It’s great to have you on board, {profileForDisplay && profileForDisplay.name}!</strong></h5>
            <p>A Koru membership has successfully been purchased for {onBehalfEmployee.fname+" "+onBehalfEmployee.lname}.</p>
            <div>
              <p style={{marginBottom: "0px"}}>We’ve sent an email confirmation to </p>
              <strong>{onBehalfEmployee.email}</strong> 
            </div><br />
            <div>
              <p style={{marginBottom: "0px"}}>A copy has been sent to</p>
              <strong>{profileForDisplay ? profileForDisplay.email : ""}</strong> 
            </div><br />
            <div>
            If you don’t receive your email confirmation in a few minutes, please check your junk folder or get in touch with the <a href='https://www.airnewzealand.co.nz/koru#contact' target='_blank'>Koru contact centre</a>.
            We look forward to seeing you on board and in our lounges soon. 
            </div>
          </div>}
      {paymentStatus == "failed" && 
        <div className="alert alert-warning hide-fontawesome" role="alert">
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M0 10C0 15.5228 4.47715 20 10 20C15.5228 20 20 15.5228 20 10C20 4.47715 15.5228 0 10 0C4.47715 0 0 4.47715 0 10ZM18 10C18 14.4183 14.4183 18 10 18C5.58172 18 2 14.4183 2 10C2 5.58172 5.58172 2 10 2C14.4183 2 18 5.58172 18 10ZM8.78784 14.25C8.78784 13.5596 9.34749 13 10.0378 13C10.7282 13 11.2878 13.5596 11.2878 14.25C11.2878 14.9404 10.7282 15.5 10.0378 15.5C9.34749 15.5 8.78784 14.9404 8.78784 14.25ZM10 4C9.18945 4 8.54912 4.6877 8.60687 5.49619L8.92875 10.0025C8.9689 10.5646 9.43655 11 10 11C10.5634 11 11.0311 10.5646 11.0712 10.0025L11.3931 5.49619C11.4509 4.6877 10.8106 4 10 4Z" fill="white" />
            <mask id="mask0_6869_7632" style={{maskType:"alpha"}} maskUnits="userSpaceOnUse" x="0" y="0" width="20" height="20">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M0 10C0 15.5228 4.47715 20 10 20C15.5228 20 20 15.5228 20 10C20 4.47715 15.5228 0 10 0C4.47715 0 0 4.47715 0 10ZM18 10C18 14.4183 14.4183 18 10 18C5.58172 18 2 14.4183 2 10C2 5.58172 5.58172 2 10 2C14.4183 2 18 5.58172 18 10ZM8.78784 14.25C8.78784 13.5596 9.34749 13 10.0378 13C10.7282 13 11.2878 13.5596 11.2878 14.25C11.2878 14.9404 10.7282 15.5 10.0378 15.5C9.34749 15.5 8.78784 14.9404 8.78784 14.25ZM10 4C9.18945 4 8.54912 4.6877 8.60687 5.49619L8.92875 10.0025C8.9689 10.5646 9.43655 11 10 11C10.5634 11 11.0311 10.5646 11.0712 10.0025L11.3931 5.49619C11.4509 4.6877 10.8106 4 10 4Z" fill="white" />
            </mask>
            <g mask="url(#mask0_6869_7632)"> </g>
          </svg>
          Your payment has been cancelled and you have not been charged.</div>
      }

      <div class=" latamClub">
        <div class="row">
          <div class="col-lg-12">
            {paymentStatus == "success" && profileForDisplay && !isOnBehalfAdminEnrolment() &&
              <>
                {!isDeliveryAddressPresent ? <>
                  <h2>Confirm the delivery address</h2>
                  <p> Please review the employee’s contact details below to ensure they receive any items we may need to send them as part of their Koru membership. If any details are incorrect, please ask the employee to log into their Airpoints account to update.  
</p>
                  <div class="card editable">
                    <div class="card-body">
                      <div class="editable__left">
                        <h5>{profileForDisplay.name}</h5>
                        <p>{profileForDisplay.address.addressLine1} {profileForDisplay.address.addressLine2}
                          <br />{profileForDisplay.address.streetNumber} {profileForDisplay.address.district}
                          <br />{profileForDisplay.address.city} {profileForDisplay.address.zip}
                          <br />{profileForDisplay.address.state} {profileForDisplay.address.country}</p>
                        <div>{profileForDisplay.email}</div>
                        <p></p>
                      </div>
                      <div class="editable__right">
                        Wrong address?<br /><a onClick={() => {trackData(PAYMENT_UPDATE_ADDRESS_LINK, ["https://www.airnewzealand.co.nz/membership/profile/personalInfo/contactDetails"]);}} href="javascript:void(0)">Click here to edit</a>
                      </div>
                    </div>
                  </div>
                </>  : <>           
                  <div class="card editable editable--no-address">
                    <div class="card-body" style={{"padding": "0px"}}>
                      <div class="editable__left">
                        <h5>Add your delivery address </h5>
                        <p>To receive any items that may need to be sent to you as part of your Koru membership, please add your delivery address now.</p>
                      </div>
                      <div class="editable__right pl-2">
                        <a class="btn btn-secondary" onClick={() => {trackData(PAYMENT_ADD_ADDRESS_LINK, ["https://www.airnewzealand.co.nz/membership/profile/personalInfo/contactDetails"]);}} href="javascript:void(0)">Enter address</a> </div>
                    </div>
                  </div>
                </>
                }
                <div class="row no-gutters widgets--membership-box">
                  <div class="col-md-3">
                    <img src="images/cart-membership-logo.png" class="card-img" alt="..." />
                  </div>
                  <div class="col-md-9">
                    <h2>Your Koru membership</h2>
                    <p>Some text as an introduction to Koru membership and getting started from here.</p>
                    <div class="btn-wrap btn-wrap--grp text-left">
                      <button type="button" class="btn btn-primary" onClick={() => {trackData(PAYMENT_VIEW_KORU_PROFILE, {}); goToOverview()}}>Koru membership profile</button>
                      <button type="button" data-toggle="modal" onClick={() => {trackData(PAYMENT_VIEW_DIGITAL_CARD, {})}} data-target="#digital-card-modal" className="btn btn-secondary">View Koru card</button>

                    </div>
                  </div>
                </div>
              </>}
              {paymentStatus == "success" && isOnBehalfAdminEnrolment() &&
              <>
                {Object.keys(onBehalfEmployee).includes('address') ? <>
                  <h2>Confirm the delivery address</h2>
                  <p> Please review the employee’s contact details below to ensure they receive any items we may need to send them as part of their Koru membership. </p>
                  <p>If any details are incorrect, please ask the employee to log into their Airpoints account to update.</p>
                  <div class="card editable">
                    <div class="card-body">
                      <div class="editable__left">
                        <h5>{onBehalfEmployee.fname+" "+onBehalfEmployee.lname}</h5>
                        <p>{onBehalfEmployee.address.addressLine1} {onBehalfEmployee.address.addressLine2}
                          <br />{onBehalfEmployee.address.streetNumber} {onBehalfEmployee.address.district}
                          <br />{onBehalfEmployee.address.city} {onBehalfEmployee.address.zip}
                          <br />{onBehalfEmployee.address.state} {onBehalfEmployee.address.country}</p>
                        <div>{onBehalfEmployee.email}</div>
                        <p></p>
                      </div>
                    </div>
                  </div>
                </>  : <>           
                  <div class="card editable editable--no-address">
                    <div class="card-body" style={{"padding": "0px"}}>
                      <div class="editable__left">
                        <h5>No delivery address added</h5>
                        <p>Please add your delivery address so that we are able to send you any items that may need to be sent to you as part of your Koru Membership</p>
                      </div>
                      <div class="editable__right pl-2">
                        <a class="btn btn-secondary" onClick={() => {trackData(PAYMENT_ADD_ADDRESS_LINK, ["https://www.airnewzealand.co.nz/membership/profile/personalInfo/contactDetails"]);}} href="javascript:void(0)">
                        Enter address</a> </div>
                    </div>
                  </div>
                </>
                }
              </>}
            
            <h2>{t('subscription.statusPage.contactCentre.title')}</h2>
            <p>{t('subscription.statusPage.contactCentre.description')}</p>
            <div class="contact--address">
              <p><strong>{t('subscription.statusPage.contactCentre.phoneLabel')}: </strong>{t('subscription.statusPage.contactCentre.phoneValue')}</p>
              <p><strong>{t('subscription.statusPage.contactCentre.emailLabel')}: </strong>{t('subscription.statusPage.contactCentre.emailValue')}</p>
              {/* <p><strong>{t('subscription.statusPage.contactCentre.faxLabel')}: </strong>{t('subscription.statusPage.contactCentre.faxValue')}</p> */}
              <p><strong>{t('subscription.statusPage.contactCentre.addressLabel')}: </strong>{t('subscription.statusPage.contactCentre.addressValue')}</p>
              {/* <p><strong>{t('subscription.statusPage.contactCentre.hoursLabel')}: </strong>{t('subscription.statusPage.contactCentre.hoursValue')}</p> */}
            </div>
            {paymentStatus == "failed" &&
              <div class="col-lg-12" style={{ paddingTop: "2rem", paddingLeft: "0px" }}>
                <button type="button" class="btn btn-secondary" onClick={() => { getItemFromBrowserStorage("membershipNumber") ? goToOverview() : gotToBenefit() }} data-test="payment-test">{getItemFromBrowserStorage("membershipNumber") ? "Back to overview" : "Back to benefit"}</button>
              </div>
            }
          </div>
        </div>

      </div>
    </main>
  );
};


export default (withTranslation()(Success));