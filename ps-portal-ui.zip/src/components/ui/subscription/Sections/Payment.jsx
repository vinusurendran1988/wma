import React from "react";
import { withTranslation } from 'react-i18next';

const Payment = props => {
    const {t} = props;
    return (
        <div className="row mainSec">
            <div className="col-lg-12 mainLeftSec">
                <div className="form-row feturesSec cardSec"><div className="col-lg-12"><h3>{t('latam.credit_card_pay')}</h3> </div>
                    <div className="col-lg-4">
                        <div className="form-row">
                            <div className="col-lg-12">
                                <label>{t('latam.credit_card_no')}</label>
                                <div className="cardNum"><input type="text" aria-label={t('latam.credit_card_no')} className="" /><i className="fa fa-credit-card" aria-hidden="true"></i></div>
                            </div>

                            <div className="col-lg-8 col-md-4 col-6 mt-3 mb-3">
                                <label>{t('latam.expiry')}</label>
                                <div className="input-group">
                                    <input type="text" aria-label={t('latam.expiry_month')} className="" />
                                    <input type="text" aria-label={t('latam.expiry_year')} className="" />
                                </div>
                            </div>
                            <div className="col-lg-4 col-md-3 col-6 mt-3 mb-3">
                                <label>{t('latam.ccv')}</label>
                                <div>
                                    <input type="text" aria-label={t('latam.ccv')} className="" />
                                </div>
                            </div>
                            <div className="col-lg-12 mb-3">
                                <label>{t('latam.name_on_cc')}</label>
                                <div>
                                    <input type="text" aria-label={t('latam.name_on_cc')} className="" />
                                </div>
                            </div>
                            <div className="col-lg-12">
                                <button type="button" className="btn btn-primary btn-block" onClick={() => props.doPayment()}>{t('latam.pay')} 46 USD</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default withTranslation()(Payment);