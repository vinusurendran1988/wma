import { mount, shallow } from 'enzyme';
import moxios from 'moxios';
import React, * as reactModule from 'react';
import { Provider } from 'react-redux';
import Checkout from './Checkout';
import { BrowserRouter as Router } from 'react-router-dom';
import { testStore } from '../../../common/utils';
import { axiosInstance } from '../../../common/utils/api';
import { findComponent, mockServiceResponse } from '../../../common/testUtils';
//import Enzyme, {mount} from 'enzyme' 
import { _URL_PRODUCT_ENROLL, _URL_PRODUCT_PAY_ACCEPT } from '../../../common/config/config';
import ReactTestUtils from 'react-dom/test-utils';
import { acceptPayment, doEnrollment } from '../actions';

var store = testStore({})
let rootComponent;
let component;
const setUp = (props = {}, isDefaultConfig = false) => {
    props.resetError = jest.fn();
    props.setPageInfo = jest.fn();
    props.setError = jest.fn();
    window.location = jest.fn();
    window.localStorage.setItem("cartItem", { "membership": { "id": "3", "type": "product", "name": "Enrol Individual Membership 1 year", "description": null, "startDate": "06 Oct 2021", "endDate": "31-Oct-2022", "duration": "1 year", "durationType": "Y", "i18nCode": "join_main_pr-1", "price": { "interval": null, "currency": null, "originalFee": 255, "originalCost": 629, "latestFee": 255, "latestCost": 629, "latestTotal": 884, "originalTotal": 884 }, "isSelected": true, "showDiscount": false }, "total": 1149, "guestCard": { "id": "3", "type": "card", "name": "KORU Guest Card 9 Months ", "description": null, "startDate": null, "endDate": null, "duration": 9, "durationType": "M", "i18nCode": "join_gc_pr-3", "price": { "interval": null, "currency": null, "originalFee": 0, "originalCost": 250, "latestFee": 0, "latestCost": 250, "latestTotal": 250 }, "isSelected": true }, "addOn": { "id": "1", "type": "add-on", "name": "Baggage Tag", "description": null, "startDate": null, "endDate": null, "duration": 0, "durationType": "M", "i18nCode": "join_pf_pr-3", "price": { "interval": null, "currency": null, "originalFee": 0, "originalCost": 12, "latestFee": 0, "latestCost": 15, "latestTotal": 15 }, "isSelected": true } })
    window.localStorage.setItem("language", { "name": "English", "code": "en", "flagCode": "GB" })
    JSON.parse = jest.fn().mockImplementationOnce(() => {
        return ({ "membership": { "id": "3", "type": "product", "name": "Enrol Individual Membership 1 year", "description": null, "startDate": "06 Oct 2021", "endDate": "31-Oct-2022", "duration": "1 year", "durationType": "Y", "i18nCode": "join_main_pr-1", "price": { "interval": null, "currency": null, "originalFee": 255, "originalCost": 629, "latestFee": 255, "latestCost": 629, "latestTotal": 884, "originalTotal": 884 }, "isSelected": true, "showDiscount": false }, "total": 1149, "guestCard": { "id": "3", "type": "card", "name": "KORU Guest Card 9 Months ", "description": null, "startDate": null, "endDate": null, "duration": 9, "durationType": "M", "i18nCode": "join_gc_pr-3", "price": { "interval": null, "currency": null, "originalFee": 0, "originalCost": 250, "latestFee": 0, "latestCost": 250, "latestTotal": 250 }, "isSelected": true }, "addOn": { "id": "1", "type": "add-on", "name": "Baggage Tag", "description": null, "startDate": null, "endDate": null, "duration": 0, "durationType": "M", "i18nCode": "join_pf_pr-3", "price": { "interval": null, "currency": null, "originalFee": 0, "originalCost": 12, "latestFee": 0, "latestCost": 15, "latestTotal": 15 }, "isSelected": true } })
    });

    rootComponent = mount(
        <Provider store={store} >
            <Checkout {...props} />
        </Provider>
    );
};
describe('Checkout component tests', () => {

    beforeEach(() => {

        store = testStore({});
        setUp({})
        rootComponent = rootComponent.update()
        component = findComponent(rootComponent, 'Checkout');
        moxios.install(axiosInstance);

    })

    afterEach(() => {
        moxios.uninstall(axiosInstance);
    });

    it('first demo test case', () => {
        expect(2 + 2).toEqual(4)
    })

    it('Get enrolment status success', () => {
        JSON.parse = jest.fn().mockImplementationOnce(() => {
            return ("language", { "name": "English", "code": "en", "flagCode": "GB" })
        });
        mockServiceResponse(UPDATE_ENROLL_RESPONSE, 200)
        return ReactTestUtils.act(() => {
            return store.dispatch(doEnrollment({}))
                .then(() => {
                    let newState = store.getState();
                    //expect(newState.subscriptionReducer).toBe(UPDATE_ENROLL_RESPONSE1);
                    rootComponent.update()
                    component.update();
                    JSON.parse = jest.fn().mockImplementationOnce(() => {
                        return ("language", { "name": "English", "code": "en", "flagCode": "GB" })
                    });
                })
        })
    })

    it('Get enrolment status failed', () => {
        JSON.parse = jest.fn().mockImplementationOnce(() => {
            return ("language", { "name": "English", "code": "en", "flagCode": "GB" })
        });
        mockServiceResponse(UPDATE_ENROLL_ERROR_RESPONSE, 500)
        return ReactTestUtils.act(() => {
            return store.dispatch(doEnrollment({}))
                .then(() => {
                    let newState = store.getState();
                    //expect(newState.subscriptionReducer).toBe(UPDATE_ENROLL_RESPONSE1);
                    rootComponent.update()
                    component.update();
                    JSON.parse = jest.fn().mockImplementationOnce(() => {
                        return ("language", { "name": "English", "code": "en", "flagCode": "GB" })
                    });
                })
        })
    })

    it('Get payment status sucess', () => {
        JSON.parse = jest.fn().mockImplementationOnce(() => {
            return ("language", { "name": "English", "code": "en", "flagCode": "GB" })
        });
        mockServiceResponse(UPDATE_PAYMENT_RESPONSE, 200)
        return ReactTestUtils.act(() => {
            return store.dispatch(acceptPayment({}))
                .then(() => {
                    let newState = store.getState();
                    rootComponent.update()
                    component.update();
                    JSON.parse = jest.fn().mockImplementationOnce(() => {
                        return ("language", { "name": "English", "code": "en", "flagCode": "GB" })
                    });
                })
        })
    })

    it('Get payment status failed', () => {
        JSON.parse = jest.fn().mockImplementationOnce(() => {
            return ("language", { "name": "English", "code": "en", "flagCode": "GB" })
        });
        mockServiceResponse(UPDATE_PAYMENT_ERROR_RESPONSE, 500)
        return ReactTestUtils.act(() => {
            return store.dispatch(acceptPayment({}))
                .then(() => {
                    let newState = store.getState();
                    rootComponent.update()
                    component.update();
                    JSON.parse = jest.fn().mockImplementationOnce(() => {
                        return ("language", { "name": "English", "code": "en", "flagCode": "GB" })
                    });
                })
        })
    })

    it('Edit membership function invoke', () => {
        rootComponent = rootComponent.update();
        let buttons = rootComponent.find('a[data-test="edit-plan"]');
        buttons.find('a').simulate('click');
    })

    it('go to payment function invoke', () => {
        rootComponent = rootComponent.update();
        let inputCheckbox = rootComponent.find('input[type="checkbox"][data-test="terms-and-condition-test-data"]');
        inputCheckbox.simulate('click');
        let buttons1 = rootComponent.find('button[type="button"][data-test="payment-test"]');
        buttons1.find('button').simulate('click');
    })
    it('remove item function invoke', () => {
        rootComponent = rootComponent.update();
        let buttons = rootComponent.find('a[data-test="remove-item-test"]');
        buttons.find('a').simulate('click');
    })
    it('koru terms and condiiton 1 link cleck', () => {
        rootComponent = rootComponent.update();
        let buttons1 = rootComponent.find('a[data-test="terms-test1"]');
        buttons1.find('a').simulate('click');
        let buttons2 = rootComponent.find('a[data-test="terms-test2"]');
        buttons2.find('a').simulate('click');
        let buttons3 = rootComponent.find('a[data-test="terms-test3"]');
        buttons3.find('a').simulate('click');
        let buttons4 = rootComponent.find('a[data-test="terms-test4"]');
        buttons4.find('a').simulate('click');

    }) 
    it('remove item addon function invoke', () => {
        rootComponent = rootComponent.update();
        let buttons = rootComponent.find('a[data-test="remove-item-test-addon"]');
        buttons.find('a').simulate('click');
    })
})

const UPDATE_ENROLL_RESPONSE1 = { "enrollStatus": { status: "success", response: { "enrollStatus": { "status": "success" }, "payAcceptStatus": { "status": "success" } } } }
const UPDATE_ENROLL_RESPONSE = { "object": { "memberActivityStatus": { 'enrollStatus': { "status": "success" }, "payAcceptStatus": { "status": "success" } } } }
const UPDATE_PAYMENT_RESPONSE = { "object": { "memberActivityStatus": { 'enrollStatus': { "status": "success" }, "payAcceptStatus": { "status": "success" } } } }

const UPDATE_ENROLL_ERROR_RESPONSE = { "statuscode": "500", "statusMessage": "FAILURE", "error": { "code": "500", "type": "INTERNAL_SERVER_ERROR", "message": "Enrol member failed", "errorDetails": [{ "message": "Member already enrolled to program" }] } }
const UPDATE_PAYMENT_ERROR_RESPONSE = { "statuscode": "500", "statusMessage": "FAILURE", "error": { "code": "500", "type": "INTERNAL_SERVER_ERROR", "message": "Enrol member failed", "errorDetails": [{ "message": "Member already enrolled to program" }] } }
