import React, { useEffect, useState } from "react";
import { withTranslation } from 'react-i18next';
import { connect, useDispatch, useSelector } from 'react-redux';
import { useHistory } from "react-router-dom";
import { fetchConfiguration } from "../../../common/middleware/redux/commonAction";
import { CONFIG_SECTION_SUBSCRIPTION } from "../../../common/utils/Constants";
import { getItemFromBrowserStorage, setItemToBrowserStorage, removeItemFromBrowserStorage } from "../../../common/utils/storage.utils";
import { NAVIGATE_CLUB, NAVIGATE_CLUB_SUCCESS } from '../../../common/utils/urlConstants';
import { acceptPayment, addToCart, doEnrollment, removeFromCart, doRenew, doStandAlonePurchase } from "../actions";
import { FLOW_TYPE, JOIN, STANDALONE, TAB_CHECKOUT } from "../Constants";
import { getOnBehalfEmployeeDetails, isOnBehalfAdminEnrolment} from "../Services/CommonUtils"
import Custommessage from "../../../common/components/custommessage";
import { withSuspense } from '../../../common/utils';
import parse from 'html-react-parser';
import "../subscription.css";
import { CHECKOUT_EDIT_PLAN, CHECKOUT_BACK_TO_SELECT, trackData } from "../../../common/utils/analytics.utils"



const Checkout = (props) => {
  const dispatch = useDispatch()
  let cart = useSelector(state => state.cartReducer.cartDetails);
  // const memType = useSelector(state => state.membershipTypeReducer.type)
  const memType = getItemFromBrowserStorage(FLOW_TYPE)
  const membershipType = memType == STANDALONE ? JOIN : memType;
  const config = useSelector(state => state.configurationReducer[CONFIG_SECTION_SUBSCRIPTION])
  const [isConfigLoaded, setConfigFlag] = useState(false)

  if (typeof cart == "undefined") {
    let storedItems = getItemFromBrowserStorage("cartItem")
    if (storedItems != "") {
      let cartItems = JSON.parse(storedItems);
      Object.keys(cartItems).forEach((key) => dispatch(addToCart(key, cartItems[key])));
    }
  }
  cart = useSelector(state => state.cartReducer.cartDetails);

  const onBehalfEmployee = getOnBehalfEmployeeDetails();
  const onBehalfMessageBannerText = isOnBehalfAdminEnrolment() ? "You’re purchasing this membership on behalf of <b>"+
                                    onBehalfEmployee.fname+" "+onBehalfEmployee.lname
                                    +"</b>.You’ll see details from their Airpoints profile in relation to this purchase." : "";
  const [adminOnBehalf, setAdminOnBehalf] = useState(isOnBehalfAdminEnrolment());
  const [isPaymentEnabled, setIsPaymentEnabled] = useState('');
  const [adminTnC, setAdminTnC] = useState(isOnBehalfAdminEnrolment() ? false : -1);
  const [commonTnC, setCommonTnC] = useState(false);
  const [highlightAdminTnCError, setHighlightAdminTnCError] = useState(false);
  const [highlightCommonTnCError, setHighlightCommonTnCError] = useState(false);

  const history = useHistory();
  const subscription = useSelector(state => state.subscriptionReducer);
  const overViewData = getItemFromBrowserStorage("overView") ? JSON.parse(getItemFromBrowserStorage("overView")) : null;
  // const overviewDataResponse = useSelector(state => state.subscriptionReducer.overviewData)
  useEffect(() => {
    if (!config || config && Object.keys(config).length) {
      dispatch(fetchConfiguration(CONFIG_SECTION_SUBSCRIPTION))
    }
  }, []);
  useEffect(() => {
    if (config) {
      setConfigFlag(true)
    }
  }, [config]);

  useEffect(() => {
    if (Object.keys(subscription).includes('standaloneStatus') && subscription.standaloneStatus.status == "success" && !Object.keys(subscription).includes('payAcceptStatus')) {
      dispatch(acceptPayment(prepareAcceptPaymentRequest(subscription.standaloneStatus.response, cart, "standAlone")));
    }
    else if (Object.keys(subscription).includes('renewStatus') && subscription.renewStatus.status == "success" && !Object.keys(subscription).includes('payAcceptStatus')) {
      dispatch(acceptPayment(prepareAcceptPaymentRequest(subscription.renewStatus.response, cart, "renew")));
    } else if (Object.keys(subscription).includes('enrollStatus') && subscription.enrollStatus.status == "success" && !Object.keys(subscription).includes('payAcceptStatus')) {
      dispatch(acceptPayment(prepareAcceptPaymentRequest(subscription.enrollStatus.response, cart)));
    } else if (Object.keys(subscription).includes('enrollStatus') && subscription.enrollStatus.status == "success" && Object.keys(subscription).includes('payAcceptStatus') && subscription.payAcceptStatus.status == "success") {
      window.location = `#${NAVIGATE_CLUB_SUCCESS}?payment=success`;
    } else if (Object.keys(subscription).includes('standaloneStatus') && subscription.standaloneStatus.status == "success" && Object.keys(subscription).includes('payAcceptStatus') && subscription.payAcceptStatus.status == "success") {
      window.location = `#${NAVIGATE_CLUB_SUCCESS}?payment=success`;
    }
    else if (Object.keys(subscription).includes('renewStatus') && subscription.renewStatus.status == "success" && Object.keys(subscription).includes('payAcceptStatus') && subscription.payAcceptStatus.status == "success") {
      window.location = `#${NAVIGATE_CLUB_SUCCESS}?payment=success&type=renew`;
    } else if (Object.keys(subscription).includes('payAcceptStatus') && subscription.payAcceptStatus.status == "failed") {
      window.location = `#${NAVIGATE_CLUB_SUCCESS}?payment=failed`;
    } else if (Object.keys(subscription).includes('enrollStatus') && subscription.enrollStatus.status == "failed") {
      window.location = `#${NAVIGATE_CLUB_SUCCESS}?payment=failed`;
    } else if (Object.keys(subscription).includes('renewStatus') && subscription.renewStatus.status == "failed") {
      window.location = `#${NAVIGATE_CLUB_SUCCESS}?payment=failed`;
    } else if (Object.keys(subscription).includes('standaloneStatus') && subscription.standaloneStatus.status == "failed") {
      window.location = `#${NAVIGATE_CLUB_SUCCESS}?payment=failed`;
    }
  }, [subscription]);

  const { t } = props;
  const editMembership = () => {
    window.location = `#${NAVIGATE_CLUB}` + '/' + memType;
  }

  const goToPayment = () => {
    if ( memType != STANDALONE) {
      if (commonTnC != true) {
        setHighlightCommonTnCError(true);
      }
      if (adminTnC != -1 && adminTnC != true) {
        setHighlightAdminTnCError(true);
      }
      if (commonTnC != true || (adminTnC != -1 && adminTnC != true)) {
        return;
      }
    }
    if (getItemFromBrowserStorage(FLOW_TYPE) == STANDALONE) {
      dispatch(doStandAlonePurchase(prepareStandAlonePurchaseRequest(cart)));
    }
    else if (overViewData != null && Object.keys(overViewData).includes('response')) {
      dispatch(doRenew(prepareRenewRequest(cart, overViewData)));
    } else {
      dispatch(doEnrollment(prepareEnrollRequest(cart)));
    }
    removeItemFromBrowserStorage('cartItem');
    removeItemFromBrowserStorage('overView');
  }

  const prepareEnrollRequest = (cart) => {
    let period = parseInt(cart.membership.duration.split(" ")[0]) * 12;
    let payload = {
      "object": {
        "memberAccount": {
          "companyCode": "NZ",
          "programCode": "KORU",
          "membershipNumber": isOnBehalfAdminEnrolment() ? onBehalfEmployee.membershipNumber : localStorage.getItem("membershipNumber"),
          "enrolmentSource": "W",
          "periodType": "R",
          "period": period,
          "memberProfile": {
            "companyCode": "NZ",
            "programCode": "AP",
            "membershipNumber": isOnBehalfAdminEnrolment() ? onBehalfEmployee.membershipNumber : localStorage.getItem("membershipNumber"),
            "membershipType": "I"
          },
          "memberDynamicAttributes": [
            {
              "attributeCode": "17",
              "groupInstanceID": "1",
              "attributeValue": "1",
              "type": "P"
            },
            {
              "attributeCode": "2",
              "operationFlag": "1",
              "attributeValue": "PR",
              "type": "P"
            }
          ]
        }
      }
    };
    if (Object.keys(cart).includes("addOn")) {
      payload.object.memberAccount.memberDynamicAttributes.push({
        "attributeCode": "26",
        "groupInstanceID": "1",
        "attributeValue": "Yes",
        "type": "P"
      });
    } else {
      payload.object.memberAccount.memberDynamicAttributes.push({
        "attributeCode": "26",
        "groupInstanceID": "1",
        "attributeValue": "No",
        "type": "P"
      });
    }
    if (Object.keys(cart).includes("guestCard")) {
      let dynamicAttrMapping = {
        "3": "GC3M",
        "6": "GC6M",
        "9": "GC9M",
        "12": "GC12M",
      }
      payload.object.memberAccount.memberDynamicAttributes.push({
        "attributeCode": "27",
        "groupInstanceID": "1",
        "attributeValue": dynamicAttrMapping[cart.guestCard.duration],
        "type": "P"
      });
    } else {
      payload.object.memberAccount.memberDynamicAttributes.push({
        "attributeCode": "27",
        "groupInstanceID": "1",
        "attributeValue": "No",
        "type": "P"
      });
    }

    if (isOnBehalfAdminEnrolment()) {
      payload.object.memberAccount.memberDynamicAttributes.push({
        "attributeCode": "19",
        "groupInstanceID": "1",
        "attributeValue": localStorage.getItem("membershipNumber"),
        "type": "C"
      });
    }
    return payload;
  }

  const prepareStandAlonePurchaseRequest = (cart) => {
    let dynamicAttrMapping = {
      "3": "GC3M",
      "6": "GC6M",
      "9": "GC9M",
      "12": "GC12M",
    }
    let payload = {
      "object": {
          "companyCode": "NZ",
          "programCode": "KORU",
          "membershipNumber": isOnBehalfAdminEnrolment() ? onBehalfEmployee.membershipNumber : localStorage.getItem("membershipNumber"),
          "partnerCode": "KORU",
          "activityCode": Object.keys(cart).includes("guestCard") ? "GC" : "RBT",
          "activityDescription": "",
          "adhocAttributes": Object.keys(cart).includes("guestCard") ? [
            {
              "attributeCode": "GCV",
              "attributeValue": dynamicAttrMapping[cart.guestCard.duration],
            }
          ] : []
      }
    };
    if (Object.keys(cart).includes("guestCard")) {
      if (Object.keys(cart).includes("addOn")) {
        payload.object.adhocAttributes.push({
          "attributeCode": "IBT",
          "attributeValue": "Y"
        });
      }
    }
    return payload;
  }
  const getActivityType = (type) =>{
     switch(type){
        case "enroll" :{
          return "ME"
        }
        case "renew" : {
          return "AR"
        }
        case "standAlone" : {
          return "AD"
        }
     }
  }
  const getActivityCode = (type) =>{
    switch(type){
       case "enroll" :{
         return "ME"
       }
       case "renew" : {
         return "RA"
       }
       case "standAlone" : {
         return Object.keys(cart).includes("guestCard") ? "GC" : "RBT"
       }
    }
 }
  const prepareAcceptPaymentRequest = (enrollResponse, cart, type = "enroll") => {
    let activityNumber = enrollResponse.activityNumber;
    let payload = {
      "object": {
        "companyCode": "NZ",
        "programCode": "KORU",
        "membershipNumber": isOnBehalfAdminEnrolment() ? onBehalfEmployee.membershipNumber : localStorage.getItem("membershipNumber"),
        "activityType": getActivityType(type),
        "transactionType": "enroll",
        "transactionId": "",
        "activityNumber": activityNumber,
        "activityCode": getActivityCode(type),
        "promotionIdentifier": "",
        "paymentRemark": "",
        "paymentDetail": [
          {
            "pointsCollected": 0,
            "amountCollected": cart.total,
            "paymentType": "",
            "currencyCode": "USD",
            "paymentSource": "W",
            "paymentGateWayRefNumber": "25052113210000011204",
            "quoteReferenceNumber": ""
          }
        ]
      }
    };
    if (type == "renew") {
      payload.object.activityType = "AR";
      payload.object.activityCode = "AR";
      payload.object.transactionType = "renewal";
    }
    return payload;
  }

  const prepareRenewRequest = (cart, overViewData) => {
    let period = parseInt(cart.membership.duration.split(" ")[0]) * 12;
    let dynamicAttrMapping = {
      "3": "GC3M",
      "6": "GC6M",
      "9": "GC9M",
      "12": "GC12M",
    }
    let payload = {
      "object": {
        "companyCode": "NZ",
        "programCode": "KORU",
        "membershipNumber": isOnBehalfAdminEnrolment() ? onBehalfEmployee.membershipNumber : localStorage.getItem("membershipNumber"),
        // "membershipNumber": 22,
        "membershipType": "I",
        "currentExpiryDate": overViewData.response.membershipDetails.expiryDate,
        "period": period,
        "extendToDay": "0",
        "extendToMonth": "0",
        "periodType": "R",
        "adhocAttributes": [{
          "attributeCode": "TNC",
          "attributeValue": "Y"
        }]
      }
    };

    if (isOnBehalfAdminEnrolment()) {
      Object.defineProperty(payload.object, 'memberAccount', {
        value: {memberDynamicAttributes: []}
      })
      // payload.object.memberAccount.memberDynamicAttributes = [];
      payload.object.memberAccount.memberDynamicAttributes.push({
        "attributeCode": "RNBY",
        "groupInstanceID": "1",
        "attributeValue": localStorage.getItem("membershipNumber"),
        "type": "C"
      });
    }

    if (Object.keys(cart).includes("guestCard")) {
      payload.object.adhocAttributes.push({
        "attributeCode": "GCV",
        "attributeValue": dynamicAttrMapping[cart.guestCard.duration],
      })
    }
    return payload;
  }

  const calculateTotal = (cartItems) => {
    let total = 0
    let cartTotalInStore = 0
    if (cartItems && Object.keys(cartItems).length > 0) {
      cartTotalInStore = cartItems['total']
      if (cartItems.membership && cartItems.membership.price && cartItems.membership.price.latestTotal) {
        total = total + cartItems.membership.price.latestTotal
      }
      if (cartItems.guestCard && cartItems.guestCard.price && cartItems.guestCard.price.latestCost) {
        total = total + cartItems.guestCard.price.latestCost
      }
      if (cartItems.addOn && cartItems.addOn.price && cartItems.addOn.price.latestCost) {
        total = total + cartItems.addOn.price.latestCost
      }

    }
    if (cartTotalInStore != total) {
      dispatch(addToCart("total", total))
    }
  }

  const removeItem = (item) => {
    console.log("cart in ()", cart);
    dispatch(removeFromCart(item))
    calculateTotal(cart)
    setItemToBrowserStorage("cartItem", JSON.stringify(cart))
    if (!(JSON.parse(getItemFromBrowserStorage("cartItem")).addOn) && (!JSON.parse(getItemFromBrowserStorage("cartItem")).guestCard) && (memType == STANDALONE)) {
      window.location = `#${NAVIGATE_CLUB}` + '/' + memType;
    }
  }
  const goToSelect = () => {
    window.location = `#${NAVIGATE_CLUB}` + '/' + memType;
  }

  /**
   * 
   */
  const getPaymentButtonStatus = () => {
    if (memType == STANDALONE) {
      return false;
    } else {
      if (adminTnC == -1) {
        return !commonTnC;
      } else {
        return !(adminTnC && commonTnC)
      }
    }
  }

  return (
    <main role="main" id="content" class="container member-plan cart-view">
      <ol class="cart-view__timeline">
        <li class="cart-view__timeline--first cart-view__timeline--active">1. Select</li>
        <li class="cart-view__timeline--active cart-view__timeline--current">2. Checkout</li>
        <li>3. Payment</li>
        <li class="cart-view__timeline--last">4. Success</li>
      </ol>
      {isOnBehalfAdminEnrolment() && 
        <>
          <br />
          <Custommessage
            type={"info"}
            message={[parse(onBehalfMessageBannerText)]}
            canTranslate={false}
          /><br />
        </>
      }
      <div>
        <h1>Check out</h1>
      </div>
      <div class=" latamClub">
        <div class="row">
          <div class="col-lg-12">
            <h2>Purchase summary</h2>
            {cart.membership &&
              <table class="table  cart-table">
                <thead>
                  <tr>
                    <th scope="col" style={{ width: "35%" }}>Membership plan</th>
                    <th scope="col" class="text-center" style={{ width: "25%" }}>Valid to</th>
                    <th scope="col" class="text-center cart-table__remove">Edit/ Remove</th>
                    <th scope="col" class="text-right cart-table__price">Price</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td scope="row">{t(`productName.${cart.membership && cart.membership.i18nCode}`)}</td>
                    <td class="text-center">{cart.membership && cart.membership.endDate}</td>
                    <td class="text-center"><a href="javascript:void(0)" onClick={() => {trackData(CHECKOUT_EDIT_PLAN, {}); editMembership()}} class="btn btn-sm btn-outline-primary preferences__btn" data-test="edit-plan">Edit</a></td>
                    <td class="text-right"><strong>${cart.membership && cart.membership.price.latestTotal}</strong></td>
                  </tr>
                </tbody>
              </table>
            }
            {(cart.guestCard || cart.addOn) &&
              <table class="table cart-table">
                <thead>
                  <tr><th scope="col" colspan="3">Additional add-ons</th></tr>
                </thead>
                <tbody>
                  {cart.guestCard && <tr>
                    <td scope="row" style={{ width: "59%" }}>{t(`guestCardName.${cart.guestCard.i18nCode}`)}</td>
                    <td class="text-center cart-table__remove"><a
                      onClick={() => removeItem("guestCard")}
                      class="btn-link" data-test="remove-item-test">Remove</a></td>
                    <td class="text-right cart-table__price"><strong>${cart.guestCard.price.latestCost}</strong></td>
                  </tr>}
                  {cart.addOn && <tr>
                    <td scope="row">{t(`addOnName.${cart.addOn.i18nCode}`)}</td>
                    <td class="text-center cart-table__remove">
                      <a class="btn-link" data-test="remove-item-test-addon" onClick={() => removeItem("addOn")}  >Remove</a></td>
                    <td class="text-right cart-table__price"><strong>${cart.addOn.price.latestCost}</strong></td>
                  </tr>}
                </tbody>
              </table>
            }
            <div class="total-value"><b>
              <div class="total-value--left">Total:</div></b>
              <b><div class="total-value--right">NZD ${cart.total}</div></b>
            </div>
            {config &&
              config.ui &&
              config.ui.layout &&
              config.ui.layout[membershipType] &&
              config.ui.layout[membershipType].tabs[TAB_CHECKOUT] &&
              config.ui.layout[membershipType].tabs[TAB_CHECKOUT].isImpNoteRequred && memType != STANDALONE ?
              <div>
                <h2>Things you need to know </h2>
                <ul class="imp-list">
                  <li>Koru member benefits apply when travelling on Air New Zealand operated flights (with Air New Zealand ticket and flight number).</li>
                  <li>Koru membership is non-refundable and non-transferable.</li>
                  <li>If you currently hold or are close to receiving Airpoints Gold or Elite status, you already receive Koru membership benefits as part of your Airpoints status. As a Koru membership runs for the full period purchased, refunds of any portion of the membership are not permitted should you wish to proceed.</li>
                  <li>Koru membership is not a Star Alliance recognised product.</li>
                </ul>
              </div> : <></>
            }
            {(adminOnBehalf && memType != STANDALONE) &&
              <>
                <div className={highlightAdminTnCError ? 'subscription_checkout_tnc imp-list--approve' : 'imp-list--approve'}>
                  <div class="form-group">
                    <input type="checkbox" data-test="terms-and-condition-test-data" onClick={(event) => {if(event.target.checked) { setAdminTnC(true); setHighlightAdminTnCError(false)} else {setAdminTnC(false)}}} id="html1" />
                    <label for="html1">I confirm that I have been authorised by the individual to sign them up for a Koru Corporate membership and have made the individual aware of the terms that apply.</label>
                  </div>
                </div>
                <div className={highlightAdminTnCError ? "subscription_checkout_tnc_errorMessage" : "hide"}>
                  <div className="simple-alert"><div className="alert alert-danger alert--custom hide-fontawesome" role="alert">
                  <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M0 10C0 15.5228 4.47715 20 10 20C15.5228 20 20 15.5228 20 10C20 4.47715 15.5228 0 10 0C4.47715 0 0 4.47715 0 10ZM8.60688 5.49619C8.54913 4.6877 9.18946 4 10 4C10.8106 4 11.4509 4.6877 11.3931 5.49619L11.0713 10.0025C11.0311 10.5646 10.5635 11 10 11C9.43656 11 8.96891 10.5646 8.92876 10.0025L8.60688 5.49619ZM8.78785 14.25C8.78785 13.5596 9.3475 13 10.0379 13C10.7282 13 11.2879 13.5596 11.2879 14.25C11.2879 14.9404 10.7282 15.5 10.0379 15.5C9.3475 15.5 8.78785 14.9404 8.78785 14.25Z" fill="#EE6A2F" />
                    <mask id="mask0_5049_74100" style={{ maskType: "alpha" }} maskUnits="userSpaceOnUse" x="0" y="0" width="20" height="20">
                      <path fill-rule="evenodd" clip-rule="evenodd" d="M0 10C0 15.5228 4.47715 20 10 20C15.5228 20 20 15.5228 20 10C20 4.47715 15.5228 0 10 0C4.47715 0 0 4.47715 0 10ZM8.60688 5.49619C8.54913 4.6877 9.18946 4 10 4C10.8106 4 11.4509 4.6877 11.3931 5.49619L11.0713 10.0025C11.0311 10.5646 10.5635 11 10 11C9.43656 11 8.96891 10.5646 8.92876 10.0025L8.60688 5.49619ZM8.78785 14.25C8.78785 13.5596 9.3475 13 10.0379 13C10.7282 13 11.2879 13.5596 11.2879 14.25C11.2879 14.9404 10.7282 15.5 10.0379 15.5C9.3475 15.5 8.78785 14.9404 8.78785 14.25Z" fill="white" />
                    </mask>
                    <g mask="url(#mask0_5049_74100)">
                    </g>
                  </svg> Please read and accept the Terms and Conditions to proceed to payment. </div></div>
                </div>
                <br />
              </>
            }
            { memType != STANDALONE &&
              <>
                <div class={highlightCommonTnCError ? 'subscription_checkout_tnc imp-list--approve' : 'imp-list--approve'}>
                  <div class="form-group">
                    <input type="checkbox" data-test="terms-and-condition-test-data" onClick={(event) => { if(event.target.checked) { setCommonTnC(true);setHighlightCommonTnCError(false) } else {  setCommonTnC(false)}}} id="html2" />
                    <label for="html2">The Koru Programme is subject to the  <a target='_blank' href="https://www.airnewzealand.co.nz/koru-terms-conditions" data-test="terms-test1">Koru Terms and Conditions</a>and the <a target='_blank' href="https://www.airnewzealand.co.nz/privacy-policy" data-test="terms-test2">Air New Zealand Privacy Policy</a>,which I have read, understood and agree to.</label>
                  </div>
                </div>
                <div className={highlightCommonTnCError ? "subscription_checkout_tnc_errorMessage" : "hide"}>
                <div className="simple-alert"><div className="alert alert-danger alert--custom hide-fontawesome" role="alert">
                  <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M0 10C0 15.5228 4.47715 20 10 20C15.5228 20 20 15.5228 20 10C20 4.47715 15.5228 0 10 0C4.47715 0 0 4.47715 0 10ZM8.60688 5.49619C8.54913 4.6877 9.18946 4 10 4C10.8106 4 11.4509 4.6877 11.3931 5.49619L11.0713 10.0025C11.0311 10.5646 10.5635 11 10 11C9.43656 11 8.96891 10.5646 8.92876 10.0025L8.60688 5.49619ZM8.78785 14.25C8.78785 13.5596 9.3475 13 10.0379 13C10.7282 13 11.2879 13.5596 11.2879 14.25C11.2879 14.9404 10.7282 15.5 10.0379 15.5C9.3475 15.5 8.78785 14.9404 8.78785 14.25Z" fill="#EE6A2F" />
                    <mask id="mask0_5049_74100" style={{ maskType: "alpha" }} maskUnits="userSpaceOnUse" x="0" y="0" width="20" height="20">
                      <path fill-rule="evenodd" clip-rule="evenodd" d="M0 10C0 15.5228 4.47715 20 10 20C15.5228 20 20 15.5228 20 10C20 4.47715 15.5228 0 10 0C4.47715 0 0 4.47715 0 10ZM8.60688 5.49619C8.54913 4.6877 9.18946 4 10 4C10.8106 4 11.4509 4.6877 11.3931 5.49619L11.0713 10.0025C11.0311 10.5646 10.5635 11 10 11C9.43656 11 8.96891 10.5646 8.92876 10.0025L8.60688 5.49619ZM8.78785 14.25C8.78785 13.5596 9.3475 13 10.0379 13C10.7282 13 11.2879 13.5596 11.2879 14.25C11.2879 14.9404 10.7282 15.5 10.0379 15.5C9.3475 15.5 8.78785 14.9404 8.78785 14.25Z" fill="white" />
                    </mask>
                    <g mask="url(#mask0_5049_74100)">
                    </g>
                  </svg> Please read and accept the Terms and Conditions to proceed to payment. </div></div>
                </div>
              </>
            }
           <br/>
           <div class="btn-wrap btn-wrap--grp btn-wrap-block__mobile btn-wrap-justify">
              <button type="button" class="btn btn-secondary" onClick={() => { trackData(CHECKOUT_BACK_TO_SELECT, {}); goToSelect() }} data-test="payment-test">Back to select</button>
              <button type="button" className={`btn btn-primary ${getPaymentButtonStatus() ? "disabled" : ""}`} onClick={() => { goToPayment() }} data-test="payment-test">Go to payment</button>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
};


export default withSuspense()(connect()(withTranslation()(Checkout)))