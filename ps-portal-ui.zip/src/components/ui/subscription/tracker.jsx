import React, {Fragment} from "react"
import ReactDOM from "react-dom"
import { useDispatch, useSelector } from 'react-redux';




const SubscriptionAnalytics = () => {
    const cartItems = useSelector(state => state.cartReducer.cartDetails)
    document.querySelector('#my-button').addEventListener('click', () => {
        console.log("Event fired - "+cartItems);
    });

    return <Fragment></Fragment>
}

export default SubscriptionAnalytics;