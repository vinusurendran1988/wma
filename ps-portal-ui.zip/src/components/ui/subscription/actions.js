import { _URL_PRODUCT_LIST, _URL_PRODUCT_ENROLL, _URL_PRODUCT_PAY_ACCEPT, _URL_VALIDATE_MEMBER_PLAN, _URL_FETCH_PROFILE_DETAILS, _URL_GET_OVERVIEW_DETAILS, _URL_PRODUCT_RENEW, _URL_PRODUCT_SATNDALONE_PURCHASE } from "../../common/config/config";
import { getApiErrorMessage } from "../../common/utils";
import { doPost } from "../../common/utils/api";
import { startApiLoading, stopApiLoading, startButtonSpinner, stopButtonSpinner } from '../../common/components/fieldbank/loader/action';

// Action Type
export const SELECTED_PACKS = "SELECTED_PACKS";
export const MEMBERSHIP_TYPE = "MEMBERSHIP_TYPE";

export const GET_PRODUCT_DETAILS = "GET_PRODUCT_DETAILS";
export const GET_GUEST_CARD_DETAILS = "GET_GUEST_CARD_DETAILS";
export const GET_ADD_ON_DETAILS = "GET_ADD_ON_DETAILS";
export const GET_VALIDATION_MSG = "GET_VALIDATION_MSG ";
export const GET_OVERVIEW_DATA = "GET_OVERVIEW_DATA";

export const UPDATE_ENROLL_STATUS = "UPDATE_ENROLL_STATUS";
export const UPDATE_STANDALONE_PURCHASE_STATUS = "UPDATE_STANDALONE_PURCHASE_STATUS";
export const UPDATE_RENEW_STATUS = "UPDATE_RENEW_STATUS";
export const UPDATE_PAYMENT_ACCEPT = "UPDATE_PAYMENT_ACCEPT";
export const GET_PROFILE_DATA = "GET_PROFILE_DATA";

export const ADD_TO_CART = "ADD_TO_CART"
export const REMOVE_FROM_CART = "REMOVE_FROM_CART"
export const SELECTED_TAB = "SELECTED_TAB"


export const selectPackage = config => {
  return {
    type: SELECTED_PACKS,
    payload: config
  }
}


export const addMembershipType = payload => {
  return {
    type: MEMBERSHIP_TYPE,
    payload: payload
  }
}

/**
 * Action call to get pack details
 * @param {JSON} payload Request payload to be dispatched
 * @author Amrutha J Raj
 */
export const getProductDetails = (payload) => {
  return async dispatch => {
    await doPost(_URL_PRODUCT_LIST, payload)
      .then((response) => {
        dispatch({
          type: GET_PRODUCT_DETAILS,
          payload: response.data
        })
      })
      .catch((error) => {
        dispatch({
          type: GET_PRODUCT_DETAILS,
          payload: { error: getApiErrorMessage(error.response.data) }

        })
      })
  };
}

/**
* Action call to save products to cart
* @param {JSON} payload Request payload to be dispatched
* @author Amrutha J Raj
*/
export const addToCart = (id, payload) => {
  return async dispatch => {
    return dispatch({
      type: ADD_TO_CART,
      payload: { [id]: payload }
    })
  }
}


/**
* Action call to save tab selected in profile
* @param {JSON} payload Request payload to be dispatched
* @author Amrutha J Raj
*/
export const setCurrentTab = (payload) => {
  return async dispatch => {
    return dispatch({
      type: SELECTED_TAB,
      payload: payload
    })
  }
}

/**
* Action call to get guest card details
* @param {JSON} payload Request payload to be dispatched
* @author Amrutha J Raj
*/
export const getGuestCards = (payload) => {
  return async dispatch => {
    await doPost(_URL_PRODUCT_LIST, payload)
      .then((response) => {
        dispatch({
          type: GET_GUEST_CARD_DETAILS,
          payload: response.data
        })
      })
      .catch((error) => {
        dispatch({
          type: GET_GUEST_CARD_DETAILS,
          payload: { error: getApiErrorMessage(error.response.data) }

        })
      })
  };
}

/**
* Action call to remove products from cart
* @param {JSON} payload Request payload to be dispatched
* @author Amrutha J Raj
*/
export const removeFromCart = (payload) => {
  return async dispatch => {
    return dispatch({
      type: REMOVE_FROM_CART,
      payload: payload
    })
  }
}

/**
* Action call to get add ons
* @param {JSON} payload Request payload to be dispatched
* @author Amrutha J Raj
*/
export const getAddOns = (payload) => {
  return async dispatch => {
    await doPost(_URL_PRODUCT_LIST, payload)
      .then((response) => {
        dispatch({
          type: GET_ADD_ON_DETAILS,
          payload: response.data
        })
      })
      .catch((error) => {
        dispatch({
          type: GET_ADD_ON_DETAILS,
          payload: { error: getApiErrorMessage(error.response.data) }

        })
      })
  };
}

/**
 * Action call for enrollment
 */
export const doEnrollment = (payload) => {
  return async dispatch => {
    dispatch(startApiLoading("doEnrollment"))
    await doPost(_URL_PRODUCT_ENROLL, payload)
    .then((response) => {
      dispatch(stopApiLoading("doEnrollment"))
      dispatch({
        type: UPDATE_ENROLL_STATUS,
        payload: response.data.object.memberActivityStatus
      })
    })
    .catch((error) => {
      dispatch(stopApiLoading("doEnrollment"))
      dispatch({
        type: UPDATE_ENROLL_STATUS,
        payload: { error: getApiErrorMessage(error.response.data) }
      })
    })
  }
}



/**
 * Action call for standalone purchase
 */
 export const doStandAlonePurchase = (payload) => {
  return async dispatch => {
    dispatch(startApiLoading("doStandAlonePurchase"))
    await doPost(_URL_PRODUCT_SATNDALONE_PURCHASE, payload)
    .then((response) => {
      dispatch(stopApiLoading("doStandAlonePurchase"))
      dispatch({
        type: UPDATE_STANDALONE_PURCHASE_STATUS,
        payload: response.data.object
      })
    })
    .catch((error) => {
      dispatch(stopApiLoading("doStandAlonePurchase"))
      dispatch({
        type: UPDATE_STANDALONE_PURCHASE_STATUS,
        payload: { error: getApiErrorMessage(error.response.data) }
      })
    })
  }
}

/**
 * Action call for accept payment
 */
export const acceptPayment = (payload) => {
  return async dispatch => {
    dispatch(startApiLoading("acceptPayment"))
    await doPost(_URL_PRODUCT_PAY_ACCEPT, payload)
    .then((response) => {
      dispatch(stopApiLoading("acceptPayment"))
      dispatch({
        type: UPDATE_PAYMENT_ACCEPT,
        payload: response.data
      })
    })
    .catch((error) => {
      dispatch(stopApiLoading("acceptPayment"))
      dispatch({
        type: UPDATE_PAYMENT_ACCEPT,
        payload: { error: getApiErrorMessage(error.response.data) }

      })
    })
  }
}

/**
 * 
 */
export const doRenew = (payload) => {
  return async dispatch => {
    dispatch(startApiLoading("renewSubscription"))
    await doPost(_URL_PRODUCT_RENEW, payload)
    .then((response) => {
      dispatch(stopApiLoading("renewSubscription"))
      dispatch({
        type: UPDATE_RENEW_STATUS,
        payload: response.data.object.memberActivityStatus
      })
    })
    .catch((error) => {
      dispatch(stopApiLoading("renewSubscription"))
      dispatch({
        type: UPDATE_RENEW_STATUS,
        payload: { error: getApiErrorMessage(error.response.data) }

      })
    })
  }
}

/**
* Action call to get warning messags
* @param {JSON} payload Request payload to be dispatched
* @author Amrutha J Raj
*/
export const getWarningMessages = (payload) => {
  return async dispatch => {
    await doPost(_URL_VALIDATE_MEMBER_PLAN, payload)
      .then((response) => {
        dispatch({
          type: GET_VALIDATION_MSG,
          payload: response.data
        })
      })
      .catch((error) => {
        dispatch({
          type: GET_VALIDATION_MSG,
          payload: { error: getApiErrorMessage(error.response.data) }

        })
      })
  };
}

/**
 * Profile fetching
 */
export const getProfileDetails = (payload) => {
  return async dispatch => {
    dispatch(startApiLoading("getProfileDetails"))
    await doPost(_URL_FETCH_PROFILE_DETAILS, payload)
      .then((response) => {
        dispatch(stopApiLoading("getProfileDetails"))
        dispatch({
          type: GET_PROFILE_DATA,
          payload: response.data
        })
      })
      .catch((error) => {
        let response = {
          "statuscode": "200",
          "statusMessage": "SUCCESS",
          "object": {
            "isAccrualValid": "NA",
            "isRedemptionValid": "NA",
            "memberAccount": {
              "companyCode": "NZ",
              "programCode": "KORU",
              "membershipNumber": "0008010701",
              "accountStatus": "Active",
              "accountStatusCode": "A",
              "accountExpiryDate": "30-Sep-2023",
              "enrolmentSource": "W",
              "enrolmentDate": "24-Sep-2021 00:00:00",
              "accountPeriodType": "R",
              "accountExpiryinMonths": 24,
              "extendToDay": "0",
              "extendToMonth": "0",
              "tier": "CLS",
              "tierFromDate": "24-Sep-2021",
              "suspendFlag": "0",
              "memberProfile": {
                "companyCode": "NZ",
                "membershipNumber": "0008010701",
                "membershipType": "I",
                "membershipStatus": "Active",
                "membershipStatusCode": "A",
                "enrollmentSource": "W",
                "enrollmentSourceCode": "W",
                "secretQuestion": "ABC",
                "secretAnswer": "ABC",
                "customerPassword": "4779BB616E3A94C4794A0A90C8E62DA1EE7C9C8E",
                "individualInfo": {
                  "memberNationality": "IN",
                  "preferredLanguage": "EN",
                  "preferredAddress": "H",
                  "preferredEmailAddress": "H",
                  "preferredPhoneNumber": "HM",
                  "title": "MR",
                  "givenName": "Federic",
                  "familyName": "Singh",
                  "displayName": "Mr Federic Singh",
                  "initials": "-Not Specified",
                  "gender": "M",
                  "maritalStatus": "S",
                  "dateOfBirth": "30-Sep-1990",
                  "passportNumber": "",
                  "countryOfResidence": "IN",
                  "staffID": "",
                  "companyName": "IBS",
                  "designation": "SSE",
                  "industryType": "",
                  "incomeBand": "",
                  "memberContactInfos": [
                    {
                      "addressType": "H",
                      "addressLine1": "House No",
                      "addressLine2": "Flat No",
                      "streetNumber": "Street",
                      "district": "District",
                      "city": "city",
                      "state": "state",
                      "country": "IN",
                      "zipCode": "093030",
                      "addressInvalid": false,
                      "emailAddress": "fed@gmal.com",
                      "phoneISDCode": "3543",
                      "phoneAreaCode": "5454",
                      "phoneNumber": "52354534",
                      "mobileISDCode": "+966",
                      "mobileAreaCode": "099",
                      "mobileNumber": "235235215235",
                      "faxNumber": "",
                      "skypeID": "",
                      "postalAddressStatus": "1",
                      "emailAddressStatus": "1",
                      "phoneNumberStatus": "1",
                      "mobileNumberStatus": "1",
                      "faxNumberStatus": "1"
                    }
                  ]
                }
              },
              "memberPreferences": [],
              "memberDynamicAttributes": [
                {
                  "attributeGroupName": "KORU Attribute",
                  "attributeCode": "17",
                  "groupInstanceID": "1",
                  "attributeValue": "1",
                  "type": "P"
                }
              ],
              "accrualSegment": []
            },
            "memberArtefactDetail": [],
            "areMandatoryFieldsFilled": true
          }
        }
        dispatch(stopApiLoading("getProfileDetails"))
        dispatch({
          type: GET_PROFILE_DATA,
          payload: { error: getApiErrorMessage(error.response.data) }
          // payload: response
        })
      })
  };
}


/**
* Action call to get Overview data
* @param {JSON} payload Request payload to be dispatched
* @author Geo George
*/
export const getOverviewData = (payload) => {
  return async dispatch => {
    await doPost(_URL_GET_OVERVIEW_DETAILS, payload)
      .then((response) => {
        dispatch({
          type: GET_OVERVIEW_DATA,
          payload: response.data
        })
      })
      .catch((error) => {
        dispatch({
          type: GET_OVERVIEW_DATA,
          payload: { error: getApiErrorMessage(error.response.data) }
        })
      })
  };
}

export const clearOverviewData = () => {
  return async dispatch => {
    return dispatch({
      type: GET_OVERVIEW_DATA,
      payload: {}
    })
  }


}