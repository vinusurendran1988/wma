import { GUEST_CARD, MEM_TYPE_PT } from "../Constants"


/**
 * Utils method to get the guest card object from the overview response
 * @param {Object} overviewObject 
 * @returns Guestcard
 */
export const getGuestCardDetails = (overviewObject) => {
    let guestCard
    if (overviewObject && overviewObject.membershipDetails &&
        overviewObject.membershipDetails.subscription &&
        overviewObject.membershipDetails.subscription.length > 0) {
        guestCard = overviewObject.membershipDetails.subscription.find(item => item.type == GUEST_CARD)
    }
    return guestCard
}

/**
 * Utils method to check if the member is a KORU partner
 * @param {Object} overviewObject 
 * @returns boolean 
 */
export const checkKoruPartner = (overviewObject) => {
    let isKoruPartner = false
    if (overviewObject && overviewObject.profile &&
        Object.keys(overviewObject.profile).length > 0 && overviewObject.profile.nomineeType) {
        if (overviewObject.profile.nomineeType == MEM_TYPE_PT) {
            isKoruPartner = true
        }
        return isKoruPartner
    }
}