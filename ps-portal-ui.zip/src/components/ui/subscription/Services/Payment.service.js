import API_PATHS from "../Constants/api-paths.constant";

const requestDetails = {
    headers: {
        'x-auth-token': ' 27df7a3b28c0dc5983a390a63eac7f99087ff009',
        'x-auth-channel': 'WEB@EYH',
        "Content-Type": "application/json",
    }
};

/**
 * @description Service for getting the payment token.
 */

export const getPaymentToken = async () => {
    let requestDetailsObj = {
        method: "POST",
        ...requestDetails
    };
    const response = await fetch(API_PATHS.PAYMENT_GET_TOKEN, {
        ...requestDetailsObj
    });
    if (!response.ok)
        return Promise.reject(body.message || "Error in payment token API");
    const body = await response.json();
    return body;
};

/**
 * @description Service for getting the payment redirection URL.
 * @param {number} requestDetails request body
 */
export const getPaymentRedirectionUrl = async (token, sampleRequest) => {
    let requestDetailsObj = { ...sampleRequest, ...requestDetails };
    requestDetailsObj.method = "POST";
    requestDetailsObj.headers.Authorization = token;
    requestDetailsObj.body = JSON.stringify(sampleRequest);
    const response = await fetch(API_PATHS.PAYMENT_REDIRECT, {
        ...requestDetailsObj
    });
    if (!response.ok)
        return Promise.reject(body.message || "Error in payment redirection URL API");
    const body = await response.json();
    return body;
};