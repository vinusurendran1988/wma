import axios from 'axios';
import {
    _URL_PRODUCT_LIST
} from '../../../common/config/config';

export class PacksService {

    getPacksDetails() {
        let req = {
            "object": {
                "companyCode": "NZ",
                "programCode": "KORU",
                "membershipNumber": "16",
                "activityCode": "ME"
            }
        }
        return axios.post(_URL_PRODUCT_LIST, req)
            .then(res => {
                let baseTotal = 0;
                let final = res.data.object.productDetails.map((data, index) => {
                    data.isSelected = index == 1 ? true : false;
                    // data.showDealSection = index > 0 ? true : false;
                    data.showDealSection = false;
                    let year1 = parseInt(data.startDate.split(" ")[2]);
                    let year2 = parseInt(data.endDate.split(" ")[2]);
                    data.duration = (year2 - year1) + " year";

                    if (index == 0) {baseTotal = data.price.total}
                    if (index > 0) {
                        data.price.totalWithoutDiscount = parseInt(baseTotal) * (year2 - year1);
                        data.price.discount = parseInt(data.price.totalWithoutDiscount) - parseInt(data.price.total)
                    }
                    data.price.joiningFee = parseInt(data.price.joiningFee)
                    data.price.cost       = parseInt(data.price.cost)

                    return data;
                })
                return final;
            });
    }

    getPaymentDetails() {
        return axios.get('data/samplePaymentRequest.json')
            .then(res => res.data);
    }
}