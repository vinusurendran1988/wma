import { getFormattedDate, checkDateIsLessThanCurrentDate } from "../../../common/utils";
import { DATE_FORMAT_DMMMYYYY_WITH_SPACE, EXPIRED, EXPIRING, GUEST_CARD, LIFETIME, MEM_TYPE_PR, MEM_TYPE_PT, VALID_TO } from "../Constants";


export const getDigitalCardDetails = (profileData, t) => {
    return {
        displayName: profileData.profile && profileData.profile.givenName + " " + profileData.profile.familyName,
        title: t("digital_card.title"),
        expiryMessage: getExpiryMessage(profileData, t),
        descriptionRequired: false,
        membershipType: profileData.profile && profileData.membershipDetails &&
            getMembershiptype(profileData.profile.nomineeType, profileData.membershipDetails.userMessageDetails, t),
        footerMessage: checkGuestCardPresent(profileData, t),
        membershipNumber: profileData.profile && profileData.profile.membershipNumber
    }

}

const getExpiryMessage = (profileData, t) => {
    return profileData.membershipDetails && profileData.membershipDetails.userMessageDetails &&
        profileData.membershipDetails.userMessageDetails.map(item => {
            switch (item.code.toLowerCase()) {
                case VALID_TO: {
                    return t("digital_card.expiry.validTo").replace("{EXPIRY_DATE}", getFormattedDate(profileData.membershipDetails.expiryDate, DATE_FORMAT_DMMMYYYY_WITH_SPACE))
                }
                case EXPIRING: {
                    return t("digital_card.expiry.expires").replace("{EXPIRY_DATE}", getFormattedDate(profileData.membershipDetails.expiryDate, DATE_FORMAT_DMMMYYYY_WITH_SPACE))
                }
                case EXPIRED: {
                    return t("digital_card.expiry.expired").replace("{EXPIRY_DATE}", getFormattedDate(profileData.membershipDetails.expiryDate, DATE_FORMAT_DMMMYYYY_WITH_SPACE))
                }
                default:
                    break;
            }
        })
}

const getMembershiptype = (nomineeType, messageDetailsArray, t) => {
    const ifLifetimeMember = messageDetailsArray.find(item => item.code == LIFETIME)
    if (nomineeType == MEM_TYPE_PR) {
        if (ifLifetimeMember) {
            return t('digital_card.lifetimeMember')
        }
    }
    else if (nomineeType == MEM_TYPE_PT) {
        if (ifLifetimeMember) {
            return t('digital_card.lifetimePartner')
        }
        else {
            return t('digital_card.koruPartner')
        }
    }
}
const checkGuestCardPresent = (profileData, t) => {
    let isExpired
    if (profileData && profileData.membershipDetails &&
        profileData.membershipDetails.subscription) {
        const guestCard = profileData.membershipDetails.subscription.find(item => item.type == GUEST_CARD)
        if (guestCard && Object.keys(guestCard).length > 0) {
            isExpired = checkDateIsLessThanCurrentDate(guestCard.expiryDate)
            if (!isExpired) {
                return {
                    name: t('digital_card.extraGuest'),
                    message: t("digital_card.expiry.expires").replace("{EXPIRY_DATE}", getFormattedDate(guestCard.expiryDate, DATE_FORMAT_DMMMYYYY_WITH_SPACE))
                }
            }
        }
    }
}
