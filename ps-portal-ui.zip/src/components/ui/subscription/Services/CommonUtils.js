import { getItemFromBrowserStorage, setItemToBrowserStorage, removeItemFromBrowserStorage } from "../../../common/utils/storage.utils";
import { getCurrentDate, getDiffByTwoDate, getFormattedDate } from '../../../common/utils';
import { DATE_FORMAT_DDMMMYYYY_WITH_HYPHEN, DATE_FORMAT_DDMMYYYY_WITH_SPACE, DAYS } from '../../../ui/subscription/Constants';
import moment from "moment";
/**
 * 
 */
export const isOnBehalfAdminEnrolment = () => {
    let data = getItemFromBrowserStorage("corpEmployeeDetails");
    if (!data) {
        return false;
    }
    let employee = JSON.parse(data);
    if (employee != null && employee.membershipNumber != "") {
        return true;
    } else {
        return false;
    }
}

/**
 * 
 */
export const getOnBehalfEmployeeDetails = () => {
    let data = getItemFromBrowserStorage("corpEmployeeDetails");
    if (data) {
        return JSON.parse(data);
    } else {
        return false;
    }
}

/**
 * 
 */
export const isShowCorporateLink = (userData) => {
    try {
        let programs = userData.programs;
        if (Object.keys(userData.programs).includes("corporateInfo")) {
            return  userData.programs.corporateInfo.length ? true : false;
        } else {
            return false;
        }
    } catch (e) {
        return false;
    }
}

/**
 * 
 */
export const getCompanyData = (memberDynamicAttr) => {
    let companyId = memberDynamicAttr.filter((record) => {
        if(record.attributeCode == '12') {
            return record;
        }
    });
    let companyName = memberDynamicAttr.filter((record) => {
        if(record.attributeCode == '20') {
            return record;
        }
    });
    if (companyId.length && companyName.length) {
        return {companyName: companyName[0].attributeValue, companyId: companyId[0].attributeValue}
    } else {
        return {companyName: "", companyId: ""}
    }
}

/**
 * 
 */
export const getCompanyContractExpiry = (memberDynamicAttr) => {
    let date = memberDynamicAttr.filter((record) => {
        if(record.attributeCode == '14') {
            return record;
        }
    });
    let validFrom = memberDynamicAttr.find((record) => {
        if(record.attributeCode == '13') {
            return record;
        }
    });
    let isShow = false;
    if (date.length && date[0].attributeValue != "") {
        isShow = !checkIfDateIsAfterGracePeriod(date[0].attributeValue);
    }
    
    if (validFrom && validFrom.attributeValue) {
    let isFutureDate = checkDateisFutureDate(getFormattedDate(validFrom.attributeValue, DATE_FORMAT_DDMMYYYY_WITH_SPACE))
    if(isFutureDate)
        isShow = false
    }
   

    let contractExpiry = (date.length && isShow) ? date[0].attributeValue : "";

    if (contractExpiry.endsWith("2099")) {
        contractExpiry = "No expiry";
    } else if (contractExpiry) {
        contractExpiry = getFormattedDate(contractExpiry, DATE_FORMAT_DDMMYYYY_WITH_SPACE);
    } else {
        contractExpiry = "";
    }
    return contractExpiry;
}
/**
 * Method to check if a given date is after grace period
 * @param {*} dateToCheck 
 * @returns boolean
 */
export const checkIfDateIsAfterGracePeriod = (dateToCheck) => {
    let newDate = new Date(dateToCheck)
    newDate.setMonth(newDate.getMonth() + 1);
    newDate = getFormattedDate(newDate, DATE_FORMAT_DDMMYYYY_WITH_SPACE)
    let gracePeriodDate = moment(newDate).clone().endOf('month').format(DATE_FORMAT_DDMMYYYY_WITH_SPACE)
    const daysToExpire = getDiffByTwoDate(gracePeriodDate, getCurrentDate(DATE_FORMAT_DDMMYYYY_WITH_SPACE), DATE_FORMAT_DDMMYYYY_WITH_SPACE, DATE_FORMAT_DDMMYYYY_WITH_SPACE, DAYS)

    if (daysToExpire < 0) {
        return true
    }
    return false
}

/**
 * Method to check if a given date is a future date
 * @param {*} dateToCheck 
 * @returns boolean
 */
export const checkDateisFutureDate = (dateToCheck) => {
    let formattedDate = getFormattedDate(dateToCheck, DATE_FORMAT_DDMMYYYY_WITH_SPACE)
    const days = getDiffByTwoDate(formattedDate, getCurrentDate(DATE_FORMAT_DDMMYYYY_WITH_SPACE),
        DATE_FORMAT_DDMMYYYY_WITH_SPACE, DATE_FORMAT_DDMMYYYY_WITH_SPACE, DAYS)
        if(days > 0) return true
        false
}