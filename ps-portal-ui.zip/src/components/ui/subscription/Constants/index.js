export const SUBSCRIPTION_AGE_MSG = "SUBSCRIPTION_AGE_MSG"
export const SUBSCRIPTION_TIER_MSG = "SUBSCRIPTION_TIER_MSG"
export const WAIVER_END_DATE_MSG = "WAIVER_END_DATE_MSG"
export const DOLLAR = "$"
export const ZERO_DOLLAR ="$0.00"
export const EMPTY_SPACES =" "
export const JOIN ="join"
export const RENEW ="renew"
export const STANDALONE="preferences"
export const LIFETIME ="LIFETIME"

export const DATE_FORMAT_DDMMYYYY_WITH_SPACE = "DD MMM YYYY"
export const DATE_FORMAT_DD_MM_YYYY = "DD_MM_YYYY"
export const DATE_FORMAT_DMMMYYYY_WITH_SPACE = "D MMM YYYY"
export const DATE_FORMAT_DDMMMYYYY_WITH_HYPHEN = "DD-MMM-YYYY"


export const DAYS = "days"
export const VALID_TO = "valid_to"
export const MEM_TYPE_PR = "PR"
export const MEM_TYPE_PT = "PT"
export const MEM_TYPE_PR_PT = "PR_PT"
export const EXPIRED = "expired"
export const EXPIRING = "expiring"
export const GOLD_ELITE = "gold_elite"

export const EXPIRED_ALERT_CLASS_NAME = "alert alert-warning alert--custom"
export const EXPIRES_ALERT_CLASS_NAME = "alert alert-info alert--custom"
export const RENEW_ENDPOINT = "/renew"
export const JOIN_ENDPOINT = "/join"
export const STANDALONE_ENDPOINT = "/preferences"
export const GUEST_CARD = "guestCard"

export const TAB_PRODUCT_LIST ="selectPlan"
export const TAB_CHECKOUT ="checkout"
export const TAB_PAYMENT ="payment"
export const TAB_SUCCESS ="success"

export const FLOW_TYPE = "flowType"








