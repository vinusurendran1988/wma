const BASE_API_PATH = "http://192.168.45.84:8060";
const API_PATHS = {
  PAYMENT_GET_TOKEN: `${BASE_API_PATH}/auth`,
  PAYMENT_REDIRECT: `${BASE_API_PATH}/api/public/v1.1/payment/redirectPayment`,
};

export default API_PATHS;
