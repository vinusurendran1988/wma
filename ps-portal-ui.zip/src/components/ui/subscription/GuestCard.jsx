import React, { useEffect } from "react";
import { withTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { getCurrentDate, getDiffByTwoDate } from "../../common/utils";
import { 
  BROWSER_STORAGE_KEY_COMPANY_CODE, 
  BROWSER_STORAGE_KEY_PROGRAM_CODE, 
  BROWSER_STORAGE_KEY_DEFAULT_PROGRAM_CODE,
  BROWSER_STORAGE_KEY_MEMBERSHIP_NO, 
  getItemFromBrowserStorage, 
} from "../../common/utils/storage.utils";
import { getGuestCards } from "./actions";
import { DATE_FORMAT_DDMMMYYYY_WITH_HYPHEN, DATE_FORMAT_DD_MM_YYYY, DOLLAR } from "./Constants";
import { getOnBehalfEmployeeDetails, isOnBehalfAdminEnrolment} from "./Services/CommonUtils"
import { SELECT_GUEST_CARD, trackData } from "../../common/utils/analytics.utils"
import parse from 'html-react-parser';


const GuestCard = (props) => {

    const guestCardDetails = useSelector(state => state.subscriptionReducer.guestCardDetails)
    const [guestCardList, setGuestCardList] = React.useState([])
    const [filteredGuestCardDetails, setFilteredGuestCardDetails] = React.useState(null)
    const cartItems = useSelector(state => state.cartReducer.cartDetails)
    const guestCardCartItems = getItemsFromCart("guestCard", cartItems)
    const [selectedGuestCard, setSelectedGuestCard] = React.useState({})
    const memType = useSelector(state => state.membershipTypeReducer.type)
    let isGuestCardSelected = false
    const { t, status, configSection,standAlonePurchaseFlag,isGuestCardIsVisible } = props
    const onBehalfEmployee = getOnBehalfEmployeeDetails();

    if (guestCardCartItems && Object.keys(guestCardCartItems).length > 0 && guestCardCartItems.isSelected) {
        isGuestCardSelected = guestCardCartItems.isSelected
        if (JSON.stringify(selectedGuestCard) != JSON.stringify(guestCardCartItems)) {
            setSelectedGuestCard(guestCardCartItems)
        }
    }
    const dispatch = useDispatch()

    useEffect(() => {
        if (!guestCardDetails) {
            dispatch(getGuestCards({
                "object": {
                    "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                    "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_DEFAULT_PROGRAM_CODE),
                    "membershipNumber": isOnBehalfAdminEnrolment() ? onBehalfEmployee.membershipNumber : getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                    "activityCode": "GC",
                    "flowType":memType
                }
            }))
        }
    }, []);
    useEffect(() => {
        if (guestCardDetails) {
          setGuestCardList(guestCardDetails.productDetails)
        }
    }, [guestCardDetails]);

    useEffect(() => {
        if (guestCardList) {
            if (standAlonePurchaseFlag && isGuestCardIsVisible) {
                filterProductList()
            } else {
                setFilteredGuestCardDetails(guestCardList)
            }
        }
    }, [guestCardList]);

    const filterProductList = ()=>{
        const profileOverviewData = JSON.parse(getItemFromBrowserStorage("overView"));
        const expiryDate = profileOverviewData.response.membershipDetails.expiryDate;
        const currentDate = getCurrentDate();
        const monthToExpire = getDiffByTwoDate(expiryDate, currentDate, DATE_FORMAT_DDMMMYYYY_WITH_HYPHEN, DATE_FORMAT_DD_MM_YYYY,"months")
        const filteredList = guestCardList.filter(e=>e.duration <= monthToExpire);        
        // var filteredList = guestCardList.map(function(el) {
        //     var o = Object.assign({}, el);
        //     o.disabled = el.duration <= monthToExpire?false:true;
        //     return o;
        // }) 
        if(filteredList){
            setFilteredGuestCardDetails(filteredList)
        }
    }
    return (
        <>
            {(!standAlonePurchaseFlag || (standAlonePurchaseFlag && isGuestCardIsVisible)) && configSection && configSection.fields && filteredGuestCardDetails && filteredGuestCardDetails.length?
                <div className="col-lg-12">
                    {configSection.fields.title && configSection.fields.title.visibility &&
                        <h2>{t('subscription.guestCard.title')} <span>
                            {standAlonePurchaseFlag?"":t('subscription.guestCard.subTitle')}</span></h2>
                    }
                    {configSection.fields.subTitle && configSection.fields.subTitle.visibility &&
                        <h3>
                            {filteredGuestCardDetails &&
                                calculateRange(t('subscription.guestCard.subTitleOne'), filteredGuestCardDetails)}</h3>
                    }
                    {configSection.fields.description && configSection.fields.description.visibility &&
                        <p> {parse(t('subscription.guestCard.subTitleTwo'))}  
                        {1 == 0 && <a href="https://www.airnewzealand.co.nz/koru-benefits#guest-card"> {t('subscription.guestCard.moreInfo')}</a>}
                       </p>
                    }

                    <div className="row">
                        {configSection.fields.contentBody && configSection.fields.contentBody.visibility &&  filteredGuestCardDetails && 
                            filteredGuestCardDetails.map(guestCard => {
                                return <div className={configSection.fields.contentBody.className ? configSection.fields.contentBody.className : "col-lg-6"}>
                                    <div className={`card guest-card ${(status || guestCard.disabled) && "guest-card--inactive"} ${selectedGuestCard.id == guestCard.id &&
                                        JSON.stringify(guestCardCartItems) == JSON.stringify(selectedGuestCard) ? "guest-card--selected" : ""}`}>
                                        <div className="card-body">
                                            <div>
                                                <h5 className="guest-card__title">${guestCard.price && guestCard.price.latestCost}</h5>
                                                <p className="card-text"> {t(`guestCardName.${guestCard.i18nCode}`)}</p>
                                            </div>
                                            <div className="guest-card__rate">
                                                <a className={`btn btn-outline-primary preferences__btn  ${status || guestCard.disabled ? "disabled" : ""}`}
                                                    disabled={status || guestCard.disabled}
                                                    onClick={() => {
                                                        trackData(SELECT_GUEST_CARD, [guestCard, t(`guestCardName.${guestCard.i18nCode}`)]);
                                                        setSelectedGuestCard(guestCard)
                                                        props.selectedGuestCard(guestCard)
                                                    }
                                                    }>
                                                    {selectedGuestCard.id == guestCard.id &&
                                                        JSON.stringify(guestCardCartItems) == JSON.stringify(selectedGuestCard)
                                                        ?
                                                        <> Selected &nbsp;
                                                            < svg aria-hidden="true" focusable="false" data-prefix="fal" data-icon="check" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" className="svg-inline--fa fa-check fa-w-14 fa-2x">
                                                                <path fill="currentColor" d="M413.505 91.951L133.49 371.966l-98.995-98.995c-4.686-4.686-12.284-4.686-16.971 0L6.211 284.284c-4.686 4.686-4.686 12.284 0 16.971l118.794 118.794c4.686 4.686 12.284 4.686 16.971 0l299.813-299.813c4.686-4.686 4.686-12.284 0-16.971l-11.314-11.314c-4.686-4.686-12.284-4.686-16.97 0z" className=""></path>
                                                            </svg>
                                                        </>
                                                        :
                                                        "Select"}
                                                </a></div>
                                        </div>
                                    </div>
                                </div>
                            })}
                    </div>
                </div>:<></>
            }
        </>
    );
}


const getItemsFromCart = (itemType, cartItems) => {
    const items = cartItems && Object.keys(cartItems).length > 0 &&
        cartItems[itemType]
    return items
}

const calculateRange = (message, guestCards) => {
    let length = guestCards.length
    const sortedGuestCards = guestCards.sort((a, b) => {
        return a.duration - b.duration
    });
    const minGuestCard = sortedGuestCards[0] && Object.keys(sortedGuestCards[0]).length > 0 &&
        sortedGuestCards[0].price && sortedGuestCards[0].price.latestCost
    const maxGuestCard = sortedGuestCards[length - 1] &&
        Object.keys(sortedGuestCards[length - 1]).length > 0 &&
        sortedGuestCards[length - 1].price && sortedGuestCards[length - 1].price.latestCost

    const finalText = message + DOLLAR + minGuestCard + " - "
        + DOLLAR + maxGuestCard
    return finalText
}
export default withTranslation()(GuestCard)
