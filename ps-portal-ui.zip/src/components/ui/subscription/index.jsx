import React, { useEffect, useState, usePrevious } from "react";
import { withTranslation } from 'react-i18next';
import { connect, useDispatch, useSelector } from 'react-redux';
import Loader from '../../common/components/fieldbank/loader/Loader';
import { withSuspense } from '../../common/utils';
import { 
  BROWSER_STORAGE_KEY_COMPANY_CODE, 
  BROWSER_STORAGE_KEY_PROGRAM_CODE, 
  BROWSER_STORAGE_KEY_DEFAULT_PROGRAM_CODE,
  BROWSER_STORAGE_KEY_MEMBERSHIP_NO, 
  getItemFromBrowserStorage, 
  removeItemFromBrowserStorage, 
  setItemToBrowserStorage 
} from "../../common/utils/storage.utils";
import { addMembershipType, addToCart, getProductDetails, getWarningMessages, removeFromCart } from "./actions";
import { FLOW_TYPE, JOIN, RENEW, STANDALONE, TAB_PRODUCT_LIST, TAB_SUCCESS, WAIVER_END_DATE_MSG } from "./Constants";
import GuestCard from "./GuestCard";
import PlanSummary from "./PlanSummary";
import Preferences from "./Preferences";
import ProductList from "./ProductList";
import parse from 'html-react-parser';
import { isEmpty } from "lodash";
import { withRouter } from "react-router";
import { NAVIGATE_CLUB, NAVIGATE_CLUB_OVERVIEW } from "../../common/utils/urlConstants";
import { CONFIG_SECTION_SUBSCRIPTION } from "../../common/utils/Constants";
import { fetchConfiguration } from "../../common/middleware/redux/commonAction";
import Custommessage from "../../common/components/custommessage";
import { getOnBehalfEmployeeDetails, isOnBehalfAdminEnrolment} from "./Services/CommonUtils"


const Subscription = (props) => {
  const [productList, setProductList] = useState(null)
  const [warning, setWarning] = useState([])
  const [cartItem, setCartItem] = React.useState([])
  const [isGuestCardIsVisible, setIsGuestCardIsVisible] = useState(true)
  const [standAlonePurchaseFlag, setStandAlonePurchaseFlag] = useState(false)
  const productDetails = useSelector(state => state.subscriptionReducer.productDetails)
  const warningMessages = useSelector(state => state.warningMessageReducer.warnings)
  const det = useSelector(state => state.subscriptionReducer)
  const guestCardDetails = useSelector(state => state.subscriptionReducer.guestCardDetails)
  const cartItems = useSelector(state => state.cartReducer.cartDetails)
  const memType = useSelector(state => state.membershipTypeReducer.type)
  const membershipType = memType == STANDALONE?JOIN:memType;
  const config = useSelector(state => state.configurationReducer[CONFIG_SECTION_SUBSCRIPTION])

  const onBehalfEmployee = getOnBehalfEmployeeDetails();
  const onBehalfMessageBannerText = isOnBehalfAdminEnrolment() ? "You’re purchasing this membership on behalf of <b>"+
                                    onBehalfEmployee.fname+" "+onBehalfEmployee.lname
                                    +"</b>.You’ll see details from their Airpoints profile in relation to this purchase." : "";

  const dispatch = useDispatch()
  useEffect(() => {
    if (!config || config && Object.keys(config).length) {
      dispatch(fetchConfiguration(CONFIG_SECTION_SUBSCRIPTION))
    }
    if (props.match && props.match.params
      && props.match.params.type) {
      setItemToBrowserStorage(FLOW_TYPE,props.match.params.type)  
      switch (props.match.params.type) {
        case JOIN: {
          dispatch(addMembershipType(JOIN))
          break
        }
        case RENEW: {
          dispatch(addMembershipType(RENEW))
          break
        }
        case STANDALONE: {
          dispatch(addMembershipType(STANDALONE))
          setStandAlonePurchaseFlag(true)
          break
        }
        default: {
          window.location = `#${NAVIGATE_CLUB}` + '/join'
          dispatch(addMembershipType(JOIN))
          break
        }
      }
    } else {
      dispatch(addMembershipType(JOIN))
    }

  }, []);

  useEffect(() => {
    if (standAlonePurchaseFlag) {
      getStandAloneData();
    }
  }, [standAlonePurchaseFlag]);


  const getStandAloneData = () =>{
    const profileOverviewData = JSON.parse(getItemFromBrowserStorage("overView"));
    if(profileOverviewData && profileOverviewData.response){
      if(profileOverviewData.response.profile && profileOverviewData.response.profile.nomineeType == "PT"){
        setIsGuestCardIsVisible(false)
      }
      if(profileOverviewData.response.membershipDetails && profileOverviewData.response.membershipDetails.subscription && profileOverviewData.response.membershipDetails.subscription.length>0){
        if(profileOverviewData.response.membershipDetails.subscription.filter(e => e.type = "guestCard")){
          setIsGuestCardIsVisible(false)
        }
      }
    }
  }

  useEffect(() => {
    if (productDetails && Object.keys(productDetails).length > 0) {
      getProductList(productDetails);
    }
  }, [productDetails]);

  useEffect(() => {
    if (membershipType && !isEmpty(membershipType)) {
      switch (membershipType) {
        case JOIN: {
          fetchWarnings("productList")
          fetchProductDetails("ME","JOIN")
          break
        }
        case RENEW: {
          fetchWarnings("renewProductList")
          fetchProductDetails("RA","RENEW")
          break
        }
      }
    }
  }, [membershipType]);


  const fetchProductDetails = (activityCode,flowType) => {
    if ((!productDetails || (productDetails && Object.keys(productDetails).length == 0)) && memType != STANDALONE) {
      dispatch(getProductDetails({
        "object": {
          "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
          "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_DEFAULT_PROGRAM_CODE),
          "membershipNumber": isOnBehalfAdminEnrolment() ? onBehalfEmployee.membershipNumber : getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
          "activityCode": activityCode,
          "flowType": flowType

        }
      }))
    }
  }

  const fetchWarnings = (validationType) => {
    //if (!warningMessages) {
      dispatch(getWarningMessages({
        "object": {
          "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
          "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_DEFAULT_PROGRAM_CODE),
          "membershipNumber": isOnBehalfAdminEnrolment() ? onBehalfEmployee.membershipNumber : getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
          "validationType": validationType
        }
      }))
    //}
  }

  const calculateTotal = (price) => {
    const newPrice = price
    newPrice.originalFee = price.originalFee == null ? 0 : price.originalFee
    newPrice.latestFee = price.latestFee == null ? 0 : price.latestFee
    // Discount Calculation
    newPrice.latestTotal = parseInt(price.latestCost) + parseInt(newPrice.latestFee)
    newPrice.originalTotal = parseInt(price.originalCost) + parseInt(newPrice.originalFee);
    return newPrice
  }

  const getProductList = (product) => {
    let baseTotal = 0;
    let final = product.productDetails.map((data, index) => {
      data.isSelected = false
      data.showDiscount = false
      data.duration = isNaN(data.duration) ? data.duration : data.duration > 1 ? data.duration + " years" : data.duration + " year"
      data.price = calculateTotal(data.price)
      if (data.price.latestTotal < data.price.originalTotal) {
        data.showDiscount = true;
        data.price.discountValue = data.price.originalTotal - data.price.latestTotal;
      }
      return data
    });
    /**
     * This is to default selection of product if only one exist
     * Plan Summary will be shown by default
     */
    if ((warning && !getValidationStatus()) || (warning.length == 0)) {
      if (final.length == 1) {
        final[0].isSelected = true;
        // setCartItem(final[0]);
        setCartItem(oldArray => [...oldArray, final[0]]);
        dispatch(addToCart("membership", final[0]))
      }
    }
    /**
     * This is to show the edit plan flow.
     */
    if (getItemFromBrowserStorage("cartItem")) {
      let selection = JSON.parse(getItemFromBrowserStorage("cartItem")).membership;
      if (selection) {
        removeItemFromBrowserStorage("cartItem");
        final = final.map((data, index) => {
          if (data.id == selection.id) {
            data.isSelected = true;
          }
          return data;
        });
        // setCartItem(selection);
        setCartItem(oldArray => [...oldArray, selection])
        dispatch(addToCart("membership", selection))
      }
    }
    setProductList(final);
  }

  const getValidationStatus = () => {
    let statusFlag = false
    warning.map(warn => {
      if (warn.status) {
        statusFlag = true
        return true
      }
    })
    return statusFlag;
  }

  const onPackSelected = (selectedIndex, product) => {
    let newProductList = productList.map((product, index) => {
      product.isSelected = (index == selectedIndex) ? true : false;
      return product;
    });
    // setCartItem(product)
    setCartItem(oldArray => [...oldArray, product]);
    dispatch(addToCart("membership", product))
    setProductList(newProductList)
  };

  const onGuestCardSelected = (guestCard) => {
    const itemToRemove = cartItems && Object.keys(cartItems).length > 0 && cartItems["guestCard"]
    guestCard.isSelected = true
    if (guestCard != itemToRemove) {
      dispatch(addToCart("guestCard", guestCard))
      setCartItem(oldArray => [...oldArray, guestCard])
    }
    else {
      dispatch(removeFromCart("guestCard"))

      setCartItem(oldArray => oldArray.filter(item => item != guestCard))

    }
  }

  const onPreferenceSelected = (addOn) => {
    const itemToRemove = cartItems && Object.keys(cartItems).length > 0 && cartItems["addOn"]
    addOn.isSelected = true
    if (addOn != itemToRemove) {
      dispatch(addToCart("addOn", addOn))
      setCartItem(oldArray => [...oldArray, addOn])
    }
    else {
      dispatch(removeFromCart("addOn"))
      setCartItem(oldArray => oldArray.filter(item => item != addOn))

    }
  }


  const getWarningsObject = (warningList) => {
    const sortedWarningList = warningList.sort((a, b) => {
      return a.priorityOrder - b.priorityOrder
    });
    if (JSON.stringify(warning) != JSON.stringify(sortedWarningList)) {
      let priorityList = sortedWarningList.filter(e => e.priorityOrder == sortedWarningList[0].priorityOrder);
      setWarning(priorityList.sort((a, b) => (b.messageType > a.messageType) ? 1 : ((a.messageType > b.messageType) ? -1 : 0)))
    }
  }

  const renderSubscriptionBody = (order, sectionConfig, index) => {
    if (sectionConfig && sectionConfig.visibility) {
      switch (order) {
        case "membership": return <><ProductList status={getValidationStatus()} productList={productList} onPackSelected={(index, product) => onPackSelected(index, product)} configSection={sectionConfig} standAlonePurchaseFlag = {standAlonePurchaseFlag} config={config} />
       {!standAlonePurchaseFlag && <hr class="separator" /> }</>
        case "guestCard": return <GuestCard status={getValidationStatus()} selectedGuestCard={(guestCard) => onGuestCardSelected(guestCard)} configSection={sectionConfig} standAlonePurchaseFlag = {standAlonePurchaseFlag} isGuestCardIsVisible={isGuestCardIsVisible}/>
        case "adddOn": return (memType != STANDALONE) ? '' : <Preferences status={getValidationStatus()} selectedPreferences={(addOn) => onPreferenceSelected(addOn)} configSection={sectionConfig} standAlonePurchaseFlag = {standAlonePurchaseFlag}/>
        case "summary": return <PlanSummary cartItem={cartItem} status={getValidationStatus()} configSection={sectionConfig} standAlonePurchaseFlag = {standAlonePurchaseFlag}/>
      }
    }
    return <></>
  }

  const { t } = props;

  if (warningMessages && Object.keys(warningMessages).length > 0 &&
    warningMessages.userMessageDetailList &&
    Object.keys(warningMessages.userMessageDetailList).length > 0) {
    if (warning && Object.keys(warning).length == 0) {
      getWarningsObject(warningMessages.userMessageDetailList)
    }
  }
  const getTabclassName = (tabName) =>{
     if(tabName == TAB_PRODUCT_LIST){
       return "cart-view__timeline--first cart-view__timeline--active cart-view__timeline--first cart-view__timeline--current"
     }else if(tabName == TAB_SUCCESS){
      return "cart-view__timeline--last"
     }
     return ""
  }
  return (
    <main className="member-plan">
      {
        config &&
        config.ui &&
        config.ui.layout &&
        config.ui.layout[membershipType] &&
        config.ui.layout[membershipType].tabsOrder &&
        <ol className="cart-view__timeline">
          {config.ui.layout[membershipType].tabsOrder.map(tab => {
            return <li className={getTabclassName(tab)}>{t(`subscription.${tab}`)}</li>
          })
          }
        </ol>
      }
      {isOnBehalfAdminEnrolment() && 
        <>
          <br />
          <Custommessage
            type={"info"}
            message={[parse(onBehalfMessageBannerText)]}
            canTranslate={false}
          /><br />
        </>
      }
      <div>
        <h1>{standAlonePurchaseFlag?t('subscription.standAlone.title'):t('subscription.selectMemType')}</h1>
        {!standAlonePurchaseFlag && <p>{t('subscription.description')}</p>}
      </div>
      {warning.map(message => {
        return (
          <Custommessage
            type={message.messageType == "WARN" ? "warning" : message.messageType.toLowerCase()}
            message={message.messageCode != WAIVER_END_DATE_MSG ?
              [parse(t(`subscription.userMessages.${message.messageCode}`))] :
              [parse(t(`subscription.userMessages.${message.messageCode}`).replace("${WAIVER_END_DATE}", message.value))]}
            canTranslate={false}
          />
        )
      })}
      <div className="latamClub">
        <div className="row">
          {(!productList && memType != STANDALONE) && <Loader />}
          {(productList || memType == STANDALONE) && <div className="col-lg-12 ml-n3" >
            {
              config &&
              config.ui &&
              config.ui.layout &&
              config.ui.layout[membershipType] &&
              config.ui.layout[membershipType].tabs[TAB_PRODUCT_LIST] &&
              config.ui.layout[membershipType].tabs[TAB_PRODUCT_LIST].order &&
              config.ui.layout[membershipType].tabs[TAB_PRODUCT_LIST].order.map((elem, index) => {
                return renderSubscriptionBody(elem, config.ui.layout[membershipType].tabs[TAB_PRODUCT_LIST].elements[elem], index)
              })
            }
          </div>}
        </div>
      </div>
    </main>
  );
};

export default withSuspense()(connect()(withTranslation()(withRouter(Subscription))))