import {
    ADD_TO_CART, GET_ADD_ON_DETAILS,
    GET_GUEST_CARD_DETAILS, GET_PRODUCT_DETAILS, GET_VALIDATION_MSG, REMOVE_FROM_CART, SELECTED_PACKS,
    UPDATE_ENROLL_STATUS, UPDATE_PAYMENT_ACCEPT, GET_PROFILE_DATA, MEMBERSHIP_TYPE, GET_OVERVIEW_DATA, UPDATE_RENEW_STATUS, SELECTED_TAB, UPDATE_STANDALONE_PURCHASE_STATUS
} from './actions';
const initialState = {};

export default function packagesReducer(state = initialState, action) {
    const { type, payload } = action;
    switch (type) {
        case SELECTED_PACKS:
            return Object.assign({}, state, {
                selectedPack: payload
            });
        default:
            break;
    }
    return state;
}

export const membershipTypeReducer = (state, action) => {
    if (!state) state = {}
    const { type, payload } = action;
    switch (type) {
        case MEMBERSHIP_TYPE:
            return ({ type: payload })
        default:
            break;
    }
    return state;
}

export const subscriptionReducer = (state, action) => {
    const { type, payload } = action;
    if (!state) state = {}
    switch (type) {
        case GET_PRODUCT_DETAILS:
            return ({
                ...state,
                productDetails: payload.object,
            })
        case GET_GUEST_CARD_DETAILS:
            return ({
                ...state,
                guestCardDetails: payload.object,
            })
        case GET_ADD_ON_DETAILS:
            return ({
                ...state,
                addOnDetails: payload.object,
            })
        case UPDATE_ENROLL_STATUS:
            if (Object.keys(payload).includes('error')) {
                return ({
                    ...state,
                    enrollStatus: { status: "failed", response: payload },
                })
            } else {
                return ({
                    ...state,
                    enrollStatus: { status: "success", response: payload },
                })
            }
        case UPDATE_RENEW_STATUS:
            if (Object.keys(payload).includes('error')) {
                return ({
                    ...state,
                    renewStatus: { status: "failed", response: payload },
                })
            } else {
                return ({
                    ...state,
                    renewStatus: { status: "success", response: payload },
                })
            }
        case UPDATE_STANDALONE_PURCHASE_STATUS:
            if (Object.keys(payload).includes('error')) {
                return ({
                    ...state,
                    standaloneStatus: { status: "failed", response: payload },
                })
            } else {
                return ({
                    ...state,
                    standaloneStatus: { status: "success", response: payload },
                })
            }
        case UPDATE_PAYMENT_ACCEPT:
            if (Object.keys(payload).includes('error')) {
                return ({
                    ...state,
                    payAcceptStatus: { status: "failed", response: payload },
                })
            } else {
                return ({
                    ...state,
                    payAcceptStatus: { status: "success", response: payload.object },
                })
            }
        case GET_PROFILE_DATA:
            if (Object.keys(payload).includes('error')) {
                return ({
                    ...state,
                    profileData: { status: "failed", response: payload },
                })
            } else {
                return ({
                    ...state,
                    profileData: { status: "success", response: payload.object },
                })
            }
        case GET_OVERVIEW_DATA:
            if (Object.keys(payload).includes('error')) {
                return ({
                    ...state,
                    overviewData: { status: "failed", response: payload },
                })
            } else {
                return ({
                    ...state,
                    overviewData: { status: "success", response: payload.object },
                })
            }
        default:
            return state;
    }
}

export const cartReducer = (state = {}, action) => {
    const { type, payload } = action;
    if (!state) state = {}
    switch (type) {
        case ADD_TO_CART:
            return ({
                ...state,
                cartDetails: state && state.cartDetails && Object.keys(state.cartDetails).length > 0 ?
                    ifCartContainsKey(state, payload) ? replaceItemInCart(state, payload) : { ...state.cartDetails, ...payload }
                    : { ...payload }
            })
        case REMOVE_FROM_CART:
            return ({
                ...state,
                cartDetails: { ...removeItemInCart(state, payload) }
            })
        default:
            return state
    }
}

export const warningMessageReducer = (state, action) => {
    const { type, payload } = action;
    if (!state) state = {}
    switch (type) {
        case GET_VALIDATION_MSG:
            return ({
                warnings: payload.object,
            })

        default:
            return state;
    }
}

export const currentTabReducer = (state,action)=>{
    const { type, payload } = action;
    if (!state) state = {}
    switch (type) {
        case SELECTED_TAB : {
            return({
                selectedTab : payload
            })
        }
        default:
            return state;
    }
}

const ifCartContainsKey = (state, payload) => {
    const keys = Object.keys(state.cartDetails) && Object.keys(state.cartDetails).length > 0 && Object.keys(state.cartDetails)
    const currentKey = Object.keys(payload) && Object.keys(payload).length > 0 && Object.keys(payload)[0]
    if (keys.includes(currentKey) && currentKey != "total") {
        return true
    }
    else {
        return false
    }
}

const replaceItemInCart = (state, payload) => {
    const key = Object.keys(payload) && Object.keys(payload).length > 0 && Object.keys(payload)[0]
    state.cartDetails[key] = payload[key]
    return state.cartDetails
}

const removeItemInCart = (state, key) => {
    let newObj = state.cartDetails
    delete newObj[key]
    return newObj
}