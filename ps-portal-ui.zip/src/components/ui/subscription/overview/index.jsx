import React, { useEffect, useState } from "react";
import ReactDOM from 'react-dom'
import { withTranslation } from "react-i18next";
import { connect, useDispatch, useSelector } from 'react-redux';
import { withRouter } from "react-router";
import { fetchConfiguration } from "../../../common/middleware/redux/commonAction";
import { withSuspense } from "../../../common/utils";
import { BENEFITS, CONFIG_SECTION_SUBSCRIPTION, GUESTCARD_ADDON, MEMBERSHIP } from "../../../common/utils/Constants";
import { 
    BROWSER_STORAGE_KEY_COMPANY_CODE, 
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO_ANZ, 
    BROWSER_STORAGE_KEY_OVERVIEW, 
    BROWSER_STORAGE_KEY_PROGRAM_CODE, 
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
    BROWSER_STORAGE_KEY_DEFAULT_PROGRAM_CODE,
    getItemFromBrowserStorage, 
    setItemToBrowserStorage 
} from "../../../common/utils/storage.utils";
import { getOverviewData, getProfileDetails } from "../actions";
import GuestCardsAndAddOn from "./GuestCardsAndAddOn";
import MembershipDetails from "./MembershipDetails";


const Overview = (props) => {
    const { t } = props;
    const dispatch = useDispatch()
    const overviewDataResponse = useSelector(state => state.subscriptionReducer.overviewData)
    const [overviewData, setOverviewData] = useState()
    const config = useSelector(state => state.configurationReducer[CONFIG_SECTION_SUBSCRIPTION])
    const selectedTab = useSelector(state => state.currentTabReducer.selectedTab)

    useEffect(() => {
        setItemToBrowserStorage("overView", "");
        setItemToBrowserStorage("corpEmployeeDetails", "");
        document.body.className = "theme__one view__compact";
        getOverviewDetails();
        dispatch(getProfileDetails({
            "object": {
                "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                "membershipNumber": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)
            }
        }));
    }, [])

    useEffect(() => {
       if(overviewDataResponse && overviewDataResponse.response &&
            Object.keys(overviewDataResponse.response).length != 0) {
            setItemToBrowserStorage(BROWSER_STORAGE_KEY_OVERVIEW, JSON.stringify(overviewDataResponse));
            setOverviewData(overviewDataResponse)
        }
    }, [overviewDataResponse])

    const getOverviewDetails = () => {
        if (!config || config && Object.keys(config).length) {
            dispatch(fetchConfiguration(CONFIG_SECTION_SUBSCRIPTION))
        }
        if (!overviewDataResponse || 
            (overviewDataResponse && overviewDataResponse.response==undefined )) {
            dispatch(getOverviewData({
                "object": {
                    "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                    "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_DEFAULT_PROGRAM_CODE),
                    "membershipNumber": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)
                }
            }))
        }
    }

    
    const renderTabBody = (tab) => {
        switch (tab) {
            case MEMBERSHIP: return <MembershipDetails />
            case GUESTCARD_ADDON: return <GuestCardsAndAddOn overviewData={overviewData &&
                overviewData.response} />
            case BENEFITS: return <div></div>
        }
    }
    return (
        <div>
            {
                renderTabBody(selectedTab)
            }

        </div>)
}

export default withSuspense()(connect()(withTranslation()(withRouter(Overview))))