import parse from 'html-react-parser';
import React, { useMemo, useState } from "react";
import ReactDOM from 'react-dom'
import { withTranslation } from "react-i18next";
import { useDispatch } from 'react-redux';
import { checkDateIsLessThanCurrentDate, getFormattedDate } from '../../../common/utils';
import { MEMBERSHIP } from '../../../common/utils/Constants';
import { NAVIGATE_CLUB } from '../../../common/utils/urlConstants';
import { clearOverviewData, setCurrentTab } from '../actions';
import { DATE_FORMAT_DMMMYYYY_WITH_SPACE, STANDALONE_ENDPOINT } from '../Constants';
import { checkKoruPartner, getGuestCardDetails } from "../Services/OverviewUtils";
import { 
  OVERVIEW_ADDON_PURCHASE,
  OVERVIEW_GUESTADDON_LINK_CLICK,
  trackData 
} from "../../../common/utils/analytics.utils"


const GuestCardsAndAddOn = (props) => {

    const dispatch = useDispatch()
    let isExpired
    const { t, overviewData } = props
    const [koruPartner, setKoruPartner] = useState()
    const [guestCard, setGuestCard] = useState({})

    if (overviewData && Object.keys(overviewData).length) {
        let guestCardDetails = getGuestCardDetails(overviewData)
        if (guestCardDetails && Object.keys(guestCardDetails).length > 0 && Object.keys(guestCard).length == 0) {
            setGuestCard(guestCardDetails)
        }

        if (checkKoruPartner(overviewData) && koruPartner === undefined) {
            setKoruPartner(true)
        }
    }


    const purchase = () => {
        document.body.className = "";
        dispatch(clearOverviewData());
        dispatch(setCurrentTab(MEMBERSHIP));

        window.location = `#${NAVIGATE_CLUB}` + STANDALONE_ENDPOINT
        window.location.reload()
    }
    if (guestCard && Object.keys(guestCard).length > 0) {
        isExpired = checkDateIsLessThanCurrentDate(guestCard.expiryDate)
    }

    return (<>

        <h1>{t('guestCardAndAddOn.title')} </h1>
        <div>
            <div className="row">
                <div className="col-lg-12">
                    <h2>{t('guestCardAndAddOn.subTitle')}</h2>
                    {koruPartner ?
                        <div className="alert alert-info" role="alert">
                            {t('guestCardAndAddOn.koruWarning')}
                            {parse(t("guestCardAndAddOn.learnMore"))}
                        </div>
                        :
                        <>
                            {Object.keys(guestCard).length > 0 && !isExpired ?
                                <>
                                    <div className="card card-icon-inline">
                                        <div className="card-body">
                                            <div className="card-icon-inline__icon">
                                                <svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path fillRule="evenodd" clipRule="evenodd" d="M1.30023 6.5C1.30023 10.0898 4.21033 13 7.80012 13C11.3899 13 14.3 10.0898 14.3 6.5C14.3 2.91015 11.3899 0 7.80012 0C4.21033 0 1.30023 2.91015 1.30023 6.5ZM14.9496 12.1302C15.485 11.4514 15.9257 10.6945 16.2519 9.87936C16.8251 10.2105 17.4903 10.4 18.1999 10.4C20.3538 10.4 22.0998 8.6539 22.0998 6.5C22.0998 4.34608 20.3538 2.6 18.1999 2.6C17.4903 2.6 16.8251 2.78949 16.2519 3.12063C15.9257 2.30552 15.485 1.5486 14.9496 0.869762C15.9058 0.316599 17.0159 0 18.1999 0C21.7897 0 24.6998 2.91015 24.6998 6.5C24.6998 10.0898 21.7897 13 18.1999 13C17.0159 13 15.9058 12.6834 14.9496 12.1302ZM18.2 15.6L22.1001 15.6008C24.2539 15.6009 25.9998 17.347 25.9998 19.5008L26 26H23.4L23.3999 19.5008C23.3999 18.7829 22.8179 18.2008 22.0999 18.2008L18.2 18.2003V15.6ZM7.80012 10.4C9.95399 10.4 11.7001 8.6539 11.7001 6.5C11.7001 4.34608 9.95399 2.6 7.80012 2.6C5.64624 2.6 3.90018 4.34608 3.90018 6.5C3.90018 8.6539 5.64624 10.4 7.80012 10.4ZM0.000168563 26H2.60013L2.59996 19.4999C2.59996 18.782 3.18198 18.2 3.89994 18.2L11.6999 18.2008C12.4179 18.2008 12.9999 18.7828 12.9999 19.5008L13 26H15.6L15.5998 19.5007C15.5998 17.347 13.8539 15.6009 11.7001 15.6008L3.90004 15.6C1.74606 15.6 0 17.3461 0 19.5L0.000168563 26Z" fill="black" />
                                                    <mask id="mask0_1584_30454" style={{ maskType: "alpha" }} maskUnits="userSpaceOnUse" x="0" y="0" width="26" height="26">
                                                        <path fillRule="evenodd" clipRule="evenodd" d="M1.30023 6.5C1.30023 10.0898 4.21033 13 7.80012 13C11.3899 13 14.3 10.0898 14.3 6.5C14.3 2.91015 11.3899 0 7.80012 0C4.21033 0 1.30023 2.91015 1.30023 6.5ZM14.9496 12.1302C15.485 11.4514 15.9257 10.6945 16.2519 9.87936C16.8251 10.2105 17.4903 10.4 18.1999 10.4C20.3538 10.4 22.0998 8.6539 22.0998 6.5C22.0998 4.34608 20.3538 2.6 18.1999 2.6C17.4903 2.6 16.8251 2.78949 16.2519 3.12063C15.9257 2.30552 15.485 1.5486 14.9496 0.869762C15.9058 0.316599 17.0159 0 18.1999 0C21.7897 0 24.6998 2.91015 24.6998 6.5C24.6998 10.0898 21.7897 13 18.1999 13C17.0159 13 15.9058 12.6834 14.9496 12.1302ZM18.2 15.6L22.1001 15.6008C24.2539 15.6009 25.9998 17.347 25.9998 19.5008L26 26H23.4L23.3999 19.5008C23.3999 18.7829 22.8179 18.2008 22.0999 18.2008L18.2 18.2003V15.6ZM7.80012 10.4C9.95399 10.4 11.7001 8.6539 11.7001 6.5C11.7001 4.34608 9.95399 2.6 7.80012 2.6C5.64624 2.6 3.90018 4.34608 3.90018 6.5C3.90018 8.6539 5.64624 10.4 7.80012 10.4ZM0.000168563 26H2.60013L2.59996 19.4999C2.59996 18.782 3.18198 18.2 3.89994 18.2L11.6999 18.2008C12.4179 18.2008 12.9999 18.7828 12.9999 19.5008L13 26H15.6L15.5998 19.5007C15.5998 17.347 13.8539 15.6009 11.7001 15.6008L3.90004 15.6C1.74606 15.6 0 17.3461 0 19.5L0.000168563 26Z" fill="white" />
                                                    </mask>
                                                    <g mask="url(#mask0_1584_30454)">
                                                    </g>
                                                </svg>
                                            </div>
                                            <div className="card-icon-inline__text"><h5>
                                                {t(`guestCardName.${guestCard.code}`)}
                                            </h5>
                                                <div className="card-icon-inline__expiry">{t('subscription.overview.expires_tag')} {getFormattedDate(guestCard.expiryDate, DATE_FORMAT_DMMMYYYY_WITH_SPACE)}</div>
                                                {t('guestCardAndAddOn.description')}
                                            </div>

                                        </div>
                                    </div>
                                    <p>
                                        <a onClick={() => trackData(OVERVIEW_GUESTADDON_LINK_CLICK, ['https://www.airnewzealand.co.nz/koru-benefits#lounge-access'])} href='https://www.airnewzealand.co.nz/koru-benefits#lounge-access' target='_blank'>Learn more</a> about lounge access for you and your guests 
                                    </p>
                                </>
                                :
                                <>
                                    {parse(t('guestCardAndAddOn.noGuestCardMessage'))}
                                    <p>
                                        <a onClick={() => trackData(OVERVIEW_GUESTADDON_LINK_CLICK, ['https://www.airnewzealand.co.nz/koru-benefits#guest-card'])} href='https://www.airnewzealand.co.nz/koru-benefits#guest-card' target='_blank'>Learn more</a>
                                    </p>
                                </>
                            }
                        </>
                    }

                </div>
                <div className="col-lg-12">
                    <h2>{t('guestCardAndAddOn.addOnTitle')}</h2>
                    <p>{parse(t('guestCardAndAddOn.addOnDesc'))}</p>
                    <div class="btn-wrap btn-wrap--grp btn-wrap-block__mobile btn-wrap-justify">
                    <a onClick={() => {trackData(OVERVIEW_ADDON_PURCHASE, {});purchase()}} className="btn btn-primary" role="button">
                        {t('guestCardAndAddOn.continuePurchase')}</a></div>
                        </div>
            </div>
        </div>


    </>);
}

export default withTranslation()(GuestCardsAndAddOn)

