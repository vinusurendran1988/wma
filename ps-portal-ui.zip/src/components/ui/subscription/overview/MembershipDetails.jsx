import React, { useEffect, useState } from "react";
import { withTranslation } from "react-i18next";
import { connect, useDispatch, useSelector } from 'react-redux';
import { withRouter } from "react-router";
import DigitalCard from "../../../common/components/fieldbank/DigitalCard";
import { _IMAGE_BASEURL } from "../../../common/config/config";
import { getCurrentDate, getDiffByTwoDate, getFormattedDate, withSuspense } from "../../../common/utils";
import {
    OVERVIEW_RENEW_MEMBERSHIP, PAYMENT_VIEW_DIGITAL_CARD, trackData
} from "../../../common/utils/analytics.utils";
import { CONFIG_SECTION_SUBSCRIPTION } from "../../../common/utils/Constants";
import { NAVIGATE_CLUB } from "../../../common/utils/urlConstants";
import { DATE_FORMAT_DDMMMYYYY_WITH_HYPHEN, DATE_FORMAT_DDMMYYYY_WITH_SPACE, DATE_FORMAT_DD_MM_YYYY, DATE_FORMAT_DMMMYYYY_WITH_SPACE, DAYS, EXPIRED, EXPIRING, GOLD_ELITE, LIFETIME, MEM_TYPE_PR, MEM_TYPE_PR_PT, MEM_TYPE_PT, RENEW_ENDPOINT, VALID_TO } from "../Constants";
import { getDigitalCardDetails } from "../Services/DigitalCardUtils";
const renewMessageCodes = ['EXPIRING', 'EXPIRED', 'VALID_TO']
const GRACE_PERIOD = 1

const MembershipDetails = (props) => {
    const [disableAlert, setDisableAlertFlag] = useState(false)
    const [overviewData, setOverviewData] = useState([])
    const [expiryValue, setExpiryValue] = useState({})
    const [expiryDateAfterGracePeriod, setExpiryDateAfterGracePeriod] = useState({})
    const { t } = props;
    const dispatch = useDispatch()
    const overviewDataResponse = useSelector(state => state.subscriptionReducer.overviewData)
    const config = useSelector(state => state.configurationReducer[CONFIG_SECTION_SUBSCRIPTION])

 

    useEffect(() => {
        checkExpiredStatus(overviewDataResponse ? overviewDataResponse.response : {});
    }, [overviewDataResponse])

    useEffect(() => {
        populateData();
        if(overviewData && overviewData.membershipDetails){
            setValuesForExpiry( overviewData.membershipDetails.expiryDate, overviewData.profile.nomineeType)
        }
    }, [overviewData])

    const checkExpiredStatus = (overviewDataObject) => {
        if (overviewDataObject && overviewDataObject.membershipDetails && overviewDataObject.membershipDetails.expiryDate) {
            const currentDate = getCurrentDate();
            let currentExpiryDate = new Date(overviewDataObject.membershipDetails.expiryDate);
            currentExpiryDate.setMonth(currentExpiryDate.getMonth() + GRACE_PERIOD);
            const daysToExpire = getDiffByTwoDate(currentDate, getFormattedDate(currentExpiryDate, DATE_FORMAT_DDMMYYYY_WITH_SPACE), DATE_FORMAT_DD_MM_YYYY, DATE_FORMAT_DDMMYYYY_WITH_SPACE, DAYS)
            if (daysToExpire > 0) {
                handleRenewBtnClick();
            } else {
                setOverviewData(overviewDataObject);
            }
        }
    }

    const populateData = () => {
        if (overviewData && overviewData.membershipDetails && overviewData.membershipDetails.userMessageDetails && overviewData.profile && overviewData.profile.nomineeType == MEM_TYPE_PR) {
            let renewMemberMessage = overviewData.membershipDetails.userMessageDetails.filter(e => e.code.toLowerCase() == VALID_TO);
            if (renewMemberMessage.length > 0 && overviewData.nomineeDetails && overviewData.nomineeDetails[0] && overviewData.nomineeDetails[0].membershipDetails && overviewData.nomineeDetails[0].membershipDetails.userMessageDetails) {
                let renewPartnerMessage = overviewData.nomineeDetails[0].membershipDetails.userMessageDetails.filter(e => e.code.toLowerCase() == VALID_TO);
                if (renewPartnerMessage.length > 0) {
                    setDisableAlertFlag(true)
                }
            }
        }
    }
    const getExpiryDateTagName = (userMessages) => {
        let renewMessage = userMessages.filter(e => renewMessageCodes.includes(e.code));
        let expiryTag = "";
        if (renewMessage.length > 0) {
            if (renewMessage[0] && renewMessage[0].code.toLowerCase().includes(EXPIRED)) {
                expiryTag = t("subscription.overview.expired_tag")
            } else if (renewMessage[0] && renewMessage[0].code.toLowerCase().includes(EXPIRING)) {
                expiryTag = t("subscription.overview.expires_tag")
            } else {
                expiryTag = t("subscription.overview.validto_tag")
            }
        } else {
            expiryTag = t("subscription.overview.validto_tag")
        }
        return expiryTag;
    }
    const handleRenewBtnClick = () => {
        document.body.className = ""
        window.location = `#${NAVIGATE_CLUB}` + RENEW_ENDPOINT
    }
    const getReniewalMessage = (userMessages, nomineeType, expiryDate) => {
        let renewMessage = userMessages.filter(e => renewMessageCodes.includes(e.code));
        let alertClassName = "";
        let isPrimaryBtnEnable = false
        if (renewMessage[0] && renewMessage[0].code.toLowerCase().includes(EXPIRED)) {
            alertClassName = "expired"
            // alertClassName = EXPIRED_ALERT_CLASS_NAME

            isPrimaryBtnEnable = true
        } else if (renewMessage[0] && renewMessage[0].code.toLowerCase().includes(EXPIRING)) {
            // alertClassName = EXPIRES_ALERT_CLASS_NAME
            alertClassName = "expiring"

        } else {
            alertClassName = ""
        }
        if (renewMessage.length > 0 && !disableAlert && nomineeType) {
            return (
            <div>
                {alertClassName &&
                    getGoldEliteTierInfo(userMessages)
                }
                <div className={alertClassName ? alertClassName : ""} role="alert">
                <hr />
                    {alertClassName ?
                            <div className="simple-alert">
                                <div className={`alert ${alertClassName == "expiring" ? "" : "alert-warning"} alert--custom hide-fontawesome`} role="alert">
                                    {alertClassName == "expiring" ?
                                        <svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M0 10.6152C0 16.1381 4.47715 20.6152 10 20.6152C15.5228 20.6152 20 16.1381 20 10.6152C20 5.09239 15.5228 0.615234 10 0.615234C4.47715 0.615234 0 5.09239 0 10.6152ZM18 10.6152C18 15.0335 14.4183 18.6152 10 18.6152C5.58172 18.6152 2 15.0335 2 10.6152C2 6.19696 5.58172 2.61523 10 2.61523C14.4183 2.61523 18 6.19696 18 10.6152ZM8.75 5.86523C8.75 5.17488 9.30964 4.61523 10 4.61523C10.6904 4.61523 11.25 5.17488 11.25 5.86523C11.25 6.55559 10.6904 7.11523 10 7.11523C9.30964 7.11523 8.75 6.55559 8.75 5.86523ZM10 8.61523C9.30964 8.61523 8.75 9.17488 8.75 9.86523V15.3652C8.75 16.0556 9.30964 16.6152 10 16.6152C10.6904 16.6152 11.25 16.0556 11.25 15.3652V9.86523C11.25 9.17488 10.6904 8.61523 10 8.61523Z" fill="white"></path></svg>
                                        :
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M0 10C0 15.5228 4.47715 20 10 20C15.5228 20 20 15.5228 20 10C20 4.47715 15.5228 0 10 0C4.47715 0 0 4.47715 0 10ZM8.60688 5.49619C8.54913 4.6877 9.18946 4 10 4C10.8106 4 11.4509 4.6877 11.3931 5.49619L11.0713 10.0025C11.0311 10.5646 10.5635 11 10 11C9.43656 11 8.96891 10.5646 8.92876 10.0025L8.60688 5.49619ZM8.78785 14.25C8.78785 13.5596 9.3475 13 10.0379 13C10.7282 13 11.2879 13.5596 11.2879 14.25C11.2879 14.9404 10.7282 15.5 10.0379 15.5C9.3475 15.5 8.78785 14.9404 8.78785 14.25Z" fill="#EE6A2F" />
                                            <mask id="mask0_5049_74100" style={{ maskType: "alpha" }} maskUnits="userSpaceOnUse" x="0" y="0" width="20" height="20">
                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M0 10C0 15.5228 4.47715 20 10 20C15.5228 20 20 15.5228 20 10C20 4.47715 15.5228 0 10 0C4.47715 0 0 4.47715 0 10ZM8.60688 5.49619C8.54913 4.6877 9.18946 4 10 4C10.8106 4 11.4509 4.6877 11.3931 5.49619L11.0713 10.0025C11.0311 10.5646 10.5635 11 10 11C9.43656 11 8.96891 10.5646 8.92876 10.0025L8.60688 5.49619ZM8.78785 14.25C8.78785 13.5596 9.3475 13 10.0379 13C10.7282 13 11.2879 13.5596 11.2879 14.25C11.2879 14.9404 10.7282 15.5 10.0379 15.5C9.3475 15.5 8.78785 14.9404 8.78785 14.25Z" fill="white" />
                                            </mask>
                                            <g mask="url(#mask0_5049_74100)">
                                            </g>
                                        </svg>
                                    }
                        {t(`subscription.userMessages.${(renewMessage[0].code + "_" + nomineeType).toLowerCase()}`).replace("${expiry_days}", expiryValue[nomineeType]).replace("${expiry_date}", getFormattedDate(expiryDate, DATE_FORMAT_DMMMYYYY_WITH_SPACE)).replace("${grace_expiry_date}", expiryDateAfterGracePeriod[nomineeType])}
                        </div></div>
                        : <>
                        {renewMessage && t(`subscription.userMessages.${(renewMessage[0].code + "_" + nomineeType).toLowerCase()}`).replace("${expiry_days}", expiryValue[nomineeType]).replace("${expiry_date}", getFormattedDate(expiryDate, DATE_FORMAT_DMMMYYYY_WITH_SPACE)).replace("${grace_expiry_date}", expiryDateAfterGracePeriod[nomineeType])}
        
                        </>
                    }
                    {(nomineeType == MEM_TYPE_PR) && alertClassName ?
                        <div className="pb-2">
                            <button type="button" className={isPrimaryBtnEnable ? "btn btn-primary" : "btn btn-secondary"} onClick={() => { trackData(OVERVIEW_RENEW_MEMBERSHIP, {}); handleRenewBtnClick() }}>Renew membership</button>
                        </div> : <div className="pb-5"></div>
                    }
                </div>
                </div>
                )
        } else {
            return (<></>)
        }
    }

    const setValuesForExpiry = ( expiryDate, nomineeType)=>{
        if (!expiryValue[nomineeType]) {
            const currentDate = getCurrentDate();
            const daysToExpire = getDiffByTwoDate(expiryDate, currentDate, DATE_FORMAT_DDMMMYYYY_WITH_HYPHEN, DATE_FORMAT_DD_MM_YYYY)
            setExpiryValue(ev => ({
                ...ev,
                [nomineeType]: daysToExpire,
            }))
        }
        if (!expiryDateAfterGracePeriod[nomineeType]) {
            let graceDate = new Date(expiryDate);
            console.log(graceDate.setMonth(graceDate.getMonth() + GRACE_PERIOD));
            setExpiryDateAfterGracePeriod(ev => ({
                ...ev,
                [nomineeType]: getFormattedDate(graceDate, DATE_FORMAT_DMMMYYYY_WITH_SPACE)
            }))
        }
    }
    const getExpiryDateValue = (userMessages, expiryDate) => {
       
        let renewMessage = userMessages.filter(e => e.code.toLowerCase() == LIFETIME.toLowerCase());
        return <p className="type">{renewMessage[0] ? t(`subscription.userMessages.${renewMessage[0].code.toLowerCase()}`) : getFormattedDate(expiryDate, DATE_FORMAT_DMMMYYYY_WITH_SPACE)}</p>
    }
    const getGoldEliteTierInfo = (userMessages) => {
        let goldEliteMessage = userMessages.filter(e => e.code.toLowerCase() == GOLD_ELITE);
        if (goldEliteMessage.length > 0) {
            return <div className="alert alert-danger alert--status" role="alert">  {t(`subscription.userMessages.${goldEliteMessage[0].code.toLowerCase()}`)}<div> </div> </div>
        }
    }
    if (!digitalCardObject || digitalCardObject && Object.keys(digitalCardObject).length == 0) {
        var digitalCardObject = overviewDataResponse && overviewDataResponse.response &&
            overviewDataResponse.response && getDigitalCardDetails(overviewDataResponse.response, t)
    }

    return (<>
            {digitalCardObject &&
                <DigitalCard id="digital-card-modal"
                    displayName={digitalCardObject.displayName}
                    expiryMessage={digitalCardObject.expiryMessage}
                    title={digitalCardObject.title}
                    descriptionRequired={digitalCardObject.descriptionRequired}
                    membershipType={digitalCardObject.membershipType}
                    footerMessage={digitalCardObject.footerMessage}
                    membershipNumber={digitalCardObject.membershipNumber} />
            }
            {config &&
                config.ui &&
                config.ui.layout &&
                config.ui.layout.overview &&
                <div className="form-row ">
                    {overviewData && overviewData.membershipDetails && config.ui.layout.overview.elements && config.ui.layout.overview.elements.digitalCardView && config.ui.layout.overview.elements.digitalCardView.visibility &&
                        <div className="col-lg-12">
                            <h1>{t("subscription.overview.page_heading")}</h1>
                            <div className="card-preview">
                                <img style={{ height: "10%" }} src={`${_IMAGE_BASEURL}/card-preview.jpg`} alt="no content" /><div className="card-preview__inner"><div className="card-preview__text"><h3>Digital Koru card</h3>
                                    <p style={{"fontSize": "14px"}}>
                                        {t("subscription.overview.digital_card_description")}
                                    </p>
                                </div>
                                    {config.ui.layout.overview.elements.digitalCardView.isViewDigitalCardEnabled &&
                                        <button type="button" data-toggle="modal" onClick={() => {trackData(PAYMENT_VIEW_DIGITAL_CARD, {})}} data-target="#digital-card-modal" className="btn btn-primary">View Koru card</button>
                                    }
                                </div>
                            </div>
                            {config.ui.layout.overview.elements.memberDetail && config.ui.layout.overview.elements.memberDetail.visibility && config.ui.layout.overview.elements.memberDetail.fields &&
                                <div className="preview profile-info">
                                    <div className="form-row">
                                        <div className="col-lg-8">
                                            {config.ui.layout.overview.elements.memberDetail.fields.heading.visibility &&
                                                <h2 className="mt-0"> {t("subscription.overview.your_details")}</h2>
                                            }
                                            <div className="form-row">
                                                {overviewData.nomineeDetails && overviewData.nomineeDetails[0] && overviewData.profile && overviewData.profile.nomineeType == MEM_TYPE_PT && config.ui.layout.overview.elements.memberDetail.fields.nomineeName.visibility &&
                                                    <div className="col-lg-12">
                                                        <div className="form-group">
                                                            <label className="label" for="f1">{t("subscription.overview.your_koru_nominee")}</label>
                                                            <p className="type">{overviewData.nomineeDetails[0].profile.givenName + " " + overviewData.nomineeDetails[0].profile.familyName}</p>
                                                        </div>
                                                    </div>
                                                }
                                                {config.ui.layout.overview.elements.memberDetail.fields.memberShipPlan.visibility &&
                                                    <div className="col-lg-12">
                                                        <div className="form-group">
                                                            <label className="label" for="f1">{t("subscription.overview.membership_plan_label")}</label>
                                                            {overviewData.profile.companyName == null && <p className="type">{t(`productName.${overviewData.membershipDetails.membershipPlanCode}`)}</p>}
                                                            {overviewData.profile.companyName != null &&
                                                                <>
                                                                    <p className="type" style={{"margin-bottom": "auto"}}>{t(`productName.${overviewData.membershipDetails.membershipPlanCode}`)}</p>
                                                                    <p className="type">{overviewData.profile.companyName}</p>
                                                                </>
                                                            }
                                                        </div>
                                                    </div>
                                                }
                                                {overviewData.membershipDetails.userMessageDetails && config.ui.layout.overview.elements.memberDetail.fields.expiryDetails.visibility &&
                                                    <div className="col-lg-12">
                                                        <div className="form-group">
                                                            <label className="label" for="f1">{getExpiryDateTagName(overviewData.membershipDetails.userMessageDetails)}</label>
                                                            {getExpiryDateValue(overviewData.membershipDetails.userMessageDetails, overviewData.membershipDetails.expiryDate, overviewData.profile.nomineeType)}
                                                        </div>
                                                    </div>
                                                }
                                            </div>
                                        </div>
                                        {/* {overviewData.membershipDetails.userMessageDetails &&
                                    getGoldEliteTierInfo(overviewData.membershipDetails.userMessageDetails)
                                } */}
                                        {overviewData.membershipDetails.userMessageDetails && config.ui.layout.overview.elements.memberDetail.fields.warningAndInfo.visibility &&
                                            getReniewalMessage(overviewData.membershipDetails.userMessageDetails, overviewData.profile.nomineeType, overviewData.membershipDetails.expiryDate)
                                        }

                                    </div>
                                </div>
                            }
                            {overviewData && overviewData.profile && overviewData.profile.nomineeType == MEM_TYPE_PR && overviewData.nomineeDetails && overviewData.nomineeDetails[0] && config.ui.layout.overview.elements.partnerDetail && config.ui.layout.overview.elements.partnerDetail.visibility && config.ui.layout.overview.elements.partnerDetail.fields &&
                                <div className="preview profile-info">
                                    <div className="form-row">
                                        <div className="col-lg-8">
                                            {config.ui.layout.overview.elements.partnerDetail.fields.heading.visibility &&
                                                <h2 className="mb-4"> {t("subscription.overview.partner_details")}</h2>
                                            }
                                            <div className="form-row">
                                                {overviewData.nomineeDetails[0].profile && config.ui.layout.overview.elements.partnerDetail.fields.partnerName.visibility &&
                                                    <div className="col-lg-12">
                                                        <div className="form-group">
                                                            <label className="label" for="f1">{t("subscription.overview.partner_name")}</label>
                                                            <p className="type">{overviewData.nomineeDetails[0].profile.givenName + " " + overviewData.nomineeDetails[0].profile.familyName}</p>
                                                        </div>
                                                    </div>
                                                }
                                                {overviewData.nomineeDetails[0].membershipDetails &&
                                                    <>
                                                        {config.ui.layout.overview.elements.partnerDetail.fields.memberShipPlan.visibility &&
                                                            <div className="col-lg-12">
                                                                <div className="form-group">
                                                                    <label className="label" for="f1">{t("subscription.overview.partners_plan_label")}</label>
                                                                    <p className="type">{t(`productName.${overviewData.nomineeDetails[0].membershipDetails.membershipPlanCode}`)}</p>
                                                                </div>
                                                            </div>
                                                        }
                                                        {config.ui.layout.overview.elements.partnerDetail.fields.expiryDetails.visibility &&

                                                            <div className="col-lg-12">
                                                                <div className="form-group">
                                                                    <label className="label" for="f1">{getExpiryDateTagName(overviewData.nomineeDetails[0].membershipDetails.userMessageDetails)}</label>
                                                                    {getExpiryDateValue(overviewData.nomineeDetails[0].membershipDetails.userMessageDetails, overviewData.nomineeDetails[0].membershipDetails.expiryDate, MEM_TYPE_PR_PT)}
                                                                </div>
                                                            </div>
                                                        }
                                                    </>
                                                }
                                            </div>
                                        </div>
                                        {overviewData.nomineeDetails[0].membershipDetails.userMessageDetails && config.ui.layout.overview.elements.partnerDetail.fields.warningAndInfo.visibility &&
                                            getReniewalMessage(overviewData.nomineeDetails[0].membershipDetails.userMessageDetails, MEM_TYPE_PR_PT, overviewData.nomineeDetails[0].membershipDetails.expiryDate)
                                        }
                                    </div>
                                </div>
                            }
                        </div>
                    }
                </div>
            }
    </>)
}

export default withSuspense()(connect()(withTranslation()(withRouter(MembershipDetails))))