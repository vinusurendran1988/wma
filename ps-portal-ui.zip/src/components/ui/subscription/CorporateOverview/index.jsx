import { isEmpty } from "lodash";
import React, { useEffect } from "react";
import { withTranslation } from "react-i18next";
import { connect, useDispatch, useSelector } from 'react-redux';
import { withRouter } from "react-router";
import { fetchConfiguration } from "../../../common/middleware/redux/commonAction";
import { withSuspense } from "../../../common/utils";
import { CONFIG_SECTION_COMPANY_PROFILE, CONFIG_SECTION_MANAGE_ACCOUNT_USERS, CORP_MEMBERS, CORP_PROFILE } from "../../../common/utils/Constants";
import CompanyProfile from "../../../impl/companyProfile";
import ManageAccountUsers from "../../../impl/manageaccountusers";
import { getCompanyData } from "../Services/CommonUtils";

const CorporateOverview = (props) => {
    const { t } = props;
    const dispatch = useDispatch()
    const selectedTab = useSelector(state => state.currentTabReducer.selectedTab);
    const config = useSelector(state => state.configurationReducer[CONFIG_SECTION_COMPANY_PROFILE])
    const accountUsersconfig = useSelector(state => state.configurationReducer[CONFIG_SECTION_MANAGE_ACCOUNT_USERS])
    const profileData = useSelector(state => state.profileDataReducer.profileData);
    const companyData = (profileData && 'object' in profileData) ? getCompanyData(profileData.object.memberAccount.memberDynamicAttributes) : {};
    useEffect(() => {
        document.body.className = "theme__one view__compact";
        if (!config || config && Object.keys(config).length) {
            dispatch(fetchConfiguration(CONFIG_SECTION_COMPANY_PROFILE))
        }
        if (!accountUsersconfig || accountUsersconfig && Object.keys(accountUsersconfig).length) {
            dispatch(fetchConfiguration(CONFIG_SECTION_MANAGE_ACCOUNT_USERS))
        }
        // dispatch(getProfileDetails(prepareProfileDataPayload()))
    }, [])

    /**
     * Request formation for profile fetch
     */
    // const prepareProfileDataPayload = () => {
    //     return {
    //     "object": {
    //         "companyCode": "NZ",
    //         "programCode": "KORU",
    //         "membershipNumber": getItemFromBrowserStorage("membershipNumber")
    //     }
    //     }
    // }
    console.log("profile data ---------- ",profileData);

    console.log("company data ---------- ",companyData);
    const renderTabBody = (tab) => {
        tab = (tab == "membership") ? "manageUsers" : tab;
        switch (tab) {
            case CORP_PROFILE: return <CompanyProfile companyData={companyData} />
            case CORP_MEMBERS: return <ManageAccountUsers companyData={companyData} />
        }
    }
    return (
        <div>
            {Object.keys(companyData).includes("companyId") && 
             !isEmpty(companyData.companyId) ?  renderTabBody(selectedTab) : ''}

        </div>)
}

export default withSuspense()(connect()(withTranslation()(withRouter(CorporateOverview))))