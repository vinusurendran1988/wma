import React, {useEffect} from "react";
import { withTranslation } from "react-i18next";
import { useDispatch, useSelector } from 'react-redux';
import { getItemFromBrowserStorage, setItemToBrowserStorage } from "../../common/utils/storage.utils";
import { NAVIGATE_CLUB_CHECKOUT, NAVIGATE_CLUB_OVERVIEW } from "../../common/utils/urlConstants";
import { addToCart } from "./actions";
import { DOLLAR, ZERO_DOLLAR } from "./Constants";
import { CONTINUE_CHECKOUT, trackData } from "../../common/utils/analytics.utils"

const checkoutButtonClick = (cartItems) => {
    trackData(CONTINUE_CHECKOUT, cartItems);
    setItemToBrowserStorage("cartItem", JSON.stringify(cartItems))
    window.location = `#${NAVIGATE_CLUB_CHECKOUT}`
}
const checkIfCartIsNotEmpty = (cartItems) => {
    if (cartItems && Object.keys(cartItems).length > 0) {
        return true
    }
    else {
        return false
    }
}

const getItemsFromCart = (itemType, cartItems) => {
    const items = cartItems && Object.keys(cartItems).length > 0 &&
        cartItems[itemType]
    return items
}

const calculateTotal = (membershipDetails, guestCardDetails, addOnDetails, cartItems, dispatch) => {
    let membershipDetailsPrice = 0
    let guestCardDetailsPrice = 0
    let addOnDetailPrice = 0
    let cartTotalInStore = 0
    if (cartItems && Object.keys(cartItems).length &&
        cartItems['total']) {
        cartTotalInStore = cartItems['total']
    }
    if (membershipDetails && membershipDetails.price && membershipDetails.price.latestTotal) {
        membershipDetailsPrice = membershipDetails.price.latestTotal
    }
    if (guestCardDetails && guestCardDetails.price && guestCardDetails.price.latestCost) {
        guestCardDetailsPrice = guestCardDetails.price.latestCost
    }
    if (addOnDetails && addOnDetails.price && addOnDetails.price.latestCost) {
        addOnDetailPrice = addOnDetails.price.latestCost
    }
    const total = membershipDetailsPrice + guestCardDetailsPrice + addOnDetailPrice
    if (cartTotalInStore != total) {
        dispatch(addToCart("total", total))
    }
    return total
}

const PlanSummary = (props) => {
    useEffect(() => {
        // SubscriptionAnalytics();
    }, [])
    const cartItems = useSelector(state => state.cartReducer.cartDetails)
    const dispatch = useDispatch()
    const { t, status, configSection,standAlonePurchaseFlag } = props
    const [showMessage, setShowMessage] = React.useState(false)
    let memberShipDetailsFromCart = {}
    let guestCardDetailsFromCart = {}
    let addOnDetailsFromCart = {}
    if (checkIfCartIsNotEmpty(cartItems)) {
        memberShipDetailsFromCart = getItemsFromCart('membership', cartItems)
        guestCardDetailsFromCart = getItemsFromCart("guestCard", cartItems)
        addOnDetailsFromCart = getItemsFromCart('addOn', cartItems)
        if (showMessage && memberShipDetailsFromCart && Object.keys(memberShipDetailsFromCart).length > 0) {
            setShowMessage(false)
        }
    }
    const goToOverview = () => {
        window.location = `#${NAVIGATE_CLUB_OVERVIEW}`;
    }
    const gotToBenefit = () => {
        window.location.assign('https://www.airnewzealand.co.nz/vloyalty/action/mybenefits');
    }
    const checkStandAloneSelectionStatus = () =>{
        if(standAlonePurchaseFlag){    
            if(checkIfCartIsNotEmpty(cartItems) && ((guestCardDetailsFromCart &&  Object.keys(guestCardDetailsFromCart).length > 0) || (addOnDetailsFromCart &&  Object.keys(addOnDetailsFromCart).length > 0) )){
               return true
            }
        }
        return false
    }
    const anyItemSelected = ()=>{
        if(((guestCardDetailsFromCart && Object.keys(guestCardDetailsFromCart).length)) || ((addOnDetailsFromCart && Object.keys(addOnDetailsFromCart).length))){
           return false
        }else{
            return true
        }
    }
    return (<>
        {configSection && configSection.fields &&
            <div className="col-lg-12">
                {configSection.fields.title && configSection.fields.title.visibility &&
                    <h2 >{t('subscription.planSummary.title')}</h2>
                }
                {configSection.fields.contentBody && configSection.fields.contentBody.visibility &&
                    <ul className=" list-group list-group-flush plan-summary">
                        {checkIfCartIsNotEmpty(cartItems) ?
                            memberShipDetailsFromCart && <li className="list-group-item">
                                <div>{t(`productName.${memberShipDetailsFromCart.i18nCode}`)}
                                </div>
                                <div>{
                                    DOLLAR + (memberShipDetailsFromCart && memberShipDetailsFromCart.price
                                        && memberShipDetailsFromCart.price.latestTotal)
                                }
                                </div>
                            </li>
                            :
                            <li className="list-group-item">
                                <div>{t(`subscription.planSummary.${standAlonePurchaseFlag?'emptySelection':'selectPlan'}`)}
                                </div>
                                <div>{ZERO_DOLLAR}
                                </div>
                            </li>
                        }
                        {guestCardDetailsFromCart && Object.keys(guestCardDetailsFromCart).length ?
                            <li className="list-group-item">
                                <div>
                                    {t(`guestCardName.${guestCardDetailsFromCart.i18nCode}`)}
                                </div>
                                <div>{checkIfCartIsNotEmpty(cartItems) ?
                                    DOLLAR + (guestCardDetailsFromCart.price.latestCost) :
                                    ZERO_DOLLAR
                                }
                                </div>
                            </li> : ""
                        }
                        {addOnDetailsFromCart && Object.keys(addOnDetailsFromCart).length ?
                            <li className="list-group-item">
                                <div>
                                    {t(`addOnName.${addOnDetailsFromCart.i18nCode}`)}
                                </div>
                                <div>{checkIfCartIsNotEmpty(cartItems) ?
                                    DOLLAR + (addOnDetailsFromCart.price.latestCost) :
                                    ZERO_DOLLAR
                                }
                                </div>
                            </li> : ""
                        }
                {/* {(!(guestCardDetailsFromCart && Object.keys(guestCardDetailsFromCart).length)) && (!(addOnDetailsFromCart && Object.keys(addOnDetailsFromCart).length)) &&
                    <p>Nothing selected</p>
                } */}
                        <li className="list-group-item list-group-item--total">
                            <div> {t('subscription.planSummary.total')}</div>
                            <div>{t('subscription.planSummary.nzdDollar')}
                                {checkIfCartIsNotEmpty(cartItems) ?
                                    DOLLAR +
                                    (calculateTotal(memberShipDetailsFromCart, guestCardDetailsFromCart, addOnDetailsFromCart, cartItems, dispatch)) :
                                    ZERO_DOLLAR}</div>
                        </li>
                    </ul>
                }
                <div style={{"display": "flow-root"}}>
                    {configSection.isBackBtnRequired &&
                        <button type="button" style={{"float":"left"}} class="btn btn-secondary" onClick={() => { getItemFromBrowserStorage("membershipNumber") ? goToOverview() : gotToBenefit() }} data-test="payment-test">{getItemFromBrowserStorage("membershipNumber") ? "Back to Koru" : "Back to benefit"}</button>
                    }

                    <button type="button" id="my-button" style={{"float":"right"}}
                        className={`btn btn-primary ${checkIfCartIsNotEmpty(cartItems) && memberShipDetailsFromCart &&
                            Object.keys(memberShipDetailsFromCart).length > 0 &&
                            !status ?
                            "" :checkStandAloneSelectionStatus(cartItems)?"":"disabled"
                            }`}
                        onClick={() => checkIfCartIsNotEmpty(cartItems) && memberShipDetailsFromCart &&
                            Object.keys(memberShipDetailsFromCart).length > 0 &&
                            !status ?
                            checkoutButtonClick(cartItems) :
                            checkStandAloneSelectionStatus(cartItems)?checkoutButtonClick(cartItems):setShowMessage(true)
                        }>
                        {t('subscription.planSummary.checkOut')}
                    </button>
                </div>
                {showMessage == true && anyItemSelected() && <div class="text-right cart-view__select-membership"> 
               
                    <div className="simple-alert float-right">
                        <div className="alert alert--custom hide-fontawesome" role="alert">
                            <svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M0 10.6152C0 16.1381 4.47715 20.6152 10 20.6152C15.5228 20.6152 20 16.1381 20 10.6152C20 5.09239 15.5228 0.615234 10 0.615234C4.47715 0.615234 0 5.09239 0 10.6152ZM18 10.6152C18 15.0335 14.4183 18.6152 10 18.6152C5.58172 18.6152 2 15.0335 2 10.6152C2 6.19696 5.58172 2.61523 10 2.61523C14.4183 2.61523 18 6.19696 18 10.6152ZM8.75 5.86523C8.75 5.17488 9.30964 4.61523 10 4.61523C10.6904 4.61523 11.25 5.17488 11.25 5.86523C11.25 6.55559 10.6904 7.11523 10 7.11523C9.30964 7.11523 8.75 6.55559 8.75 5.86523ZM10 8.61523C9.30964 8.61523 8.75 9.17488 8.75 9.86523V15.3652C8.75 16.0556 9.30964 16.6152 10 16.6152C10.6904 16.6152 11.25 16.0556 11.25 15.3652V9.86523C11.25 9.17488 10.6904 8.61523 10 8.61523Z" fill="white" />
                            </svg> {t(`subscription.planSummary.${standAlonePurchaseFlag ? 'selectPreference' : 'selectMemPlan'}`)}</div>
                            </div>
                </div>}
            </div>}
    </>);
}

export default (withTranslation()(PlanSummary))