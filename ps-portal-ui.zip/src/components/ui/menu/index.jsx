import React, { Component } from 'react';

class MenuCard extends Component {
    render() {
        const { t, config } = this.props
        return (
            <>
            <div className="cardWrap cardWrap3">
                <div className="list-group">
                    {
                        config &&
                        config.fields &&
                        config.fields.map((field, idx) => {
                            if(field.visibility)
                                return <a key={`menu-${field.id}-${idx}`} href={`#${field.link}`} 
                                            className="list-group-item list-group-item-action" data-test="menu-link-item">
                                            <i className={field.className} aria-hidden="true"></i>
                                            {t('sidebar.menucard.'+field.id)}
                                        </a>
                        })
                    }
                </div>
            </div>           
            </>
        );
    }
}

MenuCard.propTypes = {

};

export default MenuCard;