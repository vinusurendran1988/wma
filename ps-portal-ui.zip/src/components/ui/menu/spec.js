import React from 'react';
import MenuCard from './index';
import { findByTestAttr } from '../../common/testUtils/index';
import { mount } from 'enzyme';
import { NAVIGATE_MILEAGE_CALCULATOR, NAVIGATE_MEMBER_CLAIMSUMMARY, NAVIGATE_BUY, NAVIGATE_TRANSFER, NAVIGATE_MEMBER_MYACTIVITY, NAVIGATE_MEMBER_BOOKING } from '../../common/utils/urlConstants';
let rootComponent;

const setUp = (props = {}) => {
    rootComponent = mount(
        <MenuCard {...props} />
    );
};

describe('MenuCard Component', () => {
    beforeEach(() => {
        setUp({config, t: jest.fn()})
    });
    test('Rendering wihtout fail', () => {
        const itemList = findByTestAttr(rootComponent, "menu-link-item")
        expect(itemList.length).toBe(6);
    });
});

const config = {
    "fields": [
      {
        "id": "calculator",
        "visibility": true,
        "className": "fa fa-calculator",
        "link": NAVIGATE_MILEAGE_CALCULATOR
      },
      {
        "id": "claim",
        "visibility": true,
        "className": "fa fa-money",
        "link": NAVIGATE_MEMBER_CLAIMSUMMARY
      },
      {
        "id": "buy",
        "visibility": true,
        "className": "fa fa-plane",
        "link": NAVIGATE_BUY
      },
      {
        "id": "transfer",
        "visibility": true,
        "className": "fa fa-exchange",
        "link": NAVIGATE_TRANSFER
      },
      {
        "id": "activity",
        "visibility": true,
        "className": "fa fa-file-text-o",
        "link": NAVIGATE_MEMBER_MYACTIVITY
      },
      {
        "id": "destination",
        "visibility": true,
        "className": "fa fa-map-marker",
        "link": NAVIGATE_MEMBER_BOOKING
      }
    ]
  }