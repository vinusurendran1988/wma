import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import CustomMessage from '../../common/components/custommessage';
import Button from '../../common/components/fieldbank/Button';
import { clearValidateResponse, fetchConfiguration } from '../../common/middleware/redux/commonAction';
import { CONTEXT_PAGE, FULL_ACCESS, havePrivilege } from '../../common/privileges';
import { getApiErrorMessage, getCurrentPageUri, withSuspense } from '../../common/utils';
import { CONFIG_SECTION_MANAGE_ACCOUNT_USERS, PROGRAM_TYPE_CORPORATE } from '../../common/utils/Constants';
import {
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    BROWSER_STORAGE_KEY_PROGRAM_TYPE,
    getItemFromBrowserStorage
} from '../../common/utils/storage.utils';
import AccountUsersTable from './AccountUsersTable';
import { retrieveAccountUsers } from './actions';
import AddAccountUser from './AddAccountUser';
import { DANGER, RESPONSE_SUCCESS, SUCCESS } from './Constants';

/**
 * Method to get request body for retrieve account users
 * @author Amrutha
 */

export const getRequestBodyRetrieveAccountUsers = () => {
    let requestPayload = {}
    requestPayload.companyCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE)
    requestPayload.programCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE)
    requestPayload.membershipNumber = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)
    return requestPayload
}

/**
 * Component to manage users
 * @author Amrutha
 */

class ManageAccountUsers extends Component {
    constructor(props) {
        super(props);
        this.state = {
            showAddAccountUserPage: false,
            showSuccessMessage: false,
            apiResponse: {}
        }
    }

    componentDidMount() {
        this.props.setPageInfo(this.props, { config: this.props.manageAccountUsersConfig, confSection: CONFIG_SECTION_MANAGE_ACCOUNT_USERS })

        this.populateNomineeList()
    }

    componentDidUpdate(prevProps) {
        const { updateAccountUserResponse, deleteAccountUserResponse, userAddedResponse, t } = this.props
        const apiResponse = {}
        if (JSON.stringify(prevProps.updateAccountUserResponse) !== JSON.stringify(updateAccountUserResponse)) {
            if (updateAccountUserResponse && updateAccountUserResponse.statusMessage == RESPONSE_SUCCESS) {
                apiResponse["type"] = SUCCESS
                apiResponse["messages"] = [('manage_account_users.messages.updateSuccess')]
                apiResponse["canTranslate"] = true
            }
            else if (updateAccountUserResponse && updateAccountUserResponse.error) {
                apiResponse["type"] = DANGER
                apiResponse["messages"] = updateAccountUserResponse.error.length > 0 && getApiErrorMessage(updateAccountUserResponse.error[0].error)
                apiResponse["canTranslate"] = false
            }
            this.setState({ apiResponse })
        }
        else if (JSON.stringify(prevProps.deleteAccountUserResponse) !== JSON.stringify(deleteAccountUserResponse)) {
            if (deleteAccountUserResponse && deleteAccountUserResponse.statusMessage == RESPONSE_SUCCESS) {
                apiResponse["type"] = SUCCESS
                apiResponse["messages"] = [('manage_account_users.messages.deleteSuccess')]
                apiResponse["canTranslate"] = true
            }
            else if (deleteAccountUserResponse && deleteAccountUserResponse.error) {
                apiResponse["type"] = DANGER
                apiResponse["messages"] = deleteAccountUserResponse.error.length > 0 && getApiErrorMessage(deleteAccountUserResponse.error[0].error)
                apiResponse["canTranslate"] = false
            }
            this.setState({ apiResponse })
        }
        else if (JSON.stringify(prevProps.userAddedResponse) != JSON.stringify(userAddedResponse)) {
            if (userAddedResponse && userAddedResponse.statusMessage == RESPONSE_SUCCESS) {
                apiResponse["type"] = SUCCESS
                apiResponse["messages"] = [('manage_account_users.messages.addSuccess')]
                apiResponse["canTranslate"] = true
            }
            else if (userAddedResponse && userAddedResponse.error) {
                apiResponse["type"] = DANGER
                apiResponse["messages"] = userAddedResponse.error.length > 0 && getApiErrorMessage(userAddedResponse.error[0].error)
                apiResponse["canTranslate"] = false
            }
            this.setState({ apiResponse })
        }
    }

    /**
    * Invokes API call to retrieve nominees so that it can be displayed in table.
    * 
    * @author Amrutha J Raj
    */
    populateNomineeList = () => {
        this.props.retrieveAccountUsers({
            object: getRequestBodyRetrieveAccountUsers()
        })
    }

    /**
    * Callback method when add account user is success
    * 
    * @author Amrutha J Raj
    */
    getUserAddedResponse() {
        this.setState({ showAddAccountUserPage: false, showSuccessMessage: true })
        this.populateNomineeList()
    }

    /**
   * Get table columns from configuration 
   * 
   * @author Amrutha J Raj
   */
    getTableColumnsFromConfig = (privilegeCheck) => {
        const { manageAccountUsersConfig } = this.props
        if (privilegeCheck) {
            if (manageAccountUsersConfig && manageAccountUsersConfig.ui && manageAccountUsersConfig.ui.layout &&
                manageAccountUsersConfig.ui.layout.elements && manageAccountUsersConfig.ui.layout.elements &&
                manageAccountUsersConfig.ui.layout.elements.view_account_users && manageAccountUsersConfig.ui.layout.elements.view_account_users.table
                && manageAccountUsersConfig.ui.layout.elements.view_account_users.table.columns &&
                manageAccountUsersConfig.ui.layout.elements.view_account_users.table.columns.length > 0) {
                return manageAccountUsersConfig.ui.layout.elements.view_account_users.table.columns.filter(c => c.privilege.includes(privilegeCheck.permission))
            }
        }
        else {
            return []
        }
    }

    render() {
        const { t, accountUsers, accountSummary, corporateNominees, userPrivileges } = this.props
        const { apiResponse } = this.state
        const userData = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE) === PROGRAM_TYPE_CORPORATE ? corporateNominees : accountSummary
        if (userPrivileges && userData) {
            const privilegeCheck = havePrivilege(
                { "url": getCurrentPageUri(), "tab": "" },
                userData,
                CONTEXT_PAGE,
                userPrivileges)
            return (
                <>
                    <h1>{this.state.showAddAccountUserPage ?
                        t('manage_account_users.add_account_users.title') :
                        t('manage_account_users.view_account_users.title')}
                    </h1>
                    {apiResponse && apiResponse.type && apiResponse.type.length > 0 && <CustomMessage type={apiResponse.type}
                        message={apiResponse.messages}
                        data-test="customMessageComponent" canTranslate={apiResponse.canTranslate} />
                    }
                    <div className="form-row mb-4 align-items-center">
                        <div className="col-lg-10">
                            <p>{this.state.showAddAccountUserPage ?   t('manage_account_users.add_account_users.description') :
                            t('manage_account_users.view_account_users.description')}</p>
                        </div>
                        {privilegeCheck && privilegeCheck.canDisplay && privilegeCheck.permission == FULL_ACCESS &&
                            <div className="col-lg-2 text-right">
                                <Button
                                    type="button"
                                    className="btn btn-secondary btn-sm"
                                    handleOnClick={() => {
                                        this.props.clearValidateResponse()
                                        this.setState({ showAddAccountUserPage: !this.state.showAddAccountUserPage, apiResponse: {} })
                                    }
                                    }
                                    label={this.state.showAddAccountUserPage ?
                                        t("manage_account_users.view_account_users.title") :
                                        t("manage_account_users.add_account_users.title")
                                    }
                                />

                            </div>
                        }
                    </div>

                    {this.state.showAddAccountUserPage ?
                        <AddAccountUser userdAdded={() => this.getUserAddedResponse()} /> :
                        <AccountUsersTable
                            privilegeCheck={privilegeCheck}
                            clearResponse={() => this.setState({ apiResponse: {} })}
                            field={{
                                "values": accountUsers && accountUsers.nomineeDetails,
                                "columns": this.getTableColumnsFromConfig(privilegeCheck)
                            }}
                            className={"table"} />
                    }
                </>
            );
        }
        else {
            return (<div></div>)
        }
    }
}

const mapStateToProps = (state) => {
    return {
        manageAccountUsersConfig: state.configurationReducer[CONFIG_SECTION_MANAGE_ACCOUNT_USERS],
        accountUsers: state.retrieveAccountUsersReducer.retrieveAccountUsers,
        userAddedResponse: state.addAccountUserReducer.response,
        updateAccountUserResponse: state.updateAccountUserPrivilegeReducer.response,
        deleteAccountUserResponse: state.deleteAccountUserReducer.response,
        userPrivileges: state.privilegesReducer.privileges,
        corporateNominees: state.retriveAccountNomineeReducer.corporateNominees,
        accountSummary: state.accountSummaryReducer.accountSummary

    }
}

const mapDispatchToProps = {
    fetchConfiguration,
    retrieveAccountUsers,
    clearValidateResponse
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(ManageAccountUsers)))

