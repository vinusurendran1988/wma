import { JSONPath } from 'jsonpath-plus';
import { Dialog } from 'primereact/dialog';
import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import FieldBank from '../../common/components/fieldbank';
import Button from '../../common/components/fieldbank/Button';
import { FIELDTYPE_TABLE } from '../../common/components/fieldbank/Constants';
import DropDown from '../../common/components/fieldbank/DropDown';
import Popup from '../../common/components/popup/Popup';
import { fetchMasterData } from '../../common/middleware/redux/commonAction';
import { FULL_ACCESS } from '../../common/privileges';
import {
    withSuspense
} from '../../common/utils';
import { ACCOUNT_USER_PRIVILEGE, CONFIG_SECTION_DEFAULT, CONFIG_SECTION_MANAGE_ACCOUNT_USERS } from '../../common/utils/Constants';
import { doAdditionalMapping } from '../../common/utils/object.utils';
import { BROWSER_STORAGE_KEY_CUSTOMER_NO, BROWSER_STORAGE_KEY_PROGRAM_CODE, getItemFromBrowserStorage } from '../../common/utils/storage.utils';
import { deleteAccountUser, updateAccountUserPrivilege } from './actions';
import { ACCOUNT_HOLDER, ACCOUNT_STATUS, ACTIVE, DELETED } from './Constants';

/**
 * Table to display nominees
 * @author Amrutha
 */
class AccountUsersTable extends Component {
    constructor(props) {
        super(props);
        this.state = {
            pointBlockObject: null,
            showModal: false,
            editPrivilegeData: false,
            selectedPrivilege: "",
            nomineeData: {},
            enabled: false,
            accountUserInfo: {},
            deleteAccountUserRequest: {},
            updateAccountUserRequest: {},
            nomineeAccountGroupType: "",
            openDeleteConfirmModal : false,
            accountUserToDelete : {}
        }
    }
    componentDidMount() {
        if (!this.props.accountStatusList || this.props.accountStatusList.length == 0) {
            this.props.fetchMasterData(ACCOUNT_STATUS, this.props.masterEntityLookup, this.props.masterEntityLookupFilters)
        }
        if (!this.props.privilegesList || this.props.privilegesList.length == 0) {
            this.props.fetchMasterData(ACCOUNT_USER_PRIVILEGE, this.props.masterEntityLookup, this.props.masterEntityLookupFilters)
        }

    }
    /**
     * Dropdown change for privilege
     * @param {selectedValue} selectedValue
     * @param {accountUser} Nominee Details
     * @param {props} props
     * 
     * @param {props} props
     * @author Amrutha J Raj
     * 
     */

    privilegeDropDownChange = (selectedValue, accountUser, props) => {
        const privilege = props && props.config &&
            JSONPath({ path: props.config.uiPath, json: accountUser }) && JSONPath({ path: props.config.uiPath, json: accountUser })[0]
        this.setState(
            {
                selectedPrivilege: selectedValue
            }, () => {
                if (privilege != this.state.selectedPrivilege) {
                    this.setState({ enabled: true })
                }
                else {
                    this.setState({ enabled: false })
                }
            })

    }

    /**
     * Column template for showing the privileges
     * @param {rowData} Nominee Details
     * @param {props} props
     * @author Amrutha J Raj
     * 
     */
    privilegeBodyTemplate = (rowData, props) => {
        if (props && props.config && props.config.uiPath) {
            if (this.props.privilegesList) {
                let selectedObj = this.props.privilegesList.find(item => item.FieldValue == JSONPath({ path: props.config.uiPath, json: rowData }))
                if (selectedObj && Object.keys(selectedObj).length > 0) {
                    return (
                        <React.Fragment>
                            {this.state.editPrivilegeData && this.state.editableId == rowData.customerNumber ?
                                <div className="text-field">
                                    <DropDown
                                        visibility={true}
                                        name="partnerCode"
                                        id="id-partnerCode"
                                        onChange={(value) => this.privilegeDropDownChange(value, rowData, props)}
                                        enabled={true}
                                        removeDefaultOption={true}
                                        options={this.props.privilegesList.map(privilege => {
                                            return {
                                                label: privilege.FieldDescription,
                                                value: privilege.FieldValue
                                            }
                                        })}
                                        value={selectedObj.FieldValue} />
                                </div>

                                :
                                <>
                                    {selectedObj.FieldDescription}

                                </>
                            }
                        </React.Fragment>
                    );
                }
            }
        }
    }

    /**
     * Column template for update/delete action
     * @param {rowData} Nominee details
     * 
     * @author Amrutha J Raj
     */
    actionBodyTemplate = (rowData, props) => {

        return <React.Fragment>
            {rowData.nomineeStatus == ACTIVE &&
                (getItemFromBrowserStorage(BROWSER_STORAGE_KEY_CUSTOMER_NO) !== rowData.customerNumber) &&
                (this.props.privilegeCheck && this.props.privilegeCheck.canDisplay && this.props.privilegeCheck.permission == FULL_ACCESS) &&
                rowData.accountGroupType != ACCOUNT_HOLDER &&
                <div className="btn-wrap btn-wrap--grp actions">
                    {this.state.editPrivilegeData && this.state.editableId == rowData.customerNumber ?
                        <>
                            <Button
                                type="button"
                                className="btn btn-primary btn-sm"
                                enabled={this.state.enabled}
                                handleOnClick={() => this.updatePrivilegeClick(rowData, props)}
                                label={this.props.t("manage_account_users.view_account_users.columns.update_btn")}
                            />
                            <Button
                                type="button"
                                className="btn btn-secondary btn-sm"
                                handleOnClick={() => this.setState(
                                    {
                                        editPrivilegeData: false,
                                        enabled: false,
                                        editableId: "",
                                        selectedPrivilege: ""
                                    })}
                                label={this.props.t("manage_account_users.view_account_users.columns.cancel_btn")}
                            />
                        </>
                        :
                        <>
                            <i className="fa fa-pencil"
                                title="Edit"
                                aria-hidden="true"
                                role="button"
                                onClick={() => {
                                    this.props.clearResponse()
                                    this.setState({
                                        editPrivilegeData: true,
                                        enabled: false,
                                        editableId: rowData.customerNumber,

                                    })
                                }
                                }
                            ></i>
                            &nbsp;
                        <i className="fa fa-trash" type="button"
                            title="Delete"
                            onClick={() => this.setState({ openDeleteConfirmModal: true, accountUserToDelete: rowData })}
                            aria-hidden="true"></i>
                    </>
                    }
                </div>
            }


        </React.Fragment>
    }
    /**
     * Column template for showing the status
     * @param {rowData} Extend or Renew Table row
     * @param {props} props
     * @author Amrutha J Raj
     * 
     */
    statusBodyTemplate = (rowData, props) => {
        if (this.props.accountStatusList) {
            let selectedObj = this.props.accountStatusList.find(item => item.FieldValue == rowData.nomineeStatus)
            if (selectedObj && Object.keys(selectedObj).length > 0) {
                return (
                    <React.Fragment>
                        <span className={`badge ${selectedObj.FieldDescription == DELETED ?
                            "badge-danger" : "badge-success"}`}>
                            {selectedObj.FieldDescription}</span>
                    </React.Fragment>
                );
            }
        }
    }

    /**
    * Method to delete account user 
    * @param {accountUser}  Accountuser to be deleted 
    * 
    * @author Amrutha J Raj
    * 
    */
    deleteConfirmModal = () => {
        return (<Dialog
            aria-labelledby={`Label`}
            aria-modal="true"
            id={"delete"}
            dismissableMask={true}
            closable={false}
            visible={this.state.openDeleteConfirmModal}
            header=""
            className="confirm-modal"
            onHide={() => this.setState({ openDeleteConfirmModal: false })}
            footer={
                <div className="btn-wrap btn-wrap--grp">
                    <Button
                        className="btn btn-secondary"
                        handleOnClick={() => this.setState({ openDeleteConfirmModal: false })}
                        id="delete-cancel"
                        label={this.props.t("manage_account_users.delete_prompt.cancel")} />
                    <Button
                        className="btn btn-primary"
                        handleOnClick={() => this.deleteAccountUserClick(this.state.accountUserToDelete)}
                        id="delete-button"
                        label={this.props.t("manage_account_users.delete_prompt.submit")} />
                </div>
            }
        >
            <div className="modal-body">
                <h4>{this.props.t("manage_account_users.delete_prompt.message")}</h4>
            </div>
        </Dialog>
        )
    }

    /**
      * Method to delete account user 
      * @param {accountUser}  Accountuser to be deleted 
      * 
      * @author Amrutha J Raj
      * 
      */
    deleteAccountUserClick = (accountUser) => {
        const { config, defaultConfig } = this.props
        this.setState({
            accountUserInfo: accountUser,
            openDeleteConfirmModal:false,
            nomineeAccountGroupType: this.getAccountGroupType(defaultConfig, accountUser.accountGroupType)
        }, () => {
            if (config) {
                if (config.ui && config.ui.layout &&
                    config.ui.layout.elements &&
                    config.ui.layout.elements.delete_account_user &&
                    config.ui.layout.elements.delete_account_user.request &&
                    config.ui.layout.elements.delete_account_user.request.additionalMapping
                ) {
                    doAdditionalMapping(this, "deleteAccountUserRequest", config.ui.layout.elements.delete_account_user.request.additionalMapping)
                }
            }
        })
        this.props.clearResponse()
        this.props.deleteAccountUser(this.state.deleteAccountUserRequest)
    }

    /**
    * Method to get account group type
    * @param {config}  config
    * @param {accountGroupType}  accountGroupType
    * 
    * 
    * @author Amrutha J Raj
    * 
    */
    getAccountGroupType(config, accountGroupType) {
        if (config && config.programs) {
            let corpProg = config.programs.find(obj => obj.programCode == getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE))
            if (corpProg && Object.keys(corpProg).length > 0 && corpProg.data && corpProg.data.nomineeAccountGroupTypes) {
                let accountGroupObj = corpProg.data.nomineeAccountGroupTypes.find(item => item.value == accountGroupType)
                if (accountGroupObj && Object.keys(accountGroupObj).length > 0) {
                    return accountGroupObj.key
                }
            }
        }
    }

    /**
    * Method to update account user privilege 
    * @param {accountUser}  Accountuser to be deleted 
    * 
    * @author Amrutha J Raj
    * 
    */
    updatePrivilegeClick = (accountUser, props) => {
        const { config, defaultConfig } = this.props
        this.setState(
            {
                editPrivilegeData: false,
                editableId: accountUser.customerNumber,
                nomineeData: accountUser,
                nomineeAccountGroupType: this.getAccountGroupType(defaultConfig, accountUser.accountGroupType)
            }, () => {
                if (config) {
                    if (config.ui && config.ui.layout &&
                        config.ui.layout.elements &&
                        config.ui.layout.elements.update_account_user &&
                        config.ui.layout.elements.update_account_user.request &&
                        config.ui.layout.elements.update_account_user.request.additionalMapping
                    ) {
                        doAdditionalMapping(this, "updateAccountUserRequest", config.ui.layout.elements.update_account_user.request.additionalMapping)
                    }
                }
            })

        const privilege = props && props.config &&
            JSONPath({ path: props.config.uiPath, json: accountUser }) && JSONPath({ path: props.config.uiPath, json: accountUser })[0]

        if (privilege !== this.selectedPrivilege) {
            this.setState({ enabled: true })
            this.props.updateAccountUserPrivilege(this.state.updateAccountUserRequest)

        }
    }

    render() {
        const { field, className, t, globalFilter, } = this.props;
        return (
            <>
                <FieldBank
                    field={{
                        fieldType: FIELDTYPE_TABLE,
                        globalFilter: globalFilter,
                        emptyMessage: t('extend_expiry.no_results_found'),
                        bodyTemplates: {
                            privilegeBodyTemplate: this.privilegeBodyTemplate,
                            statusBodyTemplate: this.statusBodyTemplate,
                            actionBodyTemplate: this.actionBodyTemplate

                        },
                        ...field
                    }}
                    className={className}
                />
                { this.deleteConfirmModal()}
            </>);
    }

}

const mapStateToProps = (state) => {
    return {
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        masterEntityLookup: state.masterEntityDataReducer.masterEntityLookup,
        config: state.configurationReducer[CONFIG_SECTION_MANAGE_ACCOUNT_USERS],
        accountStatusList: state.masterData[ACCOUNT_STATUS] ? state.masterData[ACCOUNT_STATUS] : [],
        privilegesList: state.masterData[ACCOUNT_USER_PRIVILEGE] ? state.masterData[ACCOUNT_USER_PRIVILEGE] : [],
        masterEntityLookupFilters: state.masterEntityDataReducer.masterEntityLookupFilters,
    }
}
const mapDispatchToProps = {
    fetchMasterData,
    deleteAccountUser,
    updateAccountUserPrivilege

}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(AccountUsersTable)));