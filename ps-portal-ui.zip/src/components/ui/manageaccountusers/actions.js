import { getRequestBodyRetrieveAccountUsers } from "."
import { startApiLoading, startButtonSpinner, stopApiLoading, stopButtonSpinner } from "../../common/components/fieldbank/loader/action"
import { _URL_ADD_NOMINEE, _URL_DELETE_NOMINEE, _URL_RETRIEVE_ACCOUNT_USERS, _URL_UPDATE_ACCOUNT_USER_PRIVILEGE } from "../../common/config/config"
import { ERROR } from "../../common/middleware/redux/commonAction"
import { getApiErrorMessage } from "../../common/utils"
import { doPost } from "../../common/utils/api"
import {
    ACTION_ADD_ACCOUNT_USER, ACTION_RETRIEVE_ACCOUNT_USERS_SUCCESS, ACTION_UPDATE_ACCOUNT_USER_DELETE, ACTION_UPDATE_ACCOUNT_USER_PRIVILEGE
} from "./Constants"

/**
 * Action call to retrieve account users
 * @param {JSON} payload Request payload to be dispatched
 * @author Amrutha J Raj
 */
export const retrieveAccountUsers = (payload) => {
    return async dispatch => {
        dispatch(startApiLoading("retrieveNominees"))
        await doPost(_URL_RETRIEVE_ACCOUNT_USERS, payload)
            .then((response) => {
                dispatch(stopApiLoading("retrieveNominees"))
                dispatch({
                    type: ACTION_RETRIEVE_ACCOUNT_USERS_SUCCESS,
                    payload: response.data.object
                })
            })
            .catch((error) => {
                dispatch(stopApiLoading("retrieveNominees"))
                dispatch({
                    type: ERROR,
                    payload: { error: getApiErrorMessage(error.response.data.error) }
                })
            })
    }
}

/**
 * Action call to add account user
 * @param {JSON} payload Request payload to be dispatched
 * @param {String} id
 * 
 * @author Amrutha J Raj
 */
export const addAccountUser = (payload, id) => {
    return async dispatch => {
        dispatch({
            type: ACTION_ADD_ACCOUNT_USER,
            payload: {}
        })

        dispatch(startButtonSpinner(id, "addAccountUser"))
        await doPost(_URL_ADD_NOMINEE, payload)
            .then((response) => {
                dispatch(stopButtonSpinner(id, "addAccountUser"))
                dispatch({
                    type: ACTION_ADD_ACCOUNT_USER,
                    payload: response.data
                })
                dispatch(retrieveAccountUsers({
                    object: getRequestBodyRetrieveAccountUsers()
                }))
            })
            .catch((error) => {
                dispatch(stopButtonSpinner(id, "addAccountUser"))
                dispatch({
                    type: ACTION_ADD_ACCOUNT_USER,
                    payload: { error: getApiErrorMessage(error.response.data) }
                })
            })
    }
}


/**
 * Action call to update account user
 * @param {JSON} payload Request payload to be dispatched
 * @author Amrutha J Raj
 */
export const updateAccountUserPrivilege = (payload) => {
    return async dispatch => {
        dispatch({
            type: ACTION_UPDATE_ACCOUNT_USER_PRIVILEGE,
            payload: {}
        })
        dispatch(startApiLoading("updateAccountUserPrivilege"))
        await doPost(_URL_UPDATE_ACCOUNT_USER_PRIVILEGE, payload)
            .then((response) => {

                dispatch({
                    type: ACTION_UPDATE_ACCOUNT_USER_PRIVILEGE,
                    payload: response.data
                })

                dispatch(retrieveAccountUsers({
                    object: getRequestBodyRetrieveAccountUsers()
                }))
                dispatch(stopApiLoading("updateAccountUserPrivilege"))
            })
            .catch((error) => {
                dispatch(stopApiLoading("updateAccountUserPrivilege"))
                dispatch({
                    type: ACTION_UPDATE_ACCOUNT_USER_PRIVILEGE,
                    payload: { error: getApiErrorMessage(error.response.data) }
                })
            })
    }
}

/**
 * Action call to delete account user
 * @param {JSON} payload Request payload to be dispatched
 * @author Amrutha J Raj
 */
export const deleteAccountUser = (payload) => {
    return async dispatch => {
        dispatch({
            type: ACTION_UPDATE_ACCOUNT_USER_DELETE,
            payload: {}
        })
        dispatch(startApiLoading("deleteAccountUser"))
        await doPost(_URL_DELETE_NOMINEE, payload)
            .then((response) => {
                dispatch({
                    type: ACTION_UPDATE_ACCOUNT_USER_DELETE,
                    payload: response.data
                })
                dispatch(retrieveAccountUsers({
                    object: getRequestBodyRetrieveAccountUsers()
                }))
                dispatch(stopApiLoading("updateAccountUserPrivilege"))
            })
            .catch((error) => {
                dispatch(stopApiLoading("deleteAccountUser"))
                dispatch({
                    type: ACTION_UPDATE_ACCOUNT_USER_DELETE,
                    payload: { error: getApiErrorMessage(error.response.data) }
                })
            })
    }
}