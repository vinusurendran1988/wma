import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import CustomMessage from '../../common/components/custommessage';
import Button from '../../common/components/fieldbank/Button';
import { clearValidateResponse, fetchMasterData, resetError, setError, validateMemberDetails } from '../../common/middleware/redux/commonAction';
import { getApiErrorMessage, withSuspense } from '../../common/utils';
import { ACCOUNT_USER_PRIVILEGE, CONFIG_SECTION_MANAGE_ACCOUNT_USERS, RELATIONSHIP } from '../../common/utils/Constants';
import { doAdditionalMapping } from '../../common/utils/object.utils';
import Section from '../updateprofile/Section';
import { addAccountUser } from './actions';
import { ACCOUNT_STATUS, ADD_ACCOUNT_USER, ADD_MEMBER, DANGER, TAB_MEMBER, VALIDATE_MEMBER } from './Constants';

class AddAccountUser extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedTab: TAB_MEMBER,
            showWarningAndErrorValidate: false,
            showWarningAndErrorAdd: false,
            isValidateButtonClicked: false,
            isAddButtonClicked: false,
            request: {},
            validateUserResponseObject: {},
            isValidationSuccess: false,
            validateMemberError: [],
            addUserError: [],
            addUserAccountRequest: {},
            accountStatus: "",
            apiResponse: {
                type: "",
                messages: [],
                canTranslate: false
            },
            translate: false,
            disableValidateInfo: true
        }
    }
    componentDidMount() {
        this.initializePage()

        if (!this.props.relationship || this.props.relationship.length == 0) {
            this.props.fetchMasterData(RELATIONSHIP, this.props.masterEntityLookup, this.props.masterEntityLookupFilters)
        }
        if (!this.props.privilegesList || this.props.privilegesList.length == 0) {
            this.props.fetchMasterData(ACCOUNT_USER_PRIVILEGE, this.props.masterEntityLookup, this.props.masterEntityLookupFilters)
        }
    }

    componentDidUpdate(prevProps) {
        const { config, errors } = this.props
        if (this.props.memberData && Object.keys(this.props.memberData).length > 0) {
            if (JSON.stringify(prevProps.memberData) !== JSON.stringify(this.props.memberData)) {

                if (config) {
                    if (config.ui && config.ui.layout &&
                        config.ui.layout.elements && config.ui.layout.elements &&
                        config.ui.layout.elements.add_account_user &&
                        config.ui.layout.elements.add_account_user.elements &&
                        config.ui.layout.elements.add_account_user.elements.basic_info &&
                        config.ui.layout.elements.add_account_user.elements.basic_info.request &&
                        config.ui.layout.elements.add_account_user.elements.basic_info.request.additionalMapping
                    ) {
                        doAdditionalMapping(this, "addUserAccountRequest", config.ui.layout.elements.add_account_user.elements.basic_info.request.additionalMapping)
                    }
                }

                this.setState({
                    isValidationSuccess: true,
                    disableValidateInfo: false,
                    addUserError: [],
                    validateMemberError: [],
                    validateUserResponseObject: {
                        object: this.props.memberData
                    }
                })
            }

        }

        if (errors) {
            if (errors.message && JSON.stringify(errors) != JSON.stringify(prevProps.errors)) {
                this.setState({
                    apiResponse: {
                        type: DANGER,
                        messages: getApiErrorMessage(errors),
                        canTranslate: false
                    }
                })
            }
        }

        if (JSON.stringify(prevProps.userAddedResponse) != JSON.stringify(this.props.userAddedResponse)) {
            this.props.userdAdded()
        }

    }

    /**
    * Handles the tab change
    * @param {Event} event 
    * @author Amrutha J Raj
    */
    changeTab(tab) {
        this.setState({
            selectedTab: tab,
            dropdownDisplay: "none"
        })
    }

    /**
    * Initialize the page
    * 
    * @author Amrutha J Raj
    */
    initializePage() {
        const { config } = this.props

        if (config) {
            if (config.ui && config.ui.layout &&
                config.ui.layout.elements && config.ui.layout.elements &&
                config.ui.layout.elements.add_account_user &&
                config.ui.layout.elements.add_account_user.elements &&
                config.ui.layout.elements.add_account_user.elements.validate_info &&
                config.ui.layout.elements.add_account_user.elements.validate_info.request &&
                config.ui.layout.elements.add_account_user.elements.validate_info.request.additionalMapping
            ) {
                doAdditionalMapping(this, "request", config.ui.layout.elements.add_account_user.elements.validate_info.request.additionalMapping)
            }
        }
    }

    /**
    * Method to get the tabs from config
    * 
    * @author Amrutha J Raj
    */
    getTabsFromConfig = () => {
        const { config } = this.props
        if (config.ui && config.ui.layout &&
            config.ui.layout.elements && config.ui.layout.elements &&
            config.ui.layout.elements.add_account_user &&
            config.ui.layout.elements.add_account_user.tabs) {
            return config.ui.layout.elements.add_account_user.tabs
        }
    }

    /**
  * Handle request change for textfield from Section
  * @param {Object} request
  * @author Amrutha J Raj
  */
    handleRequestChange(request, key) {
        const payload = {}
        if (key == VALIDATE_MEMBER) {
            this.setState({ request })
        }
        else if (key == ADD_MEMBER) {
            this.setState({ addUserAccountRequest: request })
        }
        this.setState({
            showWarningAndErrorValidate: false,
            showWarningAndErrorAdd: false
        })
    }

    /**
     * Handle validation error messages from Section
     * @param {key} request
     * @param {codes} codes
     * @author Amrutha J Raj
     */
    handleErrorMessagesFromSection(key, codes) {
        if (!codes.length) { this.props.resetError() }
        if (JSON.stringify(codes) != JSON.stringify(this.state[key])) {
            this.setState({ [key]: codes })
        }
    }

    /**
    * Set state from Section
    * @param {Object} field
    * @param {String} value
    * 
    * @author Amrutha J Raj
    */
    addValueToState(field, value) {
        let newState = {}
        newState[field.name] = value
        this.setState(newState)
    }

    /**
    * Method to handle validations from Section
    * @param {Object} field
    * @param {Object} validation
    * @param {String} value 
    *
    * @author Amrutha J Raj
    */
    validateWithStateVariable(field, validation, value, key) {
        let { pattern, fields } = validation
        let isValidationSuccess = true, canUpdateState = false
        fields.forEach((fd) => {
            const newPattern = pattern.replace("[fields]", this.state[fd])
            if (!isPatternMatch(newPattern, value)) {
                isValidationSuccess = false
            }
        })
        let errorCodes = this.state[key]
        if (!isValidationSuccess) {
            if (!errorCodes.includes(validation.customMessageId)) {
                errorCodes.push(validation.customMessageId)
                canUpdateState = true
            }
        } else if (errorCodes.includes(validation.customMessageId)) {
            const index = errorCodes.indexOf(validation.customMessageId)
            if (index > -1) {
                canUpdateState = true
                errorCodes.splice(index, 1)
            }
        }
        field.error = !isValidationSuccess
        if (canUpdateState) {
            this.setState({
                [key]: errorCodes,
                translate: true
            })
        }
        return !isValidationSuccess
    }

    /**
    * Method to find value from state
    * @param {Object} stateFieldName
    * 
    * @author Amrutha J Raj
    */
    findValueFromState(stateFieldName) {
        return this.state[stateFieldName] ? this.state[stateFieldName] : ""
    }

    /**
    * Method to validate member
    * 
    * 
    * @author Amrutha J Raj
    */
    validateMember = () => {
        const { validateMemberError, request } = this.state;
        this.setState({ addUserError: [], apiResponse: {} })
        if (validateMemberError.length > 0) {
            this.props.setError(validateMemberError);
        } else {
            this.props.validateMemberDetails(request)
        }
        this.setState({
            showWarningAndErrorValidate: true,
            isValidateButtonClicked: true
        })


    }

    /**
    * Method to reset form data
    * 
    * 
    * @author Amrutha J Raj
    */
    resetFormData() {
        this.props.resetError()
        this.props.clearValidateResponse()

        this.setState({
            isValidateButtonClicked: false,
            isAddButtonClicked: false,
            request: {},
            disableValidateInfo: true,
            validateUserResponseObject: {},
            isValidationSuccess: false,
            addUserAccountRequest: {},
            showWarningAndErrorValidate: false,
            showWarningAndErrorAdd: false
        }, () => {
            this.initializePage()

        })
    }


    addAccountUser = () => {
        const { addUserError } = this.state;
        const { config } = this.props

        if (addUserError.length > 0) {
            this.props.setError(addUserError);
        } else {
            if (config) {
                if (config.ui && config.ui.layout &&
                    config.ui.layout.elements && config.ui.layout.elements &&
                    config.ui.layout.elements.add_account_user &&
                    config.ui.layout.elements.add_account_user.elements &&
                    config.ui.layout.elements.add_account_user.elements.basic_info &&
                    config.ui.layout.elements.add_account_user.elements.basic_info.request &&
                    config.ui.layout.elements.add_account_user.elements.basic_info.request.additionalMapping
                ) {
                    this.props.addAccountUser(this.state.addUserAccountRequest, ADD_ACCOUNT_USER)
                }
            }
        }
        this.setState({
            showWarningAndErrorAdd: true,
            isAddButtonClicked: true
        })

    }
    render() {
        const { t, config } = this.props
        const { showWarningAndErrorAdd, isValidateButtonClicked, isAddButtonClicked, showWarningAndErrorValidate, apiResponse, selectedTab, validateMemberError, addUserError } = this.state
        const errorCodes = isAddButtonClicked ? [...validateMemberError, ...addUserError] : [...validateMemberError]
        const tabs = config && this.getTabsFromConfig()
        const sectionElements = config && config.ui && config.ui.layout &&
            config.ui.layout.elements && config.ui.layout.elements.add_account_user &&
            config.ui.layout.elements.add_account_user.elements

        return (
            <div>
                {(showWarningAndErrorValidate || showWarningAndErrorAdd) &&
                    <CustomMessage type={errorCodes.length > 0 ? DANGER : apiResponse.type}
                        message={errorCodes.length > 0 ? errorCodes : apiResponse.messages}
                        data-test="customMessageComponent"
                        canTranslate={errorCodes.length > 0 ? errorCodes.length > 0 : apiResponse.canTranslate} />}

                <nav data-test="navigation" className="tab">
                    <div id='countries' className="tab__mob">
                        <i className="fa fa-caret-down" aria-hidden="true"></i>
                        <dl>
                            <dt>
                                <a data-test="default-tab" onClick={() => this.setState({ dropdownDisplay: "block" })}>
                                    <span>{t(`manage_account_users.add_account_users.tabs.${selectedTab}`)}</span></a>
                            </dt>
                            <dd>
                                <ul data-test="tab-list" style={{ display: this.state.dropdownDisplay }}>
                                    {tabs && tabs.map((tab, index) => {
                                        return (<li key={index}>
                                            <a data-test={`tab-Mob-${index}`} onClick={() => this.changeTab(tab)}>
                                                {t(`manage_account_users.add_account_users.tabs.${tab}`)}</a></li>)
                                    })}
                                </ul>
                            </dd>
                        </dl>
                    </div>

                    <div className="nav nav-tabs nav-tabs--booking" id="nav-tab" role="tablist">
                        {tabs && tabs.map((tab, index) => {
                            return (
                                <a className={"nav-item nav-link " + (selectedTab === tab ? "active" : "")}
                                    key={index}
                                    data-test={`tab-btn-${index}`}
                                    id="nav-home-tab"
                                    onClick={() => this.changeTab(tab)}
                                    data-toggle="tab" href={`${tab}`} role="tab" aria-controls="nav-1" aria-selected="true">
                                    <span>  {t(`manage_account_users.add_account_users.tabs.${tab}`)}</span>
                                </a>
                            )
                        })}
                    </div>
                </nav>

                <div className="tab-content" id="nav-tabContent">
                    <div className="tab-pane fade show active" id="nav-1" role="tabpanel" aria-labelledby="nav-home-tab">
                        <div className="col-xl-8 col-lg-10 col-md-12">
                            <div className="form-row">
                                <div className="col-lg-12">
                                    {sectionElements && <Section
                                        key={"add-account-user"}
                                        page={"add_account_user"}
                                        id={"add-account-user"}
                                        displayElements={sectionElements.validate_info}
                                        request={this.state.request}
                                        canWrite={this.state.disableValidateInfo}
                                        onRequestChange={(req) => this.handleRequestChange(req, VALIDATE_MEMBER)}
                                        dynamicAttributes={""}
                                        errorCodes={this.state.validateMemberError}
                                        handleOnClick={() => this.validateMember()}
                                        showWarningAndError={showWarningAndErrorValidate}
                                        onErrorCodes={(codes) => this.handleErrorMessagesFromSection(codes, "validateMemberError")}
                                        isButtonClicked={isValidateButtonClicked}
                                        addValueToState={(field, value) => this.addValueToState(field, value)}
                                        validateWithStateVariable={(field, validation, value) => this.validateWithStateVariable(field, validation, value, "validateMemberError")}
                                        findValueFromState={(stateFieldName, fieldType) => this.findValueFromState(stateFieldName, fieldType)}
                                    />}
                                </div>
                                {this.state.isValidationSuccess ?
                                    <div className="col-lg-12">
                                        {sectionElements && <Section
                                            key={"add-account-user"}
                                            page={"add_account_user"}
                                            id={"add-account-user"}
                                            displayElements={sectionElements.basic_info}
                                            request={this.state.addUserAccountRequest}
                                            onRequestChange={(req) => this.handleRequestChange(req, ADD_MEMBER)}
                                            dynamicAttributes={""}
                                            errorCodes={this.state.addUserError}
                                            showWarningAndError={showWarningAndErrorAdd}
                                            onErrorCodes={(codes) => this.handleErrorMessagesFromSection(codes, "addUserError")}
                                            isButtonClicked={isAddButtonClicked}
                                            addValueToState={(field, value) => this.addValueToState(field, value)}
                                            validateWithStateVariable={(field, validation, value) => this.validateWithStateVariable(field, validation, value, "addUserError")}
                                            findValueFromState={(stateFieldName, fieldType) => this.findValueFromState(stateFieldName, fieldType)}
                                        />}

                                        <div className="btn-wrap btn-wrap--grp text-lg-right">
                                            <Button
                                                className="btn btn-secondary"
                                                handleOnClick={() => this.resetFormData()}
                                                id={"id-cancel"}
                                                label={t("manage_account_users.add_account_users.basic_info.cancel_btn")} />
                                            <Button
                                                className="btn btn-primary"
                                                handleOnClick={() => this.addAccountUser()}
                                                id={"id-add"}
                                                label={t("manage_account_users.add_account_users.basic_info.add_btn")} />
                                        </div>
                                    </div>
                                    :
                                    ""
                                }
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        memberData: state.validateMemberDetailReducer.validateMemberData,
        masterEntityLookup: state.masterEntityDataReducer.masterEntityLookup,
        config: state.configurationReducer[CONFIG_SECTION_MANAGE_ACCOUNT_USERS],
        relationship: state.masterData[RELATIONSHIP] ? state.masterData[RELATIONSHIP] : [],
        masterEntityLookupFilters: state.masterEntityDataReducer.masterEntityLookupFilters,
        userAddedResponse: state.addAccountUserReducer.response,
        errors: state.commonErrorReducer.error,
        accountStatusList: state.masterData[ACCOUNT_STATUS] ? state.masterData[ACCOUNT_STATUS] : [],

    }
}
const mapDispatchToProps = {
    setError,
    resetError,
    validateMemberDetails,
    fetchMasterData,
    addAccountUser,
    clearValidateResponse
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(AddAccountUser)));
