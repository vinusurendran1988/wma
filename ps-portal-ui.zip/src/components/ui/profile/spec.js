import React from 'react';
import { Provider } from 'react-redux';
import { mount } from 'enzyme';
import moxios from 'moxios';
import { testStore } from '../../common/utils';
import Profile from './index'
import {
    SESSION_STORAGE_COMPANY_CODE,
    SESSION_STORAGE_PROGRAM_CODE,
    SESSION_STORAGE_MEMBERSHIP_NO,
    CONFIG_SECTION_PROFILE
} from '../../common/utils/Constants';
import {
    mockServiceResponse,
    findByTestAttr
} from '../../common/testUtils';
import { fetchConfiguration } from '../../common/middleware/redux/commonAction';

var store;
let rootComponent;
let component;

const setUp = (props = {}) => {
    window.sessionStorage.setItem(SESSION_STORAGE_COMPANY_CODE, 'IBS')
    window.sessionStorage.setItem(SESSION_STORAGE_PROGRAM_CODE, 'PRG14')
    localStorage.setItem(SESSION_STORAGE_MEMBERSHIP_NO, 'IM0008010415')
    rootComponent = mount(
        <Provider store={store} >
            <Profile {...props} />
        </Provider>
    );
};

/**
 * Test for Profile component
 * @author Ajmal Aliyar
 */
describe('Profile Component', () => {
    describe('Render without errors', () => {
        beforeEach(() => {
            const RESPONSE_CONFIG_PROFILE = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "section": "profile", "companyCode": "IBS", "programCode": "PRG14", "accountStatusCodes": { "Unregistered": "U", "Active": "A", "Inactive": "I", "Suspended": "S", "Deleted": "D", "Closed": "C", "Expired": "E", "Merged": "M", "Provisional": "P", "Payment Due": "R", "Inactive-Unregistered": "V", "On Hold": "H", "Pending Activation": "N", "Blocked": "B" }, "operationFlags": { "Insert": "I", "Update": "U", "Delete": "D" }, "addressTypes": { "Home": "H", "Business": "B" }, "membershipStatusCodes": { "Active": "A", "BlackListed": "B", "Closed": "C", "Deceased": "D", "Suspended": "S", "Inactive": "I", "Protected": "P" }, "image": { "maxSizeInMB": 2, "supportedTypes": ["png", "jpg", "jpeg"] }, "password": { "pattern": "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&.,{}()?-_=+<>*!^/]).{8,20})" }, "qrConfig": { "width": 350, "height": 350, "defaultPointType": "BONUS", "fields": [{ "fieldName": "givenName", "labelName": "Member Name" }, { "fieldName": "membershipNumber", "labelName": "Membership ID" }, { "fieldName": "tierName", "labelName": "Tier Name" }, { "fieldName": "tierToDate", "labelName": "Expiry date" }] }, "dynamicAttributes": { "updateProfile": [{ "attributeCode": "68", "attributeName": "User Id", "attributeValue": "", "attributeMapping": "userId", "type": "C" }, { "attributeCode": "23", "attributeName": "English Name", "attributeValue": "", "attributeMapping": "koreanName", "type": "P" }, { "attributeCode": "18", "attributeName": "Secret Question", "attributeValue": "", "type": "P" }, { "attributeCode": "19", "attributeName": "Answer", "attributeValue": "", "type": "P" }] }, "ui": { "tabs": ["update-profile", "security", "preference"], "dynamicAttributesPath": "object.memberAccount.memberDynamicAttributes", "isLayoutSequential": false, "image": { "defaultAvatarMale": "", "defaultAvatarFemale": "", "defaultAvatarOthers": "" }, "layout": { "order": ["basicInfo", "contactInfo", "companyInfo", "pinInfo", "securityQnInfo"], "elements": { "basicInfo": { "fields": [{ "name": "displayName", "id": "id-displayName", "visibility": true, "required": true, "path": "object.memberAccount.memberProfile.individualInfo.displayName", "validation": { "pattern": "^[ a-zA-Z0-9]{1,20}$", "customMessageId": "profile.form.name" } }, { "name": "koreanName", "id": "id-koreanName", "visibility": true, "validation": { "pattern": "^[ a-zA-Z]{1,20}$", "customMessageId": "profile.form.kname" } }, { "name": "givenName", "id": "id-givenName", "visibility": true, "required": true, "path": "object.memberAccount.memberProfile.individualInfo.givenName", "validation": { "pattern": "^[ a-zA-Z]{1,20}$", "customMessageId": "profile.form.fname" }, "additional": [{ "id": "id-title", "name": "title", "type": "lov", "source": "master", "path": "object.memberAccount.memberProfile.individualInfo.title", "values": [{ "key": "M", "value": "Male" }, { "key": "F", "value": "Female" }], "sourceKey": "titleMaster", "isRequired": true, "validation": { "pattern": "^[a-zA-Z]{1,20}$", "customMessageId": "enrolment.form.title" } }] }, { "name": "familyName", "id": "id-familyName", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.familyName", "validation": { "pattern": "^[ a-zA-Z]{1,20}$", "customMessageId": "profile.form.lname" } }, { "name": "dateOfBirth", "id": "id-dateOfBirth", "path": "object.memberAccount.memberProfile.individualInfo.dateOfBirth", "visibility": true, "required": true, "validation1": { "pattern": "^[0-9]{4}-[a-zA-Z]{3}-[0-9]{2}$", "customMessageId": "profile.form.dob" } }, { "name": "gender", "id": "id-gender", "path": "object.memberAccount.memberProfile.individualInfo.gender", "visibility": true, "source": "default", "sourceKey": "gender", "required": true }, { "name": "preferredLanguage", "id": "id-preferred-language", "path": "object.memberAccount.memberProfile.individualInfo.preferredLanguage", "type": "lov", "source": "master", "sourceKey": "languageMaster", "visibility": true, "isRequired": true, "validation": { "pattern": "[A-Z]{2}$", "customMessageId": "enrolment.form.preferredLanguage" } }] }, "contactInfo": { "fields": [{ "name": "address1", "id": "id-address1", "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.0.addressLine1", "visibility": true }, { "name": "address1Line1", "id": "id-addressLine1", "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.0.addressLine2", "visibility": true }, { "name": "address1PostCode", "id": "id-address1PostCode", "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.0.zipCode", "visibility": true, "validation": { "pattern": "^[0-9]{4,10}$", "customMessageId": "profile.form.postcode" } }, { "name": "address1Ph", "id": "id-address1Ph", "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.0.phoneNumber", "visibility": true, "validation": { "pattern": "^[0-9]{5,15}$", "customMessageId": "form.phone.errorMessage" } }, { "name": "address1MobileISDCode", "id": "id-address1MobileISDCode", "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.0.mobileISDCode", "visibility": true }, { "name": "address1Mobile", "id": "id-address1Mobile", "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.0.mobileNumber", "visibility": true, "validation": { "pattern": "^[0-9]{5,15}$", "customMessageId": "form.mobileNumber.errorMessage" } }, { "name": "address1Fax", "id": "id-address1Fax", "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.0.faxNumber", "visibility": true, "validation": { "pattern": "^[0-9]{5,15}$", "customMessageId": "form.mobileNumber.errorMessage" } }, { "name": "memberNationality", "id": "id-natinality", "path": "object.memberAccount.memberProfile.individualInfo.memberNationality", "type": "lov", "source": "master", "sourceKey": "countryMaster", "visibility": true, "isRequired": true, "validation": { "pattern": "[A-Z]{2}$", "customMessageId": "enrolment.form.nationality" } }, { "name": "address1Email", "id": "id-address1Email", "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.0.emailAddress", "visibility": true, "validation": { "pattern": "\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$", "customMessageId": "form.emailAddress.errorMessage" } }] }, "companyInfo": { "fields": [{ "name": "companyName", "id": "id-company-name", "path": "object.memberAccount.memberProfile.individualInfo.companyName", "visibility": true }, { "name": "jobTitle", "id": "id-jobTitle", "path": "object.memberAccount.memberProfile.individualInfo.designation", "visibility": true }, { "name": "address2", "id": "id-address2", "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.1.addressLine1", "visibility": true }, { "name": "address2Line1", "id": "id-address2Line1", "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.1.addressLine2", "visibility": true }, { "name": "address2PostCode", "id": "id-address2PostCode", "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.1.zipCode", "visibility": true, "validation": { "pattern": "^[0-9]{4,10}$", "customMessageId": "profile.form.postcode" } }, { "name": "address2Ph", "id": "id-address2Ph", "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.1.phoneNumber", "visibility": true, "validation": { "pattern": "^[0-9]{5,15}$", "customMessageId": "form.phone.errorMessage" } }, { "name": "address2MobileISDCode", "id": "id-address2MobileISDCode", "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.1.mobileISDCode", "visibility": true }, { "name": "address2Mobile", "id": "id-address2Mobile", "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.1.mobileNumber", "visibility": true, "validation": { "pattern": "^[0-9]{5,15}$", "customMessageId": "form.mobileNumber.errorMessage" } }, { "name": "address2Fax", "id": "id-address2Fax", "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.1.faxNumber", "visibility": true }, { "name": "address2Email", "id": "id-address2Email", "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.1.emailAddress", "visibility": true, "validation": { "pattern": "^(|\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+)$", "customMessageId": "form.emailAddress.errorMessage" } }] }, "pinInfo": { "fields": [{ "name": "", "id": "", "visibility": true }] }, "securityQnInfo": { "fields": [{ "name": "", "id": "", "visibility": true }] } } } } } }
            store = undefined
            store = testStore({})
            moxios.install();
            setUp({})
            rootComponent.update()
            mockServiceResponse(RESPONSE_CONFIG_PROFILE, 200)
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_PROFILE))
                .then(() => {
                    rootComponent.update()
                    let newState = store.getState()
                    expect(newState.configurationReducer.profile).toBe(RESPONSE_CONFIG_PROFILE.object)
                })
        });

        afterEach(() => {
            moxios.uninstall()
        })

        test('Click tabs', () => {
            const update_profile_tab = findByTestAttr(rootComponent, "update-profile-tab")
            update_profile_tab.simulate('click')
            rootComponent.update()

            const security_tab = findByTestAttr(rootComponent, "security-tab")
            security_tab.prop('onClick')()
            rootComponent.update()

            const preference_tab = findByTestAttr(rootComponent, "preference-tab")
            preference_tab.prop('onClick')()
            rootComponent.update()
        })
    })
})