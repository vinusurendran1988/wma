import React, { Component } from 'react'
import PropTypes from 'prop-types';
import { withTranslation } from 'react-i18next';
import { withSuspense, toTitleCase } from '../../common/utils';
import { connect } from 'react-redux';
import { doPost } from '../../common/utils/api';
import { _URL_ADD_PROFILE_PICTURE, _IMAGE_BASEURL } from '../../common/config/config';
import { fetchProfileImage, fetchConfiguration } from '../../common/middleware/redux/commonAction';
import {
    getItemFromBrowserStorage,
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO
} from '../../common/utils/storage.utils';
import { CONFIG_SECTION_SIMULATE_RULE } from '../../common/utils/Constants';
import { JSONPath } from 'jsonpath-plus';
import { getProfileCompleteness, PROFILE_COMPLETENESS_PERCENTAGE } from './actions'
import { PROFILE_COMPLETENESS_KEY } from './Constants';

class ProfileHeader extends Component {
    constructor() {
        super();
        this.state = {
            currentTierName: "",
            nextTierName: "",
            nextTierTargetMiles: null,
            nextTiertargetSegments: null,
            currentSkypassMiles: 0,
            qualifyingSegment: 0,
            milesNeededToQualify: 0,
            segmentsNeededToQualify: 0,
            qualifyingMilesProgressPercentage: "0%",
            qualifyingSegmentProgressPercentage: "0%"
        }
        this.filechooser = React.createRef();
    }
    componentDidMount() {
        if (!this.props.profileImage) {
            const profileImageRequest = {
                object: {
                    companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                    programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                    membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)
                }
            }
            this.props.fetchProfileImage(profileImageRequest)
        }

        if (!this.props.simulateRuleConfig) {
            this.props.fetchConfiguration(CONFIG_SECTION_SIMULATE_RULE)
        } else {
            this.setProfilePercentageCompletion()
        }
    }
    componentDidUpdate(prevProps) {
        if (prevProps.profileData != this.props.profileData
            || prevProps.simulateRuleConfig != this.props.simulateRuleConfig
            || prevProps.showProfileCompletion != this.props.showProfileCompletion) {
            this.setProfilePercentageCompletion()
        }
    }

    /**
     * @author Somdas M
     * Method to invoke the api to retrieve the profile completion percentage
     * The simulate configuration contains the executionItems which contains the variables that represents each field
     * in the profile screen. Out of these fields available, the request is created with the ones whose value is
     * not empty/ non null.
     */
    setProfilePercentageCompletion = () => {
        const { profileData, simulateRuleConfig, showProfileCompletion } = this.props

        if (showProfileCompletion && profileData && simulateRuleConfig
            && Object.keys(profileData).length > 0 && Object.keys(simulateRuleConfig).length > 0) {
            const simulateRuleObject = simulateRuleConfig.ruleTypes.find(e => e.key == PROFILE_COMPLETENESS_KEY)
            if (simulateRuleObject && simulateRuleObject.executionItems) {
                let executionItems = []
                simulateRuleObject.executionItems.map(executionItem => {
                    if (executionItem.variables) {
                        executionItem.variables.map(variable => {
                            const { uiPath } = variable
                            if (uiPath && uiPath.trim() != "") {
                                const variableValue = JSONPath({ path: uiPath, json: profileData })
                                if (variableValue && variableValue.length != 0 && variableValue[0] != "") {
                                    const newVariable = { ...variable }
                                    newVariable.value = variableValue[0]
                                    executionItems.push(newVariable)
                                }
                            }
                        })
                    }
                    // const { value } = item
                })
                const payload = {
                    "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                    "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                    "membershipNumber": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                    "ruleType": simulateRuleObject.ruleType,
                    "executionItems": [{
                        "variables": executionItems
                    }]
                }

                this.props.getProfileCompleteness({ object: payload })
            }
        }
    }
    updateProfilePic(event) {
        const files = event.target.files;
        if (files && files.length && ['image/jpeg', 'image/png'].includes(files[0].type)) {
            const formData = new FormData();
            formData.append('companyCode', getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE));
            formData.append('programCode', getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE));
            formData.append('membershipNumber', getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO));
            formData.append('profileImgType', 'jpg');
            formData.append('profileImgData', files[0]);
            doPost(_URL_ADD_PROFILE_PICTURE, formData, {
                'Content-type': 'multipart/form-data'
            })
                .then(response => {
                    const profileImageRequest = {
                        object: {
                            companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                            programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                            membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                        }
                    }
                    this.props.fetchProfileImage(profileImageRequest)
                }).catch(error => {
                    console.log(error)
                    if (this.props.imgError) {
                        this.props.imgError([error.response.data.message])
                    }
                }
                );
        }
    }
    updateProfilePic(event) {
        const files = event.target.files;
        if (files && files.length && ['image/jpeg', 'image/png'].includes(files[0].type)) {
            const formData = new FormData();
            formData.append('companyCode', getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE));
            formData.append('programCode', getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE));
            formData.append('membershipNumber', getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO));
            formData.append('profileImgType', 'jpg');
            formData.append('profileImgData', files[0]);
            doPost(_URL_ADD_PROFILE_PICTURE, formData, {
                'Content-type': 'multipart/form-data'
            })
                .then(response => {
                    const profileImageRequest = {
                        object: {
                            companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                            programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                            membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                        }
                    }
                    this.props.fetchProfileImage(profileImageRequest)
                }).catch(error => {
                    console.log(error)
                    if (this.props.imgError) {
                        this.props.imgError([error.response.data.message])
                    }
                }
                );
        }
    }

    render() {
        let { title, descriptionRequred, profileImageData, t, showProfileCompletion, completed, showProfieImageEditBtn } = this.props;
        return (
            <div className="card mb-3 profile__progress">
                <div className="card-body">
                    <div className="d-flex justify-content-start ">
                        <div className="profile__progress--img">
                            <input ref={this.filechooser} id="profile-pic-inp" style={{ display: 'none' }} type="file" onChange={event => this.updateProfilePic(event)} />
                            <img src={
                                profileImageData
                                    ?
                                    "data:image/" +
                                    profileImageData.profileImgType +
                                    ";" +
                                    profileImageData.profileImgEncoder +
                                    "," +
                                    profileImageData.profileImgData
                                    :
                                    `${_IMAGE_BASEURL}/default-profile-picture.png`
                            } alt="Profile Photo" />
                            {showProfieImageEditBtn &&
                                <a style={{ cursor: 'pointer' }} onClick={() => { this.filechooser.current.click() }}>
                                    <i className="fa fa-pencil" aria-hidden="true" ></i>
                                </a>
                            }
                        </div>
                        <div className="profile__progress--name flex-grow-1 d-flex justify-content-between">
                            <div className="align-self-center h2">{title}</div>
                            {descriptionRequred &&
                                <div className="align-self-center">{t('profile.tierProgress.complete_your_profile_and_earn')}
                                    {/* <div className="h5 text-center">1000 {t('profile.tierProgress.miles')}</div> */}
                                </div>
                            }
                        </div>
                    </div>
                </div>
                {
                    showProfileCompletion &&
                    <div className="profile__progress--bar" style={{ "width": `${completed}%` }}><span>{t('profile.tierProgress.profile')} {completed}%</span></div>
                }
            </div>

        )
    }
}

ProfileHeader.propTypes = {
    title: PropTypes.string,
    isProfile: PropTypes.bool
};

ProfileHeader.defaultProps = {
    title: "-",
    isProfile: false,
    profileImageData: null
}

function mapStateToProps(state) {
    return {
        accountSummary: state.accountSummaryReducer.accountSummary,
        simulateRuleConfig: state.configurationReducer[CONFIG_SECTION_SIMULATE_RULE],
        completed: state.profileCompletenessPercentageReducer.completed
    }
}

const mapDispatchToProps = {
    fetchProfileImage,
    fetchConfiguration,
    getProfileCompleteness
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(ProfileHeader)));