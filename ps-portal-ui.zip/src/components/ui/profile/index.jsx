import React from 'react';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { withSuspense, toTitleCase, getCurrentPageUri } from '../../common/utils';
import { fetchProfileData } from '../updateprofile/actions';
import { TAB_UPDATEPROFILE, TAB_PREFERENCE, TAB_SECURITY, TAB_UPDATE_CUSTOMER_PROFILE, TAB_UPDATE_COMPANY_PROFILE, TAB_PRIVACY, TAB_MODIFY_USER_DETAILS } from './Constants';
import { PROGRAM_TYPE_INDIVIDUAL, PROGRAM_TYPE_CORPORATE, CONFIG_SECTION_PROFILE } from '../../common/utils/Constants';
import { setError, fetchCustomerProfileData } from '../../common/middleware/redux/commonAction';
import SecurityComponent from '../security';
import Preferences from '../preferences/index'
import UpdateProfile from '../updateprofile/index';
import { getItemFromBrowserStorage, BROWSER_STORAGE_KEY_PROGRAM_TYPE } from '../../common/utils/storage.utils';
import CustomerProfile from '../customerProfile';
import { findValueFromObjectByPath } from '../../common/utils/object.utils'
import { havePrivilege, CONTEXT_TAB } from '../../common/privileges';
import _403 from '../errors/403';
import _404 from '../errors/404';
import PrivacyComponent from '../privacy';
import ProfileHeader from './ProfileHeader';
import ModifyUserDetails from '../modifyuserdetails';

/**
 * @author Ajmal Aliyar
 * Component to render Profile page and its corresponding tabs
 */
class Profile extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
        }
    }

    componentDidMount() {
        this.props.setPageInfo(this.props, { config: this.props.config, confSection: CONFIG_SECTION_PROFILE })
        // const programCodeInBrowser = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE)
        const porgramType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE)

        //FixMe: Check the programCode for both the member and corporate profile data.
        if (!this.props.profileData || Object.keys(this.props.profileData).length == 0) {
            this.props.fetchProfileData();
        }

        if (porgramType == PROGRAM_TYPE_CORPORATE &&
            (!this.props.customerProfileData ||
                Object.keys(this.props.customerProfileData).length == 0)) {
            this.props.fetchCustomerProfileData();
        }
        const { tabs } = this.props
        if (tabs && tabs.length && !this.state.currentTab) {
            this.setState({ currentTab: tabs[0] })
        }
    }

    componentDidUpdate(prevProps, prevState) {
        const { tabs } = this.props
        if (tabs && tabs.length && !this.state.currentTab) {
            this.setState({ currentTab: tabs[0] })
        }
    }

    renderSelectedTab(tab) {
        if (tab) {
            const porgramType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE)
            const { profileData, customerProfileData, userPrivileges, accountSummary, corporateNominees } = this.props
            const userData = porgramType === PROGRAM_TYPE_CORPORATE ? corporateNominees : accountSummary
            if (userPrivileges && userData) {
                const privilegeCheckData = havePrivilege(
                    { "url": getCurrentPageUri(), "tab": tab },
                    userData,
                    CONTEXT_TAB,
                    userPrivileges)

                if (privilegeCheckData.canDisplay) {

                    switch (tab) {
                        case TAB_UPDATE_CUSTOMER_PROFILE:
                            return customerProfileData && Object.keys(customerProfileData).length > 0 ? <CustomerProfile privilegeCheckData={privilegeCheckData} setPageInfo={this.props.setPageInfo} isProtected={this.props.isProtected} /> : <div></div>
                        case TAB_UPDATE_COMPANY_PROFILE:
                        case TAB_UPDATEPROFILE:
                            return profileData && Object.keys(profileData).length > 0 ? <UpdateProfile privilegeCheckData={privilegeCheckData} isProfileComplete={true} setPageInfo={this.props.setPageInfo} isProtected={this.props.isProtected} /> : <div></div>
                        case TAB_PREFERENCE:
                            return <Preferences privilegeCheckData={privilegeCheckData} setPageInfo={this.props.setPageInfo} isProtected={this.props.isProtected} />
                        case TAB_SECURITY:
                            return <SecurityComponent privilegeCheckData={privilegeCheckData} setPageInfo={this.props.setPageInfo} isProtected={this.props.isProtected} />
                        case TAB_PRIVACY:
                            return <PrivacyComponent setPageInfo={this.props.setPageInfo} isProtected={this.props.isProtected} />
                        case TAB_MODIFY_USER_DETAILS:
                            return <ModifyUserDetails privilegeCheckData={privilegeCheckData} setPageInfo={this.props.setPageInfo} isProtected={this.props.isProtected} />

                            default:
                            return <_404 />
                    }
                } else {
                    return <_403 />
                }
            }
        }
    }

    render() {
        const { profileData, t, profileImage, tabs, displayName, showProfileCompletion, accountSummary,config } = this.props;
        const programType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE)
        const { currentTab } = this.state;
        //const title = displayName ? toTitleCase(findValueFromObjectByPath(profileData, displayName, "")) : ""//`${getValue(profileData, fieldMapping.givenName)} ${getValue(profileData, fieldMapping.familyName)}`;
        let title = "";
        if (programType === PROGRAM_TYPE_CORPORATE) {
            title = profileData ? profileData.object.memberAccount.memberProfile.corporateInfo.companyName : "";
        } else if (programType === PROGRAM_TYPE_INDIVIDUAL) {
            title = accountSummary ? toTitleCase(accountSummary.givenName) + " " + toTitleCase(accountSummary.familyName) : ""
        }


        return (
            <div className={`col-lg-${programType === PROGRAM_TYPE_INDIVIDUAL ? "12" : "12"}`} data-test="ProfileComponent">
                <h1>{t(programType == PROGRAM_TYPE_CORPORATE?'profile.corporateHeader':'profile.updateProfile')}</h1>
                <p>{t(programType == PROGRAM_TYPE_CORPORATE?'profile.corporateDescription':'')}</p>
                <ProfileHeader
                    title={title}
                    isProfile={true}
                    showProfileCompletion={showProfileCompletion}
                    profileImageData={profileImage}
                    imgError={(e) => this.props.setError(e)}
                    profileData={profileData}
                    descriptionRequred={programType === PROGRAM_TYPE_INDIVIDUAL ? true : false}
                    showProfieImageEditBtn={config?config.ui.showProfieImageEditBtn:false}
                />
                {programType != PROGRAM_TYPE_CORPORATE &&
                    <nav className="tab">
                        <div className="nav nav-tabs nav-tabs--booking nav-tabs--profile" id="myTab" role="tablist">
                            {
                                tabs &&
                                    tabs.length ?
                                    tabs.map((tab, index) => {
                                        return <a className={`nav-item nav-link ${(tab == currentTab) ? 'active' : ''}`}
                                            id={`${tab}-tab`} data-toggle="tab"
                                            href={`#${tab}`} role="tab"
                                            aria-controls="home"
                                            key={index}
                                            aria-selected={(tab == currentTab) ? "true" : "false"}
                                            onClick={() => {
                                                this.setState({
                                                    currentTab: tab
                                                })
                                            }}
                                            data-test={`${tab}-tab`}
                                        >{t(`profile.tabname.${tab}`)}</a>
                                    })
                                    : <div></div>
                            }
                        </div>
                    </nav>
                }
                <div className="tab-content" id="myTabContent">
                    <div className="tab-pane fade show active"
                        id={currentTab}
                        role="tabpanel"
                        aria-labelledby={`${currentTab}-tab`}>
                        {
                            this.renderSelectedTab(currentTab)
                        }
                    </div>
                </div>
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
        profileData: state.profileDataReducer.profileData,
        profileImage: state.profileImageReducer.profileImage,
        tabs: findValueFromObjectByPath(state, 'configurationReducer.profile.ui.tabs', []),
        displayName: findValueFromObjectByPath(state, 'configurationReducer.profile.ui.layout.displayName', ""),
        showProfileCompletion: findValueFromObjectByPath(state, 'configurationReducer.profile.ui.showProfileCompletion', ""),
        customerProfileData: state.fetchCustomerProfileReducer,
        accountSummary: state.accountSummaryReducer.accountSummary,
        userPrivileges: state.privilegesReducer.privileges,
        corporateNominees: state.retriveAccountNomineeReducer.corporateNominees,
        config: state.configurationReducer[CONFIG_SECTION_PROFILE]
    }
}

const mapDispatchToProps = dispatch => {
    return {
        fetchProfileData: params => dispatch(fetchProfileData()),
        setError: messageArray => dispatch(setError(messageArray)),
        fetchCustomerProfileData: params => dispatch(fetchCustomerProfileData(params))
    }
}

Profile.defaultProps = {
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(Profile)));