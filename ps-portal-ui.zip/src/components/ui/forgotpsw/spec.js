import React, { Suspense } from 'react';
import ForgotPassword from './index';
import { findByTestAttr, findComponent, mockServiceResponse } from '../../common/testUtils';
import { testStore } from '../../common/utils';
import moxios from 'moxios';
import { mount, shallow } from 'enzyme';
import ReactTestUtils from 'react-dom/test-utils';
import {
    fetchConfiguration
} from '../../common/middleware/redux/commonAction'
import {
    CONFIG_SECTION_FORGOTPSW
} from '../../common/utils/Constants';
import { forgotPasswordLink } from './actions';
import { _URL_FORGOT_PSW_LINK } from '../../common/config/config';



let store = testStore({})
let rootComponent;
let component;

const setUp = (props = {}) => {
    rootComponent = mount(<ForgotPassword {...props} store={store} />);
    component = findComponent(rootComponent, 'ForgotPassword');
};

describe('login Component', () => {

    beforeEach(() => {
        setUp({});
        component.setState({
            email: "",
            memNo: "",
            isEmpty: false,
            success: false,
            match: true,
            isValid: true
        });
        moxios.install();
        window.sessionStorage.setItem('companyCode', 'IBS')
        window.sessionStorage.setItem('programCode', 'PRG14')
        window.localStorage.setItem('membershipNumber', 'IM0008010415')
    });

    afterEach(() => {
        moxios.uninstall();
    });

    it('forgotPsw: Fetch configuration for forgot password and render without errors', () => {
        mockServiceResponse(CONFIG_RESPONSE)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_FORGOTPSW))
                .then(() => {
                    const newState = store.getState();
                    expect(newState.configurationReducer.forgotpsw).toStrictEqual(CONFIG_RESPONSE.object);
                    const forgotPswComponent = findByTestAttr(component, 'forgotPswComponent');
                    expect(forgotPswComponent.length).toBe(1);
                    component.setState({
                        email: "abc@gmail.com",
                        memNo: "ABCD",
                    });

                    component.setState({
                        email: " ",
                        memNo: " ",
                    });
                    rootComponent = rootComponent.update()
                    component = findComponent(rootComponent, 'ForgotPassword');
                    const buttonSubmitWithEmpty = findByTestAttr(component, 'buttonSubmit')
                    expect(buttonSubmitWithEmpty.length).toBe(1);
                    buttonSubmitWithEmpty.simulate('click');


                    rootComponent = rootComponent.update()
                    component = findComponent(rootComponent, 'ForgotPassword');
                    const handlehange = findByTestAttr(component, 'memNo')
                    expect(handlehange.length).toBe(1);
                    handlehange.simulate('change');

                    rootComponent = rootComponent.update()
                    component = findComponent(rootComponent, 'ForgotPassword');
                    const handlehangeemail = findByTestAttr(component, 'email')
                    expect(handlehangeemail.length).toBe(1);
                    handlehangeemail.simulate('change');

                    rootComponent = rootComponent.update()
                    component = findComponent(rootComponent, 'ForgotPassword');
                    const buttonSubmit = findByTestAttr(component, 'buttonSubmit')
                    expect(buttonSubmit.length).toBe(1);
                    buttonSubmit.simulate('click');
                    mockServiceResponse(constForgotResponse);
                    return ReactTestUtils.act(() => {
                        return store.dispatch(forgotPasswordLink(forgotPswData))
                            .then(() => {
                            });
                        });
                });
        });
    });

});

const CONFIG_RESPONSE = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "section": "forgotpsw", "companyCode": "IBS", "programCode": "PRG14", "ui": { "layout": { "order": ["forgotPswCard"], "elements": { "forgotPswCard": { "fields": [{ "name": "memNo", "id": "id-membership-number", "visibility": true, "isRequired": true }, { "name": "email", "id": "id-email", "visibility": true, "isRequired": true, "validation": { "pattern": "\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$", "customMessageId": "forgotpsw.message.enter-valid-email_address" } }] } } } } } };
const forgotPswData = {
    "object": {
        "companyCode": "IBS",
        "programCode": "PRG14",
        "membershipNumber": "IM0008010421",
        "emailId": "abin123@gmail.com"
    }
};

const constForgotResponse = {
    "statuscode": "200",
    "statusMessage": "SUCCESS",
    "object": {
        "membershipNumber": "IM0008010421"
    }
};