import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { withSuspense, isPatternMatch } from '../../common/utils';
import { forgotPasswordLink } from './actions';
import { connect } from 'react-redux';
import { fetchConfiguration, logOut } from '../../common/middleware/redux/commonAction';
import { CONFIG_SECTION_FORGOTPSW } from '../../common/utils/Constants';
import {
  getItemFromBrowserStorage,
  BROWSER_STORAGE_KEY_COMPANY_CODE,
  BROWSER_STORAGE_KEY_PROGRAM_CODE
} from '../../common/utils/storage.utils';
import {
  getApiErrorMessage
} from '../../common/utils';
import CustomMessage from '../../common/components/custommessage';
import { FORGOT_PASSWORD_BTN } from './Constant';
import Button from '../../common/components/fieldbank/Button';

class ForgotPassword extends Component {
  constructor(props) {
    super(props);
    this.resetLink = this.resetLink.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.state = {
      customMessageType: "",
      customMessages: [],
      canTranslate: true,
      isSuccess: false,
      memNo: "",
      email: ""
    }
  }

  handleChange(value, fieldName) {
    let { customMessages, customMessageType } = this.state
    if (customMessages.length > 0) {
      customMessages = []
      customMessageType = ""
    }

    this.setState({
      memNo: fieldName == 'memNo' ? value : null,
      email: fieldName == 'email' ? value : null,
      customMessages,
      customMessageType
    })

  }

  resetLink() {
    this.setState({
      customMessages: [],
      customMessageType: "",
      canTranslate: true
    }, () => {
      const { configuration } = this.props;
      const { fields } = configuration ? configuration.ui.layout.elements.forgotPswCard : '';
      if (fields) {
        let customMessages = []
        let customMessageType = ""
        let { canTranslate } = this.state

        if(!this.state.memNo && !this.state.email){
          customMessages.push('forgotpsw.message.enter-email-memNo')
          customMessageType = "danger"
          canTranslate = true
          this.setState({
            customMessages,
            customMessageType,
            canTranslate
          })
        } else {
          fields.forEach((field) => {
            if (field.visibility && field.validations) {
              field.validations.map((validation) => {
                if (this.state[field.name]) {
                  if (!isPatternMatch(validation.pattern, this.state[field.name])) {
                    customMessages.push(validation.customMessageId)
                    customMessageType = "danger"
                    canTranslate = true
                  }
                }
              })
              this.setState({
                customMessages,
                customMessageType,
                canTranslate
              })

            }
          })
        }
        if (customMessages.length == 0) {
          let payload = {
            "object": {
              "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
              "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE)
            }
          };
          if (this.state.memNo) {
            payload.object["membershipNumber"] = this.state.memNo
          }
          else if (this.state.email) {
            payload.object["emailId"] = this.state.email
          }
          this.props.forgotPasswordLink(payload, FORGOT_PASSWORD_BTN);
        }
      }
    })

  }

  componentDidMount() {
    this.props.setPageInfo(this.props, {config: this.props.configuration, confSection: CONFIG_SECTION_FORGOTPSW})
  }

  componentDidUpdate(prevProps) {
    if (JSON.stringify(prevProps.forgotpsw) !== JSON.stringify(this.props.forgotpsw)) {
      let data = this.props.forgotpsw;
      if (this.props.forgotpsw.statusMessage == "SUCCESS") {
        this.setState({
          customMessages: ["forgotpsw.message.success"],
          customMessageType: "success",
          canTranslate: true,
          isSuccess: true
        });
      }
      else {
        if (data.error) {
          this.setState({
            customMessages: getApiErrorMessage(data.error),
            customMessageType: "danger",
            canTranslate: false
          });
        }
      }
    }
  }

  render() {
    const { t } = this.props;
    const { configuration } = this.props;
    const { fields } = configuration ? configuration.ui.layout.elements.forgotPswCard : '';
    const { customMessageType, customMessages, canTranslate } = this.state
    return (
      <div className="password password--forget">
        {this.state.isSuccess ? (
          <div className="success-bar">
            <h1>{t('resetPsw.message.redirect_msg1')}</h1>
            <p className="success-desc">{t('resetPsw.message.redirect_msg2')}</p>
          </div>
        ) : (
          <div>
            <h1>{t('forgotpsw.title')}</h1>
            <p>{t('forgotpsw.description')}</p>
            {!this.state.isSuccess &&
              <CustomMessage type={customMessageType} message={customMessages} canTranslate={canTranslate} />
            }
            {fields ?
              <>
                {fields.map((field) => {
                  if (field.visibility) {
                    return {
                      "email": <><label className="label">{t('form.emailAddress.label')}</label>
                        <div className="txt-wrap" id={field.id}>
                          <input type="text" className="txt" value={this.state[field.name] ? this.state[field.name] : ""} onChange={(e) => this.handleChange(e.target.value, field.name)} />
                        </div></>,
                      "or": <span className="option" id={field.id}>or</span>,
                      "memNo": <><label className="label">{t('form.membershipNumber.label')}</label>
                        <div className="txt-wrap">
                          <input type="text" className="txt" id={field.id} value={this.state[field.name] ? this.state[field.name] : ""} onChange={(e) => this.handleChange(e.target.value, field.name)} />
                        </div>
                      </>,
                      "resetbtn": <div className="btn-wrap">
                        <Button
                          className="btn btn-primary btn-lg"
                          type="submit"
                          handleOnClick={() => this.resetLink()}
                          id={FORGOT_PASSWORD_BTN}
                          label={t('forgotpsw.continue')} />
                      </div>
                    }[field.name] || <div></div>
                  }
                })}
              </>
              : ''
            }
          </div>)}
      </div>
    );
  }
}
function mapStateToProps(state) {
  return {
    forgotpsw: state.forgotpsw.forgotPassword,
    configuration: state.configurationReducer[CONFIG_SECTION_FORGOTPSW]
  }
}
const mapDispatchToProps = {
  forgotPasswordLink,
  fetchConfiguration,
  logOut
}


export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(ForgotPassword)));
