import React from 'react';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { withSuspense, getCurrentDate, getRelativeDate, getLink, numberWithCommas, } from '../../common/utils';
import {
    fetchConfiguration
} from '../../common/middleware/redux/commonAction';
import { CONFIG_SECTION_ACTIVITYDETAILS, DD_MM_YYYY_HH_MM_SS } from '../../common/utils/Constants';
import {
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    getItemFromBrowserStorage
} from '../../common/utils/storage.utils';
import { fetchActivityDetails } from './actions'
import { actionRetrieveActivityDetails } from '../myactivity/actions'
import { NAVIGATE_MEMBER_MYACTIVITY } from '../../common/utils/urlConstants';
import { _IMAGE_BASEURL } from '../../common/config/config';

class RecentActivity extends React.Component {
    constructor(props) {
        super(props);
    }
    componentDidMount() {
        if (!this.props.config) this.props.fetchConfiguration(CONFIG_SECTION_ACTIVITYDETAILS);
    }
    componentDidUpdate(prevProps) {
        if (this.props.activityDetailsConfig && this.props.activityDetail == undefined) {
            this.callRetrieveActivitiesApi(this.props.activityDetailsConfig)
        }
    }
    callRetrieveActivitiesApi(activityDetailsConfig) {
        const {
            activityStatus,
            activityCode,
            openingBalanceRequired,
            activityAttributesRequired,
            sortOrder,
            preferredLanguageCode,
            dateTypeIdentifier,
            ui
        } = activityDetailsConfig

        const {
            defaultPageNumber,
            defaultAbsoluteIndex,
            defaultPageSize,
            defaultNumberOfDaysToDisplay
        } = ui

        const currentIndexListArrayPosition = 0
        const transactionId = "_"
        const indexList = [defaultAbsoluteIndex]
        const toDate = getCurrentDate(DD_MM_YYYY_HH_MM_SS)
        const fromDate = getRelativeDate(toDate, -defaultNumberOfDaysToDisplay, DD_MM_YYYY_HH_MM_SS)
        const companyCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE)
        const programCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE)
        const membershipNumber = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)
        const object = {
            companyCode,
            programCode,
            membershipNumber,
            transactionId,
            activityStatus,
            activityCode,
            openingBalanceRequired,
            activityAttributesRequired,
            fromDate,
            toDate,
            sortOrder,
            preferredLanguageCode,
            dateTypeIdentifier,
            pageNumber: defaultPageNumber,
            absoluteIndex: indexList[currentIndexListArrayPosition],
            pageSize: defaultPageSize
        }
        this.props.fetchActivityDetails({ object });
    }

    handleExpandPointDetailsClick = (e) => {
        $(e.target.parentNode).children('.toggle-items').animate({width: 'toggle'}).css('display', 'flex');	
		$(e.target).toggleClass('active');
    }

    renderFirstPointBlock = (point, idx) => {
        return <div class="right-items" id={`right-items-${idx}`}>
            <span class="head">{point.pointDetails}</span>
            <span class={`type ${point.points < 0 ? "negative" : ""}`}>{numberWithCommas(point.points)}</span>
        </div>
    }

    renderMultiplePoints = (pointDetails, idx) => {
        return <>
            {
                this.renderFirstPointBlock(pointDetails[0])
            }
            <div class="activitylist__toggle">
                <div id={`activitylist-points-${idx}`} class="toggle-items" style={{ display: "none;" }}>
                    <ul>
                        {
                            pointDetails.slice(1).map((point, idx) => {
                                return <li key={`point-details-${idx}`} class="right-items item-box-primary">
                                    <span class="head">{point.pointDetails}</span>
                                    <span class={`type ${point.points < 0 ? "negative" : ""}`}>{numberWithCommas(point.points)}</span>
                                </li>

                            })
                        }
                    </ul>
                </div>
                <a onClick={this.handleExpandPointDetailsClick} class="button-toggle"></a>
            </div>
        </>
    }

    renderActivityPoints = (pointDetails, idx) => {
        if (pointDetails) {
            if (pointDetails.length == 1) {
                return this.renderFirstPointBlock(pointDetails[0], idx)
            } else if (pointDetails.length > 1) {
                return this.renderMultiplePoints(pointDetails, idx)
            }
        }
        return <div class="right-items">NA</div>
    }
    render() {
        const { activityDetail, viewLimit, viewAll, redirectUrl, t } = this.props
        return (

            <div className={`${this.props.className ? this.props.className : ""}`}>
                <div className="card">
                    <div className="widgets__title">
                        <h3>{t('recentactivities.title')}</h3>
                        {
                            viewAll && activityDetail && activityDetail.activityDetails && activityDetail.activityDetails.length &&
                            <a className="link" href={`#${NAVIGATE_MEMBER_MYACTIVITY}`}>{t('recentactivities.all')}</a>
                        }
                    </div>
                    <div className="card-body">
                        <ul className="list-group list-group-flush activitiesList">
                            {activityDetail && activityDetail.activityDetails && activityDetail.activityDetails.length ? (
                                activityDetail.activityDetails.map((act, idx) => {
                                    if (idx < viewLimit) {
                                        return (<li key={"recent-" + idx} className="d-flex justify-content-between">
                                            <div className="activitiesListLeft">
                                                <div class="activitiesListDate">{act.activityDate}</div>
                                                <div className="activitiesListName">{act.activityDescription}</div>
                                            </div>
                                            <div class="activitiesListRight">
                                                {this.renderActivityPoints(act.pointDetails, idx)}
                                            </div>
                                        </li>
                                        )
                                    }
                                })
                            ) : <div class="card-body no-content">
                                    <div class="thumb mb-3">
                                        <img src={`${_IMAGE_BASEURL}/no-content-activity.svg`} alt="no content" />
                                    </div>
                                    <span class="desc mb-3">{t('recentactivities.no_activity')}</span>
                                    <div class="btn-wrap mb-3">
                                        <button class="btn-round" onClick={() => window.location.href = getLink(redirectUrl)}>
                                            {t('dashboard.reedem_your_miles')}
                                        </button>
                                    </div>
                                </div>
                            }
                        </ul>
                    </div>
                </div>
            </div>

        )
    }
}
const mapStateToProps = (state) => {
    return {
        activityDetailsConfig: state.configurationReducer[CONFIG_SECTION_ACTIVITYDETAILS],
        activityDetail: state.recentActivityReducer.recentActivity,
    }
}
const mapDispatchToProps = {
    fetchConfiguration,
    actionRetrieveActivityDetails,
    fetchActivityDetails
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(RecentActivity)));