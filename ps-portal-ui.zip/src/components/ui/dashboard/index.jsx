import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import RecommendedPartners from './recommendedPartners';
import RecommendedBenefits from './recommendedBenefits'
import TierProgress from '../../common/components/fieldbank/TierProgress';
import UpcomingFlights from './UpcomingFlights';
import RecentActivity from './RecentActivity';
import MyFamily from './MyFamily';
import { withSuspense } from '../../common/utils';
import {
    fetchAccountSummary,
    fetchConfiguration
} from '../../common/middleware/redux/commonAction';
import { UPGRADE } from '../overview/Constants';
import SearchFlights from '../../common/components/fieldbank/SearchFlights';
import { CONFIG_SECTION_DASHBOARD } from '../../common/utils/Constants';
import ClaimWidget from './ClaimWidget';
import ReferWidget from './ReferWidget';
class Dashboard extends Component {

    constructor(props) {
        super(props);
    }
    componentDidMount() {
        this.props.setPageInfo(this.props, {config: this.props.config, confSection: CONFIG_SECTION_DASHBOARD})
    }

    renderWidgets = (sectionConfig, order, index) => {
        return <div className={sectionConfig.className ? sectionConfig.className : ""}>
            {
                sectionConfig.fields.map((fieldConfig, idx) => {
                    if (fieldConfig.visibility) {
                        return {
                            "dashboardUpcomingFlights": <UpcomingFlights className={fieldConfig.className} key={`dashboard-${order}-${index}-${fieldConfig.name}-${idx}`} viewLimit={fieldConfig.viewLimit} viewAll={fieldConfig.viewAll} redirectUrl={fieldConfig.redirectUrl}/>,
                            "dashboardRecentActivities": <RecentActivity className={fieldConfig.className} key={`dashboard-${order}-${index}-${fieldConfig.name}-${idx}`} viewLimit={fieldConfig.viewLimit} viewAll={fieldConfig.viewAll} redirectUrl={fieldConfig.redirectUrl}/>,
                            "dashboardMyFamily": <MyFamily className={fieldConfig.className} key={`dashboard-${order}-${index}-${fieldConfig.name}-${idx}`} viewLimit={fieldConfig.viewLimit} viewAll={fieldConfig.viewAll} redirectUrl={fieldConfig.redirectUrl}/>,
                            "dashboardClaimMiles": <ClaimWidget className={fieldConfig.className} key={`dashboard-${order}-${index}-${fieldConfig.name}-${idx}`} />,
                            "dashboardReferral": <ReferWidget className={fieldConfig.className} key={`dashboard-${order}-${index}-${fieldConfig.name}-${idx}`} />
                        }[fieldConfig.name] || <></>
                    } else {
                        return <></>
                    }
                })
            }
        </div>
    }

    renderDashboardBody = (order, sectionConfig, index) => {
        const { accountSummary } = this.props;
        if (sectionConfig && sectionConfig.visibility) {
            switch (order) {
                case "tierGraph": return accountSummary && accountSummary.tierOptions && accountSummary.tierOptions.find(e => e.type == UPGRADE) ? <TierProgress showTitle={sectionConfig.showTitle} className={sectionConfig.className} key={'dashboard-' + index} accountSummary={accountSummary} /> : ""
                case "flightSearch": return <SearchFlights className={sectionConfig.className} key={`dashboard-${order}-${index}`} />
                case "widget1": return <div className="widgets" key={`dashboard-${order}-${index}`}>{this.renderWidgets(sectionConfig, order, index)}</div>
                case "offers": return <RecommendedBenefits className={sectionConfig.className} accountSummary={accountSummary} key={`dashboard-${order}-${index}`} viewAll={sectionConfig.viewAll}/>
                case "promotions": return <RecommendedPartners className={sectionConfig.className} accountSummary={accountSummary} key={`dashboard-${order}-${index}`} viewAll={sectionConfig.viewAll}/>
                case "internalLinks": return this.renderWidgets(sectionConfig, order, index)
            }
        }
        return <></>
    }

    render() {
        const { config } = this.props;
        return (
            <>
                {
                    config &&
                    config.ui &&
                    config.ui.layout &&
                    config.ui.layout.order &&
                    config.ui.layout.order.map((order, index) => {
                        return this.renderDashboardBody(order, config.ui.layout.elements[order], index)
                    })
                }
            </>
        )
    }
}


const mapStateToProps = state => {
    return {
        accountSummary: state.accountSummaryReducer.accountSummary,
        config: state.configurationReducer[CONFIG_SECTION_DASHBOARD]
    }

}
const mapDispatchToProps = {
    fetchAccountSummary,
    fetchConfiguration
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(Dashboard)));
