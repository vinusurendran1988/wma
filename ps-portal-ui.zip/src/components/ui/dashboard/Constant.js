export const PAGE_TITLE = 'Dashboard';
export const FIELD_ID_TOTALMILES = "totalMiles"

