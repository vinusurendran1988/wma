import React from 'react';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { getLink, withSuspense } from '../../common/utils';
import {
    CONFIG_SECTION_MYFLIGHTS, CONFIG_SECTION_ACCOUNT_SUMMARY
} from '../../common/utils/Constants';
import { fetchConfiguration } from '../../common/middleware/redux/commonAction'
import { actionFetchFlights } from '../myflight/actions'
import { NAVIGATE_MEMBER_BOOKING, NAVIGATE_MEMBER_MYFLIGHT } from '../../common/utils/urlConstants';
import { _IMAGE_BASEURL } from '../../common/config/config';

class UpcomingFlights extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            type: "",
            uriPath: undefined,
            requestPayload: {},
            flightsListToDisplay: []
        }
    }
    componentDidMount() {
        const { myFlightsConfig } = this.props

        if (!myFlightsConfig) {
            this.props.fetchConfiguration(CONFIG_SECTION_MYFLIGHTS)
        }
        else {
            this.initializePage()
        }
        if (!this.props.accountSummaryConfig) { this.props.fetchConfiguration(CONFIG_SECTION_ACCOUNT_SUMMARY) }
    }
    componentDidUpdate(prevProps, prevState) {

        const { myFlightsConfig, responseFlightsList } = this.props
        const { uriPath } = this.state
        if (prevProps.myFlightsConfig !== myFlightsConfig) {
            this.initializePage()
        }
        if (prevState.uriPath !== uriPath) {
            this.retrieveFlights()
        }
        if (prevProps.responseFlightsList !== responseFlightsList) {
            this.updateFlightListToDisplay()
        }
    }
    initializePage() {
        const { myFlightsConfig } = this.props
        if (
            myFlightsConfig.ui &&
            myFlightsConfig.ui.filterOptions &&
            myFlightsConfig.ui.filterOptions.length
        ) {
            const value = myFlightsConfig.ui.filterOptions[0]
            this.setState({
                uriPath: value.uriPath,
                type: value.displayText
            })
        }
    }
    retrieveFlights() {
        const { myFlightsConfig } = this.props
        const { uriPath } = this.state
        const { data } = myFlightsConfig
        let { defaultAirLineCode, profileId, dateInclusive } = data
        if (uriPath) {
            const object = {
                "profileId": profileId,
                "loyaltyNumber": "",
                "origin": "",
                "destination": "",
                "airlineCode": defaultAirLineCode,
                "flightNumber": "",
                "pnrNumber": "",
                "pnrStatus": ""
            }
            // if (this.state.type == "my_flights.upcoming_flights" && dateInclusive) {
            //     object["flightStartDate"] = getCurrentDate(YYYY_MM_DD)
            //     object["flightEndDate"] = getRelativeDate(getCurrentDate(), myFlightsConfig.upcomingFlightDurationInDays, YYYY_MM_DD, DD_MMM_YYYY)
            // }
            this.setState(prevState => ({
                requestPayload: {
                    object
                }
            }), () => {
                this.props.actionFetchFlights(uriPath, this.state.requestPayload)
            })
        }
    }
    updateFlightListToDisplay() {
        const { responseFlightsList } = this.props

        let list = []
        const keys = Object.keys(responseFlightsList)
        keys.forEach((key) => {
            list.push(...responseFlightsList[key])
        })

        this.setState({
            flightsListToDisplay: list
        })
    }

    render() {
        const { flightsListToDisplay } = this.state
        const { t, viewLimit, viewAll, redirectUrl } = this.props
        return (
            <div className={`${this.props.className?this.props.className:""}`}>
                <div className="card">
                    <div className="widgets__title">
                        <h3>{t('upcomingflights.title')}</h3>
                        {
                            viewAll && flightsListToDisplay[0] && Object.keys(flightsListToDisplay[0]).length > 0 &&
                            <a className="link" href={`#${NAVIGATE_MEMBER_MYFLIGHT}`}>{t('upcomingflights.all')}</a> 
                        }
                    </div>
                    <ul className="card-body">
                        {flightsListToDisplay[0] && Object.keys(flightsListToDisplay[0]).length > 0 ? (
                            flightsListToDisplay.map((flightData, idx) => {
                                if (idx < viewLimit) {
                                    return (<li key={"up-" + idx} className="d-flex upcommingWrap">
                                        <div className="p-2"> <i> <img src={`${_IMAGE_BASEURL}/icons/icon-flight.svg`} /> </i> </div>
                                        <div className="p-2 flex-grow-1">
                                            <div className="heading">
                                                {flightData.origin}
                                                <span className="devider">-</span>
                                                {flightData.destination}
                                            </div>
                                            <div className="details">
                                                {flightData.scheduledDepartureDateTime.split(' ')[0]}
                                                <span className="devider">|</span>
                                                {flightData.airlineCode}{"-"}{flightData.flightNumber}
                                                {/* <span className="devider">|</span>
                                                Economy */}
                                            </div>
                                        </div>
                                    </li>
                                    )
                                }
                            })
                        ) : <div class="card-body no-content"> 
                                <div class="thumb mb-3">
                                <img src={`${_IMAGE_BASEURL}/no-content-flight.png`} alt="no content"/>
                                </div>
                                <span class="desc mb-3">{t('upcomingflights.no_flights')}</span>
                                <div class="btn-wrap mb-3">
                                <button class="btn-round" onClick={() => window.location.href = getLink(redirectUrl)}>
                                {t('dashboard.book_a_trip')}
                                </button>
                                </div>
                            </div>
                        }
                    </ul>
                </div>
            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return {
        myFlightsConfig: state.configurationReducer[CONFIG_SECTION_MYFLIGHTS],
        responseFlightsList: state.myFlightsReducer,
        accountSummaryConfig: state.configurationReducer[CONFIG_SECTION_ACCOUNT_SUMMARY]
    }
}
const mapDispatchToProps = {
    fetchConfiguration,
    actionFetchFlights
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(UpcomingFlights)));