import React, { Suspense } from 'react';
import { findByTestAttr, findComponent, } from '../../common/testUtils/findInComponentUtil';
import { testStore } from '../../common/utils';
import moxios from 'moxios';
import { mount, shallow } from 'enzyme';
import ReactTestUtils from 'react-dom/test-utils';

jest.mock('react-i18next', () => ({
 /* this mock makes sure any components using 
    the translate HoC receive the t function as a prop */
    withTranslation: () => Component => {
        Component.defaultProps = { ...Component.defaultProps, t: () => "" };
        return Component;
    },
}));

var store = testStore({})
let rootComponent;
let component;