import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import { withSuspense } from '../../common/utils';
import { fetchRecommededPartnersDetails } from './actions';
import {
    fetchConfiguration
} from '../../common/middleware/redux/commonAction';
import {
    CONFIG_SECTION_DEFAULT,
    CONFIG_SECTION_ACCOUNT_SUMMARY
} from '../../common/utils/Constants';
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';
import {
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    getItemFromBrowserStorage
} from '../../common/utils/storage.utils';
import { Carousel } from 'primereact/carousel';
import { NAVIGATE_PARTNERS } from '../../common/utils/urlConstants';
import ApiLoader from '../../common/components/fieldbank/loader/ApiLoader';
import { _IMAGE_BASEURL } from '../../common/config/config';

/**
 * This Class is to display the Recommended Partners in the dashboard screen.
 * The details for the Recommended Partners are been fetched from the CMS API 
 * based on the loggedin user tier
 */
class RecommendedPartners extends Component {
    constructor(props) {
        super(props)
        this.state = {
            request: {}
        }
    }

    componentDidMount() {
        if (!this.props.recommendedPartnersData) {
            this.getRecommendedParnters();
        }
    }

    /**
     * Handling of updations when props or state are updated.
     * @param {*} prevProp 
     * @param {*} prevState 
     */
    componentDidUpdate(prevProp, prevState) {
        if (prevProp.defaultConfig != this.props.defaultConfig) {
            this.getRecommendedParnters();
        }
    }

    /**
     * This method is been invoked to get the recommended partners from CMS_API
     */
    getRecommendedParnters() {

        if (Object.keys(this.state.request).length == 0 && this.props.defaultConfig) {
            const { defaultConfig } = this.props;
            const currentProgram = getCurrentProgramFromDefaultConfig(defaultConfig)
            let queryData = {};
            if (currentProgram &&
                currentProgram.data &&
                currentProgram.data.cmsDetails &&
                currentProgram.data.cmsDetails.partners) {
                queryData = { ...currentProgram.data.cmsDetails.partners };
                /**
                 * Checking queryData and resource, also the tier name for the logged user
                 * Appending the tier name with the resource['tier'] in partners
                 */
                if (queryData.resource && queryData.resource.tier && this.props.accountSummary.tierName) {
                    queryData.resource['tier'] = queryData.resource.tier + "_" + this.props.accountSummary.tierName.toLocaleLowerCase()
                }
            }
            const request = {
                object: {
                    companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                    programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                    membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                    ...queryData
                }
            }
            this.setState({
                request
            }, () => {
                this.props.fetchRecommededPartnersDetails(this.state.request)
            })
        }
    }

    render() {
        const { t, recommendedPartnersData, viewAll } = this.props
        const responsiveOptions = [
            {
                breakpoint: '1024px',
                numVisible: 3,
                numScroll: 3
            },
            {
                breakpoint: '600px',
                numVisible: 2,
                numScroll: 2
            },
            {
                breakpoint: '480px',
                numVisible: 1,
                numScroll: 1
            }
        ];

        /**
         * Template to render the image and the value along with the content link
         * @param {*} item 
         */
        const getTemplate = (item) => {
            return (
                <div className="form-row">
                    <div className="col-lg-12">
                        {
                            item.metaData && item.metaData.contentLinkID ?
                                <a href={`#${NAVIGATE_PARTNERS}/` + item.metaData.contentLinkID} target="_blank">
                                    <img src={item.url} className="d-block" alt="attractions" />
                                </a> : <img src={item.url} className="d-block" alt="attractions" />
                        }
                        <div className="txtWraper">
                            <div className="txtHeading text-center">
                                {item.content.value}
                            </div>
                        </div>
                    </div>
                </div>
            )
        }
        
        if (recommendedPartnersData == undefined) {
            return <div><ApiLoader /></div>
        } else{
            return (
                <div className="partner-block mb-3">
                    <div className="title">
                        <h2>{t('dashboard.partnertitle')}</h2>
                        {
                            recommendedPartnersData && recommendedPartnersData.data && viewAll &&
                            <a href={`#${NAVIGATE_PARTNERS}`} className="link">{t('dashboard.allpartners')} <i className="icon-link"> <img src={`${_IMAGE_BASEURL}/icons/icon-rit-arw.svg`} /> </i> </a>
                        }
                    </div>
                    <div id="carouselExampleControls" className="carousel slide" data-ride="carousel">
                        <div className="carousel-inner">
                            <div className="carousel-demo attractions">
                            {recommendedPartnersData && recommendedPartnersData.data ? (
                                <Carousel value={recommendedPartnersData.data} itemTemplate={getTemplate}
                                    numVisible={4} numScroll={1} className="custom-carousel" circular
                                    responsiveOptions={responsiveOptions}
                                >
                                </Carousel>
                                ) : (<div className="text-center">{t('dashboard.noPartners')}</div>)
                            }
                            </div>
                        </div>
                    </div>
                </div>              
            )
        }
    }
}
const mapStateToProps = state => {
    return {
        accountSummary: state.accountSummaryReducer.accountSummary,
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        accountSummaryConfig: state.configurationReducer[CONFIG_SECTION_ACCOUNT_SUMMARY],
        recommendedPartnersData: state.offersPartnersReducer.recommendedPartners
    }
}
const mapDispatchToProps = {
    fetchConfiguration,
    fetchRecommededPartnersDetails
}
export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(RecommendedPartners)))