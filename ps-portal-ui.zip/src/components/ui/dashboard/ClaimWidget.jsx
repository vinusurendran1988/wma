import React from 'react';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { withSuspense } from '../../common/utils';
import { _IMAGE_BASEURL } from '../../common/config/config';

class ClaimWidget extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
        }
    }
    componentDidMount() {
    }

    render() {
        const { t } = this.props
        return (
            <div className={`${this.props.className?this.props.className:""}`}>
                <div className="card">
                    <div className="card-body">
                        <div className="title title--sub">
                            <h3>{t('claimandrefer.claimtitle')}</h3>
                        </div>
                        <div className="refer__content"> <img src={`${_IMAGE_BASEURL}/claimMailes.png`} className="float-left" alt="Claim missing miles" />
                            <p>{t('claimandrefer.claimdescription')}<a href="#/member/claimsubmit" className="link">&nbsp;{t('claimandrefer.claimnow')}<i className="icon-link"><img src={`${_IMAGE_BASEURL}/icons/icon-rit-arw.svg`} /></i></a> </p>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}


const mapStateToProps = (state) => {
    return {
    }
}
const mapDispatchToProps = {
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(ClaimWidget)));