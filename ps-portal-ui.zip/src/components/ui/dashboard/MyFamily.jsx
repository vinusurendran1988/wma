import React from 'react';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import {
    withSuspense,
    toTitleCase,
    numberWithCommas,
    getLink
} from '../../common/utils';

import {
    getFamilyMembers,
    fetchConfiguration
} from '../../common/middleware/redux/commonAction';
import {
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    getItemFromBrowserStorage
} from '../../common/utils/storage.utils';
import { CONFIG_SECTION_SUMMARY } from '../../common/utils/Constants';
import { FIELD_ID_TOTALMILES } from './Constant';
import { doPost } from '../../common/utils/api';
import { _IMAGE_BASEURL, _URL_FETCH_PROFILE_IMAGE } from '../../common/config/config';
import { NAVIGATE_FAMILY_MEMBER_ADD, NAVIGATE_FAMILY_POOLING } from '../../common/utils/urlConstants';

class MyFamily extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            profilePics: {},
            isProfileCalled: false
        }
    }
    componentDidMount() {
        if (!this.props.familyMembers || this.props.familyMembers.length == 0) {
            const object = {
                companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)
            }
            this.props.getFamilyMembers({ object });
        }
        if (!this.props.summaryConfig) this.props.fetchConfiguration(CONFIG_SECTION_SUMMARY)
        this.fetchProfilePhoto()
    }
    componentDidUpdate(prevProps) {
        this.fetchProfilePhoto()
    }
    getPoints(pointDetails, config) {
        if(config && pointDetails) {
            let pointTypes = config.fields.find(object => {
                return object.id == FIELD_ID_TOTALMILES
            }).data.pointTypes
            let totalPoints = 0
            pointDetails.forEach(p => {
                if (pointTypes.includes(p.pointType)) {
                    totalPoints += parseInt(p.points)
                }
            })
            return numberWithCommas(totalPoints)
        }
        return "0"
    }
    fetchProfilePhoto = () => {
        const { familyMembers } = this.props;
        if(!this.state.isProfileCalled && familyMembers) {
            familyMembers.map((member, idx) => {
                const requestBody = {
                    object: {
                        companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                        programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                        membershipNumber: member.membershipNumber
                    }
                }
                doPost(_URL_FETCH_PROFILE_IMAGE, requestBody)
                    .then(response => {
                        const profilePics = this.state.profilePics
                        profilePics[member.membershipNumber] = 'data:image/png;base64, ' + response.data.object.profileImgData;
                        this.setState({
                            profilePics,
                            isProfileCalled: true
                        })
                    }).catch(error => {
                        console.log(error);
                    })
            })
        }
    }

    getMyFamilyContent = (familyMembers, viewLimit, config, t) => {
        return <div className="card-body">
            <div className="dashFamilyWrap">
                <div className="d-flex align-items-center">
                    <div className="membersHeading">
                        <div>
                            {
                                familyMembers &&
                                familyMembers.map((member, idx) => {
                                    // const profilePic = this.state.profilePics[member.membershipNumber]?this.state.profilePics[member.membershipNumber]:`${_IMAGE_BASEURL}/default-profile-picture.png`
                                    return this.state.profilePics[member.membershipNumber] ? <img style={{ maxWidth: "50px", maxHeight: "50px" }} src={this.state.profilePics[member.membershipNumber]} className="img-fluid" alt={`${member.displayName} profile pic`} /> : <></>
                                    // return <img width="30px" src={profilePic} className="img-fluid" alt={`${member.displayName} profile pic`} /> 
                                })
                            }
                        </div>
                    </div>
                    <div> <a href={`#${NAVIGATE_FAMILY_MEMBER_ADD}`} className="btn-add"> <i>+</i> {t('my_family.add_new')}</a> </div>
                </div>
                <ul>
                    {familyMembers.map((member, idx) => {
                        if (idx < viewLimit) {
                            return (
                                <li key={"list-" + idx} className="family-list-item">
                                    <span key={"list-div-span1" + idx}>{toTitleCase(member.displayName)}</span>
                                    {/* <span key={"list-div-span1" + idx}>{toTitleCase(member.displayName)} <i> <img src={infoImage} /> </i> </span> */}
                                    <strong key={"list-div-strong" + idx}>{this.getPoints(member.pointDetails, config)}</strong>
                                </li>
                            )
                        }
                    })
                    }
                </ul>
            </div>
        </div>
    }

    render() {
        const { summaryConfig, viewLimit, viewAll, familyMembers, redirectUrl, t } = this.props
        let config;
        summaryConfig &&
            summaryConfig.ui &&
            summaryConfig.ui.layout &&
            summaryConfig.ui.layout.order &&
            summaryConfig.ui.layout.order.map((layout, idx) => {
                if (!config) config = summaryConfig.ui.layout.elements[layout]
            })
        return (

            <div className={`${this.props.className?this.props.className:""}`}>
                <div className="card">
                    <div className="widgets__title">
                        <h3>{t('dashboard.my_family')}</h3>
                        {
                            familyMembers && familyMembers.length > 0 && viewAll &&
                            <a className="link" href={`#${NAVIGATE_FAMILY_POOLING}`}>{t('my_family.all')}</a>
                        }
                    </div>
                    {
                        familyMembers && familyMembers.length ? this.getMyFamilyContent(familyMembers, viewLimit, config, t)
                            : <div class="card-body no-content">
                                <div class="thumb mb-3">
                                    <img src={`${_IMAGE_BASEURL}/no-content-family.svg`} alt="no content"/>
                                </div>
                                <span class="desc mb-3">{t('my_family.no_family_member')}</span>
                                <div class="btn-wrap mb-3">
                                    <button class="btn-round"
                                        onClick={() => window.location.href = getLink(redirectUrl)}>
                                        {t('dashboard.add_family_member')}
                                    </button>
                                </div>
                            </div>
                    }
                    
                </div>
            </div>

        )
    }
}
const mapStateToProps = (state) => {
    return {
        familyMembers: state.familyListReducer.members,
        summaryConfig: state.configurationReducer[CONFIG_SECTION_SUMMARY],
    }
}
const mapDispatchToProps = {
    getFamilyMembers,
    fetchConfiguration
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(MyFamily)));