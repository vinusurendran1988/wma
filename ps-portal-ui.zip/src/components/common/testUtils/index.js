import checkPropTypes from 'check-prop-types';
import moxios from 'moxios';

export const findByTestAttr = (component, attr) => {
    const wrapper = component.find(`[data-test='${attr}']`);
    return wrapper;
};

export const findComponent = (component, componentName) => {
    return component
        .find('Suspense')
        .find(`Connect(${componentName})`)
        .find(componentName);
}

export const findComponentWithoutSuspense = (component, componentName) => {
    return component
        .find(`Connect(${componentName})`)
        .find(componentName);
}

export const checkProps = (component, expectedProps) => {
    const propsErr = checkPropTypes(component.propTypes, expectedProps, 'props', component.name);
    return propsErr;
}

export const testReducer = (reducer, initialState, action) => {
    return reducer(initialState, action);
}

export const shallowRender = () =>{

}

export const mockServiceResponse = (data, statusCode=200, headers={}) => {
    try {
        moxios.wait(() => {
            const request = moxios.requests.mostRecent();
            request.respondWith({
                status: statusCode,
                response: data,
                headers
            });
        });
    } catch(error) {
        console.log("error: mockServiceResponse : ", error)
    }
}