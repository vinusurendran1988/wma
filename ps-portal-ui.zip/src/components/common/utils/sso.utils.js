import { BROWSER_STORAGE_KEY_TOKEN, BROWSER_STORAGE_KEY_REDIRECT_URL, setItemToBrowserStorage } from "./storage.utils"
import { ROUTER_CONFIG } from "../config/routing"
import { REDIRECT_TO } from "./Constants"
import { NAVIGATE_MEMBER_DASHBOARD } from "./urlConstants"
import { getCurrentPageUri } from "."

/**
 * @description Method to extract the token from the URL
 * @author Somdas M
 */
export const handleQueryParamsInURL = () =>{
    const { hash } = window.location
    if (hash && hash.includes("?")) {
        const queryParams = hash.split("?")
        queryParams.map((queryParam, idx)=>{
            if(idx>0 && queryParam && queryParam.includes("=")){
                const param = queryParam.split("=")
                if(param && param.length == 2){
                    switch(param[0]){
                        case BROWSER_STORAGE_KEY_TOKEN:
                        setItemToBrowserStorage(BROWSER_STORAGE_KEY_TOKEN, param[1]);
                        window.history.pushState({},null, queryParams[0])
                        break;
                    }
                }
            }
        })
    }
}

/**
 * @description Method to set the redirection url
 * @author Somdas M
 */
export const handlePageRedirectionURL = () => {
    const currentPage = getCurrentPageUri()
    let pageConfig = ROUTER_CONFIG.routes.find(config => config.url == currentPage)
    if (!pageConfig) {
        pageConfig = ROUTER_CONFIG.routes.find(config => config.urls && config.urls.includes(currentPage))
    }
    if (pageConfig && pageConfig.isProtected) {
        const { hash } = window.location
        let redirectionUrl = hash && hash.includes("#")?hash.split("#")[1]:''
        setItemToBrowserStorage(BROWSER_STORAGE_KEY_REDIRECT_URL, redirectionUrl);
        window.location.href = `#${ROUTER_CONFIG.default.url}?${REDIRECT_TO}=${redirectionUrl}`
    }
}

/**
 * @description Method to redirect to the redirectTo url
 * @author Somdas M
 */
export const redirectPage = () => {
    let hasRedirectionUrl = false
    if(window.location.hash.includes("?")){
        const queryParams = window.location.hash.split("?")
        let redirectionBaseUrl = '', params=''
        let foundRedirectUrl=false
        queryParams.map((queryParam, idx) => {
            if (idx > 0) {
                if (queryParam.includes(REDIRECT_TO) && queryParam.includes("=") && !foundRedirectUrl) {
                    const param = queryParam.split("=")
                    redirectionBaseUrl = param[1]?param[1]:''
                    foundRedirectUrl = true
                } else {
                    params+=queryParam
                }
            }
        })
        if (redirectionBaseUrl) {
            hasRedirectionUrl = true
            window.location = `#${redirectionBaseUrl}${params?"?"+params:""}`
        } 
    }
    if(!hasRedirectionUrl){
        window.location = `#${NAVIGATE_MEMBER_DASHBOARD}`
    }
} 