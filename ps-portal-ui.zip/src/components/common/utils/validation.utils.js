/**
 * Performs Regex validations on value and returns a result object.
 * @param {*} validations array of validation objects
 * @param {*} value value to be validated
 * @author Ajmal V Aliyar
 */
export const performValidationsOnValue = (validations, value) => {
    let response ={
        isError: false,
        errorMessages:[]
    }
    if(validations && Array.isArray(validations)){
        validations.forEach(validation => {
            if(!isPatternMatch(validation.pattern, value)){
                response.isError = true
                response.errorMessages.push(validation.customMessageId)
            }
        })
    } else {
        console.error("Validations should be array. Received instead : ", validations);
    }
    return response
}

/**
 * Returns if the value matches the Regex pattern
 * @param {string} pattern
 * @param {string} value
 * @author Somdas M
 */
export const isPatternMatch = (pattern, value)=>{
    value = value?value:""
    const regex = new RegExp(pattern)
    return regex.test(value)
}