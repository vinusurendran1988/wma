/**
 * convert period seperated {path} to array
 * @param {*} path 
 * @param {*} defaultOutput 
 * @return result as array of keys
 * @author Ajmal V Aliyar
 */
export const convertPathToArray = (path, defaultOutput = []) => {
    try {
        return path.split('.')
    } catch (error) {
        return defaultOutput
    }
}