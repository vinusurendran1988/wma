import { convertPathToArray } from "./array.utils";
import { constructJsonPath, getCurrentDate } from ".";
import { DD_MMM_YYYY } from "./Constants";
import { getCurrentProgramFromDefaultConfig } from "./configurationFiles.utils";
import { JSONPath } from "jsonpath-plus";

/**
 * Traverses the passed in {object} to find the value residing at {path}
 * @param {*} object 
 * @param {*} path 
 * @returns value found in location {path} of {object}
 * @author Ajmal V Aliyar
 */
export const findValueFromObjectByPath = (object, path, defaultValue=undefined) => {
    path = convertPathToArray(path)
    try {
        if (object) {
            path.forEach(currentPath => object = object[currentPath]);
            return object;
        } else {
            console.error("findValueFromObjectByPath -> Cannot parse object : ", object)
            return defaultValue
        }
    } catch (error) {
        return defaultValue;
    }
}

/**
 * Traverses the passed in {object} to find the value residing at {path}
 * @param {*} object 
 * @param {*} path 
 * @returns value found in location {path} of {object}
 * @author Ajmal V Aliyar
 */
export const setPathInObjectIfNotExisting = (object, path) => {
    path = convertPathToArray(path)
    try {
        if (object) {
            let exisitngObj = {...object}
            let dynamicPath = []
            path.forEach(location => {
                dynamicPath.push(location)
                if (!object[location]) {
                    object = {
                        [location]: undefined
                    }
                }
                object = object[location]
                setValueToObjectByPath(exisitngObj, dynamicPath.join("."), object)
            });
            return exisitngObj;
        } else {
            console.error("findValueFromObjectByPath -> Cannot parse object : ", object)
            return undefined
        }
    } catch (error) {
        return undefined;
    }
}

/**
 * Sets {value} to an {object} at {path}
 * @param {*} object 
 * @param {*} path 
 * @param {*} value 
 * @author Ajmal V Aliyar
 */
export const setValueToObjectByPath = (object, path = '', value = '') => {
    if (Object.keys(object).length == 0 && path) {
        constructJsonPath(path, value, object)
    }
    else {
        if (path) {
            path = convertPathToArray(path)
            if (object) {
                for (let i = 0; i < path.length - 1; i++) {
                    object = object[path[i]];
                }
                object[path[path.length - 1]] = value;
            } else {
                console.error("setValueToObjectByPath -> Cannot parse object : ", object)
            }
        } else {
            console.warn(`Path is empty!`)
        }
    }

}

/**
 * Retrieves the value from various source for additional field mapping.
 * @param {string} path 
 * @param {object} config 
 * @param {object} reqest 
 * @author Somdas M
 */
export const getValueFromPath = (path, props, defaultValue = undefined) => {
    let { config, request, state, defaultConfig } = props
    let returnValue = ""
    if(path.startsWith("object")){
        returnValue = findValueFromObjectByPath(request, path, defaultValue)
    } else if(path.startsWith("window")){
        returnValue = findValueFromObjectByPath({window}, path, defaultValue)
    } else if(path.startsWith("config")){
        returnValue = findValueFromObjectByPath({config}, path, defaultValue)
    } else if(path.startsWith("getCurrentDate")){
        returnValue = getCurrentDate(DD_MMM_YYYY)
    } else if(path.startsWith("state")){
        returnValue = findValueFromObjectByPath({state}, path, defaultValue)
    }  else if (path.startsWith("state")) {
        returnValue = findValueFromObjectByPath({ state }, path, defaultValue)
    }
    else if(path.startsWith("defaultConfig")){
        if (path.includes(".program.")) {
            defaultConfig = getCurrentProgramFromDefaultConfig(defaultConfig)
        }
        returnValue = findValueFromObjectByPath({ defaultConfig }, path)
    }
    else {
        returnValue = findValueFromObjectByPath(props, path, defaultValue)
    }
    return returnValue
}

/**
 * Retuns true if the dependentPath exists during addtional field mapping
 * @param {Array} dependentPath  
 * @author Somdas M
 */
export const isDependentExists = (dependentPath, props)=> {
    if(!dependentPath){
        return true
    }
    let tValue = ""
    dependentPath.forEach((path)=>{
        let returnValue = getValueFromPath(path, props)
        if (returnValue) {
            tValue += " " + returnValue
        }
    })
    if(tValue){
        return true
    }
    return false
}

/**
* Method to map the additional fields from the configuration to the request object
*
* @param {this} ReferenceObject
* @param {String} RequestObjectName
* @param {Object} configObject  
* 
* @author Amrutha
*/
export const doAdditionalMapping = (reference, objectName, configObject = {}) => {
    const { config } = reference.props
    let request = reference.state[objectName]
    let path = {}
    if (configObject && Object.keys(configObject).length > 0) {
        path = configObject
    }
    else if (config && config.ui && config.ui.request && config.ui.request.additionalMapping) {
        path = config.ui.request.additionalMapping
    }

    if (path) {
        path.forEach((fields) => {
            let { fromPath, toPath, dependentPath } = fields
            let value = undefined
            fromPath.forEach((path, index) => {
                if (value == undefined) value = ""
                let dataSource = {}
                if (path.startsWith("object")) {
                    dataSource = { ...request }
                }
                else if (path.startsWith("state")) {
                    dataSource = { state: { ...reference.state } }
                }
                else if (path.startsWith("props")) {
                    dataSource = { props: { ...reference.props } }
                }
                else if (path.startsWith("window")) {
                    dataSource = { ...window }
                }
                else if (path.startsWith("config")) {
                    dataSource = { config: { ...config } }
                }
                // else if(path.startsWith("getCurrentDate")){
                //     dataSource = getCurrentDate(DD_MMM_YYYY) 
                // }
                let returnValue = JSONPath({ path: path, json: dataSource })[0]
                if (returnValue && (typeof (returnValue) !== "object") && isDependentExists(dependentPath, { config, request, state: reference.state, props: reference.props })) {
                    value += (index > 0 ? " " : "") + returnValue
                }
                else if (returnValue && typeof (returnValue) == "object") {
                    value = returnValue
                }
            })
            if (value != undefined) {
                constructJsonPath(toPath, value, request)
                setValueToObjectByPath(request, toPath, value)
            }
        })
    }
}