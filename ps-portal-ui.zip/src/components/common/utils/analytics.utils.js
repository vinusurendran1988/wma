export const SELECT_MEMBERSHIP = 'SELECT_MEMBERSHIP';
export const SELECT_GUEST_CARD = 'SELECT_GUEST_CARD';
// export const SELECT_ADDON = 'SELECT_ADDON';
export const CONTINUE_CHECKOUT = 'CONTINUE_CHECKOUT';
export const CHECKOUT_EDIT_PLAN = 'EDIT_PLAN';
export const CHECKOUT_BACK_TO_SELECT = 'CHECKOUT_BACK_TO_SELECT';
export const PAYMENT_BACK_TO_BENEFITS = 'PAYMENT_BACK_TO_BENEFITS';
export const PAYMENT_UPDATE_EMAIL_ADDRESS_LINK = 'PAYMENT_UPDATE_EMAIL_ADDRESS_LINK';
export const PAYMENT_CALL_CENTRE_TEXT_LINK = 'PAYMENT_CALL_CENTRE_TEXT_LINK';
export const PAYMENT_UPDATE_ADDRESS_LINK = 'PAYMENT_UPDATE_ADDRESS_LINK';
export const PAYMENT_ADD_ADDRESS_LINK = 'PAYMENT_ADD_ADDRESS_LINK';
export const PAYMENT_VIEW_DIGITAL_CARD = 'PAYMENT_VIEW_DIGITAL_CARD';
export const PAYMENT_VIEW_KORU_PROFILE = 'PAYMENT_VIEW_KORU_PROFILE';
export const OVERVIEW_DOWNLOAD_DIGITAL_CARD = 'OVERVIEW_DOWNLOAD_DIGITAL_CARD';
export const OVERVIEW_RENEW_MEMBERSHIP = 'OVERVIEW_RENEW_MEMBERSHIP';
export const OVERVIEW_ADDON_PURCHASE= 'OVERVIEW_ADDON_PURCHASE';
export const OVERVIEW_GUESTADDON_LINK_CLICK = 'OVERVIEW_GUESTADDON_LINK_CLICK';

export const trackData = (identifier, object) => {
    switch (identifier) {
        case SELECT_MEMBERSHIP:
            selectMembershipObject(object);
            break;
        case SELECT_GUEST_CARD:
            selectGuestCardpObject(object);
            break;
        case CONTINUE_CHECKOUT:
            continueCheckoutObject(object);
            break;
        case CHECKOUT_EDIT_PLAN:
            editPlanObject();
            break;
        case CHECKOUT_BACK_TO_SELECT:
            backToSelectObject();
            break;
        case PAYMENT_BACK_TO_BENEFITS:
            backToBenefitsFromPaymentFailObject();
            break;
        case PAYMENT_UPDATE_EMAIL_ADDRESS_LINK:
            paymentUpdateEmailAddressLink(object);
            break;
        case PAYMENT_CALL_CENTRE_TEXT_LINK:
            paymentCallCentreTextLink(object);
            break;
        case PAYMENT_UPDATE_ADDRESS_LINK:
            paymentUpdateAddressLink(object);
            break;
        case PAYMENT_ADD_ADDRESS_LINK:
            paymentAddAddressLink(object);
            break;
        case PAYMENT_VIEW_DIGITAL_CARD:
            paymentViewDigitalCard(object);
            break;
        case PAYMENT_VIEW_KORU_PROFILE:
            paymentViewProfile(object);
            break;
        case OVERVIEW_DOWNLOAD_DIGITAL_CARD:
            downloadDigitalCard(object);
            break;
        case OVERVIEW_RENEW_MEMBERSHIP:
            overviewRenewMembership(object);
            break;
        case OVERVIEW_ADDON_PURCHASE:
            overviewAddonPurchase(object);
            break; 
        case OVERVIEW_GUESTADDON_LINK_CLICK:
            overviewGuestAddonMoreDetails(object);
            break;           

        default:
            console.log("Invalid identifier used");
    }
}

const selectMembershipObject = (object) => {
    try {
        let product = object[0];
        product.name = object[1];

        window.dataLayer.push({ ecommerce: null });  // Clear the previous ecommerce object.
        window.dataLayer.push({
            'event': 'trackEventEcommerce',
            'eventDetails': {
                'description': 'Impression Event for Membership',
                'category': 'ecommerce',
                'action': 'impression',
                'label': 'undefined',
                'value': 'undefined',
            },
            'ecommerce': {
                'click': {
                    'products': [product]
                }
            }
        });
    } catch(e) {
        console.log(e)
    }
}

const selectGuestCardpObject = (object) => {
    try {
        let product = object[0];
        product.name = object[1];

        window.dataLayer.push({ ecommerce: null });  // Clear the previous ecommerce object.
        window.dataLayer.push({
            'event': 'trackEventEcommerce',
            'eventDetails': {
                'description': 'Impression Event for Guest Card',
                'category': 'ecommerce',
                'action': 'impression',
                'label': 'undefined',
                'value': 'undefined',
            },
            'ecommerce': {
                'click': {
                    'products': [product]
                }
            }
        });
    } catch(e) {
        console.log(e)
    }
}

const continueCheckoutObject = (object) => {
    try {
        let product = object;

        window.dataLayer.push({ ecommerce: null });  // Clear the previous ecommerce object.
        window.dataLayer.push({
            'event': 'trackEventEcommerce',
            'eventDetails': {
                'description': 'Add to Cart Event for all products in cart',
                'category': 'ecommerce',
                'action': 'add to cart',
                'label': 'undefined',
                'value': 'undefined',
            },
            'ecommerce': {
                'add': {
                    'products': [product]
                }
            }
        });
    } catch(e) {
        console.log(e)
    }
}

const editPlanObject = () => {
    try {
        window.dataLayer.push({ ecommerce: null });  // Clear the previous ecommerce object.
        window.dataLayer.push({
            'event': 'trackEventNoEcommerce',
            'eventDetails': {
                'description': 'Edit Plan CTA',
                'category': 'cta button',
                'action': 'Edit Plan',
                'label': 'undefined',
                'value': 'undefined',
            }
        });
    } catch(e) {
        console.log(e)
    }
}

const backToSelectObject = () => {
    try {
        window.dataLayer.push({ ecommerce: null });  // Clear the previous ecommerce object.
        window.dataLayer.push({
            'event': 'trackEventNoEcommerce',
            'eventDetails': {
                'description': 'Back to select CTA',
                'category': 'cta button',
                'action': 'Back to select',
                'label': 'undefined',
                'value': 'undefined',
            }
        });
    } catch(e) {
        console.log(e)
    }
}

const backToBenefitsFromPaymentFailObject = () => {
    try {
        window.dataLayer.push({ ecommerce: null });  // Clear the previous ecommerce object.
        window.dataLayer.push({
            'event': 'trackEventNoEcommerce',
            'eventDetails': {
                'description': 'Back to benefits CTA',
                'category': 'cta button',
                'action': 'Back to benefits',
                'label': 'undefined',
                'value': 'undefined',
            }
        });
    } catch(e) {
        console.log(e)
    }
}

const paymentUpdateEmailAddressLink = (object) => {
    try {
        window.dataLayer.push({ ecommerce: null });  // Clear the previous ecommerce object.
        window.dataLayer.push({
            'event': 'trackEventNoEcommerce',
            'eventDetails': {
                'description': 'Update email address text link',
                'category': 'text link',
                'action': 'Update email address',
                'label': object[0],
                'value': 'undefined',
            },
            'eventCallback': function() {
                document.location = object[0]
            }
        });
    } catch(e) {
        console.log(e)
    }
}

const paymentCallCentreTextLink = (object) => {
    try {
        window.dataLayer.push({ ecommerce: null });  // Clear the previous ecommerce object.
        window.dataLayer.push({
            'event': 'trackEventNoEcommerce',
            'eventDetails': {
                'description': 'call centre text link',
                'category': 'text link',
                'action': 'call centre',
                'label': object[0],
                'value': 'undefined',
            },
            'eventCallback': function() {
                document.location = object[0]
            }
        });
    } catch(e) {
        console.log(e)
    }
}

const paymentUpdateAddressLink = (object) => {
    try {
        window.dataLayer.push({ ecommerce: null });  // Clear the previous ecommerce object.
        window.dataLayer.push({
            'event': 'trackEventNoEcommerce',
            'eventDetails': {
                'description': 'Click here to edit text link',
                'category': 'text link',
                'action': 'Click here to edit',
                'label': object[0],
                'value': 'undefined',
            },
            'eventCallback': function() {
                document.location = object[0]
            }
        });
    } catch(e) {
        console.log(e)
    }
}

const paymentAddAddressLink = (object) => {
    try {
        window.dataLayer.push({ ecommerce: null });  // Clear the previous ecommerce object.
        window.dataLayer.push({
            'event': 'trackEventNoEcommerce',
            'eventDetails': {
                'description': 'No delivery address added, Enter address CTA',
                'category': 'cta button',
                'action': 'Enter address',
                'label': 'undefined',
                'value': 'undefined',
            },
            'eventCallback': function() {
                document.location = object[0]
            }
        });
    } catch(e) {
        console.log(e)
    }
}

const paymentViewDigitalCard = () => {
    try {
        window.dataLayer.push({ ecommerce: null });  // Clear the previous ecommerce object.
        window.dataLayer.push({
            'event': 'trackEventNoEcommerce',
            'eventDetails': {
                'description': 'View Koru Card CTA',
                'category': 'cta button',
                'action': 'View Koru Card',
                'label': 'undefined',
                'value': 'undefined',
            }
        });
    } catch(e) {
        console.log(e)
    }
}

const paymentViewProfile = () => {
    try {
        window.dataLayer.push({ ecommerce: null });  // Clear the previous ecommerce object.
        window.dataLayer.push({
            'event': 'trackEventNoEcommerce',
            'eventDetails': {
                'description': 'Koru Membership Profile CTA',
                'category': 'cta button',
                'action': 'Koru Membership Profile',
                'label': 'undefined',
                'value': 'undefined',
            }
        });
    } catch(e) {
        console.log(e)
    }
}

const downloadDigitalCard = () => {
    try {
        window.dataLayer.push({ ecommerce: null });  // Clear the previous ecommerce object.
        window.dataLayer.push({
            'event': 'trackEventNoEcommerce',
            'eventDetails': {
                'description': 'Download Image CTA',
                'category': 'cta button',
                'action': 'Download image',
                'label': 'undefined',
                'value': 'undefined',
            }
        });
    } catch(e) {
        console.log(e)
    }
}

const overviewRenewMembership = () => {
    try {
        window.dataLayer.push({ ecommerce: null });  // Clear the previous ecommerce object.
        window.dataLayer.push({
            'event': 'trackEventNoEcommerce',
            'eventDetails': {
                'description': 'Renew membership CTA',
                'category': 'cta button',
                'action': 'Renew membership',
                'label': 'undefined',
                'value': 'undefined',
            }
        });
    } catch(e) {
        console.log(e)
    }
}

const overviewAddonPurchase = () => {
    try {
        window.dataLayer.push({ ecommerce: null });  // Clear the previous ecommerce object.
        window.dataLayer.push({
            'event': 'trackEventNoEcommerce',
            'eventDetails': {
                'description': 'Continue to purchase CTA',
                'category': 'cta button',
                'action': 'Continue to purchase',
                'label': 'undefined',
                'value': 'undefined',
            }
        });
    } catch(e) {
        console.log(e)
    }
}

const overviewGuestAddonMoreDetails = (object) => {
    try {
        window.dataLayer.push({ ecommerce: null });  // Clear the previous ecommerce object.
        window.dataLayer.push({
            'event': 'trackEventNoEcommerce',
            'eventDetails': {
                'description': 'Find out details text link',
                'category': 'text link',
                'action': 'Find out more',
                'label': object[0],
                'value': 'undefined',
            }
        });
    } catch(e) {
        console.log(e)
    }
}


