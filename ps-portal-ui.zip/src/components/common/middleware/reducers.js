import { combineReducers } from 'redux';
import {
    profileImageReducer
} from '../../ui/mileagecard/reducer';
import { mileageCalculatorReducer } from '../../ui/mileagecalculator/reducer';
import {
    authenticateTransactionReducer,
    buyPointReducer,
    buyPointAcceptReducer,
    logoutTransactionReducer,
    simulateRuleReducer,
    tierUpgradeReducer,
    giftPointsReducer
} from '../../ui/buypoints/reducer'
import login from '../../ui/login/reducer';
import { commonErrorReducer } from './redux/commonErrorReducer'
import {
    searchMember,
    transferMilesMessage
} from '../../ui/transfermiles/reducers';
import myActivityReducer from '../../ui/myactivity/reducer';
import forgotpsw from '../../ui/forgotpsw/reducer';
import { claimsubmitReducer } from '../../ui/claimsubmit/reducer';
import enrolment from '../../ui/enrolment/reducer';
import { retroClaimRequestsReducer } from '../../ui/claimsummary/reducer'
import { language, getHeaderDetailsReducer, getNotificationsReducer } from '../../ui/header/reducer';
import { getFooterDetailsReducer } from '../../ui/cmsfooter/reducer';
import {
    newFamilyMemberSearchReducer,
    addFamilyMemberReducer
} from '../../ui/addfamilymember/reducer'
import {
    profileCompletenessPercentageReducer
} from '../../ui/profile/reducer'

import {
    accountSummaryReducer,
    masterData,
    configurationReducer,
    userInfoReducer,
    logOutReducer,
    fetchCustomerProfileReducer,
    profileDataReducer,
    defaultUserProfileDataReducer,
    currentLoginUserDataReducer,
    privilegesReducer,
    qrCodeImageReducer,
    retriveAccountNomineeReducer,
    masterEntityDataReducer,
    pageReferenceReducer,
    familyListReducer,
    menuReferenceReducer,
    setTierDetailsReducer,
    validateMemberDetailReducer
} from './redux/commonReducer';
import resetpsw from '../../ui/resetpsw/reducer';
import changePsw from '../../ui/security/changepassword/reducer';
import feedback from '../../ui/feedback/reducer';
import changePinReducer from '../../ui/security/changepin/reducer';
import { preferenceUpdateReducer} from '../../ui/preferences/reducer';
import myFlightsReducer from '../../ui/myflight/reducer'
import {
    retrieveNomineesReducer,
    retrieveCustomerReducer,
    addTravellerReducer,
    addNomineeReducer,
    updateTravellerReducer,
    updateNomineeReducer,
    deleteTravellerReducer,
    deleteNomineeReducer
} from '../../ui/corporate/admin/managepeople/reducer'
import { RESET_STATE } from './redux/commonAction';
import { convertPointsReducer } from '../../ui/migratepoints/reducer'
import packagesReducer,
{
    subscriptionReducer,
    cartReducer,
    warningMessageReducer,
    membershipTypeReducer,
    currentTabReducer
} from '../../ui/subscription/reducer';
import { recentActivityReducer, offersPartnersReducer } from  '../../ui/dashboard/reducer'
import { loaderReducer } from '../components/fieldbank/loader/reducer'
import mfaReducer from '../../common/components/mfa/reducer'
import { partnersBenefitsReducer } from '../../ui/promotions/reducer'
import { activateUserReducer } from '../../ui/useractivation/reducer'
import { extendExpiryReducer,retrieveQuoteReducer,renewMilesPaymentReducer } from '../../ui/extendexpiry/reducer'
import { retrieveAccountUsersReducer,addAccountUserReducer, updateAccountUserPrivilegeReducer, deleteAccountUserReducer } from '../../ui/manageaccountusers/reducer'
import { travelCompanionReducer,retrieveTravelCompanionReducer  } from '../../ui/travelcompanion/reducer';
import { referralDataReducer } from '../../ui/referral/reducer'
import CompanyProfileReducer from '../../impl/companyProfile/reducer';
import companyRegReducer from '../../impl/corporateRegister/enrolment/reducer';
import { changeEmailReducer } from '../../ui/modifyuserdetails/reducer';
import { activateReducer } from '../../ui/useractivation/reducer';
import { deleteAccountUsersReducer, editAccountUserReducer } from '../../impl/manageaccountusers/reducer';

const appReducer = combineReducers({
    retroClaimRequestsReducer,
    menuReferenceReducer,
    userInfoReducer,
    profileImageReducer,
    profileDataReducer,
    qrCodeImageReducer,
    setTierDetailsReducer,
    validateMemberDetailReducer,
    accountSummaryReducer,
    authenticateTransactionReducer,
    buyPointReducer,
    buyPointAcceptReducer,
    logoutTransactionReducer,
    simulateRuleReducer,
    tierUpgradeReducer,
    mileageCalculatorReducer,
    searchMember,
    commonErrorReducer,
    transferMilesMessage,
    claimsubmitReducer,
    enrolment,
    newFamilyMemberSearchReducer,
    addFamilyMemberReducer,
    myActivityReducer,
    login,
    configurationReducer,
    changePinReducer,
    masterData,
    resetpsw,
    forgotpsw,
    changePsw,
    feedback,
    logOutReducer,
    preferenceUpdateReducer,
    myFlightsReducer,
    fetchCustomerProfileReducer,
    currentLoginUserDataReducer,
    privilegesReducer,
    retriveAccountNomineeReducer,
    retrieveNomineesReducer,
    addTravellerReducer,
    addNomineeReducer,
    updateTravellerReducer,
    updateNomineeReducer,
    deleteTravellerReducer,
    deleteNomineeReducer,
    retrieveCustomerReducer,
    convertPointsReducer,
    packagesReducer,
    recentActivityReducer,
    masterEntityDataReducer,
    loaderReducer,
    mfaReducer,
    pageReferenceReducer,
    language,
    getHeaderDetailsReducer,
    getFooterDetailsReducer,
    offersPartnersReducer,
    partnersBenefitsReducer,
    familyListReducer,
    activateReducer,
    getNotificationsReducer,
    extendExpiryReducer,
    retrieveQuoteReducer,
    renewMilesPaymentReducer,
    profileCompletenessPercentageReducer,
    validateMemberDetailReducer,
    retrieveAccountUsersReducer,
    validateMemberDetailReducer,
    addAccountUserReducer,
    updateAccountUserPrivilegeReducer,
    deleteAccountUserReducer,
    defaultUserProfileDataReducer,
    travelCompanionReducer,
    retrieveTravelCompanionReducer,
    referralDataReducer,
    giftPointsReducer,
    subscriptionReducer,
    cartReducer,
    warningMessageReducer,
    membershipTypeReducer,
    currentTabReducer,
    CompanyProfileReducer,
    companyRegReducer,
    changeEmailReducer,
    editAccountUserReducer,
    deleteAccountUsersReducer
});

const rootReducer = (state, action) => {
    // Clear all data in redux store to initial.
    if(action.type === RESET_STATE)
       state = undefined;

    return appReducer(state, action);
 };
 export default rootReducer;