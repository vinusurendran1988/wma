import React from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { withSuspense, getFormattedDate, isEmptyOrSpaces, getAdditionalTableClassNames, getRelativeDate, getCurrentDate } from '../../utils/';
import { withTranslation } from 'react-i18next';
import * as jsPDF from 'jspdf';
import 'jspdf-autotable'
import xlsx from 'xlsx';
import FileSaver from 'file-saver';
import { EXPORT_CSV, EXPORT_PDF, EXPORT_XLSX, YYYYMMDD, DD_MMM_YYYY, BLANK } from '../../utils/Constants';
import { Dropdown } from 'primereact/dropdown';
import { getItemFromBrowserStorage, BROWSER_STORAGE_KEY_DATE_TIME_FORMAT, BROWSER_STORAGE_KEY_DATE_FORMAT } from '../../utils/storage.utils';
import parse from 'html-react-parser';
import { MultiSelect } from 'primereact/multiselect';
import { FilterMatchMode, FilterOperator } from "primereact/api";
import { Calendar } from 'primereact/calendar';
import { DATE_FORMAT_DDMMYYYY_WITH_SPACE } from '../../../ui/subscription/Constants';


/**
 * @name Custom Table component.
 * 
 * @author Ajmal V Aliyar
 */
class Table extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            templates: props.bodyTemplates,
            updatedValue: [],
            selectedStatus: null
        }
        this.exportCSV = this.exportCSV.bind(this);
        this.exportPdf = this.exportPdf.bind(this);
    }

    defaultColumnBodyTemplate(data, props) { //to work from inside 
        let className
        const { column } = props
        if (column && column.props && column.props.config && column.props.config.additionalClassNames && column.props.config.additionalClassNames.length) {
            className = getAdditionalTableClassNames(column.props.config.additionalClassNames, data)
        }
        return (
            <React.Fragment>
                {/* <span className="p-column-title">{props.header}</span> */}
                <span className={`${className ? className + " text-break" : "text-break"}`}>{data[props.field]}</span>
            </React.Fragment>
        );
    }
    dateTemplate = (rowData, props) => {
        let className
        const { column } = props
        if (column && column.props && column.props.config && column.props.config.additionalClassNames && column.props.config.additionalClassNames.length) {
            className = getAdditionalTableClassNames(column.props.config.additionalClassNames, rowData)
        }
        if (isEmptyOrSpaces(rowData.actualDate)) {
            rowData["actualDate"] = rowData[props.field]
        }
        const _dateFormat = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_DATE_FORMAT)
        const inputDateFormat = !isEmptyOrSpaces(props.inputDateFormat) ? props.inputDateFormat : DD_MMM_YYYY
        const displayDate = getFormattedDate(rowData["actualDate"], !isEmptyOrSpaces(_dateFormat) ? _dateFormat : YYYYMMDD, inputDateFormat)
        const date = displayDate.split("-")
        rowData["displayDate"] = displayDate
        rowData[props.field] = getFormattedDate(rowData["actualDate"], YYYYMMDD, inputDateFormat)
        return <React.Fragment>
            <span className="p-column-title">{props.header}</span>
            <span className={`${className ? className + " p-column-date" : "p-column-date"}`}>
                {date[0]}<span className="devider">-</span>{date[1]}<span className="devider">-</span>{date[2]}
            </span>
        </React.Fragment>
    }

    componentDidUpdate() {
        switch (this.props.exportStr) {
            case EXPORT_PDF:
                this.exportPdf();
                break;
            case EXPORT_XLSX:
                this.exportExcel();
                break;
            case EXPORT_CSV:
                this.exportCSV();
                break;
        }

    }

    getDataKey = (col) => {
        if (col.body == "dateTemplate") {
            return "displayDate"
        }
        return col.field
    }

    exportCSV = () => {
        this.dt.exportCSV(false);
    }

    exportCSVFunction = (data) => {
        let value = data.data
        const { rowData, field, column } = data
        if ( field=="expiryDate" && value) {
            const relativeDate = getRelativeDate(getFormattedDate(getCurrentDate(), DATE_FORMAT_DDMMYYYY_WITH_SPACE), 100000)
            const formattedDate = getFormattedDate(relativeDate, DATE_FORMAT_DDMMYYYY_WITH_SPACE, "DD-MM-YYYY")
            const formattedNomineeDate = getFormattedDate(value, DATE_FORMAT_DDMMYYYY_WITH_SPACE)
            value = formattedNomineeDate != formattedDate ?
                formattedNomineeDate :
                ""
        }
        if (field=="tierStatus" && value == BLANK) {
            value = ""
        }
        if (field=="groupName" &&  value  == BLANK) {
            value = ""
        }
        return value
    }

    exportPdf() {
        const { t, downloadValues } = this.props
        let exportColumns = this.props.columns.filter(col => col.visibility === true).
            map(col => ({ title: col.headerWithoutStyle ? t(col.headerWithoutStyle) : t(col.header), dataKey: this.getDataKey(col) }))
        const doc = new jsPDF.default(0, 0);
        doc.autoTable(exportColumns, this.props.globalFilter.length > 0 ? this.state.updatedValue : downloadValues);
        doc.save(this.props.exportFileName + "_" + new Date().getTime() + ".pdf");

    }
    exportExcel() {
        const { t, downloadValues} = this.props
        let exportColumns = this.props.columns.filter(col => col.visibility === true)//.map(col => this.getDataKey(col));
        let rangeVal = exportColumns.length - 1;
        const excelSheetContent = this.props.globalFilter.length > 0 ? this.state.updatedValue : downloadValues
        excelSheetContent.map(content => {
            Object.keys(content).map(arrayContent => {
                const column = this.props.columns.find(e => e.field == arrayContent)
                if (column) {
                    let cellValue = content[arrayContent]
                    if (column.body == "dateTemplate") {
                        cellValue = content.displayDate
                    }
                    if(column.headerWithoutStyle){
                        content[parse(t(column.headerWithoutStyle))] = cellValue
                    }
                    else{
                        content[parse(t(column.header))] = cellValue

                    }
                }
            })
        })

        const header = exportColumns.map(column => {
            const { field } = column
            const currentField = this.props.columns.find(e => e.field == field)
            return currentField.headerWithoutStyle ? this.props.t(currentField.headerWithoutStyle) : this.props.t(currentField.header)
        })
        const worksheet = xlsx.utils.json_to_sheet(excelSheetContent, { header });
        const range = xlsx.utils.decode_range(worksheet['!ref']);
        range.e['c'] = rangeVal;
        worksheet['!ref'] = xlsx.utils.encode_range(range);
        const workbook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
        const excelBuffer = xlsx.write(workbook, { bookType: 'xlsx', type: 'array' });
        this.saveAsExcelFile(excelBuffer, this.props.exportFileName + "_" + new Date().getTime());

    }

    saveAsExcelFile(buffer, fileName) {

        let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
        let EXCEL_EXTENSION = '.xlsx';
        const data = new Blob([buffer], {
            type: EXCEL_TYPE
        });
        FileSaver.saveAs(data, fileName + EXCEL_EXTENSION);

    }

    applyFilter = (filterKey, filterList) => {
        const { t } = this.props
        return (
            <MultiSelect
                value={this.state[filterKey]}
                options={filterList}
                itemTemplate={this.statusItemTemplate}
                onChange={(event) => this.onApplyFilterChange(event, filterKey)}
                placeholder={t(`tableFilters.placeholder.${filterKey}`)}
                className="p-column-filter"
            />
        );
    }

    dateFilterTemplate = (options) => {
        return (
            <Calendar
                value={options.value}
                onChange={(e) => options.filterCallback(e.value, options.index)}
                // dateFormat="dd-M-yy"
                dateFormat="dd M yy"
                placeholder="Select date"
            />
        );
    }

    representativesItemTemplate(option) {
        return (
            <div className="p-multiselect-representative-option">
                <span className="image-text">{option.name}</span>
            </div>
        );
    }

    onApplyFilterChange = (event, filterKey, filterMode = "in") => {
        this.dt.filter(event.value, filterKey, filterMode);
        this.setState({ [filterKey]: event.value });
    }
    statusItemTemplate = (option) => {
        return (
            <span>
                {option == this.props.showTickIconFor ?
                    <i className="fa fa-check" style={{ color: "black" }}></i>
                    :
                    option}

            </span>
        );
    }
    render() {
        const {
            values,
            columns,
            globalFilter,
            emptyMessage,
            defaultSortFields,
            defaultSort,
            t,
            onValueChange
        } = this.props

        const dynamicColumns = (columns && columns.length)
            ? columns.map((col, index) => {
                if (col.visibility) {
                    const { templates } = this.state
                    let props = {
                        key: index,
                        header: parse(t(col.header)),
                        field: col.field,
                        actualField: col.actualField,
                        config: col,
                        partnerList: this.props.partnerList,
                    }
                    if (col.enableRenewLinkFor) {
                        props.enableRenewLinkFor = col.enableRenewLinkFor
                    }
                    if (col.enableJoinLinkFor) {
                        props.enableJoinLinkFor = col.enableJoinLinkFor
                    }
                    if (col.body && templates[col.body]) {
                        props.body = templates[col.body]
                    } else if (col.body && !templates[col.body] && this[col.body]) {
                        props.body = this[col.body]
                    } else {
                        props.body = this.defaultColumnBodyTemplate
                    }
                    if (col.sortable) {
                        props.sortable = col.sortable
                    }
                    if (col.filter && !col.dateFilter) {
                        props.filter = col.filter
                        let filterList = []
                        const { values } = this.props
                        if (col.filterList && col.filterList.length) {
                            filterList = col.filterList
                        } else if (values && values.length) {
                            values.map(value => {
                                if (!filterList.includes(value[col.field])) {
                                    let filterValue = value[col.field]
                                    filterList.push(filterValue)
                                }
                            })
                        }

                        props.filterField = col.field
                        props.showFilterMenu = true
                        props.showFilterMenuOptions = false
                        props.showFilterMatchModes = false
                        props.filterElement = this.applyFilter(col.field, filterList)
                        props.style = { minWidth: col.colWidth }
                    }
                    props.style = { minWidth: col.colWidth }
                    if (col.dateFilter) {
                        props.filterField = col.field
                        props.filter = col.filter
                        props.showFilterMenu = true
                        props.dataType = "date"
                        props.filterElement = this.dateFilterTemplate

                    }

                    return <Column className={`${col.className ? col.className : ""}`} {...props} />

                }
            })
            : [];
        const defaultSortSelected = defaultSort && defaultSort == "asc" ? 1 : -1

        return (
            <>
                <div className="datatable-responsive-demo">
                    <DataTable
                        exportFunction={this.exportCSVFunction}
                        sortField={defaultSortFields}
                        sortOrder={defaultSortSelected}
                        ref={(el) => { this.dt = el; }}
                        value={values}
                        emptyMessage={emptyMessage}
                        className="p-datatable-responsive-demo"
                        filterDisplay="menu"
                        globalFilter={globalFilter}
                        exportFilename={this.props.exportFileName + "_" + new Date().getTime()}
                        onValueChange={(e) => this.setState({
                            updatedValue: globalFilter && globalFilter.length > 0 ? e : values
                        }, () => onValueChange(e))}
                    >
                        {dynamicColumns}

                    </DataTable>
                </div>
            </>
        )
    }
}

Table.defaultProps = {
}
export default withSuspense()(withTranslation()(Table));