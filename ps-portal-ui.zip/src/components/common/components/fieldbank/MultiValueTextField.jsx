import React from 'react';
import { withTranslation } from 'react-i18next';
import { withSuspense } from '../../utils';

/**
 * @name Custom input field component.
 * @description Component that text field that can take multiple values
 * 
 * @author Geo George
 */
class MultiValueTextField extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            value: this.props.value
        }
    }

    componentDidUpdate(prevProps) {
        if ((prevProps.id !== this.props.id) || (prevProps.value != this.props.value)) {
            this.setState({ value: this.props.value })
        }
    }

    handleChange(value) {
        this.setState({ value })
        return value
    }

    render() {
        const { t, 
                label,
                id,
                isRequired,
                error,
                placeholder,
                onChange,
                isMultipleValueAllowed,
                handleKeyDown,
                name,
                itemList,
                handleDelete,
             } = this.props
        const { value } = this.state
        return (
            <div className="form-group">
                <label htmlFor={id}>{t(label)}{isRequired && <span className="text-warning">*</span>}</label>
                <input
                    className={"" + (error ? " is-invalid" : "")}
                    id={id}
                    placeholder={t(placeholder)}
                    type="text"
                    value={value?value:''}
                    onChange={(e) => onChange(this.handleChange(e.target.value))}
                    onKeyDown={isMultipleValueAllowed ? handleKeyDown : ""}
                    data-test={name}
                />
                {isMultipleValueAllowed && itemList.map(email => (
                    <div className="tag-item email-chip" key={email}>
                        {email}
                        <button
                            type="button"
                            className="close-button"
                            onClick={() => handleDelete(email)}
                            data-test="deleteBtn">
                            &times;
                        </button>
                    </div>
                ))}
            </div>
        )
    }
}

export default withSuspense()(withTranslation()(MultiValueTextField));