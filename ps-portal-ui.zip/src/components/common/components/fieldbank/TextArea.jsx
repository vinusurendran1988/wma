import React from 'react';

/**
 * @name Custom TextArea component.
 * 
 * @author Ajmal Aliyar
 */
export default class TextArea extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            value: this.props.value
        }
    }

    componentDidUpdate(prevProps) {
        if ((prevProps.id !== this.props.id) || (prevProps.value != this.props.value)) {
            this.setState({ value: this.props.value })
        }
    }

    handleChange(value) {
        this.setState({ value })
        return value
    }

    render() {
        const {
            label,
            isRequired,
            id,
            onChange,
            testIdentifier,
            info,
            enabled,
            placeholder,
            error,
            minimumCharacter,
            maximumCharacter
        } = this.props
        const { value } = this.state
        return (
            <div className="form-group">
                <label
                    htmlFor={id}
                >
                    {label}
                    {isRequired &&
                        <span className="text-warning">*</span>
                    }
                </label>
                <textarea
                    className={"" + (error ? " is-invalid" : "reftextarea")}
                    id={id}
                    placeholder={placeholder}
                    onChange={(e) => onChange(this.handleChange(e.target.value))}
                    value={value}
                    data-test={testIdentifier}
                    aria-describedby={`${id}_help`}
                    disabled={!enabled}
                    minLength={minimumCharacter?minimumCharacter:""} 
                    maxLength={maximumCharacter?maximumCharacter:""} 
                />
                <small id={`${id}_help`} className="form-text text-muted">{info}</small>
            </div>
        )
    }
}

TextArea.defaultProps = {
    label: "",
    value: "",
    isRequired: false
}