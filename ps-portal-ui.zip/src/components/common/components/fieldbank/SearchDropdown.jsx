import React, { Component } from 'react';
import { AutoComplete } from 'primereact/autocomplete';


/**
 * @name Custom DropDown component with search feature.
 * @description Component that consists of a label and an autocomplete field.
 * 
 * @author Somdas M
 */
class SearchDropdown extends Component {

    constructor (props) {
        super(props);
        this.state = {
            selectedValue: props.value,
            suggestions: null
        }
        this.suggestResult = this.suggestResult.bind(this)
        this.itemTemplate = this.itemTemplate.bind(this)
    }

    componentDidUpdate(prevProps) {
        if (prevProps.value != this.props.value) {
            this.setState({ selectedValue: this.props.value })
        }
    }

    handleChange(value) {
        let { selectedValue } = this.state
        if(value.value){
            selectedValue = value.label 
            value = value.value
        }
        this.setState({ selectedValue})
        return value
    }

    suggestResult(event) {
        setTimeout(() => {
            var results = this.props.options.filter(obj => {
                return obj.label.toLowerCase().startsWith(event.query.toLowerCase())
                    || obj.value.toLowerCase().startsWith(event.query.toLowerCase());
            })
            this.setState({ suggestions: results });
        }, 500);
    }

    itemTemplate(obj){
        return `${obj.value} - ${obj.label}`
    }

    render() {
        const {
            label,
            isRequired,
            id,
            onChange,
            testIdentifier,
            t,
            info,
            error,
            enabled,
            placeholder,
            labelDesc,
            itemTemplate,
            labelClass
        } = this.props
        const { selectedValue, suggestions } = this.state
        return (
            <div className="form-group">
                <label htmlFor={id} className={labelClass?labelClass:"d-block"}>
                    {label}
                    {
                        isRequired &&
                        <span className="text-warning">*</span>
                    }
                    {
                        labelDesc &&
                        <> {labelDesc}</>
                       
                    }
                </label>
                <AutoComplete
                    inputClassName={`${error ? "is-invalid" : ""}`}
                    value={selectedValue}
                    itemTemplate={itemTemplate ? itemTemplate : this.itemTemplate}
                    suggestions={suggestions}
                    completeMethod={this.suggestResult}
                    field={label}
                    placeholder={placeholder}
                    onChange={event => onChange(this.handleChange(event.target.value))}
                    data-test={testIdentifier}
                    disabled={!enabled}
                    inputId={id}
                />
                <small id={`${id}_help`} className="form-text text-muted">{info}</small>
            </div>
        );
    }
}

export default SearchDropdown;