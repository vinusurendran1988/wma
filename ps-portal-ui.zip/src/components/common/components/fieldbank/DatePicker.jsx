import React from 'react';
import { getFormattedDate } from '../../utils';
import { DD_MMM_YYYY,CALENDAR_SELECTION_MODE } from '../../utils/Constants';
import { Calendar } from 'primereact/calendar';
import moment from 'moment'
import 'primeflex/primeflex.css';
import { Dropdown } from 'primereact/dropdown';


/**
 * @name Custom DatePicker component.
 * 
 * @author Somdas M
 */
export default class DatePicker extends React.Component {

    constructor(props) {
        super(props);
    }
 
    yearNavigatorTemplate = (e) => {
        return <Dropdown value={e.value} options={e.options} onChange={(event) => e.onChange(event.originalEvent, event.value)} className="p-ml-2" style={{ lineHeight: 1 }} />;
    }

    monthNavigatorTemplate = (e) => {
        return <Dropdown value={e.value} options={e.options} onChange={(event) => e.onChange(event.originalEvent, event.value)} style={{ lineHeight: 1 }} />;
    }
    render() {
        const {
            label,
            isRequired,
            id,
            onChange,
            testIdentifier,
            info,
            error,
            enabled,
            minDate,
            maxDate,
            placeholder,
            dateFormat,
            numberOfMonths,
            selectionMode,
            yearNavigator,
            monthNavigator,
            footerTemplate,
            calenderRef,
            labelClassName
        } = this.props

        let dateValue = this.props.value.selectedCustomDate?this.props.value.selectedCustomDate:this.props.value;
        return (
            <div className="form-group">
                <label
                    htmlFor={id}
                    className={labelClassName?labelClassName:""}
                >
                    {label}
                    {isRequired &&
                        <span className="text-warning">*</span>
                    }
                </label>
                <div className="input-wrap date-wrap">
                    <Calendar
                        aria-required="true"
                        aria-describedby={`${id}_help`}
                        id={'cust-calendar-' + id}
                        inputId={id}
                        inputClassName={`${error ? "is-invalid" : ""}`}
                        value={dateValue && selectionMode ==CALENDAR_SELECTION_MODE?dateValue:new Date(moment(dateValue, DD_MMM_YYYY).valueOf())}
                        onChange={(e) => onChange(selectionMode ==CALENDAR_SELECTION_MODE?e.value:getFormattedDate(e.value, DD_MMM_YYYY))}
                        minDate={new Date(minDate)}
                        maxDate={new Date(maxDate)}
                        yearNavigator={yearNavigator}
                        yearRange="1900:2030"
                        monthNavigator={monthNavigator}
                        showIcon={false}
                        data-test={testIdentifier}
                        disabled={!enabled}
                        required={isRequired}
                        placeholder={placeholder}
                        dateFormat={dateFormat?dateFormat:'dd/M/yy'}
                        numberOfMonths = {numberOfMonths}
                        selectionMode ={selectionMode}
                        yearNavigatorTemplate={this.yearNavigatorTemplate}
                        monthNavigatorTemplate={this.monthNavigatorTemplate}
                        footerTemplate={footerTemplate}
                        ref={calenderRef}
                    >
                    </Calendar>
                </div>
                <small id={`${id}_help`} className="form-text text-muted">{info}</small>
            </div>
        )
    }
}

DatePicker.defaultProps = {
    label: "",
    value: "",
    isRequired: false
}