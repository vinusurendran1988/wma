import React from 'react';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { withSuspense } from '../../../common/utils';
import { Calendar } from 'primereact/calendar';

class SearchFlights extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            isItemEnabled: false,
            origin: '',
            destination: '',
            cabinClass: '',
            departureDate: '',
            returnDate: '',
        }
    }
    componentDidMount() {
    }
    handleChange(e) {
        if (e.target.name == "origin" || e.target.name == "destination") {
            this.setState({
                isItemEnabled: true
            })
        }
        this.setState({ [e.target.name]: e.target.value });
    }
    handleSubmit = (e) => {
        e.preventDefault();
        return false;
      }
    render() {
        const { t, className } = this.props;

        return (
            <div className={`${className?className:"flight-search mb-3"}`}>
                <div className="col-xl-11 col-lg-12">
                    <ul className="flight-search__travell">
                        <li> <a role="button">{t('searchflight.one_way')}</a> </li>
                        <li> <a role="button" className="selected">{t('searchflight.return')}</a> </li>
                        <li> <a role="button">{t('searchflight.multicity')}</a> </li>
                        <li className="switch-wrap">
                            <input className="toggle-switch" type="checkbox" id="switch" />
                            <label className="switch-wrap-label" htmlFor="switch">{t('searchflight.toggle')}</label>
                            <span>{t('searchflight.use_miles')}</span> </li>
                    </ul>
                    <form className="flight-search__form" onSubmit={this.handleSubmit}>
                        <div className="form-group">
                            <div className="items">
                                <div className="input-wrap select-wrap">
                                    <select id="country" value={this.state.origin} name="origin" onChange={(e) => this.handleChange(e)} >
                                        <option value="">FROM</option>
                                        <option value="london">LHR - London Heathrow, United Kingdom</option>
                                    </select>
                                </div>
                                <div className="input-wrap select-wrap">
                                    <select id="country" value={this.state.destination} name="destination" onChange={(e) => this.handleChange(e)}>
                                        <option value="">TO</option>
                                        <option value="dubai">DXB - Dubai, United Arab Emirates</option>
                                    </select>
                                </div>
                            </div>
                            {this.state.isItemEnabled &&
                                <div className="items">
                                    <div className="input-wrap date-wrap">
                                        <Calendar
                                            name="departureDate"
                                            minDate={new Date()}
                                            numberOfMonths={1}
                                            value={this.state.departureDate || ""}
                                            onChange={(e) => this.handleChange(e)}
                                            placeholder={"DEPARTURE DATE"}
                                        />
                                    </div>
                                    <div className="input-wrap date-wrap">
                                        <Calendar
                                            name="returnDate"
                                            minDate={new Date()}
                                            value={this.state.returnDate || ""}
                                            onChange={(e) => this.handleChange(e)}
                                            placeholder={"RETURN DATE"}
                                        />
                                    </div>
                                    <div className="input-wrap select-wrap">
                                        <select id="country" value={this.state.cabinClass} name="cabinClass" onChange={(e) => this.handleChange(e)} >
                                            <option value="economy">Economy</option>
                                            <option value="premiumEconomy">Premium Economy</option>
                                        </select>
                                    </div>
                                </div>
                            }
                        </div>
                        <div className="btn-wrap">
                            <button onClick={(e) => e.preventDefault()} className="btn btn-primary">{t('searchflight.search_flights')}</button>
                        </div>
                    </form>
                </div>
            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return {
    }
}
const mapDispatchToProps = {
}
export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(SearchFlights)));