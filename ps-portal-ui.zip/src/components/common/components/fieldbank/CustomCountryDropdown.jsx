import React, { Component } from 'react';
import { Dropdown } from 'primereact/dropdown';
import { withSuspense } from '../../utils';
import { withTranslation } from 'react-i18next';
import ReactCountryFlag from "react-country-flag"
import './style.css'

class CustomCountryDropdown extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedValue: this.props.value
        }
        this.selectedCountryTemplate = this.selectedCountryTemplate.bind(this)
        this.countryOptionTemplate = this.countryOptionTemplate.bind(this)
    }

    componentDidUpdate(prevProps) {
        if (prevProps.value != this.props.value) {
            this.setState({ selectedValue: this.props.value })
        }
    }

    handleChange(value) {
        this.setState({ selectedValue: value })
        return value
    }

    selectedCountryTemplate(option, props) {
        if (option) {
            return (
                <div>
                    <div><ReactCountryFlag countryCode={option.value} svg /> {option.label}</div>
                </div>
            );
        }
    
        return (
            <span>
                {props.placeholder}
            </span>
        );
    }
    
    countryOptionTemplate(option) {
        return (
            <div>
                <div><ReactCountryFlag countryCode={option.value} svg /> {option.label}</div>
            </div>
        );
    }
    
    render() {
        const {
            label,
            options,
            isRequired,
            id,
            onChange,
            testIdentifier,
            t,
            info,
            error,
            enabled,
            placeholder
        } = this.props
        const { selectedValue } = this.state
        return (
            <div className="form-group">
                <label htmlFor={id}>
                    {label}
                    {isRequired &&
                        <span className="text-warning">*</span>
                    }
                </label>
                
                
                
                <Dropdown
                    inputId={id}
                    className={`country-item-value ${error?"is-invalid": ""}`}
                    value={selectedValue}
                    options={options}
                    onChange={(e) => onChange(this.handleChange(e.value))}
                    optionLabel="label"
                    optionValue="value"
                    placeholder={placeholder}
                    aria-describedby={`${id}_help`}
                    data-test={testIdentifier}
                    disabled={!enabled}
                    valueTemplate={this.selectedCountryTemplate}
                    itemTemplate={this.countryOptionTemplate}
                    filter
                    showClear
                    
                />









                {/* <select
                    id={id}
                    className={`${error?"is-invalid": ""}`}
                    id="exampleFormControlInput1"
                    aria-describedby={`${id}_help`}
                    value={selectedValue}
                    onChange={event => onChange(this.handleChange(event.target.value))}
                    data-test={testIdentifier}
                    disabled={!enabled}
                >
                    <option value="">{t('fieldbank.dropdown_default_option')}</option>
                    {options.map((option, index) => {
                        return <option
                            key={index}
                            value={option.value}
                        >{option.label}</option>
                    })}
                </select> */}
                <small id={`${id}_help`} className="form-text text-muted">{info}</small>
            </div>
        )
    }
}


CustomCountryDropdown.defaultProps = {
    label: "",
    isRequired: false,
    options: [],
    value: ""
}

export default withSuspense()(withTranslation()(CustomCountryDropdown));