import React, { Component } from 'react';
import { getMessage } from '../../../ui/overview/OverviewUtils';
import { UPGRADE } from '../../../ui/overview/Constants';
import { withTranslation } from 'react-i18next';
import DonutChart from '../donutChart';
import { fetchConfiguration } from '../../middleware/redux/commonAction';
import { CONFIG_SECTION_OVERVIEW, CONFIG_SECTION_ACCOUNT_SUMMARY } from '../../utils/Constants';
import { withSuspense } from '../../utils';
import { connect } from 'react-redux';


class TierProgress extends Component {
  constructor(props) {
    super(props)

  }
  componentDidMount() {
    if (!this.props.overviewConfig) {
      this.props.fetchConfiguration(CONFIG_SECTION_OVERVIEW)
    }
  }
  renderDounutChart(options, memberTierDetails, colors) {
    return options && options.map((option, index) => {
      const { optionDetails } = option
      return optionDetails.map((detail, idx) => {
        if (detail.preferred) {
          return <>
            <div className="graph">
              <DonutChart
                currentTier={memberTierDetails.tierDetails.currentTierName}
                nextTier={memberTierDetails.tierDetails.nextTierName}
                nextTarget={parseInt(detail.next)}
                difference={parseInt(detail.diff)}
                pointsAchieved={parseInt(detail.current)}
                icon={detail.uiType}
                colors={colors}
                name={detail.name}
              />
            </div>
          </>
        }
      })
    })
  }


  renderTierProgress(colors, accountSummary) {
    return <>
      {
        accountSummary && accountSummary.tierOptions &&
        accountSummary.tierOptions.map((tierOption) => {
          return this.renderTierProgressData(tierOption, colors)
        })
      }
    </>
  }

  renderTierProgressData(tierOption, colors) {
    if (tierOption.type == UPGRADE) {
      const { options } = tierOption
      const { t, memberTierDetails } = this.props
      return <>
        <div className="reward__graph">
          {memberTierDetails && memberTierDetails.tierDetails && this.renderDounutChart(options, memberTierDetails, colors)}
        </div>
        <div className="reward__desc"> {getMessage(tierOption, UPGRADE, "", "", t)} <strong className="text-uppercase">{tierOption.tierName}</strong> ! <span className="text-important">Upgrade and get more miles and additional benefits!* </span> </div>
      </>
    }
  }

  render() {
    const { overviewConfig, accountSummary, showTitle, className, t, memberTierDetails } = this.props;
    const donutConfig = overviewConfig && overviewConfig.config.ui.layout.elements['graph']
    return (
      <>
        {
          showTitle &&
            <div className="title">
              <h2>{t('overview.tier_progress')}</h2>
            </div>
        }
        <div className={`${className?className:""}`}>
          {donutConfig && this.renderTierProgress(donutConfig.colors, accountSummary)}
        </div>
      </>
    );
  }
}

function mapStateToProps(state) {
  return {
    overviewConfig: state.configurationReducer[CONFIG_SECTION_OVERVIEW],
    accountSummary: state.accountSummaryReducer.accountSummary,
    accountSummaryConfig: state.configurationReducer[CONFIG_SECTION_ACCOUNT_SUMMARY],
    memberTierDetails : state.setTierDetailsReducer.payload
  }
}

const mapDispatchToProps = {
  fetchConfiguration
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(TierProgress)));
