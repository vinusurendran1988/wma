import React from 'react';
import { withSuspense } from '../../utils';
import { withTranslation } from 'react-i18next';
import { openPopup } from '../../utils/common.utils';
import { FACEBOOK, GOOGLE } from '../../../ui/enrolment/Constants';
import { _IMAGE_BASEURL } from '../../config/config';

/**
 * @name Custom Checkbox component.
 * @description Component that consists of a label and multiple checkboxes.
 * 
 * @author Ajmal Aliyar
 */
class SocialMedia extends React.Component {

    constructor(props){
        super(props)
        this.fbregister = this.fbregister.bind(this)
        this.googleregister = this.googleregister.bind(this)
    }

    /**
     * Function to open the facebook popup
     */
    fbregister() {
        openPopup(FACEBOOK)
    }

    /**
     * Function to open the facebook popup
     */
    googleregister() {
        openPopup(GOOGLE)
    }
    render() {
        const { className, t } = this.props
        return (
            <div className={className}>
                <h5>{t('enrolment.register_with')}</h5>
                <span className="loginBtn loginBtn--facebook" onClick={this.fbregister} data-test="fbLogin"></span>
                <span className="loginGbtn" data-test="googleLogin" onClick={this.googleregister}>
                    <img src={`${_IMAGE_BASEURL}/icons/gicon.png`} alt="Google Icon" />
                </span>
            </div>
            )

    }
}


export default withSuspense()(withTranslation()(SocialMedia));