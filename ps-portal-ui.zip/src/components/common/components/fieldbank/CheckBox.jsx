import React from 'react';
import { withSuspense } from '../../utils';
import { withTranslation } from 'react-i18next';
import parse from 'html-react-parser';

/**
 * @name Custom Checkbox component.
 * @description Component that consists of a label and multiple checkboxes.
 * 
 * @author Ajmal Aliyar
 */
class CheckBox extends React.Component {


    handleChange(value) {
        return value
    }

    render() {
        const {
            label,
            isRequired,
            testIdentifier,
            value,
            id,
            info,
            onChange,
            error,
            enabled
        } = this.props

        return (
            <div className="form-check form-check-inline">
                <input
                    className={`form-check-input ${error?"is-invalid": ""}`}
                    type="checkbox"
                    id={id}
                    checked={value}
                    aria-describedby={`${id}_help`}
                    onChange={(e) =>onChange(this.handleChange(e.target.checked))}
                    data-test={`${testIdentifier}`}
                    disabled={!enabled}
                />
                <label
                    className="form-check-label"
                    htmlFor={id}>{parse(label)}</label>
                <small id={`${id}_help`} className="form-text text-muted">{info}</small>
            </div>
        )

    }
}

CheckBox.defaultProps = {
    label: "",
    isRequired: false,
    value: ""
}

export default withSuspense()(withTranslation()(CheckBox));