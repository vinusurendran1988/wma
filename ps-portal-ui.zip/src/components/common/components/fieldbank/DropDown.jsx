import React from 'react';
import { withSuspense } from '../../utils/';
import { withTranslation } from 'react-i18next';
import parse from 'html-react-parser';

/**
 * @name Custom DropDown component.
 * @description Component that consists of a label and a dropdown box.
 * 
 * @author Ajmal Aliyar
 */
class DropDown extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            selectedValue: this.props.value
        }
    }

    componentDidUpdate(prevProps) {
        if (prevProps.value != this.props.value) {
            this.setState({ selectedValue: this.props.value })
        }
    }

    handleChange(value) {
        this.setState({ selectedValue: value })
        return value
    }

    render() {
        const {
            label,
            options,
            isRequired,
            id,
            onChange,
            testIdentifier,
            t,
            info,
            error,
            enabled,
            placeholder,
            removeDefaultOption,
            labelClassName,
            errorMessage,
            toolTip
        } = this.props
        const { selectedValue } = this.state
        return (
            <div className="form-group">
                <label className={labelClassName?labelClassName:""} htmlFor={id}>
                {parse(label)}
                {toolTip && <i className="fa fa-question-circle" aria-hidden="true"  data-toggle='tooltip' title= {toolTip}></i>}
                </label>
                <select
                    inputId={id}
                    // className={`${error?"is-invalid": ""}`}
                    aria-describedby={`${id}_help`}
                    value={selectedValue}
                    placeholder={placeholder}
                    onChange={event => onChange(this.handleChange(event.target.value))}
                    data-test={testIdentifier}
                    disabled={!enabled}
                >
                    {removeDefaultOption!=true && <option value="">{t('fieldbank.dropdown_default_option')}</option>}
                    {options.map((option, index) => {
                        return <option
                            key={index}
                            value={option.value}
                        >{option.label}</option>
                    })}
                </select>
                {error && 
                    <div className="simple-alert"><div className="alert alert-danger alert--custom hide-fontawesome" role="alert">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M0 10C0 15.5228 4.47715 20 10 20C15.5228 20 20 15.5228 20 10C20 4.47715 15.5228 0 10 0C4.47715 0 0 4.47715 0 10ZM8.60688 5.49619C8.54913 4.6877 9.18946 4 10 4C10.8106 4 11.4509 4.6877 11.3931 5.49619L11.0713 10.0025C11.0311 10.5646 10.5635 11 10 11C9.43656 11 8.96891 10.5646 8.92876 10.0025L8.60688 5.49619ZM8.78785 14.25C8.78785 13.5596 9.3475 13 10.0379 13C10.7282 13 11.2879 13.5596 11.2879 14.25C11.2879 14.9404 10.7282 15.5 10.0379 15.5C9.3475 15.5 8.78785 14.9404 8.78785 14.25Z" fill="#EE6A2F" />
                            <mask id="mask0_5049_74100" style={{ maskType: "alpha" }} maskUnits="userSpaceOnUse" x="0" y="0" width="20" height="20">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M0 10C0 15.5228 4.47715 20 10 20C15.5228 20 20 15.5228 20 10C20 4.47715 15.5228 0 10 0C4.47715 0 0 4.47715 0 10ZM8.60688 5.49619C8.54913 4.6877 9.18946 4 10 4C10.8106 4 11.4509 4.6877 11.3931 5.49619L11.0713 10.0025C11.0311 10.5646 10.5635 11 10 11C9.43656 11 8.96891 10.5646 8.92876 10.0025L8.60688 5.49619ZM8.78785 14.25C8.78785 13.5596 9.3475 13 10.0379 13C10.7282 13 11.2879 13.5596 11.2879 14.25C11.2879 14.9404 10.7282 15.5 10.0379 15.5C9.3475 15.5 8.78785 14.9404 8.78785 14.25Z" fill="white" />
                            </mask>
                            <g mask="url(#mask0_5049_74100)">
                            </g>
                        </svg> {t(errorMessage)} </div></div>
                }

                
                <small id={`${id}_help`} className="form-text text-muted">{info}</small>

            </div>
        )
    }
}

DropDown.defaultProps = {
    label: "",
    isRequired: false,
    options: [],
    value: ""
}

export default withSuspense()(withTranslation()(DropDown));