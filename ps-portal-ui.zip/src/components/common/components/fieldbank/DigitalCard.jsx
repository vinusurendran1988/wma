import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import {
    isEmptyOrSpaces,
    toTitleCase,
    toUpperCase,
    withSuspense
} from '../../../common/utils';
import Loader from '../../../common/components/fieldbank/loader/Loader';
import { BROWSER_STORAGE_KEY_MEMBERSHIP_NO, getItemFromBrowserStorage } from '../../utils/storage.utils';
import * as htmlToImage from 'html-to-image';
import download from 'downloadjs';
import { _IMAGE_BASEURL } from '../../config/config';
import moment from 'moment'
import { HYPHEN } from './Constants';
import { CONFIG_SECTION_DASHBOARD, CONFIG_SECTION_ACCOUNT_SUMMARY } from '../../utils/Constants';
import { OVERVIEW_DOWNLOAD_DIGITAL_CARD, trackData } from '../../utils/analytics.utils'
import { fetchConfiguration } from '../../../common/middleware/redux/commonAction';
import Button from './Button';
import { startButtonSpinner, stopButtonSpinner } from './loader/action';

class DigitalCard extends Component {
    constructor(props) {
        super(props)
        this.downloadCard = this.downloadCard.bind(this)
        this.myRef = React.createRef();
        this.state = {
            isLoading: false
        }
    }

    componentDidMount() {
        if (!this.props.config) {
            this.props.fetchConfiguration(CONFIG_SECTION_DASHBOARD)
        }
    }

    downloadCard = (config) => {
        this.props.startButtonSpinner("download", "downloadcard")

        const { t, displayName } = this.props
        if (config) {
            const currentTimeStamp = moment().valueOf()
            const fileNameFromConfig = config.ui && config.ui.digitalCard && config.ui.digitalCard.cardName
            const fileExtension = config.ui && config.ui.digitalCard && config.ui.digitalCard.cardExtension
            const customizeDigitalCard = config.ui && config.ui.digitalCard && config.ui.digitalCard.customizeDigitalCard
            let downloadFileName;
            if (customizeDigitalCard) {
                downloadFileName = fileNameFromConfig + displayName + fileExtension

            }
            else {
                downloadFileName = fileNameFromConfig + HYPHEN + currentTimeStamp + fileExtension
            }
            this.setState({
                isLoading: true
            })
            const digitalCard = this.myRef.current;
            const pngProperties = (config.ui &&
                config.ui.digitalCard &&
                config.ui.digitalCard.pngProperties) ?
                config.ui.digitalCard.pngProperties : {}
            htmlToImage.toPng(digitalCard, pngProperties)
                .then((dataUrl) => {
                    this.setState({
                        isLoading: false
                    })
                    download(dataUrl, downloadFileName);
                    this.props.stopButtonSpinner("download", "downloadcard")

                })
                .catch(function (error) {
                    console.error('Downloading failed', error);
                    this.setState({
                        isLoading: false
                    })
                });
        }
    }

    getClassName() {
        const { footerMessage, expiryMessage, config } = this.props
        let secondaryClassName = ""
        let customizeDigitalCard = config && config.ui && config.ui.digitalCard &&
            config.ui.digitalCard.customizeDigitalCard
        if (customizeDigitalCard) {
            if (expiryMessage && expiryMessage.length > 0 && expiryMessage[0] && expiryMessage[0].includes("Expired")) {
                secondaryClassName = "digital-card--inactive"
            }
            if (footerMessage) {
                secondaryClassName = "digital-card--extra-guest"
            }

        }
        return `digital-card ${secondaryClassName}`
    }

    render() {
        const { t, accountSummary, qrcodeImage, config,
            profileData, memberTierDetails, descriptionRequired,
            expiryMessage, title, footerMessage, membershipType } = this.props
        let membershipNumber
        let displayName
        let customizeDigitalCard
        let downloadButtonStyle
      
        if (config && config.ui && config.ui.digitalCard) {
            customizeDigitalCard = config.ui.digitalCard.customizeDigitalCard
        }
        if (customizeDigitalCard) {
            displayName = this.props.displayName
            membershipNumber = this.props.membershipNumber
        }
        else {
            membershipNumber = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)
            displayName = profileData && profileData.object && profileData.object.memberAccount && profileData.object.memberAccount.memberProfile &&
                profileData.object.memberAccount.memberProfile.individualInfo && profileData.object.memberAccount.memberProfile.individualInfo.displayName
                 downloadButtonStyle = {
                    visibility: `${this.state.isLoading ? 'hidden' : 'visible'}`
                }
            }
       
       
        return (
            <div className="modal fade modal--digital" id="digital-card-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal--digital__title" id="exampleModalLongTitle">
                                {customizeDigitalCard & title ?
                                    t("sidebar.mileage_card.title")
                                    :
                                    title
                                }
                            </h5>
                            {customizeDigitalCard && descriptionRequired && <p className="modal--digital__desc">
                                {t("sidebar.mileage_card.description")}
                            </p>
                            }
                            <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                <img src={`${_IMAGE_BASEURL}/icons/icon-close.svg`} alt="Close Digital Card Popup Button" />
                            </button>
                        </div>
                        <div className="modal-body">
                            <div className="row">
                                <div className="col-lg-12">
                                    <div
                                        className="digital-card digital-card--inactive"
                                        className={this.getClassName()}
                                        ref={this.myRef}>
                                        {
                                            customizeDigitalCard ?
                                                <></>
                                                :
                                                <div className="digital-card__bg"></div>
                                        }
                                        <div className="digital-card__status">
                                            <strong className="text">
                                                {
                                                    memberTierDetails && memberTierDetails.tier1 ?
                                                        memberTierDetails.tier1.type : ""
                                                }
                                            </strong>
                                            <strong className="type">
                                                {
                                                    memberTierDetails && memberTierDetails.tier1 ?
                                                        memberTierDetails.tier1.name : ""
                                                }
                                            </strong>
                                        </div>
                                        <div className="digital-card__info">
                                            <span className="name">{toTitleCase(displayName)}</span>
                                            <span className="number">{(membershipNumber) ? membershipNumber : ''}</span>
                                            <span className="date" style={{fontStyle:"normal"}}>
                                                {customizeDigitalCard && expiryMessage ?
                                                    <>
                                                        {expiryMessage.length > 0 && expiryMessage[0] && expiryMessage[0].includes("Expired") &&
                                                            <div class="icon">
                                                                <svg aria-hidden="true" focusable="false" data-prefix="far" data-icon="exclamation-circle" role="img"
                                                                    xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                                    <path fill="currentColor" d="M256 8C119.043 8 8 119.083 8 256c0 136.997 111.043 248 248 248s248-111.003 248-248C504 119.083 392.957 8 256 8zm0 448c-110.532 0-200-89.431-200-200 0-110.495 89.472-200 200-200 110.491 0 200 89.471 200 200 0 110.53-89.431 200-200 200zm42-104c0 23.159-18.841 42-42 42s-42-18.841-42-42 18.841-42 42-42 42 18.841 42 42zm-81.37-211.401l6.8 136c.319 6.387 5.591 11.401 11.985 11.401h41.17c6.394 0 11.666-5.014 11.985-11.401l6.8-136c.343-6.854-5.122-12.599-11.985-12.599h-54.77c-6.863 0-12.328 5.745-11.985 12.599z" class="">
                                                                    </path></svg>
                                                            </div>
                                                        }
                                                        {expiryMessage}
                                                    </>
                                                    :
                                                    <>

                                                        {t("sidebar.mileage_card.expiry_date")}: {accountSummary && (accountSummary.tierToDate) ? accountSummary.tierToDate : 'Not Applicable'}
                                                    </>
                                                }

                                                {membershipType && <div class="flag"> {membershipType}</div>
                                                }
                                            </span>
                                        </div>
                                        <div className="digital-card__blck">
                                            <div className="bar-code">{(qrcodeImage && qrcodeImage.qrCode) ? <img src={qrcodeImage.qrCode} width="100" alt="QR Code" /> : <Loader />}</div>
                                            <div className="logo"><img src={`${_IMAGE_BASEURL}/logo-card.png`} alt="ifly-logo" /></div>
                                        </div>
                                        {
                                            memberTierDetails && memberTierDetails.tier2 ?
                                                <div className="cobrand">
                                                    <span>{memberTierDetails.tier2.type} </span>
                                                    <strong className="text-uppercase"> {memberTierDetails.tier2.name}</strong>
                                                </div> : ""
                                        }
                                        {customizeDigitalCard && footerMessage &&
                                            <div class="digital-card__bottom">
                                                <div class="extra-guest">
                                                    <strong style={{width:"103px"}}>{footerMessage.name} </strong>
                                                    <span style={{width:"160px"}}>{footerMessage.message}</span>  </div>
                                            </div>
                                        }
                                    </div>
                                    {
                                        this.state.isLoading && !customizeDigitalCard  && <Loader className="download-spinner" />
                                    }
                                    <div className="utils-wrap" style={downloadButtonStyle}>
                                        {
                                            customizeDigitalCard ?
                                                <Button  id="download" className="btn btn-secondary" 
                                                handleOnClick={() => {trackData(OVERVIEW_DOWNLOAD_DIGITAL_CARD, {});this.downloadCard(config)}} 
                                                label = {t("sidebar.mileage_card.donwloadImage")}/>
                                                
                                                :
                                                <a className="utils" role="button" data-test="downloadCardTest"
                                                    onClick={() => this.downloadCard(config)}>
                                                    <img src={`${_IMAGE_BASEURL}/icons/icon-download.svg`} alt="" /><span>
                                                        {t("sidebar.mileage_card.download")}</span></a>
                                        }
                                    </div>
                                    {customizeDigitalCard && <p class="modal--digital__desc">{t("sidebar.mileage_card.bottomText")}</p>}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

function mapStateToProps(state) {

    return {
        accountSummary: state.accountSummaryReducer.accountSummary,
        qrcodeImage: state.qrCodeImageReducer.qrImage,
        config: state.configurationReducer[CONFIG_SECTION_DASHBOARD],
        profileData: state.profileDataReducer.profileData,
        memberTierDetails: state.setTierDetailsReducer.payload,
        accountSummaryConfig: state.configurationReducer[CONFIG_SECTION_ACCOUNT_SUMMARY],
    }
}

const mapDispatchToProps = {
    fetchConfiguration,
    startButtonSpinner,
    stopButtonSpinner
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(DigitalCard)));