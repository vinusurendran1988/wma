import React from 'react';
import { withSuspense } from '../../utils';
import { withTranslation } from 'react-i18next';
import parse from 'html-react-parser';

/**
 * @name Custom DropDown component.
 * @description Component that consists of a label and a dropdown box.
 * 
 * @author Ajmal Aliyar
 */
class DropDownWithTextField extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            selectedOption: this.props.selectedOption,
            textValue: this.props.textValue
        }
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevProps.selectedOption != this.props.selectedOption) {
            this.setState({ selectedOption: this.props.selectedOption })
        }
        if (prevProps.textValue != this.props.textValue) {
            this.setState({ textValue: this.props.textValue })
        }
        if (
            prevState.selectedOption != this.state.selectedOption
            || prevState.textValue != this.state.textValue
        ) {
            const { onChange } = this.props
            onChange({
                text: this.state.textValue,
                option: this.state.selectedOption
            })
        }
    }

    handleChange(key, value) {
        this.setState({ [key]: value })
    }

    render() {
        const {
            label,
            isRequired,
            id,
            options,
            testIdentifier,
            t,
            info,
            error,
            enabled,
            additionalError
        } = this.props
        const { selectedOption, textValue } = this.state
        return (
            <div className="form-group">
                <label htmlFor={`${id}-text`}>
                {parse(label)}
                </label>
                <div className="input-group">
                    <div className="input-group-prepend">
                        <select
                            id={`${id}-select`}
                            className={`${additionalError?"is-invalid": "custom-select"}`}
                            value={selectedOption}
                            onChange={event => this.handleChange("selectedOption", event.target.value)}
                            data-test={testIdentifier}
                            aria-describedby={`${id}_help`}
                            disabled={!enabled}
                        >
                            <option value="">{t('fieldbank.dropdown_default_option')}</option>
                            {options.map((option, index) => {
                                return <option
                                    key={index}
                                    value={option.value}
                                >{option.label}</option>
                            })}
                        </select>
                    </div>
                    <input
                        id={`${id}-text`}
                        type="text"
                        className={`${error?"is-invalid": ""} form-control`}
                        value={textValue}
                        onChange={event => this.handleChange("textValue", event.target.value)}
                        disabled={!enabled}
                    />
                </div>
                <small id={`${id}_help`} className="form-text text-muted">{info}</small>
            </div>
        )
    }
}

DropDownWithTextField.defaultProps = {
    label: "",
    isRequired: false,
    options: [],
    textValue: "",
    selectedOption: ""
}

export default withSuspense()(withTranslation()(DropDownWithTextField));

