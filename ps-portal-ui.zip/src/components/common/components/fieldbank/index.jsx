import React from 'react'
import CheckBoxGroup from './CheckBoxGroup'
import DropDown from './DropDown'
import RadioButtonGroup from './RadioButtonGroup'
import {
    FIELDTYPE_CHECKBOXGROUP,
    FIELDTYPE_DROPDOWN,
    FIELDTYPE_RADIOBUTTONGROUP,
    FIELDTYPE_TEXTFIELD,
    FIELDTYPE_TEXTAREA,
    FIELDTYPE_DROPDOWN_TEXTFIELD,
    FIELDTYPE_DATE,
    FIELDTYPE_CHECKBOX,
    FIELDTYPE_PASSWORD,
    FIELDTYPE_SOCIAL_MEDIA,
    FIELDTYPE_NONE,
    FIELDTYPE_HORIZONTAL_LINE,
    FIELDTYPE_CUSTOM_COUNTY_DROPDOWN,
    FIELDTYPE_CUSTOM_SEARCH_DROPDOWN,
    FIELDTYPE_TABLE,
    FIELDTYPE_TEXTFIELD_WITH_BUTTON,
    FIELDTYPE_SECURITY_QUESTION,
    FIELDTYPE_MULTI_VALUE_TEXTFIELD,
    FIELDTYPE_LABEL_TEXTFIELD,
    FIELDTYPE_SIMPLE_TEXT,
    FIELDTYPE_ALERT_BOX,
    FIELDTYPE_LINK
} from './Constants'
import TextField from './TextField'
import TextfieldWithButton from './TextfieldWithButton'
import TextArea from './TextArea'
import DropDownWithTextField from './DropDownWithTextField'
import DatePicker from './DatePicker'
import CheckBox from './CheckBox'
import SocialMedia from './SocialMedia'
import CustomCountryDropdown from './CustomCountryDropdown'
import SearchDropdown from './SearchDropdown'
import Table from './Table'
import SecurityQuestions from '../../../ui/security/securityquestions'
import MultiValueTextField from './MultiValueTextField'
import LabelTextfield from './LabelTextfield'
import AlertBox from './AlertBox'
import Link from './Link'

export default function FieldBank(props) {

    const renderField = (properties) => {
        if (properties && properties.fieldType) {
            return (<div className={props.className}>{
                (() => {
                    switch (properties.fieldType) {
                        case FIELDTYPE_SOCIAL_MEDIA:
                            return <SocialMedia
                                className={properties.className}
                            />
                        case FIELDTYPE_CHECKBOXGROUP:
                            return <CheckBoxGroup
                                label={properties.label}
                                placeholder={properties.placeholder}
                                checkBoxes={properties.options}
                                isRequired={properties.isRequired}
                                value={properties.value}
                                onChange={properties.onChange}
                                testIdentifier={properties.testIdentifier}
                                error={properties.error}
                                info={properties.info}
                                enabled={properties.enabled}
                                checkboxGroupClassName={properties.checkboxGroupClassName}
                            />
                        case FIELDTYPE_CHECKBOX:
                            return <CheckBox
                                label={properties.label}
                                placeholder={properties.placeholder}
                                isRequired={properties.isRequired}
                                value={properties.value}
                                id={properties.id}
                                onChange={properties.onChange}
                                testIdentifier={properties.testIdentifier}
                                error={properties.error}
                                info={properties.info}
                                enabled={properties.enabled}
                            />
                        case FIELDTYPE_DROPDOWN:
                            return <DropDown
                                label={properties.label}
                                placeholder={properties.placeholder}
                                options={properties.options}
                                isRequired={properties.isRequired}
                                id={properties.id}
                                value={properties.value}
                                onChange={properties.onChange}
                                testIdentifier={properties.testIdentifier}
                                error={properties.error}
                                info={properties.info}
                                enabled={properties.enabled}
                                removeDefaultOption={properties.removeDefaultOption}
                                errorMessage = {properties.errorMessage}
                                toolTip = {properties.toolTip}
                            />
                        case FIELDTYPE_CUSTOM_SEARCH_DROPDOWN:
                            return <SearchDropdown
                                label={properties.label}
                                placeholder={properties.placeholder}
                                options={properties.options}
                                isRequired={properties.isRequired}
                                id={properties.id}
                                value={properties.value}
                                onChange={properties.onChange}
                                testIdentifier={properties.testIdentifier}
                                error={properties.error}
                                info={properties.info}
                                enabled={properties.enabled}
                            />
                        case FIELDTYPE_CUSTOM_COUNTY_DROPDOWN:
                            return <CustomCountryDropdown
                                label={properties.label}
                                placeholder={properties.placeholder}
                                options={properties.options}
                                isRequired={properties.isRequired}
                                id={properties.id}
                                value={properties.value}
                                onChange={properties.onChange}
                                testIdentifier={properties.testIdentifier}
                                error={properties.error}
                                info={properties.info}
                                enabled={properties.enabled}
                            />
                        case FIELDTYPE_DATE:
                            return <DatePicker
                                label={properties.label}
                                placeholder={properties.placeholder}
                                options={properties.options}
                                isRequired={properties.isRequired}
                                id={properties.id}
                                value={properties.value}
                                onChange={properties.onChange}
                                testIdentifier={properties.testIdentifier}
                                error={properties.error}
                                info={properties.info}
                                enabled={properties.enabled}
                                minDate={properties.minDate}
                                maxDate={properties.maxDate}
                                dateFormat={properties.dateFormat}
                                readOnlyInput={properties.readOnlyInput}
                                numberOfMonths={properties.numberOfMonths}
                                selectionMode={properties.selectionMode}
                                monthNavigator={properties.monthNavigator}
                                yearNavigator={properties.yearNavigator}
                                footerTemplate={properties.footerTemplate}
                                calenderRef={properties.calenderRef}

                            />
                        case FIELDTYPE_RADIOBUTTONGROUP:
                            return <RadioButtonGroup
                                label={properties.label}
                                placeholder={properties.placeholder}
                                radioButtons={properties.options}
                                isRequired={properties.isRequired}
                                id={properties.id}
                                value={properties.value}
                                onChange={properties.onChange}
                                testIdentifier={properties.testIdentifier}
                                info={properties.info}
                                enabled={properties.enabled}
                                error={properties.error}
                                errorMessage = {properties.errorMessage}
                            />
                        case FIELDTYPE_PASSWORD:
                        case FIELDTYPE_TEXTFIELD:
                            return <TextField
                                label={properties.label}
                                placeholder={properties.placeholder}
                                isRequired={properties.isRequired}
                                id={properties.id}
                                value={properties.value}
                                onChange={properties.onChange}
                                testIdentifier={properties.testIdentifier}
                                error={properties.error}
                                info={properties.info}
                                type={properties.fieldType == FIELDTYPE_PASSWORD ? "password" : "text"}
                                enabled={properties.enabled}
                                errorMessage = {properties.errorMessage}
                                toolTip = {properties.toolTip}
                            />
                        case FIELDTYPE_TEXTAREA:
                            return <TextArea
                                label={properties.label}
                                placeholder={properties.placeholder}
                                isRequired={properties.isRequired}
                                id={properties.id}
                                value={properties.value}
                                onChange={properties.onChange}
                                testIdentifier={properties.testIdentifier}
                                error={properties.error}
                                info={properties.info}
                                enabled={properties.enabled}
                                minimumCharacter={properties.minimumCharacter}
                                maximumCharacter={properties.maximumCharacter}
                            />
                        case FIELDTYPE_DROPDOWN_TEXTFIELD:
                            return <DropDownWithTextField
                                label={properties.label}
                                placeholder={properties.placeholder}
                                isRequired={properties.isRequired}
                                id={properties.id}
                                options={properties.options}
                                textValue={(properties.value && properties.value.text) ? properties.value.text : ""}
                                selectedOption={(properties.value && properties.value.option) ? properties.value.option : ""}
                                onChange={properties.onChange}
                                testIdentifier={properties.testIdentifier}
                                info={properties.info}
                                error={properties.error}
                                additionalError={properties.additionalError}
                                enabled={properties.enabled}
                            />
                        case FIELDTYPE_TABLE:
                            return <Table
                                values={properties.values}
                                downloadValues={properties.downloadValues}
                                columns={properties.columns}
                                exportStr={properties.exportStr}
                                exportFileName={properties.exportFileName}
                                bodyTemplates={properties.bodyTemplates}
                                globalFilter={properties.globalFilter}
                                emptyMessage={properties.emptyMessage}
                                onValueChange={properties.onValueChange}
                                partnerList={properties.partnerList}
                                showTickIconFor = {properties.showTickIconFor}
                                defaultSortFields = {properties.defaultSortFields}
                                defaultSort = {properties.defaultSort}
                            />
                        case FIELDTYPE_TEXTFIELD_WITH_BUTTON:
                            return <TextfieldWithButton
                                label={properties.label}
                                placeholder={properties.placeholder}
                                isRequired={properties.isRequired}
                                id={properties.id}
                                value={properties.value}
                                onChange={properties.onChange}
                                buttonName={properties.buttonName}
                                testIdentifier={properties.testIdentifier}
                                error={properties.error}
                                info={properties.info}
                                type={properties.fieldType == FIELDTYPE_PASSWORD ? "password" : "text"}
                                enabled={properties.enabled}
                                handleOnClick={properties.handleOnClick}
                            />
                        case FIELDTYPE_NONE:
                            return <div className={properties.className}></div>
                        case FIELDTYPE_HORIZONTAL_LINE:
                            return <hr />
                        case FIELDTYPE_SECURITY_QUESTION:
                            return <SecurityQuestions
                                numberOfQuestions={properties.numberOfQuestions}
                                errorIndices={properties.errorIndices}
                                onChange={properties.onChange}
                                isRequired={properties.isRequired}
                                renderType={properties.renderType}
                                idx={properties.id}
                                reset={properties.resetForm}
                                values={properties.values}
                                type={properties.securityQuestionType}
                                filterType={properties.securityQuestionFilterType}
                                filterValue={properties.securityQuestionFilterValue}

                            />
                        case FIELDTYPE_MULTI_VALUE_TEXTFIELD:
                            return <MultiValueTextField
                                // {...props}
                                value={properties.value}
                                key={properties.key}
                                onChange={properties.onChange}
                                placeholder={properties.placeholder}
                                itemList={properties.itemList}
                                handleKeyDown={properties.handleKeyDown}
                                label={properties.label}
                                handleDelete={properties.handleDelete}
                                enabled={properties.enabled}
                                error={properties.error}
                                id={properties.id}
                                isRequired={properties.isRequired}
                                isMultipleValueAllowed={properties.isMultipleValueAllowed}
                                name={properties.name}
                            />
                        case FIELDTYPE_LABEL_TEXTFIELD:
                            return <LabelTextfield
                                label={properties.label}
                                placeholder={properties.placeholder}
                                isRequired={properties.isRequired}
                                id={properties.id}
                                value={properties.value}
                                onChange={properties.onChange}
                                testIdentifier={properties.testIdentifier}
                                error={properties.error}
                                info={properties.info}
                                type={properties.fieldType}
                                enabled={properties.enabled}
                            />
                        case FIELDTYPE_ALERT_BOX:
                            return <AlertBox
                                message={properties.i18MessageCode}
                                type={properties.boxType}
                            />
                            case FIELDTYPE_LINK:
                            return <Link
                                label={properties.label}
                                id={properties.id}
                                placeholder={properties.placeholder}
                                onClick = {properties.onClick}
                            />
                        default:
                            console.error("Unrecognized Field Type : ", properties.fieldType);
                            return <div className={properties.className}></div>
                    }
                })()
            }</div>)
        } else {
            console.error("FieldBank should be provided with a 'field' prop with a fieldType");
            return <p></p>
        }
    }

    return renderField(props.field)
}
