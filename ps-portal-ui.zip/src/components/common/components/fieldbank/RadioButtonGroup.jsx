import React from 'react';
import { withSuspense } from '../../utils/';
import { withTranslation } from 'react-i18next';
import parse from 'html-react-parser';

/**
 * @name Custom RadioButtonGroup component.
 * @description Component that consists of a label and multiple radiobuttons.
 * 
 * @author Ajmal Aliyar
 */
class RadioButtonGroup extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            selectedValue: this.props.value
        }
    }

    handleChange(value) {
        this.setState({ selectedValue: value })
        return value
    }

    render() {
        const {
            label,
            radioButtons,
            isRequired,
            id,
            onChange,
            error,
            testIdentifier,
            info,
            enabled,
            t,
            errorMessage
        } = this.props
        const { selectedValue } = this.state
        if (radioButtons.length) {
            return (
                <div className="form-group">
                    <div className="lead">
                    {parse(label)}
                    </div>
                    {radioButtons.map((radioButton, index) => {
                        return <div
                            key={index}
                            className="form-check form-check-inline"
                        >
                            <input
                                className="form-check-input"
                                type="radio"
                                id={radioButton.id}
                                name={id}
                                value={radioButton.value}
                                checked={selectedValue == radioButton.value}
                                onChange={(e) => onChange(this.handleChange(e.target.value))}
                                data-test={`${testIdentifier}-${index}`}
                                aria-describedby={`${id}_help`}
                                disabled={!enabled}
                            />
                            <label className="form-check-label" htmlFor={radioButton.id}>{radioButton.label}</label>
                        </div>
                    })}
                     {error && 
                    //  <p class="is-invalid-txt" style={{"display": "inherit"}}><i class="fa fa-exclamation-circle"></i>
                    // &nbsp;{t(errorMessage)}</p>
                        <div className="simple-alert"><div className="alert alert-danger alert--custom hide-fontawesome" role="alert">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M0 10C0 15.5228 4.47715 20 10 20C15.5228 20 20 15.5228 20 10C20 4.47715 15.5228 0 10 0C4.47715 0 0 4.47715 0 10ZM8.60688 5.49619C8.54913 4.6877 9.18946 4 10 4C10.8106 4 11.4509 4.6877 11.3931 5.49619L11.0713 10.0025C11.0311 10.5646 10.5635 11 10 11C9.43656 11 8.96891 10.5646 8.92876 10.0025L8.60688 5.49619ZM8.78785 14.25C8.78785 13.5596 9.3475 13 10.0379 13C10.7282 13 11.2879 13.5596 11.2879 14.25C11.2879 14.9404 10.7282 15.5 10.0379 15.5C9.3475 15.5 8.78785 14.9404 8.78785 14.25Z" fill="#EE6A2F" />
                                <mask id="mask0_5049_74100" style={{ maskType: "alpha" }} maskUnits="userSpaceOnUse" x="0" y="0" width="20" height="20">
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M0 10C0 15.5228 4.47715 20 10 20C15.5228 20 20 15.5228 20 10C20 4.47715 15.5228 0 10 0C4.47715 0 0 4.47715 0 10ZM8.60688 5.49619C8.54913 4.6877 9.18946 4 10 4C10.8106 4 11.4509 4.6877 11.3931 5.49619L11.0713 10.0025C11.0311 10.5646 10.5635 11 10 11C9.43656 11 8.96891 10.5646 8.92876 10.0025L8.60688 5.49619ZM8.78785 14.25C8.78785 13.5596 9.3475 13 10.0379 13C10.7282 13 11.2879 13.5596 11.2879 14.25C11.2879 14.9404 10.7282 15.5 10.0379 15.5C9.3475 15.5 8.78785 14.9404 8.78785 14.25Z" fill="white" />
                                </mask>
                                <g mask="url(#mask0_5049_74100)">
                                </g>
                            </svg> {t(errorMessage)} </div></div>

                }
                    <small id={`${id}_help`} className="form-text text-muted">{info}</small>
                </div>
            )
        } else {
            return <p>{t('fieldbank.radiobutton_options_empty')}</p>
        }
    }
}

RadioButtonGroup.defaultProps = {
    label: "",
    isRequired: false,
    radioButtons: []
}

export default withSuspense()(withTranslation()(RadioButtonGroup));