import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withTranslation } from 'react-i18next';
import { withSuspense } from '../../utils';
import parse from 'html-react-parser';

/**
 * @name Custom Alert box component
 * @description Component of an alert of different types (success, error, warning & info)
 * 
 * @author Amrutha Jayaraj
 */

class AlertBox extends Component {
    render() {
        const { type, message, t, canTranslate } = this.props
        return (
            message && message.length > 0 &&
            <div className={`alert alert-${type} hide-fontawesome`} role="alert">
                <svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M0 10.6152C0 16.1381 4.47715 20.6152 10 20.6152C15.5228 20.6152 20 16.1381 20 10.6152C20 5.09239 15.5228 0.615234 10 0.615234C4.47715 0.615234 0 5.09239 0 10.6152ZM18 10.6152C18 15.0335 14.4183 18.6152 10 18.6152C5.58172 18.6152 2 15.0335 2 10.6152C2 6.19696 5.58172 2.61523 10 2.61523C14.4183 2.61523 18 6.19696 18 10.6152ZM8.75 5.86523C8.75 5.17488 9.30964 4.61523 10 4.61523C10.6904 4.61523 11.25 5.17488 11.25 5.86523C11.25 6.55559 10.6904 7.11523 10 7.11523C9.30964 7.11523 8.75 6.55559 8.75 5.86523ZM10 8.61523C9.30964 8.61523 8.75 9.17488 8.75 9.86523V15.3652C8.75 16.0556 9.30964 16.6152 10 16.6152C10.6904 16.6152 11.25 16.0556 11.25 15.3652V9.86523C11.25 9.17488 10.6904 8.61523 10 8.61523Z" fill="white"></path>
                </svg>  {
                   message && message.length > 0 && parse(t(message))
                }</div>




        );
    }
}

AlertBox.propTypes = {
    message: PropTypes.array,
    type: PropTypes.string
};

AlertBox.defaultProps = {
    message: [],
    type: "success",
    canTranslate: false
}
export default withSuspense()(withTranslation()(AlertBox));