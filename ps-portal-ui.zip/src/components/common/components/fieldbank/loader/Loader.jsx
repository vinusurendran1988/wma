
import React from 'react';
import { ProgressSpinner } from 'primereact/progressspinner';

export default class Loader extends React.Component {
    render() {
        return <div className="container" style={{textAlign: "center"}}><ProgressSpinner {...this.props}/></div>
    }
}