import React, { Component } from 'react';
import { connect } from 'react-redux';
import { ProgressBar} from 'primereact/progressbar';

class ApiLoader extends Component {

    render() {
        return (
            this.props.inprogress != 0 && <ProgressBar mode="indeterminate" color="#1fadaf" style={{ height: '2px' }}></ProgressBar>
        );
    }
}

function mapStateToProps(state) {
    return {
        inprogress: state.loaderReducer.inprogress
    }
}

export default connect(mapStateToProps, {})(ApiLoader);