import React from 'react';
import parse from 'html-react-parser';


/**
 * @name Custom Link Component
 * 
 * @author Amrutha J Raj
 */
export default class Link extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            value: this.props.value
        }
    }

    componentDidUpdate(prevProps) {
        if ((prevProps.id !== this.props.id) || (prevProps.value != this.props.value)) {
            this.setState({ value: this.props.value })
        }
    }

    handleChange(value) {
        this.setState({ value })
        return value
    }

    render() {
        const {
            placeholder,
        } = this.props

        const { value } = this.state
        return (
            <div className="form-group">
                <a   href="javascript:void(0)" role="button" onClick={()=>this.props.onClick()}>{placeholder}</a>
            </div>
        )
    }
}

Link.defaultProps = {
    label: "",
    value: "",
    isRequired: false
}