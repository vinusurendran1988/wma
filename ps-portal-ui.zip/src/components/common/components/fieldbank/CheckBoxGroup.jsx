import React from 'react';
import { withSuspense } from '../../utils/';
import { withTranslation } from 'react-i18next';

/**
 * @name Custom Checkbox component.
 * @description Component that consists of a label and multiple checkboxes.
 * 
 * @author Ajmal Aliyar
 */
class CheckBoxGroup extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            selectedValues: this.props.value
        }
    }

    componentDidUpdate(prevProps){
        if(prevProps.value != this.props.value){
            this.setState({selectedValues: this.props.value})
        }
    }

    handleChange(doInclude, value) {
        const { selectedValues } = this.state
        let updatedSelection = selectedValues
        if (doInclude) {
            updatedSelection.push(value)
        } else {
            updatedSelection.splice(updatedSelection.indexOf(value), 1)
        }
        this.setState({ selectedValues: updatedSelection })
        return updatedSelection
    }

    render() {
        const {
            label,
            checkBoxes,
            isRequired,
            onChange,
            testIdentifier,
            t,
            info,
            enabled,
            checkboxGroupClassName
        } = this.props
        const { selectedValues } = this.state

        //TODO replace this id by an actual id from props
        const id = label.replace(/\s/g, '')

        if (checkBoxes.length) {
            return (
                <>
                    <div className="lead"
                        aria-describedby={id}
                    >
                        {label}
                        {isRequired &&
                            <span className="text-warning">*</span>
                        }
                    </div>
                    <div className="row">
                    {checkBoxes.map((checkBox, index) => {
                        return <div key={index} className={checkboxGroupClassName?checkboxGroupClassName:"form-check form-check-inline"}>
                            <input
                                className="form-check-input"
                                type="checkbox"
                                id={checkBox.id}
                                value={checkBox.value}
                                checked={selectedValues.includes(checkBox.value)}
                                onChange={(e) => onChange(this.handleChange(e.target.checked, checkBox.value))}
                                data-test={`${testIdentifier}-${index}`}
                                disabled={!enabled}
                            />
                            <label
                                className="form-check-label"
                                htmlFor={checkBox.id}>{checkBox.label}</label>
                        </div>
                    })}
                    </div>
                    <small id={id} className="form-text text-muted">{info}</small>
                </>
            )
        } else {
            return <p>{t('fieldbank.checkbox_options_empty')}</p>
        }
    }
}

CheckBoxGroup.defaultProps = {
    label: "",
    isRequired: false,
    checkBoxes: [],
    value: []
}

export default withSuspense()(withTranslation()(CheckBoxGroup));