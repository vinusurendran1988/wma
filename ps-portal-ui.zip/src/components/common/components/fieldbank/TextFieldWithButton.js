import React from 'react';
import Button from './Button';


/**
 * @name Custom input field component.
 * @description Component that consists of a input field and button
 * 
 * @author Geo George
 */
export default class TextfieldWithButton extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            value: this.props.value
        }
    }

    componentDidUpdate(prevProps) {
        if ((prevProps.id !== this.props.id) || (prevProps.value != this.props.value)) {
            this.setState({ value: this.props.value })
        }
    }

    handleChange(value) {
        this.setState({ value })
        return value
    }

    render() {
        const {
            label,
            isRequired,
            id,
            onChange,
            info,
            testIdentifier,
            error,
            type,
            enabled,
            placeholder,
            handleOnClick,
            buttonName
        } = this.props
        const { value } = this.state
        return (

            <div className="d-flex align-items-end flex-wrap">
                <div className="form-group flex-grow-1">
                    <label
                        className="d-block"
                        htmlFor={id}
                    >
                        {label}
                        {isRequired &&
                            <span className="text-warning">*</span>
                        }
                    </label>
                    <input
                        className={`${error ? "is-invalid" : ""}`}
                        type={type}
                        aria-required="true"
                        aria-describedby={`${id}_help`}
                        placeholder={placeholder}
                        id={id}
                        value={value}
                        onChange={(e) => onChange(this.handleChange(e.target.value))}
                        data-test={testIdentifier}
                        disabled={!enabled}
                    />
                </div>
                <div className="ml-2 mb-3">
                    <Button
                        className="btn btn-primary"
                        handleOnClick={(e) => handleOnClick(e, value)}
                        id={"check_btn"}
                        data-test="btnCheck"
                        enabled={enabled}
                        label={buttonName} />
                </div>
                <small id={`${id}_help`} className="info w-100">{info}</small>
            </div >
        )
    }
}

TextfieldWithButton.defaultProps = {
    label: "",
    value: "",
    isRequired: false
}