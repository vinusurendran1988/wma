import React from 'react';
import parse from 'html-react-parser';


/**
 * @name Custom TextField component.
 * 
 * @author Amrutha J Raj
 */
export default class LabelTextfield extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            value: this.props.value
        }
    }

    componentDidUpdate(prevProps) {
        if ((prevProps.id !== this.props.id) || (prevProps.value != this.props.value)) {
            this.setState({ value: this.props.value })
        }
    }

    handleChange(value) {
        this.setState({ value })
        return value
    }

    render() {
        const {
            label,
            id
        } = this.props

        const { value } = this.state
        return (
            <div className="form-group">
                <label htmlFor={id}>
                    {parse(label)}
                </label>
                <span>{value}</span>

            </div>
        )
    }
}

LabelTextfield.defaultProps = {
    label: "",
    value: "",
    isRequired: false
}