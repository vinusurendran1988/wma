import React, { Component } from 'react';
import { AutoComplete } from 'primereact/autocomplete';

export default class AutoCompleteField extends Component {

    constructor(props) {
        super(props);
        this.state = {
            suggestions: null,
            selected: props.selected,
            loadingData: true
        }
        this.suggestResult = this.suggestResult.bind(this)
    }

    componentDidUpdate(prevProps){
        if(this.props.selected != prevProps.selected){
            this.setState({
                selected: this.props.selected
            })
        }
        if(prevProps.list != this.props.list && this.props.list.length>0){
            this.setState(({
                loadingData: false
            }))
        }
    }

    suggestResult(event) {
        setTimeout(() => {
            var results = this.props.list.filter(obj => {
                return obj.name.toLowerCase().startsWith(event.query.toLowerCase());
            })
            this.setState({ suggestions: results });
        }, 500);
    }

    render() {
        return <AutoComplete
            className={this.props.className}
            forceSelection
            value={this.state.selected}
            suggestions={this.state.suggestions}
            completeMethod={this.suggestResult}
            field="name"
            placeholder={this.props.placeholder}
            minLength={1}
            onBlur={(e) => {
                if (!e.target.value) {
                    this.props.handleSelectEvent({ name: "", value: "" });
                }
            }
            }
            onChange={(e) => {
                this.setState({
                    selected: e.target.value
                })
                if(e.target.value && typeof e.target.value == "object"){
                    if (e.target.value.value) {
                        this.props.handleSelectEvent(e.target.value);
                    }
                } 
            }}
            data-test= {this.props.dataForTest}
            {...this.props}
        />
    }
}