import React from 'react'
import Gender from '../masterservice/Gender';
import MobileNumber from '../masterservice/MobileNumber';
import FirstName from '../masterservice/FirstName';
import Country from '../masterservice/Country';
import PreferredLanguage from '../masterservice/PreferredLanguage';
import SecurityQuestions from '../../../ui/security/securityquestions'
import CustomDropdown from '../masterservice/CustomDropdown';
import ReferralEmail from '../../../ui/referral/ReferralEmail';

export default function FieldBank(propsParam) {
    const renderSwitchCases = (props) => {
        const { field, t } = props
        const userDefinedClass = props.className ? props.className : "col-lg-6 "
        switch (field.name) {
            case 'userId':
            case "lastName":
            case "koreanName":
            case "emailAddress":
            case "address1":
            case "address2":
            case "companyName":
            case "jobTitle":
            case "companyAddress":
            case "businessEmail":
            case "zip":
            case "department":
                return <div className={userDefinedClass} key={field.id}>
                    <div className="form-group">
                        <label htmlFor={field.id}>{t(`form.${field.name}.label`)} {field.isRequired && <span className="text-warning">*</span>}</label>
                        <input className="" type="text" aria-required="true" placeholder={t(`form.${field.name}.placeholder`)} id={field.id} value={props.data[field.name]} onChange={(e) => props.handleChange(field.name, e)} data-test={field.name}/>
                    </div>
                </div>
            case 'memberPin':
            case 'oldPin':
            case 'newPin':
            case 'confirmPin':
                return <div className={userDefinedClass} key={field.id}>
                    <div className="form-group">
                        <label htmlFor={field.id}>{t(`form.${field.name}.label`)} {field.isRequired && <span className="text-warning">*</span>}</label>
                        <input className="" maxLength={4} type="password" aria-required="true" placeholder={t(`form.${field.name}.placeholder`)} id={field.id} value={(props.data && props.data[field.name])?props.data[field.name]:''} onChange={(e) => props.handleNumberInput(field.name, e)} data-test={field.name}/>
                    </div>
                </div>
            case 'password':
            case 'confirmPassword':
            case 'oldPassword':
            case 'newPassword':
                return <div className={userDefinedClass} key={field.id}>
                    <div className="form-group">
                        <label htmlFor={field.id}>{t(`form.${field.name}.label`)} {field.isRequired && <span className="text-warning">*</span>}</label>
                        <input className="" type="password" aria-required="true" placeholder={t(`form.${field.name}.placeholder`)} id={field.id} value={(props.data && props.data[field.name])?props.data[field.name]:''} onChange={(e) => props.handleChange(field.name, e)} data-test={field.name}/>
                    </div>
                </div>
            
            case "firstName":
                return <div className={userDefinedClass} key={field.id}>
                    <FirstName
                        {...props}
                    />
                </div>
            
            case "preferredLanguage":
                return <div className={userDefinedClass} key={field.id}>
                    <PreferredLanguage
                    {...props}
                    />
                </div>
            case "dob":
                return <div className={userDefinedClass} key={field.id}>
                    <div className="form-group">
                        <label htmlFor={field.id}>{t(`form.${field.name}.label`)} {field.isRequired && <span className="text-warning">*</span>}</label>
                        <input className="" type="date" aria-required="true" placeholder={t(`form.${field.name}.placeholder`)} id={field.id} value={props.data[field.name]} onChange={(e) => props.handleChange(field.name, e)} data-test={field.name}/>
                    </div>
                </div>
            case "gender":
                return <div className={userDefinedClass} key={field.id}>
                    <Gender
                        {...props}
                        label={t(`form.${field.name}.placeholder`)}
                        key={field.id}
                        id={field.id}
                        value={props.data[field.name]}
                        onChange={(e) => props.handleChange(field.name, e)
                        }
                    /></div>
            
            case "mobileNumber":
                return <div className={userDefinedClass} key={field.id}>
                    <MobileNumber
                        tag="mobileISDCode"
                        label={t(`form.${field.name}.label`)}
                        placeholder={t(`form.${field.name}.placeholder`)}
                        isdCode={props.data.mobileISDCode}
                        phNumber={props.data.mobileNumber}
                        {...props}
                    />
                </div>
            case "memberNationality":
            case "country":
            case "countryOfResidence":
                return <div className={userDefinedClass} key={field.id}>
                    <Country
                        label = {`form.${field.name}.label`}
                        placeholder = {`form.${field.name}.placeholder`}
                        {...props}
                    />
                </div>
            case "phone":
                return <div className={userDefinedClass} key={field.id}>
                    <MobileNumber
                        tag="phoneISDCode"
                        label={t(`form.${field.name}.label`)}
                        placeholder={t(`form.${field.name}.placeholder`)}
                        isdCode={props.phoneISDCode}
                        phNumber={props.phoneNumber}
                        {...props}
                    />
                </div>
            case "companyPhone":
                return <div className={userDefinedClass} key={field.id}>
                    <MobileNumber
                        tag="companyPhoneISDCode"
                        label={t(`form.${field.name}.label`)}
                        placeholder={t(`form.${field.name}.placeholder`)}
                        isdCode={props.companyPhoneISDCode}
                        phNumber={props.companyPhoneNumber}
                        {...props}
                    />
                </div>
            case 'additionalSecurityInfo':
                return <div className={userDefinedClass}>
                    <div className="alert alert-warning" role="alert"><i className="fa fa-exclamation-circle"
                        aria-hidden="true"></i> {t(field.messageId)}
                    </div>
                </div>
            case "securityQuestions":
                return(
                    <SecurityQuestions
                        numberOfQuestions={props.count}
                        errorIndices={props.errorIndices}
                        onChange={securityQuestions => {
                            props.manageSecurityQuestions(securityQuestions);
                        }}
                        idx={props.idx}
                        reset={props.resetForm}
                        values={props.values}
                        type={props.securityQuestionType}
                        filterType={props.securityQuestionFilterType}
                        filterValue={props.securityQuestionFilterValue}
                    />)
            case "preferredAddress":
            case "preferredEmailAddress":
            case "preferredPhoneNumber":
                return <div className={userDefinedClass} key={field.id}>
                    <CustomDropdown
                        label = {t(`form.${field.name}.label`)}
                        dropDownValue={props.data[field.name]?props.data[field.name]:(field.defaultValue?field.defaultValue:"")}
                        defaultSelectValue= {t(`form.${field.name}.placeholder`)}
                        sourceKey={field.sourceKey}
                        {...props}
                />
                </div>
            case "referralEmail":
                return <ReferralEmail 
                    {...props}
                />
            case "referralDescription":
                return <div className={userDefinedClass}>
                    <div className="form-group">
                        <label htmlFor={field.id}> {props.label}{field.isRequired && <span className="text-warning">*</span>}</label>
                        <textarea 
                            id={field.id} 
                            className="" 
                            placeholder={props.placeholder} 
                            minLength={field.minimumCharacter} 
                            maxLength={field.maximumCharacter} 
                            value={props.value?props.value:""} 
                            onChange={(e)=>props.handleChange(e)} 
                            data-test={field.name}></textarea>
                    </div>
                </div>
            default: return <div></div>

        }
    }
    return renderSwitchCases(propsParam)
}