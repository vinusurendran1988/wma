import React from 'react'
import { fetchMasterData } from '../../middleware/redux/commonAction';
import { withSuspense } from '../../utils';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import {
    CONFIG_SECTION_DEFAULT, DATA_SOURCE_DEFAULT, DATA_SOURCE_MASTER
} from '../../utils/Constants'
import { getCurrentProgramFromDefaultConfig } from '../../utils/configurationFiles.utils';

class CustomDropdown extends React.Component {

    constructor(props){
        super(props);
        this.state={
            _values:[]
        }
    }

    componentDidMount() {
        const { field, masterEntityLookup } = this.props
        if (field.source == DATA_SOURCE_MASTER && Object.keys(masterEntityLookup).length > 0 &&
            (!this.props.masterValues || this.props.masterValues[this.props.sourceKey].length != 0)) {
            this.props.fetchMasterData(this.props.sourceKey, masterEntityLookup)
        }
        if(field.defaultValue){
            this.props.handleChange(field.name, {target:{value: field.defaultValue}})
        }
    }

    componentDidUpdate(prevProps, prevState) {
        if(JSON.stringify(prevProps.masterValues)!= JSON.stringify(this.props.masterValues)){
            this.setState({
                _values: this.props.masterValues[this.props.sourceKey]
            })
        }
        if (this.props.field.source == DATA_SOURCE_DEFAULT) {

            const config = getCurrentProgramFromDefaultConfig(this.props.defaultConfig)
            if (config && Object.keys(config).length > 0 && config.data[this.props.field.sourceKey] &&
                config.data[this.props.field.sourceKey] != this.state[this.props.field.sourceKey])

                this.setState({
                    [this.props.field.sourceKey]: config.data[this.props.field.sourceKey]
                })
        }
    }

    render() {
        const { field, label, dropDownValue, defaultSelectValue  } = this.props
        return (
            // <div className="input-group" key={field.id}>
            <div className="form-group" key={field.id}>
                <label htmlFor={field.id}>{label} {field.isRequired && <span className="text-warning">*</span>}</label>
                <div className="input-group-prepend">
                    <select className="" value={dropDownValue} id={field.id} onChange={(e) => { this.props.handleChange(field.name, e) }} data-test={field.name}>
                        {!field.defaultValue&&<option value="">{defaultSelectValue}</option>}
                        {
                                        field.source == DATA_SOURCE_MASTER &&
                                        this.state._values.map((title, index) => {
                                            return <option key={index} value={title.CountryCode}>{title.CountryName}</option>
                                        })
                                    }
                                    {
                                        field.source == DATA_SOURCE_DEFAULT && this.state[field.sourceKey] &&
                                        this.state[field.sourceKey].map((title, index) => {
                                            return <option key={index} value={title.key}>{title.value}</option>
                                        })
                                    }
                                    {
                                        field.source == "values" &&
                                        field.values.map((title, index) => {
                                            return <option key={index} value={title.key}>{title.value}</option>
                                        })
                                    }
                    </select>
                </div>
            </div>
        )
    }
}

CustomDropdown.defaultProps = {
    value: '',
    label: '',
    onChange: () => { }
}

const mapStateToProps = state => {
    return ({
        masterValues: state.masterData,
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        masterEntityLookup: state.masterEntityDataReducer.masterEntityLookup
    })
}

const mapDispatchToProps = { fetchMasterData }

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(CustomDropdown)));