import React from 'react';
import { CONFIG_SECTION_DEFAULT, CONFIG_SECTION_ENROL } from "../../utils/Constants";
import moxios from 'moxios';
import { mount } from 'enzyme';
import { testStore } from '../../utils';
import ReactTestUtils from 'react-dom/test-utils';
import {
    fetchConfiguration, fetchMasterData
} from '../../middleware/redux/commonAction'
import { Provider } from 'react-redux'

import {
    findByTestAttr,
    findComponent,
    mockServiceResponse
} from '../../testUtils';
import Enrolment from '../../../ui/enrolment';
import {
    COUNTRY_ISD,
    TITLE_GENDER,
    LANGUAGE
} from '../../utils/Constants'

let store;
let rootComponent;
let component;

const setUpEnrol = (props = {}) => {
    store = testStore({})
    //props.handleChange = jest.fn()
    rootComponent = mount(<Provider store={store}>
        <Enrolment {...props} store={store} />
    </Provider>);
    component = findComponent(rootComponent, 'Enrolment');
};

describe('Enrolment Action: ', () => {
    beforeEach(() => {
        store = undefined
        moxios.install();
        setUpEnrol({});
        window.sessionStorage.setItem("companyCode", "IBS")
        window.sessionStorage.setItem("programCode", "PRG14")
    });


    afterEach(() => {
        moxios.uninstall();
    });

    it('enrolment: Fetch data from master', () => {
        const enrolmentComponent = findByTestAttr(component, 'enrolmentComponent');
        expect(enrolmentComponent.length).toBe(1);

        mockServiceResponse(CONFIG_RESPONSE_MASTER)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_ENROL))
                .then(() => {
                    let newState = store.getState();
                    rootComponent = rootComponent.update();
                    component = findComponent(rootComponent, 'Enrolment');
                    expect(newState.configurationReducer[CONFIG_SECTION_ENROL]).toBe(CONFIG_RESPONSE_MASTER.object);

                    mockServiceResponse(MASTER_CONFIG_COUNTRY)
                    return ReactTestUtils.act(() => {
                        return store.dispatch(fetchMasterData(COUNTRY_ISD))
                            .then(() => {
                                mockServiceResponse(MASTER_CONFIG_GENDER)
                                return ReactTestUtils.act(() => {
                                    return store.dispatch(fetchMasterData(TITLE_GENDER))
                                        .then(() => {
                                            mockServiceResponse(MASTER_CONFIG_LANG)
                                            return ReactTestUtils.act(() => {
                                                return store.dispatch(fetchMasterData(LANGUAGE))
                                                    .then(() => {

                                                        newState = store.getState();
                                                        expect(newState.masterData[LANGUAGE].masterRecordList).toBe(MASTER_CONFIG_LANG.masterRecordList)
                                                        expect(newState.masterData[TITLE_GENDER].masterRecordList).toBe(MASTER_CONFIG_GENDER.masterRecordList)
                                                        expect(newState.masterData[COUNTRY_ISD].masterRecordList).toBe(MASTER_CONFIG_COUNTRY.masterRecordList)

                                                        const memberNationality = findByTestAttr(component, 'memberNationality');
                                                        expect(memberNationality.length).toBe(1);
                                                        memberNationality.simulate('change', { target: { value: "IN", classList: { value: "test" } } })

                                                        const gender = findByTestAttr(component, 'gender');
                                                        expect(gender.length).toBe(1);
                                                        gender.simulate('change', { target: { value: "M", classList: { value: "test" } } })
                                                    })
                                            })

                                        })
                                })

                            })
                    })
                })
        });

    })

    it('enrolment: Fetch data from default', () => {
        const enrolmentComponent = findByTestAttr(component, 'enrolmentComponent');
        expect(enrolmentComponent.length).toBe(1);

        mockServiceResponse(CONFIG_RESPONSE_DEFAULT)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_ENROL))
                .then(() => {
                    let newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_ENROL]).toBe(CONFIG_RESPONSE_DEFAULT.object);
                    mockServiceResponse(DEFAULT_RESPONSE)
                    return ReactTestUtils.act(() => {
                        return store.dispatch(fetchConfiguration(CONFIG_SECTION_DEFAULT))
                            .then(() => {
                                newState = store.getState();
                                rootComponent = rootComponent.update();
                                component = findComponent(rootComponent, 'Enrolment');
                                expect(newState.configurationReducer[CONFIG_SECTION_DEFAULT]).toStrictEqual(DEFAULT_RESPONSE.object);

                                const memberNationality = findByTestAttr(component, 'memberNationality');
                                expect(memberNationality.length).toBe(1);
                                memberNationality.simulate('change', { target: { value: "IN", classList: { value: "test" } } })
                                
                                const title = findByTestAttr(component, 'title');
                                expect(title.length).toBe(1);
                                title.simulate('change', { target: { value: "MR", classList: { value: "test" } } })

                                const firstName = findByTestAttr(component, 'firstName');
                                expect(firstName.length).toBe(1);
                                firstName.simulate('change', { target: { value: "tester", classList: { value: "test" } } })

                                const mobileISDCode = findByTestAttr(component, 'mobileISDCode');
                                expect(mobileISDCode.length).toBe(1);
                                mobileISDCode.simulate('change', { target: { value: "+91", classList: { value: "test" } } })

                                const mobileNumber = findByTestAttr(component, 'mobileNumber');
                                expect(mobileNumber.length).toBe(1);
                                mobileNumber.simulate('change', { target: { value: "1234567890", classList: { value: "test" } } })

                                const preferredLanguage = findByTestAttr(component, 'preferredLanguage');
                                expect(preferredLanguage.length).toBe(1);
                                preferredLanguage.simulate('change', { target: { value: "EN", classList: { value: "test" } } })
                                // mockServiceResponse(DEFAULT_RESPONSE)
                                // return ReactTestUtils.act(() => {
                                //     return store.dispatch(fetchConfiguration(CONFIG_SECTION_DEFAULT))
                                //         .then(() => {

                                //         })
                                // }); 
                                
                            })
                    });
                })
        });

    })

    it('enrolment: Fetch data from values', () => {
        const enrolmentComponent = findByTestAttr(component, 'enrolmentComponent');
        expect(enrolmentComponent.length).toBe(1);

        mockServiceResponse(CONFIG_RESPONSE_VALUES)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_ENROL))
                .then(() => {
                    let newState = store.getState();
                    rootComponent = rootComponent.update();
                    component = findComponent(rootComponent, 'Enrolment');
                    expect(newState.configurationReducer[CONFIG_SECTION_ENROL]).toBe(CONFIG_RESPONSE_VALUES.object);

                    mockServiceResponse(DEFAULT_RESPONSE)
                    return ReactTestUtils.act(() => {
                        return store.dispatch(fetchConfiguration(CONFIG_SECTION_DEFAULT))
                            .then(() => {
                                newState = store.getState();
                                rootComponent = rootComponent.update();
                                component = findComponent(rootComponent, 'Enrolment');
                                expect(newState.configurationReducer[CONFIG_SECTION_DEFAULT]).toStrictEqual(DEFAULT_RESPONSE.object);

                                const memberNationality = findByTestAttr(component, 'memberNationality');
                                expect(memberNationality.length).toBe(1);
                                memberNationality.simulate('change', { target: { value: "IN", classList: { value: "test" } } })
                            })
                    });
                })
        });

    })


})


const CONFIG_RESPONSE_MASTER = {"statuscode":"200","statusMessage":"SUCCESS","object":{"section":"enrol","companyCode":"IBS","programCode":"PRG14","activationType":"twoStep/singleStep","defaults":{"membershipStatus":"A","operationFlag":"I"},"password":{"pattern":"((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&.,{}()?-_=+<>*!^/]).{8,20})"},"dynamicAttributes":{"enrol":[{"attributeCode":"68","attributeName":"User Id","attributeValue":"","attributeMapping":"userId","type":"C","operationFlag":"I"},{"attributeCode":"23","attributeName":"English Name","attributeValue":"","attributeMapping":"koreanName","type":"P","operationFlag":"I"},{"attributeCode":"18","attributeName":"Secret Question","attributeValue":"","attributeMapping":"","type":"P","operationFlag":"I"},{"attributeCode":"19","attributeName":"Answer","attributeValue":"","attributeMapping":"","type":"P","operationFlag":"I"}],"activation":[{"attributeCode":"33","attributeName":"Email Address Verified","attributeValue":"Y","attributeMapping":"","type":"P","operationFlag":"I"}]},"accountStatus":"A","enrolmentSource":"W","membershipType":"I","preferredAddress":"H","preferredEmailAddress":"H","preferredPhoneNumber":"HP","industryType":"N","incomeBand":"2","addressTypes":["H","B"],"memberReferralType":"M","ui":{"isLayoutSequential":true,"request":{"additionalMapping":[{"name":["firstName","lastName"],"path":"object.memberAccount.memberProfile.individualInfo.displayName"},{"name":["dynamicAttributes"],"path":"object.memberAccount.memberDynamicAttributes"}]},"layout":{"order":["loginInfo","personalInfo","contactInfo","companyInfo","activation","preferredCommunication","agreeTerms"],"elements":{"loginInfo":{"fields":[{"name":"userId","id":"id-user-id","visibility":true,"isRequired":true,"path":"object.memberAccount.memberProfile.userId","validation":[{"pattern":"^[a-zA-Z0-9]{1,15}$","customMessageId":"enrolment.form.userId"}]},{"name":"memberPin","id":"id-member-pin","visibility":true,"isRequired":true,"path":"object.memberAccount.memberProfile.pin","validation":[{"pattern":"^[0-9]{4}$","customMessageId":"form.memberPin.errorMessage"}]},{"name":"password","id":"id-password","visibility":true,"isRequired":true,"validation":[{"pattern":"^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$","customMessageId":"form.password.errorMessage"}]},{"name":"confirmPassword","id":"id-confirm-password","path":"object.memberAccount.memberProfile.customerPassword","visibility":true,"isRequired":true,"validation":[{"pattern":"^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$","customMessageId":"form.confirmPassword.errorMessage.invalid"},{"pattern":"^[password]$","fields":["password"],"customMessageId":"form.confirmPassword.errorMessage.unEqual"}]}]},"personalInfo":{"fields":[{"name":"firstName","id":"id-first-name","additional":[{"id":"id-title","name":"title","type":"lov","source":"master","values":[{"key":"MR","value":"Mr"},{"key":"MRS","value":"Mrs"}],"sourceKey":"titleMaster","isRequired":true,"path":"object.memberAccount.memberProfile.individualInfo.title","validation":[{"pattern":"^[a-zA-Z]{1,20}$","customMessageId":"form.title.errorMessage"}]}],"visibility":true,"isRequired":true,"path":"object.memberAccount.memberProfile.individualInfo.givenName","validation":[{"pattern":"[ a-zA-Z]{1,20}$","customMessageId":"form.firstName.errorMessage"}]},{"name":"lastName","id":"id-last-name","visibility":true,"isRequired":true,"path":"object.memberAccount.memberProfile.individualInfo.familyName","validation":[{"pattern":"[ a-zA-Z]{1,20}$","customMessageId":"form.lastName.errorMessage"}]},{"name":"koreanName","id":"id-korean-name","visibility":true,"isRequired":true,"path":"object.memberAccount.memberProfile.userId","validation":[{"pattern":"[ a-zA-Z]{1,20}$","customMessageId":"enrolment.form.koreanName"}]},{"name":"memberNationality","id":"id-member-nationality","type":"lov","source":"master","sourceKey":"countryMaster","visibility":true,"isRequired":true,"path":"object.memberAccount.memberProfile.individualInfo.memberNationality","validation":[{"pattern":"[A-Z]{2}$","customMessageId":"form.memberNationality.errorMessage"}]},{"name":"countryOfResidence","id":"id-country-of-residence","type":"lov","source":"master","sourceKey":"countryMaster","visibility":true,"isRequired":true,"path":"object.memberAccount.memberProfile.individualInfo.countryOfResidence","validation":[{"pattern":"[A-Z]{2}$","customMessageId":"form.countryOfResidence.errorMessage"}]},{"name":"preferredLanguage","id":"id-preferred-language","type":"lov","source":"master","sourceKey":"languageMaster","path":"object.memberAccount.memberProfile.individualInfo.preferredLanguage","visibility":true,"isRequired":true,"validation":[{"pattern":"[A-Z]{2}$","customMessageId":"form.preferredLanguage.errorMessage"}]},{"name":"dob","id":"id-dob","visibility":true,"isRequired":true,"path":"object.memberAccount.memberProfile.individualInfo.dateOfBirth","validation":[{"pattern":"([12]\\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))","customMessageId":"form.dob.errorMessage"}]},{"name":"gender","id":"id-gender","type":"lov","source":"master","sourceKey":"gender","path":"object.memberAccount.memberProfile.individualInfo.gender","visibility":true},{"name":"emailAddress","id":"id-email-id","visibility":true,"isRequired":true,"path":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].emailAddress","validation":[{"pattern":"\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$","customMessageId":"form.emailAddress.errorMessage"}]},{"name":"mobileNumber","id":"id-mobile-number","additional":[{"id":"id-isd-code","name":"mobileISDCode","type":"lov","source":"master","sourceKey":"countryMaster","path":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].mobileISDCode","isRequired":true,"validation":[{"pattern":"(\\+?\\d{1,3}|\\d{1,4})$","customMessageId":"form.mobileNumberISDCode.errorMessage"}]}],"visibility":true,"isRequired":true,"path":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].mobileNumber","validation":[{"pattern":"\\d+$","customMessageId":"form.mobileNumber.errorMessage"}]}]},"contactInfo":{"fields":[{"name":"address1","id":"id-address-1","visibility":true,"path":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].addressLine1"},{"name":"address2","id":"id-address-2","visibility":true,"path":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].addressLine2"},{"name":"country","id":"id-country","type":"lov","source":"master","sourceKey":"countryMaster","visibility":true,"isRequired":false,"path":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].country","validation":[{"pattern":"[A-Z]{2}$","customMessageId":"form.country.errorMessage"}]},{"name":"zip","id":"id-zip","visibility":true,"path":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].zipCode"},{"name":"phone","id":"id-phone","additional":[{"id":"id-phone-isd-code","name":"phoneISDCode","type":"lov","source":"master","sourceKey":"countryMaster","isRequired":false,"path":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].phoneISDCode","validation":[{"pattern":"(\\+?\\d{1,3}|\\d{1,4})$","customMessageId":"form.phoneISDCode.errorMessage"}]}],"path":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].phoneNumber","visibility":true}]},"companyInfo":{"fields":[{"name":"companyName","id":"id-company-name","visibility":true,"path":"object.memberAccount.memberProfile.individualInfo.companyName"},{"name":"jobTitle","id":"id-job-title","visibility":true,"path":"object.memberAccount.memberProfile.individualInfo.designation"},{"name":"companyAddress","id":"id-company-address","visibility":true,"path":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[1].addressLine1"},{"name":"companyPhone","id":"id-company-phone","visibility":true,"path":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[1].phoneNumber","additional":[{"id":"id-company-phone-isd-code","name":"companyPhoneISDCode","type":"lov","source":"master","sourceKey":"countryMaster","isRequired":false,"path":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[1].phoneISDCode","validation":[{"pattern":"(\\+?\\d{1,3}|\\d{1,4})$","customMessageId":"form.mobileNumberISDCode.errorMessage"}]}]},{"name":"businessEmail","id":"id-business-email","visibility":true,"path":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[1].emailAddress","validation":[{"pattern":"\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$","customMessageId":"form.businessEmail.errorMessage"}]}]},"agreeTerms":{"fields":[{"name":"agreeTerms","id":"id-agree-terms","visibility":true,"isRequired":true,"validation":[{"pattern":"^(true)$","customMessageId":"form.agreeTerms.errorMessage"}]},{"name":"privacyPolicy","id":"id-agree-privacy-policy","visibility":true,"isRequired":true,"validation":[{"pattern":"^(true)$","customMessageId":"form.privacyPolicy.errorMessage"}]},{"name":"thirdPartyPolicy","id":"id-third-party-policy","visibility":true},{"name":"marketingAdvt","id":"id-marketing-advt","visibility":true},{"name":"agreeAll","id":"id-agree-all","visibility":true}]},"preferredCommunication":{"fields":[{"name":"preferredAddress","id":"id-preferred-address","visibility":true,"isRequired":true,"path":"object.memberAccount.memberProfile.individualInfo.preferredAddress","source":"values","defaultValue":"H","values":[{"key":"H","value":"Home"},{"key":"B","value":"Business"}]},{"name":"preferredEmailAddress","id":"id-preferred-emailAddress","visibility":true,"isRequired":true,"path":"object.memberAccount.memberProfile.individualInfo.preferredEmailAddress","source":"values","defaultValue":"H","values":[{"key":"H","value":"Home"},{"key":"B","value":"Business"}]},{"name":"preferredPhoneNumber","id":"id-preferred-phoneNumber","visibility":true,"isRequired":true,"path":"object.memberAccount.memberProfile.individualInfo.preferredPhoneNumber","source":"values","defaultValue":"HP","values":[{"key":"HP","value":"Home"},{"key":"BP","value":"Business"}]}]},"activation":{"fields":[{"name":"","id":"","visibility":true}]}}}}}}
const CONFIG_RESPONSE_DEFAULT = {"statuscode":"200","statusMessage":"SUCCESS","object":{"section":"enrol","companyCode":"IBS","programCode":"PRG14","activationType":"twoStep/singleStep","defaults":{"membershipStatus":"A","operationFlag":"I"},"password":{"pattern":"((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&.,{}()?-_=+<>*!^/]).{8,20})"},"dynamicAttributes":{"enrol":[{"attributeCode":"68","attributeName":"User Id","attributeValue":"","attributeMapping":"userId","type":"C","operationFlag":"I"},{"attributeCode":"23","attributeName":"English Name","attributeValue":"","attributeMapping":"koreanName","type":"P","operationFlag":"I"},{"attributeCode":"18","attributeName":"Secret Question","attributeValue":"","attributeMapping":"","type":"P","operationFlag":"I"},{"attributeCode":"19","attributeName":"Answer","attributeValue":"","attributeMapping":"","type":"P","operationFlag":"I"}],"activation":[{"attributeCode":"33","attributeName":"Email Address Verified","attributeValue":"Y","attributeMapping":"","type":"P","operationFlag":"I"}]},"accountStatus":"A","enrolmentSource":"W","membershipType":"I","preferredAddress":"H","preferredEmailAddress":"H","preferredPhoneNumber":"HP","industryType":"N","incomeBand":"2","addressTypes":["H","B"],"memberReferralType":"M","ui":{"isLayoutSequential":true,"request":{"additionalMapping":[{"name":["firstName","lastName"],"path":"object.memberAccount.memberProfile.individualInfo.displayName"},{"name":["dynamicAttributes"],"path":"object.memberAccount.memberDynamicAttributes"}]},"layout":{"order":["loginInfo","personalInfo","contactInfo","companyInfo","activation","preferredCommunication","agreeTerms"],"elements":{"loginInfo":{"fields":[{"name":"userId","id":"id-user-id","visibility":true,"isRequired":true,"path":"object.memberAccount.memberProfile.userId","validation":[{"pattern":"^[a-zA-Z0-9]{1,15}$","customMessageId":"enrolment.form.userId"}]},{"name":"memberPin","id":"id-member-pin","visibility":true,"isRequired":true,"path":"object.memberAccount.memberProfile.pin","validation":[{"pattern":"^[0-9]{4}$","customMessageId":"form.memberPin.errorMessage"}]},{"name":"password","id":"id-password","visibility":true,"isRequired":true,"validation":[{"pattern":"^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$","customMessageId":"form.password.errorMessage"}]},{"name":"confirmPassword","id":"id-confirm-password","path":"object.memberAccount.memberProfile.customerPassword","visibility":true,"isRequired":true,"validation":[{"pattern":"^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$","customMessageId":"form.confirmPassword.errorMessage.invalid"},{"pattern":"^[password]$","fields":["password"],"customMessageId":"form.confirmPassword.errorMessage.unEqual"}]}]},"personalInfo":{"fields":[{"name":"firstName","id":"id-first-name","additional":[{"id":"id-title","name":"title","type":"lov","source":"default","values":[{"key":"MR","value":"Mr"},{"key":"MRS","value":"Mrs"}],"sourceKey":"titleMaster","isRequired":true,"path":"object.memberAccount.memberProfile.individualInfo.title","validation":[{"pattern":"^[a-zA-Z]{1,20}$","customMessageId":"form.title.errorMessage"}]}],"visibility":true,"isRequired":true,"path":"object.memberAccount.memberProfile.individualInfo.givenName","validation":[{"pattern":"[ a-zA-Z]{1,20}$","customMessageId":"form.firstName.errorMessage"}]},{"name":"lastName","id":"id-last-name","visibility":true,"isRequired":true,"path":"object.memberAccount.memberProfile.individualInfo.familyName","validation":[{"pattern":"[ a-zA-Z]{1,20}$","customMessageId":"form.lastName.errorMessage"}]},{"name":"koreanName","id":"id-korean-name","visibility":true,"isRequired":true,"path":"object.memberAccount.memberProfile.userId","validation":[{"pattern":"[ a-zA-Z]{1,20}$","customMessageId":"enrolment.form.koreanName"}]},{"name":"memberNationality","id":"id-member-nationality","type":"lov","source":"default","sourceKey":"countryMaster","visibility":true,"isRequired":true,"path":"object.memberAccount.memberProfile.individualInfo.memberNationality","validation":[{"pattern":"[A-Z]{2}$","customMessageId":"form.memberNationality.errorMessage"}]},{"name":"countryOfResidence","id":"id-country-of-residence","type":"lov","source":"default","sourceKey":"countryMaster","visibility":true,"isRequired":true,"path":"object.memberAccount.memberProfile.individualInfo.countryOfResidence","validation":[{"pattern":"[A-Z]{2}$","customMessageId":"form.countryOfResidence.errorMessage"}]},{"name":"preferredLanguage","id":"id-preferred-language","type":"lov","source":"default","sourceKey":"languageMaster","path":"object.memberAccount.memberProfile.individualInfo.preferredLanguage","visibility":true,"isRequired":true,"validation":[{"pattern":"[A-Z]{2}$","customMessageId":"form.preferredLanguage.errorMessage"}]},{"name":"dob","id":"id-dob","visibility":true,"isRequired":true,"path":"object.memberAccount.memberProfile.individualInfo.dateOfBirth","validation":[{"pattern":"([12]\\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))","customMessageId":"form.dob.errorMessage"}]},{"name":"gender","id":"id-gender","type":"lov","source":"default","sourceKey":"gender","path":"object.memberAccount.memberProfile.individualInfo.gender","visibility":true},{"name":"emailAddress","id":"id-email-id","visibility":true,"isRequired":true,"path":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].emailAddress","validation":[{"pattern":"\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$","customMessageId":"form.emailAddress.errorMessage"}]},{"name":"mobileNumber","id":"id-mobile-number","additional":[{"id":"id-isd-code","name":"mobileISDCode","type":"lov","source":"default","sourceKey":"countryMaster","path":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].mobileISDCode","isRequired":true,"validation":[{"pattern":"(\\+?\\d{1,3}|\\d{1,4})$","customMessageId":"form.mobileNumberISDCode.errorMessage"}]}],"visibility":true,"isRequired":true,"path":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].mobileNumber","validation":[{"pattern":"\\d+$","customMessageId":"form.mobileNumber.errorMessage"}]}]},"contactInfo":{"fields":[{"name":"address1","id":"id-address-1","visibility":true,"path":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].addressLine1"},{"name":"address2","id":"id-address-2","visibility":true,"path":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].addressLine2"},{"name":"country","id":"id-country","type":"lov","source":"default","sourceKey":"countryMaster","visibility":true,"isRequired":false,"path":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].country","validation":[{"pattern":"[A-Z]{2}$","customMessageId":"form.country.errorMessage"}]},{"name":"zip","id":"id-zip","visibility":true,"path":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].zipCode"},{"name":"phone","id":"id-phone","additional":[{"id":"id-phone-isd-code","name":"phoneISDCode","type":"lov","source":"default","sourceKey":"countryMaster","isRequired":false,"path":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].phoneISDCode","validation":[{"pattern":"(\\+?\\d{1,3}|\\d{1,4})$","customMessageId":"form.phoneISDCode.errorMessage"}]}],"path":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].phoneNumber","visibility":true}]},"companyInfo":{"fields":[{"name":"companyName","id":"id-company-name","visibility":true,"path":"object.memberAccount.memberProfile.individualInfo.companyName"},{"name":"jobTitle","id":"id-job-title","visibility":true,"path":"object.memberAccount.memberProfile.individualInfo.designation"},{"name":"companyAddress","id":"id-company-address","visibility":true,"path":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[1].addressLine1"},{"name":"companyPhone","id":"id-company-phone","visibility":true,"path":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[1].phoneNumber","additional":[{"id":"id-company-phone-isd-code","name":"companyPhoneISDCode","type":"lov","source":"default","sourceKey":"countryMaster","isRequired":false,"path":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[1].phoneISDCode","validation":[{"pattern":"(\\+?\\d{1,3}|\\d{1,4})$","customMessageId":"form.mobileNumberISDCode.errorMessage"}]}]},{"name":"businessEmail","id":"id-business-email","visibility":true,"path":"object.memberAccount.memberProfile.individualInfo.memberContactInfos[1].emailAddress","validation":[{"pattern":"\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$","customMessageId":"form.businessEmail.errorMessage"}]}]},"agreeTerms":{"fields":[{"name":"agreeTerms","id":"id-agree-terms","visibility":true,"isRequired":true,"validation":[{"pattern":"^(true)$","customMessageId":"form.agreeTerms.errorMessage"}]},{"name":"privacyPolicy","id":"id-agree-privacy-policy","visibility":true,"isRequired":true,"validation":[{"pattern":"^(true)$","customMessageId":"form.privacyPolicy.errorMessage"}]},{"name":"thirdPartyPolicy","id":"id-third-party-policy","visibility":true},{"name":"marketingAdvt","id":"id-marketing-advt","visibility":true},{"name":"agreeAll","id":"id-agree-all","visibility":true}]},"preferredCommunication":{"fields":[{"name":"preferredAddress","id":"id-preferred-address","visibility":true,"isRequired":true,"path":"object.memberAccount.memberProfile.individualInfo.preferredAddress","source":"default","sourceKey":"preferredAddressTypes","defaultValue":"H","values":[{"key":"H","value":"Home"},{"key":"B","value":"Business"}]},{"name":"preferredEmailAddress","id":"id-preferred-emailAddress","visibility":true,"isRequired":true,"path":"object.memberAccount.memberProfile.individualInfo.preferredEmailAddress","source":"values","defaultValue":"H","values":[{"key":"H","value":"Home"},{"key":"B","value":"Business"}]},{"name":"preferredPhoneNumber","id":"id-preferred-phoneNumber","visibility":true,"isRequired":true,"path":"object.memberAccount.memberProfile.individualInfo.preferredPhoneNumber","source":"values","defaultValue":"HP","values":[{"key":"HP","value":"Home"},{"key":"BP","value":"Business"}]}]},"activation":{"fields":[{"name":"","id":"","visibility":true}]}}}}}}
const CONFIG_RESPONSE_VALUES = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "section": "enrol", "companyCode": "IBS", "programCode": "PRG14", "activationType": "twoStep/singleStep", "defaults": { "membershipStatus": "A", "operationFlag": "I" }, "password": { "pattern": "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&.,{}()?-_=+<>*!^/]).{8,20})" }, "dynamicAttributes": { "enrol": [{ "attributeCode": "68", "attributeName": "User Id", "attributeValue": "", "attributeMapping": "userId", "type": "C", "operationFlag": "I" }, { "attributeCode": "23", "attributeName": "English Name", "attributeValue": "", "attributeMapping": "koreanName", "type": "P", "operationFlag": "I" }, { "attributeCode": "18", "attributeName": "Secret Question", "attributeValue": "", "attributeMapping": "", "type": "P", "operationFlag": "I" }, { "attributeCode": "19", "attributeName": "Answer", "attributeValue": "", "attributeMapping": "", "type": "P", "operationFlag": "I" }], "activation": [{ "attributeCode": "33", "attributeName": "Email Address Verified", "attributeValue": "Y", "attributeMapping": "", "type": "P", "operationFlag": "I" }] }, "accountStatus": "A", "enrolmentSource": "W", "membershipType": "I", "preferredAddress": [{"key":"H","value":"Home"}], "preferredEmailAddress": "H", "preferredPhoneNumber": "HP", "industryType": "N", "incomeBand": "2", "addressType": "H", "memberReferralType": "M", "ui": { "isLayoutSequential": true, "layout": { "order": ["loginInfo", "personalInfo", "contactInfo", "companyInfo", "activation", "agreeTerms"], "elements": { "loginInfo": { "fields": [{ "name": "userId", "id": "id-user-id", "visibility": true, "isRequired": true, "validation": { "pattern": "^[a-zA-Z0-9]{1,15}$", "customMessageId": "enrolment.form.userId" } }, { "name": "memberPin", "id": "id-member-pin", "visibility": true, "isRequired": true, "validation": { "pattern": "^[0-9]{4}$", "customMessageId": "enrolment.form.memberPin" } }, { "name": "password", "id": "id-password", "visibility": true, "isRequired": true, "validation": { "pattern": "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$", "customMessageId": "enrolment.form.password" } }, { "name": "confirmPassword", "id": "id-confirm-password", "visibility": true, "isRequired": true, "validation": { "pattern": "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$", "customMessageId": "enrolment.form.confirmPassword" } }] }, "personalInfo": { "fields": [{ "name": "firstName", "id": "id-first-name", "additional": [{ "id": "id-title", "name": "title", "type": "lov", "source": "values", "values":[{"key": "M","value": "Male"},{"key": "F","value": "Female"}],"sourceKey": "titleMaster", "isRequired": true, "validation": { "pattern": "^[a-zA-Z]{1,20}$", "customMessageId": "enrolment.form.title" } }], "visibility": true, "isRequired": true, "validation": { "pattern": "[ a-zA-Z]{1,20}$", "customMessageId": "enrolment.form.firstName" } }, { "name": "lastName", "id": "id-last-name", "visibility": true, "isRequired": true, "validation": { "pattern": "[ a-zA-Z]{1,20}$", "customMessageId": "enrolment.form.lastName" } }, { "name": "koreanName", "id": "id-korean-name", "visibility": true, "isRequired": true, "validation": { "pattern": "[ a-zA-Z]{1,20}$", "customMessageId": "enrolment.form.koreanName" } }, { "name": "preferredLanguage", "id": "id-preferred-language", "type": "lov", "source": "values","values":[{"key": "EN","value":"ENGLISH"},{"key": "KO","value":"KOREAN"}], "sourceKey": "languageMaster", "visibility": true, "isRequired": true, "validation": { "pattern": "[A-Z]{2}$", "customMessageId": "enrolment.form.preferredLanguage" } }, { "name": "dob", "id": "id-dob", "visibility": true, "isRequired": true, "validation": { "pattern": "([12]\\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))", "customMessageId": "enrolment.form.dob" } }, { "name": "gender", "id": "id-gender", "type": "lov", "source": "values", "sourceKey": "gender", "visibility": true, "values":[{ "key": "U", "value": "Unknown" }, { "key": "M", "value": "Male" }, { "key": "F", "value": "Female" }] }, { "name": "emailAddress", "id": "id-email-id", "visibility": true, "isRequired": true, "validation": { "pattern": "\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$", "customMessageId": "enrolment.form.emailAddress" } }, { "name": "mobileNumber", "id": "id-mobile-number", "additional": [{ "id": "id-isd-code", "name": "mobileISDCode", "type": "lov", "source": "values","values":[{"key":"+91","value":"INDIA"},{"key":"+93","value":"AFGHANISTAN"}],"sourceKey": "countryMaster", "isRequired": true, "validation": { "pattern": "(\\+?\\d{1,3}|\\d{1,4})$", "customMessageId": "enrolment.form.isdCode" } }], "visibility": true, "isRequired": true, "validation": { "pattern": "\\d+$", "customMessageId": "enrolment.form.mobileNumber" } }] }, "contactInfo": { "fields": [{ "name": "address1", "id": "id-addres-1", "visibility": true }, { "name": "address2", "id": "id-addres-2", "visibility": true }, { "name": "memberNationality", "id": "id-natinality", "type": "lov", "source": "values", "values":[{"value":"AFGHANISTAN","key":"AF"},{"value":"ALBANIA","key":"AL"},{"value":"ALGERIA","key":"DZ"},{"value":"AMERICAN SAMOA","key":"AS"},{"value":"ANDORRA","key":"AD"},{"value":"ANGOLA","key":"AO"},{"value":"ANGUILLA","key":"AI"}], "visibility": true, "isRequired": true, "validation": { "pattern": "[A-Z]{2}$", "customMessageId": "enrolment.form.nationality" } }, { "name": "zip", "id": "id-zip", "visibility": true }, { "name": "phone", "id": "id-phone", "visibility": true }] }, "companyInfo": { "fields": [{ "name": "companyName", "id": "id-company-name", "visibility": true }, { "name": "department", "id": "id-department", "visibility": true }, { "name": "jobTitle", "id": "id-job-title", "visibility": true }, { "name": "address", "id": "id-company-address", "visibility": true }, { "name": "phone", "id": "id-company-phone", "visibility": true }, { "name": "businessEmail", "id": "id-business-email", "visibility": true, "validation": { "pattern": "\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$", "customMessageId": "enrolment.form.emailAddress" } }] }, "agreeTerms": { "fields": [{ "name": "agreeTerms", "id": "id-agree-terms", "visibility": true, "isRequired": true, "validation": { "pattern": "^(true)$", "customMessageId": "enrolment.form.termsOfUse" } }, { "name": "privacyPolicy", "id": "id-agree-privacy-policy", "visibility": true, "isRequired": true, "validation": { "pattern": "^(true)$", "customMessageId": "enrolment.form.privacyPolicy" } }, { "name": "thirdPartyPolicy", "id": "id-third-party-policy", "visibility": true }, { "name": "marketingAdvt", "id": "id-marketing-advt", "visibility": true }, { "name": "agreeAll", "id": "id-agree-all", "visibility": true }] }, "activation": { "fields": [{ "name": "", "id": "", "visibility": true }] } } } } } }
const DEFAULT_RESPONSE = { "statuscode": "200", "statusMessage": "SUCCESS", "object": [{ "section": "default", "companyCode": "IBS", "programCode": "PRG14", "skipPinChangeReminder": true, "defaultCurrency": "USD", "defaultPasswordRegex": "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$", "tiers": [{ "name": "Blue", "code": "BLU", "order": "1", "upgradeExpiryInMonths": "12", "downgradeExpiryInMonths": "12" }, { "name": "Silver", "code": "SIL", "order": "2", "upgradeExpiryInMonths": "12", "downgradeExpiryInMonths": "12" }, { "name": "Gold", "code": "GOL", "order": "3", "upgradeExpiryInMonths": "12", "downgradeExpiryInMonths": "12" }, { "name": "Platinum", "code": "PLT", "order": "4", "upgradeExpiryInMonths": "12", "downgradeExpiryInMonths": "12" }, { "name": "Diamond", "code": "DIA", "order": "5", "upgradeExpiryInMonths": "12", "downgradeExpiryInMonths": "12" }],"titleMaster" :[{"key":"MR", "value":"Mr"},{"key":"MRS", "value":"Mrs"}],"currencies": [{ "code": "HKD", "name": "Hong Kong Dollar" }, { "code": "HKD", "name": "Hong Kong Dollar" }, { "code": "TWD", "name": "New Taiwan Dollar" }, { "code": "PHP", "name": "PESO" }, { "code": "KRW", "name": "South Korean Won" }, { "code": "USD", "name": "US Dollar" }, { "code": "VND", "name": "Vietnam Don" }, { "code": "JPY", "name": "Yen" }, { "code": "CNY", "name": "Yuan Renminbi" }], "partners": [{ "value": "KE", "name": "Korean Air" }, { "value": "DL", "name": "Delta Airlines" }, { "value": "EY", "name": "Etihad Airways" }], "cabinClasses": { "KE": [{ "cabinClassCode": "E", "cabinClassName": "Economy" }, { "cabinClassCode": "B", "cabinClassName": "Prestige" }, { "cabinClassCode": "F", "cabinClassName": "First" }] }, "cabinClassBookingClassMapping": { "KE": [{ "cabinClass": "E", "bookingClass": "B" }, { "cabinClass": "B", "bookingClass": "R" }, { "cabinClass": "F", "bookingClass": "F" }] },"isdCodes":[{"key":"+91","value":"INDIA"},{"key":"+93","value":"AFGHANISTAN"}],"languageMaster":[{"LanguageCode":"OM","LanguageName":"AFAN(OROMO)"},{"LanguageCode":"SQ","LanguageName":"ALBANIAN"}],"preferredAddressTypes":[{"key":"H","value":"Home"}], "gender": [{ "key": "U", "value": "Unknown" }, { "key": "M", "value": "Male" }, { "key": "F", "value": "Female" }],"countryMaster":[{"value":"AFGHANISTAN","key":"AF"},{"value":"ALBANIA","key":"AL"},{"value":"ALGERIA","key":"DZ"},{"value":"AMERICAN SAMOA","key":"AS"},{"value":"ANDORRA","key":"AD"},{"value":"ANGOLA","key":"AO"},{"value":"ANGUILLA","key":"AI"}]}] }
const MASTER_CONFIG_COUNTRY = {
    "statuscode": "200",
    "statusMessage": "SUCCESS",
    "object": {
        "companyCode": "IBS",
        "entityCode": "CNTMST",
        "programCode": "PRG14",
        "masterRecordList": [{
            "IsdCode": "+93",
            "DefaultLanguage": "EN",
            "CountryName": "AFGHANISTAN",
            "PostalRegionType": "F",
            "CountryCode": "AF"
        }, {
            "IsdCode": "+355",
            "DefaultLanguage": "EN",
            "CountryName": "ALBANIA",
            "PostalRegionType": "F",
            "CountryCode": "AL"
        }, {
            "IsdCode": "+213",
            "DefaultLanguage": "EN",
            "CountryName": "ALGERIA",
            "PostalRegionType": "F",
            "CountryCode": "DZ"
        }, {
            "IsdCode": "+684",
            "DefaultLanguage": "EN",
            "CountryName": "AMERICAN SAMOA",
            "PostalRegionType": "F",
            "CountryCode": "AS"
        }, {
            "IsdCode": "+376",
            "DefaultLanguage": "EN",
            "CountryName": "ANDORRA",
            "PostalRegionType": "F",
            "CountryCode": "AD"
        }, {
            "IsdCode": "+244",
            "DefaultLanguage": "EN",
            "CountryName": "ANGOLA",
            "PostalRegionType": "F",
            "CountryCode": "AO"
        }, {
            "IsdCode": "+264",
            "DefaultLanguage": "EN",
            "CountryName": "ANGUILLA",
            "PostalRegionType": "F",
            "CountryCode": "AI"
        }, {
            "IsdCode": "+672",
            "DefaultLanguage": "EN",
            "CountryName": "ANTARCTICA",
            "PostalRegionType": "F",
            "CountryCode": "AQ"
        }, {
            "IsdCode": "+268",
            "DefaultLanguage": "EN",
            "CountryName": "ANTIGUA AND BARBUDA",
            "PostalRegionType": "F",
            "CountryCode": "AG"
        }, {
            "IsdCode": "+54",
            "DefaultLanguage": "EN",
            "CountryName": "ARGENTINA",
            "PostalRegionType": "F",
            "CountryCode": "AR"
        }, {
            "IsdCode": "+374",
            "DefaultLanguage": "EN",
            "CountryName": "ARMENIA",
            "PostalRegionType": "F",
            "CountryCode": "AM"
        }, {
            "IsdCode": "+297",
            "DefaultLanguage": "EN",
            "CountryName": "ARUBA",
            "PostalRegionType": "F",
            "CountryCode": "AW"
        }, {
            "IsdCode": "+61",
            "DefaultLanguage": "EN",
            "CountryName": "AUSTRALIA",
            "PostalRegionType": "F",
            "CountryCode": "AU"
        }, {
            "IsdCode": "+43",
            "DefaultLanguage": "EN",
            "CountryName": "AUSTRIA",
            "PostalRegionType": "F",
            "CountryCode": "AT"
        }, {
            "IsdCode": "+994",
            "DefaultLanguage": "EN",
            "CountryName": "AZERBAIDJAN",
            "PostalRegionType": "F",
            "CountryCode": "AZ"
        }, {
            "IsdCode": "+242",
            "DefaultLanguage": "EN",
            "CountryName": "BAHAMAS",
            "PostalRegionType": "F",
            "CountryCode": "BS"
        }, {
            "IsdCode": "+973",
            "DefaultLanguage": "EN",
            "CountryName": "BAHRAIN",
            "PostalRegionType": "F",
            "CountryCode": "BH"
        }, {
            "IsdCode": "+880",
            "DefaultLanguage": "EN",
            "CountryName": "BANGLADESH",
            "PostalRegionType": "F",
            "CountryCode": "BD"
        }, {
            "IsdCode": "+246",
            "DefaultLanguage": "EN",
            "CountryName": "BARBADOS",
            "PostalRegionType": "F",
            "CountryCode": "BB"
        }, {
            "IsdCode": "+375",
            "DefaultLanguage": "EN",
            "CountryName": "BELARUS",
            "PostalRegionType": "F",
            "CountryCode": "BY"
        }, {
            "IsdCode": "+32",
            "DefaultLanguage": "EN",
            "CountryName": "BELGIUM",
            "PostalRegionType": "F",
            "CountryCode": "BE"
        }, {
            "IsdCode": "+501",
            "DefaultLanguage": "EN",
            "CountryName": "BELIZE",
            "PostalRegionType": "F",
            "CountryCode": "BZ"
        }, {
            "IsdCode": "+229",
            "DefaultLanguage": "EN",
            "CountryName": "BENIN",
            "PostalRegionType": "F",
            "CountryCode": "BJ"
        }, {
            "IsdCode": "+441",
            "DefaultLanguage": "EN",
            "CountryName": "BERMUDA",
            "PostalRegionType": "F",
            "CountryCode": "BM"
        }, {
            "IsdCode": "+975",
            "DefaultLanguage": "EN",
            "CountryName": "BHUTAN",
            "PostalRegionType": "F",
            "CountryCode": "BT"
        }, {
            "IsdCode": "+591",
            "DefaultLanguage": "EN",
            "CountryName": "BOLIVIA",
            "PostalRegionType": "F",
            "CountryCode": "BO"
        }, {
            "IsdCode": "+387",
            "DefaultLanguage": "EN",
            "CountryName": "BOSNIA-HERZEGOVINA",
            "PostalRegionType": "F",
            "CountryCode": "BA"
        }, {
            "IsdCode": "+267",
            "DefaultLanguage": "EN",
            "CountryName": "BOTSWANA",
            "PostalRegionType": "F",
            "CountryCode": "BW"
        }, {
            "IsdCode": "+47",
            "DefaultLanguage": "EN",
            "CountryName": "BOUVET ISLAND",
            "PostalRegionType": "F",
            "CountryCode": "BV"
        }, {
            "IsdCode": "+55",
            "DefaultLanguage": "EN",
            "CountryName": "BRAZIL",
            "PostalRegionType": "F",
            "CountryCode": "BR"
        }, {
            "IsdCode": "+246",
            "DefaultLanguage": "EN",
            "CountryName": "BRITISH INDIAN OCEAN TERRITORY",
            "PostalRegionType": "F",
            "CountryCode": "IO"
        }, {
            "IsdCode": "+673",
            "DefaultLanguage": "EN",
            "CountryName": "BRUNEI DARUSSALAM",
            "PostalRegionType": "F",
            "CountryCode": "BN"
        }, {
            "IsdCode": "+359",
            "DefaultLanguage": "EN",
            "CountryName": "BULGARIA",
            "PostalRegionType": "F",
            "CountryCode": "BG"
        }, {
            "IsdCode": "+226",
            "DefaultLanguage": "EN",
            "CountryName": "BURKINA FASO",
            "PostalRegionType": "F",
            "CountryCode": "BF"
        }, {
            "IsdCode": "+257",
            "DefaultLanguage": "EN",
            "CountryName": "BURUNDI",
            "PostalRegionType": "F",
            "CountryCode": "BI"
        }, {
            "IsdCode": "+855",
            "DefaultLanguage": "EN",
            "CountryName": "CAMBODIA, KINGDOM OF",
            "PostalRegionType": "F",
            "CountryCode": "KH"
        }, {
            "IsdCode": "+237",
            "DefaultLanguage": "EN",
            "CountryName": "CAMEROON",
            "PostalRegionType": "F",
            "CountryCode": "CM"
        }, {
            "IsdCode": "+1",
            "DefaultLanguage": "EN",
            "CountryName": "CANADA",
            "PostalRegionType": "F",
            "CountryCode": "CA"
        }, {
            "IsdCode": "+238",
            "DefaultLanguage": "EN",
            "CountryName": "CAPE VERDE",
            "PostalRegionType": "F",
            "CountryCode": "CV"
        }, {
            "IsdCode": "+345",
            "DefaultLanguage": "EN",
            "CountryName": "CAYMAN ISLANDS",
            "PostalRegionType": "F",
            "CountryCode": "KY"
        }, {
            "IsdCode": "+236",
            "DefaultLanguage": "EN",
            "CountryName": "CENTRAL AFRICAN REPUBLIC",
            "PostalRegionType": "F",
            "CountryCode": "CF"
        }, {
            "IsdCode": "+235",
            "DefaultLanguage": "EN",
            "CountryName": "CHAD",
            "PostalRegionType": "F",
            "CountryCode": "TD"
        }, {
            "IsdCode": "+56",
            "DefaultLanguage": "EN",
            "CountryName": "CHILE",
            "PostalRegionType": "F",
            "CountryCode": "CL"
        }, {
            "IsdCode": "+86",
            "DefaultLanguage": "EN",
            "CountryName": "CHINA",
            "PostalRegionType": "F",
            "CountryCode": "CN"
        }, {
            "IsdCode": "+61",
            "DefaultLanguage": "EN",
            "CountryName": "CHRISTMAS ISLAND",
            "PostalRegionType": "F",
            "CountryCode": "CX"
        }, {
            "IsdCode": "+61",
            "DefaultLanguage": "EN",
            "CountryName": "COCOS (KEELING) ISLANDS",
            "PostalRegionType": "F",
            "CountryCode": "CC"
        }, {
            "IsdCode": "+57",
            "DefaultLanguage": "EN",
            "CountryName": "COLOMBIA",
            "PostalRegionType": "F",
            "CountryCode": "CO"
        }, {
            "IsdCode": "+269",
            "DefaultLanguage": "EN",
            "CountryName": "COMOROS",
            "PostalRegionType": "F",
            "CountryCode": "KM"
        }, {
            "IsdCode": "+242",
            "DefaultLanguage": "EN",
            "CountryName": "CONGO",
            "PostalRegionType": "F",
            "CountryCode": "CG"
        }, {
            "IsdCode": "+682",
            "DefaultLanguage": "EN",
            "CountryName": "COOK ISLANDS",
            "PostalRegionType": "F",
            "CountryCode": "CK"
        }, {
            "IsdCode": "+506",
            "DefaultLanguage": "EN",
            "CountryName": "COSTA RICA",
            "PostalRegionType": "F",
            "CountryCode": "CR"
        }, {
            "IsdCode": "+385",
            "DefaultLanguage": "EN",
            "CountryName": "CROATIA",
            "PostalRegionType": "F",
            "CountryCode": "HR"
        }, {
            "IsdCode": "+53",
            "DefaultLanguage": "EN",
            "CountryName": "CUBA",
            "PostalRegionType": "F",
            "CountryCode": "CU"
        }, {
            "IsdCode": "+357",
            "DefaultLanguage": "EN",
            "CountryName": "CYPRUS",
            "PostalRegionType": "F",
            "CountryCode": "CY"
        }, {
            "IsdCode": "+420",
            "DefaultLanguage": "EN",
            "CountryName": "CZECH REPUBLIC",
            "PostalRegionType": "F",
            "CountryCode": "CZ"
        }, {
            "IsdCode": "+243",
            "DefaultLanguage": "EN",
            "CountryName": "DEMOCRATIC REPUBLIC OF THE CONGO",
            "PostalRegionType": "F",
            "CountryCode": "CD"
        }, {
            "IsdCode": "+45",
            "DefaultLanguage": "EN",
            "CountryName": "DENMARK",
            "PostalRegionType": "F",
            "CountryCode": "DK"
        }, {
            "IsdCode": "+253",
            "DefaultLanguage": "EN",
            "CountryName": "DJIBOUTI",
            "PostalRegionType": "F",
            "CountryCode": "DJ"
        }, {
            "IsdCode": "+767",
            "DefaultLanguage": "EN",
            "CountryName": "DOMINICA",
            "PostalRegionType": "F",
            "CountryCode": "DM"
        }, {
            "IsdCode": "+809",
            "DefaultLanguage": "EN",
            "CountryName": "DOMINICAN REPUBLIC",
            "PostalRegionType": "F",
            "CountryCode": "DO"
        }, {
            "IsdCode": "+670",
            "DefaultLanguage": "EN",
            "CountryName": "EAST TIMOR",
            "PostalRegionType": "F",
            "CountryCode": "TP"
        }, {
            "IsdCode": "+593",
            "DefaultLanguage": "EN",
            "CountryName": "ECUADOR",
            "PostalRegionType": "F",
            "CountryCode": "EC"
        }, {
            "IsdCode": "+20",
            "DefaultLanguage": "EN",
            "CountryName": "EGYPT",
            "PostalRegionType": "F",
            "CountryCode": "EG"
        }, {
            "IsdCode": "+503",
            "DefaultLanguage": "EN",
            "CountryName": "EL SALVADOR",
            "PostalRegionType": "F",
            "CountryCode": "SV"
        }, {
            "IsdCode": "+240",
            "DefaultLanguage": "EN",
            "CountryName": "EQUATORIAL GUINEA",
            "PostalRegionType": "F",
            "CountryCode": "GQ"
        }, {
            "IsdCode": "+291",
            "DefaultLanguage": "EN",
            "CountryName": "ERITREA",
            "PostalRegionType": "F",
            "CountryCode": "ER"
        }, {
            "IsdCode": "+372",
            "DefaultLanguage": "EN",
            "CountryName": "ESTONIA",
            "PostalRegionType": "F",
            "CountryCode": "EE"
        }, {
            "IsdCode": "+251",
            "DefaultLanguage": "EN",
            "CountryName": "ETHIOPIA",
            "PostalRegionType": "F",
            "CountryCode": "ET"
        }, {
            "IsdCode": "+500",
            "DefaultLanguage": "EN",
            "CountryName": "FALKLAND ISLANDS",
            "PostalRegionType": "F",
            "CountryCode": "FK"
        }, {
            "IsdCode": "+298",
            "DefaultLanguage": "EN",
            "CountryName": "FAROE ISLANDS",
            "PostalRegionType": "F",
            "CountryCode": "FO"
        }, {
            "IsdCode": "+679",
            "DefaultLanguage": "EN",
            "CountryName": "FIJI",
            "PostalRegionType": "F",
            "CountryCode": "FJ"
        }, {
            "IsdCode": "+358",
            "DefaultLanguage": "EN",
            "CountryName": "FINLAND",
            "PostalRegionType": "F",
            "CountryCode": "FI"
        }, {
            "IsdCode": "+420",
            "DefaultLanguage": "EN",
            "CountryName": "FORMER CZECHOSLOVAKIA",
            "PostalRegionType": "F",
            "CountryCode": "CS"
        }, {
            "IsdCode": "+7 ",
            "DefaultLanguage": "EN",
            "CountryName": "FORMER USSR",
            "PostalRegionType": "F",
            "CountryCode": "SU"
        }, {
            "IsdCode": "+33",
            "DefaultLanguage": "EN",
            "CountryName": "FRANCE",
            "PostalRegionType": "F",
            "CountryCode": "FR"
        }, {
            "IsdCode": "+33",
            "DefaultLanguage": "EN",
            "CountryName": "FRANCE (EUROPEAN TERRITORY)",
            "PostalRegionType": "F",
            "CountryCode": "FX"
        }, {
            "IsdCode": "+594",
            "DefaultLanguage": "EN",
            "CountryName": "FRENCH GUYANA",
            "PostalRegionType": "F",
            "CountryCode": "GF"
        }, {
            "IsdCode": "+33",
            "DefaultLanguage": "EN",
            "CountryName": "FRENCH SOUTHERN TERRITORIES",
            "PostalRegionType": "F",
            "CountryCode": "TF"
        }, {
            "IsdCode": "+241",
            "DefaultLanguage": "EN",
            "CountryName": "GABON",
            "PostalRegionType": "F",
            "CountryCode": "GA"
        }, {
            "IsdCode": "+220",
            "DefaultLanguage": "EN",
            "CountryName": "GAMBIA",
            "PostalRegionType": "F",
            "CountryCode": "GM"
        }, {
            "IsdCode": "+995",
            "DefaultLanguage": "EN",
            "CountryName": "GEORGIA",
            "PostalRegionType": "F",
            "CountryCode": "GE"
        }, {
            "IsdCode": "+49",
            "DefaultLanguage": "EN",
            "CountryName": "GERMANY",
            "PostalRegionType": "F",
            "CountryCode": "DE"
        }, {
            "IsdCode": "+233",
            "DefaultLanguage": "EN",
            "CountryName": "GHANA",
            "PostalRegionType": "F",
            "CountryCode": "GH"
        }, {
            "IsdCode": "+350",
            "DefaultLanguage": "EN",
            "CountryName": "GIBRALTAR",
            "PostalRegionType": "F",
            "CountryCode": "GI"
        }, {
            "IsdCode": "+44",
            "DefaultLanguage": "EN",
            "CountryName": "GREAT BRITAIN",
            "PostalRegionType": "F",
            "CountryCode": "GB"
        }, {
            "IsdCode": "+30",
            "DefaultLanguage": "EN",
            "CountryName": "GREECE",
            "PostalRegionType": "F",
            "CountryCode": "GR"
        }, {
            "IsdCode": "+299",
            "DefaultLanguage": "EN",
            "CountryName": "GREENLAND",
            "PostalRegionType": "F",
            "CountryCode": "GL"
        }, {
            "IsdCode": "+473",
            "DefaultLanguage": "EN",
            "CountryName": "GRENADA",
            "PostalRegionType": "F",
            "CountryCode": "GD"
        }, {
            "IsdCode": "+590",
            "DefaultLanguage": "EN",
            "CountryName": "GUADELOUPE (FRENCH)",
            "PostalRegionType": "F",
            "CountryCode": "GP"
        }, {
            "IsdCode": "+670",
            "DefaultLanguage": "EN",
            "CountryName": "GUAM (USA)",
            "PostalRegionType": "F",
            "CountryCode": "GU"
        }, {
            "IsdCode": "+502",
            "DefaultLanguage": "EN",
            "CountryName": "GUATEMALA",
            "PostalRegionType": "F",
            "CountryCode": "GT"
        }, {
            "IsdCode": "+224",
            "DefaultLanguage": "EN",
            "CountryName": "GUINEA",
            "PostalRegionType": "F",
            "CountryCode": "GN"
        }, {
            "IsdCode": "+245",
            "DefaultLanguage": "EN",
            "CountryName": "GUINEA BISSAU",
            "PostalRegionType": "F",
            "CountryCode": "GW"
        }, {
            "IsdCode": "+592",
            "DefaultLanguage": "EN",
            "CountryName": "GUYANA",
            "PostalRegionType": "F",
            "CountryCode": "GY"
        }, {
            "IsdCode": "+509",
            "DefaultLanguage": "EN",
            "CountryName": "HAITI",
            "PostalRegionType": "F",
            "CountryCode": "HT"
        }, {
            "IsdCode": "+61",
            "DefaultLanguage": "EN",
            "CountryName": "HEARD AND MCDONALD ISLANDS",
            "PostalRegionType": "F",
            "CountryCode": "HM"
        }, {
            "IsdCode": "+39",
            "DefaultLanguage": "EN",
            "CountryName": "HOLY SEE (VATICAN CITY STATE)",
            "PostalRegionType": "F",
            "CountryCode": "VA"
        }, {
            "IsdCode": "+504",
            "DefaultLanguage": "EN",
            "CountryName": "HONDURAS",
            "PostalRegionType": "F",
            "CountryCode": "HN"
        }, {
            "IsdCode": "+852",
            "DefaultLanguage": "EN",
            "CountryName": "HONG KONG",
            "PostalRegionType": "F",
            "CountryCode": "HK"
        }, {
            "IsdCode": "+36",
            "DefaultLanguage": "EN",
            "CountryName": "HUNGARY",
            "PostalRegionType": "F",
            "CountryCode": "HU"
        }, {
            "IsdCode": "+354",
            "DefaultLanguage": "EN",
            "CountryName": "ICELAND",
            "PostalRegionType": "F",
            "CountryCode": "IS"
        }, {
            "IsdCode": "+91",
            "DefaultLanguage": "EN",
            "CountryName": "INDIA",
            "PostalRegionType": "F",
            "CountryCode": "IN"
        }, {
            "IsdCode": "+62",
            "DefaultLanguage": "EN",
            "CountryName": "INDONESIA",
            "PostalRegionType": "F",
            "CountryCode": "ID"
        }, {
            "IsdCode": "+98",
            "DefaultLanguage": "EN",
            "CountryName": "IRAN",
            "PostalRegionType": "F",
            "CountryCode": "IR"
        }, {
            "IsdCode": "+964",
            "DefaultLanguage": "EN",
            "CountryName": "IRAQ",
            "PostalRegionType": "F",
            "CountryCode": "IQ"
        }, {
            "IsdCode": "+353",
            "DefaultLanguage": "EN",
            "CountryName": "IRELAND",
            "PostalRegionType": "F",
            "CountryCode": "IE"
        }, {
            "IsdCode": "+972",
            "DefaultLanguage": "EN",
            "CountryName": "ISRAEL",
            "PostalRegionType": "F",
            "CountryCode": "IL"
        }, {
            "IsdCode": "+39",
            "DefaultLanguage": "EN",
            "CountryName": "ITALY",
            "PostalRegionType": "F",
            "CountryCode": "IT"
        }, {
            "IsdCode": "+225",
            "DefaultLanguage": "EN",
            "CountryName": "IVORY COAST",
            "PostalRegionType": "F",
            "CountryCode": "CI"
        }, {
            "IsdCode": "+876",
            "DefaultLanguage": "EN",
            "CountryName": "JAMAICA",
            "PostalRegionType": "F",
            "CountryCode": "JM"
        }, {
            "IsdCode": "+81",
            "DefaultLanguage": "EN",
            "CountryName": "JAPAN",
            "PostalRegionType": "F",
            "CountryCode": "JP"
        }, {
            "IsdCode": "+962",
            "DefaultLanguage": "EN",
            "CountryName": "JORDAN",
            "PostalRegionType": "F",
            "CountryCode": "JO"
        }, {
            "IsdCode": "+7",
            "DefaultLanguage": "EN",
            "CountryName": "KAZAKHSTAN",
            "PostalRegionType": "F",
            "CountryCode": "KZ"
        }, {
            "IsdCode": "+254",
            "DefaultLanguage": "EN",
            "CountryName": "KENYA",
            "PostalRegionType": "F",
            "CountryCode": "KE"
        }, {
            "IsdCode": "+686",
            "DefaultLanguage": "EN",
            "CountryName": "KIRIBATI",
            "PostalRegionType": "F",
            "CountryCode": "KI"
        }, {
            "IsdCode": "+965",
            "DefaultLanguage": "EN",
            "CountryName": "KUWAIT",
            "PostalRegionType": "F",
            "CountryCode": "KW"
        }, {
            "IsdCode": "+996",
            "DefaultLanguage": "EN",
            "CountryName": "KYRGYZ REPUBLIC (KYRGYZSTAN)",
            "PostalRegionType": "F",
            "CountryCode": "KG"
        }, {
            "IsdCode": "+856",
            "DefaultLanguage": "EN",
            "CountryName": "LAOS",
            "PostalRegionType": "F",
            "CountryCode": "LA"
        }, {
            "IsdCode": "+371",
            "DefaultLanguage": "EN",
            "CountryName": "LATVIA",
            "PostalRegionType": "F",
            "CountryCode": "LV"
        }, {
            "IsdCode": "+961",
            "DefaultLanguage": "EN",
            "CountryName": "LEBANON",
            "PostalRegionType": "F",
            "CountryCode": "LB"
        }, {
            "IsdCode": "+266",
            "DefaultLanguage": "EN",
            "CountryName": "LESOTHO",
            "PostalRegionType": "F",
            "CountryCode": "LS"
        }, {
            "IsdCode": "+231",
            "DefaultLanguage": "EN",
            "CountryName": "LIBERIA",
            "PostalRegionType": "F",
            "CountryCode": "LR"
        }, {
            "IsdCode": "+218",
            "DefaultLanguage": "EN",
            "CountryName": "LIBYA",
            "PostalRegionType": "F",
            "CountryCode": "LY"
        }, {
            "IsdCode": "+41",
            "DefaultLanguage": "EN",
            "CountryName": "LIECHTENSTEIN",
            "PostalRegionType": "F",
            "CountryCode": "LI"
        }, {
            "IsdCode": "+370",
            "DefaultLanguage": "EN",
            "CountryName": "LITHUANIA",
            "PostalRegionType": "F",
            "CountryCode": "LT"
        }, {
            "IsdCode": "+352",
            "DefaultLanguage": "EN",
            "CountryName": "LUXEMBOURG",
            "PostalRegionType": "F",
            "CountryCode": "LU"
        }, {
            "IsdCode": "+853",
            "DefaultLanguage": "EN",
            "CountryName": "MACAU",
            "PostalRegionType": "F",
            "CountryCode": "MO"
        }, {
            "IsdCode": "+389",
            "DefaultLanguage": "EN",
            "CountryName": "MACEDONIA",
            "PostalRegionType": "F",
            "CountryCode": "MK"
        }, {
            "IsdCode": "+261",
            "DefaultLanguage": "EN",
            "CountryName": "MADAGASCAR",
            "PostalRegionType": "F",
            "CountryCode": "MG"
        }, {
            "IsdCode": "+265",
            "DefaultLanguage": "EN",
            "CountryName": "MALAWI",
            "PostalRegionType": "F",
            "CountryCode": "MW"
        }, {
            "IsdCode": "+60",
            "DefaultLanguage": "EN",
            "CountryName": "MALAYSIA",
            "PostalRegionType": "F",
            "CountryCode": "MY"
        }, {
            "IsdCode": "+960",
            "DefaultLanguage": "EN",
            "CountryName": "MALDIVES",
            "PostalRegionType": "F",
            "CountryCode": "MV"
        }, {
            "IsdCode": "+223",
            "DefaultLanguage": "EN",
            "CountryName": "MALI",
            "PostalRegionType": "F",
            "CountryCode": "ML"
        }, {
            "IsdCode": "+356",
            "DefaultLanguage": "EN",
            "CountryName": "MALTA",
            "PostalRegionType": "F",
            "CountryCode": "MT"
        }, {
            "IsdCode": "+692",
            "DefaultLanguage": "EN",
            "CountryName": "MARSHALL ISLANDS",
            "PostalRegionType": "F",
            "CountryCode": "MH"
        }, {
            "IsdCode": "+596",
            "DefaultLanguage": "EN",
            "CountryName": "MARTINIQUE (FRENCH)",
            "PostalRegionType": "F",
            "CountryCode": "MQ"
        }, {
            "IsdCode": "+222",
            "DefaultLanguage": "EN",
            "CountryName": "MAURITANIA",
            "PostalRegionType": "F",
            "CountryCode": "MR"
        }, {
            "IsdCode": "+230",
            "DefaultLanguage": "EN",
            "CountryName": "MAURITIUS",
            "PostalRegionType": "F",
            "CountryCode": "MU"
        }, {
            "IsdCode": "+269",
            "DefaultLanguage": "EN",
            "CountryName": "MAYOTTE",
            "PostalRegionType": "F",
            "CountryCode": "YT"
        }, {
            "IsdCode": "+52",
            "DefaultLanguage": "EN",
            "CountryName": "MEXICO",
            "PostalRegionType": "F",
            "CountryCode": "MX"
        }, {
            "IsdCode": "+691",
            "DefaultLanguage": "EN",
            "CountryName": "MICRONESIA",
            "PostalRegionType": "F",
            "CountryCode": "FM"
        }, {
            "IsdCode": "+373 ",
            "DefaultLanguage": "EN",
            "CountryName": "MOLDAVIA",
            "PostalRegionType": "F",
            "CountryCode": "MD"
        }, {
            "IsdCode": "+377",
            "DefaultLanguage": "EN",
            "CountryName": "MONACO",
            "PostalRegionType": "F",
            "CountryCode": "MC"
        }, {
            "IsdCode": "+976",
            "DefaultLanguage": "EN",
            "CountryName": "MONGOLIA",
            "PostalRegionType": "F",
            "CountryCode": "MN"
        }, {
            "IsdCode": "+382",
            "DefaultLanguage": "EN",
            "CountryName": "MONTENEGRO",
            "PostalRegionType": "F",
            "CountryCode": "ME"
        }, {
            "IsdCode": "+664",
            "DefaultLanguage": "EN",
            "CountryName": "MONTSERRAT",
            "PostalRegionType": "F",
            "CountryCode": "MS"
        }, {
            "IsdCode": "+212",
            "DefaultLanguage": "EN",
            "CountryName": "MOROCCO",
            "PostalRegionType": "F",
            "CountryCode": "MA"
        }, {
            "IsdCode": "+258",
            "DefaultLanguage": "EN",
            "CountryName": "MOZAMBIQUE",
            "PostalRegionType": "F",
            "CountryCode": "MZ"
        }, {
            "IsdCode": "+95",
            "DefaultLanguage": "EN",
            "CountryName": "MYANMAR",
            "PostalRegionType": "F",
            "CountryCode": "MM"
        }, {
            "IsdCode": "+264",
            "DefaultLanguage": "EN",
            "CountryName": "NAMIBIA",
            "PostalRegionType": "F",
            "CountryCode": "NA"
        }, {
            "IsdCode": "+674",
            "DefaultLanguage": "EN",
            "CountryName": "NAURU",
            "PostalRegionType": "F",
            "CountryCode": "NR"
        }, {
            "IsdCode": "+977",
            "DefaultLanguage": "EN",
            "CountryName": "NEPAL",
            "PostalRegionType": "F",
            "CountryCode": "NP"
        }, {
            "IsdCode": "+31",
            "DefaultLanguage": "EN",
            "CountryName": "NETHERLANDS",
            "PostalRegionType": "F",
            "CountryCode": "NL"
        }, {
            "IsdCode": "+599",
            "DefaultLanguage": "EN",
            "CountryName": "NETHERLANDS ANTILLES",
            "PostalRegionType": "F",
            "CountryCode": "AN"
        }, {
            "IsdCode": "+687",
            "DefaultLanguage": "EN",
            "CountryName": "NEW CALEDONIA (FRENCH)",
            "PostalRegionType": "F",
            "CountryCode": "NC"
        }, {
            "IsdCode": "+64",
            "DefaultLanguage": "EN",
            "CountryName": "NEW ZEALAND",
            "PostalRegionType": "F",
            "CountryCode": "NZ"
        }, {
            "IsdCode": "+505",
            "DefaultLanguage": "EN",
            "CountryName": "NICARAGUA",
            "PostalRegionType": "F",
            "CountryCode": "NI"
        }, {
            "IsdCode": "+227",
            "DefaultLanguage": "EN",
            "CountryName": "NIGER",
            "PostalRegionType": "F",
            "CountryCode": "NE"
        }, {
            "IsdCode": "+234",
            "DefaultLanguage": "EN",
            "CountryName": "NIGERIA",
            "PostalRegionType": "F",
            "CountryCode": "NG"
        }, {
            "IsdCode": "+683",
            "DefaultLanguage": "EN",
            "CountryName": "NIUE",
            "PostalRegionType": "F",
            "CountryCode": "NU"
        }, {
            "IsdCode": "+672",
            "DefaultLanguage": "EN",
            "CountryName": "NORFOLK ISLAND",
            "PostalRegionType": "F",
            "CountryCode": "NF"
        }, {
            "IsdCode": "+850",
            "DefaultLanguage": "EN",
            "CountryName": "NORTH KOREA",
            "PostalRegionType": "F",
            "CountryCode": "KP"
        }, {
            "IsdCode": "+670 ",
            "DefaultLanguage": "EN",
            "CountryName": "NORTHERN MARIANA ISLANDS",
            "PostalRegionType": "F",
            "CountryCode": "MP"
        }, {
            "IsdCode": "+47",
            "DefaultLanguage": "EN",
            "CountryName": "NORWAY",
            "PostalRegionType": "F",
            "CountryCode": "NO"
        }, {
            "IsdCode": "+968",
            "DefaultLanguage": "EN",
            "CountryName": "OMAN",
            "PostalRegionType": "F",
            "CountryCode": "WY"
        }, {
            "IsdCode": "+968",
            "DefaultLanguage": "EN",
            "CountryName": "OMAN",
            "PostalRegionType": "F",
            "CountryCode": "OM"
        }, {
            "IsdCode": "+92",
            "DefaultLanguage": "EN",
            "CountryName": "PAKISTAN",
            "PostalRegionType": "F",
            "CountryCode": "PK"
        }, {
            "IsdCode": "+680",
            "DefaultLanguage": "EN",
            "CountryName": "PALAU",
            "PostalRegionType": "F",
            "CountryCode": "PW"
        }, {
            "IsdCode": "+970",
            "DefaultLanguage": "EN",
            "CountryName": "PALESTINIAN TERRITORY",
            "PostalRegionType": "F",
            "CountryCode": "PS"
        }, {
            "IsdCode": "+507",
            "DefaultLanguage": "EN",
            "CountryName": "PANAMA",
            "PostalRegionType": "F",
            "CountryCode": "PA"
        }, {
            "IsdCode": "+675",
            "DefaultLanguage": "EN",
            "CountryName": "PAPUA NEW GUINEA",
            "PostalRegionType": "F",
            "CountryCode": "PG"
        }, {
            "IsdCode": "+595",
            "DefaultLanguage": "EN",
            "CountryName": "PARAGUAY",
            "PostalRegionType": "F",
            "CountryCode": "PY"
        }, {
            "IsdCode": "+51",
            "DefaultLanguage": "EN",
            "CountryName": "PERU",
            "PostalRegionType": "F",
            "CountryCode": "PE"
        }, {
            "IsdCode": "+63",
            "DefaultLanguage": "EN",
            "CountryName": "PHILIPPINES",
            "PostalRegionType": "F",
            "CountryCode": "PH"
        }, {
            "IsdCode": "+649 ",
            "DefaultLanguage": "EN",
            "CountryName": "PITCAIRN ISLAND",
            "PostalRegionType": "F",
            "CountryCode": "PN"
        }, {
            "IsdCode": "+48",
            "DefaultLanguage": "EN",
            "CountryName": "POLAND",
            "PostalRegionType": "F",
            "CountryCode": "PL"
        }, {
            "IsdCode": "+689",
            "DefaultLanguage": "EN",
            "CountryName": "POLYNESIA (FRENCH)",
            "PostalRegionType": "F",
            "CountryCode": "PF"
        }, {
            "IsdCode": "+351 ",
            "DefaultLanguage": "EN",
            "CountryName": "PORTUGAL",
            "PostalRegionType": "F",
            "CountryCode": "PT"
        }, {
            "IsdCode": "+787",
            "DefaultLanguage": "EN",
            "CountryName": "PUERTO RICO",
            "PostalRegionType": "F",
            "CountryCode": "PR"
        }, {
            "IsdCode": "+675 ",
            "DefaultLanguage": "EN",
            "CountryName": "Papaua New Guinea",
            "PostalRegionType": "F",
            "CountryCode": "PNG"
        }, {
            "IsdCode": "+974",
            "DefaultLanguage": "EN",
            "CountryName": "QATAR",
            "PostalRegionType": "F",
            "CountryCode": "QA"
        }, {
            "IsdCode": "+262",
            "DefaultLanguage": "EN",
            "CountryName": "REUNION (FRENCH)",
            "PostalRegionType": "F",
            "CountryCode": "RE"
        }, {
            "IsdCode": "+40",
            "DefaultLanguage": "EN",
            "CountryName": "ROMANIA",
            "PostalRegionType": "F",
            "CountryCode": "RO"
        }, {
            "IsdCode": "+7",
            "DefaultLanguage": "EN",
            "CountryName": "RUSSIAN FEDERATION",
            "PostalRegionType": "F",
            "CountryCode": "XU"
        }, {
            "IsdCode": "+7",
            "DefaultLanguage": "EN",
            "CountryName": "RUSSIAN FEDERATION",
            "PostalRegionType": "F",
            "CountryCode": "RU"
        }, {
            "IsdCode": "+250",
            "DefaultLanguage": "EN",
            "CountryName": "RWANDA",
            "PostalRegionType": "F",
            "CountryCode": "RW"
        }, {
            "IsdCode": "+290",
            "DefaultLanguage": "EN",
            "CountryName": "SAINT HELENA",
            "PostalRegionType": "F",
            "CountryCode": "SH"
        }, {
            "IsdCode": "+758",
            "DefaultLanguage": "EN",
            "CountryName": "SAINT LUCIA",
            "PostalRegionType": "F",
            "CountryCode": "LC"
        }, {
            "IsdCode": "+508",
            "DefaultLanguage": "EN",
            "CountryName": "SAINT PIERRE AND MIQUELON",
            "PostalRegionType": "F",
            "CountryCode": "PM"
        }, {
            "IsdCode": "+809",
            "DefaultLanguage": "EN",
            "CountryName": "SAINT VIN-GREN",
            "PostalRegionType": "F",
            "CountryCode": "VC"
        }, {
            "IsdCode": "+685",
            "DefaultLanguage": "EN",
            "CountryName": "SAMOA",
            "PostalRegionType": "F",
            "CountryCode": "WS"
        }, {
            "IsdCode": "+378",
            "DefaultLanguage": "EN",
            "CountryName": "SAN MARINO",
            "PostalRegionType": "F",
            "CountryCode": "SM"
        }, {
            "IsdCode": "+239",
            "DefaultLanguage": "EN",
            "CountryName": "SAO TOME AND PRINCIPE",
            "PostalRegionType": "F",
            "CountryCode": "ST"
        }, {
            "IsdCode": "+966",
            "DefaultLanguage": "EN",
            "CountryName": "SAUDI ARABIA",
            "PostalRegionType": "F",
            "CountryCode": "SA"
        }, {
            "IsdCode": "+221",
            "DefaultLanguage": "EN",
            "CountryName": "SENEGAL",
            "PostalRegionType": "F",
            "CountryCode": "SN"
        }, {
            "IsdCode": "+381",
            "DefaultLanguage": "EN",
            "CountryName": "SERBIA",
            "PostalRegionType": "F",
            "CountryCode": "RS"
        }, {
            "IsdCode": "+248",
            "DefaultLanguage": "EN",
            "CountryName": "SEYCHELLES",
            "PostalRegionType": "F",
            "CountryCode": "SC"
        }, {
            "IsdCode": "+232",
            "DefaultLanguage": "EN",
            "CountryName": "SIERRA LEONE",
            "PostalRegionType": "F",
            "CountryCode": "SL"
        }, {
            "IsdCode": "+65",
            "DefaultLanguage": "EN",
            "CountryName": "SINGAPORE",
            "PostalRegionType": "F",
            "CountryCode": "SG"
        }, {
            "IsdCode": "+421",
            "DefaultLanguage": "EN",
            "CountryName": "SLOVAK REPUBLIC",
            "PostalRegionType": "F",
            "CountryCode": "SK"
        }, {
            "IsdCode": "+386",
            "DefaultLanguage": "EN",
            "CountryName": "SLOVENIA",
            "PostalRegionType": "F",
            "CountryCode": "SI"
        }, {
            "IsdCode": "+677",
            "DefaultLanguage": "EN",
            "CountryName": "SOLOMON ISLANDS",
            "PostalRegionType": "F",
            "CountryCode": "SB"
        }, {
            "IsdCode": "+252",
            "DefaultLanguage": "EN",
            "CountryName": "SOMALIA",
            "PostalRegionType": "F",
            "CountryCode": "SO"
        }, {
            "IsdCode": "+27",
            "DefaultLanguage": "EN",
            "CountryName": "SOUTH AFRICA",
            "PostalRegionType": "F",
            "CountryCode": "ZA"
        }, {
            "IsdCode": "+82",
            "DefaultLanguage": "EN",
            "CountryName": "SOUTH KOREA",
            "PostalRegionType": "F",
            "CountryCode": "KR"
        }, {
            "IsdCode": "+34",
            "DefaultLanguage": "EN",
            "CountryName": "SPAIN",
            "PostalRegionType": "F",
            "CountryCode": "ES"
        }, {
            "IsdCode": "+94",
            "DefaultLanguage": "EN",
            "CountryName": "SRI LANKA",
            "PostalRegionType": "F",
            "CountryCode": "LK"
        }, {
            "IsdCode": "+869",
            "DefaultLanguage": "EN",
            "CountryName": "ST KITTS-NEVIS",
            "PostalRegionType": "F",
            "CountryCode": "KN"
        }, {
            "IsdCode": "+249",
            "DefaultLanguage": "EN",
            "CountryName": "SUDAN",
            "PostalRegionType": "F",
            "CountryCode": "SD"
        }, {
            "IsdCode": "+597",
            "DefaultLanguage": "EN",
            "CountryName": "SURINAME",
            "PostalRegionType": "F",
            "CountryCode": "SR"
        }, {
            "IsdCode": "+47 ",
            "DefaultLanguage": "EN",
            "CountryName": "SVALBARD AND JAN MAYEN ISLANDS",
            "PostalRegionType": "F",
            "CountryCode": "SJ"
        }, {
            "IsdCode": "+268",
            "DefaultLanguage": "EN",
            "CountryName": "SWAZILAND",
            "PostalRegionType": "F",
            "CountryCode": "SZ"
        }, {
            "IsdCode": "+46",
            "DefaultLanguage": "EN",
            "CountryName": "SWEDEN",
            "PostalRegionType": "F",
            "CountryCode": "SE"
        }, {
            "IsdCode": "+41",
            "DefaultLanguage": "EN",
            "CountryName": "SWITZERLAND",
            "PostalRegionType": "F",
            "CountryCode": "CH"
        }, {
            "IsdCode": "+963",
            "DefaultLanguage": "EN",
            "CountryName": "SYRIA",
            "PostalRegionType": "F",
            "CountryCode": "SY"
        }, {
            "IsdCode": "+7",
            "DefaultLanguage": "EN",
            "CountryName": "TADJIKISTAN",
            "PostalRegionType": "F",
            "CountryCode": "TJ"
        }, {
            "IsdCode": "+886",
            "DefaultLanguage": "EN",
            "CountryName": "TAIWAN",
            "PostalRegionType": "F",
            "CountryCode": "TW"
        }, {
            "IsdCode": "+255",
            "DefaultLanguage": "EN",
            "CountryName": "TANZANIA",
            "PostalRegionType": "F",
            "CountryCode": "TZ"
        }, {
            "IsdCode": "+66",
            "DefaultLanguage": "EN",
            "CountryName": "THAILAND",
            "PostalRegionType": "F",
            "CountryCode": "TH"
        }, {
            "IsdCode": "+228",
            "DefaultLanguage": "EN",
            "CountryName": "TOGO",
            "PostalRegionType": "F",
            "CountryCode": "TG"
        }, {
            "IsdCode": "+690",
            "DefaultLanguage": "EN",
            "CountryName": "TOKELAU",
            "PostalRegionType": "F",
            "CountryCode": "TK"
        }, {
            "IsdCode": "+676",
            "DefaultLanguage": "EN",
            "CountryName": "TONGA",
            "PostalRegionType": "F",
            "CountryCode": "TO"
        }, {
            "IsdCode": "+868",
            "DefaultLanguage": "EN",
            "CountryName": "TRINIDAD AND TOBAGO",
            "PostalRegionType": "F",
            "CountryCode": "TT"
        }, {
            "IsdCode": "+216",
            "DefaultLanguage": "EN",
            "CountryName": "TUNISIA",
            "PostalRegionType": "F",
            "CountryCode": "TN"
        }, {
            "IsdCode": "+90",
            "DefaultLanguage": "EN",
            "CountryName": "TURKEY",
            "PostalRegionType": "F",
            "CountryCode": "TR"
        }, {
            "IsdCode": "+993",
            "DefaultLanguage": "EN",
            "CountryName": "TURKMENISTAN",
            "PostalRegionType": "F",
            "CountryCode": "TM"
        }, {
            "IsdCode": "+649",
            "DefaultLanguage": "EN",
            "CountryName": "TURKS AND CAICOS ISLANDS",
            "PostalRegionType": "F",
            "CountryCode": "TC"
        }, {
            "IsdCode": "+688",
            "DefaultLanguage": "EN",
            "CountryName": "TUVALU",
            "PostalRegionType": "F",
            "CountryCode": "TV"
        }, {
            "IsdCode": "+256",
            "DefaultLanguage": "EN",
            "CountryName": "UGANDA",
            "PostalRegionType": "F",
            "CountryCode": "UG"
        }, {
            "IsdCode": "+380",
            "DefaultLanguage": "EN",
            "CountryName": "UKRAINE",
            "PostalRegionType": "F",
            "CountryCode": "UA"
        }, {
            "IsdCode": "+971",
            "DefaultLanguage": "EN",
            "CountryName": "UNITED ARAB EMIRATES",
            "PostalRegionType": "F",
            "CountryCode": "AE"
        }, {
            "IsdCode": "+44",
            "DefaultLanguage": "EN",
            "CountryName": "UNITED KINGDOM",
            "PostalRegionType": "F",
            "CountryCode": "UK"
        }, {
            "IsdCode": "+1",
            "DefaultLanguage": "EN",
            "CountryName": "UNITED STATES",
            "PostalRegionType": "F",
            "CountryCode": "US"
        }, {
            "IsdCode": "+598",
            "DefaultLanguage": "EN",
            "CountryName": "URUGUAY",
            "PostalRegionType": "F",
            "CountryCode": "UY"
        }, {
            "IsdCode": "+1",
            "DefaultLanguage": "EN",
            "CountryName": "USA MINOR OUTLYING ISLANDS",
            "PostalRegionType": "F",
            "CountryCode": "UM"
        }, {
            "IsdCode": "+998",
            "DefaultLanguage": "EN",
            "CountryName": "UZBEKISTAN",
            "PostalRegionType": "F",
            "CountryCode": "UZ"
        }, {
            "IsdCode": "+999",
            "DefaultLanguage": "EN",
            "CountryName": "Unknown",
            "PostalRegionType": "F",
            "CountryCode": "XX"
        }, {
            "IsdCode": "+678",
            "DefaultLanguage": "EN",
            "CountryName": "VANUATU",
            "PostalRegionType": "F",
            "CountryCode": "VU"
        }, {
            "IsdCode": "+58",
            "DefaultLanguage": "EN",
            "CountryName": "VENEZUELA",
            "PostalRegionType": "F",
            "CountryCode": "VE"
        }, {
            "IsdCode": "+84",
            "DefaultLanguage": "EN",
            "CountryName": "VIETNAM",
            "PostalRegionType": "F",
            "CountryCode": "VN"
        }, {
            "IsdCode": "+284 ",
            "DefaultLanguage": "EN",
            "CountryName": "VIRGIN ISLANDS (BRITISH)",
            "PostalRegionType": "F",
            "CountryCode": "VG"
        }, {
            "IsdCode": "+340 ",
            "DefaultLanguage": "EN",
            "CountryName": "VIRGIN ISLANDS (USA)",
            "PostalRegionType": "F",
            "CountryCode": "VI"
        }, {
            "IsdCode": "+681",
            "DefaultLanguage": "EN",
            "CountryName": "WALLIS AND FUTUNA ISLANDS",
            "PostalRegionType": "F",
            "CountryCode": "WF"
        }, {
            "IsdCode": "+808",
            "DefaultLanguage": "EN",
            "CountryName": "WESTERN SAHARA",
            "PostalRegionType": "F",
            "CountryCode": "EH"
        }, {
            "IsdCode": "+967",
            "DefaultLanguage": "EN",
            "CountryName": "YEMEN",
            "PostalRegionType": "F",
            "CountryCode": "YE"
        }, {
            "IsdCode": "+381",
            "DefaultLanguage": "EN",
            "CountryName": "YUGOSLAVIA",
            "PostalRegionType": "F",
            "CountryCode": "YU"
        }, {
            "IsdCode": "+243",
            "DefaultLanguage": "EN",
            "CountryName": "ZAIRE",
            "PostalRegionType": "F",
            "CountryCode": "ZR"
        }, {
            "IsdCode": "+260",
            "DefaultLanguage": "EN",
            "CountryName": "ZAMBIA",
            "PostalRegionType": "F",
            "CountryCode": "ZM"
        }, {
            "IsdCode": "+263",
            "DefaultLanguage": "EN",
            "CountryName": "ZIMBABWE",
            "PostalRegionType": "F",
            "CountryCode": "ZW"
        }]
    }
}
const MASTER_CONFIG_LANG = {"statuscode":"200","statusMessage":"SUCCESS","object":{"companyCode":"IBS","entityCode":"LNGMST","programCode":"PRG14","masterRecordList":[{"LanguageCode":"OM","LanguageName":"AFAN(OROMO)"},{"LanguageCode":"SQ","LanguageName":"ALBANIAN"},{"LanguageCode":"HY","LanguageName":"ARMENIAN"},{"LanguageCode":"EU","LanguageName":"BASQUE"},{"LanguageCode":"DZ","LanguageName":"BHUTANI"},{"LanguageCode":"BR","LanguageName":"BRETON"},{"LanguageCode":"MY","LanguageName":"BURMESE"},{"LanguageCode":"KM","LanguageName":"CAMBODIAN"},{"LanguageCode":"CA","LanguageName":"CATALAN"},{"LanguageCode":"ZH","LanguageName":"CHINESE"},{"LanguageCode":"CO","LanguageName":"CORSICAN"},{"LanguageCode":"HR","LanguageName":"CROATIAN"},{"LanguageCode":"CS","LanguageName":"CZECH"},{"LanguageCode":"DA","LanguageName":"DANISH"},{"LanguageCode":"NL","LanguageName":"DUTCH"},{"LanguageCode":"EN","LanguageName":"ENGLISH"},{"LanguageCode":"EO","LanguageName":"ESPERANTO"},{"LanguageCode":"ET","LanguageName":"ESTONIAN"},{"LanguageCode":"FO","LanguageName":"FAROESE"},{"LanguageCode":"FJ","LanguageName":"FIJI"},{"LanguageCode":"FI","LanguageName":"FINNISH"},{"LanguageCode":"FR","LanguageName":"FRENCH"},{"LanguageCode":"FY","LanguageName":"FRISIAN"},{"LanguageCode":"GL","LanguageName":"GALICIAN"},{"LanguageCode":"KA","LanguageName":"GEORGIAN"},{"LanguageCode":"DE","LanguageName":"GERMAN"},{"LanguageCode":"EL","LanguageName":"GREEK"},{"LanguageCode":"KL","LanguageName":"GREENLANDIC"},{"LanguageCode":"GN","LanguageName":"GUARANI"},{"LanguageCode":"GU","LanguageName":"GUJARATI"},{"LanguageCode":"HA","LanguageName":"HAUSA"},{"LanguageCode":"HE","LanguageName":"HEBREW"},{"LanguageCode":"HI","LanguageName":"HINDI"},{"LanguageCode":"HU","LanguageName":"HUNGARIAN"},{"LanguageCode":"IS","LanguageName":"ICELANDIC"},{"LanguageCode":"ID","LanguageName":"INDONESIAN"},{"LanguageCode":"IA","LanguageName":"INTERLINGUA"},{"LanguageCode":"IE","LanguageName":"INTERLINGUE"},{"LanguageCode":"IU","LanguageName":"INUKTITUT"},{"LanguageCode":"IK","LanguageName":"INUPIAK"},{"LanguageCode":"GA","LanguageName":"IRISH"},{"LanguageCode":"IT","LanguageName":"ITALIAN"},{"LanguageCode":"JA","LanguageName":"JAPANESE"},{"LanguageCode":"JV","LanguageName":"JAVANESE"},{"LanguageCode":"KN","LanguageName":"KANNADA"},{"LanguageCode":"KS","LanguageName":"KASHMIRI"},{"LanguageCode":"KK","LanguageName":"KAZAKH"},{"LanguageCode":"RW","LanguageName":"KINYARWANDA"},{"LanguageCode":"KY","LanguageName":"KIRGHIZ"},{"LanguageCode":"KO","LanguageName":"KOREAN"},{"LanguageCode":"KU","LanguageName":"KURDISH"},{"LanguageCode":"RN","LanguageName":"KURUNDI"},{"LanguageCode":"LO","LanguageName":"LAOTHIAN"},{"LanguageCode":"LA","LanguageName":"LATIN"},{"LanguageCode":"LV","LanguageName":"LATVIAN;LETTISH"},{"LanguageCode":"LN","LanguageName":"LINGALA"},{"LanguageCode":"LT","LanguageName":"LITHUANIAN"},{"LanguageCode":"MK","LanguageName":"MACEDONIAN"},{"LanguageCode":"MG","LanguageName":"MALAGASY"},{"LanguageCode":"MS","LanguageName":"MALAY"},{"LanguageCode":"ML","LanguageName":"MALAYALAM"},{"LanguageCode":"MT","LanguageName":"MALTESE"},{"LanguageCode":"MI","LanguageName":"MAORI"},{"LanguageCode":"MR","LanguageName":"MARATHI"},{"LanguageCode":"MO","LanguageName":"MOLDAVIAN"},{"LanguageCode":"MN","LanguageName":"MONGOLIAN"},{"LanguageCode":"NA","LanguageName":"NAURU"},{"LanguageCode":"NE","LanguageName":"NEPALI"},{"LanguageCode":"NO","LanguageName":"NORWEGIAN"},{"LanguageCode":"OC","LanguageName":"OCCITAN"},{"LanguageCode":"OR","LanguageName":"ORIYA"},{"LanguageCode":"PS","LanguageName":"PASHTO;PUSHTO"},{"LanguageCode":"FA","LanguageName":"PERSIAN(FARSI)"},{"LanguageCode":"PL","LanguageName":"POLISH"},{"LanguageCode":"PT","LanguageName":"PORTUGUESE"},{"LanguageCode":"PA","LanguageName":"PUNJABI"},{"LanguageCode":"QU","LanguageName":"QUECHUA"},{"LanguageCode":"RM","LanguageName":"RHAETO-ROMANCE"},{"LanguageCode":"RO","LanguageName":"ROMANIAN"},{"LanguageCode":"RU","LanguageName":"RUSSIAN"},{"LanguageCode":"SM","LanguageName":"SAMOAN"},{"LanguageCode":"SG","LanguageName":"SANGHO"},{"LanguageCode":"SA","LanguageName":"SANSKRIT"},{"LanguageCode":"GD","LanguageName":"SCOTSGAELIC"},{"LanguageCode":"SR","LanguageName":"SERBIAN"},{"LanguageCode":"SH","LanguageName":"SERBO-CROATIAN"},{"LanguageCode":"ST","LanguageName":"SESOTHO"},{"LanguageCode":"TN","LanguageName":"SETSWANA"},{"LanguageCode":"SN","LanguageName":"SHONA"},{"LanguageCode":"SD","LanguageName":"SINDHI"},{"LanguageCode":"SI","LanguageName":"SINGHALESE"},{"LanguageCode":"SS","LanguageName":"SISWATI"},{"LanguageCode":"SK","LanguageName":"SLOVAK"},{"LanguageCode":"SL","LanguageName":"SLOVENIAN"},{"LanguageCode":"SO","LanguageName":"SOMALI"},{"LanguageCode":"ES","LanguageName":"SPANISH"},{"LanguageCode":"SU","LanguageName":"SUNDANESE"},{"LanguageCode":"SW","LanguageName":"SWAHILI"},{"LanguageCode":"SV","LanguageName":"SWEDISH"},{"LanguageCode":"TL","LanguageName":"TAGALOG"},{"LanguageCode":"TG","LanguageName":"TAJIK"},{"LanguageCode":"TA","LanguageName":"TAMIL"},{"LanguageCode":"TT","LanguageName":"TATAR"},{"LanguageCode":"TE","LanguageName":"TELUGU"},{"LanguageCode":"TH","LanguageName":"THAI"},{"LanguageCode":"BO","LanguageName":"TIBETAN"},{"LanguageCode":"TI","LanguageName":"TIGRINYA"},{"LanguageCode":"TO","LanguageName":"TONGA"},{"LanguageCode":"TS","LanguageName":"TSONGA"},{"LanguageCode":"TR","LanguageName":"TURKISH"},{"LanguageCode":"TK","LanguageName":"TURKMEN"},{"LanguageCode":"TW","LanguageName":"TWI"},{"LanguageCode":"UG","LanguageName":"UIGUR"},{"LanguageCode":"UK","LanguageName":"UKRAINIAN"},{"LanguageCode":"UR","LanguageName":"URDU"},{"LanguageCode":"UZ","LanguageName":"UZBEK"},{"LanguageCode":"VI","LanguageName":"VIETNAMESE"},{"LanguageCode":"VO","LanguageName":"VOLAPUK"},{"LanguageCode":"CY","LanguageName":"WELSH"},{"LanguageCode":"WO","LanguageName":"WOLOF"},{"LanguageCode":"XH","LanguageName":"XHOSA"},{"LanguageCode":"YI","LanguageName":"YIDDISH"},{"LanguageCode":"YO","LanguageName":"YORUBA"},{"LanguageCode":"ZA","LanguageName":"ZHUANG"},{"LanguageCode":"ZU","LanguageName":"ZULU"}]}}
const MASTER_CONFIG_GENDER = {"statuscode":"200","statusMessage":"SUCCESS","object":{"companyCode":"IBS","entityCode":"TLEMST","programCode":"PRG14","masterRecordList":[{"TitleName":"Unknown","SequenceNumber":"12","TitleCode":"U","Gender":"B"},{"TitleName":"Mr","SequenceNumber":"32","TitleCode":"MR","Gender":"M"},{"TitleName":"Mrs","SequenceNumber":"33","TitleCode":"MRS","Gender":"F"}]}}