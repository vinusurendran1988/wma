import React from 'react';
import { withTranslation } from 'react-i18next';
import { withSuspense } from '../../utils';
import { connect } from 'react-redux';
import { fetchMasterData } from '../../middleware/redux/commonAction';
import { COUNTRY_ISD } from '../../utils/Constants';

/**
 * @author Alan Kuriakose
 * Component to fetch ISD code and render dropdown
 */
class ISDCode extends React.Component {

    componentDidMount() {
        const { masterEntityLookup } = this.props
        if (Object.keys(masterEntityLookup).length > 0 && 
            !this.props.ISDCodes || this.props.ISDCodes.length === 0) {
            this.props.fetchMasterData(COUNTRY_ISD, masterEntityLookup)
        }
    }

    render() {
        const { t, onChange, label, value, ISDCodes } = this.props;
        return(
            <div className="form-group">
                <label>{t('profile.basicInfo.ISDCode')}</label>
                <select className="" value={value} onChange={event=>{
                    onChange(event)
                }}>
                    {label&&<option value="">{label}</option>}
                    {ISDCodes.map((ISDCodeObj, index) => 
                    <option key={index} value={ISDCodeObj.IsdCode}>{ISDCodeObj.IsdCode+' - '+ISDCodeObj.CountryName}</option>)}
                </select>
            </div>
        )
    }
}

ISDCode.defaultProps = {
    value: '',
    label: '',
    onChange: ()=>{}
}

const mapStateToProps = state => {
    return {
        ISDCodes: state.masterData[COUNTRY_ISD] ? state.masterData[COUNTRY_ISD] : [],
        masterEntityLookup: state.masterEntityDataReducer.masterEntityLookup
    }
}

const mapDispatchToProps = { fetchMasterData }

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(ISDCode)));