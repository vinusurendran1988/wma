import React from 'react';
import { connect } from 'react-redux';
import { fetchMasterData } from '../../middleware/redux/commonAction';
import { TITLE_GENDER } from '../../utils/Constants';

/**
 * @author Alan Kuriakose
 * Component to render all titles like Mr, Mrs etc..
 */
class Titles extends React.Component {

    componentDidMount() {
        const { titles } = this.props;
        if(Object.keys(masterEntityLookup).length > 0 && !titles) {
            fetchMasterData(TITLE_GENDER)
        }
    }

    render() {
        const { label } = this.props;
                return(<div className="form-group">
                    {label && <label htmlFor={field.id}>{t(label)} {field.isRequired && <span className="text-warning">*</span>}</label>}
                    <select className="">
                        <option value="">Select title</option>
                    </select>
                </div>)
    }
}

const mapStateToProps = state => {
    return({
        titles: state.masterData[TITLE_GENDER] || [],
        masterEntityLookup: state.masterEntityDataReducer.masterEntityLookup
    })
}

const mapDispatchToProps = { fetchMasterData }

Titles.defaultProps = {
    label: undefined,
    className: undefined
}

export default connect(mapStateToProps, mapDispatchToProps)(Titles);