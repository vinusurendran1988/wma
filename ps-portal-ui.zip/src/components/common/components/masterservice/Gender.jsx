import React from 'react';
import { withTranslation } from 'react-i18next';
import { withSuspense } from '../../utils';
import { connect } from 'react-redux';
import { fetchMasterData } from '../../middleware/redux/commonAction';
import {
    TITLE_GENDER,
    CONFIG_SECTION_DEFAULT,
    DATA_SOURCE_DEFAULT,
    DATA_SOURCE_MASTER
} from '../../utils/Constants'
import { getCurrentProgramFromDefaultConfig } from '../../utils/configurationFiles.utils';

/**
 * @author Alan Kuriakose
 * Component to fetch gender data and render dropdown
 */
class Gender extends React.Component {

    constructor(props){
        super(props);
        this.state={}
    }

    componentDidMount() {
        const { field, masterEntityLookup } = this.props
        if (field.source == DATA_SOURCE_MASTER &&
            Object.keys(masterEntityLookup).length > 0 &&
            (this.props.genders || this.props.genders.length === 0)) {
            this.props.fetchMasterData(TITLE_GENDER, masterEntityLookup)
        }
    }

    componentDidUpdate(prevProps, prevState){
        if (this.props.field.source == DATA_SOURCE_DEFAULT) {
        
            const config = getCurrentProgramFromDefaultConfig(this.props.defaultConfig)
            if (config && Object.keys(config).length > 0 && config[this.props.field.sourceKey] &&
                config[this.props.field.sourceKey] != this.state[this.props.field.sourceKey])

                this.setState({
                    [this.props.field.sourceKey]: config[this.props.field.sourceKey]
                })
        }
    }

    render() {
        const { t, onChange, label, field, value } = this.props;
        return (
            <div className="form-group">
                <label htmlFor={field.id}>{t(`form.${field.name}.label`)} {field.isRequired && <span className="text-warning">*</span>}</label>
                <select className="" value={value} id={field.id} onChange={event=>onChange(event)} data-test={field.name}>
                    {label&&<option value="">{label}</option>}
                    {
                        field.source == DATA_SOURCE_MASTER &&
                        this.props.genders.map((title, index) => {
                            return <option key={index} value={title.Gender}>{title.Gender}</option>
                        })
                    }
                    {
                        field.source == DATA_SOURCE_DEFAULT && this.state[field.sourceKey] &&
                        this.state[field.sourceKey].map((title, index) => {
                            return <option key={index} value={title.key}>{title.value}</option>
                        })
                    }
                    {
                        field.source == "values" &&
                        field.values.map((title, index) => {
                            return <option key={index} value={title.key}>{title.value}</option>
                        })
                    }
                </select>
            </div>
        )
    }
}

Gender.defaultProps = {
    value: '',
    label: '',
    onChange: ()=>{},
    field: {}
}

const mapStateToProps = state => {
    return({
        genders: state.masterData[TITLE_GENDER]?state.masterData[TITLE_GENDER]:[],
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        masterEntityLookup: state.masterEntityDataReducer.masterEntityLookup
    })
}

const mapDispatchToProps = { fetchMasterData }

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(Gender)));