import React from 'react';
import { withTranslation } from 'react-i18next';
import { withSuspense } from '../../utils';
import { connect } from 'react-redux';
import { fetchMasterData } from '../../middleware/redux/commonAction';
import {
    TITLE_GENDER, CONFIG_SECTION_DEFAULT, DATA_SOURCE_DEFAULT, DATA_SOURCE_MASTER,
} from '../../utils/Constants'
import { getCurrentProgramFromDefaultConfig } from '../../utils/configurationFiles.utils';
/**
 * @author Somdas M
 * Component to fetch title data and render dropdown
 */
class FirstName extends React.Component {

    constructor(props) {
        super(props);
        this.state = {}
    }

    componentDidMount() {
        const { field, masterEntityLookup } = this.props
        if (field.additional.find(f => f.name == "title").source == DATA_SOURCE_MASTER && 
            Object.keys(masterEntityLookup).length > 0 &&
            (!this.props.masterTitles || this.props.masterTitles.length === 0)) {
            this.props.fetchMasterData(TITLE_GENDER, masterEntityLookup)
        }
    }

    componentDidUpdate(prevProps, prevState) {
        if (this.props.field.additional.find(f=>f.name=="title").source == DATA_SOURCE_DEFAULT) {

            const config = getCurrentProgramFromDefaultConfig(this.props.defaultConfig)
            if (config && Object.keys(config).length > 0 && config[this.props.field.additional.find(field=>field.source == DATA_SOURCE_DEFAULT).sourceKey] &&
                config[this.props.field.additional.find(field=>field.source == DATA_SOURCE_DEFAULT).sourceKey] != this.state[this.props.field.additional.find(field=>field.source == DATA_SOURCE_DEFAULT).sourceKey])

                this.setState({
                    [this.props.field.additional.find(field=>field.source == DATA_SOURCE_DEFAULT).sourceKey]: config[this.props.field.additional.find(field=>field.source == DATA_SOURCE_DEFAULT).sourceKey]
                })
        }
    }

    render() {
        const { t, field, error } = this.props;
        return (
            <div className="form-group">
                        <label htmlFor={field.additional.find(f=>f.name=="title").id}>{t(`form.${field.name}.label`)} {field.isRequired && <span className="text-warning">*</span>}</label>
                        <div className="input-group">
                            <div className="input-group-prepend">
                                <select className="custom-select" value={this.props.data["title"]} onChange={(e) => this.props.handleChange("title", e,field.additional.find(f=>f.name=="title").path)} id={field.additional.find(f=>f.name=="title").id} data-test="title">
                                    <option value="">{t("form.title.placeholder")}</option>
                                    {
                                        field.additional.find(f=>f.name=="title").source == DATA_SOURCE_MASTER &&
                                        this.props.masterTitles.map((titleObj, index) => {
                                            return <option key={index} value={titleObj.TitleCode}>{titleObj.TitleName}</option>
                                        })
                                    }
                                    {
                                        field.additional.find(f=>f.name=="title").source == DATA_SOURCE_DEFAULT && this.state[field.additional.find(fieldObj=>fieldObj.source == DATA_SOURCE_DEFAULT).sourceKey] &&
                                        this.state[field.additional.find(fieldObj=>fieldObj.source == DATA_SOURCE_DEFAULT).sourceKey].map((titleObj, index) => {
                                            return <option key={index} value={titleObj.key}>{titleObj.value}</option>
                                        })
                                    }
                                    {
                                        field.additional.find(f=>f.name=="title").source == "values" &&
                                        field.additional.find(f=>f.name=="title").values.map((titleObj, index) => {
                                            return <option key={index} value={titleObj.key}>{titleObj.value}</option>
                                        })
                                    }
                                </select>
                            </div>
                            <input type="text" className={`${error?' is-invalid':''}`} aria-label="Text input with dropdown button" id={field.id} placeholder={t(`form.${field.name}.placeholder`)} value={this.props.data[field.name]} onChange={(e) => this.props.handleChange(field.name, e)} data-test={field.name}/>
                        </div>
                    </div>
        )
    }
}

FirstName.defaultProps = {
    value: '',
    label: '',
    onChange: () => { },
    error: false
}

const mapStateToProps = state => {
    return ({
        masterTitles: state.masterData[TITLE_GENDER] ? state.masterData[TITLE_GENDER] : [],
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        masterEntityLookup: state.masterEntityDataReducer.masterEntityLookup
    })
}

const mapDispatchToProps = { fetchMasterData }

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(FirstName)));