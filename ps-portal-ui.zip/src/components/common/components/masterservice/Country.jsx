import React from 'react'
import { fetchMasterData } from '../../middleware/redux/commonAction';
import { withSuspense } from '../../utils';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import {
    COUNTRY_ISD,
    CONFIG_SECTION_DEFAULT,
    DATA_SOURCE_DEFAULT,
    DATA_SOURCE_MASTER
} from '../../utils/Constants'
import { getCurrentProgramFromDefaultConfig } from '../../utils/configurationFiles.utils';

class Country extends React.Component {

    constructor(props){
        super(props);
        this.state={}
    }

    componentDidMount() {
        const { field, masterEntityLookup } = this.props
        if (field.source == "master" && Object.keys(masterEntityLookup).length > 0 &&
            (!this.props.country_isd || this.props.country_isd.length === 0)) {
            this.props.fetchMasterData(COUNTRY_ISD, masterEntityLookup)
        }
    }

    componentDidUpdate(prevProps, prevState) {
        if (this.props.field.source == DATA_SOURCE_DEFAULT) {

            const config = getCurrentProgramFromDefaultConfig(this.props.defaultConfig)
            if (config && Object.keys(config).length > 0 && config[this.props.field.sourceKey] &&
                config[this.props.field.sourceKey] != this.state[this.props.field.sourceKey])
                this.setState({
                    [this.props.field.sourceKey]: config[this.props.field.sourceKey]
                })
        }
    }

    render() {
        const { t, field, label, placeholder } = this.props
        return (
            <div className="form-group" key={field.id}>
                <label htmlFor={field.id}>{t(label)} {field.isRequired && <span className="text-warning">*</span>}</label>
                <div className="input-group-prepend">
                    <select className="" value={this.props.data[field.name]} id={field.id} onChange={(e) => { this.props.handleChange(field.name, e) }} data-test={field.name}>
                        <option value="">{t(placeholder)}</option>
                        {
                                        field.source == DATA_SOURCE_MASTER &&
                                        this.props.country_isd.map((title, index) => {
                                            return <option key={index} value={title.CountryCode}>{title.CountryName}</option>
                                        })
                                    }
                                    {
                                        field.source == DATA_SOURCE_DEFAULT && this.state[field.sourceKey] &&
                                        this.state[field.sourceKey].map((title, index) => {
                                            return <option key={index} value={title.key}>{title.value}</option>
                                        })
                                    }
                                    {
                                        field.source == "values" &&
                                        field.values.map((title, index) => {
                                            return <option key={index} value={title.key}>{title.value}</option>
                                        })
                                    }
                    </select>
                </div>
            </div>
        )
    }
}

Country.defaultProps = {
    value: '',
    label: '',
    onChange: () => { }
}

const mapStateToProps = state => {
    return ({
        country_isd: state.masterData[COUNTRY_ISD] ? state.masterData[COUNTRY_ISD] : [],
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        masterEntityLookup: state.masterEntityDataReducer.masterEntityLookup
    })
}

const mapDispatchToProps = { fetchMasterData }

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(Country)));