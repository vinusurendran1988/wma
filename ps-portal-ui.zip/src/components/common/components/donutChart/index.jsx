import React, { Component } from 'react';
import { withSuspense, numberWithCommas } from '../../utils';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import './index.css'
import Stars from './Stars';
import Plane from './Plane';

class DonutChart extends Component {
    constructor (props) {
        super(props)
        this.state = {
            message: ''
        }
        this.arc1Ref = React.createRef();
        this.arc2Ref = React.createRef();
        this.circleRef = React.createRef();
        this.rectRef = React.createRef();
        this.triangleRef = React.createRef();
        this.tooltipRef = React.createRef();
        this.text1Ref = React.createRef();
        this.text2Ref = React.createRef();
        this.iconRef = React.createRef();
    }

    componentDidMount() {
        this.setProgress();
    }

    /**
     * Method to compose the message based on point difference.
     * Invoke the drawProgressBar.
     * @author Alan Kuriakose
     */
    setProgress() {
        const { difference, t, nextTier, pointsAchieved, nextTarget, showDescription } = this.props
        if (showDescription) {
            let message = ''
            if (difference < 0) {
                message = <div className="small text-center"><strong>{numberWithCommas(Math.floor(-difference))}</strong> {t("overview.more_miles_than")} <strong>{nextTier}</strong></div>
            } else {
                message = <div className="small text-center"><strong>{numberWithCommas(Math.floor(difference))}</strong> {t("overview.more_miles_to")} <strong>{nextTier}</strong></div>
            }

            this.setState({
                message
            })
        }
        this.drawProgressBar(pointsAchieved, nextTarget < pointsAchieved ? pointsAchieved : nextTarget);
    }

    /**
     * Function to draw progress bar
     * @author Alan Kuriakose
     * @param {integer} achieved - points achieved
     * @param {integer} target - target points to achieve
     */
    drawProgressBar(achieved = 1, target = 1) {
        const centerX = 119;
        const centerY = 70;
        const radius = 55;
        const startAngle = 230;
        const endAngle = 490;
        const tooltipHeight = 15;
        const tooltipMid = tooltipHeight / 2;
        const smallerCircleRadius = 10;
        const triangleStart = 5;
        const triangleWidth = 1;
        const achievedAngle = startAngle + achieved * (endAngle - startAngle) / target;
        const isFirstHalf = target > 1 && achieved < target/2

        this.arc1Ref.current.setAttribute("d", this.describeArc(centerX, centerY, radius, startAngle, endAngle));
        this.arc2Ref.current.setAttribute("d", this.describeArc(centerX, centerY, radius, startAngle, achievedAngle));
        const circleCenter = this.polarToCartesian(centerX, centerY, radius, achievedAngle);
        this.circleRef.current.setAttribute("cx", circleCenter.x);
        this.circleRef.current.setAttribute("cy", circleCenter.y);
        
        const text = this.text2Ref.current;
        text.textContent = numberWithCommas(parseInt(achieved));
        if(isFirstHalf && typeof text.getBBox === "function") {
            const toolTipStart = circleCenter.x - (text.getBBox().width + 17 + smallerCircleRadius)
            this.tooltipRef.current.setAttribute('transform', `translate(${toolTipStart}, ${circleCenter.y - tooltipHeight / 2})`)
            const newTriangleStart = text.getBBox().width + 9 + triangleWidth

            const trianglepath = `M ${newTriangleStart} ${tooltipMid} L ${newTriangleStart - triangleWidth} ${tooltipMid - 1} L ${newTriangleStart - triangleWidth} ${tooltipMid + 1}  Z`;
            this.triangleRef.current.setAttribute('d', trianglepath);

            this.rectRef.current.setAttribute('x', 2);
            this.rectRef.current.setAttribute('y', 0);

            text.setAttribute('x', 5);
            text.setAttribute('y', tooltipMid + 5);
        } else {
            this.tooltipRef.current.setAttribute('transform', `translate(${circleCenter.x + smallerCircleRadius}, ${circleCenter.y - tooltipHeight / 2})`)
            const trianglepath = `M ${triangleStart} ${tooltipMid} L ${triangleStart + triangleWidth} ${tooltipMid - 1} L ${triangleStart + triangleWidth} ${tooltipMid + 1}  Z`;
            this.triangleRef.current.setAttribute('d', trianglepath);
            this.rectRef.current.setAttribute('x', triangleStart + triangleWidth);
            this.rectRef.current.setAttribute('y', 0);

            text.setAttribute('x', triangleStart + triangleWidth + 5);
            text.setAttribute('y', tooltipMid + 5);
        }

        this.iconRef.current.setAttribute('transform', `translate(${centerX - 22}, ${centerY - 25})`);
        this.rectRef.current.setAttribute('width', (typeof text.getBBox === "function") ? text.getBBox().width + 8 : 0)
        this.text1Ref.current.setAttribute('x', centerX);
        this.text1Ref.current.setAttribute('y', centerY + 30);
    }

    /**
     * Function to convert polar coordinates to rectangular coordinates
     * @author Alan Kuriakose
     * @param {integer} centerX - center x axis
     * @param {integer} centerY - center y axis
     * @param {integer} radius - radius
     * @param {integer} angleInDegrees - angle in degrees
     */
    polarToCartesian(centerX, centerY, radius, angleInDegrees) {
        const angleInRadians = (angleInDegrees - 90) * Math.PI / 180.0;

        return {
            x: centerX + (radius * Math.cos(angleInRadians)),
            y: centerY + (radius * Math.sin(angleInRadians))
        };
    }

    /**
     * Function to generate path for arc in svg
     * @author Alan Kuriakose
     * @param {integer} x - center x axis
     * @param {integer} y - center y axis
     * @param {integer} radius - radius
     * @param {integer} startAngle - start angle in degrees
     * @param {integer} endAngle - end angle in degrees
     */
    describeArc(x, y, radius, startAngle, endAngle) {

        const start = this.polarToCartesian(x, y, radius, endAngle);
        const end = this.polarToCartesian(x, y, radius, startAngle);

        const largeArcFlag = endAngle - startAngle <= 180 ? "0" : "1";

        const d = [
            "M", start.x, start.y,
            "A", radius, radius, 0, largeArcFlag, 0, end.x, end.y
        ].join(" ");

        return d;
    }
    render() {
        const { message } = this.state
        const { currentTier, nextTier, nextTarget, basePoints, t, icon, colors,name } = this.props;
        return (
            <>
                <div className=" text-center graphWrap">
                <p>{name}</p>
                    <svg width="238" height="118" alt="donut chart">
                        <path ref={this.arc1Ref} fill="none" stroke="#ddd" className="arc-path" />
                        <path ref={this.arc2Ref} fill="none" stroke="#446688" className="arc-path" />
                        <circle ref={this.circleRef} fill="orange" stroke="white" strokeWidth="2" r="10" />
                        <g ref={this.iconRef}>
                            {   icon && 
                                {
                                    "point": <Stars width={45} height={35} color={colors[nextTier.toLowerCase()] || colors.diamond} />,
                                    "flight": <Plane width={45} height={35} color={colors[nextTier.toLowerCase()] || colors.diamond} />
                                }[icon]
                            }
                        </g>
                        {<text ref={this.text1Ref} fontWeight="bold" textAnchor="middle" stroke={colors[nextTier.toLowerCase()] || colors.diamond} >{numberWithCommas(nextTarget)}</text>}
                        <g ref={this.tooltipRef}>
                            <path ref={this.triangleRef} fill="none" stroke="black" strokeWidth="3" className="tooltip-triangle" />
                            <rect ref={this.rectRef} height="15" fill="orange" rx="5" ry="5" />
                            <text ref={this.text2Ref} fontWeight="bold" fontSize="smaller" ></text>
                        </g>
                    </svg>
                    <div class="graph__tiername" >
                        <span class="text-uppercase">{currentTier}</span>
                        <span class="text-uppercase">{nextTier}</span>
                    </div>
                </div>
                {message}
                {basePoints && basePoints.expiryDate &&
                    <div className="text-danger small text-center">{basePoints.points} {t("overview.expiry_msg")} {new Date(basePoints.expiryDate).toDateString()}!</div>
                }
            </>
        );
    }
}


function mapStateToProps(state) {
    return {
    }
}

const mapDispatchToProps = { }

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(DonutChart)));