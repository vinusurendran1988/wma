import React from 'react';

/**
 * This renders a configurable svg star icon - color, width & height configurable
 * @author Alan Kuriakose
 */
export default class Plane extends React.Component {
    render() {
        const { width, height, color } = this.props;
        return (
            <svg aria-hidden="true"
                focusable="false"
                data-prefix="fas"
                data-icon="plane"
                role="img"
                xmlns="http://www.w3.org/2000/svg"
                width={width} height={height}
                viewBox="0 0 576 512"
                className="svg-inline--fa fa-plane fa-w-18 fa-3x">
                <path fill="currentColor"
                    d="M480 192H365.71L260.61 8.06A16.014 16.014 0 0 0 246.71 0h-65.5c-10.63 0-18.3 10.17-15.38 20.39L214.86 192H112l-43.2-57.6c-3.02-4.03-7.77-6.4-12.8-6.4H16.01C5.6 128-2.04 137.78.49 147.88L32 256 .49 364.12C-2.04 374.22 5.6 384 16.01 384H56c5.04 0 9.78-2.37 12.8-6.4L112 320h102.86l-49.03 171.6c-2.92 10.22 4.75 20.4 15.38 20.4h65.5c5.74 0 11.04-3.08 13.89-8.06L365.71 320H480c35.35 0 96-28.65 96-64s-60.65-64-96-64z" opacity="1" fillOpacity="0" stroke={color} strokeWidth="8" strokeOpacity="1">
                </path>
            </svg>
            // <svg xmlns="http://www.w3.org/2000/svg" width={width} height={height} viewBox="0 0 576 512">
            //         <path style={{transform: "rotate(13deg)"}} d="M554.048,185.274c-7.838-19.746-67.729-26.958-97.809-15.248c-19.825,7.716-79.059,31.442-79.059,31.442l-128.373,51.04    l-145.854,58.006L6.555,268.949c-2.072-0.881-4.477-0.186-5.744,1.697c-1.267,1.861-1.032,4.372,0.572,5.953l67.313,67.032    c-1.485,7.404,1.354,11.841,1.354,11.841c-5.604,2.557-8.298,9.043-6.017,14.824c2.32,5.807,8.774,8.679,14.619,6.638    c0.663,0.706,4.23,4.193,8.041,7.879c6.182,5.998,15.302,7.825,23.322,4.679l194.513-76.312l-47.371,51.486    c-3.188,3.478-3.099,8.815,0.203,12.187c1.546,1.564,3.108,3.146,4.667,4.723c3.128,3.146,8.07,3.479,11.599,0.82l160.66-121.336    l51.174-20.12C534.999,222.317,561.899,205.026,554.048,185.274z" opacity="1" fillOpacity="0" stroke={color} strokeWidth="8" strokeOpacity="1"/>
            //         <path style={{transform: "rotate(13deg)"}} d="M203.877,238.87l48.356,3.54l112.981-44.925l-161.461,17.201c-4.405,0.47-7.778,4.106-7.907,8.533    c-0.063,2.213-0.123,4.433-0.175,6.64C195.571,234.571,199.174,238.534,203.877,238.87z"/>
            
            // </svg>
        )
    }
}

Plane.defaultProps = {
    width: 131,
    height: 125,
    color: 'black'
}