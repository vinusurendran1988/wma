import React from 'react';

/**
 * This renders a configurable svg star icon - color, width & height configurable
 * @author Alan Kuriakose
 */
export default class Stars extends React.Component {
    render() {
        const { width, height, color } = this.props;
        return (
            <svg version="1.1" preserveAspectRatio="xMidYMid meet" viewBox="0 0 131 125" width={width} height={height}>
                <g>
                    <g>
                        <g>
                            <g>
                                <path d="M55.55 76.65L33.42 50.37L65.77 45.26L68.68 37.96L60.66 37.96L47.66 7.31L33.42 37.96L6.05 43.07L27.08 67.16L20.51 102.2L47.66 83.22L55.55 89.79L51.17 117.53" opacity="1" fillOpacity="0" stroke={color} strokeWidth="8" strokeOpacity="1"></path>
                            </g>
                        </g>
                        <g>
                            <g>
                                <path d="M56.28 75.92L35.18 51.1L66.5 45.26L81.09 10.23L94.96 45.26L125.39 51.1L102.99 78.11L110.29 118.26L78.68 97.09L51.9 116.07L56.28 75.92Z" opacity="1" fillOpacity="0" stroke={color} strokeWidth="8" strokeOpacity="1"></path>
                            </g>
                        </g>
                    </g>
                </g>
            </svg>
        )
    }
}

Stars.defaultProps = {
    width: 131,
    height: 125,
    color: 'black'
}