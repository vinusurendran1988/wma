export const ID_CONFIRM_BUTTON = "add-edit-popup-confirm-button"
export const ID_CANCEL_BUTTON = "add-cancel-popup-confirm-button"