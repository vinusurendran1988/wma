import React from 'react';
import { withSuspense } from '../../utils';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { Dialog } from 'primereact/dialog';
import Section from '../../../ui/updateprofile/Section'
import CustomMessage from '../custommessage/index';
import { ID_CONFIRM_BUTTON, ID_CANCEL_BUTTON } from './Constants';
import Button from '../fieldbank/Button';

class AddEditPopup extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            request: props.request,
            isSubmitButtonClicked: false
        }
    }

    /**
     * 
     * @author Ajmal V Aliyar
     */
    componentDidMount() {
    }

    componentDidUpdate(prevProps) {
    }

    render() {
        const {
            t,
            id,
            isVisible,
            i18Path,
            onPopupHide,
            onClickCancel,
            onClickConfirm,
            layout,
            request,
            messages,
            isSuccessMessage,
            canTranslateMessage,
            showWarningAndError
        } = this.props
        const {
            isSubmitButtonClicked
        } = this.state

        const dynamicAttributeProperties = {
            "path": this.props.dynamicAttributesPath,
            "attributes": this.props.dynamicAttributes
        }

        return (
            <Dialog
                className="managePeopleDialogBox"
                aria-labelledby={`${id}Label`} //not sure
                aria-modal="true" //not sure
                id={id}
                visible={isVisible}
                header={t(`${i18Path}.header`)}
                onHide={() => onPopupHide()}
                footer={
                    <div className="btn-wrap btn-wrap--grp">
                        <Button
                            className="btn btn-secondary"
                            handleOnClick={() => onClickCancel()}
                            id={ID_CANCEL_BUTTON}
                            data-test={ID_CANCEL_BUTTON}
                            label={t(`${i18Path}.button_cancel`)} />
                        <Button
                            className="btn btn-primary"
                            handleOnClick={() => onClickConfirm()}
                            id={ID_CONFIRM_BUTTON}
                            data-test={ID_CONFIRM_BUTTON}
                            label={t(`${i18Path}.button_confirm`)} />
                    </div>
                }
            >
                <div className="modal-body">
                    {
                        showWarningAndError &&
                        (messages && messages.length > 0) &&
                        <CustomMessage
                            type={isSuccessMessage ? "success" : "danger"}
                            message={messages}
                            canTranslate={canTranslateMessage}
                        />
                    }
                    {
                        layout &&
                        layout.order &&
                        layout.order.length &&
                        layout.elements &&
                        layout.order.map((section, i) => {
                            return <Section
                                key={i}
                                page={"form"}
                                id={section}
                                displayElements={layout.elements[section]}
                                request={request}
                                onRequestChange={(req) => this.props.onRequestChange(req)}
                                dynamicAttributes={dynamicAttributeProperties}
                                errorCodes={messages}
                                showWarningAndError={showWarningAndError}
                                onErrorCodes={(codes) => this.props.onErrorCodes(codes)}
                                isButtonClicked={isSubmitButtonClicked}
                                findValueFromState={(stateFieldName, fieldType) => this.props.findValueFromState(stateFieldName, fieldType)}
                            />
                        })
                    }
                </div>
            </Dialog >
        )
    }
}

AddEditPopup.defaultProps = {
};

const mapStateToProps = (state) => {
    return {
    }
}

const mapDispatchToProps = {
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(AddEditPopup)));