import React from 'react';
import { withSuspense } from '../../utils';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { Dialog } from 'primereact/dialog';
import CustomMessage from '../custommessage/index';
import { 
    POPUP_TYPE_INFO, 
    POPUP_TYPE_WARNING, 
    POPUP_TYPE_CONFIRMATION, 
    ID_SIMPLE_POPUP 
} from './Constants';
import Button from '../fieldbank/Button';

class Popup extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            displayCancelButton: false
        }
    }

    /**
     * 
     * @author Ajmal V Aliyar
     */
    componentDidMount() {
        this.initializePopupWithType()
    }

    initializePopupWithType() {
        const { popupType } = this.props
        let displayCancelButton
        switch (popupType) {
            case POPUP_TYPE_INFO:
                displayCancelButton = false
                break
            case POPUP_TYPE_WARNING:
                displayCancelButton = false
                break
            case POPUP_TYPE_CONFIRMATION:
                displayCancelButton = true
                break
            default:
                displayCancelButton = false
        }
        this.setState({ displayCancelButton })
    }

    componentDidUpdate(prevProps) {

    }

    render() {
        const {
            t,
            isVisible,
            id,
            i18Path,
            onPopupHide,
            onClickCancel,
            onClickConfirm,
            errors,
            isSuccessMessage,
            canTranslateMessage
        } = this.props
        const {
            displayCancelButton
        } = this.state

        return (
            <Dialog
                aria-labelledby={`${id}Label`} //not sure
                aria-modal="true" //not sure
                id={id}
                visible={isVisible}
                header={t(`${i18Path}.header`)}
                onHide={() => onPopupHide()}
                footer={
                    <div className="btn-wrap btn-wrap--grp">
                        {
                            displayCancelButton &&
                            <button
                                type="button"
                                className="btn btn-secondary"
                                onClick={() => onClickCancel()}
                            >
                                {t(`${i18Path}.button_cancel`)}
                            </button>
                        }
                        <Button
                            className="btn btn-primary"
                            handleOnClick={() => onClickConfirm()}
                            id={ID_SIMPLE_POPUP}
                            data-test={ID_SIMPLE_POPUP}
                            label={t(`${i18Path}.button_confirm`)} />
                    </div>
                }
            >
                <div className="modal-body">

                    {<CustomMessage
                        type={isSuccessMessage ? "success" : "danger"}
                        message={errors}
                        canTranslate={canTranslateMessage}
                    />}
                    <p>{t(`${i18Path}.text`)}</p>
                </div>
            </Dialog>
        )
    }
}

Popup.defaultProps = {
};

const mapStateToProps = (state) => {
    return {
    }
}

const mapDispatchToProps = {
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(Popup)));