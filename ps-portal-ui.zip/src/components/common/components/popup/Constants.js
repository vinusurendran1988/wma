export const POPUP_TYPE_WARNING = "warning"
export const POPUP_TYPE_INFO = "info"
export const POPUP_TYPE_CONFIRMATION = "confirmation"
export const ID_SIMPLE_POPUP = "id-simple-popup"