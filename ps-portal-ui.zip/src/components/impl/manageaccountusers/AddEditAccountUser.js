import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import CustomMessage from '../../common/components/custommessage';
import AlertBox from '../../common/components/fieldbank/AlertBox';
import Button from '../../common/components/fieldbank/Button';
import { clearValidateResponse, resetError, setError, validateMemberDetails } from '../../common/middleware/redux/commonAction';
import { getApiErrorMessage, isEmptyOrSpaces, withSuspense } from '../../common/utils';
import { ACCOUNT_USER_PRIVILEGE, CONFIG_SECTION_DEFAULT, CONFIG_SECTION_MANAGE_ACCOUNT_USERS, RELATIONSHIP } from '../../common/utils/Constants';
import { doAdditionalMapping } from '../../common/utils/object.utils';
import Section from '../../ui/updateprofile/Section';
import { addAccountUser, editAccountUser } from './actions';
import { ACCOUNT_STATUS, ADD_ACCOUNT_USER, ADD_MEMBER, DANGER, EDIT_ACCOUNT_USER, EDIT_MEMBER, TAB_MEMBER, VALIDATE_MEMBER } from './Constants';
class AddEditAccountUser extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedTab: TAB_MEMBER,
            showWarningAndErrorValidate: false,
            showWarningAndErrorAdd: false,
            isValidateButtonClicked: false,
            isAddButtonClicked: false,
            isEditButtonClicked: false,
            userAddedSuccess: false,
            request: {},
            validateUserResponseObject: {},
            isValidationSuccess: false,
            validateMemberError: [],
            addUserError: [],
            editUserError: [],
            addUserAccountRequest: {},
            editUserAccountRequest: {},
            accountStatus: "",
            apiResponse: {
                type: "",
                messages: [],
                canTranslate: false
            },
            translate: false,
            disableValidateInfo: true
        }
    }
    componentDidMount() {
        const { type } = this.props
        if (type == "edit") {
            this.initializeEditPage()
        }
        else {
            this.initializePage()

        }
    }

    componentDidUpdate(prevProps) {
        const { config, errors, memberData, t } = this.props
        const { addUserAccountRequest, request } = this.state
        if (this.props.memberData && Object.keys(this.props.memberData).length > 0) {
            if (JSON.stringify(prevProps.memberData) !== JSON.stringify(this.props.memberData)) {
                if (memberData && memberData.error) {
                    if (memberData.error.errorDetails && !this.state.apiResponse.messages) {
                        this.setState({
                            apiResponse: {
                                type: "danger",
                                message: getApiErrorMessage(memberData.error),
                            }
                        })
                    }
                }
                else {
                    if (config) {
                        if (config.ui && config.ui.layout &&
                            config.ui.layout.elements && config.ui.layout.elements &&
                            config.ui.layout.elements.add_account_user &&
                            config.ui.layout.elements.add_account_user.elements &&
                            config.ui.layout.elements.add_account_user.elements.basic_info &&
                            config.ui.layout.elements.add_account_user.elements.basic_info.request &&
                            config.ui.layout.elements.add_account_user.elements.basic_info.request.additionalMapping
                        ) {
                            doAdditionalMapping(this, "addUserAccountRequest", config.ui.layout.elements.add_account_user.elements.basic_info.request.additionalMapping)
                        }
                    }

                    this.setState({
                        isValidationSuccess: true,
                        disableValidateInfo: false,
                        addUserError: [],
                        validateMemberError: [],
                        validateUserResponseObject: {
                            object: this.props.memberData
                        }
                    })
                }
            }

        }
        if (errors) {
            if (errors.message && JSON.stringify(errors) != JSON.stringify(prevProps.errors)) {
                this.setState({
                    apiResponse: {
                        type: DANGER,
                        message: getApiErrorMessage(errors),
                    },
                    isValidationSuccess: false
                })
            }
        }
        if (this.props.userAddedResponse && JSON.stringify(prevProps.userAddedResponse) != JSON.stringify(this.props.userAddedResponse)) {
            if (this.props.userAddedResponse.statuscode == 200) {
                let name
                if (addUserAccountRequest && addUserAccountRequest.object && addUserAccountRequest.object.nomineeDetails &&
                    Object.keys(addUserAccountRequest.object.nomineeDetails).length > 0) {
                    name = addUserAccountRequest.object.nomineeDetails[0].givenName + " "
                        + addUserAccountRequest.object.nomineeDetails[0].familyName
                }
                let reqCopy = JSON.parse(JSON.stringify(request))
                reqCopy.object.givenName = ""
                reqCopy.object.membershipNumber = ""
                this.setState({
                    userAddedSuccess: true,
                    apiResponse: {
                        type: "success",
                        message: t('corpReg.addMember.inviteSent').replace("{NAME}", name)
                    },
                    isValidationSuccess: false,
                    request:reqCopy,
                    // addUserAccountRequest:{},
                    // disableValidateInfo : false
                })
                this.props.userAdded();
            } else if (this.props.userAddedResponse && this.props.userAddedResponse.error && this.props.userAddedResponse.error.length > 0) {
                this.setState({
                    apiResponse: {
                        type: DANGER,
                        message: this.props.userAddedResponse.error.length > 0 &&
                            getApiErrorMessage(this.props.userAddedResponse.error[0].error)
                    },
                    isValidationSuccess: false,
                    disableValidateInfo: true
                })
            }
        }
        if (this.props.userUpdatedResponse && JSON.stringify(prevProps.userUpdatedResponse) != JSON.stringify(this.props.userUpdatedResponse)) {
            if (this.props.userUpdatedResponse.statuscode == "200") {

                this.setState({
                    userUpdatedSuccess: true,
                    apiResponse: {
                        type: "success",
                        message: t('corpReg.addMember.editSuccess')
                    }
                })
                window.scrollTo(0, 0)

            } else if (this.props.userUpdatedResponse && this.props.userUpdatedResponse.error && this.props.userUpdatedResponse.error.length > 0) {
                this.setState({
                    apiResponse: {
                        type: DANGER,
                        message: this.props.userUpdatedResponse.error.length > 0 && getApiErrorMessage(this.props.userUpdatedResponse.error[0].error),
                    },
                    isValidationSuccess: false,
                    disableValidateInfo: true
                })
                window.scrollTo(0, 0)
            }
        }

    }



    /**
    * Initialize the page
    * 
    * @author Amrutha J Raj
    */
    initializePage() {
        const { config } = this.props

        if (config) {
            if (config.ui && config.ui.layout &&
                config.ui.layout.elements && config.ui.layout.elements &&
                config.ui.layout.elements.add_account_user &&
                config.ui.layout.elements.add_account_user.elements &&
                config.ui.layout.elements.add_account_user.elements.validate_info &&
                config.ui.layout.elements.add_account_user.elements.validate_info.request &&
                config.ui.layout.elements.add_account_user.elements.validate_info.request.additionalMapping
            ) {
                doAdditionalMapping(this, "request", config.ui.layout.elements.add_account_user.elements.validate_info.request.additionalMapping)
            }
        }
    }

    initializeEditPage() {
        const { config } = this.props
        if (config) {
            if (config.ui && config.ui.layout && config.ui.layout.elements && config.ui.layout.elements &&
                config.ui.layout.elements.edit_account_user &&
                config.ui.layout.elements.edit_account_user.elements &&
                config.ui.layout.elements.edit_account_user.elements.basic_info &&
                config.ui.layout.elements.edit_account_user.elements.basic_info.request &&
                config.ui.layout.elements.edit_account_user.elements.basic_info.request.additionalMapping) {
                doAdditionalMapping(this, "editUserAccountRequest", config.ui.layout.elements.edit_account_user.elements.basic_info.request.additionalMapping)

            }
        }
    }
    /**
  * Handle request change for textfield from Section
  * @param {Object} request
  * @author Amrutha J Raj
  */
    handleRequestChange(request, key) {
        const payload = {}
        if (key == VALIDATE_MEMBER) {
            this.setState({ request })
        }
        else if (key == ADD_MEMBER) {
            this.setState({ addUserAccountRequest: request })
        }
        else if (key == EDIT_MEMBER) {
            this.setState({ editUserAccountRequest: request, apiResponse: undefined })

        }
        this.setState({
            showWarningAndErrorValidate: false,
            showWarningAndErrorAdd: false,
            apiResponse : {}
        })
    }

    /**
     * Handle validation error messages from Section
     * @param {key} request
     * @param {codes} codes
     * @author Amrutha J Raj
     */
    handleErrorMessagesFromSection(key, codes) {
        if (!codes.length) { this.props.resetError() }
        if (JSON.stringify(codes) != JSON.stringify(this.state[key])) {
            this.setState({ [key]: codes })
        }
    }


    /**
    * Set state from Section
    * @param {Object} field
    * @param {String} value
    * 
    * @author Amrutha J Raj
    */
    addValueToState(field, value) {
        let newState = {}
        newState[field.name] = value
        this.setState(newState)
    }

    /**
    * Method to handle validations from Section
    * @param {Object} field
    * @param {Object} validation
    * @param {String} value 
    *
    * @author Amrutha J Raj
    */
    validateWithStateVariable(field, validation, value, key) {
        let { pattern, fields } = validation
        let isValidationSuccess = true, canUpdateState = false
        fields.forEach((fd) => {
            const newPattern = pattern.replace("[fields]", this.state[fd])
            if (!isPatternMatch(newPattern, value)) {
                isValidationSuccess = false
            }
        })
        let errorCodes = this.state[key]
        if (!isValidationSuccess) {
            if (!errorCodes.includes(validation.customMessageId)) {
                errorCodes.push(validation.customMessageId)
                canUpdateState = true
            }
        } else if (errorCodes.includes(validation.customMessageId)) {
            const index = errorCodes.indexOf(validation.customMessageId)
            if (index > -1) {
                canUpdateState = true
                errorCodes.splice(index, 1)
            }
        }
        field.error = !isValidationSuccess
        if (canUpdateState) {
            this.setState({
                [key]: errorCodes,
                translate: true
            })
        }
        return !isValidationSuccess
    }

    /**
    * Method to find value from state
    * @param {Object} stateFieldName
    * 
    * @author Amrutha J Raj
    */
    findValueFromState(stateFieldName) {
        return this.state[stateFieldName] ? this.state[stateFieldName] : ""
    }

    /**
    * Method to validate member
    * 
    * 
    * @author Amrutha J Raj
    */
    validateMember = () => {
        const { validateMemberError, request } = this.state;
        this.setState({ addUserError: [], apiResponse: {} })
        if (validateMemberError.length > 0) {
            this.props.setError(validateMemberError);
        } else {
            this.props.validateMemberDetails(request)
        }
        this.setState({
            showWarningAndErrorValidate: true,
            isValidateButtonClicked: true
        })


    }

    /**
    * Method to reset form data
    * 
    * 
    * @author Amrutha J Raj
    */
    resetFormData() {
        this.props.resetError()
        this.props.clearValidateResponse()

        this.setState({
            isValidateButtonClicked: false,
            isAddButtonClicked: false,
            request: {},
            disableValidateInfo: true,
            validateUserResponseObject: {},
            isValidationSuccess: false,
            addUserAccountRequest: {},
            showWarningAndErrorValidate: false,
            showWarningAndErrorAdd: false
        }, () => {
            this.initializePage()

        })
    }

    /**
    * Method to add new member to the corporate
    * 
    * 
    * @author Amrutha J Raj
    */
    addAccountUser = (customerDynamicAttribute) => {
        const { addUserError } = this.state;
        const { config, companyData } = this.props
        if (addUserError.length > 0) {
            this.props.setError(addUserError);
        } else {
            if (config) {
                if (config.ui && config.ui.layout &&
                    config.ui.layout.elements && config.ui.layout.elements &&
                    config.ui.layout.elements.add_account_user &&
                    config.ui.layout.elements.add_account_user.elements &&
                    config.ui.layout.elements.add_account_user.elements.basic_info &&
                    config.ui.layout.elements.add_account_user.elements.basic_info.request &&
                    config.ui.layout.elements.add_account_user.elements.basic_info.request.additionalMapping
                ) {
                    const request = this.getRequestBodyAdd(customerDynamicAttribute)
                    this.props.addAccountUser(request, ADD_ACCOUNT_USER, companyData)
                }
            }
        }
        this.setState({
            showWarningAndErrorAdd: true,
            isAddButtonClicked: true
        })

    }
    getRequestBodyAdd = (customerDynamicAttribute) => {
        const { addUserAccountRequest } = this.state
        const {memberData}=this.props
        let requestBody = JSON.parse(JSON.stringify(addUserAccountRequest))
        if (requestBody.object && requestBody.object.group && !isEmptyOrSpaces(requestBody.object.group)) {
            customerDynamicAttribute.map(item => {
                if (item.attributeCode == 27) {
                    item.attributeValue = requestBody.object.group
                }
                return item
            })
            requestBody.object.nomineeDetails[0].customerDynamicAttribute = customerDynamicAttribute
        }
        if(memberData && memberData.memberType=="D"){
            requestBody.object.nomineeDetails[0].membershipNumber = ""
        }
        delete requestBody.object["group"]
        console.log("requestBody ----add------- ", requestBody)
        return requestBody
    }

    getRequestBody = (customerDynamicAttribute) => {
        const { editUserAccountRequest } = this.state
        const { config, rowData, defaultConfig } = this.props
        let requestBody = JSON.parse(JSON.stringify(editUserAccountRequest))
        if (requestBody.object && requestBody.object.group && !isEmptyOrSpaces(requestBody.object.group)) {
            customerDynamicAttribute.map(item => {
                if (item.attributeCode == 27) {
                    item.attributeValue = requestBody.object.group
                }
                return item
            })
            requestBody.object.customerDynamicAttribute = customerDynamicAttribute
        }
        if (rowData && rowData.accountGroupType) {
            let accGroupType
            if (defaultConfig && defaultConfig.programs) {
                const prog = defaultConfig.programs.find(prog => prog.id == "defa_prg")
                if (prog && prog.data && prog.data.nomineeAccountGroupTypes) {
                    accGroupType = prog.data.nomineeAccountGroupTypes.find(item => item.value == rowData.accountGroupType)
                }
            }
            if (accGroupType && Object.keys(accGroupType).length > 0) {
                requestBody.object.accountGroupType = accGroupType.key
            }
        }
        delete requestBody.object["group"]
        console.log("requestBody ------edit----- ", requestBody)
        return requestBody
    }

    editAccountUser = (customerDynamicAttribute) => {
        const { editUserError } = this.state;
        const { config, row, companyData } = this.props
        if (editUserError.length > 0) {
            this.props.setError(editUserError);
        } else {
            const request = this.getRequestBody(customerDynamicAttribute)
            this.props.editAccountUser(request, "editAccountUser", companyData)

        }
        this.setState({
            showWarningAndErrorAdd: true,
            isAddButtonClicked: true
        })

    }

    getResponseObjectEditAccountUser = () => {
        const { rowData } = this.props
        if (rowData && rowData.customerDynamicAttribute) {
            const group = rowData.customerDynamicAttribute.find(item => item.attributeCode == "27")
            if (group && Object.keys(group).length > 0) {
                rowData.group = group.attributeValue
            }
        }
        return rowData
    }
    getResponseObjectAddUser = ()=>{
        const { memberData } = this.props
        if(memberData && Object.keys(memberData).length>0){
            memberData.name = memberData.givenName + " " +memberData.familyName
        }
        return memberData
    }

    renderAddAccountUser = () => {
        const { t, config } = this.props
        const { showWarningAndErrorAdd, isValidateButtonClicked, isAddButtonClicked,
            showWarningAndErrorValidate, apiResponse, selectedTab, validateMemberError, 
            addUserError, addUserAccountRequest, userAddedSuccess, request } = this.state
        const errorCodes = isAddButtonClicked ? [...validateMemberError, ...addUserError] : [...validateMemberError]
        const sectionElements = config && config.ui && config.ui.layout &&
            config.ui.layout.elements && config.ui.layout.elements.add_account_user &&
            config.ui.layout.elements.add_account_user.elements
        return (<div className="form">
            {!this.state.isValidationSuccess &&
                <>
                    <div className="">
                        {sectionElements && <Section
                            key={"add-account-user"}
                            page={"add_account_user"}
                            id={"add-account-user"}
                            displayElements={sectionElements.validate_info}
                            request={this.state.request}
                            canWrite={true}
                            onRequestChange={(req) => this.handleRequestChange(req, VALIDATE_MEMBER)}
                            dynamicAttributes={""}
                            errorCodes={this.state.validateMemberError}
                            handleOnClick={() => this.validateMember()}
                            showWarningAndError={showWarningAndErrorValidate}
                            onErrorCodes={(codes) => this.handleErrorMessagesFromSection(codes, "validateMemberError")}
                            isButtonClicked={isValidateButtonClicked}
                            addValueToState={(field, value) => this.addValueToState(field, value)}
                            validateWithStateVariable={(field, validation, value) => this.validateWithStateVariable(field, validation, value, "validateMemberError")}
                            template={sectionElements && sectionElements.template}

                            findValueFromState={(stateFieldName, fieldType) => this.findValueFromState(stateFieldName, fieldType)}
                        />}
                    </div>
                    <div className="btn-wrap btn-wrap--grp">
                        <Button
                            className="btn btn-primary"
                            enabled ={request.object && request.object.givenName && request.object.membershipNumber ? true : false}
                            handleOnClick={() => this.validateMember()}
                            id={"id-add"}
                            label={t("corpReg.addMember.btnFindMember")} />
                        <Button
                            className="btn btn-secondary"
                            handleOnClick={() => {
                                this.setState({ addUserError: [], apiResponse: {} })
                                this.props.backTriggered()}
                            }
                            id={"id-cancel"}
                            label={t("corpReg.addMember.btnBackToList")} />
                    </div>
                </>
            }

            {this.state.isValidationSuccess && this.props.memberData && Object.keys(this.props.memberData).length > 0
                && apiResponse && !apiResponse.messages
                ?
                <div className="">
                    {sectionElements && <Section
                        key={"add-account-user"}
                        page={"add_account_user"}
                        id={"add-account-user"}
                        displayElements={sectionElements.basic_info}
                        request={this.state.addUserAccountRequest}
                        response={this.getResponseObjectAddUser()}
                        onRequestChange={(req) => this.handleRequestChange(req, ADD_MEMBER)}
                        dynamicAttributes={""}
                        errorCodes={this.state.addUserError}
                        showWarningAndError={showWarningAndErrorAdd}
                        onErrorCodes={(codes) => this.handleErrorMessagesFromSection(codes, "addUserError")}
                        isButtonClicked={isAddButtonClicked}
                        addValueToState={(field, value) => this.addValueToState(field, value)}
                        validateWithStateVariable={(field, validation, value) => this.validateWithStateVariable(field, validation, value, "addUserError")}
                        findValueFromState={(stateFieldName, fieldType) => this.findValueFromState(stateFieldName, fieldType)}
                        template={config && config.ui && config.ui.template}
                        template={sectionElements && sectionElements.template}
                        onClick={() => { this.resetFormData() }
                        }

                    />}

                    <div className="btn-wrap btn-wrap--grp">
                        <Button
                            className="btn btn-primary"
                            enabled ={addUserAccountRequest.object && addUserAccountRequest.object.nomineeDetails &&
                                addUserAccountRequest.object.nomineeDetails[0] && 
                                addUserAccountRequest.object.nomineeDetails[0].accountGroupType ? true : false}
                            handleOnClick={() => this.addAccountUser(sectionElements.basic_info.customerDynamicAttribute)}
                            id={ADD_ACCOUNT_USER}
                            label={t("corpReg.addMember.btnSend")} />
                        <Button
                            className="btn btn-secondary"
                            handleOnClick={() => this.props.backTriggered()}
                            id={"id-cancel"}
                            label={t("corpReg.addMember.btnBackToList")} />

                    </div>
                </div>
                :
                ""
            }
        </div>)
    }
    renderEditAccountUser = () => {
        const { t, config } = this.props
        const { showWarningAndErrorAdd, isEditButtonClicked } = this.state
        const sectionElements = config && config.ui && config.ui.layout &&
            config.ui.layout.elements && config.ui.layout.elements.edit_account_user &&
            config.ui.layout.elements.edit_account_user.elements
        return (<div className="form">
            <div className="">
                {sectionElements && this.props.rowData && <Section
                    key={"edit-account-user"}
                    page={"edit_account_user"}
                    id={"edit-account-user"}
                    displayElements={sectionElements.basic_info}
                    request={this.state.editUserAccountRequest}
                    response={this.getResponseObjectEditAccountUser()}
                    onRequestChange={(req) => this.handleRequestChange(req, EDIT_MEMBER)}
                    dynamicAttributes={""}
                    errorCodes={this.state.addUserError}
                    showWarningAndError={showWarningAndErrorAdd}
                    onErrorCodes={(codes) => this.handleErrorMessagesFromSection(codes, "editUserError")}
                    isButtonClicked={isEditButtonClicked}
                    addValueToState={(field, value) => this.addValueToState(field, value)}
                    validateWithStateVariable={(field, validation, value) => this.validateWithStateVariable(field, validation, value, "editUserError")}
                    findValueFromState={(stateFieldName, fieldType) => this.findValueFromState(stateFieldName, fieldType)}
                    template={config && config.ui && config.ui.template}
                    template={sectionElements && sectionElements.template}
                    onClick={() => { this.resetFormData() }
                    }

                />}

                <div className="btn-wrap btn-wrap--grp">
                    <Button
                        className="btn btn-primary"
                        handleOnClick={() => this.editAccountUser(sectionElements.basic_info.customerDynamicAttribute)}
                        id={"editAccountUser"}
                        label={t("corpReg.addMember.btnEdit")} />
                    <Button
                        className="btn btn-secondary"
                        handleOnClick={() => this.props.backTriggered()}
                        id={"id-cancel"}
                        label={t("corpReg.addMember.btnBackToList")} />

                </div>
            </div>

        </div>)
    }
    renderPage = () => {
        switch (this.props.type) {
            case "add": return this.renderAddAccountUser()
            case "edit": return this.renderEditAccountUser()
        }
    }

    render() {
        const { t, config } = this.props
        const { apiResponse, addUserAccountRequest, userAddedSuccess } = this.state
        return (
            <div>
                <div>
                    {apiResponse && apiResponse.message &&
                        <AlertBox type={apiResponse.type}
                            message={apiResponse.message}
                        />
                    }
                    {/* {addUserAccountRequest && addUserAccountRequest.object && addUserAccountRequest.object.nomineeDetails &&
                        Object.keys(addUserAccountRequest.object.nomineeDetails).length > 0 && userAddedSuccess &&
                        <AlertBox type="success"
                            message={t("corpReg.addMember.inviteSent")
                                .replace("{NAME}", addUserAccountRequest.object.nomineeDetails[0].familyName + " " + addUserAccountRequest.object.nomineeDetails[0].givenName)} />
                    } */}

                </div>
                <div className="single-col-view">
                    {this.renderPage()}
                </div>

            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        memberData: state.validateMemberDetailReducer.validateMemberData,
        masterEntityLookup: state.masterEntityDataReducer.masterEntityLookup,
        config: state.configurationReducer[CONFIG_SECTION_MANAGE_ACCOUNT_USERS],
        relationship: state.masterData[RELATIONSHIP] ? state.masterData[RELATIONSHIP] : [],
        masterEntityLookupFilters: state.masterEntityDataReducer.masterEntityLookupFilters,
        userAddedResponse: state.addAccountUserReducer.response,
        userUpdatedResponse: state.editAccountUserReducer.response,
        errors: state.commonErrorReducer.error,
        accountStatusList: state.masterData[ACCOUNT_STATUS] ? state.masterData[ACCOUNT_STATUS] : [],
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT]

    }
}
const mapDispatchToProps = {
    setError,
    resetError,
    validateMemberDetails,
    addAccountUser,
    clearValidateResponse,
    editAccountUser
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(AddEditAccountUser)));
