import parse from 'html-react-parser';
import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import AlertBox from '../../common/components/fieldbank/AlertBox';
import Button from '../../common/components/fieldbank/Button';
import { clearValidateResponse, fetchConfiguration, fetchMasterData } from '../../common/middleware/redux/commonAction';
import { getApiErrorMessage, getCurrentDate, getDefaultFormattedDate, getFormattedDate, getRelativeDate, isEmptyOrSpaces, withSuspense } from '../../common/utils';
import { ACC_GROUP_TYPE, BLANK, CONFIG_SECTION_MANAGE_ACCOUNT_USERS, EXPORT_CSV, EXPORT_PDF, EXPORT_XLSX } from '../../common/utils/Constants';
import {
    BROWSER_STORAGE_KEY_COMPANY_CODE, 
    BROWSER_STORAGE_KEY_DEFAULT_PROGRAM_CODE, 
    BROWSER_STORAGE_KEY_PROGRAM_CODE, 
    getItemFromBrowserStorage,
    setItemToBrowserStorage
} from '../../common/utils/storage.utils';
import { DATE_FORMAT_DDMMYYYY_WITH_SPACE } from '../../ui/subscription/Constants';
import { fetchCompanyProfile } from '../companyProfile/action';
import AccountUsersTable from './AccountUsersTable';
import { retrieveAccountUsers } from './actions';
import AddEditAccountUser from './AddEditAccountUser';
import { DANGER, RESPONSE_SUCCESS, SUCCESS } from './Constants';


/**
 * Method to get request body for retrieve account users
 * @author Amrutha
 */

export const getRequestBodyRetrieveAccountUsers = (companyData) => {
    let requestPayload = {}
    requestPayload.companyCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE)
    requestPayload.programCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_DEFAULT_PROGRAM_CODE)
    requestPayload.membershipNumber = companyData.companyId
    return requestPayload
}

/**
 * Component to manage users
 * @author Amrutha
 */

class ManageAccountUsers extends Component {
    constructor(props) {
        super(props);
        this.state = {
            showSuccessMessage: false,
            apiResponse: {},
            editOrAddPage: "",
            rowData: {},
            exportFlag: false,
            globalFilter: "",


        }
    }

    componentDidMount() {
        setItemToBrowserStorage("overView", "")
        // this.props.setPageInfo(this.props, { config: this.props.manageAccountUsersConfig, confSection: CONFIG_SECTION_MANAGE_ACCOUNT_USERS })
        const { companyProfile, config } = this.props
        if (!this.props.accountGroupType || this.props.accountGroupType.length == 0) {
            this.props.fetchMasterData(ACC_GROUP_TYPE, this.props.masterEntityLookup, this.props.masterEntityLookupFilters)
        }
        if (!companyProfile || companyProfile && Object.keys(companyProfile).length == 0) {
            const requestBody = {
                "object": {
                    "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                    "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_DEFAULT_PROGRAM_CODE),
                    "membershipNumber": this.props.companyData.companyId
                }
            }
            this.props.fetchCompanyProfile(requestBody)
        }
        this.populateNomineeList()
    }

    componentDidUpdate(prevProps) {
        const { updateAccountUserResponse, deleteAccountUserResponse, userAddedResponse, t, accountUsers } = this.props
        const apiResponse = {}

        if (JSON.stringify(prevProps.deleteAccountUserResponse) !== JSON.stringify(deleteAccountUserResponse)) {
            // if (deleteAccountUserResponse && deleteAccountUserResponse.statusMessage == RESPONSE_SUCCESS) {
            // }
            if (deleteAccountUserResponse && deleteAccountUserResponse.error) {
                apiResponse["type"] = DANGER
                apiResponse["message"] = deleteAccountUserResponse.error.length > 0 && getApiErrorMessage(deleteAccountUserResponse.error[0].error)
            }
            else if (deleteAccountUserResponse && deleteAccountUserResponse.statusMessage == RESPONSE_SUCCESS) {
                apiResponse["type"] = SUCCESS
                apiResponse["message"] = t('corpReg.addMember.deleteSuccess')
                console.log("Deleted success in corp nomineeesss");
            }
            this.setState({ apiResponse })

        }
        if (this.state.exportStr && this.state.exportStr.length > 0) {
            this.setState({ exportStr: "" })
        }

    }

    /**
    * Invokes API call to retrieve nominees so that it can be displayed in table.
    * 
    * @author Amrutha J Raj
    */
    populateNomineeList = () => {
        this.props.retrieveAccountUsers({
            object: getRequestBodyRetrieveAccountUsers(this.props.companyData)
        })
    }

    /**
    * Callback method when add account user is success
    * 
    * @author Amrutha J Raj
    */
    getUserAddedResponse() {
        this.setState({ showSuccessMessage: true })
        this.populateNomineeList()
    }

    /**
   * Get table columns from configuration 
   * 
   * @author Amrutha J Raj
   */
    getTableColumnsFromConfig = () => {
        const { manageAccountUsersConfig } = this.props
        // if (privilegeCheck) {
        if (manageAccountUsersConfig && manageAccountUsersConfig.ui && manageAccountUsersConfig.ui.layout &&
            manageAccountUsersConfig.ui.layout.elements && manageAccountUsersConfig.ui.layout.elements &&
            manageAccountUsersConfig.ui.layout.elements.view_account_users && manageAccountUsersConfig.ui.layout.elements.view_account_users.table
            && manageAccountUsersConfig.ui.layout.elements.view_account_users.table) {
            return manageAccountUsersConfig.ui.layout.elements.view_account_users.table

        }
    }

    editMember = (rowData) => {
        this.setState({ rowData: rowData }, () => {
            this.setState({ editOrAddPage: "edit" })
        })
    }

    getNomineeDetailsForTable = () => {
        const { accountUsers } = this.props
        accountUsers.nomineeDetails.map(nominee => {
            nominee.name = nominee.givenName + " " + nominee.familyName
            const groupObject = nominee.customerDynamicAttribute.find(item => item.attributeCode == "27")
            if (groupObject) {
                nominee.groupName = groupObject.attributeValue
            }
            else {
                nominee.groupName = BLANK
            }
            if (nominee.status) {
                if (nominee.status == "KORU_MEMBER" || nominee.status == "NO_MEMBERSIHP" ||
                    nominee.status == "EXPIRING" || nominee.status == "INVITED" ||
                    nominee.status == "EXPIRED") {
                    nominee.status = this.props.t(`corpReg.listUsers.status.${nominee.status}`)
                }
                else if (nominee.status == "" || nominee.status == null) {
                    nominee.status = BLANK
                }
            }
            if (nominee.tierStatus == "" || nominee.tierStatus == null) {
                nominee.tierStatus = BLANK
            }
            return nominee
        })

        return accountUsers.nomineeDetails
    }

    getNomineeDetailsForDownload = () => {
        const nomineeDetails = JSON.parse(JSON.stringify(this.getNomineeDetailsForTable()))
        const relativeDate = getRelativeDate(getFormattedDate(getCurrentDate(), DATE_FORMAT_DDMMYYYY_WITH_SPACE), 100000)
        const formattedDate = getFormattedDate(relativeDate, DATE_FORMAT_DDMMYYYY_WITH_SPACE, "DD-MM-YYYY")

        nomineeDetails.map(nominee => {
            if (nominee.expiryDate) {
                const formattedNomineeDate = getFormattedDate(nominee.expiryDate, DATE_FORMAT_DDMMYYYY_WITH_SPACE)
                nominee.expiryDate = formattedNomineeDate != formattedDate ?
                    formattedNomineeDate :
                    ""
            }
            if (nominee.tierStatus == BLANK) {
                nominee.tierStatus = ""
            }
            if (nominee.groupName == BLANK) {
                nominee.groupName = ""
            }
            return nominee
        })
        return nomineeDetails
    }

    onValueChange(e) {
        this.setState({ exportFlag: e.length > 0 ? true : false })
    }


    render() {
        const { t, accountUsers, accountSummary, userPrivileges } = this.props
        const { apiResponse, exportFlag, exportStr, globalFilter } = this.state
        const table = this.getTableColumnsFromConfig()
        // const nomineeDetails = accountUsers && this.getNomineeDetailsForTable()
        return (
            <>
                <h1>
                    {
                        isEmptyOrSpaces(this.state.editOrAddPage) ? t('corpReg.listUsers.title') :
                            this.state.editOrAddPage == "add" ? parse(t('corpReg.listUsers.addTitle')) : parse(t('corpReg.listUsers.editTitle'))
                    }
                </h1>
                {isEmptyOrSpaces(this.state.editOrAddPage) && apiResponse && apiResponse.message && <AlertBox type={apiResponse.type}
                    message={apiResponse.message}
                />
                }
                <div className="row">
                    <div className="col-lg-12">
                        <p>
                            {
                                isEmptyOrSpaces(this.state.editOrAddPage) ? parse(t('corpReg.listUsers.desc')) :
                                    this.state.editOrAddPage == "add" && parse(t('corpReg.listUsers.addDesc'))
                            }
                        </p>

                    </div>
                    {isEmptyOrSpaces(this.state.editOrAddPage) &&
                        <div className="col-lg-12">
                            <div className="btn-wrap btn-wrap--grp btn-wrap-block__mobile btn-wrap-justify">
                                <input
                                    id="search-txt"
                                    type="text"
                                    class="txt form-control"
                                    placeholder="Search members"
                                    data-test="table-search"
                                    value={globalFilter}
                                    style={{ "width": "30%" }}
                                    onChange={(e) => this.setState({ globalFilter: e.target.value })} />
                                <div class="btn-wrap-justify__group">
                                    <a href="#"
                                        className="btn btn-secondary"
                                        role="button" id="dropdownMenuLink" aria-label="export link"
                                        data-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">
                                        Export
                                    </a>
                                    <div className="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuLink">
                                        <a className="dropdown-item"
                                            onClick={(e) => this.setState({ exportStr: EXPORT_CSV })}
                                            role="button">{t("export_file.exportCsv")}</a>
                                        <a className="dropdown-item"
                                            onClick={(e) => this.setState({ exportStr: EXPORT_PDF })}
                                            role="button">{t("export_file.exportPdf")}</a>
                                        <a className="dropdown-item"
                                            onClick={(e) => this.setState({ exportStr: EXPORT_XLSX })}
                                            role="button">{t("export_file.exportXlsx")}</a>

                                    </div>
                                    {isEmptyOrSpaces(this.state.editOrAddPage) &&
                                        <Button
                                            type="button"
                                            className="btn btn-primary"
                                            handleOnClick={() => {
                                                this.props.clearValidateResponse()
                                                this.setState({
                                                    apiResponse: {},
                                                    editOrAddPage: "add",
                                                    apiResponse: {}
                                                })
                                            }
                                            }
                                            label={t("corpReg.addMember.btnAdd")}
                                        />
                                    }
                                </div>
                            </div>
                        </div>
                    }
                    <div className="col-lg-12">
                        {!isEmptyOrSpaces(this.state.editOrAddPage) ?
                            <AddEditAccountUser
                                {...(this.state.rowData && { rowData: this.state.rowData })}
                                type={this.state.editOrAddPage}
                                companyData={this.props.companyData}
                                backTriggered={() => this.setState({ editOrAddPage: "" })}
                                userAdded={() => this.getUserAddedResponse()} /> :

                            table && Object.keys(table).length > 0 && <AccountUsersTable
                                companyData={this.props.companyData}
                                editUser={(rowData) => this.editMember(rowData)}
                                clearResponse={() => this.setState({ apiResponse: {} })}
                                field={{
                                    "values": accountUsers && this.getNomineeDetailsForTable(),
                                    "columns": table && table.columns && Object.keys(table.columns).length > 0 && table.columns,
                                    downloadValues: accountUsers && this.getNomineeDetailsForDownload(),
                                    globalFilter: globalFilter,
                                    exportStr: this.state.exportStr,
                                    defaultSort: table && table.defaultSort,
                                    defaultSortFields: table && table.defaultSortFields,
                                    exportFileName: table && table.tableName,
                                    showTickIconFor: table && table.showTickIconFor
                                }}
                                t={this.props.t}
                                onValueChange={(e) => this.onValueChange(e)}
                                className={"Corporate-Users-Table"} />
                        }
                    </div>
                </div>
            </>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        manageAccountUsersConfig: state.configurationReducer[CONFIG_SECTION_MANAGE_ACCOUNT_USERS],
        accountUsers: state.retrieveAccountUsersReducer.retrieveAccountUsers,
        userAddedResponse: state.addAccountUserReducer.response,
        updateAccountUserResponse: state.updateAccountUserPrivilegeReducer.response,
        deleteAccountUserResponse: state.deleteAccountUsersReducer.response,
        userPrivileges: state.privilegesReducer.privileges,
        accountSummary: state.accountSummaryReducer.accountSummary,
        masterEntityLookup: state.masterEntityDataReducer.masterEntityLookup,
        masterEntityLookupFilters: state.masterEntityDataReducer.masterEntityLookupFilters,
        accountGroupType: state.masterData[ACC_GROUP_TYPE] ? state.masterData[ACC_GROUP_TYPE] : [],

    }
}

const mapDispatchToProps = {
    fetchConfiguration,
    retrieveAccountUsers,
    clearValidateResponse,
    fetchCompanyProfile,
    fetchMasterData
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(ManageAccountUsers)))

