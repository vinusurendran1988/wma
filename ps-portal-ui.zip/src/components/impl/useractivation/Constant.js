export const ID_ACTIVATE_BTN = "ID_ACTIVATE_BTN"
export const DEFAULT = "default"
export const CONTEXT = "CONTEXT"
export const NOMINEE_ACTIVATION = "nomineeActivation"
export const NA = "na"
export const EA = "ea"

