import React from 'react';
import UserActivation from './index'
import { testStore } from '../../common/utils';
import { findComponent, mockServiceResponse, findByTestAttr, stubMockServiceResponse } from '../../common/testUtils';
import { mount } from 'enzyme';
import moxios from 'moxios';
import { axiosInstance } from '../../common/utils/api';
import { Provider } from 'react-redux';
import { _URL_ADDITIONAL_DETAILS, _URL_USER_ACTIVATION, _URL_CONFIGURATION_SERVICE } from '../../common/config/config';
import ReactTestUtils from 'react-dom/test-utils';
import { fetchConfiguration } from '../../common/middleware/redux/commonAction';
import { CONFIG_SECTION_ACTIVATION } from '../../common/utils/Constants';

var store = testStore({})
let rootComponent;
let component;

const setUp = (props = {}, isDefaultConfig = false) => {
    props.resetError = jest.fn();
    props.setPageInfo = jest.fn();
    props.setError = jest.fn();
    if(isDefaultConfig){
        props["config"] = JSON.parse(JSON.stringify(CONFIG_RESPONSE)).object
    }
    rootComponent = mount(<Provider store={store}>
        <UserActivation {...props} store={store} />
    </Provider>);
    component = findComponent(rootComponent, 'UserActivation');
};

const updateComponents = () => {
    rootComponent = rootComponent.update()
    component = findComponent(rootComponent, 'UserActivation');
}

describe('Should render the page invoking the api for configuration', () => {
    beforeEach(() => {
        store = undefined
        store = testStore({})
        moxios.install(axiosInstance);
    });

    afterEach(() => {
        moxios.uninstall(axiosInstance);
    });

    it('Should render with configuration passed and submit the request', () => {
        mockServiceResponse(CONFIG_RESPONSE)
        setUp({});
        const newUrl = 'activation?TKN=604A81D3AF55F24D3F5814B2C6D25DF774710320&MEM_ID=IM0008010804';
        Object.defineProperty(window, 'location', {
            writable: true,
            value: {
                hash: newUrl
            }
        });
        window.scrollTo = jest.fn()
        moxios.stubRequest(_URL_USER_ACTIVATION, {
            status: 200,
            responseText: ACTIVATION_SUCCESS
        })
        moxios.stubRequest(_URL_ADDITIONAL_DETAILS, {
            status: 200,
            responseText: ADDITIONAL_DETAILS
        })
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_ACTIVATION))
                .then(() => {
                    let newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_ACTIVATION]).toBe(CONFIG_RESPONSE.object);
                    updateComponents();

                    const submit = findByTestAttr(component, 'submit');
                    expect(submit.length).toBe(1);
                    submit.props().onClick();

                    const activation = findByTestAttr(component, 'activation');
                    expect(activation.length).toBe(1);

                    const activationForm = findByTestAttr(component, 'activationForm');
                    expect(activationForm.length).toBe(1);

                    const password_password = findByTestAttr(component, 'password_password');
                    expect(password_password.length).toBe(1);
                    password_password.simulate('change', { target: { value: "Pwd@1234" } })

                    const password_confirmPassword = findByTestAttr(component, 'password_confirmPassword');
                    expect(password_confirmPassword.length).toBe(1);
                    password_confirmPassword.simulate('change', { target: { value: "Pwd@1234" } })

                    const securityQuestion_question1 = findByTestAttr(component, 'securityQuestion_question1');
                    expect(securityQuestion_question1.length).toBe(1);
                    securityQuestion_question1.simulate('change', { target: { value: "MN" } })

                    const securityQuestion_answer1 = findByTestAttr(component, 'securityQuestion_answer1');
                    expect(securityQuestion_answer1.length).toBe(1);
                    securityQuestion_answer1.simulate('change', { target: { value: "testName" } })

                    const pin_memberPin = findByTestAttr(component, 'pin_memberPin');
                    expect(pin_memberPin.length).toBe(1);
                    pin_memberPin.simulate('change', { target: { value: "1234" } })

                    const pin_confirmPin = findByTestAttr(component, 'pin_confirmPin');
                    expect(pin_confirmPin.length).toBe(1);
                    pin_confirmPin.simulate('change', { target: { value: "1234" } })

                    submit.props().onClick();

                    const loginBtn = findByTestAttr(component, 'loginBtn');
                    expect(loginBtn.length).toBe(1);
                    loginBtn.simulate('click')
                    
                })
        })
    })

})

describe('Should render the page with predefined configuration', () => {
    beforeEach(() => {
        store = undefined
        store = testStore({})
        moxios.install(axiosInstance);
        mockServiceResponse(CONFIG_RESPONSE, 200)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_ACTIVATION))
            .then(() => {
                setUp({}, true);
                updateComponents()
             })
        })
    });

    afterEach(() => {
        moxios.uninstall(axiosInstance);
    });

    it('Should cover the error scenarios', () => {
        
        return ReactTestUtils.act(()=>{
            moxios.stubRequest(_URL_USER_ACTIVATION, {
                status: 500,
                responseText: ACTIVATION_FAILED
            })
            const activation = findByTestAttr(component, 'activation');
            expect(activation.length).toBe(1);
    
            const activationForm = findByTestAttr(component, 'activationForm');
            expect(activationForm.length).toBe(1);
    
            const password_password = findByTestAttr(component, 'password_password');
            expect(password_password.length).toBe(1);
            password_password.simulate('change', { target: { value: "Pwd@1234" } })
    
            const password_confirmPassword = findByTestAttr(component, 'password_confirmPassword');
            expect(password_confirmPassword.length).toBe(1);
            password_confirmPassword.simulate('change', { target: { value: "Pwd@1234" } })
    
            const securityQuestion_question1 = findByTestAttr(component, 'securityQuestion_question1');
            expect(securityQuestion_question1.length).toBe(1);
            securityQuestion_question1.simulate('change', { target: { value: "MN" } })
    
            const securityQuestion_answer1 = findByTestAttr(component, 'securityQuestion_answer1');
            expect(securityQuestion_answer1.length).toBe(1);
            securityQuestion_answer1.simulate('change', { target: { value: "testName" } })
    
            const pin_memberPin = findByTestAttr(component, 'pin_memberPin');
            expect(pin_memberPin.length).toBe(1);
            pin_memberPin.simulate('change', { target: { value: "1234" } })
    
            const pin_confirmPin = findByTestAttr(component, 'pin_confirmPin');
            expect(pin_confirmPin.length).toBe(1);
            pin_confirmPin.simulate('change', { target: { value: "1234" } })
    
            const submit = findByTestAttr(component, 'submit');
            expect(submit.length).toBe(1);
            submit.props().onClick();
    
            const loginBtn = findByTestAttr(component, 'loginBtn');
            expect(loginBtn.length).toBe(1);
            loginBtn.simulate('click')
        })
    })
})

describe('Should cover the uncovered statements/branches', () => {
    beforeEach(() => {
        store = undefined
        store = testStore({})
        moxios.install(axiosInstance);
    });

    afterEach(() => {
        moxios.uninstall(axiosInstance);
    });

    it('Should render with configuration passed and submit the request', () => {
        mockServiceResponse(CONFIG_SECTION_ACTIVATION_FOR_UNCOVERED)
        setUp({});
        const newUrl = 'activation?TEST=1324&PWD=IN001';
        Object.defineProperty(window, 'location', {
            writable: true,
            value: {
                hash: newUrl
            }
        });
        window.scrollTo = jest.fn()
        moxios.stubRequest(_URL_USER_ACTIVATION, {
            status: 200,
            responseText: ACTIVATION_SUCCESS_FOR_UNCOVERED
        })
        moxios.stubRequest(_URL_ADDITIONAL_DETAILS, {
            status: 200,
            responseText: ADDITIONAL_DETAILS
        })
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_ACTIVATION))
                .then(() => {
                    let newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_ACTIVATION]).toBe(CONFIG_SECTION_ACTIVATION_FOR_UNCOVERED.object);
                    updateComponents();

                    const submit = findByTestAttr(component, 'submit');
                    expect(submit.length).toBe(1);
                    submit.props().onClick();

                    const activation = findByTestAttr(component, 'activation');
                    expect(activation.length).toBe(1);

                    const activationForm = findByTestAttr(component, 'activationForm');
                    expect(activationForm.length).toBe(1);

                    const password_password = findByTestAttr(component, 'password_password');
                    expect(password_password.length).toBe(1);
                    password_password.simulate('change', { target: { value: "Pwd@1234" } })

                    const password_confirmPassword = findByTestAttr(component, 'password_confirmPassword');
                    expect(password_confirmPassword.length).toBe(1);
                    password_confirmPassword.simulate('change', { target: { value: "Pwd@1234" } })

                    const securityQuestion_question1 = findByTestAttr(component, 'securityQuestion_question1');
                    expect(securityQuestion_question1.length).toBe(1);
                    securityQuestion_question1.simulate('change', { target: { value: "MN" } })

                    const securityQuestion_answer1 = findByTestAttr(component, 'securityQuestion_answer1');
                    expect(securityQuestion_answer1.length).toBe(1);
                    securityQuestion_answer1.simulate('change', { target: { value: "testName" } })

                    const pin_memberPin = findByTestAttr(component, 'pin_memberPin');
                    expect(pin_memberPin.length).toBe(1);
                    pin_memberPin.simulate('change', { target: { value: "1234" } })

                    const pin_confirmPin = findByTestAttr(component, 'pin_confirmPin');
                    expect(pin_confirmPin.length).toBe(1);
                    pin_confirmPin.simulate('change', { target: { value: "1234" } })

                    submit.props().onClick();

                    const loginBtn = findByTestAttr(component, 'loginBtn');
                    expect(loginBtn.length).toBe(1);
                    loginBtn.simulate('click')
                    
                })
        })
    })
})

describe('Should handle multiple question with same selected by user',()=>{
    beforeEach(() => {
        store = undefined
        store = testStore({})
        moxios.install(axiosInstance);
    });

    afterEach(() => {
        moxios.uninstall(axiosInstance);
    });

    it('Should render with configuration passed and submit the request', () => {
        setUp({});
        const newUrl = 'activation?TKN=604A81D3AF55F24D3F5814B2C6D25DF774710320&MEM_ID=IM0008010804';
        Object.defineProperty(window, 'location', {
            writable: true,
            value: {
                hash: newUrl
            }
        });
        window.scrollTo = jest.fn()
        moxios.stubRequest(_URL_USER_ACTIVATION, {
            status: 200,
            responseText: ACTIVATION_SUCCESS
        })
        moxios.stubRequest(_URL_ADDITIONAL_DETAILS, {
            status: 200,
            responseText: ADDITIONAL_DETAILS
        })
        moxios.stubRequest(_URL_CONFIGURATION_SERVICE, {
            status: 200,
            responseText: CONFIG_SECTION_ACTIVATION_MULTIPLE_QUESTIONS
        })
        mockServiceResponse(CONFIG_SECTION_ACTIVATION_MULTIPLE_QUESTIONS)
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_ACTIVATION))
                .then(() => {
                    let newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_ACTIVATION]).toBe(CONFIG_SECTION_ACTIVATION_MULTIPLE_QUESTIONS.object);
                    updateComponents();

                    const activation = findByTestAttr(component, 'activation');
                    expect(activation.length).toBe(1);

                    const activationForm = findByTestAttr(component, 'activationForm');
                    expect(activationForm.length).toBe(1);

                    console.log("Component: ", newState.configurationReducer[CONFIG_SECTION_ACTIVATION])
                    const password_password = findByTestAttr(component, 'password_password');
                    expect(password_password.length).toBe(1);
                    password_password.simulate('change', { target: { value: "Pwd@1234" } })

                    const password_confirmPassword = findByTestAttr(component, 'password_confirmPassword');
                    expect(password_confirmPassword.length).toBe(1);
                    password_confirmPassword.simulate('change', { target: { value: "Pwd@1234" } })

                    const securityQuestion_question1 = findByTestAttr(component, 'securityQuestion_question1');
                    expect(securityQuestion_question1.length).toBe(1);
                    securityQuestion_question1.simulate('change', { target: { value: "MN" } })

                    const securityQuestion_answer1 = findByTestAttr(component, 'securityQuestion_answer1');
                    expect(securityQuestion_answer1.length).toBe(1);
                    securityQuestion_answer1.simulate('change', { target: { value: "testName" } })

                    const securityQuestion_question2 = findByTestAttr(component, 'securityQuestion_question2');
                    expect(securityQuestion_question2.length).toBe(1);
                    securityQuestion_question2.simulate('change', { target: { value: "MN" } })

                    const securityQuestion_answer2 = findByTestAttr(component, 'securityQuestion_answer2');
                    expect(securityQuestion_answer2.length).toBe(1);
                    securityQuestion_answer2.simulate('change', { target: { value: "testName" } })

                    const pin_memberPin = findByTestAttr(component, 'pin_memberPin');
                    expect(pin_memberPin.length).toBe(1);
                    pin_memberPin.simulate('change', { target: { value: "1234" } })

                    const pin_confirmPin = findByTestAttr(component, 'pin_confirmPin');
                    expect(pin_confirmPin.length).toBe(1);
                    pin_confirmPin.simulate('change', { target: { value: "1234" } })

                    
                    const submit = findByTestAttr(component, 'submit');
                    expect(submit.length).toBe(1);
                    submit.props().onClick();
                })
    })
})



const CONFIG_RESPONSE = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "section": "activation", "companyCode": "IBS", "programCode": "PRG14", "defaults": { "accountStatus": "A", "operationFlag": "U" }, "activationModes": [{ "type": "pin", "enable": true, "validation": {} }, { "type": "password", "enable": true, "validation": {} }, { "type": "securityQuestion", "enable": true, "validation": { "count": 1 } }], "securityQuestion": { "count": 1, "enable": true, "additionalType": "memberDynamicAttribute", "filterType": "attributeCode", "validation": [] }, "password": { "enable": true, "validation": [] }, "pin": { "enable": true, "validation": [] }, "dynamicAttributes": { "securityQuestion": [{ "attributeCode": "18", "attributeName": "Secret Question", "attributeValue": "", "attributeMapping": "", "type": "P", "attributeKey": "SQ" }, { "attributeCode": "19", "attributeName": "Secret Answer", "attributeValue": "", "attributeMapping": "", "type": "P", "attributeKey": "SA" }] }, "ui": { "isLayoutSequential": true, "request": { "dynamicAttributesPath": "object.memberDynamicAttributes", "additionalMapping": [{ "fromPath": ["window.localStorage.companyCode"], "toPath": "object.companyCode" }, { "fromPath": ["window.localStorage.programCode"], "toPath": "object.programCode" }, { "fromPath": ["state.data.membershipNumber"], "toPath": "object.membershipNumber" }, { "fromPath": ["state.data.token"], "toPath": "object.token" }] }, "layout": { "order": ["password", "securityQuestion", "pin"], "elements": { "password": { "className": "", "fields": [{ "className": "col-lg-5 col-md-7", "name": "password", "id": "id-password", "visibility": true, "required": true, "fieldType": "P", "path": { "state": true, "response": "", "request": "object.password" }, "validations": [{ "pattern": "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$", "customMessageId": "form.password.errorMessage.invalid" }] }, { "className": "col-lg-5 col-md-7", "name": "confirmPassword", "id": "id-confirm-password", "path": { "state": true, "response": "", "request": "" }, "visibility": true, "required": true, "fieldType": "P", "validations": [{ "pattern": "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$", "customMessageId": "form.confirmPassword.errorMessage.invalid" }, { "state": true, "pattern": "^[fields]$", "fields": ["password"], "customMessageId": "form.confirmPassword.errorMessage.unEqual" }] }] }, "pin": { "className": "col-lg-5 col-md-7", "fields": [{ "className": "col-lg-5 col-md-7", "name": "memberPin", "id": "id-member-pin", "visibility": true, "required": true, "fieldType": "P", "path": { "state": true, "response": "", "request": "object.pin" }, "validations": [{ "pattern": "^[0-9]{4}$", "customMessageId": "form.memberPin.errorMessage.invalid" }] }, { "className": "col-lg-5 col-md-7", "name": "confirmPin", "id": "id-confirm-pin", "visibility": true, "required": true, "fieldType": "P", "path": { "state": true, "response": "", "request": "" }, "validations": [{ "pattern": "^[0-9]{4}$", "customMessageId": "form.confirmPin.errorMessage.invalid" }, { "state": true, "pattern": "^[fields]$", "fields": ["memberPin"], "customMessageId": "form.confirmPin.errorMessage.unEqual" }] }] }, "securityQuestion1": { "className": "col-lg-5 col-md-7", "fields": [{ "questionWrapperClass": "col-lg-8 col-md-10", "answerWrapperClass": "col-lg-5 col-md-7", "renderType": "render1_1", "name": "securityQuestions", "id": "id-security-pwd-security-questions", "visibility": true, "className": "col-lg-12", "required": true, "fieldType": "SQ", "count": 1, "additionalType": "memberDynamicAttribute", "filterType": "attributeCode", "validations": [{ "pattern": "^(?=.*[a-zA-Z0-9])", "customMessageId": "security.changePassword.security_question.errorMessage" }] }] }, "securityQuestion": { "className": "col-lg-8 col-md-10", "fields": [{ "name": "question1", "id": "id-security-question-1", "type": "lov", "source": { "type": "props", "key": "securityQuestions", "selector": { "label": "optionName", "value": "optionCode" } }, "visibility": true, "required": true, "fieldType": "B", "path": { "state": true, "response": "", "request": "" }, "validations": [{ "pattern": "[A-Z]{2}$", "customMessageId": "form.question1.errorMessage.invalid" }] }, { "className": "col-lg-5 col-md-7", "name": "answer1", "id": "id-security-answer-1", "visibility": true, "required": true, "fieldType": "P", "path": { "state": true, "response": "", "request": "" }, "validations": [{ "pattern": "^[ a-zA-Z0-9]{1,20}$", "customMessageId": "form.answer1.errorMessage.invalid" }] }] } } } } } }
const ACTIVATION_SUCCESS = {"statuscode":"200","statusMessage":"SUCCESS","object":{"memberActivityStatus":{"companyCode":"IBS","programCode":"PRG14","membershipNumber":"IM0008010905","accountStatus":"A","activityNumber":"NIL","activityStatus":"P","pointDetails":[]},"pointDetail":[]}}
const ACTIVATION_FAILED = {"statuscode":"500","statusMessage":"FAILURE","error":{"code":"500","type":"INTERNAL_SERVER_ERROR","message":"Activate member failed","errorDetails":[{"message":"Authenticate token failed"}]}}
const ADDITIONAL_DETAILS = {"statuscode":"200","statusMessage":"SUCCESS","object":{"companyCode":"IBS","programCode":"PRG14","memberPreferences":[],"memberDynamicAttributes":[{"attributeCode":"18","attributeName":"Secret Question","description":"Secret Question","mandatory":false,"fieldType":"STRING","dataType":"ALPHANUMERIC","displayOrder":30,"inputType":"B","type":"M","attributeInputOption":[{"optionCode":"MN","optionName":"Mother's Name","sequenceNumber":1,"defaultFlag":false},{"optionCode":"WD","optionName":"Anniversary Year","sequenceNumber":2,"defaultFlag":false}]}]}}
const CONFIG_SECTION_ACTIVATION_FOR_UNCOVERED = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "section": "activation", "companyCode": "IBS", "programCode": "PRG14", "defaults": { "accountStatus": "A", "operationFlag": "U" }, "activationModes": [{ "type": "pin", "enable": true, "validation": {} }, { "type": "password", "enable": true, "validation": {} }, { "type": "securityQuestion", "enable": true, "validation": { "count": 1 } }], "securityQuestion": { "count": 1, "enable": true, "additionalType": "memberDynamicAttribute", "filterType": "attributeCode", "validation": [] }, "password": { "enable": true, "validation": [] }, "pin": { "enable": true, "validation": [] }, "dynamicAttributes": { }, "ui": { "isLayoutSequential": true, "request": { "additionalMapping": [{ "fromPath": ["window.localStorage.companyCode"], "toPath": "object.companyCode" }, { "fromPath": ["window.localStorage.programCode"], "toPath": "object.programCode" }, { "fromPath": ["state.data.membershipNumber"], "toPath": "object.membershipNumber" }, { "fromPath": ["state.data.token"], "toPath": "object.token" }] }, "layout": { "order": ["password", "securityQuestion", "pin"], "elements": { "password": { "className": "", "fields": [{ "className": "col-lg-5 col-md-7", "name": "password", "id": "id-password", "visibility": true, "required": true, "fieldType": "P", "path": { "state": true, "response": "", "request": "object.password" }, "validations": [{ "pattern": "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$", "customMessageId": "form.password.errorMessage.invalid" }] }, { "className": "col-lg-5 col-md-7", "name": "confirmPassword", "id": "id-confirm-password", "path": { "state": true, "response": "", "request": "" }, "visibility": true, "required": true, "fieldType": "P", "validations": [{ "pattern": "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$", "customMessageId": "form.confirmPassword.errorMessage.invalid" }, { "state": true, "pattern": "^[fields]$", "fields": ["password"], "customMessageId": "form.confirmPassword.errorMessage.unEqual" }] }] }, "pin": { "className": "col-lg-5 col-md-7", "fields": [{ "className": "col-lg-5 col-md-7", "name": "memberPin", "id": "id-member-pin", "visibility": true, "required": true, "fieldType": "P", "path": { "state": true, "response": "", "request": "object.pin" }, "validations": [{ "pattern": "^[0-9]{4}$", "customMessageId": "form.memberPin.errorMessage.invalid" }] }, { "className": "col-lg-5 col-md-7", "name": "confirmPin", "id": "id-confirm-pin", "visibility": true, "required": true, "fieldType": "P", "path": { "state": true, "response": "", "request": "" }, "validations": [{ "pattern": "^[0-9]{4}$", "customMessageId": "form.confirmPin.errorMessage.invalid" }, { "state": true, "pattern": "^[fields]$", "fields": ["memberPin"], "customMessageId": "form.confirmPin.errorMessage.unEqual" }] }] }, "securityQuestion1": { "className": "col-lg-5 col-md-7", "fields": [{ "questionWrapperClass": "col-lg-8 col-md-10", "answerWrapperClass": "col-lg-5 col-md-7", "renderType": "render1_1", "name": "securityQuestions", "id": "id-security-pwd-security-questions", "visibility": true, "className": "col-lg-12", "required": true, "fieldType": "SQ", "count": 1, "additionalType": "memberDynamicAttribute", "filterType": "attributeCode", "validations": [{ "pattern": "^(?=.*[a-zA-Z0-9])", "customMessageId": "security.changePassword.security_question.errorMessage" }] }] }, "securityQuestion": { "className": "col-lg-8 col-md-10", "fields": [{ "name": "question1", "id": "id-security-question-1", "type": "lov", "source": { "type": "props", "key": "securityQuestions", "selector": { "label": "optionName", "value": "optionCode" } }, "visibility": true, "required": true, "fieldType": "B", "path": { "state": true, "response": "", "request": "" }, "validations": [{ "pattern": "[A-Z]{2}$", "customMessageId": "form.question1.errorMessage.invalid" }] }, { "className": "col-lg-5 col-md-7", "name": "answer1", "id": "id-security-answer-1", "visibility": true, "required": true, "fieldType": "P", "path": { "state": true, "response": "", "request": "" }, "validations": [{ "pattern": "^[ a-zA-Z0-9]{1,20}$", "customMessageId": "form.answer1.errorMessage.invalid" }] }] } } } } } }
const ACTIVATION_SUCCESS_FOR_UNCOVERED = {"statuscode":"200","statusMessage":"SUCCESS","object":{"memberActivityStatus":{"companyCode":"IBS","programCode":"PRG14","accountStatus":"A","activityNumber":"NIL","activityStatus":"P","pointDetails":[]},"pointDetail":[]}}
const CONFIG_SECTION_ACTIVATION_MULTIPLE_QUESTIONS = {"statuscode":"200","statusMessage":"SUCCESS","object":{"section":"activation","companyCode":"IBS","programCode":"PRG14","defaults":{"accountStatus":"A","operationFlag":"U"},"activationModes":[{"type":"pin","enable":true,"validation":{}},{"type":"password","enable":true,"validation":{}},{"type":"securityQuestion","enable":true,"validation":{"count":1}}],"securityQuestion":{"count":2,"enable":true,"additionalType":"memberDynamicAttribute","filterType":"attributeCode","validation":[]},"password":{"enable":true,"validation":[]},"pin":{"enable":true,"validation":[]},"dynamicAttributes":{"securityQuestion":[{"attributeCode":"18","attributeName":"Secret Question","attributeValue":"","attributeMapping":"","type":"P","attributeKey":"SQ"},{"attributeCode":"19","attributeName":"Secret Answer","attributeValue":"","attributeMapping":"","type":"P","attributeKey":"SA"}]},"ui":{"isLayoutSequential":true,"request":{"dynamicAttributesPath":"object.memberDynamicAttributes","additionalMapping":[{"fromPath":["window.localStorage.companyCode"],"toPath":"object.companyCode"},{"fromPath":["window.localStorage.programCode"],"toPath":"object.programCode"},{"fromPath":["state.data.membershipNumber"],"toPath":"object.membershipNumber"},{"fromPath":["state.data.token"],"toPath":"object.token"}]},"layout":{"order":["password","securityQuestion","pin"],"elements":{"password":{"className":"","fields":[{"className":"col-lg-5 col-md-7","name":"password","id":"id-password","visibility":true,"required":true,"fieldType":"P","path":{"state":true,"response":"","request":"object.password"},"validations":[{"pattern":"^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$","customMessageId":"form.password.errorMessage.invalid"}]},{"className":"col-lg-5 col-md-7","name":"confirmPassword","id":"id-confirm-password","path":{"state":true,"response":"","request":""},"visibility":true,"required":true,"fieldType":"P","validations":[{"pattern":"^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$","customMessageId":"form.confirmPassword.errorMessage.invalid"},{"state":true,"pattern":"^[fields]$","fields":["password"],"customMessageId":"form.confirmPassword.errorMessage.unEqual"}]}]},"pin":{"className":"col-lg-5 col-md-7","fields":[{"className":"col-lg-5 col-md-7","name":"memberPin","id":"id-member-pin","visibility":true,"required":true,"fieldType":"P","path":{"state":true,"response":"","request":"object.pin"},"validations":[{"pattern":"^[0-9]{4}$","customMessageId":"form.memberPin.errorMessage.invalid"}]},{"className":"col-lg-5 col-md-7","name":"confirmPin","id":"id-confirm-pin","visibility":true,"required":true,"fieldType":"P","path":{"state":true,"response":"","request":""},"validations":[{"pattern":"^[0-9]{4}$","customMessageId":"form.confirmPin.errorMessage.invalid"},{"state":true,"pattern":"^[fields]$","fields":["memberPin"],"customMessageId":"form.confirmPin.errorMessage.unEqual"}]}]},"securityQuestion1":{"className":"col-lg-5 col-md-7","fields":[{"questionWrapperClass":"col-lg-8 col-md-10","answerWrapperClass":"col-lg-5 col-md-7","renderType":"render1_1","name":"securityQuestions","id":"id-security-pwd-security-questions","visibility":true,"className":"col-lg-12","required":true,"fieldType":"SQ","count":1,"additionalType":"memberDynamicAttribute","filterType":"attributeCode","validations":[{"pattern":"^(?=.*[a-zA-Z0-9])","customMessageId":"security.changePassword.security_question.errorMessage"}]}]},"securityQuestion":{"className":"col-lg-8 col-md-10","fields":[{"name":"question1","id":"id-security-question-1","type":"lov","source":{"type":"props","key":"securityQuestions","selector":{"label":"optionName","value":"optionCode"}},"visibility":true,"required":true,"fieldType":"B","path":{"state":true,"response":"","request":""},"validations":[{"pattern":"[A-Z]{2}$","customMessageId":"form.question1.errorMessage.invalid"}]},{"className":"col-lg-5 col-md-7","name":"answer1","id":"id-security-answer-1","visibility":true,"required":true,"fieldType":"P","path":{"state":true,"response":"","request":""},"validations":[{"pattern":"^[ a-zA-Z0-9]{1,20}$","customMessageId":"form.answer1.errorMessage.invalid"}]},{"name":"question2","id":"id-security-question-2","type":"lov","source":{"type":"props","key":"securityQuestions","selector":{"label":"optionName","value":"optionCode"}},"visibility":true,"required":true,"fieldType":"B","path":{"state":true,"response":"","request":""},"validations":[{"pattern":"[A-Z]{2}$","customMessageId":"form.question2.errorMessage.invalid"}]},{"className":"col-lg-5 col-md-7","name":"answer2","id":"id-security-answer-2","visibility":true,"required":true,"fieldType":"P","path":{"state":true,"response":"","request":""},"validations":[{"pattern":"^[ a-zA-Z0-9]{1,20}$","customMessageId":"form.answer2.errorMessage.invalid"}]}]}}}}}}