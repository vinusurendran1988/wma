import React, { Component } from 'react';
import { connect } from 'react-redux';
import { changeLanguage } from '../../ui/header/actions'
import { withTranslation } from 'react-i18next';
import { withSuspense, getSwitchProgramList, isEmptyOrSpaces, getFormattedDate, isLoggedIn } from '../../common/utils'
import ReactCountryFlag from "react-country-flag"
import { logOut, fetchConfiguration } from '../../common/middleware/redux/commonAction'
import {
    NAVIGATE_MEMBER_LOGIN,
    NAVIGATE_MEMBER_DASHBOARD,
    NAVIGATE_404,
    NAVIGATE_CORPORATE_OVERVIEW,
    NAVIGATE_CLUB_OVERVIEW,
    NAVIGATE_COMPANY_PROFILE,
    NAVIGATE_ACTIVATE,
    NAVIGATE_CORPORATE_REGISTER_KORU
} from '../../common/utils/urlConstants';
import {
    getItemFromBrowserStorage,
    setItemToBrowserStorage,
    BROWSER_STORAGE_KEY_TOKEN,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
    BROWSER_STORAGE_KEY_PROGRAM_TYPE,
    BROWSER_STORAGE_KEY_CUSTOMER_NO,
    BROWSER_STORAGE_KEY_EMAIL,
    BROWSER_STORAGE_KEY_i18_LANG
} from '../../common/utils/storage.utils';
import {
    CONFIG_SECTION_SUMMARY,
    CONFIG_SECTION_DEFAULT,
    PROGRAM_TYPE_CORPORATE,
    PROGRAM_TYPE_INDIVIDUAL,
    MEMBERSHIP, CORP_MEMBERS
} from '../../common/utils/Constants';
import { getCurrentProgramFromDefaultConfig } from '../../common/utils/configurationFiles.utils';
import { _DEFAULT_LANGUAGE, _WHITELIST_LANGUAGES, _IMAGE_BASEURL } from '../../common/config/config';
import ApiLoader from '../../common/components/fieldbank/loader/ApiLoader'
import { _URL_GULF_AIR } from '../../common/config/config';
import Notification from '../../ui/header/Notification'
import { ROUTER_CONFIG } from '../../common/config/routing';
import { setCurrentTab } from '../../ui/subscription/actions';
import { withRouter } from 'react-router';
import {getOnBehalfEmployeeDetails, isOnBehalfAdminEnrolment, isShowCorporateLink, getCompanyData, getCompanyContractExpiry} from "../../ui/subscription/Services/CommonUtils";
import { clearCompany } from '../companyProfile/action';
import { DATE_FORMAT_DDMMYYYY_WITH_SPACE } from '../../ui/subscription/Constants'
import Custommessage from "../../common/components/custommessage";

/**
 * @description Component to render Header for Gulf Air
 * @author Gowthaman A
 */
class Header extends Component {

    constructor(props) {

        super(props);
        let newState = {
            switchProgramList: [],
            request: {},
            selectedTab: MEMBERSHIP,
            navUpdate: false,
            secondaryMobileNav: {collapse: "collapsed", show: "", areaExpanded: "false"},
            tertiaryMobileNav: {collapse: "collapsed", show: "", areaExpanded: "false"}
        }
        this.ref = React.createRef();
        this.handleClickOutside = this.handleClickOutside.bind(this);
        this.logOutUser = this.logOutUser.bind(this);
        this.tierName   = "";
        this.isShowCorporateLink = false;
        this.companySecondaryNav = [
            {name: "header.subMenu.koru", class: "nav-item active", target: NAVIGATE_CLUB_OVERVIEW}, 
            {name: "header.subMenu.koruCorporate", class: "nav-item", target: NAVIGATE_COMPANY_PROFILE}
        ];
        if (window.location.hash.includes(NAVIGATE_COMPANY_PROFILE) || window.location.hash.includes(NAVIGATE_CORPORATE_REGISTER_KORU)) {
            this.companySecondaryNav = [
                {name: "header.subMenu.koru", class: "nav-item", target: NAVIGATE_CLUB_OVERVIEW}, 
                {name: "header.subMenu.koruCorporate", class: "nav-item active", target: NAVIGATE_COMPANY_PROFILE}
            ];
            newState.selectedTab = CORP_MEMBERS;

        }
        this.currentActiveSecondaryNav = {name: "header.subMenu.koru", class: "nav-item active", target: NAVIGATE_CLUB_OVERVIEW};
        //this.currentActiveSecondaryNav = {name: "header.subMenu.koruCorporate", class: "nav-item active", target: NAVIGATE_COMPANY_PROFILE};
        this.collapse = ""
        // if (ROUTER_CONFIG.config.showSwitchOption && 
        //     this.props.currentUserData && this.props.defaultConfig) {
        //     const programCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE)
        //     const { programs } = props.currentUserData.userDetails
        //     const defaultPrograms = props.defaultConfig.programs
        //     const switchProgramList = getSwitchProgramList(programs, defaultPrograms, props.currentUserData, programCode)
        //     if (switchProgramList.length > 0) {
        //         newState["switchProgramList"] = switchProgramList
        //         newState["programCode"] = programCode
        //     }
        // }

        this.state = newState

        const isToken = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_TOKEN)
        if (isToken && !this.props.summaryConfig) {
            //this.props.fetchConfiguration(CONFIG_SECTION_SUMMARY)
        }
    }

    handleClickOutside(event) {
        if (this.ref.current && !this.ref.current.contains(event.target)) {
            this.setState({secondaryMobileNav: {collapse: "collapsed", show: "", areaExpanded: "false"}})
        } else {
            if (this.state.secondaryMobileNav.areaExpanded == "true") {
                this.setState({secondaryMobileNav: {collapse: "collapsed", show: "", areaExpanded: "false"}})
            } else {
                this.setState({secondaryMobileNav: {collapse: "", show: "show", areaExpanded: "true"}})
            }
            
        }
    };


    updateSwitchMenu() {
        const programCode = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE)
        if (ROUTER_CONFIG.config.showSwitchOption &&
            this.props.currentUserData && this.props.defaultConfig &&
            (this.state.switchProgramList.length == 0 || programCode != this.state.programCode)) {
            const { programs } = this.props.currentUserData.userDetails
            const defaultPrograms = this.props.defaultConfig.programs
            const switchProgramList = getSwitchProgramList(programs, defaultPrograms, this.props.currentUserData, programCode)
            if (switchProgramList.length > 0) this.setState({ switchProgramList, programCode })
        }
    }

    /**
     * Handling of updations when props or state are updated.
     * @param {*} prevProp 
     * @param {*} prevState 
     */
    componentDidUpdate(prevProp, prevState) {
        //this.updateSwitchMenu()
        if(typeof this.props.profileData != "undefined" && Object.keys(this.props.profileData).includes('object')) {
            this.tierName = this.getTierName(this.props.profileData.object.memberAccount.memberDynamicAttributes);
            
        }
        if (typeof this.props.currentUserData != "undefined") {
            this.isShowCorporateLink = isShowCorporateLink(this.props.currentUserData.userDetails);
        }
    }

    componentDidMount() {
        document.addEventListener('click', this.handleClickOutside, true);
        let lang = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_i18_LANG)
        if (!lang) {
            lang = _WHITELIST_LANGUAGES.find(e => e.code == _DEFAULT_LANGUAGE)
        } else {
            lang = JSON.parse(lang)
        }
        this.props.changeLanguage(lang)
        this.props.setCurrentTab(this.state.selectedTab)
    }

    switchProgram(program) {

        const { programCode, programType, membershipNumber, email, customerNo } = program

        setItemToBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO, membershipNumber)
        setItemToBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE, programCode)
        setItemToBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE, programType)
        setItemToBrowserStorage(BROWSER_STORAGE_KEY_CUSTOMER_NO, customerNo)
        setItemToBrowserStorage(BROWSER_STORAGE_KEY_EMAIL, email)
        if (programType === PROGRAM_TYPE_CORPORATE) {
            window.location.href = `#${NAVIGATE_CORPORATE_OVERVIEW}`
            window.location.reload()
        } else if (programType === PROGRAM_TYPE_INDIVIDUAL) {
            window.location.href = `#${NAVIGATE_MEMBER_DASHBOARD}`
            window.location.reload()
        } else {
            window.location.href = `#${NAVIGATE_404}`
        }
    }

    getCompanyInfo(accountSummary) {
        let companyInfo = {}
        if (accountSummary) {
            let companyFullName = accountSummary.companyName
            if (companyFullName) {
                let names = companyFullName.split(" ")
                companyInfo = {
                    companyFirstName: names[0],
                    companyLastName: companyFullName.replace(names[0], '').trim(),
                    companyRegistrationNo: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO),
                    tierName: accountSummary.tierName
                }
            }
        }
        return companyInfo
    }

    getLoginURL(programCode) {
        return `#${NAVIGATE_MEMBER_LOGIN}`
    }
    getPrgramName(defaultConfig) {
        let programName = ""
        if (defaultConfig) {
            const currentProgram = getCurrentProgramFromDefaultConfig(defaultConfig)
            if (currentProgram) programName = currentProgram.programName
        }
        return programName
    }

    getLoginMenuTitle(programCode) {

        let title = ""
        const { t, accountSummary, defaultConfig } = this.props;
        const programName = this.getPrgramName(defaultConfig)
        if (programCode === PROGRAM_TYPE_INDIVIDUAL && !isEmptyOrSpaces(programName)) {
            title = t("header.welcome_to").replace("{PROGRAM_NAME}", programName)
        } else if (programCode === PROGRAM_TYPE_CORPORATE) {
            const companyInfo = this.getCompanyInfo(accountSummary)
            if (companyInfo) {
                title = `${t("header.welcome")} ${companyInfo.companyFirstName ? companyInfo.companyFirstName : ""} ${companyInfo.companyLastName ? companyInfo.companyLastName : ""}`
            } else if (!isEmptyOrSpaces(programName)) {
                title = t("header.welcome_to").replace("{PROGRAM_NAME}", programName)
            }
        }
        return isEmptyOrSpaces(title) ? t("header.welcome") : title
    }

    logOutUser() {
        //this.props.logOut();
        window.localStorage.clear();
        window.location.href ="https://public.b2c.test.vauth.airnz.co.nz/vauth/oauth2/logout?client_id=ab07bb3f-ce51-4925-8fd0-329f4e4e42fa&redirect_uri=https%3A%2F%2Fwww.airnewzealand.co.nz%2Fairpoints";
    }

    getNotificationTemplate() {
        return <Notification />
    }

    changeTab(tab) {
        this.setState({
            selectedTab: tab,
        });
        this.setState({tertiaryMobileNav: {collapse: "collapsed", show: "", areaExpanded: "false"}});
        this.props.setCurrentTab(tab)
        if(tab== "manageUsers"){
            this.props.clearCompany()
        }
    }

    getTierName(dynamicAttr) {
        const { t } = this.props;
        let tierObj = dynamicAttr.filter((data) => data.attributeCode == "06");
        if (tierObj.length) {
            return t(`header.tierNames.${tierObj[0].attributeValue}`);
        } else {
            return "";
        }
    }

    secondaryNavClick(i, tabName) {
        
        this.setState({navUpdate: true});
        this.companySecondaryNav = this.companySecondaryNav.map((nav, index) => {
            
            if (index == i) {
                this.currentActiveSecondaryNav = nav;
                nav.class = "nav-item active"
            } else {
                nav.class = "nav-item";
            }
            return nav;
        });
        if (tabName == "header.subMenu.koru") {
            this.changeTab("membership")
        } else if (tabName == "header.subMenu.koruCorporate") {
            this.changeTab("manageUsers")
        }
    }
 
    render() {
        let isShowCorporateLink = this.isShowCorporateLink;
        if (window.location.hash.includes(NAVIGATE_COMPANY_PROFILE) || window.location.hash.includes(NAVIGATE_CORPORATE_REGISTER_KORU)) {
            this.companySecondaryNav = [
                {name: "header.subMenu.koru", class: "nav-item", target: NAVIGATE_CLUB_OVERVIEW}, 
                {name: "header.subMenu.koruCorporate", class: "nav-item active", target: NAVIGATE_COMPANY_PROFILE}
            ];
            if (window.location.hash.includes(NAVIGATE_CORPORATE_REGISTER_KORU)) {
                isShowCorporateLink = !this.isShowCorporateLink;
                this.companySecondaryNav = [
                    {name: "header.subMenu.koru", class: "nav-item", target: NAVIGATE_CLUB_OVERVIEW}, 
                    {name: "header.subMenu.koruCorporate", class: "nav-item active", target: NAVIGATE_CORPORATE_REGISTER_KORU}
                ];
            }
        } else {
            this.companySecondaryNav = [
                {name: "header.subMenu.koru", class: "nav-item active", target: NAVIGATE_CLUB_OVERVIEW}, 
                {name: "header.subMenu.koruCorporate", class: "nav-item", target: NAVIGATE_COMPANY_PROFILE}
            ];
        }
        const { language, t , currentUserData, summaryConfig, profileImage, includeHeader, profileData, corporateCompanyProfile } = this.props;
        const isToken = !isEmptyOrSpaces(getItemFromBrowserStorage(BROWSER_STORAGE_KEY_TOKEN))
        const programType = getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_TYPE)
        const menuTitle = this.getLoginMenuTitle(programType)
        const loginURL = this.getLoginURL(programType)
        const headerTabs = ["membership", "guestcardsAndAddOns", "benefits"];
        const companyTabs = ["manageUsers", "profile"];
        const tierName = this.tierName;
        const onBehalfEmployee = getOnBehalfEmployeeDetails();
        let contractExpiry = "";
        let companySecondaryNav = this.companySecondaryNav;
        let currentActiveSecondaryNav = this.currentActiveSecondaryNav;
        let companyData = {}
        if (profileData && 'object' in profileData) {
            companyData = getCompanyData(profileData.object.memberAccount.memberDynamicAttributes);
        }
        if (Object.keys(corporateCompanyProfile).length && Object.keys(corporateCompanyProfile.companyProfileData).length) {
            contractExpiry = getCompanyContractExpiry(corporateCompanyProfile.companyProfileData.object.memberAccount.memberDynamicAttributes);
        }
        
        
        return (
            <>
                <header className="header">
                    <div className=" fixed-top">
                        <div className="container">
                            <div className="header__top-menu compact-top-menu">
                                {/* <div className="logo"> 
                                    <a className="navbar-brand" href={t(`header.logoURL`)}> 
                                    <img src="images/logo.png" alt="Ibs" /> </a> 
                                </div> */}

                                <div className="logo">
                                    <a class="navbar-brand" href={t(`header.logoURL`)}>
                                        <img class="logo-main" src="images/logo.png" alt="AN" />
                                        <img className="logo-falcon" src="images/logo-falcon.png" alt="" />
                                    </a>
                                </div>

                                {(profileData && 'object' in profileData) && <div class="header__site-menu">
                                    <ul class="compact-top-menu__list">
                                        <li class="nav-item userText">
                                            
                                            {profileData.object.memberAccount.memberProfile.individualInfo.displayName ? profileData.object.memberAccount.memberProfile.individualInfo.displayName : profileData.object.memberAccount.memberProfile.individualInfo.givenName + ' ' + profileData.object.memberAccount.memberProfile.individualInfo.familyName} 
                                            &nbsp;/&nbsp;
                                            {profileData.object.memberAccount.membershipNumber}
                                            &nbsp;/&nbsp;
                                            {tierName}
                                        </li>
                                        <li class="nav-item"> <a class="nav-link" href="javascript:void(0)" onClick={() => this.logOutUser()}>{t(`header.logout`)}</a> </li>
                                    </ul>
                                </div>}
                            </div>
                        </div>
                    </div>
                    {isLoggedIn() && <div class="header__portal-menu navbar-menu-dropdown">
                        <div class="container">
                        <nav class="navbar navbar-expand-lg menuWrap3">
                            <div class="navbar-menu-dropdown__heading">{t(`header.subMenu.your_profile`)}</div>
                            <ol class="breadcrumb">
                            {/* <li class="breadcrumb-item"> <a href="#">Home</a> </li> */}
                            {/* <li class="breadcrumb-item active" aria-current="page">Dashboard</li> */}
                            </ol>
                            <button ref={this.ref} class={`navbar-toggler ${this.state.secondaryMobileNav.collapse}`} 
                                type="button" data-toggle="collapse" data-target="" aria-controls="" 
                                aria-expanded={this.state.secondaryMobileNav.areaExpanded} aria-label="Toggle navigation">
                            <div class="navbar-menu-dropdown__btn-heading">{t(`${currentActiveSecondaryNav.name}`)}</div>
                            <div class="hamburger"> <span></span> <span></span> <span></span> </div>
                            <div class="navbar-menu-dropdown__btn">
                                <svg width="33" height="33" viewBox="0 0 33 33" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M26.9762 21.0539C27.6681 21.647 28.7097 21.5668 29.3027 20.8749C29.8958 20.1831 29.8157 19.1414 29.1238 18.5484L17.5738 8.64837C16.9559 8.11873 16.0441 8.11873 15.4262 8.64837L3.87617 18.5484C3.18428 19.1414 3.10415 20.1831 3.6972 20.8749C4.29025 21.5668 5.33189 21.647 6.02378 21.0539L16.5 12.0743L26.9762 21.0539Z" fill="white"></path>
                                    <mask id="mask0_1584_44534" style={{"mask-type":"alpha"}} maskUnits="userSpaceOnUse" x="3" y="8" width="27" height="14">
                                    <path d="M26.9762 21.0539C27.6681 21.647 28.7097 21.5668 29.3027 20.8749C29.8958 20.1831 29.8157 19.1414 29.1238 18.5484L17.5738 8.64837C16.9559 8.11873 16.0441 8.11873 15.4262 8.64837L3.87617 18.5484C3.18428 19.1414 3.10415 20.1831 3.6972 20.8749C4.29025 21.5668 5.33189 21.647 6.02378 21.0539L16.5 12.0743L26.9762 21.0539Z" fill="white"></path>
                                    </mask>
                                    <g mask="url(#mask0_1584_44534)"> </g>
                                </svg>
                            </div>
                            </button>
                            <div class={`collapse navbar-collapse ${this.state.secondaryMobileNav.show}`} id="">
                            {!window.location.hash.includes(NAVIGATE_ACTIVATE) && <ul class="navbar-nav">
                                <li class="nav-item nav-head"> <strong>{t(`header.subMenu.your_profile`)}<span>
                                <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M4.70654 10.627L8.24396 6.5L4.70654 2.37301C4.47292 2.10045 4.50448 1.69011 4.77705 1.45648C5.04961 1.22286 5.45995 1.25442 5.69358 1.52699L9.59358 6.07699C9.80222 6.3204 9.80222 6.6796 9.59358 6.92301L5.69358 11.473C5.45995 11.7456 5.04961 11.7771 4.77705 11.5435C4.50448 11.3099 4.47292 10.8995 4.70654 10.627Z" fill="black"></path>
                                    <mask id="mask0_3115_9439" style={{"mask-type":"alpha"}} maskUnits="userSpaceOnUse" x="4" y="1" width="6" height="11">
                                    <path d="M4.70654 10.627L8.24396 6.5L4.70654 2.37301C4.47292 2.10045 4.50448 1.69011 4.77705 1.45648C5.04961 1.22286 5.45995 1.25442 5.69358 1.52699L9.59358 6.07699C9.80222 6.3204 9.80222 6.6796 9.59358 6.92301L5.69358 11.473C5.45995 11.7456 5.04961 11.7771 4.77705 11.5435C4.50448 11.3099 4.47292 10.8995 4.70654 10.627Z" fill="white"></path>
                                    </mask>
                                    <g mask="url(#mask0_3115_9439)"> </g>
                                </svg>
                                </span></strong></li>
                                <li class="nav-item"> <a class="nav-link" href={t(`header.subMenu.balances_link`)}>{t(`header.subMenu.balances`)}</a> </li>
                                <li class="nav-item"> <a class="nav-link" href={t(`header.subMenu.bookings_link`)}>{t(`header.subMenu.bookings`)}</a> </li>
                                <li class="nav-item"> <a class="nav-link" href="javascript:void(0)">{t(`header.subMenu.benefits`)}</a> </li>
                                <li class="nav-item"> <a class="nav-link" href={t(`header.subMenu.profile_link`)}>{t(`header.subMenu.profile`)}</a> </li>
                                {companySecondaryNav && companySecondaryNav.map((nav, index) => {
                                    return(
                                        <>
                                            {
                                                (!isShowCorporateLink && nav.name == 'header.subMenu.koruCorporate') ? '' : <li key={index} className={nav.class} onClick={() => {this.secondaryNavClick(index, nav.name)}}> 
                                                    <a class="nav-link" href={`#${nav.target}`}>{t(`${nav.name}`)}</a> 
                                                </li>
                                            }
                                        </>
                                    )
                                })}
                                </ul>}
                            </div>
                        </nav>
                        </div>
                    </div>}
                   { (window.location.hash.includes(NAVIGATE_CLUB_OVERVIEW) || window.location.hash.includes(NAVIGATE_COMPANY_PROFILE) || (window.location.href.split("?").length > 1 && window.location.href.split("?")[1].indexOf("payment=success") >= 0)) &&
                    <div className="banner-img header-with-tabs">
                        <div className="container">
                            {((window.location.hash.includes(NAVIGATE_CLUB_OVERVIEW) || (window.location.href.split("?").length > 1 && window.location.href.split("?")[1].indexOf("payment=success") >= 0)) && !isOnBehalfAdminEnrolment()) && 
                                <div className="banner-img__txt">
                                    <div>
                                        <span>{t(`header.heroBanner.name`)}</span>
                                        {t(`header.heroBanner.welcome`)} {(profileData && 'object' in profileData) ? (profileData.object.memberAccount.memberProfile.individualInfo.displayName ? profileData.object.memberAccount.memberProfile.individualInfo.displayName : profileData.object.memberAccount.memberProfile.individualInfo.givenName) : ''}
                                    </div>
                                </div>
                            }
                            {(isOnBehalfAdminEnrolment() && (window.location.href.split("?").length > 1 && window.location.href.split("?")[1].indexOf("payment=success") >= 0)) && 
                                <div className="banner-img__txt">
                                    <div>
                                        <span>{t(`header.heroBanner.name`)}</span>
                                        {t(`header.heroBanner.welcome`)} {onBehalfEmployee.fname}
                                    </div>
                                </div>
                            }
                            {(window.location.hash.includes(NAVIGATE_COMPANY_PROFILE)) && 
                                <div className="banner-img__txt">
                                    <div>
                                        <span>{t(`header.heroBanner.name`)}</span>
                                        {t(`header.heroBanner.welcome`)} {companyData.companyName}
                                    </div>
                                    {contractExpiry && <div class="banner-img__validity">
                                        <span>Contract valid to:</span> {contractExpiry}
                                    </div>}
                                </div>
                            }
                            {(window.location.hash.includes(NAVIGATE_CLUB_OVERVIEW) || window.location.hash.includes(NAVIGATE_COMPANY_PROFILE)) && <div className="header-tabs">
                                <a className={`header-tabs__button ${this.state.tertiaryMobileNav.collapse}`} data-toggle="collapse"
                                    href="#header_tab" role="button" aria-expanded={this.state.tertiaryMobileNav.areaExpanded}
                                    aria-controls="multiCollapseExample1" onClick={() => {this.state.tertiaryMobileNav.areaExpanded == "false" ? this.setState({tertiaryMobileNav: {collapse: "", show: "show", areaExpanded: "true"}}) : this.setState({tertiaryMobileNav: {collapse: "collapsed", show: "", areaExpanded: "false"}})}}>
                                    <svg width="20" height="33" viewBox="0 0 33 33" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M26.9762 21.0539C27.6681 21.647 28.7097 21.5668 29.3027 20.8749C29.8958 20.1831 29.8157 19.1414 29.1238 18.5484L17.5738 8.64837C16.9559 8.11873 16.0441 8.11873 15.4262 8.64837L3.87617 18.5484C3.18428 19.1414 3.10415 20.1831 3.6972 20.8749C4.29025 21.5668 5.33189 21.647 6.02378 21.0539L16.5 12.0743L26.9762 21.0539Z" fill="white"></path>
                                        <mask id="mask0_1584_44534" style={{"mask-type":"alpha"}} maskUnits="userSpaceOnUse" x="3" y="8" width="27" height="14">
                                        <path d="M26.9762 21.0539C27.6681 21.647 28.7097 21.5668 29.3027 20.8749C29.8958 20.1831 29.8157 19.1414 29.1238 18.5484L17.5738 8.64837C16.9559 8.11873 16.0441 8.11873 15.4262 8.64837L3.87617 18.5484C3.18428 19.1414 3.10415 20.1831 3.6972 20.8749C4.29025 21.5668 5.33189 21.647 6.02378 21.0539L16.5 12.0743L26.9762 21.0539Z" fill="white"></path>
                                        </mask>
                                        <g mask="url(#mask0_1584_44534)"> </g>
                                    </svg>
                                </a>
                                <div className={`header-tabs__navs ${this.state.tertiaryMobileNav.show}`} id="">
                                    {window.location.hash.includes(NAVIGATE_CLUB_OVERVIEW) && <ul>
                                        {headerTabs && headerTabs.map((tab, index) => {
                                            return (<li key={index}>
                                                <a role="button" 
                                                    className={(this.state.selectedTab === tab ? "active" : "")}
                                                    onClick={() => this.changeTab(tab)}>{t(`header.heroBanner.${tab}`)}</a>
                                            </li>)
                                        })}
                                    </ul>}

                                    {window.location.hash.includes(NAVIGATE_COMPANY_PROFILE) && <ul>
                                        {companyTabs && companyTabs.map((tab, index) => {
                                            return (<li key={index}>
                                                <a role="button"
                                                    className={(this.state.selectedTab === tab ? "active" : ((headerTabs.includes(this.state.selectedTab) && tab === "manageUsers") ? "active" : ""))}
                                                    onClick={() => this.changeTab(tab)}>{t(`header.heroBanner.${tab}`)}</a>
                                            </li>)
                                        })}
                                    </ul>}
                                </div>
                            </div>}
                        </div>
                    </div>
                    }
                </header>
            </>
        );
    }
}

function mapStateToProps(state) {
    const { language, navUpdate } = state;
    return {
        language, navUpdate,
        summaryConfig: state.configurationReducer[CONFIG_SECTION_SUMMARY],
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        currentUserData: state.currentLoginUserDataReducer.currentUserData,
        profileImage: state.profileImageReducer.profileImage,
        profileData: state.profileDataReducer.profileData,
        corporateCompanyProfile: state.CompanyProfileReducer
    };
}

const mapDispatchToProps = {
    changeLanguage,
    fetchConfiguration,
    logOut,
    setCurrentTab,
    clearCompany
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(withRouter(Header))));