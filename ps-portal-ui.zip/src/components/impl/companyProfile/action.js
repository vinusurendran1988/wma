
import {
    doPostEnrol, doPostLogin,doPost
} from '../../common/utils/api'
import {
    _URL_ENROLMENT,
    _URL_LOGIN_DETAILS,
    _URL_CHECK_MEMBERSHIP_NUMBER,
    _URL_PREAFFILIATED_ENROLMENT,
    _URL_FETCH_PROFILE_DETAILS,
    _URL_RETRIEVE_NOMINEES,
    _URL_UPDATE_PROFILE_DETAILS
} from '../../common/config/config'
import {
    getApiErrorMessage
} from '../../common/utils'
import { NAVIGATE_MEMBER_DASHBOARD } from '../../common/utils/urlConstants';
import { 
    setItemToBrowserStorage, 
    clearBrowserStorage,
    BROWSER_STORAGE_KEY_TOKEN, 
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO,
    BROWSER_STORAGE_KEY_ENROL,
    BROWSER_STORAGE_KEY_FIRST_TIME_USER,
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_PROGRAM_CODE,
    BROWSER_STORAGE_KEY_PROGRAM_TYPE,
    getItemFromBrowserStorage,
    BROWSER_STORAGE_KEY_REFRESH_TOKEN
} from '../../common/utils/storage.utils';
import { TRUE } from './Constants';
import { 
    startApiLoading,
    startButtonSpinner, 
    stopApiLoading, 
    stopButtonSpinner
} from '../../common/components/fieldbank/loader/action';
import { ERROR } from '../../ui/promotions/actions';

// Action Type
export const ENROLMENT_DATA = "ENROLMENT_DATA";
export const ENROLMENT_ERROR = "ENROLMENT_ERROR";
export const PREAFFLIATED_DATA = "PREAFFLIATED_DATA";
export const PREAFFLIATED_ERROR = "PREAFFLIATED_ERROR";
export const PREAFFILIATED_ENROLMENT_DATA = "PREAFFILIATED_ENROLMENT_DATA";
export const COMPANY_PROFILE = "COMPANY_PROFILE"
export const NOMINEE_PROFILE = "NOMINEE_PROFILE"
export const UPDATE_COMPANY_PROFILE = "UPDATE_COMPANY_PROFILE"
export const CLEAR_COMP = "CLEAR_COMP"



/**
 * Creates Action of type <i>_URL_FETCH_PROFILE_DETAILS</i> with given data
 * @author Amrutha
 * @param {object} payload Object to be passed as data in Action
 * @returns Action of type <i>_URL_FETCH_PROFILE_DETAILS</i>
 *
 */
 export const fetchCompanyProfile= (payload, id) => {
    return async dispatch => {
      dispatch(startButtonSpinner(id, "fetchCompanyProfile"))
      await doPost(_URL_FETCH_PROFILE_DETAILS, payload)
      .then((response) => {
          dispatch(stopButtonSpinner(id, "fetchCompanyProfile"))
          dispatch({
              type: COMPANY_PROFILE,
              payload: response.data
          })
      })
      .catch((error) => {
          dispatch(stopButtonSpinner(id, "fetchCompanyProfile"))
          dispatch({
              type: COMPANY_PROFILE,
              payload: {error: getApiErrorMessage(error.response.data.error)}
          })
      })
    };
  }

  
/**
 * Action call to retrieve account users
 * @param {JSON} payload Request payload to be dispatched
 * @author Amrutha J Raj
 */
 export const retrieveNominee= (payload) => {
    return async dispatch => {
        dispatch(startApiLoading("retrieveNominees"))
        await doPost(_URL_RETRIEVE_NOMINEES, payload)
            .then((response) => {
                dispatch(stopApiLoading("retrieveNominees"))
                dispatch({
                    type: NOMINEE_PROFILE,
                    payload: response.data.object
                })
            })
            .catch((error) => {
                dispatch(stopApiLoading("retrieveNominees"))
                dispatch({
                    type: NOMINEE_PROFILE,
                    payload: { error: getApiErrorMessage(error.response.data.error) }
                })
            })
    }
}

export const updateCompanyProfile = (profileData, id) => {
    return dispatch => {
        dispatch({
            type: UPDATE_COMPANY_PROFILE,
            payload: {}
        })
        dispatch(startButtonSpinner(id, "updateCompanyProfile"))
        return doPost(_URL_UPDATE_PROFILE_DETAILS, profileData)
            .then(response => {
                dispatch(stopButtonSpinner(id, "updateCompanyProfile"))
                dispatch({
                    type: UPDATE_COMPANY_PROFILE,
                    payload: response.data
                })
            }).catch(error => {
                //console.log(error);
                dispatch(stopButtonSpinner(id, "updateCompanyProfile"))
                dispatch({
                    type: UPDATE_COMPANY_PROFILE,
                    payload: { error: getApiErrorMessage(error.response.data.error) }
                })
            })
    }
}

/**
 * Action call to clear fetch company response
 * @param {JSON} payload Request payload to be dispatched
 * @author Amrutha J Raj
 */
export const clearCompany = () => {
    return dispatch => {
        dispatch({
            type: CLEAR_COMP,
            payload: {}
        })

    }
}
