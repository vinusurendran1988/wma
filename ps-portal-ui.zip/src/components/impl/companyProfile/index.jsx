import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { fetchConfiguration } from '../../common/middleware/redux/commonAction';
import { generateRequestBodyWithEmptyValue, withSuspense } from '../../common/utils';
import { CONFIG_SECTION_COMPANY_PROFILE, CONFIG_SECTION_MANAGE_ACCOUNT_USERS } from '../../common/utils/Constants';
import { doAdditionalMapping } from '../../common/utils/object.utils';
import {
    BROWSER_STORAGE_KEY_COMPANY_CODE, BROWSER_STORAGE_KEY_DEFAULT_PROGRAM_CODE, BROWSER_STORAGE_KEY_PROGRAM_CODE, getItemFromBrowserStorage
} from '../../common/utils/storage.utils';
import { fetchCompanyProfile, retrieveNominee } from './action';
import ProfileUpdate from './ProfileUpdate';

class CompanyProfile extends Component {

    constructor(props) {
        super(props)
        this.state = {
            updateProfileRequest: {}
        }
    }

    componentDidMount() {
        document.body.className = "theme__one view__compact";
        const { companyProfile, config } = this.props
        if (!companyProfile || companyProfile && Object.keys(companyProfile).length == 0) {
            const requestBody = {
                "object": {
                    "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                    "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_DEFAULT_PROGRAM_CODE),
                    "membershipNumber": this.props.companyData.companyId
                }
            }
            this.props.fetchCompanyProfile(requestBody)
        }

        

        const retrieveReqBody = {
            "object": {
                "companyCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                "programCode": getItemFromBrowserStorage(BROWSER_STORAGE_KEY_DEFAULT_PROGRAM_CODE),
                "membershipNumber": this.props.companyData.companyId,
                "accountGroupType": "K"
            }
        }
        this.props.retrieveNominee(retrieveReqBody)

        // if (!config || config && Object.keys(config).length == 0) {
        //     this.props.fetchConfiguration(CONFIG_SECTION_COMPANY_PROFILE)
        // }
        if (this.props.config && Object.keys(this.props.config).length > 0) {
            this.setState({
                updateProfileRequest: generateRequestBodyWithEmptyValue(this.props.config)
            }, () => {
                doAdditionalMapping(this, "updateProfileRequest")
            })
        }

    }

    componentDidUpdate(prevProps, prevState) {
        // if ((JSON.stringify(prevProps.config) != JSON.stringify(this.props.config)) ) {
        //     if (this.props.config && Object.keys(this.props.config).length > 0) {
        //         this.setState({
        //             updateProfileRequest: generateRequestBodyWithEmptyValue(this.props.config)
        //         }, () => {
        //             doAdditionalMapping(this, "updateProfileRequest")
        //         })
        //     }
        // }
    }

    render() {
        const { companyProfile, config, nominee } = this.props
        return (
            <div className="page__enrollment" data-test="enrolmentComponent">
                {companyProfile && Object.keys(companyProfile).length > 0 &&
                    config && Object.keys(config).length > 0 && this.state.updateProfileRequest
                    && Object.keys(this.state.updateProfileRequest).length > 0 &&
                    nominee && Object.keys(nominee).length > 0 &&
                    <ProfileUpdate page="form.enrolment.corporate" requestBody={this.state.updateProfileRequest} />}
            </div>
        );
    }
}

function mapStateToProps(state) {
    return {
        config: state.configurationReducer[CONFIG_SECTION_COMPANY_PROFILE],
        accountUsersconfig: state.configurationReducer[CONFIG_SECTION_MANAGE_ACCOUNT_USERS],
        companyProfile: state.CompanyProfileReducer.companyProfileData,
        nominee: state.CompanyProfileReducer.nomineeProfile,
        selectedTab : state.currentTabReducer.selectedTab

    }
}

const mapDispatchToProps = {
    fetchCompanyProfile,
    retrieveNominee,
    fetchConfiguration

}
export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(withRouter(CompanyProfile))))