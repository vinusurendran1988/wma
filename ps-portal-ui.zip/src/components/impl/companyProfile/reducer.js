import {
    ENROLMENT_DATA,
    PREAFFLIATED_DATA,
    PREAFFLIATED_ERROR,
    PREAFFILIATED_ENROLMENT_DATA,
    COMPANY_PROFILE,
    NOMINEE_PROFILE,
    UPDATE_COMPANY_PROFILE,
    CLEAR_COMP
} from './action';

export default function CompanyProfileReducer(state, action) {
    const { type, payload } = action;
    if (!state) state = {}
    switch (type) {
        case COMPANY_PROFILE: {
            return {
                ...state,
                companyProfileData: payload
            }
        }
        case NOMINEE_PROFILE:{
            return{
                ...state,
                nomineeProfile : payload
            }
        }
        case UPDATE_COMPANY_PROFILE:{
            return{
                ...state,
                updateCompanyResponse : payload
            }
        }
        case CLEAR_COMP:{
            return{
                ...state,
                companyProfileData :  {}
            }
        }
        default:
            return state;
    }

}
