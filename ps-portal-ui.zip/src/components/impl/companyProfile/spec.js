import React from 'react';
import { testStore } from '../../common/utils';
import moxios from 'moxios';
import { mount, shallow } from 'enzyme';
import {
    findByTestAttr,
    findComponent,
    mockServiceResponse,
    shallowRender
} from '../../common/testUtils';
import { axiosInstance } from '../../common/utils/api'
import Enrolment from './index'
import ReactTestUtils from 'react-dom/test-utils';
import {
    enrolment, enrollLoginDetails, checkGhostCardNumber,preaffiliatedEnrolment
} from './action';
import { Provider } from 'react-redux'
import {
    CONFIG_SECTION_ENROL, CONFIG_SECTION_LOGIN, SESSION_STORAGE_COMPANY_CODE, SESSION_STORAGE_PROGRAM_CODE
} from '../../common/utils/Constants'
import {
    fetchConfiguration
} from '../../common/middleware/redux/commonAction'
import { ID_SPINNER_PROCEED_TO_PAY } from '../buypoints/Constants';
import { TOKEN } from './Constants';
import { NAVIGATE_MEMBER_REGISTER } from '../../common/utils/urlConstants';
import Section from '../updateprofile/Section';
import PostEnrolmentMember from './PostEnrolmentMember';
import Register from './Register';
import {
    _URL_ENROLMENT,
    _URL_PREAFFILIATED_ENROLMENT
} from '../../common/config/config'
let store;
let rootComponent;
let rootComponentChild;
let component;
let componentChild;

export const AIRPORT = "airport"
export const AIRLINES = "airlines"
export const TITLE_GENDER = ""
export const MILEAGE = "mileage"
export const COUNTRY_ISD = ""
export const AIRLINE_BOOKING_CLASS = "airlineBookingClass"
export const LANGUAGE = ""
export const STATE = "state"
export const CITY = "city"

const setReferenceUrl = () => {
    const location = new URL(`http://localhost:8080/#${NAVIGATE_MEMBER_REGISTER}?MPN=IM0008010360&source=referral`)
    location.assign = jest.fn()
    location.replace = jest.fn()
    location.reload = jest.fn()
    delete window.location
    window.location = location

}

const setUpEnrol = (props = {}) => {
    localStorage.setItem(TOKEN, "token")
    window.scrollTo = jest.fn();
    store = testStore({})
    props.resetError = jest.fn()
    window.open = jest.fn()
    props.setPageInfo = jest.fn();
    rootComponent = mount(<Provider store={store}>
        <Enrolment {...props} store={store} />
    </Provider>);
    component = findComponent(rootComponent, 'Enrolment');
};

const setUpChild = (props = {}) => {
    localStorage.setItem(TOKEN, "token")
    window.scrollTo = jest.fn();
    store = testStore({})
    props.resetError = jest.fn()
    window.open = jest.fn()
    props.setPageInfo = jest.fn();
    rootComponentChild = mount(<Provider store={store}>
        <Register {...props} store={store} />
    </Provider>);
    componentChild = findComponent(rootComponentChild, 'Register');
};

describe('Enrolment Action: Single step', () => {

    beforeEach(() => {
        store = undefined
        setUpEnrol({});
        setReferenceUrl()
        store = testStore({})
        moxios.install(axiosInstance);
    });


    afterEach(() => {
        moxios.uninstall(axiosInstance);
    });

    it('enrolment: Unmark error fields', () => {
        setUpEnrol({});
        setReferenceUrl()
        component.setState({
            referenceMembershipNumber: "IM0008010415"
        })
        mockServiceResponse(CONFIG_RESPONSE)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_ENROL))
                .then(() => {
                    rootComponent.update();
                    component = component.update()
                    let newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_ENROL]).toBe(CONFIG_RESPONSE.object);
                    let btnEnrollFail = findByTestAttr(rootComponent, 'btnEnrollment');
                    expect(btnEnrollFail.length).toBe(1);
                    btnEnrollFail.simulate('click')
                })
        });
    })

    it('enrolment: Enrolment failed', () => {
        mockServiceResponse(ENROL_FAIL, 500)
        return ReactTestUtils.act(() => {
            return store.dispatch(enrolment({ "test": "test" }, { loading: true, divId: "" },_URL_ENROLMENT))
                .then(() => {
                    let newState = store.getState();
                    rootComponent = rootComponent.update();
                    component = findComponent(rootComponent, 'Enrolment');
                    expect(newState.commonErrorReducer.error[0]).toBe(ENROL_FAIL.error.errorDetails[0].message)
                })
        });
    })
    it('enrolment: post enrolement - indivitual single step', () => {
        setUpEnrol({});
        localStorage.setItem("programType", "indivitual")
        window.sessionStorage.setItem("programType", "indivitual")
        component.setState({
            referenceMembershipNumber: "IM0008010415"
        })
        mockServiceResponse(CONFIG_RESPONSE)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_ENROL))
                .then(() => {
                    let newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_ENROL]).toBe(CONFIG_RESPONSE.object);

                    mockServiceResponse(LOGIN_CONFIG)
                    return ReactTestUtils.act(() => {
                        return store.dispatch(fetchConfiguration(CONFIG_SECTION_LOGIN))
                            .then(() => {
                                newState = store.getState()
                                expect(newState.configurationReducer[CONFIG_SECTION_LOGIN]).toBe(LOGIN_CONFIG.object);
                                const enrolementData = { "object": { "status": "200", "memberAccount": { "membershipNumber": "1234" } } }
                                component.instance().postEnrolment(enrolementData, { "password": "1234" })
                            });
                    });
                })
        });
    })
   
    it('enrolment: post enrolement - corporate -twostep', () => {
        setUpEnrol({});
        localStorage.setItem("programType", "corporate")
        window.sessionStorage.setItem("programType", "corporate")
        component.setState({
            referenceMembershipNumber: "IM0008010415"
        })
        mockServiceResponse(CONFIG_TWO_STEP)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_ENROL))
                .then(() => {
                    let newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_ENROL]).toBe(CONFIG_TWO_STEP.object);

                    mockServiceResponse(LOGIN_CONFIG)
                    return ReactTestUtils.act(() => {
                        return store.dispatch(fetchConfiguration(CONFIG_SECTION_LOGIN))
                            .then(() => {
                                newState = store.getState()
                                expect(newState.configurationReducer[CONFIG_SECTION_LOGIN]).toBe(LOGIN_CONFIG.object);
                                const enrolementData = { "object": { "status": "200", "memberAccount": { "membershipNumber": "1234" } } }
                                component.instance().postEnrolment(enrolementData, { "password": "1234", "request": {} })
                            });
                    });
                })
        });
    })

    it('enrolment: post enrolement member component render', () => {
        let rootComponentPostEnrolMember = mount(
            <Provider store={store}>
                <PostEnrolmentMember />
            </Provider>
        );
        let childComponentPostEnrolMember = findComponent(rootComponentPostEnrolMember, 'PostEnrolmentMember');
        expect(childComponentPostEnrolMember.contains(<childComponentPostEnrolMember />)).toBe(false)
    })


    it('enrolment: enrolement success', () => {
        let newState = store.getState()
        mockServiceResponse(ENROL_SUCCESS, 200);
        return ReactTestUtils.act(() => {
            return store.dispatch(enrolment({ "test": "test" }, { loading: "true", divId: ID_SPINNER_PROCEED_TO_PAY },_URL_ENROLMENT))
                .then(() => {
                    newState = store.getState();
                    expect(newState.enrolment.enrolmentData).toBe(ENROL_SUCCESS);
                })
        });
    })

    it('enrolment: login enrolement success', () => {
        setUpEnrol({});
        mockServiceResponse(LOGIN_SUCCESS, 200,{"ps-token":"arwerwer234","ps-refreshToken":"adfsdf345","clientId":"auth-channel","secredId":"_DHFHSGDSFDSDAQ"});
        return ReactTestUtils.act(() => {
            return store.dispatch(enrollLoginDetails({
            "companyCode": "IBS",
            "customerPassword": "Pwd@1234",
            "membershipNumber": "IM0008010964",
            "programCode": "PRG14"
         }, { loading: "true", divId: ID_SPINNER_PROCEED_TO_PAY }))
                .then(() => {
                    let newState = store.getState()
                })
        });
    })

    it('enrolment: ghost card validation success', () => {
        setUpEnrol({});
        let newState = store.getState()
        mockServiceResponse(ENROL_SUCCESS, 200);
        return ReactTestUtils.act(() => {
            return store.dispatch(checkGhostCardNumber({ "test": "test" }, { loading: "true", divId: ID_SPINNER_PROCEED_TO_PAY }))
                .then(() => {
                    newState = store.getState()
                    expect(newState.enrolment.preaffliatedData).toBe(ENROL_SUCCESS);
                })
        });
    })

    it('enrolment: ghost card validation failure', () => {
        setUpEnrol({});
        let newState = store.getState()
        mockServiceResponse(ENROL_FAIL, 500);
        return ReactTestUtils.act(() => {
            return store.dispatch(checkGhostCardNumber({ "test": "test" }, { loading: "true", divId: "" }))
                .then(() => {
                    newState = store.getState()
                })
        });
    })

    it('enrolment: check button handle click with value', () => {
        setUpChild({});
        componentChild.instance().handleOnClick(null, "IM123",);
    })

    it('enrolment: check button handle click without value', () => {
        setUpChild({});
        componentChild.instance().handleOnClick(null, null);
        expect(componentChild.state('showPreaffiliatedMessage')).toEqual(true);

    })

    it('enrolment: get dynami atribute', () => {
        setUpChild({});
        componentChild.instance().getDynamicAttributesPath();
    })

    it('enrolment: find value from state', () => {
        setUpChild({});
        componentChild.instance().findValueFromState("value", "CB");
        componentChild.instance().findValueFromState("value", "B");
    })

    it('enrolment: add value to state', () => {
        setUpChild({});
        let field = { "fieldType": "CB", "name": "memberCheck", "childRelation": ["child1"], "parentRelation": ["parent1"], "siblingRelation": ["sibling1"] }
        let field1 = { "fieldType": "CB", "name": "memberCheck", "parentRelation": ["parent1"], "siblingRelation": ["sibling1"] }
        componentChild.instance().addValueToState(field, true);
        componentChild.instance().addValueToState(field1, true);

    })

    it('enrolment: handle error message from section', () => {
        setUpChild({});
        componentChild.instance().handleErrorMessagesFromSection(["error1"]);
    })
    it('enrolment: handle request change', () => {
        setUpChild({});
        componentChild.instance().handleRequestChange({ "request": "request" });
    })

    it('enrolment: additional validation', () => {
        setUpChild({});
        mockServiceResponse(CONFIG_RESPONSE)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_ENROL))
                .then(() => {
                    let newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_ENROL]).toBe(CONFIG_RESPONSE.object);
                    componentChild.setState({
                        request: { "object": { "memberAccount": { "membershipNumber": "123", "partner": "test", "memberProfile": { "individualInfo": { "preferredPhoneNumber": "HP","memberContactInfos":[{"mobileNumber":"9562665gh451"}] } } } } },
                        errorCodes: ["form.givenName.errorMessage.invalid", "form.familyName.errorMessage.invalid","form.enrolment.preferredHomeAddress.errorMessage.invalid"]
                    })
                    componentChild.instance().additionalValidation();
                });
        });
    
    })
    it('enrolment: create payload and enrole', () => {
        setUpChild({});
        mockServiceResponse(CONFIG_RESPONSE)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_ENROL))
                .then(() => {
                    let newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_ENROL]).toBe(CONFIG_RESPONSE.object);
                    componentChild.setState({
                        request: { "object": { "memberAccount": { "membershipNumber": "123", "partner": "test", "memberProfile": { "individualInfo": { "companyName": "name" } } } } },
                        errorCodes: ["form.givenName.errorMessage.invalid", "form.familyName.errorMessage.invalid"]
                    })
                    componentChild.instance().createPayloadAndEnroll();
                });
        });
    })
    it('enrolment: create payload and preaffiliated enrole', () => {
        setUpChild({});
        mockServiceResponse(CONFIG_RESPONSE)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_ENROL))
                .then(() => {
                    let newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_ENROL]).toBe(CONFIG_RESPONSE.object);
                    componentChild.setState({
                        request: { "object": { "memberAccount": { "membershipNumber": "123", "partner": "test", "memberProfile": { "individualInfo": { "companyName": "name" } } } } },
                        errorCodes: ["form.givenName.errorMessage.invalid", "form.familyName.errorMessage.invalid"],
                        isFFnoValidatedSuccesFully:true
                    })
                    componentChild.instance().createPayloadAndEnroll();
                });
        });
    })

    it('enrolment: button enrol click with error codes', () => {
        setUpChild({});
        componentChild.setState({
            errorCodes: ["form.givenName.errorMessage.invalid", "form.familyName.errorMessage.invalid"]
        })
        componentChild.instance().enroll();
        expect(componentChild.state('showWarningAndError')).toEqual(true);

    })

    it('enrolment: button enrol click without error codes', () => {
        setUpChild({});
        componentChild.setState({
            errorCodes: [],
            request: { "object": { "memberAccount": { "membershipNumber": "123", "partner": "test", "memberProfile": { "individualInfo": { "companyName": "name" } } } } }
        })
        componentChild.instance().enroll();
        expect(componentChild.state('showWarningAndError')).toEqual(true);

    })

    it('enrolment: set translated error codes', () => {
        setUpChild({});
        componentChild.instance().setTranslatedErrorMessages(["form.givenName.errorMessage.invalid", "form.familyName.errorMessage.invalid"]);
    })

    it('enrolment: clear field values', () => {
        setUpChild({});
        componentChild.setState({
            clearDataFlag: true,
            request: { "object": { "memberAccount": { "membershipNumber": "123", "partner": "test", "memberProfile": { "individualInfo": { "companyName": "name" } } } } },

        })
        componentChild.instance().setTranslatedErrorMessages(["form.givenName.errorMessage.invalid", "form.familyName.errorMessage.invalid"]);
    })

    it('enrolment: validate with state variable', () => {
        setUpChild({});
        componentChild.setState({
            request: { "object": { "memberAccount": { "membershipNumber": "123", "partner": "test", "memberProfile": { "individualInfo": { "companyName": "name" } } } } },
            errorCodes: ["form.givenName.errorMessage.invalid", "form.familyName.errorMessage.invalid"]

        })
        let field = {
            "fieldType": "B_TF",
            "id": "id-givenName",
            "name": "givenName",
            "path": { request: "object.memberAccount.memberProfile.individualInfo.givenName", response: "" },
            "required": true,
            "validations": [],
            "visibility": true
        }
        let validation = {
            "customMessageId": "form.location.errorMessage.invalid",
            "pattern": "^[ a-zA-Z]{1,20}$",
            "fields": ["one", "two"]
        }
      
        componentChild.instance().validateWithStateVariable(field,validation,"");
        componentChild.instance().validateWithStateVariable(field,validation,"sgsgsg");

    })

});

const LOGIN_success1 = { "headers": { "ps-token": "arwerwer345", "ps-refreshToken": "sfdgdrg345" }, "data": { "details": { "cliams": { "userDetails": { "membershipNumber": "3454353fddfg" } } } } }
const CONFIG_RESPONSE = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "section": "enrol", "companyCode": "IBS", "programCode": "PRG14", "activationType": "singleStep", "defaults": { "membershipStatus": "A", "operationFlag": "I" }, "password": { "pattern": "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&.,{}()?-_=+<>*!^/]).{8,20})" }, "dynamicAttributes": { "enrol": [{ "attributeMapping": "password" }], "activation": [] }, "accountStatus": "A", "enrolmentSource": "W", "membershipType": "I", "addressTypes": ["H", "B"], "memberReferralType": "M", "ui": { "isLayoutSequential": true, "request": { "additionalMapping": [{ "fromPath": ["object.memberAccount.memberProfile.individualInfo.title", "object.memberAccount.memberProfile.individualInfo.givenName", "object.memberAccount.memberProfile.individualInfo.familyName"], "toPath": "object.memberAccount.memberProfile.individualInfo.displayName" }, { "fromPath": ["window.localStorage.companyCode"], "toPath": "object.memberAccount.companyCode" }, { "fromPath": ["window.localStorage.programCode"], "toPath": "object.memberAccount.programCode" }, { "fromPath": ["config.defaults.accountStatus"], "toPath": "object.memberAccount.accountStatus" }, { "fromPath": ["config.defaults.enrolmentSource"], "toPath": "object.memberAccount.enrolmentSource" }, { "fromPath": ["getCurrentDate()"], "toPath": "object.memberAccount.enrolmentDate" }, { "fromPath": ["config.defaults.membershipType"], "toPath": "object.memberAccount.memberProfile.membershipType" }, { "fromPath": ["getReferenceNumberFromUrl()"], "toPath": "object.memberAccount.memberReferralDetail.referenceMembershipNumber" }, { "fromPath": ["config.memberReferralType"], "toPath": "object.memberAccount.memberReferralDetail.referenceType", "dependentPath": ["object.memberAccount.memberReferralDetail.referenceMembershipNumber"] }, { "fromPath": ["defaultConfig.data.addressTypes.0.key"], "toPath": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.0.addressType" }, { "fromPath": ["defaultConfig.data.addressTypes.1.key"], "toPath": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.1.addressType" }], "postProcessing": [{ "type": "removal", "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.1", "condition": [{ "pattern": "^({\"addressLine1\":\"\",\"phoneISDCode\":\"\",\"phoneNumber\":\"\",\"emailAddress\":\"\",\"addressType\":\"B\"})$" }] }, { "type": "removal", "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.0", "condition": [{ "pattern": "^({\"addressLine1\":\"\",\"phoneISDCode\":\"\",\"phoneNumber\":\"\",\"emailAddress\":\"\",\"addressType\":\"H\"})$" }] }], "additionalValidation": [{ "preCondition": { "path": "object.memberAccount.memberProfile.individualInfo.preferredAddress", "pattern": "^(H)$" }, "postCondition": [{ "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.0.addressLine1", "pattern": "^[a-zA-Z1-9 -]{1,20}$", "elementId": "id-address-1" }, { "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.0.addressLine2", "pattern": "^[a-zA-Z1-9 -]{1,20}$", "elementId": "id-address-2" }], "customMessageId": "form.enrolment.preferredHomeAddress.errorMessage.invalid" }, { "preCondition": { "path": "object.memberAccount.memberProfile.individualInfo.preferredAddress", "pattern": "^(B)$" }, "postCondition": [{ "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.1.addressLine1", "pattern": "^[a-zA-Z1-9 -]{1,20}$", "elementId": "id-company-address" }], "customMessageId": "form.enrolment.preferredBusinessAddress.errorMessage.invalid" }, { "preCondition": { "path": "object.memberAccount.memberProfile.individualInfo.preferredEmailAddress", "pattern": "^(H)$" }, "postCondition": [{ "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.0.emailAddress", "pattern": "\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$", "elementId": "id-email-id" }], "customMessageId": "form.enrolment.preferredHomeEmailAddress.errorMessage.invalid" }, { "preCondition": { "path": "object.memberAccount.memberProfile.individualInfo.preferredEmailAddress", "pattern": "^(B)$" }, "postCondition": [{ "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.1.emailAddress", "pattern": "\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$", "elementId": "id-business-email" }], "customMessageId": "form.enrolment.preferredBusinessEmailAddress.errorMessage.invalid" }, { "preCondition": { "path": "object.memberAccount.memberProfile.individualInfo.preferredPhoneNumber", "pattern": "^(HP)$" }, "postCondition": [{ "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.0.mobileNumber", "pattern": "^[0-9]{5,15}$", "elementId": "id-mobile-number" }], "customMessageId": "form.enrolment.preferredHomePhoneNumber.errorMessage.invalid" }, { "preCondition": { "path": "object.memberAccount.memberProfile.individualInfo.preferredPhoneNumber", "pattern": "^(BP)$" }, "postCondition": [{ "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos.1.mobileNumber", "pattern": "^[0-9]{5,15}$", "elementId": "id-company-phone" }], "customMessageId": "form.enrolment.preferredBusinessPhoneNumber.errorMessage.invalid" }] }, "layout": { "order": ["loginInfo", "personalInfo", "contactInfo", "companyInfo", "activation", "preferredCommunication", "agreeTerms"], "elements": { "loginInfo": { "fields": [{ "name": "memberPin", "id": "id-member-pin", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.pin", "validation": [{ "pattern": "^[0-9]{4}$", "customMessageId": "enrolment.form.memberPin" }] }, { "name": "password", "id": "id-password", "visibility": true, "isRequired": true, "validation": [{ "pattern": "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$", "customMessageId": "enrolment.form.password" }] }, { "name": "confirmPassword", "id": "id-confirm-password", "path": "object.memberAccount.memberProfile.customerPassword", "visibility": true, "isRequired": true, "validation": [{ "pattern": "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$", "customMessageId": "enrolment.form.confirmPassword" }, { "pattern": "^[password]$", "fields": ["password"], "customMessageId": "enrolment.form.passwordMismatch" }] }] }, "personalInfo": { "fields": [{ "name": "firstName", "id": "id-first-name", "additional": [{ "id": "id-title", "name": "title", "type": "lov", "source": "master", "values": [{ "key": "M", "value": "Male" }, { "key": "F", "value": "Female" }], "sourceKey": "titleMaster", "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.title", "validation": [{ "pattern": "^[a-zA-Z]{1,20}$", "customMessageId": "enrolment.form.title" }] }], "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.givenName", "validation": [{ "pattern": "[ a-zA-Z]{1,20}$", "customMessageId": "enrolment.form.firstName" }] }, { "name": "lastName", "id": "id-last-name", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.familyName", "validation": [{ "pattern": "[ a-zA-Z]{1,20}$", "customMessageId": "enrolment.form.lastName" }] }, { "name": "memberNationality", "id": "id-member-nationality", "type": "lov", "source": "master", "sourceKey": "countryMaster", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.memberNationality", "validation": [{ "pattern": "[A-Z]{2}$", "customMessageId": "form.memberNationality.errorMessage" }] }, { "name": "countryOfResidence", "id": "id-country-of-residence", "type": "lov", "source": "master", "sourceKey": "countryMaster", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.countryOfResidence", "validation": [{ "pattern": "[A-Z]{2}$", "customMessageId": "form.countryOfResidence.errorMessage" }] }, { "name": "preferredLanguage", "id": "id-preferred-language", "type": "lov", "source": "master", "sourceKey": "languageMaster", "path": "object.memberAccount.memberProfile.individualInfo.preferredLanguage", "visibility": true, "isRequired": true, "validation": [{ "pattern": "[A-Z]{2}$", "customMessageId": "enrolment.form.preferredLanguage" }] }, { "name": "dob", "id": "id-dob", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.dateOfBirth", "validation": [{ "pattern": "([12]\\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))", "customMessageId": "enrolment.form.dob" }] }, { "name": "gender", "id": "id-gender", "type": "lov", "source": "default", "sourceKey": "gender", "path": "object.memberAccount.memberProfile.individualInfo.gender", "visibility": true }, { "name": "emailAddress", "id": "id-email-id", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].emailAddress", "validation": [{ "pattern": "\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$", "customMessageId": "enrolment.form.emailAddress" }] }, { "name": "mobileNumber", "id": "id-mobile-number", "additional": [{ "id": "id-isd-code", "name": "mobileISDCode", "type": "lov", "source": "master", "sourceKey": "countryMaster", "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].mobileISDCode", "isRequired": true, "validation": [{ "pattern": "(\\+?\\d{1,3}|\\d{1,4})$", "customMessageId": "enrolment.form.isdCode" }] }], "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].mobileNumber", "validation": [{ "pattern": "\\d+$", "customMessageId": "enrolment.form.mobileNumber" }] }] }, "contactInfo": { "fields": [{ "name": "address1", "id": "id-address-1", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].addressLine1" }, { "name": "address2", "id": "id-address-2", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].addressLine2" }, { "name": "country", "id": "id-country", "type": "lov", "source": "master", "sourceKey": "countryMaster", "visibility": true, "isRequired": false, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].country", "validation": [{ "pattern": "[A-Z]{2}$", "customMessageId": "form.country.errorMessage" }] }, { "name": "zip", "id": "id-zip", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].zipCode" }, { "name": "phone", "id": "id-phone", "additional": [{ "id": "id-phone-isd-code", "name": "phoneISDCode", "type": "lov", "source": "master", "sourceKey": "countryMaster", "isRequired": false, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].phoneISDCode", "validation": [{ "pattern": "(\\+?\\d{1,3}|\\d{1,4})$", "customMessageId": "enrolment.form.phoneIsdCode" }] }], "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].phoneNumber", "visibility": true }] }, "companyInfo": { "fields": [{ "name": "companyName", "id": "id-company-name", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.companyName" }, { "name": "jobTitle", "id": "id-job-title", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.designation" }, { "name": "companyAddress", "id": "id-company-address", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[1].addressLine1" }, { "name": "companyPhone", "id": "id-company-phone", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[1].phoneNumber", "additional": [{ "id": "id-company-phone-isd-code", "name": "companyPhoneISDCode", "type": "lov", "source": "master", "sourceKey": "countryMaster", "isRequired": false, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[1].phoneISDCode", "validation": [{ "pattern": "(\\+?\\d{1,3}|\\d{1,4})$", "customMessageId": "enrolment.form.companyPhoneIsdCode" }] }] }, { "name": "businessEmail", "id": "id-business-email", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[1].emailAddress", "validation": [{ "pattern": "\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$", "customMessageId": "enrolment.form.emailAddress" }] }] }, "agreeTerms": { "fields": [{ "name": "agreeTerms", "id": "id-agree-terms", "visibility": true, "isRequired": true, "validation": [{ "pattern": "^(true)$", "customMessageId": "enrolment.form.termsOfUse" }] }, { "name": "privacyPolicy", "id": "id-agree-privacy-policy", "visibility": true, "isRequired": true, "validation": [{ "pattern": "^(true)$", "customMessageId": "enrolment.form.privacyPolicy" }] }, { "name": "thirdPartyPolicy", "id": "id-third-party-policy", "visibility": true }, { "name": "marketingAdvt", "id": "id-marketing-advt", "visibility": true }, { "name": "agreeAll", "id": "id-agree-all", "visibility": true }] }, "preferredCommunication": { "fields": [{ "name": "preferredAddress", "id": "id-preferred-address", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.preferredAddress", "source": "values", "defaultValue": "H", "values": [{ "key": "H", "value": "Home" }, { "key": "B", "value": "Business" }] }, { "name": "preferredEmailAddress", "id": "id-preferred-emailAddress", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.preferredEmailAddress", "source": "values", "defaultValue": "H", "values": [{ "key": "H", "value": "Home" }, { "key": "B", "value": "Business" }] }, { "name": "preferredPhoneNumber", "id": "id-preferred-phoneNumber", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.preferredPhoneNumber", "source": "values", "defaultValue": "HP", "values": [{ "key": "HP", "value": "Home" }, { "key": "BP", "value": "Business" }] }] } } } } } }
const ENROL_FAIL = { "statuscode": "500", "statusMessage": "FAILURE", "error": { "code": "500", "type": "INTERNAL_SERVER_ERROR", "message": "Enrol member failed", "errorDetails": [{ "message": "Duplicate member profile exists" }] } }
const ENROL_SUCCESS = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "memberActivityStatus": { "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010137", "accountStatus": "A", "activityNumber": "ACT3224", "activityType": "ME", "activityName": "ENROLLMENT", "activityStatus": "P", "activityCode": "ME", "pointDetails": [], "tiercode": "100" }, "pointDetail": [] } }
const LOGIN_CONFIG = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "section": "login", "companyCode": "IBS", "programCode": "PRG14", "loginTypes": ["userId", "email", "membershipNumber"], "socialLoginTypes": ["facebook", "google", "twitter"], "ui": { "order": ["loginCard"], "defaultLoginTypes": "membershipNumber", "clientId": "auth-channel", "secret": "_DHFHSGDSFDSDAQ", "rememberMeExpiresDays": 30, "maxLoginAttempt": 3, "secretKey": "487439fc-27ac-446e-96f7-2cd9d5f8b73f", "layout": { "elements": { "loginCard": { "fields": [{ "name": "userId", "loginType": "userId", "id": "id_user_id", "visibility": true, "isRequired": true, "validation": { "pattern": "[a-zA-Z0-9]{5,20}", "customMessageId": "login.message.enter_user_id" } }, { "name": "preferredEmail", "loginType": "email", "id": "id_email_id", "visibility": true, "isRequired": true, "validation": { "pattern": "\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$", "customMessageId": "login.message.enter_valid_email" } }, { "name": "membershipNumber", "toUpper": true, "loginType": "membershipNumber", "id": "id_mem_id", "visibility": true, "isRequired": true, "validation": { "pattern": "[a-zA-Z0-9]{6,15}", "customMessageId": "login.message.enter_valid_mem_id" } }, { "name": "customerPassword", "id": "id-psw", "visibility": true, "isRequired": true, "type": "password", "validation": { "pattern": "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$", "customMessageId": "login.message.enter_valid_password" } }, { "name": "rememberMe", "id": "id-remember-me", "visibility": true }, { "name": "forgotPassword", "id": "id-forgot-password", "visibility": true }, { "name": "loginBtn", "id": "id-login-btn", "visibility": true }, { "name": "joinNow", "id": "id-join-now", "visibility": true }, { "name": "seperator", "id": "id-seperator", "visibility": true }, { "name": "socialLogin", "id": "id-social-login", "visibility": true }] } } } } } }
const LOGIN_SUCCESS = { "statuscode": "200", "statusMessage": "SUCCESS", "success": true, "message": "Login Successful", "errors": null, "details": { "cliams": { "sub": "IM0008010137", "provider": null, "name": "Ajmal", "exp": 1600860730, "userId": "IM0008010137", "userDetails": { "membershipNumber": "IM0008010137", "accountStatus": "A", "preferredEmailAddress": "ps-test-001@loyalty.com", "membershipType": "I", "preferredLanguage": "EN", "tier": "100", "tierFromDate": "22-Sep-2020", "customerNumber": "6219" }, "iat": 1600774330, "email": "ps-test-001@loyalty.com" } } }
const CONFIG_TWO_STEP = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "section": "enrol", "companyCode": "IBS", "programCode": "PRG14", "activationType": "twoStep", "defaults": { "membershipStatus": "A", "operationFlag": "I" }, "password": { "pattern": "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&.,{}()?-_=+<>*!^/]).{8,20})" }, "dynamicAttributes": { "enrol": [{ "attributeMapping": "password" }], "activation": [] }, "accountStatus": "A", "enrolmentSource": "W", "membershipType": "I", "addressTypes": ["H", "B"], "memberReferralType": "M", "ui": { "isLayoutSequential": true, "request": { "additionalMapping": [{ "name": ["firstName", "lastName"], "path": "object.memberAccount.memberProfile.individualInfo.displayName" }, { "name": ["dynamicAttributes"], "path": "object.memberAccount.memberDynamicAttributes" }] }, "layout": { "order": ["loginInfo", "personalInfo", "contactInfo", "companyInfo", "activation", "preferredCommunication", "agreeTerms"], "elements": { "postEnrolment": { "emailPath": "abc@ibsplc.com" }, "loginInfo": { "fields": [{ "name": "memberPin", "id": "id-member-pin", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.pin", "validation": [{ "pattern": "^[0-9]{4}$", "customMessageId": "enrolment.form.memberPin" }] }, { "name": "password", "id": "id-password", "visibility": true, "isRequired": true, "validation": [{ "pattern": "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$", "customMessageId": "enrolment.form.password" }] }, { "name": "confirmPassword", "id": "id-confirm-password", "path": "object.memberAccount.memberProfile.customerPassword", "visibility": true, "isRequired": true, "validation": [{ "pattern": "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$", "customMessageId": "enrolment.form.confirmPassword" }, { "pattern": "^[password]$", "fields": ["password"], "customMessageId": "enrolment.form.passwordMismatch" }] }] }, "personalInfo": { "fields": [{ "name": "firstName", "id": "id-first-name", "additional": [{ "id": "id-title", "name": "title", "type": "lov", "source": "master", "values": [{ "key": "M", "value": "Male" }, { "key": "F", "value": "Female" }], "sourceKey": "titleMaster", "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.title", "validation": [{ "pattern": "^[a-zA-Z]{1,20}$", "customMessageId": "enrolment.form.title" }] }], "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.givenName", "validation": [{ "pattern": "[ a-zA-Z]{1,20}$", "customMessageId": "enrolment.form.firstName" }] }, { "name": "lastName", "id": "id-last-name", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.familyName", "validation": [{ "pattern": "[ a-zA-Z]{1,20}$", "customMessageId": "enrolment.form.lastName" }] }, { "name": "memberNationality", "id": "id-member-nationality", "type": "lov", "source": "master", "sourceKey": "countryMaster", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.memberNationality", "validation": [{ "pattern": "[A-Z]{2}$", "customMessageId": "form.memberNationality.errorMessage" }] }, { "name": "countryOfResidence", "id": "id-country-of-residence", "type": "lov", "source": "master", "sourceKey": "countryMaster", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.countryOfResidence", "validation": [{ "pattern": "[A-Z]{2}$", "customMessageId": "form.countryOfResidence.errorMessage" }] }, { "name": "preferredLanguage", "id": "id-preferred-language", "type": "lov", "source": "master", "sourceKey": "languageMaster", "path": "object.memberAccount.memberProfile.individualInfo.preferredLanguage", "visibility": true, "isRequired": true, "validation": [{ "pattern": "[A-Z]{2}$", "customMessageId": "enrolment.form.preferredLanguage" }] }, { "name": "dob", "id": "id-dob", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.dateOfBirth", "validation": [{ "pattern": "([12]\\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))", "customMessageId": "enrolment.form.dob" }] }, { "name": "gender", "id": "id-gender", "type": "lov", "source": "default", "sourceKey": "gender", "path": "object.memberAccount.memberProfile.individualInfo.gender", "visibility": true }, { "name": "emailAddress", "id": "id-email-id", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].emailAddress", "validation": [{ "pattern": "\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$", "customMessageId": "enrolment.form.emailAddress" }] }, { "name": "mobileNumber", "id": "id-mobile-number", "additional": [{ "id": "id-isd-code", "name": "mobileISDCode", "type": "lov", "source": "master", "sourceKey": "countryMaster", "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].mobileISDCode", "isRequired": true, "validation": [{ "pattern": "(\\+?\\d{1,3}|\\d{1,4})$", "customMessageId": "enrolment.form.isdCode" }] }], "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].mobileNumber", "validation": [{ "pattern": "\\d+$", "customMessageId": "enrolment.form.mobileNumber" }] }] }, "contactInfo": { "fields": [{ "name": "address1", "id": "id-address-1", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].addressLine1" }, { "name": "address2", "id": "id-address-2", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].addressLine2" }, { "name": "country", "id": "id-country", "type": "lov", "source": "master", "sourceKey": "countryMaster", "visibility": true, "isRequired": false, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].country", "validation": [{ "pattern": "[A-Z]{2}$", "customMessageId": "form.country.errorMessage" }] }, { "name": "zip", "id": "id-zip", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].zipCode" }, { "name": "phone", "id": "id-phone", "additional": [{ "id": "id-phone-isd-code", "name": "phoneISDCode", "type": "lov", "source": "master", "sourceKey": "countryMaster", "isRequired": false, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].phoneISDCode", "validation": [{ "pattern": "(\\+?\\d{1,3}|\\d{1,4})$", "customMessageId": "enrolment.form.phoneIsdCode" }] }], "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].phoneNumber", "visibility": true }] }, "companyInfo": { "fields": [{ "name": "companyName", "id": "id-company-name", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.companyName" }, { "name": "jobTitle", "id": "id-job-title", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.designation" }, { "name": "companyAddress", "id": "id-company-address", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[1].addressLine1" }, { "name": "companyPhone", "id": "id-company-phone", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[1].phoneNumber", "additional": [{ "id": "id-company-phone-isd-code", "name": "companyPhoneISDCode", "type": "lov", "source": "master", "sourceKey": "countryMaster", "isRequired": false, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[1].phoneISDCode", "validation": [{ "pattern": "(\\+?\\d{1,3}|\\d{1,4})$", "customMessageId": "enrolment.form.companyPhoneIsdCode" }] }] }, { "name": "businessEmail", "id": "id-business-email", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[1].emailAddress", "validation": [{ "pattern": "\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$", "customMessageId": "enrolment.form.emailAddress" }] }] }, "agreeTerms": { "fields": [{ "name": "agreeTerms", "id": "id-agree-terms", "visibility": true, "isRequired": true, "validation": [{ "pattern": "^(true)$", "customMessageId": "enrolment.form.termsOfUse" }] }, { "name": "privacyPolicy", "id": "id-agree-privacy-policy", "visibility": true, "isRequired": true, "validation": [{ "pattern": "^(true)$", "customMessageId": "enrolment.form.privacyPolicy" }] }, { "name": "thirdPartyPolicy", "id": "id-third-party-policy", "visibility": true }, { "name": "marketingAdvt", "id": "id-marketing-advt", "visibility": true }, { "name": "agreeAll", "id": "id-agree-all", "visibility": true }] }, "preferredCommunication": { "fields": [{ "name": "preferredAddress", "id": "id-preferred-address", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.preferredAddress", "source": "values", "defaultValue": "H", "values": [{ "key": "H", "value": "Home" }, { "key": "B", "value": "Business" }] }, { "name": "preferredEmailAddress", "id": "id-preferred-emailAddress", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.preferredEmailAddress", "source": "values", "defaultValue": "H", "values": [{ "key": "H", "value": "Home" }, { "key": "B", "value": "Business" }] }, { "name": "preferredPhoneNumber", "id": "id-preferred-phoneNumber", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.preferredPhoneNumber", "source": "values", "defaultValue": "HP", "values": [{ "key": "HP", "value": "Home" }, { "key": "BP", "value": "Business" }] }] } } } } } }