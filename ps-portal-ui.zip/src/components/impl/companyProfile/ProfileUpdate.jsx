import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import AlertBox from '../../common/components/fieldbank/AlertBox';
import Button from '../../common/components/fieldbank/Button';
import { FIELDTYPE_CHECKBOX } from '../../common/components/fieldbank/Constants';
import {
    fetchConfiguration, fetchDefaultUserProfileData, logOut, resetError, setError
} from '../../common/middleware/redux/commonAction';
import {
    generateRequestBodyWithEmptyValue,
    getFormattedDate,
    isPatternMatch, withSuspense
} from '../../common/utils';
import {
    CONFIG_SECTION_COMPANY_PROFILE, CONFIG_SECTION_DEFAULT, CONFIG_SECTION_MEMBERCHECK
} from '../../common/utils/Constants';
import { findValueFromObjectByPath, getValueFromPath } from '../../common/utils/object.utils';
import {
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_PROGRAM_CODE, getItemFromBrowserStorage
} from '../../common/utils/storage.utils';
import { DATE_FORMAT_DDMMYYYY_WITH_SPACE } from '../../ui/subscription/Constants';
import { checkDateisFutureDate, checkIfDateIsAfterGracePeriod } from '../../ui/subscription/Services/CommonUtils';
import Section from '../../ui/updateprofile/Section';
import { updateCompanyProfile } from './action';
import { GET_DATA_FROM_URL, ID_SUBMIT_BUTTON } from './Constants';

class ProfileUpdate extends Component {
    constructor(props) {
        super(props)
        this.state = {
            showWarningAndError: false,
            companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
            programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
            errorCodes: [],
            isButtonClicked: false,
            isHavingFFNo: undefined,
            corporateFlag: false,
            companyProfile: props.companyProfile,
            updateProfileRequest: this.props.requestBody,
            apiResponse: undefined,
        }
        this.onCancel = this.onCancel.bind(this)
    }

    componentDidMount() {
        const { config } = this.props
        this.props.resetError()
        if (this.state.errorCodes.length) {
            this.setState({
                errorCodes: []
            })
        }
        document.body.scrollTop = document.documentElement.scrollTop = 0

    }

    componentDidUpdate(prevProps, prevState) {
        const { t, updateCompanyResponse } = this.props
        if (JSON.stringify(prevProps.updateCompanyResponse) != JSON.stringify(updateCompanyResponse)) {
            if (updateCompanyResponse && updateCompanyResponse.error) {
                this.setState({
                    apiResponse: {
                        type: "danger",
                        message: t('companyProfile.profileUpdatedFailed')
                    }
                })
                window.scrollTo(0, 0)
            }
            else if (updateCompanyResponse && updateCompanyResponse.statuscode && updateCompanyResponse.statuscode == "200") {
                this.setState({
                    apiResponse: {
                        type: "success",
                        message: t('companyProfile.savedAlert')
                    }
                })
                window.scrollTo(0, 0)
            }
            this.setState({ isProfileUpdated: true })

        }

    }

    getValueFromPath(path, key) {
        let returnValue = ""
        if (path.startsWith(GET_DATA_FROM_URL)) {
            returnValue = this.getDataFromUrl(window.location.hash, key)
        } else {
            returnValue = getValueFromPath(path, { ...this.props, ...this.state })
        }
        return returnValue
    }


    handleRequestChange(request) {
        this.setState({
            updateProfileRequest: request,
            apiResponse: undefined,
            showWarningAndError: false
        })
    }

    handleErrorMessagesFromSection(codes) {
        if (!codes.length) { this.props.resetError() }
        if (JSON.stringify(codes) != JSON.stringify(this.state.errorCodes)) {
            this.setState({ errorCodes: codes })
        }
    }

    addValueToState(field, value) {
        let newState = {}
        if (field.fieldType == FIELDTYPE_CHECKBOX) {
            if (field.name == CONFIG_SECTION_MEMBERCHECK) {
                this.setState({
                    isHavingFFNo: value ? true : undefined,
                    clearDataFlag: value ? false : true
                })
            }
            if (field.childRelation) {
                field.childRelation.forEach(child => {
                    newState[child] = value
                })
            } else if (field.parentRelation) {
                newState[field.parentRelation] = true
                if (field.siblingRelation) {
                    newState[field.parentRelation] = newState[field.parentRelation] && value
                    field.siblingRelation.forEach(sibling => {
                        newState[field.parentRelation] = this.state[sibling] && newState[field.parentRelation]

                    })
                }
            }
        }
        newState[field.name] = value
        this.setState(newState)
    }

    validateWithStateVariable(field, validation, value) {
        let { pattern, fields } = validation
        let isValidationSuccess = true, canUpdateState = false
        fields.forEach((fd) => {
            const newPattern = pattern.replace("[fields]", this.state[fd])
            if (!isPatternMatch(newPattern, value)) {
                isValidationSuccess = false
            }
        })
        let { errorCodes } = this.state
        if (!isValidationSuccess) {
            if (!errorCodes.includes(validation.customMessageId)) {
                errorCodes.push(validation.customMessageId)
                canUpdateState = true
            }
        } else if (errorCodes.includes(validation.customMessageId)) {
            const index = errorCodes.indexOf(validation.customMessageId)
            if (index > -1) {
                canUpdateState = true
                errorCodes.splice(index, 1)
            }
        }
        field.error = !isValidationSuccess
        if (canUpdateState) {
            this.setState({
                errorCodes
            })
        }
        return !isValidationSuccess
    }

    findValueFromState(stateFieldName, fieldType) {
        if (fieldType == FIELDTYPE_CHECKBOX) {
            return this.state[stateFieldName] ? this.state[stateFieldName] : false
        } else {
            return this.state[stateFieldName] ? this.state[stateFieldName] : ""
        }
    }

    getDynamicAttributesPath() {
        const { additionalMappings } = this.props
        const attribute = additionalMappings.find((attr) => { return attr.name.includes("dynamicAttributes") })
        if (attribute) {
            return attribute.path
        }
        return ""
    }

    onCancel() {
        this.setState({
            request: generateRequestBodyWithEmptyValue(this.props.config),
            isButtonClicked: false,
            showWarningAndError: false
        })
    }

    getContractInfo = () => {
        const { companyProfile } = this.props
        let contractInfo
        if (companyProfile && companyProfile.object && companyProfile.object.memberAccount &&
            companyProfile.object.memberAccount.memberDynamicAttributes) {
            const validFrom = companyProfile.object.memberAccount.memberDynamicAttributes.find(item => item.attributeCode == 13)
            const validTo = companyProfile.object.memberAccount.memberDynamicAttributes.find(item => item.attributeCode == 14)
            if (validFrom && validTo) {
                contractInfo = {
                    validFrom: validFrom,
                    validTo: validTo
                }
            }
        }
        return contractInfo
    }
    createResponseObject = () => {
        const { companyProfile, nominee, profileData } = this.props
        const responseObject = JSON.parse(JSON.stringify(companyProfile))
        responseObject.country = "New Zealand"
        const expiryDateObject = this.checkIfCommonExpiryPresent()
        if (expiryDateObject && Object.keys(expiryDateObject).length > 0) {
            var months = [
                { key: "Jan", value: "31 January" }, { key: "Feb", value: "28 February" },
                { key: "Mar", value: "31 March" }, { key: "Apr", value: "30 April" },
                { key: "May", value: "31 May" }, { key: "Jun", value: "30 June" },
                { key: "Jul", value: "31 July" }, { key: "Aug", value: "31 August" },
                { key: "Sep", value: "30 September" }, { key: "Oct", value: "31 October" },
                { key: "Nov", value: "30 November" }, { key: "Dec", value: "31 December" }]
            const expiry = months.find(month => month.key == expiryDateObject.attributeValue)
            if (expiry) {
                responseObject.commonExpiry = expiry.value
            }

        }
        const contractInfo = this.getContractInfo()
        if (contractInfo && Object.keys(contractInfo).length > 0) {
            responseObject.validFromDate = getFormattedDate(contractInfo.validFrom.attributeValue, DATE_FORMAT_DDMMYYYY_WITH_SPACE)
            if (contractInfo.validTo.attributeValue.endsWith("2099")) {
                responseObject.validToDate = this.props.t('companyProfile.noExpiry')
            }
            else {
                responseObject.validToDate = getFormattedDate(contractInfo.validTo.attributeValue, DATE_FORMAT_DDMMYYYY_WITH_SPACE)
            }
            responseObject.contractInfo = contractInfo
        }
        if (nominee) {
            responseObject.nominee = nominee
        }
        if (responseObject.object && responseObject.object.memberAccount &&
            responseObject.object.memberAccount.memberDynamicAttributes &&
            Object.keys(responseObject.object.memberAccount.memberDynamicAttributes).length > 0) {
            const travelMg = responseObject.object.memberAccount.memberDynamicAttributes.find(item => item.attributeCode == 23)
            if (travelMg) {
                responseObject.travelMgCompanyName = travelMg.attributeValue
            }
        }
        if (profileData && profileData.object && profileData.object.memberAccount && profileData.object.memberAccount.memberProfile
             && profileData.object.memberAccount.memberProfile.individualInfo) {
            if(profileData.object.memberAccount.memberProfile.individualInfo.displayName){
                responseObject["givenName"] = profileData.object.memberAccount.memberProfile.individualInfo.displayName
            }
            else{
                responseObject["givenName"] = profileData.object.memberAccount.memberProfile.individualInfo.givenName
            }
            responseObject["familyName"] = profileData.object.memberAccount.memberProfile.individualInfo.familyName
    }
        return responseObject
    }

    checkIfCommonExpiryPresent = () => {
        const { companyProfile } = this.props
        if (companyProfile && companyProfile.object && companyProfile.object.memberAccount &&
            companyProfile.object.memberAccount.memberDynamicAttributes) {
            const isExpiryObj = companyProfile.object.memberAccount.memberDynamicAttributes.find(item => item.attributeCode == 27)
            const expiryObj = companyProfile.object.memberAccount.memberDynamicAttributes.find(item => item.attributeCode == 16)
            if (expiryObj && Object.keys(expiryObj).length > 0) {
                return expiryObj
            }
        }
        return null
    }

    getSectionInfoFromConfig = (section, sectionName) => {
        if (sectionName == "corporateInfo") {
            const commonExpiryObj = this.checkIfCommonExpiryPresent()
            if (commonExpiryObj && Object.keys(commonExpiryObj).length > 0) {
                if (section.fields) {
                    section.fields.map(field => {
                        if (field.name == "commonExpiryDate") {
                            field.visibility = true
                        }
                        if (field.name == "alert") {
                            field.i18MessageCode = "form.expiryDateAlert.expiry"
                        }
                        return field
                    })
                }
            }
        }
        if (sectionName == "contractInfo") {
            let contractInfo = this.getContractInfo();
            let isAfterGracePeriod
            let isFutureDate
            if (contractInfo && contractInfo.validTo && contractInfo.validTo.attributeValue) {
                isAfterGracePeriod = checkIfDateIsAfterGracePeriod(getFormattedDate(contractInfo.validTo.attributeValue, DATE_FORMAT_DDMMYYYY_WITH_SPACE))
            }
            if (contractInfo && contractInfo.validFrom && contractInfo.validFrom.attributeValue) {
                isFutureDate = checkDateisFutureDate(getFormattedDate(contractInfo.validFrom.attributeValue, DATE_FORMAT_DDMMYYYY_WITH_SPACE))
            }

            if (!contractInfo || isAfterGracePeriod || isFutureDate) {
                section.visibility = false
            }
        }
        return section
    }

    getRequestBody = () => {
        const { updateProfileRequest } = this.state
        const { config, dynamicAttributes } = this.props
        let existingTravelMgComp
        if (updateProfileRequest && updateProfileRequest.object) {
            let requestBody = JSON.parse(JSON.stringify(updateProfileRequest))

            let travelManagementCompanyName
            if (updateProfileRequest.object.travelMgCompanyName) {
                travelManagementCompanyName = requestBody.object.travelMgCompanyName
            }
            if (travelManagementCompanyName && dynamicAttributes) {
                dynamicAttributes.map(item => {
                    if (item.attributeCode == 23) {
                        item.attributeValue = travelManagementCompanyName
                    }
                    return item
                })
                if (requestBody.object && requestBody.object.memberAccount && requestBody.object.memberAccount.memberDynamicAttributes) {
                    existingTravelMgComp = requestBody.object.memberAccount.memberDynamicAttributes.find(item => item.attributeCode == 23)
                    if (existingTravelMgComp) {
                        requestBody.object.memberAccount.memberDynamicAttributes.map(item => {
                            if (item.attributeCode == 23) {
                                item.attributeValue = travelManagementCompanyName
                            }
                        })
                    }
                    else {
                        requestBody.object.memberAccount.memberDynamicAttributes = [...requestBody.object.memberAccount.memberDynamicAttributes, ...dynamicAttributes]
                    }
                }
            }
            if (requestBody.object && requestBody.object.memberAccount &&
                requestBody.object.memberAccount.accountStatus) {
                switch (requestBody.object.memberAccount.accountStatus) {
                    case "Active": {
                        requestBody.object.memberAccount.accountStatus = "A"
                        break
                    }
                }
            }
            if (requestBody.object && requestBody.object.memberAccount &&
                requestBody.object.memberAccount.memberProfile &&
                requestBody.object.memberAccount.memberProfile.membershipStatus
            ) {
                switch (requestBody.object.memberAccount.memberProfile.membershipStatus) {
                    case "Active": {
                        requestBody.object.memberAccount.memberProfile.membershipStatus = "A"
                        break
                    }
                }
            }
            delete requestBody["object"]["travelMgCompanyName"]
            return requestBody
        }
    }


    updateProfile = () => {
        const { errorCodes } = this.state
        const reqBody = this.getRequestBody()
        console.log("Request body -------- ", reqBody);
        if (errorCodes.length > 0) {
            this.props.setError(errorCodes);
            window.scrollTo(0, 0)
        } else {
            this.props.resetError()
            this.props.updateCompanyProfile(reqBody, ID_SUBMIT_BUTTON)
        }
        this.setState({ showWarningAndError: true, isButtonClicked: true })

    }

    render() {
        const { errorCodes, showWarningAndError,
            updateProfileRequest, apiResponse } = this.state
        const { t, uiLayout, sections, config } = this.props
        const template = config && config.ui && config.ui.template

        return (
            <>
                <h1> {t('companyProfile.title')}</h1>
                {this.state.apiResponse && Object.keys(apiResponse).length &&
                    <AlertBox type={apiResponse.type} message={apiResponse.message} />
                }
                <div className="single-col-view">
                    <div className="form" data-test="enrollmentForm">
                        {
                            this.props.companyProfile && Object.keys(this.props.companyProfile).length > 0
                            && updateProfileRequest && Object.keys(updateProfileRequest).length > 0 &&
                            sections && sections.map((section, i) => {
                                return uiLayout.elements[section] && <Section
                                    key={i}
                                    id={section}
                                    displayElements={this.getSectionInfoFromConfig(uiLayout.elements[section], section)}
                                    request={updateProfileRequest}
                                    response={this.createResponseObject()}
                                    page={`${this.props.page}`}
                                    onRequestChange={(req) => this.handleRequestChange(req)}
                                    errorCodes={errorCodes}
                                    showWarningAndError={showWarningAndError}
                                    onErrorCodes={(codes) => this.handleErrorMessagesFromSection(codes)}
                                    addValueToState={(field, value) => this.addValueToState(field, value)}
                                    validateWithStateVariable={(field, validation, value) => this.validateWithStateVariable(field, validation, value)}
                                    findValueFromState={(stateFieldName, fieldType) => this.findValueFromState(stateFieldName, fieldType)}
                                    isButtonClicked={this.state.isButtonClicked}
                                    template={config && config.ui && config.ui.template}
                                />
                            })
                        }
                        <div className="btn-wrap btn-wrap--grp">
                            <Button
                                className="btn btn-primary"
                                handleOnClick={() => this.updateProfile()}
                                id={ID_SUBMIT_BUTTON}
                                testIdentifier="btnEnrollment"
                                label={t("companyProfile.saveCompany")} />
                        </div>
                    </div>
                </div>
            </>

        )
    }
}

function mapStateToProps(state) {
    return {
        sections: findValueFromObjectByPath(state, 'configurationReducer.companyprofile.ui.layout.order', []),
        uiLayout: findValueFromObjectByPath(state, 'configurationReducer.companyprofile.ui.layout', []),
        additionalMappings: findValueFromObjectByPath(state, 'configurationReducer.companyprofile.ui.request.additionalMapping', []),
        dynamicAttributes: findValueFromObjectByPath(state, 'configurationReducer.companyprofile.dynamicAttributes.updateProfile', []),
        dynamicAttributesPath: findValueFromObjectByPath(state, 'configurationReducer.companyprofile.ui.dynamicAttributesPath', ""),
        error: state.commonErrorReducer.error,
        enrolmentData: state.enrolment.enrolmentData,
        config: state.configurationReducer[CONFIG_SECTION_COMPANY_PROFILE],
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        companyProfile: state.CompanyProfileReducer.companyProfileData,
        nominee: state.CompanyProfileReducer.nomineeProfile,
        updateCompanyResponse: state.CompanyProfileReducer.updateCompanyResponse,
        profileData: state.profileDataReducer.profileData

    }
}

const mapDispatchToProps = {
    resetError,
    fetchConfiguration,
    logOut,
    setError,
    fetchDefaultUserProfileData,
    updateCompanyProfile
}
export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(ProfileUpdate)));
