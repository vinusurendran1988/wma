import React from 'react';
import { testStore } from '../../common/utils';
import moxios from 'moxios';
import { mount } from 'enzyme';
import {
    findByTestAttr,
    findComponent,
    mockServiceResponse
} from '../../common/testUtils';
import Enrolment from './index'
import ReactTestUtils from 'react-dom/test-utils';
import {
    enrolment
} from './action';
import { Provider } from 'react-redux'
import {
    CONFIG_SECTION_ENROL, CONFIG_SECTION_LOGIN, SESSION_STORAGE_COMPANY_CODE, SESSION_STORAGE_PROGRAM_CODE
} from '../../common/utils/Constants'
import {
    fetchConfiguration
} from '../../common/middleware/redux/commonAction'
import { ID_SPINNER_PROCEED_TO_PAY } from '../buypoints/Constants';
import { TOKEN } from './Constants';
import { NAVIGATE_MEMBER_REGISTER } from '../../common/utils/urlConstants';

let store;
let rootComponent;
let component;

export const AIRPORT = "airport"
export const AIRLINES = "airlines"
export const TITLE_GENDER = ""
export const MILEAGE = "mileage"
export const COUNTRY_ISD = ""
export const AIRLINE_BOOKING_CLASS = "airlineBookingClass"
export const LANGUAGE = ""
export const STATE = "state"
export const CITY = "city"

const setReferenceUrl = () => {
    const location = new URL(`http://localhost:8080/#${NAVIGATE_MEMBER_REGISTER}?MPN=IM0008010360&source=referral`)
    location.assign = jest.fn()
    location.replace = jest.fn()
    location.reload = jest.fn()
    delete window.location
    window.location = location

}

const setUpEnrol = (props = {}) => {
    localStorage.setItem(TOKEN, "token")
    window.scrollTo = jest.fn();
    store = testStore({})
    props.resetError = jest.fn()
    window.open = jest.fn()
    rootComponent = mount(<Provider store={store}>
        <Enrolment {...props} store={store} />
    </Provider>);
    component = findComponent(rootComponent, 'Enrolment');
};

describe('Enrolment Action: Single step', () => {

    beforeEach(() => {
        store = undefined
        setUpEnrol({});
        setReferenceUrl()
        moxios.install();
    });


    afterEach(() => {
        moxios.uninstall();
    });

    it('enrolment: Unmark error fields', () => {
        setReferenceUrl()
        component.setState({
            referenceMembershipNumber: "IM0008010415"
        })

        rootComponent = rootComponent.update();
        component = findComponent(rootComponent, 'Enrolment');
        const enrolmentComponent = findByTestAttr(component, 'enrolmentComponent');
        expect(enrolmentComponent.length).toBe(1);

        mockServiceResponse(CONFIG_RESPONSE)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_ENROL))
                .then(() => {
                    let newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_ENROL]).toBe(CONFIG_RESPONSE.object);

                    rootComponent = rootComponent.update();
                    component = findComponent(rootComponent, 'Enrolment');

                    let btnEnrollFail = findByTestAttr(component, 'btnEnroll');
                    expect(btnEnrollFail.length).toBe(1);
                    btnEnrollFail.simulate('click')

                    const memberPin = findByTestAttr(component, 'memberPin');
                    expect(memberPin.length).toBe(1);
                    memberPin.simulate('change', { target: { value: "4321", classList: { value: "is-invalid" } } })

                    btnEnrollFail.simulate('click')

                    const password = findByTestAttr(component, 'password');
                    expect(password.length).toBe(1);
                    password.simulate('change', { target: { value: "Pwd@1234", classList: { value: "is-invalid" } } })

                    btnEnrollFail.simulate('click')

                    const agreeTerms = findByTestAttr(component, 'agreeTerms');
                    expect(agreeTerms.length).toBe(1);
                    agreeTerms.simulate('change', { target: { value: true, classList: { value: "is-invalid" } } })
                })
        });
    })

    it('enrolment: Enrolment failed', () => {
        mockServiceResponse(ENROL_FAIL, 500)
        return ReactTestUtils.act(() => {
            return store.dispatch(enrolment({ "test": "test" }, { loading: true, divId: "" }))
                .then(() => {
                    let newState = store.getState();
                    rootComponent = rootComponent.update();
                    component = findComponent(rootComponent, 'Enrolment');
                    expect(newState.commonErrorReducer.error[0]).toBe(ENROL_FAIL.error.errorDetails[0].message)
                })
        });
    })

    // it('enrolment: Login failed after success enroll', () => {
    //     mockServiceResponse(ENROL_FAIL, 500)
    //     return ReactTestUtils.act(() => {
    //         return store.dispatch(enrollLoginDetails({ "test": "test" }, { loading: true, divId: "" }))
    //     });
    // })

    it('enrolment: open facebook and google login popup', () => {
        const enrolmentComponent = findByTestAttr(component, 'enrolmentComponent');
        expect(enrolmentComponent.length).toBe(1);

        mockServiceResponse(CONFIG_RESPONSE)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_ENROL))
                .then(() => {
                    let newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_ENROL]).toBe(CONFIG_RESPONSE.object);

                    rootComponent = rootComponent.update();
                    component = findComponent(rootComponent, 'Enrolment');
                    const loginInformationComponent = findByTestAttr(component, 'loginInformationComponent');
                    expect(loginInformationComponent.length).toBe(1);

                    const thirdPartyLogin = findByTestAttr(component, 'thirdPartyLogin');
                    expect(thirdPartyLogin.length).toBe(1);

                    const fbLogin = findByTestAttr(component, 'fbLogin');
                    expect(fbLogin.length).toBe(1);
                    fbLogin.simulate('click')

                    const googleLogin = findByTestAttr(component, 'googleLogin');
                    expect(googleLogin.length).toBe(1);
                    googleLogin.simulate('click')
                })
        });
    })
    
    it('enrolment: Successfully render index page and submit form in singleStep', () => {
        setReferenceUrl()
        component.setState({
            referenceMembershipNumber: "IM0008010415"
        })
        window.sessionStorage.setItem(SESSION_STORAGE_COMPANY_CODE, "IBS")
        window.sessionStorage.setItem(SESSION_STORAGE_PROGRAM_CODE, "PRG14")

        rootComponent = rootComponent.update();
        component = findComponent(rootComponent, 'Enrolment');
        const enrolmentComponent = findByTestAttr(component, 'enrolmentComponent');
        expect(enrolmentComponent.length).toBe(1);

        mockServiceResponse(CONFIG_RESPONSE)
        return ReactTestUtils.act(() => {
            return store.dispatch(fetchConfiguration(CONFIG_SECTION_ENROL))
                .then(() => {
                    let newState = store.getState();
                    expect(newState.configurationReducer[CONFIG_SECTION_ENROL]).toBe(CONFIG_RESPONSE.object);

                    mockServiceResponse(LOGIN_CONFIG)
                    return ReactTestUtils.act(() => {
                        return store.dispatch(fetchConfiguration(CONFIG_SECTION_LOGIN))
                            .then(() => {
                                newState = store.getState()
                                expect(newState.configurationReducer[CONFIG_SECTION_LOGIN]).toBe(LOGIN_CONFIG.object);
                                rootComponent = rootComponent.update();
                                component = findComponent(rootComponent, 'Enrolment');

                                const btnEnrollFail = findByTestAttr(component, 'btnEnroll');
                                expect(btnEnrollFail.length).toBe(1);
                                btnEnrollFail.simulate('click')

                                const loginInformationComponent = findByTestAttr(component, 'loginInformationComponent');
                                expect(loginInformationComponent.length).toBe(1);

                                const loginFields = findByTestAttr(loginInformationComponent, 'loginFields');
                                expect(loginFields.length).toBe(3);

                                const memberPin = findByTestAttr(loginInformationComponent, 'memberPin');
                                expect(memberPin.length).toBe(1);
                                memberPin.simulate('change', { target: { value: "4321", classList: { value: "test" } } })

                                const password = findByTestAttr(loginInformationComponent, 'password');
                                expect(password.length).toBe(1);
                                password.simulate('change', { target: { value: "Pwd@1234", classList: { value: "test" } } })

                                const cPassword = findByTestAttr(loginInformationComponent, 'confirmPassword');
                                expect(cPassword.length).toBe(1);
                                cPassword.simulate('change', { target: { value: "Pwd@1234", classList: { value: "test" } } })

                                const personalInformationComponent = findByTestAttr(component, 'personalInformationComponent');
                                expect(personalInformationComponent.length).toBe(1);

                                const title = findByTestAttr(personalInformationComponent, 'title');
                                expect(title.length).toBe(1);
                                title.simulate('change', { target: { value: "M", classList: { value: "test" } } })

                                const firstName = findByTestAttr(personalInformationComponent, 'firstName');
                                expect(firstName.length).toBe(1);
                                firstName.simulate('change', { target: { value: "tester", classList: { value: "test" } } })

                                const lastName = findByTestAttr(personalInformationComponent, 'lastName');
                                expect(lastName.length).toBe(1);
                                lastName.simulate('change', { target: { value: "tester", classList: { value: "test" } } })

                                const memberNationality = findByTestAttr(personalInformationComponent, 'memberNationality');
                                expect(memberNationality.length).toBe(1);
                                memberNationality.simulate('change', { target: { value: "IN", classList: { value: "test" } } })

                                const countryOfResidence = findByTestAttr(personalInformationComponent, 'countryOfResidence');
                                expect(countryOfResidence.length).toBe(1);
                                countryOfResidence.simulate('change', { target: { value: "IN", classList: { value: "test" } } })

                                const preferredLanguage = findByTestAttr(personalInformationComponent, 'preferredLanguage');
                                expect(preferredLanguage.length).toBe(1);
                                preferredLanguage.simulate('change', { target: { value: "EN", classList: { value: "test" } } })

                                const dob = findByTestAttr(personalInformationComponent, 'dob');
                                expect(dob.length).toBe(1);
                                dob.simulate('change', { target: { value: "1990-07-07", classList: { value: "test" } } })

                                const gender = findByTestAttr(personalInformationComponent, 'gender');
                                expect(gender.length).toBe(1);
                                gender.simulate('change', { target: { value: "M", classList: { value: "test" } } })

                                const emailAddress = findByTestAttr(personalInformationComponent, 'emailAddress');
                                expect(emailAddress.length).toBe(1);
                                emailAddress.simulate('change', { target: { value: "test@mailinator.com", classList: { value: "test" } } })

                                const mobileISDCode = findByTestAttr(personalInformationComponent, 'mobileISDCode');
                                expect(mobileISDCode.length).toBe(1);
                                mobileISDCode.simulate('change', { target: { value: "+91", classList: { value: "test" } } })

                                const mobileNumber = findByTestAttr(personalInformationComponent, 'mobileNumber');
                                expect(mobileNumber.length).toBe(1);
                                mobileNumber.simulate('change', { target: { value: "1234567890", classList: { value: "test" } } })

                                const contactDetailsComponent = findByTestAttr(component, 'contactDetailsComponent');
                                expect(contactDetailsComponent.length).toBe(1);

                                const address1 = findByTestAttr(contactDetailsComponent, 'address1');
                                expect(address1.length).toBe(1);
                                address1.simulate('change', { target: { value: "address1", classList: { value: "test" } } })

                                const address2 = findByTestAttr(contactDetailsComponent, 'address2');
                                expect(address2.length).toBe(1);
                                address2.simulate('change', { target: { value: "address2", classList: { value: "test" } } })

                                const zip = findByTestAttr(contactDetailsComponent, 'zip');
                                expect(zip.length).toBe(1);
                                zip.simulate('change', { target: { value: "122131", classList: { value: "test" } } })

                                const phoneISDCode = findByTestAttr(contactDetailsComponent, 'phoneISDCode');
                                expect(phoneISDCode.length).toBe(1);
                                phoneISDCode.simulate('change', { target: { value: "+91", classList: { value: "test" } } })

                                const phone = findByTestAttr(contactDetailsComponent, 'phone');
                                expect(phone.length).toBe(1);
                                phone.simulate('change', { target: { value: "12213100", classList: { value: "test" } } })

                                const companyInformationComponent = findByTestAttr(component, 'companyInformationComponent');
                                expect(companyInformationComponent.length).toBe(1);

                                const companyName = findByTestAttr(companyInformationComponent, 'companyName');
                                expect(companyName.length).toBe(1);
                                companyName.simulate('change', { target: { value: "companyName", classList: { value: "test" } } })

                                const jobTitle = findByTestAttr(companyInformationComponent, 'jobTitle');
                                expect(jobTitle.length).toBe(1);
                                jobTitle.simulate('change', { target: { value: "jobTitle", classList: { value: "test" } } })

                                const companyPhone = findByTestAttr(companyInformationComponent, 'companyPhone');
                                expect(companyPhone.length).toBe(1);
                                companyPhone.simulate('change', { target: { value: "213213213", classList: { value: "test" } } })

                                const businessEmail = findByTestAttr(companyInformationComponent, 'businessEmail');
                                expect(businessEmail.length).toBe(1);
                                businessEmail.simulate('change', { target: { value: "businessEmail@test.com", classList: { value: "test" } } })

                                const agreeTermsComponent = findByTestAttr(component, 'agreeTermsComponent');
                                expect(agreeTermsComponent.length).toBe(1);

                                const agreeTerms = findByTestAttr(agreeTermsComponent, 'agreeTerms');
                                expect(agreeTerms.length).toBe(1);
                                agreeTerms.simulate('change', { target: { value: true, classList: { value: "test" } } })

                                const privacyPolicy = findByTestAttr(agreeTermsComponent, 'privacyPolicy');
                                expect(privacyPolicy.length).toBe(1);
                                privacyPolicy.simulate('change', { target: { value: true, classList: { value: "test" } } })

                                const thirdParty = findByTestAttr(agreeTermsComponent, 'thirdPartyPolicy');
                                expect(thirdParty.length).toBe(1);
                                thirdParty.simulate('change', { target: { value: true, classList: { value: "test" } } })

                                const marketingAd = findByTestAttr(agreeTermsComponent, 'marketingAdvt');
                                expect(marketingAd.length).toBe(1);
                                marketingAd.simulate('change', { target: { value: true, classList: { value: "test" } } })

                                const agreeAll = findByTestAttr(agreeTermsComponent, 'agreeAll');
                                expect(agreeAll.length).toBe(1);
                                agreeAll.simulate('change', { target: { value: true, classList: { value: "test" } } })

                                const btnEnroll = findByTestAttr(component, 'btnEnroll');
                                expect(btnEnroll.length).toBe(1);
                                btnEnroll.simulate('click')
                                mockServiceResponse(ENROL_SUCCESS, 200);
                                return ReactTestUtils.act(() => {
                                    return store.dispatch(enrolment({ "test": "test" }, { loading: "true", divId: ID_SPINNER_PROCEED_TO_PAY }))
                                        .then(() => {
                                            newState = store.getState();
                                            expect(newState.enrolment.enrolmentData).toBe(ENROL_SUCCESS);
                                        })
                                });
                            })
                    })

                })
        });
    })
})

const CONFIG_RESPONSE = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "section": "enrol", "companyCode": "IBS", "programCode": "PRG14", "activationType": "singleStep", "defaults": { "membershipStatus": "A", "operationFlag": "I" }, "password": { "pattern": "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&.,{}()?-_=+<>*!^/]).{8,20})" }, "dynamicAttributes": { "enrol": [{"attributeMapping":"password"}], "activation": [] }, "accountStatus": "A", "enrolmentSource": "W", "membershipType": "I", "addressTypes": ["H", "B"], "memberReferralType": "M", "ui": { "isLayoutSequential": true, "request": { "additionalMapping": [{ "name": ["firstName", "lastName"], "path": "object.memberAccount.memberProfile.individualInfo.displayName" }, { "name": ["dynamicAttributes"], "path": "object.memberAccount.memberDynamicAttributes" }] }, "layout": { "order": ["loginInfo", "personalInfo", "contactInfo", "companyInfo", "activation", "preferredCommunication", "agreeTerms"], "elements": { "loginInfo": { "fields": [{ "name": "memberPin", "id": "id-member-pin", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.pin", "validation": [{ "pattern": "^[0-9]{4}$", "customMessageId": "enrolment.form.memberPin" }] }, { "name": "password", "id": "id-password", "visibility": true, "isRequired": true, "validation": [{ "pattern": "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$", "customMessageId": "enrolment.form.password" }] }, { "name": "confirmPassword", "id": "id-confirm-password", "path": "object.memberAccount.memberProfile.customerPassword", "visibility": true, "isRequired": true, "validation": [{ "pattern": "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$", "customMessageId": "enrolment.form.confirmPassword" }, { "pattern": "^[password]$", "fields": ["password"], "customMessageId": "enrolment.form.passwordMismatch" }] }] }, "personalInfo": { "fields": [{ "name": "firstName", "id": "id-first-name", "additional": [{ "id": "id-title", "name": "title", "type": "lov", "source": "master", "values": [{ "key": "M", "value": "Male" }, { "key": "F", "value": "Female" }], "sourceKey": "titleMaster", "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.title", "validation": [{ "pattern": "^[a-zA-Z]{1,20}$", "customMessageId": "enrolment.form.title" }] }], "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.givenName", "validation": [{ "pattern": "[ a-zA-Z]{1,20}$", "customMessageId": "enrolment.form.firstName" }] }, { "name": "lastName", "id": "id-last-name", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.familyName", "validation": [{ "pattern": "[ a-zA-Z]{1,20}$", "customMessageId": "enrolment.form.lastName" }] }, { "name": "memberNationality", "id": "id-member-nationality", "type": "lov", "source": "master", "sourceKey": "countryMaster", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.memberNationality", "validation": [{ "pattern": "[A-Z]{2}$", "customMessageId": "form.memberNationality.errorMessage" }] }, { "name": "countryOfResidence", "id": "id-country-of-residence", "type": "lov", "source": "master", "sourceKey": "countryMaster", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.countryOfResidence", "validation": [{ "pattern": "[A-Z]{2}$", "customMessageId": "form.countryOfResidence.errorMessage" }] }, { "name": "preferredLanguage", "id": "id-preferred-language", "type": "lov", "source": "master", "sourceKey": "languageMaster", "path": "object.memberAccount.memberProfile.individualInfo.preferredLanguage", "visibility": true, "isRequired": true, "validation": [{ "pattern": "[A-Z]{2}$", "customMessageId": "enrolment.form.preferredLanguage" }] }, { "name": "dob", "id": "id-dob", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.dateOfBirth", "validation": [{ "pattern": "([12]\\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))", "customMessageId": "enrolment.form.dob" }] }, { "name": "gender", "id": "id-gender", "type": "lov", "source": "default", "sourceKey": "gender", "path": "object.memberAccount.memberProfile.individualInfo.gender", "visibility": true }, { "name": "emailAddress", "id": "id-email-id", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].emailAddress", "validation": [{ "pattern": "\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$", "customMessageId": "enrolment.form.emailAddress" }] }, { "name": "mobileNumber", "id": "id-mobile-number", "additional": [{ "id": "id-isd-code", "name": "mobileISDCode", "type": "lov", "source": "master", "sourceKey": "countryMaster", "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].mobileISDCode", "isRequired": true, "validation": [{ "pattern": "(\\+?\\d{1,3}|\\d{1,4})$", "customMessageId": "enrolment.form.isdCode" }] }], "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].mobileNumber", "validation": [{ "pattern": "\\d+$", "customMessageId": "enrolment.form.mobileNumber" }] }] }, "contactInfo": { "fields": [{ "name": "address1", "id": "id-address-1", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].addressLine1" }, { "name": "address2", "id": "id-address-2", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].addressLine2" }, { "name": "country", "id": "id-country", "type": "lov", "source": "master", "sourceKey": "countryMaster", "visibility": true, "isRequired": false, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].country", "validation": [{ "pattern": "[A-Z]{2}$", "customMessageId": "form.country.errorMessage" }] }, { "name": "zip", "id": "id-zip", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].zipCode" }, { "name": "phone", "id": "id-phone", "additional": [{ "id": "id-phone-isd-code", "name": "phoneISDCode", "type": "lov", "source": "master", "sourceKey": "countryMaster", "isRequired": false, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].phoneISDCode", "validation": [{ "pattern": "(\\+?\\d{1,3}|\\d{1,4})$", "customMessageId": "enrolment.form.phoneIsdCode" }] }], "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].phoneNumber", "visibility": true }] }, "companyInfo": { "fields": [{ "name": "companyName", "id": "id-company-name", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.companyName" }, { "name": "jobTitle", "id": "id-job-title", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.designation" }, { "name": "companyAddress", "id": "id-company-address", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[1].addressLine1" }, { "name": "companyPhone", "id": "id-company-phone", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[1].phoneNumber", "additional": [{ "id": "id-company-phone-isd-code", "name": "companyPhoneISDCode", "type": "lov", "source": "master", "sourceKey": "countryMaster", "isRequired": false, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[1].phoneISDCode", "validation": [{ "pattern": "(\\+?\\d{1,3}|\\d{1,4})$", "customMessageId": "enrolment.form.companyPhoneIsdCode" }] }] }, { "name": "businessEmail", "id": "id-business-email", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[1].emailAddress", "validation": [{ "pattern": "\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$", "customMessageId": "enrolment.form.emailAddress" }] }] }, "agreeTerms": { "fields": [{ "name": "agreeTerms", "id": "id-agree-terms", "visibility": true, "isRequired": true, "validation": [{ "pattern": "^(true)$", "customMessageId": "enrolment.form.termsOfUse" }] }, { "name": "privacyPolicy", "id": "id-agree-privacy-policy", "visibility": true, "isRequired": true, "validation": [{ "pattern": "^(true)$", "customMessageId": "enrolment.form.privacyPolicy" }] }, { "name": "thirdPartyPolicy", "id": "id-third-party-policy", "visibility": true }, { "name": "marketingAdvt", "id": "id-marketing-advt", "visibility": true }, { "name": "agreeAll", "id": "id-agree-all", "visibility": true }] }, "preferredCommunication": { "fields": [{ "name": "preferredAddress", "id": "id-preferred-address", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.preferredAddress", "source": "values", "defaultValue": "H", "values": [{ "key": "H", "value": "Home" }, { "key": "B", "value": "Business" }] }, { "name": "preferredEmailAddress", "id": "id-preferred-emailAddress", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.preferredEmailAddress", "source": "values", "defaultValue": "H", "values": [{ "key": "H", "value": "Home" }, { "key": "B", "value": "Business" }] }, { "name": "preferredPhoneNumber", "id": "id-preferred-phoneNumber", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.preferredPhoneNumber", "source": "values", "defaultValue": "HP", "values": [{ "key": "HP", "value": "Home" }, { "key": "BP", "value": "Business" }] }] } } } } } }
const ENROL_FAIL = { "statuscode": "500", "statusMessage": "FAILURE", "error": { "code": "500", "type": "INTERNAL_SERVER_ERROR", "message": "Enrol member failed", "errorDetails": [{ "message": "Duplicate member profile exists" }] } }
const ENROL_SUCCESS = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "memberActivityStatus": { "companyCode": "IBS", "programCode": "PRG14", "membershipNumber": "IM0008010137", "accountStatus": "A", "activityNumber": "ACT3224", "activityType": "ME", "activityName": "ENROLLMENT", "activityStatus": "P", "activityCode": "ME", "pointDetails": [], "tiercode": "100" }, "pointDetail": [] } }
const LOGIN_CONFIG = { "statuscode": "200", "statusMessage": "SUCCESS", "object": { "section": "login", "companyCode": "IBS", "programCode": "PRG14", "loginTypes": ["userId", "email", "membershipNumber"], "socialLoginTypes": ["facebook", "google", "twitter"], "ui": { "order": ["loginCard"], "defaultLoginTypes": "membershipNumber", "clientId": "auth-channel", "secret": "_DHFHSGDSFDSDAQ", "rememberMeExpiresDays": 30, "maxLoginAttempt": 3, "secretKey": "487439fc-27ac-446e-96f7-2cd9d5f8b73f", "layout": { "elements": { "loginCard": { "fields": [{ "name": "userId", "loginType": "userId", "id": "id_user_id", "visibility": true, "isRequired": true, "validation": { "pattern": "[a-zA-Z0-9]{5,20}", "customMessageId": "login.message.enter_user_id" } }, { "name": "preferredEmail", "loginType": "email", "id": "id_email_id", "visibility": true, "isRequired": true, "validation": { "pattern": "\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$", "customMessageId": "login.message.enter_valid_email" } }, { "name": "membershipNumber", "toUpper": true, "loginType": "membershipNumber", "id": "id_mem_id", "visibility": true, "isRequired": true, "validation": { "pattern": "[a-zA-Z0-9]{6,15}", "customMessageId": "login.message.enter_valid_mem_id" } }, { "name": "customerPassword", "id": "id-psw", "visibility": true, "isRequired": true, "type": "password", "validation": { "pattern": "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$", "customMessageId": "login.message.enter_valid_password" } }, { "name": "rememberMe", "id": "id-remember-me", "visibility": true }, { "name": "forgotPassword", "id": "id-forgot-password", "visibility": true }, { "name": "loginBtn", "id": "id-login-btn", "visibility": true }, { "name": "joinNow", "id": "id-join-now", "visibility": true }, { "name": "seperator", "id": "id-seperator", "visibility": true }, { "name": "socialLogin", "id": "id-social-login", "visibility": true }] } } } } } }
const LOGIN_SUCCESS = { "success": true, "message": "Login Successful", "errors": null, "details": { "cliams": { "sub": "IM0008010137", "provider": null, "name": "Ajmal", "exp": 1600860730, "userId": "IM0008010137", "userDetails": { "membershipNumber": "IM0008010137", "accountStatus": "A", "preferredEmailAddress": "ps-test-001@loyalty.com", "membershipType": "I", "preferredLanguage": "EN", "tier": "100", "tierFromDate": "22-Sep-2020", "customerNumber": "6219" }, "iat": 1600774330, "email": "ps-test-001@loyalty.com" } } }
const CONFIG_TWO_STEP ={ "statuscode": "200", "statusMessage": "SUCCESS", "object": { "section": "enrol", "companyCode": "IBS", "programCode": "PRG14", "activationType": "twoStep", "defaults": { "membershipStatus": "A", "operationFlag": "I" }, "password": { "pattern": "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&.,{}()?-_=+<>*!^/]).{8,20})" }, "dynamicAttributes": { "enrol": [{"attributeMapping":"password"}], "activation": [] }, "accountStatus": "A", "enrolmentSource": "W", "membershipType": "I", "addressTypes": ["H", "B"], "memberReferralType": "M", "ui": { "isLayoutSequential": true, "request": { "additionalMapping": [{ "name": ["firstName", "lastName"], "path": "object.memberAccount.memberProfile.individualInfo.displayName" }, { "name": ["dynamicAttributes"], "path": "object.memberAccount.memberDynamicAttributes" }] }, "layout": { "order": ["loginInfo", "personalInfo", "contactInfo", "companyInfo", "activation", "preferredCommunication", "agreeTerms"], "elements": { "loginInfo": { "fields": [{ "name": "memberPin", "id": "id-member-pin", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.pin", "validation": [{ "pattern": "^[0-9]{4}$", "customMessageId": "enrolment.form.memberPin" }] }, { "name": "password", "id": "id-password", "visibility": true, "isRequired": true, "validation": [{ "pattern": "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$", "customMessageId": "enrolment.form.password" }] }, { "name": "confirmPassword", "id": "id-confirm-password", "path": "object.memberAccount.memberProfile.customerPassword", "visibility": true, "isRequired": true, "validation": [{ "pattern": "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,20}$", "customMessageId": "enrolment.form.confirmPassword" }, { "pattern": "^[password]$", "fields": ["password"], "customMessageId": "enrolment.form.passwordMismatch" }] }] }, "personalInfo": { "fields": [{ "name": "firstName", "id": "id-first-name", "additional": [{ "id": "id-title", "name": "title", "type": "lov", "source": "master", "values": [{ "key": "M", "value": "Male" }, { "key": "F", "value": "Female" }], "sourceKey": "titleMaster", "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.title", "validation": [{ "pattern": "^[a-zA-Z]{1,20}$", "customMessageId": "enrolment.form.title" }] }], "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.givenName", "validation": [{ "pattern": "[ a-zA-Z]{1,20}$", "customMessageId": "enrolment.form.firstName" }] }, { "name": "lastName", "id": "id-last-name", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.familyName", "validation": [{ "pattern": "[ a-zA-Z]{1,20}$", "customMessageId": "enrolment.form.lastName" }] }, { "name": "memberNationality", "id": "id-member-nationality", "type": "lov", "source": "master", "sourceKey": "countryMaster", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.memberNationality", "validation": [{ "pattern": "[A-Z]{2}$", "customMessageId": "form.memberNationality.errorMessage" }] }, { "name": "countryOfResidence", "id": "id-country-of-residence", "type": "lov", "source": "master", "sourceKey": "countryMaster", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.countryOfResidence", "validation": [{ "pattern": "[A-Z]{2}$", "customMessageId": "form.countryOfResidence.errorMessage" }] }, { "name": "preferredLanguage", "id": "id-preferred-language", "type": "lov", "source": "master", "sourceKey": "languageMaster", "path": "object.memberAccount.memberProfile.individualInfo.preferredLanguage", "visibility": true, "isRequired": true, "validation": [{ "pattern": "[A-Z]{2}$", "customMessageId": "enrolment.form.preferredLanguage" }] }, { "name": "dob", "id": "id-dob", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.dateOfBirth", "validation": [{ "pattern": "([12]\\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))", "customMessageId": "enrolment.form.dob" }] }, { "name": "gender", "id": "id-gender", "type": "lov", "source": "default", "sourceKey": "gender", "path": "object.memberAccount.memberProfile.individualInfo.gender", "visibility": true }, { "name": "emailAddress", "id": "id-email-id", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].emailAddress", "validation": [{ "pattern": "\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$", "customMessageId": "enrolment.form.emailAddress" }] }, { "name": "mobileNumber", "id": "id-mobile-number", "additional": [{ "id": "id-isd-code", "name": "mobileISDCode", "type": "lov", "source": "master", "sourceKey": "countryMaster", "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].mobileISDCode", "isRequired": true, "validation": [{ "pattern": "(\\+?\\d{1,3}|\\d{1,4})$", "customMessageId": "enrolment.form.isdCode" }] }], "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].mobileNumber", "validation": [{ "pattern": "\\d+$", "customMessageId": "enrolment.form.mobileNumber" }] }] }, "contactInfo": { "fields": [{ "name": "address1", "id": "id-address-1", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].addressLine1" }, { "name": "address2", "id": "id-address-2", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].addressLine2" }, { "name": "country", "id": "id-country", "type": "lov", "source": "master", "sourceKey": "countryMaster", "visibility": true, "isRequired": false, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].country", "validation": [{ "pattern": "[A-Z]{2}$", "customMessageId": "form.country.errorMessage" }] }, { "name": "zip", "id": "id-zip", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].zipCode" }, { "name": "phone", "id": "id-phone", "additional": [{ "id": "id-phone-isd-code", "name": "phoneISDCode", "type": "lov", "source": "master", "sourceKey": "countryMaster", "isRequired": false, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].phoneISDCode", "validation": [{ "pattern": "(\\+?\\d{1,3}|\\d{1,4})$", "customMessageId": "enrolment.form.phoneIsdCode" }] }], "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[0].phoneNumber", "visibility": true }] }, "companyInfo": { "fields": [{ "name": "companyName", "id": "id-company-name", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.companyName" }, { "name": "jobTitle", "id": "id-job-title", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.designation" }, { "name": "companyAddress", "id": "id-company-address", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[1].addressLine1" }, { "name": "companyPhone", "id": "id-company-phone", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[1].phoneNumber", "additional": [{ "id": "id-company-phone-isd-code", "name": "companyPhoneISDCode", "type": "lov", "source": "master", "sourceKey": "countryMaster", "isRequired": false, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[1].phoneISDCode", "validation": [{ "pattern": "(\\+?\\d{1,3}|\\d{1,4})$", "customMessageId": "enrolment.form.companyPhoneIsdCode" }] }] }, { "name": "businessEmail", "id": "id-business-email", "visibility": true, "path": "object.memberAccount.memberProfile.individualInfo.memberContactInfos[1].emailAddress", "validation": [{ "pattern": "\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$", "customMessageId": "enrolment.form.emailAddress" }] }] }, "agreeTerms": { "fields": [{ "name": "agreeTerms", "id": "id-agree-terms", "visibility": true, "isRequired": true, "validation": [{ "pattern": "^(true)$", "customMessageId": "enrolment.form.termsOfUse" }] }, { "name": "privacyPolicy", "id": "id-agree-privacy-policy", "visibility": true, "isRequired": true, "validation": [{ "pattern": "^(true)$", "customMessageId": "enrolment.form.privacyPolicy" }] }, { "name": "thirdPartyPolicy", "id": "id-third-party-policy", "visibility": true }, { "name": "marketingAdvt", "id": "id-marketing-advt", "visibility": true }, { "name": "agreeAll", "id": "id-agree-all", "visibility": true }] }, "preferredCommunication": { "fields": [{ "name": "preferredAddress", "id": "id-preferred-address", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.preferredAddress", "source": "values", "defaultValue": "H", "values": [{ "key": "H", "value": "Home" }, { "key": "B", "value": "Business" }] }, { "name": "preferredEmailAddress", "id": "id-preferred-emailAddress", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.preferredEmailAddress", "source": "values", "defaultValue": "H", "values": [{ "key": "H", "value": "Home" }, { "key": "B", "value": "Business" }] }, { "name": "preferredPhoneNumber", "id": "id-preferred-phoneNumber", "visibility": true, "isRequired": true, "path": "object.memberAccount.memberProfile.individualInfo.preferredPhoneNumber", "source": "values", "defaultValue": "HP", "values": [{ "key": "HP", "value": "Home" }, { "key": "BP", "value": "Business" }] }] } } } } } }