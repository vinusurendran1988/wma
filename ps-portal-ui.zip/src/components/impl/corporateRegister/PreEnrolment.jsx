import parse from 'html-react-parser';
import React, { Component } from 'react';
import { withTranslation } from "react-i18next";
import { connect } from 'react-redux';
import AlertBox from '../../common/components/fieldbank/AlertBox';
import Button from "../../common/components/fieldbank/Button";
import TextField from "../../common/components/fieldbank/TextField";
import { resetError, setError } from '../../common/middleware/redux/commonAction';
import { getApiErrorMessage, isPatternMatch, withSuspense, isEmployee } from '../../common/utils';
import { getItemFromBrowserStorage, setItemToBrowserStorage } from '../../common/utils/storage.utils';
import { validateBusinessNumber } from './enrolment/action';
import Custommessage from "../../common/components/custommessage";
import { getCompanyData } from "../../ui/subscription/Services/CommonUtils"
import { CONFIG_SECTION_ENROL } from '../../common/utils/Constants';
class PreEnrolment extends Component {
    constructor(props) {
        super(props)
        this.state = {
            validInput: false,
            businessNo: "",
            apiResponse: {},
            errorMessage : ""
        }
    }

    componentDidUpdate(prevProps) {
        const { validatedBusinessNumberDetails } = this.props
        if (JSON.stringify(validatedBusinessNumberDetails) != JSON.stringify(prevProps.validatedBusinessNumberDetails)) {
            if (validatedBusinessNumberDetails.statuscode == "200") {
                this.props.toProceed()
            }
            else if (validatedBusinessNumberDetails.error) {
                this.setState({
                    apiResponse: {
                        type: "danger",
                        message: getApiErrorMessage(validatedBusinessNumberDetails.error),
                    }
                })
            }

        }
    }
    proceed = () => {
        if (isPatternMatch("^[a-zA-Z0-9]{1,20}$", this.state.businessNo)) {
            setItemToBrowserStorage("businessNo", this.state.businessNo)
            const request = {
                "object": {
                    "companyCode": getItemFromBrowserStorage("companyCode"),
                    "programCode": getItemFromBrowserStorage("defaultProgramCode"),
                    "countryCode": getItemFromBrowserStorage("companyCode"),
                    "companyRegisterNumber": this.state.businessNo
                }
            }
            this.props.validateBusinessNumber(request, "validateBusinessNumber")
        }
        else {
            this.props.setError(["form.businessNo.errorMessage.invalid"]);
        }
    }

    handleChange = (event) => {
        this.setState({ businessNo: event, apiResponse : {} }, () => {
            if (isPatternMatch("^[a-zA-Z0-9]{1,30}$", this.state.businessNo)) {
                this.setState({ validInput: true, errorMessage : ""})
                
            }
            else {
                this.setState({ validInput: false, errorMessage : this.props.t("form.businessNo.errorMessage.invalid") })
            }
        })

    }
    render() {
        const { t, error, profileData} = this.props
        const { apiResponse, errorMessage } = this.state
        let isDisableEmployee = false;
        let compData = {};
        if (profileData && 'object' in profileData) {
            isDisableEmployee = isEmployee(profileData.object.memberAccount.memberDynamicAttributes);
            compData = getCompanyData(profileData.object.memberAccount.memberDynamicAttributes);
        }
        
        return (
            <div className="page__enrollment">
                <div className="row">
                    <div className="col-12 mb-5">
                        <div className="form-row">
                            <div className="col-9">
                                <h1> {t('enrolment.corporateTitle')}</h1>
                            </div>
                            {isDisableEmployee && <Custommessage
                                type={"warning"}
                                message={[parse(`You cannot register a company as your Airpoints account is are already link to company <b>${Object.keys(compData).includes("companyName") ? compData.companyName : ""}</b>.`)]}
                                canTranslate={false} />}
                            <div className="col-9">
                                <span> {parse(t('form.preEnrolment.desc'))}</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className={`col-lg-6`}>
                        {apiResponse && Object.keys(apiResponse).length > 0 &&
                            <AlertBox type={apiResponse.type} message={apiResponse.message[0]} />}
                        <div className="form-row" data-test="enrollmentForm">
                            <div className="row mb-5">
                                <div className="col-lg-12">
                                    <TextField
                                        label={t('form.businessNo.label')}
                                        isRequired={true}
                                        id="businessNo"
                                        enabled={!isDisableEmployee}
                                        type="text"
                                        onChange={(value) => this.handleChange(value)}
                                        error={error}
                                        errorMessage={errorMessage}
                                    />
                                </div>
                            </div>
                            <div className="btn-wrap btn-wrap--grp">
                                <Button
                                    className="btn btn-primary"
                                    handleOnClick={() => this.proceed()
                                    }
                                    enabled={this.state.validInput}
                                    id={"validateBusinessNumber"}
                                    testIdentifier="btnEnrollment"
                                    label={t("form.buttons.continue")} />
                            </div>
                        </div>
                    </div>
                </div>
            </div>);
    }
}

function mapStateToProps(state) {
    return {
        error: state.commonErrorReducer.error,
        validatedBusinessNumberDetails: state.companyRegReducer.validatedBusinessNumberDetails,
        profileData: state.profileDataReducer.profileData
    }
}

const mapDispatchToProps = {
    resetError,
    setError,
    validateBusinessNumber
}


export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(PreEnrolment)));
