import parse from 'html-react-parser';
import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import { fetchCurrentLoginUserData, fetchNewToken, fetchProfileData } from '../../../common/middleware/redux/commonAction';
import { withSuspense } from '../../../common/utils';
import { BROWSER_STORAGE_KEY_TOKEN, setItemToBrowserStorage } from '../../../common/utils/storage.utils';
import { NAVIGATE_COMPANY_PROFILE } from '../../../common/utils/urlConstants';
import './style.scss';

/**
 * PostEnrolment className.
 * @description For activation after enrolment.
 * @author Amrutha
 */
class PostEnrolmentCorporate extends Component {
    componentDidMount() {
        window.scrollTo(0, 0)
        this.props.fetchNewToken()

    }
    componentDidUpdate(prevProps) {
        if (JSON.stringify(prevProps.newToken) != JSON.stringify(this.props.newToken)) {
            console.log("new token ------------------------------ ", this.props.newToken);

        }
    }
    goToAddPage = () => {
            this.props.fetchCurrentLoginUserData()
            this.props.fetchProfileData()
            window.location.href = "#" + NAVIGATE_COMPANY_PROFILE
    }
    render() {
        const { t } = this.props

        return (
            <main role="main" id="content" className="container member-plan cart-view">
                <div>
                    <h1>{t('corpReg.header')}</h1>
                </div>
                <div class="alert alert-success hide-fontawesome" role="alert">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M6.99986 14.1727L3.53319 10.706C3.14291 10.3158 2.51014 10.3158 2.11986 10.706C1.72958 11.0963 1.72958 11.7291 2.11986 12.1194L6.29275 16.2923C6.68328 16.6828 7.31644 16.6828 7.70697 16.2923L18.2932 5.70604C18.6835 5.31576 18.6835 4.68299 18.2932 4.29271C17.9029 3.90243 17.2701 3.90243 16.8799 4.29271L6.99986 14.1727Z" fill="white" />
                        <mask id="mask0_6869_9148" style={{ maskType: "alpha" }} maskUnits="userSpaceOnUse" x="1" y="4" width="18" height="13">
                            <path d="M6.99986 14.1727L3.53319 10.706C3.14291 10.3158 2.51014 10.3158 2.11986 10.706C1.72958 11.0963 1.72958 11.7291 2.11986 12.1194L6.29275 16.2923C6.68328 16.6828 7.31644 16.6828 7.70697 16.2923L18.2932 5.70604C18.6835 5.31576 18.6835 4.68299 18.2932 4.29271C17.9029 3.90243 17.2701 3.90243 16.8799 4.29271L6.99986 14.1727Z" fill="white" />
                        </mask>
                        <g mask="url(#mask0_6869_9148)"> </g>
                    </svg>
                    <h5><strong>{t('corpReg.subHeader')}</strong></h5>
                    <p> {t('corpReg.success')}</p>

                </div>
                <div className=" latamClub">
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="row no-gutters widgets--membership-box">
                                <div className="col-md-9">
                                    <h2>{t('corpReg.inviteHeader')}</h2>
                                    <p>
                                        {parse(t('corpReg.inviteDesc'))}
                                    </p>
                                    <div className="btn-wrap btn-wrap--grp text-left">
                                        <button type="button" className="btn btn-primary"
                                            onClick={() => this.goToAddPage()}>
                                            {t('corpReg.inviteEmployees')}
                                        </button>
                                        <button type="button" data-toggle="modal"
                                            data-target="#digital-card-modal"
                                            onClick={() => this.goToAddPage()}
                                            className="btn btn-secondary">
                                            {t('corpReg.inviteAdmin')}
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <h2>{t('corpReg.contactCenter')}</h2>
                            <p>{t('corpReg.contactCenterDesc')}</p>
                            <div className="contact--address">
                                {parse(t('corpReg.contactAddress'))}
                            </div>
                        </div>
                    </div>
                </div>
            </main>)
    }
}

function mapStateToProps(state) {
    return {
        newToken: state.currentLoginUserDataReducer.newToken
    }
}
const mapDispatchToProps = {
    fetchNewToken,
    fetchCurrentLoginUserData,
    fetchProfileData,
    
}
export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(PostEnrolmentCorporate)))
