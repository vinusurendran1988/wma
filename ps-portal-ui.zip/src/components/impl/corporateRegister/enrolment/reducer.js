import {
    ENROLMENT_DATA,
    PREAFFLIATED_DATA,
    PREAFFLIATED_ERROR,
    PREAFFILIATED_ENROLMENT_DATA,
    REGISTER_COMP,
    VALIDATE_BUSINESS_NUMBER
} from './action';

export  function setEnrolmenteData(state, action) {
    const { type, payload } = action;
    if (!state) state = {}
    switch (type) {
        case ENROLMENT_DATA:
            return {
                enrolmentData: payload
            }
        case PREAFFLIATED_DATA:
            return {
                preaffliatedData: payload
            }
        case PREAFFLIATED_ERROR:
            return {
                preaffliatedError: payload
            }
        default:
            return state;
    }

}

export default function companyRegReducer(state, action) {
    const { type, payload } = action;
    if (!state) state = {}
    switch (type) {
        case REGISTER_COMP:
            return {
                companyRegistered: payload
            }
        case VALIDATE_BUSINESS_NUMBER:
            return{
                validatedBusinessNumberDetails : payload
            }
        default:
            return state;
    }
}
