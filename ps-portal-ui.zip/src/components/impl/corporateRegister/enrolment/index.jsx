import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import { fetchMasterData } from '../../../common/middleware/redux/commonAction';
import { withSuspense } from '../../../common/utils';
import { CONFIG_SECTION_DEFAULT, CONFIG_SECTION_ENROL, CONFIG_SECTION_LOGIN } from '../../../common/utils/Constants';
import CorpRegister from './CorpRegister';
import PostEnrolmentCorporate from './PostEnrolmentCorporate';


/**
 * Enrolment class.
 * @description Registers a new user or displays activation message for an enrolled user.
 * @author Somdas M
 */
class Enrolment extends Component {

    constructor(props) {
        super(props)
        this.state = {
            activationType: 1
        }
    }

    componentDidMount() {
        // this.props.setPageInfo(this.props, { config: this.props.config, confSection: CONFIG_SECTION_ENROL })
    }

    render() {
        const { t, defaultConfig } = this.props
        return (
            <div className="page__enrollment" data-test="enrolmentComponent">
                {
                    this.state.activationType == 1 ?
                        <CorpRegister backToPreEnrolmentPage={()=>this.props.backToPreEnrolmentPage}
                            enrollSuccess={() => this.setState({ activationType: 2 })} 
                             {...this.props} /> :
                        <PostEnrolmentCorporate data={{ email: this.state.emailAddress }} />

                }
            </div>
        );
    }
}

function mapStateToProps(state) {
    return {
        config: state.configurationReducer[CONFIG_SECTION_ENROL],
        loginConfig: state.configurationReducer[CONFIG_SECTION_LOGIN],
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        masterEntityLookup: state.masterEntityDataReducer.masterEntityLookup,
        masterEntityLookupFilters: state.masterEntityDataReducer.masterEntityLookupFilters,
        currentUserData: state.currentLoginUserDataReducer.currentUserData
    }
}

const mapDispatchToProps = { fetchMasterData }

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(Enrolment)));
