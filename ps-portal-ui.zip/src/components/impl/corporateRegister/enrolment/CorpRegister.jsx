import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import AlertBox from '../../../common/components/fieldbank/AlertBox';
import Button from '../../../common/components/fieldbank/Button';
import { FIELDTYPE_CHECKBOX } from '../../../common/components/fieldbank/Constants';
import {
    fetchConfiguration, fetchDefaultUserProfileData, logOut, resetError, setError
} from '../../../common/middleware/redux/commonAction';
import { generateRequestBodyWithEmptyValue, isEmptyOrSpaces, isPatternMatch, withSuspense } from '../../../common/utils';
import {
    CONFIG_SECTION_ACCOUNT_SUMMARY, CONFIG_SECTION_DEFAULT,
    CONFIG_SECTION_ENROL,
    CONFIG_SECTION_LOGIN, CONFIG_SECTION_MEMBERCHECK, NO_OF_EMPLOYEES, TYPE_OF_INDUSTRY
} from '../../../common/utils/Constants';
import { doAdditionalMapping, findValueFromObjectByPath } from '../../../common/utils/object.utils';
import {
    BROWSER_STORAGE_KEY_COMPANY_CODE,
    BROWSER_STORAGE_KEY_PROGRAM_CODE, getItemFromBrowserStorage
} from '../../../common/utils/storage.utils';
import Section from '../../../ui/updateprofile/Section';
import { registerCompany } from './action';
import { ID_SUBMIT_BUTTON } from './Constants';
import parse from 'html-react-parser';


class CorpRegister extends Component {
    constructor(props) {
        super(props)
        this.state = {
            showWarningAndError: false,
            request: generateRequestBodyWithEmptyValue(props.config),
            companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
            programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
            errorCodes: [],
            isButtonClicked: false,
            isHavingFFNo: undefined,
            corpEnrollRequest: {},
            agreeTermsKoruCorpOne: false,
            agreeTermsKoruCorpTwo: false,
            errorMessage: "",
            commonExpiryNeeded: false
        }
    }

    componentDidMount() {
        this.props.resetError()
        if (this.state.errorCodes.length) {
            this.setState({
                errorCodes: []
            })
        }
        if (this.props.config && this.props.profileData) {
            this.invokeDoAdditionalMapping()
        }
        document.body.scrollTop = document.documentElement.scrollTop = 0
    }

    componentDidUpdate(prevProps) {
        if (JSON.stringify(prevProps.enrolmentData) != JSON.stringify(this.props.enrolmentData)) {
            if (this.props.enrolmentData && this.props.enrolmentData.statuscode == "200") {
                // this.props.postEnrolment(this.props.enrolmentData, this.state)
                this.props.enrollSuccess()
            }
            else {
                if (this.props.enrolmentData && this.props.enrolmentData.error) {
                    this.setState({ showWarningAndError: true, errorMessage: this.props.enrolmentData.error[0] })
                }
            }
            window.scrollTo(0, 0);
        }
    }

    handleRequestChange(request) {
        if (request && request.dynamicAttr) {
            if (request.dynamicAttr.commonExpiry == "Y") {
                this.setState({ commonExpiryNeeded: true })
            }
            else {
                this.setState({ commonExpiryNeeded: false })

            }
        }
        this.setState({ corpEnrollRequest: request, showWarningAndError: false })
    }

    handleErrorMessagesFromSection(codes) {
        if (!codes.length) { this.props.resetError() }
        if (JSON.stringify(codes) != JSON.stringify(this.state.errorCodes)) {
            this.setState({ errorCodes: codes })
        }
    }

    addValueToState(field, value) {
        let newState = {}
        if (field.fieldType == FIELDTYPE_CHECKBOX) {
            if (field.name == CONFIG_SECTION_MEMBERCHECK) {
                this.setState({
                    isHavingFFNo: value ? true : undefined,
                    clearDataFlag: value ? false : true
                })
            }
            if (field.childRelation) {
                field.childRelation.forEach(child => {
                    newState[child] = value
                })
            } else if (field.parentRelation) {
                newState[field.parentRelation] = true
                if (field.siblingRelation) {
                    newState[field.parentRelation] = newState[field.parentRelation] && value
                    field.siblingRelation.forEach(sibling => {
                        newState[field.parentRelation] = this.state[sibling] && newState[field.parentRelation]

                    })
                }
            }
        }
        newState[field.name] = value
        this.setState(newState)
    }

    validateWithStateVariable(field, validation, value) {
        let { pattern, fields } = validation
        let isValidationSuccess = true, canUpdateState = false
        fields.forEach((fd) => {
            const newPattern = pattern.replace("[fields]", this.state[fd])
            if (!isPatternMatch(newPattern, value)) {
                isValidationSuccess = false
            }
        })
        let { errorCodes } = this.state
        if (!isValidationSuccess) {
            if (!errorCodes.includes(validation.customMessageId)) {
                errorCodes.push(validation.customMessageId)
                canUpdateState = true
            }
        } else if (errorCodes.includes(validation.customMessageId)) {
            const index = errorCodes.indexOf(validation.customMessageId)
            if (index > -1) {
                canUpdateState = true
                errorCodes.splice(index, 1)
            }
        }
        field.error = !isValidationSuccess
        if (canUpdateState) {
            this.setState({
                errorCodes
            })
        }
        return !isValidationSuccess
    }

    findValueFromState(stateFieldName, fieldType) {
        if (fieldType == FIELDTYPE_CHECKBOX) {
            return this.state[stateFieldName] ? this.state[stateFieldName] : false
        } else {
            return this.state[stateFieldName] ? this.state[stateFieldName] : ""
        }
    }
    /**
       * Function to create response for section
       * 
       * @author Amrutha J Raj
       */
    createResponseObject = () => {
        const { profileData, validatedBusinessNumberDetails } = this.props
        let response = {
            country: "New Zealand"
        }
        if (validatedBusinessNumberDetails && validatedBusinessNumberDetails.object &&
            Object.keys(validatedBusinessNumberDetails.object).length > 0) {
            response["companyName"] = validatedBusinessNumberDetails.object.entityName
            response["businessNo"] = validatedBusinessNumberDetails.object.nzbn
        }
        if (profileData && Object.keys(profileData).length && profileData.object && profileData.object.memberAccount
            && profileData.object.memberAccount.memberProfile && profileData.object.memberAccount.memberProfile.individualInfo) {
            if (profileData.object.memberAccount.memberProfile.individualInfo.displayName) {
                response["givenName"] = profileData.object.memberAccount.memberProfile.individualInfo.displayName
            }
            else {
                response["givenName"] = profileData.object.memberAccount.memberProfile.individualInfo.givenName
            }
            response["familyName"] = profileData.object.memberAccount.memberProfile.individualInfo.familyName
        }
        return response
    }

    /**
     * Function to create request body
     * 
     * @author Amrutha J Raj
     */
    getRequestBody = () => {
        const { corpEnrollRequest } = this.state
        const { dynamicAttributes } = this.props
        let requestBody = JSON.parse(JSON.stringify(corpEnrollRequest))

        if (requestBody && requestBody.object &&
            requestBody.object.memberAccount) {
            requestBody.object.memberAccount.memberProfile.corporateInfo.companyName = "Company_" + getItemFromBrowserStorage("businessNo")
            requestBody.object.memberAccount.memberProfile.corporateInfo.companyID = getItemFromBrowserStorage("businessNo")

            let reqBodyCopy = []
            requestBody.object.memberAccount.memberDynamicAttributes = dynamicAttributes
            requestBody.object.memberAccount.memberDynamicAttributes.map(item => {
                switch (item.attributeCode) {
                    case "17": {
                        reqBodyCopy.push(item)
                        break
                    }
                    case "20": {
                        if (requestBody.object.memberAccount.memberProfile &&
                            requestBody.object.memberAccount.memberProfile.corporateInfo) {
                            item.attributeValue = requestBody.object.memberAccount.memberProfile.corporateInfo.companyName
                            reqBodyCopy.push(item)
                        }
                        break
                    }
                    case "16": {
                        if (requestBody.dynamicAttr && requestBody.dynamicAttr.commonExpiryDate) {
                            item.attributeValue = requestBody.dynamicAttr.commonExpiryDate
                            reqBodyCopy.push(item)
                        }
                        break
                    }
                    case "22": {
                        if (requestBody.dynamicAttr && requestBody.dynamicAttr.commonExpiry) {
                            item.attributeValue = requestBody.dynamicAttr.commonExpiry
                            reqBodyCopy.push(item)
                        }
                        break
                    }
                    case "23": {
                        if (requestBody.dynamicAttr && requestBody.dynamicAttr.travelMgCompName) {
                            item.attributeValue = requestBody.dynamicAttr.travelMgCompName
                            reqBodyCopy.push(item)
                        }
                        else {
                            requestBody.object.memberAccount.memberDynamicAttributes.filter((item) => item.attributeCode !== 23)
                        }
                        break
                    }
                    case "19":
                        item.attributeValue = getItemFromBrowserStorage("membershipNumber");
                        reqBodyCopy.push(item);
                        break;
                }
                return item
            })
            requestBody.object.memberAccount.memberDynamicAttributes = []
            requestBody.object.memberAccount.memberDynamicAttributes = reqBodyCopy
            if (isEmptyOrSpaces(requestBody.object.memberAccount.memberProfile.corporateInfo.industryType)) {
                requestBody.object.memberAccount.memberProfile.corporateInfo.industryType = "N"
            }
            if (isEmptyOrSpaces(requestBody.object.memberAccount.memberProfile.corporateInfo.numberOfEmployees)) {
                requestBody.object.memberAccount.memberProfile.corporateInfo.numberOfEmployees = "X"
            }
            delete requestBody["dynamicAttr"]
        }

        const isAirpointMember = this.isAirpointsOnlyMember()
        if (isAirpointMember) {
            requestBody.object.memberAccount.memberProfile.corporateInfo.nomineeDetail.memberType = "D",
                requestBody.object.memberAccount.memberProfile.corporateInfo.nomineeDetail.membershipNumber = ""
            requestBody.object.memberAccount.memberProfile.corporateInfo.nomineeDetail.customerNumber = getItemFromBrowserStorage("customerNo")
        }
        return requestBody
    }

    /**
    * Function to enroll new company 
    * 
    * @author Amrutha J Raj
    */
    companyEnroll = () => {
        const { errorCodes } = this.state
        const reqBody = this.getRequestBody()
        console.log("Final request (Corp Register) -------- ", reqBody);
        if (errorCodes.length > 0) {
            this.props.setError(errorCodes);
            window.scrollTo(0, 0)
        } else {
            this.props.resetError()
            this.props.registerCompany(reqBody, ID_SUBMIT_BUTTON)
        }
        this.setState({ showWarningAndError: true, isButtonClicked: true })

    }

    isAirpointsOnlyMember = () => {
        const { currentUserData } = this.props
        if (currentUserData && currentUserData.userDetails && currentUserData.userDetails.programs &&
            currentUserData.userDetails.programs.individualInfo) {
            let individualProgLength = currentUserData.userDetails.programs.individualInfo.length
            let airpoints = currentUserData.userDetails.programs.individualInfo.find(prog => prog.id == "arp_prg")
            if (individualProgLength == 1 && airpoints) {
                return true
            }

        }
        return false
    }

    getDisplayElements = (sectionElements, name) => {
        let section = JSON.parse(JSON.stringify(sectionElements))
        if (name == "corporateInfo") {
            if (this.state.commonExpiryNeeded) {
                if (section.fields) {
                    section.fields.map(field => {
                        if (field.name == "commonExpiryDate") {
                            field.visibility = true
                        }
                        return field
                    })
                }
            }
        }

        return section

    }

    invokeDoAdditionalMapping = () => {
        if (this.props.config && this.props.profileData) {
            this.setState({
                corpEnrollRequest: generateRequestBodyWithEmptyValue(this.props.config)
            }, () => {
                doAdditionalMapping(this, "corpEnrollRequest")
            })
        }
    }
    render() {
        const {
            errorCodes, showWarningAndError, corpEnrollRequest, errorMessage,
            agreeTermsKoruCorpOne, agreeTermsKoruCorpTwo } = this.state
        const { t, uiLayout, sections, config } = this.props;
        const isBannerRequred = config ? config.ui.isBannerRequred : true
        const template = config && config.ui && config.ui.template
        return (
            <>
                <h1> {t('enrolment.corporateTitle')}</h1>
                {showWarningAndError && errorMessage &&
                    <AlertBox type="danger" message={errorMessage} />
                }
                <div className="single-col-view">
                    {corpEnrollRequest &&
                        Object.keys(corpEnrollRequest).length > 0 &&
                        <div className="form" data-test="enrollmentForm">
                            {
                                sections && sections.map((section, i) => {
                                    return uiLayout.elements[section] && <Section
                                        key={i}
                                        id={section}
                                        displayElements={this.getDisplayElements(uiLayout.elements[section], section)}
                                        request={corpEnrollRequest}
                                        response={this.createResponseObject()}
                                        page={`${this.props.page}`}
                                        onRequestChange={(req) => this.handleRequestChange(req)}
                                        // dynamicAttributes={dynamicAttributeProperties}
                                        errorCodes={errorCodes}
                                        showWarningAndError={showWarningAndError}
                                        onErrorCodes={(codes) => this.handleErrorMessagesFromSection(codes)}
                                        addValueToState={(field, value) => this.addValueToState(field, value)}
                                        validateWithStateVariable={(field, validation, value) => this.validateWithStateVariable(field, validation, value)}
                                        findValueFromState={(stateFieldName, fieldType) => this.findValueFromState(stateFieldName, fieldType)}
                                        isButtonClicked={this.state.isButtonClicked}
                                        template={template}
                                        onClick={() => { this.props.backToPreEnrolmentPage() }}
                                    />
                                })
                            }
                            <div class='imp-list--approve'>
                                <div class="form-group">
                                    <input type="checkbox" data-test="terms-and-condition-test-data"
                                        onClick={(event) => {
                                            if (event.target.checked) {
                                                this.setState({ agreeTermsKoruCorpOne: true })
                                            }
                                            else {
                                                this.setState({ agreeTermsKoruCorpOne: false })
                                            }
                                        }} id="agree1" />
                                    <label for="agree1">{parse(t('form.agreeTermsKoruCorpOne.label'))} </label>
                                </div>
                            </div>
                            <br />
                            <div class='imp-list--approve'>
                                <div class="form-group">
                                    <input type="checkbox" data-test="terms-and-condition-test-data"
                                        onClick={(event) => {
                                            if (event.target.checked) {
                                                this.setState({ agreeTermsKoruCorpTwo: true })
                                            }
                                            else {
                                                this.setState({ agreeTermsKoruCorpTwo: false })
                                            }
                                        }} id="agree2" />
                                    <label for="agree2">{parse(t('form.agreeTermsKoruCorpTwo.label'))} </label>
                                </div>
                            </div>
                            <br />
                            <div className="col-12 btn-wrap btn-wrap--grp">
                                <Button
                                    className="btn btn-primary"
                                    enabled={agreeTermsKoruCorpOne && agreeTermsKoruCorpTwo ? true : false}
                                    handleOnClick={() => this.companyEnroll()}
                                    id={ID_SUBMIT_BUTTON}
                                    testIdentifier="btnEnrollment"
                                    label={t("enrolment.btn_sign_up_corp")} />
                            </div>
                        </div>
                    }
                </div>
            </>

        )
    }
}

function mapStateToProps(state) {
    return {
        sections: findValueFromObjectByPath(state, 'configurationReducer.enrol.ui.layout.order', []),
        uiLayout: findValueFromObjectByPath(state, 'configurationReducer.enrol.ui.layout', []),
        additionalMappings: findValueFromObjectByPath(state, 'configurationReducer.enrol.ui.request.additionalMapping', []),
        dynamicAttributes: findValueFromObjectByPath(state, 'configurationReducer.enrol.dynamicAttributes.enrol', []),
        // dynamicAttributesPath: findValueFromObjectByPath(state, 'configurationReducer.enrol.ui.dynamicAttributesPath', ""),
        error: state.commonErrorReducer.error,
        enrolmentData: state.companyRegReducer.companyRegistered,
        preaffliatedEnrolmentData: state.enrolment.preaffliatedEnrolmentData,
        preaffliatedData: state.enrolment.preaffliatedData,
        preaffliatedError: state.enrolment.preaffliatedError,
        config: state.configurationReducer[CONFIG_SECTION_ENROL],
        defaultConfig: state.configurationReducer[CONFIG_SECTION_DEFAULT],
        accountSummaryConfig: state.configurationReducer[CONFIG_SECTION_ACCOUNT_SUMMARY],
        loginConfig: state.configurationReducer[CONFIG_SECTION_LOGIN],
        profileData: state.profileDataReducer.profileData,
        validatedBusinessNumberDetails: state.companyRegReducer.validatedBusinessNumberDetails,
        currentUserData: state.currentLoginUserDataReducer.currentUserData
    }
}

const mapDispatchToProps = {
    resetError,
    fetchConfiguration,
    logOut,
    setError,
    fetchDefaultUserProfileData,
    registerCompany
}
export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(CorpRegister)));
