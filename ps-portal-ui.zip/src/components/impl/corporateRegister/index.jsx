import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import { fetchConfiguration, fetchMasterData } from '../../common/middleware/redux/commonAction';
import { generateRequestBodyWithEmptyValue, withSuspense } from '../../common/utils';
import { CONFIG_SECTION_ENROL, NO_OF_EMPLOYEES, TYPE_OF_INDUSTRY } from '../../common/utils/Constants';
import { doAdditionalMapping } from '../../common/utils/object.utils';
import { BROWSER_STORAGE_KEY_COMPANY_CODE, BROWSER_STORAGE_KEY_MEMBERSHIP_NO, BROWSER_STORAGE_KEY_PROGRAM_CODE, getItemFromBrowserStorage } from '../../common/utils/storage.utils';
import { getProfileDetails } from '../../ui/subscription/actions';
import Enrolment from './enrolment';
import PreEnrolment from './PreEnrolment';

class CorporateRegistration extends Component {
    constructor(props) {
        super(props)
        this.state = {
            toProceed: false,
            corpEnrollRequest: {},
            businessNumber: ""
        }
    }
    componentDidMount() {
        document.body.className = "theme__one view__compact";
        const { config, profileData } = this.props
        if (!config || config && Object.keys(config).length) {
            this.props.fetchConfiguration(CONFIG_SECTION_ENROL)
        }
        if (!this.props.noOfEmployees || this.props.noOfEmployees.length == 0) {
            this.props.fetchMasterData(NO_OF_EMPLOYEES, this.props.masterEntityLookup, this.props.masterEntityLookupFilters)
        }
        if (!this.props.typeOfIndustry || this.props.typeOfIndustry.length == 0) {
            this.props.fetchMasterData(TYPE_OF_INDUSTRY, this.props.masterEntityLookup, this.props.masterEntityLookupFilters)
        }
      
    }
    componentDidUpdate(prevProps) {
        const { config, profileData } = this.props
            if (JSON.stringify(prevProps.config) != JSON.stringify(this.props.config) && this.props.profileData) {
            this.invokeDoAdditionalMapping()
        }
    }
    invokeDoAdditionalMapping = () => {
        if(this.props.config && this.props.profileData){
            this.setState({
                corpEnrollRequest: generateRequestBodyWithEmptyValue(this.props.config)
            }, () => {
                doAdditionalMapping(this, "corpEnrollRequest")
            })
        }
    }

    
    render() {
        const { profileData, config } = this.props
        return (<div>
            {this.state.toProceed 
                ?
                <Enrolment page="form.enrolment.corporate"
                    backToPreEnrolmentPage={() => {
                        this.invokeDoAdditionalMapping()
                        this.setState({ toProceed: false })}
                    }
                />
                :
                <PreEnrolment page="form.enrolment.corporate"
                    toProceed={() => this.setState({ toProceed: true })}
                    config={this.props.config} />
            }

        </div>);
    }
}

function mapStateToProps(state) {
    return {
        config: state.configurationReducer[CONFIG_SECTION_ENROL],
        profileData: state.profileDataReducer.profileData,
        masterEntityLookup: state.masterEntityDataReducer.masterEntityLookup,
        masterEntityLookupFilters: state.masterEntityDataReducer.masterEntityLookupFilters,
        noOfEmployees: state.masterData[NO_OF_EMPLOYEES] ? state.masterData[NO_OF_EMPLOYEES] : [],
        typeOfIndustry: state.masterData[TYPE_OF_INDUSTRY] ? state.masterData[TYPE_OF_INDUSTRY] : [],

    }
}

const mapDispatchToProps = { fetchConfiguration, getProfileDetails,fetchMasterData }
export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(CorporateRegistration)));