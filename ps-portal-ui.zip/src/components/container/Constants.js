export const LAYOUT_ORDER_MEMBERCARD = 'memberCard'
export const LAYOUT_ORDER_USEFULLINKS = 'usefulLinkGroup'
export const LAYOUT_ORDER_FAMILYCARD = 'familyCard'