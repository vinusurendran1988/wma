import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { withSuspense } from '../common/utils'
import MemberCard from '../ui/mileagecard';
import FamilyPlanCard from '../ui/familyplan';
import MenuCard from '../ui/menu';
import {
    getFamilyMembers
} from '../common/middleware/redux/commonAction';
import { fetchConfiguration } from '../common/middleware/redux/commonAction'
import {
    CONFIG_SECTION_SUMMARY,
    CONFIG_SECTION_ACCOUNT_SUMMARY,
} from '../common/utils/Constants';
import {
    LAYOUT_ORDER_MEMBERCARD,
    LAYOUT_ORDER_USEFULLINKS,
    LAYOUT_ORDER_FAMILYCARD
} from './Constants';
import { 
    getItemFromBrowserStorage, 
    BROWSER_STORAGE_KEY_COMPANY_CODE, 
    BROWSER_STORAGE_KEY_PROGRAM_CODE, 
    BROWSER_STORAGE_KEY_MEMBERSHIP_NO
 } from '../common/utils/storage.utils';

class SidePanel extends Component {


    componentDidMount() {
        if (!this.props.familyMembers || this.props.familyMembers.length == 0) {
            const object = {
                companyCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_COMPANY_CODE),
                programCode: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_PROGRAM_CODE),
                membershipNumber: getItemFromBrowserStorage(BROWSER_STORAGE_KEY_MEMBERSHIP_NO)
            }
            this.props.getFamilyMembers({ object });
        }
        if (!this.props.accountSummaryConfig) this.props.fetchConfiguration(CONFIG_SECTION_ACCOUNT_SUMMARY)
    }

    render() {
        const { t, summaryConfig } = this.props
        return (
            <div className="col-lg-3 col-md-4 leftSidePanel d-md-block d-sm-none">
                {
                    summaryConfig &&
                    summaryConfig.ui &&
                    summaryConfig.ui.layout &&
                    summaryConfig.ui.layout.order &&
                    summaryConfig.ui.layout.order.map((layout, idx) => {
                        const config = summaryConfig.ui.layout.elements[layout]
                        const defaultValues = {
                            defaultAbsoluteIndex: summaryConfig.ui.defaultAbsoluteIndex,
                            defaultPageSize: summaryConfig.ui.defaultPageSize,
                            isBonusRequiredForAccoutnSummary: summaryConfig.ui.isBonusRequiredForAccoutnSummary
                        }
                        return {
                            [LAYOUT_ORDER_MEMBERCARD]: <MemberCard key={`${layout}-${idx}`} t={t} config={config} defaultValues={defaultValues} />,
                            [LAYOUT_ORDER_USEFULLINKS]: <MenuCard key={`${layout}-${idx}`} t={t} config={config} />,
                            [LAYOUT_ORDER_FAMILYCARD]: this.props.familyMembers.length > 0 && <FamilyPlanCard key={`${layout}-${idx}`} members={this.props.familyMembers} t={t} config={config} />
                        }[layout]
                    })
                }
            </div>
        );
    }
}


const mapStateToProps = state => {
    return {
        familyMembers: state.familyListReducer.members,
        loadingSpinner: state.loadingSpinnerReducer,
        summaryConfig: state.configurationReducer[CONFIG_SECTION_SUMMARY],
        accountSummaryConfig: state.configurationReducer[CONFIG_SECTION_ACCOUNT_SUMMARY]
    }
}

const mapDispatchToProps = {
    getFamilyMembers,
    fetchConfiguration
}

export default withSuspense()(connect(mapStateToProps, mapDispatchToProps)(withTranslation()(SidePanel)));